﻿using System.Web;
using System.Web.Optimization;

namespace DotNetTricks.COM
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            //site css
            bundles.Add(new StyleBundle("~/css/site").Include("~/css/bootstrap.css", "~/css/site.css", "~/css/style.css", "~/css/webslidemenu.css", "~/css/responsive.css", "~/css/responsive-panels-tabs.css"));

            //public css
            bundles.Add(new StyleBundle("~/css/public").Include("~/css/bootstrap.css", "~/css/site.css", "~/css/style.css", "~/css/responsive-panels-tabs.css"));

            //learn css
            bundles.Add(new StyleBundle("~/css/learn").Include("~/css/learn.css", "~/css/syntaxhiglighter.css"));

            //tutorial css
            bundles.Add(new StyleBundle("~/css/tutorial").Include("~/Content/tutorial/site.css", "~/Content/tutorial/webslidemenu.css", "~/css/syntaxhiglighter.css", "~/Content/tutorial/tutorial.css"));

            //jquery, validation and bootstrap js
            bundles.Add(new ScriptBundle("~/js/jquery").Include("~/js/jquery.js", "~/js/jquery.validate.js", "~/js/jquery.validate.unobtrusive.js", "~/js/bootstrap.js"));

            //site js and search box js
            bundles.Add(new ScriptBundle("~/js/site").Include("~/js/course-menu.js", "~/js/webslidemenu.js", "~/js/main.js", "~/js/responsive-tabs.js", "~/js/site.js", "~/js/jquery.storageapi.js", "~/js/multislider.js"));

            //site js and search box js
            bundles.Add(new ScriptBundle("~/js/siteppc").Include("~/js/webslidemenu.js", "~/js/main.js", "~/js/responsive-tabs.js", "~/js/site.js", "~/js/jquery.storageapi.js", "~/js/multislider.js"));
            //public js
            bundles.Add(new ScriptBundle("~/js/public").Include("~/js/main.js"));

            //search box js
            bundles.Add(new ScriptBundle("~/js/searchbox").Include("~/js/site.js", "~/js/jquery.storageapi.js"));

            // member bundling
            bundles.Add(new StyleBundle("~/member/css").Include("~/Areas/Member/Content/css/app2.css", "~/Areas/Member/Content/css/circle.css"));

            //vendor css
            bundles.Add(new StyleBundle("~/member/vendor/css").Include("~/Areas/Member/Content/vendors/bower_components/bootstrap-sweetalert/lib/sweet-alert.css", "~/Areas/Member/Content/vendors/bower_components/fullcalendar/dist/fullcalendar.css", "~/Areas/Member/Content/vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.css"));

            //chart js
            bundles.Add(new ScriptBundle("~/member/chart/js").Include(
                  "~/Areas/Member/Content/js/flot-charts/pie-chart.js", "~/Areas/Member/Content/js/flot-charts/bar-chart.js", "~/Areas/Member/Content/vendors/bootstrap-wizard/jquery.bootstrap.wizard.min.js"));

            //float js
            bundles.Add(new ScriptBundle("~/member/float/js").Include("~/Areas/Member/Content/vendors/bower_components/flot/jquery.flot.js", "~/Areas/Member/Content/vendors/bower_components/flot/jquery.flot.resize.js", "~/Areas/Member/Content/vendors/bower_components/flot/jquery.flot.pie.js", "~/Areas/Member/Content/vendors/bower_components/flot.tooltip/js/jquery.flot.tooltip.js", "~/Areas/Member/Content/vendors/bower_components/flot/curvedLines.js", "~/Areas/Member/Content/vendors/sparklines/jquery.sparkline.min.js", "~/Areas/Member/Content/vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"));

            //bowercomponents js
            bundles.Add(new ScriptBundle("~/member/bowercomponents/js").Include("~/Areas/Member/Content/vendors/bower_components/moment/min/moment.min.js", "~/Areas/Member/Content/vendors/bower_components/fullcalendar/dist/fullcalendar.min.js", "~/Areas/Member/Content/vendors/bower_components/jquery.nicescroll/jquery.nicescroll.min.js", "~/Areas/Member/Content/vendors/bower_components/Waves/dist/waves.min.js", "~/Areas/Member/Content/vendors/bower_components/bootstrap-sweetalert/lib/sweet-alert.min.js", "~/Areas/Member/Content/js/functions.js", "~/Areas/Member/Content/js/demo.js"));

            //angularjs and test
            bundles.Add(new ScriptBundle("~/member/commonmok/js").Include(
               "~/Areas/Member/Content/mockuptest/scripts/angular.js", "~/Areas/Member/Content/mockuptest/scripts/angular-timer.js", "~/Areas/Member/Content/mockuptest/scripts/humanize-duration.js", "~/Areas/Member/Content/mockuptest/scripts/moment.js"));

            bundles.Add(new ScriptBundle("~/member/test/js").Include("~/Areas/Member/Content/mockuptest/scripts/test.init.js", "~/Areas/Member/Content/mockuptest/scripts/module.js", "~/Areas/Member/Content/mockuptest/scripts/filters.js", "~/Areas/Member/Content/mockuptest/scripts/test.factory.js", "~/Areas/Member/Content/mockuptest/scripts/test.controller.js"));
            bundles.Add(new ScriptBundle("~/member/Quiz/js").Include("~/Areas/Member/Content/mockuptest/scripts/Quiz.init.js", "~/Areas/Member/Content/mockuptest/scripts/Quizmodule.js", "~/Areas/Member/Content/mockuptest/scripts/Quizfilters.js", "~/Areas/Member/Content/mockuptest/scripts/Quiz.factory.js", "~/Areas/Member/Content/mockuptest/scripts/Quiz.controller.js"));

            //training
            //site css
            bundles.Add(new StyleBundle("~/css/training").Include("~/css/bootstrap.min.css", "~/css/common.css", "~/css/owl.carousel.css", "~/css/style.css", "~/css/responsive.css", "~/css/easy-responsive-tabs.css", "~/css/sm-core-css.css", "~/css/training.css"));

            //site css master
            bundles.Add(new StyleBundle("~/css/siteMaster").Include("~/css/bootstrap.css", "~/css/site.css", "~/css/style.css", "~/css/webslidemenu.css", "~/css/responsive.css", "~/css/responsive-panels-tabs.css", "~/css/masterSite.css"));

            bundles.Add(new ScriptBundle("~/ng/masterlayout").Include(
                "~/js/socialLogIninitializer.js",
                "~/js/angular.js",
                "~/js/app.js"
                ));
        }
    }
}