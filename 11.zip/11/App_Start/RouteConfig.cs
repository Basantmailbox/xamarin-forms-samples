﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace DotNetTricks.COM
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("StaticHtmls/{*path}");
            routes.MapMvcAttributeRoutes();

            AreaRegistration.RegisterAllAreas();

            routes.MapRoute(
                "QuestionRoute", // Route name
                "{controller}/{action}/{subcat}/{page}", // URL with parameters
                new { controller = "Home", action = "Index", subcat = "all", page = "1" },
                new[] { "DotNetTricks.COM.Controllers" }
              );

            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new[] { "DotNetTricks.COM.Controllers" }
              );


        }
    }
}