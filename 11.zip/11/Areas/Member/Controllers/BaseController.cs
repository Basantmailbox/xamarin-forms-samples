﻿using DNTData;
using DotNetTricks.COM.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    [CustomAuthorize(Roles = "Member")]
    public class BaseController : Controller
    {
        public CustomPrincipal CurrentUser
        {
            get
            {
                return HttpContext.User as CustomPrincipal;
            }
        }

        IUnitOfWork _iUnitOfWork;
        public IUnitOfWork UOF
        {
            get
            {
                if (_iUnitOfWork == null)
                    _iUnitOfWork = new UnitOfWork();
                return _iUnitOfWork;
            }
        }
    }
}
