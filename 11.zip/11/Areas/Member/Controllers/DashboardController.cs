﻿using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebCore;
using DNTWebCore.Enum;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    [RouteArea("Member")]
    public class DashboardController : BaseController
    {
        SmsClient sms = new SmsClient();
        int pageSize;
        public string ImgCloudPath = "";
        static CloudBlobClient blobClient;
        static CloudBlobContainer blobContainer;
        CloudStorageAccount storageAccount;

        public DashboardController()
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }

        public ActionResult Account()
        {
            //check memebership
            var membership = UOF.IMember.GetMembershipDetails(CurrentUser.UserId);
            CurrentUser.MembershipId = membership.MembershipId;
            CurrentUser.MembershipExpiry = membership.ExpiryDate;

            return View();
        }

        [ChildActionOnly]
        public ActionResult Courses()
        {
            List<CategoryCourseDTO> model = UOF.ICourse.GetCoursesByCategory().ToList();
            return View("_Courses", model);
        }

        public ActionResult Index()
        {
            ViewBag.Home = "Home";

            var categorywiseCourses = GetFreeCategorywiseCourses();
            List<CourseDTO> courseList = new List<CourseDTO>();
            foreach (var category in categorywiseCourses)
            {
                foreach (var course in category.Courses)
                {
                    var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                    CourseDTO obj = new CourseDTO
                    {
                        CourseId = course.CourseId,
                        Name = course.Name,
                        URL = course.URL,
                        DomainName = course.DomainName,
                        SmallBanner = course.SmallBanner,
                        MobileBanner = course.MobileBanner,
                        Sequence = course.Sequence,
                        Reviews = course.Reviews,
                        Learners = course.Learners,
                        CourseFeatures = course.CourseFeatures,
                        CourseDetailList = Feature,
                        IsFree = course.IsFree,
                    };
                    courseList.Add(obj);
                }
            }
            List<CourseDTO> model = courseList;
            Int64 memberId = CurrentUser.UserId;
            ViewBag.IsShowBookLink = UOF.IMember.IsShowBookLinkInMemberDashboard(memberId);

            return View(model);
        }
        protected List<CourseCategoryDTO> GetFreeCategorywiseCourses()
        {
            string key1 = "categorylistfree";
            var cachedata = CacheService.GetCacheList<CourseCategoryDTO>(key1);
            if (cachedata == null)
            {
                IEnumerable<CourseCategoryDTO> data = UOF.ICommonLogic.GetFreeCategorywiseMenuList();
                cachedata = CacheService.SetCacheList<CourseCategoryDTO>(key1, data, (int)CacheDuration.FullDay);
            }
            return cachedata.ToList();
        }
        [ChildActionOnly]
        public ActionResult Footer()
        {
            try
            {
                var courseList = UOF.ICommonLogic.GetFooterMenuCourses();
                return PartialView("_Footer", courseList);
            }
            catch (Exception)
            {
                throw;
            }
        }
        [ChildActionOnly]
        public ActionResult Menu()
        {
            try
            {
                ViewBag.profilecount = UOF.ICommonLogic.CheckMemberProfileDetails(CurrentUser.UserId);

                //check memebership
                var membership = UOF.IMember.GetMembershipDetails(CurrentUser.UserId);
                CurrentUser.MembershipId = membership.MembershipId;
                CurrentUser.MembershipExpiry = membership.ExpiryDate;

                return PartialView("_Menu");
            }
            catch (Exception)
            {
                throw;
            }
        }
        [ChildActionOnly]
        public ActionResult Header()
        {
            try
            {
                MemberNotificationsDTO model = new MemberNotificationsDTO();
                if (CurrentUser != null)
                {
                    int cusubid = UOF.IMember.GetCourseSubscription(Convert.ToInt32(CurrentUser.UserId));
                    model = UOF.IMember.GetMemberNotifications(cusubid, CurrentUser.UserId);
                    TempData["CourseSubscriptionId"] = cusubid;
                }
                return PartialView("_Header", model);
            }
            catch (Exception)
            {
                return null;
            }
        }

        [HttpGet]
        public ActionResult ViewMemberProfile()
        {
            if (CurrentUser != null)
            {
                ViewBag.ViewMemberProfile = "ViewMemberProfile";
                MemberDTO model = UOF.IMember.GetMember(CurrentUser.UserId);
                List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
                model.genderList = GenderList;

                List<SkillMaster> skList = UOF.IAdminMaster.GetAllSkillTypes();
                ///skills
                model.SelectedSkills = ViewBag.SelectedAreas = UOF.IAdminMaster.GetMemberSkillType(CurrentUser.UserId);
                List<SelectListItem> Select_List = new List<SelectListItem>();
                foreach (var s in skList)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = s.SkillId.ToString(),
                        Text = s.Name,
                        Selected = model.SelectedSkills.Where(m => m.SkillId == s.SkillId).Count() > 0 ? true : false
                    };

                    Select_List.Add(obj);
                }
                if (Select_List.Count > 0)
                {
                    foreach (var st in Select_List.Where(x => x.Selected == true).ToList())
                    {
                        model.Skills += st.Text + ", ";
                    }
                    model.Skills = model.Skills != null ? model.Skills.Remove(model.Skills.Length - 2) : "-- Please Add Your Skills --";
                }
                model.SkillList = Select_List;

                ///interested Skill
                model.SelectedInterestSkills = ViewBag.SelectedAreas = UOF.IAdminMaster.GetMemberInterestedSkill(CurrentUser.UserId);
                List<SelectListItem> Select_IList = new List<SelectListItem>();
                foreach (var s in skList)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = s.SkillId.ToString(),
                        Text = s.Name,
                        Selected = model.SelectedInterestSkills.Where(m => m.SkillId == s.SkillId).Count() > 0 ? true : false
                    };

                    Select_IList.Add(obj);
                }
                if (Select_IList.Count > 0)
                {
                    foreach (var st in Select_IList.Where(x => x.Selected == true).ToList())
                    {
                        model.InterestedSkills += st.Text + ", ";
                    }
                    model.InterestedSkills = model.InterestedSkills != null ? model.InterestedSkills.Remove(model.InterestedSkills.Length - 2) : "-- Please Add Your Interested Area --";
                }
                model.SkillInterestList = Select_IList;

                return View(model);
            }
            return RedirectToAction("Login", "Account", new { area = "" });
        }

        [HttpGet]
        public ActionResult EditMemberProfile()
        {
            if (CurrentUser != null)
            {
                MemberProfileDTO model = UOF.IMember.GetMemberProfile(CurrentUser.UserId);
                List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
                model.genderList = GenderList;

                return View(model);
            }
            return RedirectToAction("Login", "Account", new { area = "" });
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult UploadFile()
        {
            string _imgname = string.Empty;
            if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
            {
                if (CurrentUser != null)
                {
                    blobClient = storageAccount.CreateCloudBlobClient();
                    blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["memberImageFolder"].ToString());
                    blobContainer.CreateIfNotExistsAsync();

                    string pathurl = "";
                    string oldpic = CurrentUser.ProfilePic.Replace(ImgCloudPath, "");
                    var pic = System.Web.HttpContext.Current.Request.Files["MyImages"];
                    if (pic.ContentLength > 0)
                    {
                        var fileName = Path.GetFileName(pic.FileName);   //file name  
                        var ext = Path.GetExtension(pic.FileName);   //getting the extension(ex-.jpg)  

                        string name = Path.GetFileNameWithoutExtension(fileName);
                        string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                        string myfile = CurrentUser.UserId + time + ext; //

                        string _memberImageFolderLocation;
                        _memberImageFolderLocation = ConfigurationManager.AppSettings["memberImageFolder"].ToString();

                        string path = Path.Combine(Server.MapPath(_memberImageFolderLocation), myfile);
                        pathurl = "/" + _memberImageFolderLocation + myfile;

                        CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);

                        using (var fileStream = pic.InputStream)
                        {
                            blockBlob.UploadFromStream(fileStream);
                        }

                        Uri uri = new Uri(ImgCloudPath + oldpic);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();
                        _imgname = myfile;
                    }
                    else
                    {
                        pathurl = oldpic;
                    }
                    string ProfilePic = pathurl;

                    MemberProfileDTO memberModel = UOF.IMember.UpdateMemberProfilePic(CurrentUser.UserId, ProfilePic);
                    if (memberModel != null)
                    {
                        TempData["Message"] = "Profile has been Updated Successfully.";
                        //set cookie here
                        CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                        serializeModel.UserId = memberModel.MemberId;
                        serializeModel.Name = memberModel.Name;
                        serializeModel.MobileNo = memberModel.MobileNo;
                        serializeModel.Email = memberModel.Email;
                        serializeModel.Roles = CurrentUser.Roles;
                        serializeModel.ProfilePic = memberModel.ProfilePic;
                        serializeModel.CurrentLocation = CurrentUser.CurrentLocation;
                        //  serializeModel.DomainName = CurrentUser.DomainName;

                        string userData = JsonConvert.SerializeObject(serializeModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                 1,
                                 CurrentUser.Name,
                                 DateTime.Now,
                                 DateTime.Now.AddMinutes(30),
                                 false,
                                 userData);

                        string encTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                        Response.Cookies.Add(faCookie);
                        ModelState.Clear();
                    }
                }
            }
            return Json(Convert.ToString(_imgname), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveBiography(MemberProfileDTO model)
        {
            try
            {
                int flag = 1;
                model.MemberId = CurrentUser.UserId;
                UOF.IMember.UpdateMemberProfile(model, flag);
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult SaveMemberBasic(MemberProfileDTO model)
        {
            try
            {
                int flag = 2;
                model.MemberId = CurrentUser.UserId;
                UOF.IMember.UpdateMemberProfile(model, flag);
                CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                serializeModel.UserId = model.MemberId;
                serializeModel.Name = model.Name;
                serializeModel.MobileNo = CurrentUser.MobileNo;
                serializeModel.Email = CurrentUser.Email;
                serializeModel.CurrentLocation = model.CurrentLocation;
                serializeModel.Roles = CurrentUser.Roles;
                serializeModel.ProfilePic = CurrentUser.ProfilePic;
                serializeModel.ProfilePicDomain = CurrentUser.ProfilePicDomain;
                // serializeModel.DomainName = CurrentUser.DomainName;
                string userData = JsonConvert.SerializeObject(serializeModel);
                FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                         1,
                         CurrentUser.Name,
                         DateTime.Now,
                         DateTime.Now.AddMinutes(30),
                         false,
                         userData);

                string encTicket = FormsAuthentication.Encrypt(authTicket);
                HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                Response.Cookies.Add(faCookie);
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult SaveMemberContact(MemberProfileDTO model)
        {
            try
            {
                int flag = 3;
                model.MemberId = CurrentUser.UserId;
                UOF.IMember.UpdateMemberProfile(model, flag);
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult ChangePassword()
        {
            ViewBag.ChangePassword = "ChangePassword";
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordDTO model)
        {
            try
            {
                if (CurrentUser != null)
                {
                    ViewBag.ChangePassword = "ChangePassword";
                    model.Email = CurrentUser.Email;
                    bool validateOldPasswordStatus = UOF.IMember.ValidateMemberOldPassword(CurrentUser.Email, model.OldPassword);
                    if (validateOldPasswordStatus == true)
                    {

                        bool status = UOF.IMember.ChangePassword(model);
                        if (status == true)
                        {
                            FormsAuthentication.SignOut();
                            return RedirectToAction("PasswordChangedSuccessfully", "Account", new { area = "" });
                        }
                        else
                        {
                            ModelState.AddModelError("", "Something happend, Please try again later.");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Current Password does not matched.");
                    }
                }
                else
                {
                }
            }
            catch (Exception)
            { }
            return View(model);
        }

        public ActionResult CourseSubscription(int page = 1)
        {
            try
            {
                Int64 memberId = CurrentUser.UserId;
                PagingDTO<CourseSubscriptionDTO> model = UOF.IMember.GetMemberCourseSubscriptionDetails(memberId, page, pageSize);
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        public ActionResult ViewAllNotificationDetails(int page = 1, int courseId = 0)
        {
            try
            {
                Int64 memberId = CurrentUser.UserId;
                PagingDTO<CourseSubscriptionDTO> model = UOF.IMember.GetMemberBatchDetails(memberId, courseId, page, pageSize);
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        public ActionResult ViewAllMockupTestDetails(int page = 1, int batchId = 0, int courseSubscriptionId = 0)
        {
            try
            {
                // memberRepo.GetMockupTestDetails(batchId, courseSubscriptionId);
            }
            catch (Exception ex)
            { }
            return View();
        }


        [Route("batches-list")]
        public ActionResult Batcheslist()
        {
            ViewBag.Batcheslist = "Batcheslist";
            IEnumerable<BatchMasterDTO> model = UOF.ICommonLogic.GetBatchesDetailsList();
            return View(model);

        }
        [Route("payment-history")]
        public ActionResult PaymentHistory(int page = 1, int filterId = 1, string textsrch = "", string Date = "", int CourseId = 0, string Currency = "")
        {
            ViewBag.PaymentHistory = "PaymentHistory";
            DateTime? startDate = null;
            DateTime? endDate = null;

            //not in use this if
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
            }
            //this is in use
            else
            {
                startDate = Convert.ToDateTime("01/04/2019");
                endDate = DateTime.Today.AddDays(1);
            }
            textsrch = CurrentUser.Email;
            PagingDTO<TransactionDTO> model = new PagingDTO<TransactionDTO>();

            model = UOF.IAdminMaster.GetAllTransactionDetailsList(page, pageSize, filterId, textsrch, startDate.Value, endDate.Value, Currency, true, false, CourseId, null);

            if (model != null)
            {
                model.TotalRows = model.Data.Count();
                ViewBag.page = model.Page;
                decimal totalINR = 0m;
                decimal totalUSD = 0m;
                foreach (var item in model.Data)
                {
                    if (item.Currency == "INR")
                    {
                        totalINR += Math.Round(item.Total);
                    }
                    else
                    {
                        totalUSD += Math.Round(item.Total);
                    }
                }

                decimal totalGst = 0m;
                foreach (var item in model.Data)
                {
                    if (item.Currency == "INR")
                    {
                        if (item.IsGST)
                        {
                            totalGst += item.IGST;
                        }
                        else
                        {
                            totalGst += item.CGST + item.SGST;
                        }
                    }

                }
                ViewBag.TotalInrDisp = totalINR - totalGst;
                ViewBag.TotalUsdDisp = totalUSD;
                ViewBag.totalGstDisp = totalGst;
            }
            return View(model);
        }



        [HttpPost]
        [Route("print-invoice")]
        public ActionResult PrintInvoiceDetails(int id = 0)
        {
            try
            {
                //for page reload
                if (id != 0)
                {
                    TempData["id"] = id;
                }
                else if (TempData["id"] != null)
                {
                    id = Convert.ToInt32(TempData.Peek("id"));
                }

                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceById(id, true);
                string TransactionId = model.TransactionId;

                if (model != null)
                {
                    var invoicedet = UOF.IAdminMaster.GetInvoiceDetailsById(TransactionId);
                    model.CGST = invoicedet.CGST;
                    model.SGST = invoicedet.SGST;
                    model.IGST = invoicedet.IGST;
                    model.PAN = invoicedet.PAN;
                    model.GST = invoicedet.GSTIN;

                    if (model.Currency == "INR")
                    {
                        int stcode = Convert.ToInt32(model.StateCode);
                        if (stcode > 0)
                        {
                            var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                            var GSTDNT = Convert.ToInt32(TaxUtility.GSTDNT.Substring(0, 2));

                            if (tax != null)
                            {
                                if (stcode == GSTDNT)
                                {
                                    ViewBag.taxstate = "CGSTSGST";
                                    model.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                                    model.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                                    model.CGST = Math.Round((model.NetPrice * model.CGSTPercent) / 100, 2);
                                    model.SGST = Math.Round((model.NetPrice * model.SGSTPercent) / 100, 2);
                                    model.Price = Math.Round(model.NetPrice + model.CGST + model.SGST, 2);
                                }
                                else
                                {
                                    ViewBag.taxstate = "";
                                    model.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                                    model.IGST = Math.Round((model.NetPrice * model.IGSTPercent) / 100, 2);
                                    model.Price = Math.Round((model.NetPrice + model.IGST), 2);
                                }
                            }
                        }

                        //roundoff
                        if (model.Total > model.Price)
                        {
                            model.RoundOff = model.Total - model.Price;
                        }
                        else if (model.Total < model.Price)
                        {
                            model.RoundOff = model.Price - model.Total;
                        }
                    }
                }
                return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        [HttpGet]
        [Route("print-invoice/{id:int}/{insId}")]
        public ActionResult PrintInvoiceDetailsByInstallment(int id = 0, int insId = 0)
        {
            try
            {
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceForInstallmentById(id, insId, true);
                string TransactionId = model.InstallmentDetails.UID;
                if (model != null)
                {
                    var invoicedet = UOF.IAdminMaster.GetInvoiceDetailsById(TransactionId);
                    model.CGST = invoicedet.CGST;
                    model.SGST = invoicedet.SGST;
                    model.IGST = invoicedet.IGST;
                    model.PAN = invoicedet.PAN;
                    model.GST = invoicedet.GSTIN;
                    model.NetPrice = model.InstallmentDetails.NetPrice;
                    model.Price = invoicedet.Price;
                    model.Total = invoicedet.Total;

                    if (model.Currency == "INR")
                    {
                        int stcode = Convert.ToInt32(model.StateCode);
                        if (stcode > 0)
                        {
                            var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                            var GSTDNT = Convert.ToInt32(TaxUtility.GSTDNT.Substring(0, 2));

                            if (tax != null)
                            {
                                if (stcode == GSTDNT)
                                {
                                    ViewBag.taxstate = "CGSTSGST";
                                    model.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                                    model.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                                    model.CGST = Math.Round((model.NetPrice * model.CGSTPercent) / 100, 2);
                                    model.SGST = Math.Round((model.NetPrice * model.SGSTPercent) / 100, 2);
                                    model.Price = Math.Round(model.NetPrice + model.CGST + model.SGST, 2);
                                }
                                else
                                {
                                    ViewBag.taxstate = "";
                                    model.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                                    model.IGST = Math.Round((model.NetPrice * model.IGSTPercent) / 100, 2);
                                    model.Price = Math.Round((model.NetPrice + model.IGST), 2);
                                }
                            }
                        }

                        //roundoff
                        if (model.Total > model.Price)
                        {
                            model.RoundOff = model.Total - model.Price;
                        }
                        else if (model.Total < model.Price)
                        {
                            model.RoundOff = model.Price - model.Total;
                        }
                    }
                    return View(model);
                }
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        [HttpGet]
        [Route("~/PaymentDetails/{id:int}/{IsInstall:bool}")]
        public ActionResult PaymentDetails(int id = 0, bool IsInstall = false)
        {

            try
            {
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceById(id, true);

                ViewBag.Amount = Math.Round(model.Total);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.IsInstall = IsInstall;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        public ActionResult Deactivate()
        {
            try
            {
                if (CurrentUser != null)
                {
                    bool stat = UOF.IMember.DeactivateMember(Convert.ToInt32(CurrentUser.UserId));
                    if (stat == true)
                    {
                        return RedirectToAction("Login", "Account", new { area = "" });
                    }

                }

            }
            catch (Exception ex)
            { }
            return RedirectToAction("ViewMemberProfile");
        }

        public ActionResult Search()
        {
            return View();
        }

        public ActionResult ViewVideo()
        {
            return View();
        }

        public ActionResult RedirectMemberShipCourseVideo(int id = 1, int t = 0, bool f = false, int csId = 0, int b = 0)
        {
            TempData["id"] = id;
            TempData["t"] = t;
            TempData["f"] = f;
            TempData["csId"] = csId;

            //var ismas = Session["CourseType"] != null ? Session["CourseType"].ToString() : "0";
            //if ((int)EnumCourseType.MastersProgram == Convert.ToInt32(ismas))
            //{
            //    id = Convert.ToInt32(Session["CurId"]);
            //}
            //CourseSubscriptionMemberDTO check = UOF.ICourseTopic.CheckSubscriptions(id, csId, CurrentUser.UserId);
            //if (check != null)
            //{
            //    TempData["csId"] = csId;
            //    TempData["baId"] = b;
            //    TempData["flagSubsType"] = check.SubscriptionType;
            //    return RedirectToAction("CourseVideo");
            //}

            //TO DO:
            bool check = true;
            if (check)
            {
                return RedirectToAction("MembershipCourseVideo");
            }
            return RedirectToAction("CourseDetails", "CourseSubscription", new { id = id, csid = csId });
        }
        public ActionResult MembershipCourseVideo()
        {
            try
            {
                ViewBag.CursubsType = TempData["flagSubsType"];
                int courseid = (int)TempData["id"];
                int subtopic = (int)TempData["t"];
                bool RFlag = (bool)TempData["f"];

                ViewBag.id = courseid;
                ViewBag.csId = (int)TempData["csId"];

                //int csId = (int)TempData["csId"];
                //ViewBag.csId = (int)TempData["csId"];
                //int baId = (int)TempData["baId"];
                ViewBag.topic = 0;
                ViewBag.CurseName = UOF.ICourseTopic.GetCourseName(courseid);
                // ViewBag.VideoAccess = UOF.IAdminMaster.GetMemberCourseSubscribedVideo(csId);
                if (RFlag == false)
                {
                    ViewBag.RFlag = "false";
                    List<CourseTopic> model = UOF.ICourseTopic.getallVedioMenu(courseid);
                    if (subtopic != 0)
                        foreach (var top in model)
                        {
                            if (top.Subtopics.Where(x => x.SubTopicId == subtopic).FirstOrDefault() != null)
                            {
                                ViewBag.topic = top.Subtopics.Where(x => x.SubTopicId == subtopic).Select(x => x.TopicId).FirstOrDefault();
                                ViewBag.SubUrlPath = top.Subtopics.Where(x => x.SubTopicId == subtopic).Select(x => x.UrlPath).FirstOrDefault();
                            }
                        }

                    ViewBag.subtopic = subtopic;
                    return View(model);
                }
                //else
                //{
                //    ViewBag.RFlag = "true";
                //    List<CourseLiveSessionVideo> model1 = UOF.ICourseTopic.getallRVedioMenu(courseid, csId, baId);
                //    if (subtopic != 0)
                //        foreach (var top in model1)
                //        {
                //            if (top.LiveTopicId == subtopic)
                //            {
                //                ViewBag.topic = top.LiveTopicId;
                //                ViewBag.SubUrlPath = top.UrlPath;
                //            }
                //        }

                //    ViewBag.subtopic = subtopic;
                //    return View(model1);
                //}
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("Index");
        }

        public ActionResult RedirectCourseVideo(int id = 1, int t = 0, bool f = false, int csId = 0, int b = 0)
        {
            TempData["id"] = id;
            TempData["t"] = t;
            TempData["f"] = f;
            var ismas = Session["CourseType"] != null ? Session["CourseType"].ToString() : "0";
            if ((int)EnumCourseType.Instructorled == Convert.ToInt32(ismas))
            {
                id = Convert.ToInt32(Session["CurId"]);
            }
            CourseSubscriptionMemberDTO check = UOF.ICourseTopic.CheckSubscriptions(id, csId, CurrentUser.UserId);
            if (check != null)
            {
                TempData["csId"] = csId;
                TempData["baId"] = b;
                TempData["flagSubsType"] = check.SubscriptionType;
                return RedirectToAction("CourseVideo");
            }
            return RedirectToAction("ViewSubscribedCourseDetails", "CourseSubscription", new { id = csId });
        }

        public ActionResult CourseVideo()
        {
            try
            {
                ViewBag.CursubsType = TempData["flagSubsType"];
                int courseid = (int)TempData["id"];
                int subtopic = (int)TempData["t"];
                bool RFlag = (bool)TempData["f"];
                int csId = (int)TempData["csId"];
                ViewBag.csId = (int)TempData["csId"];
                int baId = (int)TempData["baId"];
                ViewBag.topic = 0;
                ViewBag.CurseName = UOF.ICourseTopic.GetCourseName(courseid);
                ViewBag.VideoAccess = UOF.IAdminMaster.GetMemberCourseSubscribedVideo(csId);
                if (RFlag == false)
                {
                    ViewBag.RFlag = "false";
                    List<CourseTopic> model = UOF.ICourseTopic.getallVedioMenu(courseid);
                    if (subtopic != 0)
                        foreach (var top in model)
                        {
                            if (top.Subtopics.Where(x => x.SubTopicId == subtopic).FirstOrDefault() != null)
                            {
                                ViewBag.topic = top.Subtopics.Where(x => x.SubTopicId == subtopic).Select(x => x.TopicId).FirstOrDefault();
                                ViewBag.SubUrlPath = top.Subtopics.Where(x => x.SubTopicId == subtopic).Select(x => x.UrlPath).FirstOrDefault();
                            }
                        }

                    ViewBag.subtopic = subtopic;
                    return View(model);
                }
                else
                {
                    ViewBag.RFlag = "true";
                    List<CourseLiveSessionVideo> model1 = UOF.ICourseTopic.getallRVedioMenu(courseid, csId, baId);
                    if (subtopic != 0)
                        foreach (var top in model1)
                        {
                            if (top.LiveTopicId == subtopic)
                            {
                                ViewBag.topic = top.LiveTopicId;
                                ViewBag.SubUrlPath = top.UrlPath;
                            }
                        }

                    ViewBag.subtopic = subtopic;
                    return View(model1);
                }
            }
            catch (Exception w)
            {
                return RedirectToAction("Index");
            }
        }
        [HttpPost]
        public JsonResult getNewotp(MemberDTO model)
        {
            try
            {
                string datanew = new Random().Next(1000, 9999).ToString();
                string data = "$143!" + datanew + "dnt8546n";
                if (data != "")
                {
                    string msg = "Your OTP for Dot Net Tricks is " + datanew;
                    Session["data"] = data;

                    try
                    {
                        sms.SendEnquiryInfo(msg, model.ContactNo);
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }


            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public JsonResult VerifyOtpcont(string OTPContText)
        {
            try
            {
                string sess = Session["data"].ToString();
                if (!string.IsNullOrEmpty(sess))
                {
                    string[] temp = sess.Split('!');
                    var data = temp[1].Substring(0, 4);
                    if (data == OTPContText)
                    {

                        ModelState.Clear();
                        Session["data"] = "";
                        return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);

                    }
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult QuizListHistory()
        {
            ViewBag.QuizHistory = "QuizHistory";
            int id = 1;
            List<MockUpTestMasterDTO> model = new List<MockUpTestMasterDTO>();
            model = UOF.IQuestionMaster.GetAllQuizList(id, pageSize, CurrentUser.UserId);
            PagingDTO<MockUpTestMasterDTO> obj = new PagingDTO<MockUpTestMasterDTO>();

            obj.Data = model;
            obj.Page = id;
            return View("_QuizListHistory", obj);
        }




    }
}