﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    public class TestController : BaseController
    {
        int pageSize;
        public TestController()

        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        public ActionResult StartTest(int mtmId = 0, int bId = 0, int csId = 0)
        {
            bool status = UOF.IQuestionMaster.IsMockupTestAlreadyTaken(mtmId, csId, bId);
            if (status == false)
            {
                MockupTestQuestionPaperDTO data = UOF.IQuestionMaster.GetMockupTestDetailsById(mtmId);
                if (data != null)
                {
                    ViewBag.MockupTestTitle = data.MockupTestTitle;
                    ViewBag.Duration = data.Duration * 60;
                    ViewBag.MockupTestMasterId = data.MockupTestMasterId;
                    ViewBag.Description = UOF.IAssessmentInstruction.Get(data.MockupTestMasterInstructionId).Description;
                    ViewBag.DifficultyLevel = data.DifficultyLevel;

                }
                ViewBag.CourseSubscriptionId = csId;
                TempData["id"] = mtmId;
                return View();
            }
            else
            {
                //test already taken - redirect to result page
                int mockupTestAttemptedStatusId = UOF.IQuestionMaster.GetMockupTestAttemptedStatusId(mtmId, csId, bId);
                return RedirectToAction("TestResult", "Test", new { id = mockupTestAttemptedStatusId });
            }
        }

        [HttpGet]
        public ActionResult TestResult(int id)
        {

            MockUpTestAttemptedStatusDTO data = UOF.IQuestionMaster.GetTestResult(id);
            ViewBag.CourseSubscriptionId = id;

            return View(data);
        }
        [HttpGet]
        public ActionResult QuizResult(int id)
        {
            MockUpTestAttemptedStatusDTO data = UOF.IQuestionMaster.GetQuizResult(id);
            if (data != null)
            {
                var categoryData = UOF.ICommonLogic.GetTechnologyCourses(null, data.CategoryID);
                data.Courses = categoryData.CategoryCourses;
            }
            return View(data);
        }
        public ActionResult TotalQuestionAnswerDetails(int id = 0)
        {
            try
            {
                IEnumerable<MockupTestQuestionOptionAnswerDTO> model = UOF.IQuestionMaster.GetTotalQuestionAnswerDetails(id);
                ViewBag.title = UOF.IQuestionMaster.getMockUpTitle(id);
                ViewBag.id = id;
                return View(model);
            }
            catch (Exception ex)
            {
                return RedirectToAction("TestResult", new { id = id });
            }
        }

        public ActionResult TotalQuestionAnswerDetailsForQuiz(int id = 0)
        {
            try
            {
                IEnumerable<MockupTestQuestionOptionAnswerDTO> model = UOF.IQuestionMaster.GetTotalQuestionAnswerDetailsForQuiz(id);
                ViewBag.title = UOF.IQuestionMaster.getMockUpTitleName(model.Select(x => x.MockupTestId).FirstOrDefault());
                ViewBag.id = id;
                return View(model);
            }
            catch (Exception ex)
            {
                return RedirectToAction("QuizResult", new { id = id });
            }
        }
        public ActionResult StartQuiz(int id = 0, bool isRetake = false)
        {
            try
            {
                var d = UOF.IMember.Get(CurrentUser.UserId);
                if (d.InterestedSkills != null)
                {
                    bool status = false;
                    if (isRetake == true)
                    {
                        status = UOF.IQuestionMaster.IsMockupQuizAlreadyTakenAgain(id, CurrentUser.UserId);
                    }
                    else
                    {
                        status = UOF.IQuestionMaster.IsMockupQuizAlreadyTaken(id, CurrentUser.UserId);
                    }
                    if (status == false)
                    {
                        MockupTestQuestionPaperDTO data = UOF.IQuestionMaster.GetMockupQuizDetailsById(id);
                        if (data != null)
                        {
                            ViewBag.MockupTestTitle = data.MockupTestTitle;
                            ViewBag.Duration = data.Duration * 60;
                            ViewBag.MockupTestMasterId = data.MockupTestMasterId;
                            ViewBag.Description = UOF.IAssessmentInstruction.Get(2).Description;
                            ViewBag.DifficultyLevel = data.DifficultyLevel;
                        }
                        else
                        {
                            return RedirectToAction("Index", "Dashboard", new { area = "Member" });
                        }
                        TempData["id"] = id;
                        return View();

                    }
                    else
                    {
                        //test already taken - redirect to result page
                        int mockupTestAttemptedStatusId = UOF.IQuestionMaster.GetMockupQuizAttemptedStatusId(id, CurrentUser.UserId);
                        return RedirectToAction("QuizResult", "Test", new { id = mockupTestAttemptedStatusId });
                    }

                }
                return RedirectToAction("FillSkill", "SkillTests", new { area = "", id = id });
            }
            catch (Exception e)
            {
            }
            return null;
        }

        public ActionResult QuizHistory()
        {
            ViewBag.QuizHistory = "QuizHistory";
            int id = 1;
            List<MockUpTestMasterDTO> model = new List<MockUpTestMasterDTO>();
            model = UOF.IQuestionMaster.GetAllQuizList(id, pageSize, CurrentUser.UserId);
            PagingDTO<MockUpTestMasterDTO> obj = new PagingDTO<MockUpTestMasterDTO>();

            obj.Data = model;
            obj.Page = id;

            return View(obj);
        }

    }
}
