﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    [RouteArea("Member")]
    public class LearningProgressController : BaseController
    {

        [ChildActionOnly]
        public ActionResult GetLearningStatus()
        {
            List<LearningProgressStatusDTO> lpDTOs = new List<LearningProgressStatusDTO>();
            if (CurrentUser != null)
            {
                lpDTOs = UOF.ILearningProgress.GetLearntStatus(CurrentUser.UserId);
            }

            return View("_LearningStatus", lpDTOs);

        }

        [ChildActionOnly]
        public ActionResult GetAllCompleted()
        {
            List<LearningProgressStatusDTO> lpDTOs = new List<LearningProgressStatusDTO>();
            if (CurrentUser != null)
            {
                lpDTOs = UOF.ILearningProgress.GetLearntStatus(CurrentUser.UserId);
            }

            return View("_AllCompleted", lpDTOs);

        }
        public ActionResult History()
        {
            return View();
        }

        public JsonResult HistoryData()
        {
            List<LearningProgressStatusDTO> lpDTOs = new List<LearningProgressStatusDTO>();
            if (CurrentUser != null)
            {
                lpDTOs = UOF.ILearningProgress.GetHistory(CurrentUser.UserId);
            }

            return Json(lpDTOs, JsonRequestBehavior.AllowGet);
        }

        public JsonResult ResetLearningCourse(int courseId)
        {
            List<LearningProgressStatusDTO> lpDTOs = new List<LearningProgressStatusDTO>();
            if (courseId > 0)
            {
                var result = UOF.ILearningProgress.ResetLearningCourse(CurrentUser.UserId, courseId);
                return Json(lpDTOs, JsonRequestBehavior.AllowGet);
            }
            return Json(lpDTOs, JsonRequestBehavior.AllowGet);
        }
    }
}