﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    public class AppController : Controller
    {
        [Route("~/app/member")]
        public ActionResult Index()
        {
            return View("~/Areas/Member/Views/App/Index.cshtml");
        }
    }
}