﻿using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    [RouteArea("Member")]
    public class BookmarkController : BaseController
    {

        public ActionResult History()
        {
            List<BookmarkDTO> bookmarkDTOs = new List<BookmarkDTO>();
            if (CurrentUser != null)
            {
                bookmarkDTOs = UOF.IBookmark.GetHistory(CurrentUser.UserId, (int)EnumCourseType.Books, 0);
            }
            return View(bookmarkDTOs);
        }

        [ChildActionOnly]
        public ActionResult GetBookmarked()
        {
            List<BookmarkDTO> bookmarkDTOs = new List<BookmarkDTO>();
            if (CurrentUser != null)
            {
                bookmarkDTOs = UOF.IBookmark.GetHistory(CurrentUser.UserId, (int)EnumCourseType.Books,3);
            }

            return View("_bookmarked", bookmarkDTOs);

        }
        public JsonResult HistoryData()
        {
            List<BookmarkDTO> bookmarkDTOs = new List<BookmarkDTO>();
            if (CurrentUser != null)
            {
                bookmarkDTOs = UOF.IBookmark.GetHistory(CurrentUser.UserId, (int)EnumCourseType.Books,0);
            }

            return Json(bookmarkDTOs, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetBookmarks()
        {
            List<Bookmark> lpDTOs = new List<Bookmark>();
            if (CurrentUser != null)
            {
                lpDTOs = UOF.IBookmark.GetHistory(CurrentUser.UserId, (int)EnumCourseType.Books);
            }

            return Json(lpDTOs, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteEntity(Guid entityId)
        {
            List<Bookmark> bookmarks = new List<Bookmark>();
            //if (string.IsNullOrEmpty(entityId))
            //{
                var result = UOF.IBookmark.DeleteEntity(entityId);
               return RedirectToAction("History");
            //}
            //else
            //{
            //    return RedirectToAction("History");
            //}
        }


    }
}