﻿using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DNTShared;
using DNTShared.DTO;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace DotNetTricks.COM.Areas.Member.Controllers
{
    [RouteArea("Member")]
    public class FreeResourcesController : BaseController
    {
        static CloudBlobClient blobClient;
        CloudStorageAccount storageAccount;
        public FreeResourcesController()
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
        }
        [HttpGet]
        public ActionResult EBooks()
        {
            if (CurrentUser != null)
            {
                MemberDTO model = UOF.IMember.GetMember(CurrentUser.UserId);
                return View(model);
            }
            return RedirectToAction("Login", "Account", new { area = "" });
        }

        public ActionResult DownloadDocuments(string id) 
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    int Documentid = Convert.ToInt32(id);
                    DocumentDTO data = UOF.IDocument.GetDocumentById(Documentid);
                    var ext = Path.GetExtension(data.DocumentUrl);
                    var filename = Path.GetFileName(data.DocumentUrl);
                    blobClient = storageAccount.CreateCloudBlobClient();

                    CloudBlobContainer container = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                    CloudBlockBlob blob = container.GetBlockBlobReference(filename);

                    Stream blobStream = blob.OpenRead();
                    if (ext == ".pdf" || ext == ".PDF")
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".pdf");
                    }
                    else
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".zip");
                    }
                 
                }

            }
            catch (Exception)
            { }
            return null;
        }

        [Route("ebooks")]
        [HttpGet]
        public ActionResult FreeBooks()
        {
            IEnumerable<BookMasterDTO> model = UOF.IBookMasters.GetAllBookList();
            ViewBag.FreeBooks = "FreeBooks";
            return View(model);
        }
        [HttpGet]
        public ActionResult FreeBooksList()
        {
            IEnumerable<BookMasterDTO> model = UOF.IBookMasters.GetAllBookList();
            ViewBag.FreeBooks = "FreeBooks";
            return View("_FreeBooksList",model);
        }
        public ActionResult DownloadBook(string id)
        {
            try
            {
                if (CurrentUser != null)
                {

                    int Documentid = Convert.ToInt32(id);

                    UOF.ICommonLogic.AddBookDownloadDetails(CurrentUser.UserId, Documentid); 

                    DocumentDTO data = UOF.IDocument.GetDocumentById(Documentid);
                    var ext = Path.GetExtension(data.DocumentUrl);
                    var filename = Path.GetFileName(data.DocumentUrl);
                    blobClient = storageAccount.CreateCloudBlobClient();

                    CloudBlobContainer container = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                    CloudBlockBlob blob = container.GetBlockBlobReference(filename);

                    Stream blobStream = blob.OpenRead();
                    if (ext == ".pdf" || ext == ".PDF")
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".pdf");
                    }
                    else
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".zip");
                    }
                    
                }
                else
                {
                    return RedirectToAction("Login", "Account", new { area = "" });
                }

            }
            catch (Exception)
            { }
            return RedirectToAction("Index", "Dasboard", new { area = "Member" });
        }

        
        public ActionResult DownloadBookFile(string id)
        {
            try
            {

                if (CurrentUser != null)
                {

                    int Documentid = Convert.ToInt32(id);

                    UOF.ICommonLogic.AddBookDownloadDetails(CurrentUser.UserId, Documentid); 

                    DocumentDTO data = UOF.IDocument.GetDocumentById(Documentid);
                    var ext = Path.GetExtension(data.DocumentUrl);
                    var filename = Path.GetFileName(data.DocumentUrl);
                    blobClient = storageAccount.CreateCloudBlobClient();

                    CloudBlobContainer container = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                    CloudBlockBlob blob = container.GetBlockBlobReference(filename);

                    Stream blobStream = blob.OpenRead();
                    if (ext == ".pdf" || ext == ".PDF")
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".pdf");
                    }
                    else
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".zip");
                    }
                   
                }
           
            }

            catch (Exception e)
            { return null; }
            return null;
            
        }
    }
}
