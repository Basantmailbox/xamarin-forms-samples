﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using System.Threading.Tasks;
using DNTWebUI.Models.Security;
using System.Globalization;

namespace DotNetTricks.COM.Areas.Member.Controllers
{

    public class CourseSubscriptionController : BaseController
    {
        int pageSize;
        public CourseSubscriptionController()

        {
            pageSize = WebConfigSetting.PageSize;
        }

        public ActionResult SubscribedCourses(int page = 1)
        {
            ViewBag.SubscribedCourses = "SubscribedCourses";
            Int64 memberId = CurrentUser.UserId;
            PagingDTO<CourseSubscriptionDTO> model = UOF.IMember.GetMemberCourseSubscriptionDetails(memberId, page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult SubscribedBooks(int page = 1)
        {
            ViewBag.SubscribedBooks = "SubscribedBooks";
            Int64 memberId = CurrentUser.UserId;
            PagingDTO<CourseSubscriptionDTO> model = UOF.IMember.GetMemberCourseSubscriptionDetails(memberId, page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult SubscribedCoursesList(int page = 1)
        {
            ViewBag.Home = "Home";
            Int64 memberId = CurrentUser.UserId;
            PagingDTO<CourseSubscriptionDTO> model = UOF.IMember.GetMemberCourseSubscriptionDetails(memberId, page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View("_SubscribedCourses", model);
        }
        public ActionResult SubscribedBookList(int page = 1)
        {
            ViewBag.Home = "Home";
            Int64 memberId = CurrentUser.UserId;
            PagingDTO<CourseSubscriptionDTO> model = UOF.IMember.GetMemberCourseSubscriptionDetails(memberId, page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View("_SubscribedBooks", model);
        }
        public ActionResult ViewSubscribedCourseDetails(int id = 0)
        {
            ViewBag.SubscribedCourses = "SubscribedCourses";
            var model = UOF.IMember.GetMemberSubscriptionDetail(id);
            if (model != null)
            {
                TempData["CourseSubscriptionId"] = model.CourseSubscriptionId;
                if (model.CertificateId != null)
                {
                    ViewBag.CertificateId = model.CertificateId;
                }
                else
                {
                    ViewBag.CertificateId = "Not Issued";
                }
            }
            return View(model);
        }

        //for membership
        public ActionResult CourseDetails(int id = 0, int csid = 0)
        {
            var model = UOF.ICourse.GetCourseDetails(id);
            if (model == null)
            {
                return RedirectToAction("Index", "Dashboard");
            }
            TempData["CourseSubscriptionId"] = csid;
            return View(model);
        }

        [TimeZoneFliter]
        [ChildActionOnly]
        public ActionResult MemberBatchDetails(int id)
        {
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            int week = GetIso8601WeekOfYear(DateTime.UtcNow);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            var timeOffSet = zone.Id;
            Session["zoneId"] = timeOffSet;


            var model = UOF.IMember.GetSubscribedMemberBatchDetails(id);
            if (model != null)
                Session["batid"] = model.BatchId;
            Session["CourseSubscriptionId"] = id;
            return PartialView("_MemberBatchDetails", model);
        }

        [ChildActionOnly]
        public ActionResult MemberAssessmentDetails(int id)
        {
            List<AssignedMockUpTestDTO> model = UOF.IMember.GetMockupTestDetails(id);
            TempData["CourseSubscriptionId"] = id;
            if (model != null)
            {
                int mtm = model.Select(s => s.AssessmentId).FirstOrDefault();
            }
            return PartialView("_MemberAssessmentDetails", model);
        }


        [TimeZoneFliter]
        public JsonResult GetBatchSchedule(int batchid, string countryZone = null)
        {
            try
            {
                var SelectedZone = countryZone;
                var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
                double minutes2 = Convert.ToDouble(defaultzone);

                int week = GetIso8601WeekOfYear(DateTime.UtcNow);
                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

                var timeOffSet = zone.Id;
                Session["zoneId"] = timeOffSet;
                ViewBag.timeOffSet = timeOffSet;
                if (countryZone != null && countryZone != "")
                {
                    timeOffSet = countryZone;
                }
                IEnumerable<BatchEventSchedule> model = UOF.IAdminMaster.GetBatchEventSchedule(batchid);
                int addHours = 0;
                var IsDayLight = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
                if (IsDayLight != null)
                {
                    addHours = IsDayLight.AppValue == "0" ? 0 : 1;
                }


                if (model.Count() != 0 && model != null)
                {
                    model = model.Select(x =>
                    {
                        x.StartDate = x.StartDateTime.ToClientTimeDate1(timeOffSet.ToString(), addHours).ToString("ddd MMM d yyyy HH: mm:ss 'GMT'");
                        return x;
                    });
                    return Json(model, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (System.Exception)
            {
                return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
            }

        }
        public ActionResult CourseVideos(int id)
        {
            SubscribeCourseDetailDTO model = UOF.ICourseTopic.GetCourseVideos(id);

            if (model != null)
            {
                if (model.CurPreRecTopiclist != null)
                {
                    TimeSpan sum = TimeSpan.Parse("00:00:00");
                    int c = 0;
                    foreach (var item in model.CurPreRecTopiclist)
                    {
                        sum = sum.Add(item.TotalTime);
                        c += item.Subtopics.Count();
                    }
                    ViewBag.AllTimeDuration = sum;
                    ViewBag.Lectures = c;
                }

                Session["CurId"] = model.CourseId;
            }
            return PartialView("_CourseVideos", model);
        }

        [ChildActionOnly]
        public ActionResult DocumentDetails(int id)
        {
            SubscribeCourseDetailDTO model = UOF.ICourseTopic.GetMockupTestDetails(id);
            ViewBag.CourseSubscriptionType = model.CourseSubsType;
            TempData["CourseSubscriptionId"] = id;

            if (model != null)
            {
                if (model.CurPreRecTopiclist != null)
                {
                    TimeSpan sum = TimeSpan.Parse("00:00:00");
                    int c = 0;
                    foreach (var item in model.CurPreRecTopiclist)
                    {
                        sum = sum.Add(item.TotalTime);
                        c += item.Subtopics.Count();
                    }
                    ViewBag.AllTimeDuration = sum;
                    ViewBag.Lectures = c;
                }

                Session["CurId"] = model.CourseId;
                Session["BatchIdLive"] = model.BatchIdLive;
                Session["CourseType"] = (int)EnumCourseType.SelfPlaced;
                ViewBag.Certificate = UOF.ICourse.getCertificateLink(model.CourseId, CurrentUser.UserId);
                int mtm = model.AssingMockList.Select(s => s.AssessmentId).FirstOrDefault();
            }
            return PartialView("_DocumentDetails", model);
        }

        public PartialViewResult TopicDetails(int id, int cursubs)
        {
            SubscribeCourseDetailDTO model = UOF.ICourseTopic.GetTopicDetails(id, cursubs);
            ViewBag.CourseSubscriptionType = model.CourseSubsType;
            TempData["CourseSubscriptionId"] = cursubs;
            Session["CourseType"] = (int)EnumCourseType.Instructorled;
            return PartialView("_TopicDetails", model);
        }

        public ActionResult ViewForum(int id = 0, int page = 1, int CourseId = 0, string textsrch = "")
        {
            ViewBag.ViewForum = "ViewForum";
            Session["Sid"] = "";
            CourseSubscriptionDTO model1 = UOF.IMember.GetMemberSubscriptionDetail(id);

            PagingDTO<ForumMasterDTO> model = UOF.ICommentMaster.GetallForum(page, pageSize, CurrentUser.UserId, model1.CourseId, textsrch);
            if (model1 != null)
            {
                TempData["CourseSubscriptionId"] = model1.CourseSubscriptionId;
                ViewBag.Course = model1.Course;
                ViewBag.strSubscribeDate = model1.strSubscribeDate;
                ViewBag.strExpiryDate = model1.strExpiryDate;
                model.CourseId = model1.CourseId;
                Session["Sid"] = model1.CourseSubscriptionId;
            }
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageSize;

            }
            if (CurrentUser == null)
            {
                ViewBag.user = 0;

            }
            else { ViewBag.user = CurrentUser.UserId; }
            return View(model);
        }

        public ActionResult CourseForum(int id = 0, int page = 1, int CourseId = 0, string textsrch = "")
        {
            ViewBag.ViewForum = "CourseForum";
            CourseDTO course = UOF.ICourse.GetCourseDetails(id);

            PagingDTO<ForumMasterDTO> model = UOF.ICommentMaster.GetallForum(page, pageSize, CurrentUser.UserId, course.CourseId, textsrch);
            if (course != null)
            {
                ViewBag.Url = course.URL;
                ViewBag.Course = course.Name;
                model.CourseId = course.CourseId;
            }
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageSize;
            }
            if (CurrentUser == null)
            {
                ViewBag.user = 0;

            }
            else { ViewBag.user = CurrentUser.UserId; }
            return View(model);
        }

        [HttpPost]
        public ActionResult ForumPage(ForumMaster obj)
        {
            ViewBag.ViewForum = "ViewForum";
            if (CurrentUser != null)
            {
                bool status = UOF.ICommentMaster.SaveForum(obj, CurrentUser.UserId);
                if (status == true)
                {
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public ActionResult showforumlist(Guid id)
        {
            try
            {
                ForumMasterDTO model = UOF.ICommentMaster.GetallForumDetails(id);
                return View(model);
            }
            catch (Exception ec)
            {
                return null;
            }
        }
        [HttpPost]
        public async Task<ActionResult> showforumlist(ForumMasterDTO data)
        {
            try
            {
                var status = await Task.Run(() => UOF.ICommentMaster.SaveReply(data, CurrentUser.UserId));
                if (status == false)
                {
                    var sid = (int)Session["Sid"];
                    return Json(new { msg = "fail", id = sid }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("showforumlist", new { id = data.FId });
            }
        }


        public static int GetIso8601WeekOfYear(DateTime time)
        {
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(time);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                time = time.AddDays(3);
            }
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(time, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        static DateTime YearWeekDayToDateTime(int year, DayOfWeek day, int week)
        {
            DateTime startOfYear = new DateTime(year, 1, 1);
            int daysToFirstCorrectDay = (((int)day - (int)startOfYear.DayOfWeek) + 7) % 7;
            return startOfYear.AddDays(7 * (week - 1) + daysToFirstCorrectDay);
        }
        static string GetBatchDays(string BatchDays, TimeSpan time1, DateTime day1,int addHours, string countryZone = null)
        {
            if (BatchDays != null)
            {
                var batchDays = BatchDays.Split(',');
                string batch = string.Empty;
                int week = GetIso8601WeekOfYear(day1);
                
                foreach (var item in batchDays)
                {
                    DayOfWeek day = DayOfWeek.Sunday;
                    switch (item.ToString())
                    {
                        case "0":
                            day = DayOfWeek.Monday;
                            break;
                        case "1":
                            day = DayOfWeek.Tuesday;
                            break;
                        case "2":
                            day = DayOfWeek.Wednesday;
                            break;
                        case "3":
                            day = DayOfWeek.Thursday;
                            break;
                        case "4":
                            day = DayOfWeek.Friday;
                            break;
                        case "5":
                            day = DayOfWeek.Saturday;
                            break;
                        case "6":
                            day = DayOfWeek.Sunday;
                            break;
                    }
                    DateTime batchdate = YearWeekDayToDateTime(DateTime.UtcNow.Year, day, week);
                    batchdate = batchdate.Add(time1);
                    if (batch == string.Empty)
                    {
                        batch = batchdate.ToClientTimeDate1(countryZone.ToString(), addHours).DayOfWeek.ToString();
                    }
                    else { batch = batch + "," + batchdate.ToClientTimeDate1(countryZone.ToString(), addHours).DayOfWeek.ToString(); }
                }
                return batch;
            }
            return "";
        }

        [HttpGet]
        [TimeZoneFliter]
        public ActionResult getmemberbatchdetails(int Id = 0, string countryZone = null)
        {

            var SelectedZone = countryZone;//.Replace(":", "");
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);

            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            int week = GetIso8601WeekOfYear(DateTime.UtcNow);

            var model = UOF.IMember.GetSubscribedMemberBatchDetails(Id);
            if (model != null)
                Session["batid"] = model.BatchId;
            Session["CourseSubscriptionId"] = Id;
            var timeOffSet = zone.Id;
            ViewBag.timeOffSet = timeOffSet;
            if (countryZone != null && countryZone != "")
            {
                timeOffSet = countryZone;
            }
            int addHours = 0;
            var IsDayLight = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
            if (IsDayLight != null)
            {
                addHours = IsDayLight.AppValue == "0" ? 0 : 1;
            }
            try
            {
                if (model != null)
                {
                    

                    model.StartDate = model.StartDate.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                    model.BatchDays = GetBatchDays(model.BatchDays, model.BatchTiming.TimeOfDay, model.StartDate,addHours, timeOffSet.ToString());
                    model.EndDate = model.EndDate.Value.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                    model.BatchTiming = model.BatchTiming.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                    model.BatchStartTimingDisplay = model.BatchTiming.ToString("MM/dd/yyyy HH:mm");
                    model.BatchEndTiming = model.BatchEndTiming.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                    model.BatchEndTimingDisplay = model.BatchEndTiming.ToString("MM/dd/yyyy HH:mm");
                    ViewBag.flag = "1";
                    return Json(model, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (System.Exception)
            {
                return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult PrintCertificate(long id = 0)
        {
            CertificateMaster data = UOF.ICourse.getCertificateView(id);
            return RedirectToAction("CertificateForPrint", data);

        }

        public ActionResult CertificateForPrint(CertificateMaster data1)
        {
            CertificateMaster data = UOF.ICourse.getCertificateView(data1.Id);
            if (data.IssueDate != null)
            {
                var d = data.IssueDate.Day;
                string d2d = d.ToString();
                string daySuffix =
                    (data.IssueDate.Day == 11 || data.IssueDate.Day == 12 || data.IssueDate.Day == 13) ? "th"
                    : (d2d == "1") ? "st"
                    : (d2d == "2") ? "nd"
                    : (d2d == "3") ? "rd"
                    : "th";
                data.disIssueDate = d2d + "<sup>" + daySuffix + "</sup>";
            }
            return new Rotativa.ViewAsPdf("CertificateForPrint", data)
            {
                FileName = data.Name + "_" + data.CourseName + ".pdf",
                PageMargins = new Rotativa.Options.Margins(1, 1, 0, 0),
                PageOrientation = Rotativa.Options.Orientation.Landscape,
            };
        }
    }
}
