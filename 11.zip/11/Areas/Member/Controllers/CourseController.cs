﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using System.Threading.Tasks;
using DNTWebUI.Models.Security;
using System.Globalization;

namespace DotNetTricks.COM.Areas.Member.Controllers
{

    public class CourseController : BaseController
    {
        int pageSize;
        public CourseController()

        {
            pageSize = WebConfigSetting.PageSize;
        }
        public ActionResult EarnedCertificates()
        {
            PagingDTO<CertificateMaster> model = new PagingDTO<CertificateMaster>();
            ViewBag.CertificateLists = "EarnedCertificates";

            if (CurrentUser != null)
            {

                model = UOF.ICourse.GetCertificateLists(CurrentUser.UserId);
            }
            //if (model != null)
            //{
            //    ViewBag.page = model.Page;
            //}
            return View(model);
        }

        public ActionResult ViewCertificateById(int id)
        {
            CertificateMaster data = UOF.ICourse.getCertificateView(id);
            //  var emp = ctx.EmployeeInfoes.Where(e => e.EmpNo == id).First();
            return View(data);
        }
        public ActionResult ViewCertificate(int id)//CertificateMaster data1)
        {
            try
            {
                CertificateMaster data = UOF.ICourse.getCertificateView(id);
                //Session["dataId"] = "";
                if (data != null)
                {
                    Session["cerId"] = id;
                    if (data.IssueDate != null)
                    {
                        var d = data.IssueDate.Day;
                        string d2d = d.ToString();
                        string daySuffix =
                            (data.IssueDate.Day == 11 || data.IssueDate.Day == 12 || data.IssueDate.Day == 13) ? "th"
                            : (d2d == "1") ? "st"
                            : (d2d == "2") ? "nd"
                            : (d2d == "3") ? "rd"
                            : "th";
                        data.disIssueDate = d2d + "<sup>" + daySuffix + "</sup>";
                    }
                    //new Rotativa.ViewAsPdf
                    return View("CertificateForPrint", data);
                    //{
                    //    FileName = data.Name + "_" + data.CourseName + ".pdf",
                    //    PageMargins = new Rotativa.Options.Margins(1, 1, 0, 0),
                    //    PageOrientation = Rotativa.Options.Orientation.Landscape,
                    //};
                }
                else
                {
                    return RedirectToAction("EarnedCertificates");
                }

            }
            catch (Exception w)
            {
                return RedirectToAction("EarnedCertificates");
            }

            //var report = new Rotativa.ActionAsPdf("IndexById", new { id = id });
            //return report;
        }

        public ActionResult DownloadCertificate()
        {
            try
            {
                if (Session["cerId"] != null)
                {
                    int id = Convert.ToInt32(Session["cerId"].ToString());
                    CertificateMaster data = UOF.ICourse.getCertificateView(id);
                    //Session["dataId"] = "";
                    if (data != null)
                    {
                        Session["cerId"] = "";
                        if (data.IssueDate != null)
                        {
                            var d = data.IssueDate.Day;
                            string d2d = d.ToString();
                            string daySuffix =
                                (data.IssueDate.Day == 11 || data.IssueDate.Day == 12 || data.IssueDate.Day == 13) ? "th"
                                : (d2d == "1") ? "st"
                                : (d2d == "2") ? "nd"
                                : (d2d == "3") ? "rd"
                                : "th";
                            data.disIssueDate = d2d + "<sup>" + daySuffix + "</sup>";
                        }
                        //
                        return new Rotativa.ViewAsPdf("CertificateForDownload", data)
                        {
                            FileName = data.Name + "_" + data.CourseName + ".pdf",
                            PageMargins = new Rotativa.Options.Margins(1, 1, 0, 0),
                            PageOrientation = Rotativa.Options.Orientation.Landscape,
                        };
                    }
                    else
                    {
                        return RedirectToAction("EarnedCertificates");
                    }
                }
                else
                {
                    return RedirectToAction("EarnedCertificates");
                }

            }
            catch (Exception w)
            {
                return RedirectToAction("EarnedCertificates");
            }

            //var report = new Rotativa.ActionAsPdf("IndexById", new { id = id });
            //return report;
        }

    }
}
