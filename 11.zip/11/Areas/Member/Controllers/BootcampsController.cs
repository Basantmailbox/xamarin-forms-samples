﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DotNetTricks.COM.Security;
using DNTData;


using System.Configuration;
using DNTShared;
using DNTShared.DTO;

namespace DotNetTricks.COM.Areas.Member.Controllers
{   
    public class BootcampsController : BaseController
    {
        int pageSize;

        public BootcampsController()
            
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }

        [HttpGet]
        public ActionResult JoinBootcamp()
        {
            try
            {
                if (CurrentUser != null)
                {
                    if (Session["eventid"] != null)
                    {
                        int _eventId = Convert.ToInt32(Session["eventid"]);
                        if (_eventId > 0)
                        {
                            EventDTO eventData = UOF.IEvent.GetEventDetailsByEventId(_eventId);
                            if (!string.IsNullOrEmpty(eventData.EventTitle))
                            {
                                EventRegistrationDTO model = new EventRegistrationDTO();

                                model.EventId = Convert.ToInt32(_eventId);
                                model.MemberId = CurrentUser.UserId;
                                model.EmailId = CurrentUser.Email;
                                model.Name = CurrentUser.Name;
                                model.MobileNo = CurrentUser.MobileNo;
                                model.Event = eventData;
                                return View(model);
                            }
                        }
                    }
                    return RedirectToAction("Index", "Dashboard", new { area = "Member" });
                }
                else
                {
                    return RedirectToAction("Login", "Account", new { area = "" });
                }
            }
            catch (Exception ex) { }
            return View();
        }

        [HttpPost]
        public ActionResult JoinBootcamp(EventRegistrationDTO model)
        {
            if (CurrentUser != null)
            {
                model.MemberId = CurrentUser.UserId;

                bool? isAlreadyRegister = UOF.IEvent.IsMemberAlreadyRegisteredForEvent(CurrentUser.UserId, model.EventId);
                if (isAlreadyRegister == true)
                {
                    ModelState.AddModelError("", "You have been already registered for this event.");
                    if (Session["eventid"] != null)
                    {
                        int _eventId = Convert.ToInt32(Session["eventid"]);
                        if (_eventId > 0)
                        {
                            EventDTO eventData = UOF.IEvent.GetEventDetailsByEventId(_eventId);
                            if (!string.IsNullOrEmpty(eventData.EventTitle))
                            {
                                EventRegistrationDTO registerModel = new EventRegistrationDTO();
                                registerModel.EventId = Convert.ToInt32(_eventId);
                                registerModel.MemberId = CurrentUser.UserId;
                                registerModel.EmailId = CurrentUser.Email;
                                registerModel.Name = CurrentUser.Name;
                                registerModel.MobileNo = CurrentUser.MobileNo;
                                registerModel.Event = eventData;
                                return View(registerModel);
                            }
                        }
                    }
                }

                bool status = UOF.IEvent.MemberEventRegistration(model);
                if (status == true)
                {

                    MailClient.SendMail_MemberEventRegistration(model);
                    return RedirectToAction("BootcampRegistrationSuccessful", "Bootcamps", new { area = "Member" });
                }

            }
            return RedirectToAction("JoinBootcamp", "Bootcamps", new { area = "Member" });
        }

        public ActionResult BootcampRegistrationSuccessful()
        {
            try
            {
                if (CurrentUser != null)
                {
                    if (Session["eventid"] != null)
                    {
                        int _eventId = Convert.ToInt32(Session["eventid"]);
                        if (_eventId > 0)
                        {
                            Session["eventid"] = null;
                            EventDTO eventData = UOF.IEvent.GetEventDetailsByEventId(_eventId);
                            if (!string.IsNullOrEmpty(eventData.EventTitle))
                            {
                                EventRegistrationDTO model = new EventRegistrationDTO();
                                model.EventId = Convert.ToInt32(_eventId);
                                model.Event = eventData;
                                return View(model);
                            }
                        }
                    }
                    return RedirectToAction("Index", "Dashboard", new { area = "Member" });
                }
                else
                {
                    return RedirectToAction("Login", "Account", new { area = "" });
                }
            }
            catch (Exception ex) { }
            return View();
        }
    }
}
