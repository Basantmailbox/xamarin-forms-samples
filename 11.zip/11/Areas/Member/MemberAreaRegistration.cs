﻿using System.Web.Mvc;

namespace DotNetTricks.COM.Areas.Member
{
    public class MemberAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Member";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
               "Member_Video",
               "Member/{controller}/{action}/{id}/{t}/{f}/{csId}",
               new[] { "DotNetTricks.COM.Areas.Member.Controllers" }
            );

            context.MapRoute(
               "Member_Mockup",
               "Member/{controller}/{action}/{mtmId}/{bId}/{csId}",
               new[] { "DotNetTricks.COM.Areas.Member.Controllers" }
            );
            context.MapRoute(
              "Member_Membership",
              "Member/{controller}/{action}/{id}/{csId}",
              new[] { "DotNetTricks.COM.Areas.Member.Controllers" }
            );
            context.MapRoute(
                "Member_default",
                "Member/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                new[] { "DotNetTricks.COM.Areas.Member.Controllers" }
            );
        }
    }
}
