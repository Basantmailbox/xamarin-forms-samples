﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Web.Security;
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System.IO;
using System.Configuration;

using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;

namespace DotNetTricks.COM.Areas.Author.Controllers
{
    public class AccountController : Controller
    {
        // GET: /Author/Account/
         IUnitOfWork UOF;
         public AccountController()
        {
            UOF = new UnitOfWork();
        }
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        // [ValidateAntiForgeryToken]
        public ActionResult Index(Users user, string msg)
        {
            if (user.UserName.Trim() != "" && user.Password.Trim() != "")
            {
                ViewBag.Message = "";
                try
                {
                    var q = UOF.IUser.GetSingle(user.UserName.Trim(), user.Password.Trim());
                    if (q != null)
                    {
                        CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                        serializeModel.Name = q.UserName;
                        serializeModel.Name = q.Name;
                        serializeModel.Roles = q.IsAdmin == true ? new string[] { "Admin" } : new string[] { "User" };

                        string userData = JsonConvert.SerializeObject(serializeModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                 1,
                                q.Name,
                                 DateTime.Now,
                                 DateTime.Now.AddMinutes(60),
                                 true,
                                 userData);

                        string encTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                        Response.Cookies.Add(faCookie);

                        return RedirectToAction("Dashboard","Home");
                    }
                    else
                    {
                        ViewBag.Message = "The user name or password provided is incorrect";
                    }
                }
                catch (Exception ex)
                {
                }
            }
            // If we got this far, something failed, redisplay form
            return View(user);
        }
    }
}
