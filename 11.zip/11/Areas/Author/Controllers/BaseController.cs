﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DotNetTricks.COM.Security;
using DNTData;

namespace DotNetTricks.COM.Areas.Author.Controllers
{
    public class BaseController : Controller
    {
        protected  CustomPrincipal CurrentUser
        {
            get { return HttpContext.User as CustomPrincipal; }
        }
        IUnitOfWork _iUnitOfWork;
        public IUnitOfWork UOF
        {
            get
            {
                if (_iUnitOfWork == null)
                    _iUnitOfWork = new UnitOfWork();
                return _iUnitOfWork;
            }
        }
    }
}