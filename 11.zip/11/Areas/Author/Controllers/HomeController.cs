﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Web.Security;
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System.IO;
using System.Configuration;

using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;

namespace DotNetTricks.COM.Areas.Author.Controllers
{
    public class HomeController : BaseController
    {
        int pageSize;
        public HomeController()
            
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }


        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Account", null);
        }

        [HttpPost]
        // [ValidateAntiForgeryToken]
        public ActionResult Index(Users user, string msg)
        {
            if (user.UserName.Trim() != "" && user.Password.Trim() != "")
            {
                ViewBag.Message = "";
                try
                {
                    var q = UOF.IUser.GetAll().Where(m => m.UserName == user.UserName && m.Password == user.Password).FirstOrDefault();
                    if (q != null)
                    {
                        CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                        serializeModel.Name = q.UserName;
                        serializeModel.Name = q.Name;
                        serializeModel.Roles = q.IsAdmin == true ? new string[] { "Admin" } : new string[] { "User" };

                        string userData = JsonConvert.SerializeObject(serializeModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                 1,
                                q.Name,
                                 DateTime.Now,
                                 DateTime.Now.AddMinutes(60),
                                 true,
                                 userData);

                        string encTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                        Response.Cookies.Add(faCookie);

                        return RedirectToAction("Dashboard");
                    }
                    else
                    {
                        ViewBag.Message = "The user name or password provided is incorrect";
                    }
                }
                catch (Exception ex)
                {
                }
            }
            // If we got this far, something failed, redisplay form
            return View(user);
        }

        [Authorize]
        void BindCategory()
        {
            //Basant_Rep
            var tblcatlist = UOF.ICategory.GetAll();//.Categories.Select(m => m).ToList().OrderBy(x => x.CategoryName);
            List<CategoryDTO> catlist = new List<CategoryDTO>();

            CategoryDTO mobj = new CategoryDTO();
            mobj.CategoryID = 0;
            mobj.CategoryName = "Select";
            catlist.Add(mobj);
            foreach (var item in tblcatlist)
            {
                mobj = new CategoryDTO();
                mobj.CategoryID = item.CategoryID;
                mobj.CategoryName = item.CategoryName;

                catlist.Add(mobj);
            }
            ViewBag.Categories = catlist;
        }

        [Authorize]
        void BindEventType()
        {
            //Basant_Rep
            var tbleventtypelist = UOF.IEventTypes.GetAll().OrderBy(x => x.EventTypeName);

            List<EventType> eventTypeList = new List<EventType>();

            EventType mobj = new EventType();
            mobj.EventTypeId = 0;
            mobj.EventTypeName = "Select";
            eventTypeList.Add(mobj);

            foreach (var item in tbleventtypelist)
            {
                mobj = new EventType();
                mobj.EventTypeId = item.EventTypeId;
                mobj.EventTypeName = item.EventTypeName;

                eventTypeList.Add(mobj);
            }
            ViewBag.EventType = eventTypeList;
        }


        [Authorize]
        void BindPost(string Name)
        {

            List<TutorialDTO> tutlist = new List<TutorialDTO>();
            if (Name != "Shailendra Chauhan")
            {
                //Basant_Rep mobjentity.Tutorials.Where(x => x.PostedBy == Name).Select(m => m).ToList().OrderBy(m => m.Title);
                var tblcatlist = UOF.ITutorial.GetMany(Name);

                TutorialDTO mobj = new TutorialDTO();
                mobj.ID = "0";
                mobj.Title = "Select";
                tutlist.Add(mobj);

                foreach (var item in tblcatlist)
                {
                    mobj = new TutorialDTO();
                    mobj.ID = item.ID;
                    mobj.Title = item.Title;

                    tutlist.Add(mobj);
                }
                ViewBag.Tutorials = tutlist;
            }
            else
            {
                //Basant_Rep  mobjentity.Tutorials.Select(m => m).ToList().OrderBy(m => m.Title);
                var tblcatlist = UOF.ITutorial.GetAll().OrderBy(m => m.Title);
                TutorialDTO mobj = new TutorialDTO();
                mobj.ID = "0";
                mobj.Title = "Select";
                tutlist.Add(mobj);

                foreach (var item in tblcatlist)
                {
                    mobj = new TutorialDTO();
                    mobj.ID = item.ID;
                    mobj.Title = item.Title;

                    tutlist.Add(mobj);
                }
                ViewBag.Tutorials = tutlist;
            }
        }

        [Authorize]
        public ActionResult AddTutorial()
        {

            BindCategory();
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddTutorial = "AddTutorial";
            TutorialDTO Model = new TutorialDTO();
            List<MentorMaster> AuthorMasterList = UOF.ICourse.GetMentorMasterList();
            Model.AuthorMasterList = AuthorMasterList;
            return View(Model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddTutorial(TutorialDTO tutorial, string[] Authors)
        {
            try
            {
                if (this.CurrentUser.Name != null)
                {
                    bool isArticleURLAlreadyExists = UOF.ITutorial.Check_ArticleURL_Already_Exists(tutorial.ArticleUrl,1);
                    if (isArticleURLAlreadyExists == true)
                    {
                        ViewBag.ArticleURL = "Article Url already exists. Please enter again.";
                        BindCategory();
                        return View(tutorial);
                    }

                    Tutorial mobj = new Tutorial();
                    //Basant_Rep .Where(m => m.CategoryID == tutorial.CategoryID).Select(m => m.CategoryName).SingleOrDefault();
                    string CatName = UOF.ICategory.Get(tutorial.CategoryID).CategoryName;

                    if (CatName.ToLower() == "c#")
                        CatName = "csharp";
                    else if (CatName.ToLower() == "c# windows apps")
                        CatName = "cswinapps";

                    string Desc;
                    mobj.ID = Utility.GenerateID();
                    mobj.CategoryID = tutorial.CategoryID;
                    mobj.ShortDescription = tutorial.ShortDescription;
                    mobj.Authors = string.Join(",", Authors);
                    Desc = tutorial.Description.Replace("\r\n", "<br>");
                    Desc = Regex.Replace(Desc, @"\s+", " ");
                    Desc = Desc.Replace("<br>", "\r\n");
                    mobj.Description = Desc;
                    mobj.DomainName = tutorial.DomainName;
                    mobj.PostedBy = this.User.Identity.Name;
                    mobj.PostedDate = tutorial.PostedDate;
                    mobj.TutorialImage = tutorial.TutorialImage;
                    mobj.ShortTitle = tutorial.ShortTitle;
                    mobj.Title = tutorial.Title;
                    mobj.Version = tutorial.Version;
                    mobj.Tags = tutorial.Tags;
                    mobj.ArticleUrl = tutorial.ArticleUrl;
                    mobj.SourceCodeUrl = tutorial.SourceCodeUrl;
                    mobj.MetaKeywords = tutorial.MetaKeywords;

                    mobj.Url = "https://www.dotnettricks.com/learn/" + CatName.ToLower().Replace(" ", string.Empty).Replace(".", string.Empty);
                    mobj.TotalViews = 0;

                    UOF.ITutorial.Add(mobj);
                    UOF.SaveChanges();
                    if (mobj.TutorialID != 0)
                    {
                        string TUrl = ""; string Tfile = ""; var Textn = ""; string Tpath = ""; string FlagT = "";
                        if (tutorial.TImage != null && tutorial.TImage.ContentLength > 0)
                        {
                            FlagT = "T";
                            var fileName = Path.GetFileName(tutorial.TImage.FileName); //file name  
                            Textn = Path.GetExtension(tutorial.TImage.FileName); //getting the extension(ex-.jpg) 
                            string name = Path.GetFileNameWithoutExtension(fileName);
                        }
                        string _tutorialImageFolderLocation;
                        _tutorialImageFolderLocation = ConfigurationManager.AppSettings["ArticleImageFolder"].ToString();
                        if (FlagT == "T")
                        {
                            Tfile = Regex.Replace(tutorial.ShortTitle, "[^0-9a-zA-Z]+", "").ToLower() + "-header" + Textn; //
                            Tpath = Path.Combine(Server.MapPath(_tutorialImageFolderLocation), Tfile);
                            TUrl = _tutorialImageFolderLocation + Tfile;
                        }
                        string directoryPath = Server.MapPath(string.Format("~/{0}/", _tutorialImageFolderLocation));
                        if (!Directory.Exists(directoryPath))
                        {
                            Directory.CreateDirectory(directoryPath);
                        }
                        mobj.TutorialImage = TUrl;
                        if (mobj.TutorialImage != null)
                        {
                            if (TUrl != "")
                            {
                                tutorial.TImage.SaveAs(Tpath);
                            }
                            ModelState.Clear();
                        }
                    }
                    UOF.SaveChanges();
                    ViewBag.Message = "Tutorial has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;

            }
            BindCategory();
            TutorialDTO Model = new TutorialDTO();
            List<MentorMaster> AuthorMasterList = UOF.ICourse.GetMentorMasterList();
            Model.AuthorMasterList = AuthorMasterList;
            ViewBag.AddTutorial = "AddTutorial";
            return View(Model);
        }

        [Authorize]
        public ActionResult EditTutorial(String id)
        {
            ViewBag.id = id;
            BindPost(this.CurrentUser.Name);
            //ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditTutorial = "EditTutorial";

            if (id != "0")
            {
                //Basant_Rep
                var tutorial = UOF.ITutorial.GetAll().Where(m => m.ID == id).Select(m => new { Description = m.Description, m.MetaKeywords, m.ShortDescription, m.ShortTitle, m.Tags, m.Title, m.Version, m.Url, m.PostedDate, m.ArticleUrl, m.Authors, m.SourceCodeUrl, m.DomainName, m.TutorialImage }).ToList();


                foreach (var item in tutorial)
                {
                    TutorialDTO model = new TutorialDTO();
                    model.Description = item.Description;
                    model.MetaKeywords = item.MetaKeywords;
                    model.ShortDescription = item.ShortDescription;
                    model.ShortTitle = item.ShortTitle;
                    model.Tags = item.Tags;
                    model.Title = item.Title;
                    model.Version = item.Version;
                    model.Url = item.Url;
                    model.Authors = item.Authors;
                    model.ArticleUrl = item.ArticleUrl;
                    model.SourceCodeUrl = item.SourceCodeUrl;
                    model.PostedDate = item.PostedDate;
                    model.DomainName = item.DomainName;
                    model.TutorialImage = item.TutorialImage;
                    ViewData["PostedDate"] = item.PostedDate;

                    List<MentorMaster> AuthorMasterList = UOF.ICourse.GetMentorMasterList();
                    model.AuthorMasterList = AuthorMasterList;
                    model.AuthorList = ViewBag.SelectedAuthors = UOF.ITutorial.GetArticleAuthors(id,1);
                    List<SelectListItem> Select_List = new List<SelectListItem>();
                    foreach (var m in AuthorMasterList)
                    {
                        SelectListItem obj = new SelectListItem()
                        {
                            Value = m.MentorId.ToString(),
                            Text = m.Name,
                            Selected = model.AuthorList.Where(me => me.MentorId == m.MentorId).Count() > 0 ? true : false
                        };

                        Select_List.Add(obj);
                    }
                    model.AuthorMaster = Select_List;
                    return View(model);
                }

            }
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditTutorial(TutorialDTO tutorial, FormCollection AuthorName)
        {
            String mId = AuthorName["AuthorName"];

            try
            {
                string TUrl = ""; string Tfile = ""; var Textn = ""; string Tpath = ""; string FlagT = ""; string Toldpic = ""; string fT = "";
                if (this.User.Identity.Name != null)
                {
                    //Basant_Rep .Where(m => m.ID == tutorial.ID).FirstOrDefault();
                    Tutorial mobj = UOF.ITutorial.GetTutorialByTID(tutorial.ID);
                    string Desc;

                    if (mobj.CategoryID > 0)
                    {
                        //Basant_Rep Categories.Where(m => m.CategoryID == mobj.CategoryID).Select(m => m.CategoryName).SingleOrDefault();
                        string CatName = UOF.ICategory.Get(mobj.CategoryID).CategoryName;

                        if (CatName.ToLower() == "c#")
                            CatName = "csharp";
                        else if (CatName.ToLower() == "c# windows apps")
                            CatName = "cswinapps";
                        Toldpic = mobj.TutorialImage;
                        if (tutorial.TImage != null && tutorial.TImage.ContentLength > 0)
                        {
                            FlagT = "T";
                            var fileName = Path.GetFileName(tutorial.TImage.FileName); //file name  
                            Textn = Path.GetExtension(tutorial.TImage.FileName); //getting the extension(ex-.jpg)  
                        }
                        string _articleImageFolderLocation;
                        _articleImageFolderLocation = ConfigurationManager.AppSettings["ArticleImageFolder"].ToString();
                        if (FlagT == "T")
                        {
                            Tfile = Regex.Replace(tutorial.ShortTitle, "[^0-9a-zA-Z]+", "").ToLower() + "-header" + Textn; //
                            Tpath = Path.Combine(Server.MapPath(_articleImageFolderLocation), Tfile);
                            TUrl = _articleImageFolderLocation + Tfile;
                        }
                        else
                        {
                            TUrl = Toldpic;
                            fT = "1";
                        }
                        string directoryPath = Server.MapPath(string.Format("~/{0}/", _articleImageFolderLocation));
                        if (!Directory.Exists(directoryPath))
                        {
                            Directory.CreateDirectory(directoryPath);
                        }

                        mobj.ShortDescription = tutorial.ShortDescription;
                        Desc = tutorial.Description.Replace("\r\n", "<br>");
                        Desc = Regex.Replace(Desc, @"\s+", " ");
                        Desc = Desc.Replace("<br>", "\r\n");
                        mobj.Description = Desc;
                        mobj.DomainName = tutorial.DomainName;
                        mobj.PostedDate = tutorial.PostedDate;
                        mobj.UpdatedDate = DateTime.Now; //tutorial.UpdatedDate;
                        mobj.ShortTitle = tutorial.ShortTitle;
                        mobj.Title = tutorial.Title;
                        mobj.Version = tutorial.Version;
                        mobj.Tags = tutorial.Tags;
                        mobj.Authors = mId;
                        mobj.ArticleUrl = tutorial.ArticleUrl;
                        mobj.SourceCodeUrl = tutorial.SourceCodeUrl;
                        mobj.TutorialImage = TUrl;
                        mobj.MetaKeywords = tutorial.MetaKeywords;
                        if (mobj.PostedBy == null || mobj.PostedBy == "")
                            mobj.PostedBy = this.User.Identity.Name;

                        mobj.Url = "https://www.dotnettricks.com/learn/" + CatName.ToLower().Replace(" ", string.Empty).Replace(".", string.Empty);

                        UOF.SaveChanges();
                        if (mobj.TutorialImage != null)
                        {
                            if (TUrl != "")
                            {
                                if (fT != "1")
                                {

                                    string Lfullpath = Request.MapPath(Toldpic);
                                    if (System.IO.File.Exists(Lfullpath))
                                    {
                                        System.IO.File.Delete(Lfullpath);
                                    }
                                    tutorial.TImage.SaveAs(Tpath);
                                }

                            }
                        }

                        ViewBag.Message = "Tutorial has been updated successfully";
                        ModelState.Clear();
                        return RedirectToAction("TutorialList");
                    }
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            BindPost(this.User.Identity.Name);

            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditTutorial = "EditTutorial";
            return View("TutorialList");
        }

        [Authorize]
        public JsonResult GetTutorial(string mID)
        {
            try
            {
                if (mID != "0")
                {
                    var tutorial = UOF.ITutorial.GetAll().Where(q => q.ID == mID).Select(m => new { Description = m.Description, m.MetaKeywords, m.ShortDescription, m.ShortTitle, m.Tags, m.Title, m.Version, m.Url }).ToList();
                    return Json(tutorial, JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        public ActionResult ViewSubscription(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.ViewSubscription = "ViewSubscription";

            var data = UOF.ISubscription.GetAll().OrderByDescending(m => m.SubscribeDate).ToList();
            List<Subscription> subscriptionList = new List<Subscription>();
            foreach (var item in data)
            {
                Subscription obj = new Subscription();
                obj.EmailID = item.EmailID;
                obj.SubscribeDate = item.SubscribeDate;
                obj.SubscribeUrl = item.SubscribeUrl;
                obj.IsVerified = item.IsVerified;
                obj.VerificationDate = item.VerificationDate;
                obj.MailSentCounter = item.MailSentCounter;

                subscriptionList.Add(obj);
            }


            PagingDTO<Subscription> model = new PagingDTO<Subscription>();
            model.TotalRows = subscriptionList.Count();
            model.PageSize = pageSize;
            model.Data = subscriptionList.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            return View(model);
        }

        public ActionResult BooksDownload(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            try
            {
                ViewBag.BooksDownload = "BooksDownload";

                //Basant_Rep .Join(mobjentity.Members, b => b.MemberId, m => m.MemberId, (b, m) => new { b, m }).OrderByDescending(x => x.b.DownloadDate).Select(x => new
                var data = UOF.IBookDownload.GetAll().Join(UOF.IMember.GetAll(), b => b.MemberId, m => m.MemberId, (b, m) => new { b, m }).OrderByDescending(x => x.b.DownloadDate).Select(x => new
                {
                    x.b.ID,
                    x.b.BookName,
                    x.b.MemberId,
                    x.b.DownloadDate,
                    x.m.Name,
                    x.m.Email,
                    x.m.MobileNo
                }).ToList();

                List<BookDownloadDTO> bookDownloadList = new List<BookDownloadDTO>();
                foreach (var item in data)
                {
                    BookDownloadDTO bookModel = new BookDownloadDTO();
                    bookModel.ID = item.ID;
                    bookModel.BookName = item.BookName;
                    bookModel.MemberId = item.MemberId;
                    bookModel.Email = item.Email;
                    bookModel.Mobile = item.MobileNo;
                    bookModel.Name = item.Name;
                    bookModel.DownloadDate = item.DownloadDate;

                    bookDownloadList.Add(bookModel);

                }


                PagingDTO<BookDownloadDTO> model = new PagingDTO<BookDownloadDTO>();
                model.TotalRows = bookDownloadList.Count();
                model.PageSize = pageSize;
                model.Data = bookDownloadList.Skip((page - 1) * pageSize).Take(pageSize).Distinct().ToList();

                return View(model);
            }
            catch (Exception)
            { }
            return View();
        }

        [Authorize]
        public ActionResult ViewCategory()
        {

            ViewBag.ViewCategory = "ViewCategory";
            BindCategory();
            return View();

        }



        [Authorize]
        public ActionResult ViewBlogger()
        {

            ViewBag.ViewBlogger = "ViewBlogger";
            BindBlogger();
            return View();

        }

        [Authorize]
        public JsonResult GetBlogger(string mID)
        {
            try
            {
                if (mID != "0")
                {
                    var blogger = UOF.IUser.GetMany(mID);
                    return Json(blogger, JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        private void BindBlogger()
        {
            var tblbloggerlist = UOF.IUser.GetAll().OrderBy(x => x.Name).ToList();
            List<Users> bloggerlist = new List<Users>();

            Users mobj = new Users();
            mobj.UserName = "0";
            mobj.Name = "Select";
            bloggerlist.Add(mobj);
            foreach (var item in tblbloggerlist)
            {
                mobj = new Users();
                mobj.UserName = item.UserName;
                mobj.Name = item.Name;

                bloggerlist.Add(mobj);
            }
            ViewBag.Bloggers = bloggerlist;
        }


        public ActionResult SendVerificationMail(int id)
        {
            try
            {
                MemberDTO model = UOF.IMember.GetMember(id);
                if (model.MemberId > 0)
                {
                    
                    bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(model);
                    if (mailStatus == true)
                    {
                        int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(model.MemberId);
                    }
                }
            }
            catch (Exception ex) { }
            return RedirectToAction("ViewUnVerifiedMembers");
        }

        public ActionResult SendSubscriptionVerificationMail(string id)
        {
            try
            {
                string _subscribeUrl = UOF.ICommonLogic.VerifyEmailSubscription(id);
                if (!string.IsNullOrEmpty(_subscribeUrl))
                {
                    
                    bool status = MailClient.SendMail_Subscription(id, _subscribeUrl);
                    if (status == true)
                    {
                        int? totalSentMailCount = UOF.ICommonLogic.IncreaseSubscribeMailSentCounter(id);
                    }
                }
            }
            catch (Exception ex) { }
            return RedirectToAction("ViewSubscription");
        }

        // By Amit
        public ActionResult TutorialList(int page = 1, int CategoryId = 0, string textsrch = "", int AuthorId = 0,bool IsSourceCode= false,string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.TutorialList = "TutorialList";
            PagingTutorialDTO<TutorialDTO> model = UOF.ITutorial.GetAllTutorialList(page, pageSize, textsrch, CategoryId, AuthorId, IsSourceCode,startDate,  endDate);
            if (model != null)
            {
                ViewBag.page = model.Page;
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategories().ToList();
                model.AuthorList = UOF.ICourse.GetMentorMasterList();
                model.CategoryLst = _categoryList;
                return View(model);
            }
            model = new PagingTutorialDTO<TutorialDTO>();
            List<CategoryDTO> _categoryList1 = UOF.ICategory.GetCategories().ToList();
            model.AuthorList = UOF.ICourse.GetMentorMasterList();
            model.CategoryLst = _categoryList1;
            return View(model);
        }

        [HttpGet]
        public ActionResult AddBlogger()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult AddBlogger(Users muser)
        {
            try
            {

                ViewBag.AddBlogger = "AddBlogger";

                Users tbl = new Users();
                tbl.Name = muser.Name;
                tbl.UserName = muser.NewUserName;
                tbl.Password = muser.Password;
                tbl.IsAdmin = false;
                tbl.IsActive = false;
                UOF.IUser.Add(tbl);
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "blogger has been added successfully";

            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }

            ViewBag.AddBlogger = "AddBlogger";
            return View();

        }

        public ActionResult BloggerList()
        {
            IEnumerable<Users> model = UOF.ITutorial.GetBloggerListDetails();
            return View(model);
        }

        [Authorize]
        public ActionResult UserDelete(string id)
        {
            try
            {
                if (id != null && id != "")
                {
                    Users data = UOF.IUser.GetSingle(id);
                    if (data != null)
                    {
                        data.IsActive = false;
                        UOF.SaveChanges();

                        ViewBag.Message = "blogger has been deleted successfully";
                        return RedirectToAction("BloggerList");
                    }
                    else { ViewBag.Message = "There some internal error"; }
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "There some internal error";
            }

            return View();

        }


        [HttpGet]
        public ActionResult EditBlogger(string id)
        {
            Users model = UOF.ITutorial.GetBloggerDetailById(id);
            ViewBag.EditBlogger = "EditBlogger";

            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditBlogger(Users model)
        {
            try
            {
                Users userobj = UOF.IUser.GetSingle(model.UserName);
                userobj.Name = model.Name;
                userobj.IsAdmin = model.IsAdmin;
                userobj.IsActive = model.IsActive;
                userobj.Password = model.Password;
                UOF.SaveChanges();
                ViewBag.Message = "User has been updated successfully";
                ModelState.Clear();
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BloggerList");

        }

        //public ActionResult CategoryList(int page = 1, string sort = "ID", string sortDir = "asc")
        //{
        //    ViewBag.CategoryList = "CategoryList";
        //    PagingDTO<CategoryDTO> model = UOF.ITutorial.GetAllCategoryList(page, pageSize);
        //    if (model != null)
        //    {
        //        ViewBag.page = model.Page;
        //    }
        //    return View(model);
        //}
        [HttpGet]
        public ActionResult AddCategory()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult AddCategory(CategoryDTO model)
        {
            try
            {
                ViewBag.AddCategory = "AddCategory";
                Category tbl = new Category();
                tbl.CategoryName = model.CategoryName;
                tbl.Url = model.Url;
                tbl.Title = model.Title;
                tbl.MetaKeywords = model.MetaKeywords;
                tbl.MetaDescription = model.MetaDescription;
                tbl.CreatedDate = DateTime.Now;
                tbl.IsActive = model.IsActive;                
                UOF.ICategory.Add(tbl);
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "Category has been added successfully";

            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }

            return View();

        }
        [Authorize]
        public ActionResult EditCategory(int id)
        {
            try
            {
                ViewBag.id = id;
                BindPost(this.CurrentUser.Name);
                ViewBag.EditCategory = "EditCategory";

                if (id > 0)
                {
                    var category = UOF.ICategory.GetAll().Where(m => m.CategoryID == id).Select(m => new { m.CategoryID, m.CategoryName, m.Title, m.Url, m.MetaKeywords, m.MetaDescription, m.IsActive }).ToList();

                    foreach (var item in category)
                    {
                        CategoryDTO model = new CategoryDTO();
                        model.CategoryID = item.CategoryID;
                        model.CategoryName = item.CategoryName;
                        model.Title = item.Title;
                        model.Url = item.Url;
                        model.MetaKeywords = item.MetaKeywords;
                        model.MetaDescription = item.MetaDescription;                       
                        model.IsActive = item.IsActive;
                        return View(model);
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult EditCategory(CategoryDTO mcat)
        {
            try
            {
                ViewBag.EditCategory = "EditCategory";
                var q = (from tbl in UOF.ICategory.GetAll()
                         where tbl.CategoryID == mcat.CategoryID
                         select tbl).FirstOrDefault();
                q.CategoryName = mcat.CategoryName;
                q.Title = mcat.Title;
                q.Url = mcat.Url;
                q.MetaKeywords = mcat.MetaKeywords;
                q.MetaDescription = mcat.MetaDescription;                
                q.IsActive = mcat.IsActive;
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "Category has been updated successfully !!";
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }
            return View();

        }

        public ActionResult _PartialCounter()
        {
            try
            {
                DashboardCounterDTO model = UOF.ITutorial.GetDashboardCounters();
                return PartialView("_PartialCounter", model);
            }
            catch
            {
                return null;
            }
        }
    }
}

