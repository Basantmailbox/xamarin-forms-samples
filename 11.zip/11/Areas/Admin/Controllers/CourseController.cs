﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;
using System.Net;
using DNTWebUI.Models;
using System.Text;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using DNTData;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class RandomGenerator
    {
        // Generate a random number between two numbers  
        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        // Generate a random string with a given size  
        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString().ToUpper();
        }

        // Generate a random password  
        public string RandomPassword()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(RandomString(3, true));
            builder.Append(RandomNumber(100, 999));
            builder.Append(RandomString(1, false));
            return builder.ToString();
        }
    }


    [RouteArea("Admin")]
    public class CourseController : BaseController
    {
        public string ImgCloudPath = "";
        static CloudBlobClient blobClient;
        static CloudBlobContainer blobContainer;
        CloudStorageAccount storageAccount;
        //private readonly DataContext mobjentity = new DataContext();
        int pageSize;

        public CourseController()
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        // [CustomAuthorizeAttribute(Roles = "Admin")]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CourseList(int page = 1, string sort = "CourseId", int CourseId = 0, int courseCategoryId = 0)
        {
            PagingMemberSubscriptionDTO<CourseDetail> model = new PagingMemberSubscriptionDTO<CourseDetail>();
            ViewBag.CourseList = "Course List";

            model = UOF.ICommonLogic.GetAllCourseListByCourseCategoryId(page, pageSize, courseCategoryId, CourseId);
            model.CourseCategoriesList = UOF.ICommonLogic.GetAllCourseCategories();
            model.CourseCategoryId = courseCategoryId;
            ViewBag.courselist = UOF.ICourse.GetallCourseList();
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.CourseCategoryIdSelectedValue = courseCategoryId;
            return View(model);
        }

        // [CustomAuthorizeAttribute(Roles = "Admin")]
        [HttpGet]
        public ActionResult CreateCourse()
        {
            ViewBag.Create = "Create Course";
            CourseDTO model = new CourseDTO();

            List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
            model.MentorMasterList = MentorMasterList;

            // List<Category> categoryDDL;
            model.CategoryDDL = UOF.ICategory.GetAll().ToList();

            List<SkillMaster> skList = UOF.IAdminMaster.GetAllSkillTypes();
            ///skills             
            model.SkillsList = skList;
            ///COURSE
            List<Course> coursesList = UOF.ICourse.GetallCourseList();
            model.curList = coursesList;

            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                    .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            SetCourseInilialDropDown(model);
            return View(model);
        }

        private void SetCourseInilialDropDown(CourseDTO model)
        {
            IEnumerable<EnumDifficultyLevel> difficultyLevelDDL = Enum.GetValues(typeof(EnumDifficultyLevel))
                                                   .Cast<EnumDifficultyLevel>();
            ViewBag.DifficultyLevelDDL = from action in difficultyLevelDDL
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };


            IEnumerable<EnumDifficultyType> difficultyTypeDDL = Enum.GetValues(typeof(EnumDifficultyType))
                                                   .Cast<EnumDifficultyType>();
            ViewBag.DifficultyTypeDDL = from action in difficultyTypeDDL
                                        select new SelectListItem
                                        {
                                            Text = action.ToString(),
                                            Value = ((int)action).ToString()
                                        };

            ViewBag.CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult CreateCourse(CourseDTO model, string[] Mentors, string[] SkillName, string[] CoursesL, string[] CategoryList)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["CourseImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();
                model.Mentors = Mentors != null ? string.Join(",", Mentors) : null;
                model.SkillName = SkillName != null ? string.Join(",", SkillName) : null;
                model.CoursesList = CoursesL != null ? string.Join(",", CoursesL) : null;
                model.CategoryList = CategoryList != null ? string.Join(",", CategoryList) : null;

                int CourseId = UOF.IAdminMaster.CreateCourse(model);
                //mapping with category
                if (CourseId != 0 && CategoryList.Length > 0)
                {
                    UOF.ICourse.MappingCourseWithCategory(CourseId, CategoryList);

                    string LUrl = ""; string SUrl = ""; string MUrl = "";
                    string Lfile = ""; string Sfile = ""; string Mfile = "";
                    var Lext = ""; var Sext = ""; var Mext = "";
                    // string Lpath = ""; string Spath = ""; string Mpath = "";
                    string FlagL = ""; string FlagS = ""; string FlagM = "";
                    if (model.Large != null && model.Large.ContentLength > 0)
                    {
                        FlagL = "L";
                        var fileName = Path.GetFileName(model.Large.FileName); //file name  
                        Lext = Path.GetExtension(model.Large.FileName); //getting the extension(ex-.jpg)  
                    }
                    if (model.Small != null && model.Small.ContentLength > 0)
                    {
                        FlagS = "S";
                        var fileName = Path.GetFileName(model.Small.FileName); //file name  
                        Sext = Path.GetExtension(model.Small.FileName); //getting the extension(ex-.jpg)  
                    }
                    if (model.Mobile != null && model.Mobile.ContentLength > 0)
                    {
                        FlagM = "M";
                        var fileName = Path.GetFileName(model.Mobile.FileName); //file name  
                        Mext = Path.GetExtension(model.Mobile.FileName); //getting the extension(ex-.jpg)  
                        string name = Path.GetFileNameWithoutExtension(fileName);
                    }

                    string _courseImageFolderLocation;
                    _courseImageFolderLocation = ConfigurationManager.AppSettings["CourseImageFolder"].ToString();

                    if (FlagL == "L")
                    {
                        Lfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "").ToLower() + "-large" + Lext; //
                        Lfile = Lfile.Replace(":", "");
                        // Lpath = _courseImageFolderLocation+ Lfile;
                        LUrl = "/" + _courseImageFolderLocation + Lfile;
                    }
                    if (FlagS == "S")
                    {
                        Sfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "").ToLower() + "-small" + Sext; //
                                                                                                            // Spath = _courseImageFolderLocation+ Sfile;
                        SUrl = "/" + _courseImageFolderLocation + Sfile;
                    }
                    if (FlagM == "M")
                    {
                        Mfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "").ToLower() + "-mobile" + Mext; //
                        //Mpath = _courseImageFolderLocation+Mfile;
                        MUrl = "/" + _courseImageFolderLocation + Mfile;
                    }

                    //string directoryPath = Server.MapPath(string.Format("~/{0}/", _courseImageFolderLocation));
                    //if (!Directory.Exists(directoryPath))
                    //{
                    //    Directory.CreateDirectory(directoryPath);
                    //}

                    model.LargeBanner = LUrl;
                    model.SmallBanner = SUrl;
                    model.MobileBanner = MUrl;
                    model.CourseId = CourseId;

                    bool stat = UOF.IAdminMaster.UpdateCourseImages(model);
                    if (stat != false)
                    {
                        if (LUrl != "")
                        {
                            CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(Lfile);
                            using (var fileStream = model.Large.InputStream)
                            {
                                blockBlob.UploadFromStream(fileStream);
                            }
                            //model.Large.SaveAs(Lpath);
                        }
                        if (SUrl != "")
                        {
                            CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(Sfile);
                            using (var fileStream = model.Small.InputStream)
                            {
                                blockBlob.UploadFromStream(fileStream);
                            }
                            //model.Small.SaveAs(Spath);
                        }
                        if (MUrl != "")
                        {
                            CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(Mfile);
                            using (var fileStream = model.Mobile.InputStream)
                            {
                                blockBlob.UploadFromStream(fileStream);
                            }
                            // model.Mobile.SaveAs(Mpath);
                        }
                        TempData["Message"] = "Details has been saved successfully";
                        ModelState.Clear();

                    }
                    ViewBag.Message = "Course has been created successfully";
                    ModelState.Clear();
                }
                else
                {
                    SetCourseInilialDropDown(model);
                    model.CategoryDDL = UOF.ICategory.GetAll().ToList();
                    ViewBag.Message = "Unable to create Course this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View("CreateCourse");
            }

            return RedirectToAction("CourseList");
        }


        [HttpGet]
        public ActionResult EditCourse(int id = 0)
        {
            CourseDTO model = UOF.ICourse.GetCourseDetails(id);
            ViewData["CreatedDate"] = model.CreatedDate;
            ViewData["UpdatedDate"] = model.UpdatedDate;
            List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
            model.MentorMasterList = MentorMasterList;
            model.MentorList = ViewBag.SelectedMentors = UOF.ICourse.GetCourseMentors(id);
            List<SelectListItem> Select_List = new List<SelectListItem>();
            foreach (var m in MentorMasterList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = m.MentorId.ToString(),
                    Text = m.Name,
                    Selected = model.MentorList.Where(me => me.MentorId == m.MentorId).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }

            //categories
            var SelCategoryList = UOF.ICourse.GetCourseCategories(model.CategoryList);
            List<SelectListItem> CategorySel_List = new List<SelectListItem>();
            var CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course);
            foreach (var m in CategoryList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = m.CategoryID.ToString(),
                    Text = m.CategoryName,
                    Selected = SelCategoryList.Where(me => me.CategoryID == m.CategoryID).Count() > 0 ? true : false
                };

                CategorySel_List.Add(obj);
            }
            model.SelectedCategories = CategorySel_List;

            ///skill
            List<SkillMaster> skList = UOF.IAdminMaster.GetAllSkillTypes();
            model.SkillsList = skList;
            model.SelectedSkills = ViewBag.SelectedMentors = UOF.ICourse.GetCourseSkill(id);
            List<SelectListItem> Select_skList = new List<SelectListItem>();
            foreach (var m in skList)
            {
                SelectListItem obj1 = new SelectListItem()
                {
                    Value = m.SkillId.ToString(),
                    Text = m.Name,
                    Selected = model.SelectedSkills.Where(e => e.SkillId == m.SkillId).Count() > 0 ? true : false
                };

                Select_skList.Add(obj1);
            }

            ///course
            List<Course> coursesList = UOF.ICourse.GetallCourseList();
            model.curList = coursesList;
            model.SelectcurList = ViewBag.SelectedCouses = UOF.ICourse.GetCourseSelected(id);
            List<SelectListItem> Select_CList = new List<SelectListItem>();
            foreach (var m in coursesList)
            {
                SelectListItem obj2 = new SelectListItem()
                {
                    Value = m.CourseId.ToString(),
                    Text = m.Name,
                    Selected = model.SelectcurList.Where(me => me.CourseId == m.CourseId).Count() > 0 ? true : false
                };

                Select_CList.Add(obj2);
            }
            model.MentorMaster = Select_List;
            model.SkillList = Select_skList;
            model.CoursesL = Select_CList;
            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                    .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };

            SetCourseInilialDropDown(model);
            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditCourse(CourseDTO model, FormCollection form, string[] Categories)
        {
            blobClient = storageAccount.CreateCloudBlobClient();
            blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["CourseImageFolder"].ToString());
            blobContainer.CreateIfNotExistsAsync();

            String mId = form["MemtorName"];
            String SkillN = form["SkillNamelist"];
            String CurL = form["CoursesLst"];
            string categoryList = form["Categories"];

            int id = 0;
            try
            {
                string LUrl = ""; string SUrl = ""; string MUrl = "";
                string Lfile = ""; string Sfile = ""; string Mfile = "";
                var Lext = ""; var Sext = ""; var Mext = "";
                //string Lpath = ""; string Spath = ""; string Mpath = "";
                string FlagL = ""; string FlagS = ""; string FlagM = "";
                string Loldpic = ""; string Soldpic = ""; string Moldpic = "";
                string fL = ""; string fS = ""; string fM = "";
                CourseDTO dt = UOF.ICourse.GetCourseDetails(model.CourseId);
                id = model.CourseId;
                if (dt != null)
                {
                    Loldpic = dt.LargeBanner.Replace(ImgCloudPath, "");
                    Soldpic = dt.SmallBanner.Replace(ImgCloudPath, "");
                    Moldpic = dt.MobileBanner.Replace(ImgCloudPath, "");
                }

                if (model.Large != null && model.Large.ContentLength > 0)
                {
                    FlagL = "L";
                    var fileName = Path.GetFileName(model.Large.FileName); //file name  
                    Lext = Path.GetExtension(model.Large.FileName); //getting the extension(ex-.jpg)  
                }
                if (model.Small != null && model.Small.ContentLength > 0)
                {
                    FlagS = "S";
                    var fileName = Path.GetFileName(model.Small.FileName); //file name  
                    Sext = Path.GetExtension(model.Small.FileName); //getting the extension(ex-.jpg)  
                }
                if (model.Mobile != null && model.Mobile.ContentLength > 0)
                {
                    FlagM = "M";
                    var fileName = Path.GetFileName(model.Mobile.FileName); //file name  
                    Mext = Path.GetExtension(model.Mobile.FileName); //getting the extension(ex-.jpg)  
                    string name = Path.GetFileNameWithoutExtension(fileName);
                }

                string _courseImageFolderLocation;
                _courseImageFolderLocation = ConfigurationManager.AppSettings["CourseImageFolder"].ToString();

                if (FlagL == "L")
                {
                    //model.Name = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "");
                    Lfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "").ToLower() + "-large" + Lext; //
                    // Lpath = Path.Combine(Server.MapPath(_courseImageFolderLocation), Lfile);
                    LUrl = "/" + _courseImageFolderLocation + Lfile;
                }
                else
                {
                    LUrl = Loldpic;
                    fL = "1";

                }
                if (FlagS == "S")
                {
                    Sfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "").ToLower() + "-small" + Sext; //
                    // Spath = Path.Combine(Server.MapPath(_courseImageFolderLocation), Sfile);
                    SUrl = "/" + _courseImageFolderLocation + Sfile;
                }
                else
                {
                    SUrl = Soldpic;
                    fS = "1";
                }
                if (FlagM == "M")
                {
                    Mfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "").ToLower() + "-mobile" + Mext; //
                    // Mpath = Path.Combine(Server.MapPath(_courseImageFolderLocation), Mfile);
                    MUrl = "/" + _courseImageFolderLocation + Mfile;
                }
                else
                {
                    MUrl = Moldpic;
                    fM = "1";
                }
                //string directoryPath = Server.MapPath(string.Format("~/{0}/", _courseImageFolderLocation));
                //if (!Directory.Exists(directoryPath))
                //{
                //    Directory.CreateDirectory(directoryPath);
                //}

                model.LargeBanner = LUrl;
                model.SmallBanner = SUrl;
                model.MobileBanner = MUrl;
                //model.Mentors = string.Join(",", Mentors);
                model.Mentors = mId;
                model.SkillName = SkillN;
                model.CoursesList = CurL;
                model.CategoryList = categoryList;

                bool stat = UOF.IAdminMaster.UpdateCourse(model);
                UOF.ICourse.UpdateMappingCourseWithCategory(model.CourseId, Categories);

                if (stat != false)
                {
                    if (LUrl != "")
                    {
                        if (fL != "1")
                        {
                            Uri uri = new Uri(ImgCloudPath + Loldpic);
                            string filename = Path.GetFileName(uri.LocalPath);

                            var blob = blobContainer.GetBlockBlobReference(filename);
                            blob.DeleteIfExists();

                            CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(Lfile);
                            using (var fileStream = model.Large.InputStream)
                            {
                                blockBlob.UploadFromStream(fileStream);
                            }
                            //string Lfullpath = Request.MapPath(Loldpic);
                            //if (System.IO.File.Exists(Lfullpath))
                            //{
                            //    System.IO.File.Delete(Lfullpath);
                            //}
                            //model.Large.SaveAs(Lpath);
                        }

                    }
                    if (SUrl != "")
                    {
                        if (fS != "1")
                        {

                            Uri uri = new Uri(ImgCloudPath + Soldpic);
                            string filename = Path.GetFileName(uri.LocalPath);

                            var blob = blobContainer.GetBlockBlobReference(filename);
                            blob.DeleteIfExists();

                            CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(Sfile);
                            using (var fileStream = model.Small.InputStream)
                            {
                                blockBlob.UploadFromStream(fileStream);
                            }
                        }

                    }
                    if (MUrl != "")
                    {
                        if (fM != "1")
                        {
                            Uri uri = new Uri(ImgCloudPath + Moldpic);
                            string filename = Path.GetFileName(uri.LocalPath);

                            var blob = blobContainer.GetBlockBlobReference(filename);
                            blob.DeleteIfExists();

                            CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(Mfile);
                            using (var fileStream = model.Mobile.InputStream)
                            {
                                blockBlob.UploadFromStream(fileStream);
                            }
                        }
                    }
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();

                }
                ViewBag.Message = "Course has been Updated successfully";
                ModelState.Clear();

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;

            }
            return RedirectToAction("CourseList");
        }

        public ActionResult SubscribedMemberDetails(int page = 1, string textsrch = "", int CourseId = 0, string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
            }
            else
            {
                startDate = DateTime.Today.AddDays(-7);
                endDate = DateTime.Today.AddDays(1);
            }

            ViewBag.SubscribedMemberDetails = "SubscribedMemberDetails";
            PagingDTO<CourseSubscriptionMemberDTO> model = UOF.IAdminMaster.GetCourseSubscribedMembers(page, pageSize, textsrch, CourseId, true, startDate, endDate);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.Date = Date;
            ViewBag.Courses = UOF.ICommonLogic.AllGetCourseList();
            Session["Message"] = null;
            Session["linkpage"] = "SubscribedMemberDetails";
            return View(model);
        }

        public ActionResult AllMemberDetails(int page = 1, string textsrch = "", int CourseId = 0, string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
            }
            else
            {
                startDate = DateTime.Today.AddDays(-7);
                endDate = DateTime.Today.AddDays(1);
            }

            ViewBag.SubscribedMemberDetails = "SubscribedMemberDetails";
            PagingDTO<CourseSubscriptionMemberDTO> model = UOF.IAdminMaster.GetCourseSubscribedMembers(page, pageSize, textsrch, CourseId, false, startDate, endDate);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.Date = Date;
            ViewBag.Courses = UOF.ICommonLogic.AllGetCourseList();
            Session["Message"] = null;
            Session["linkpage"] = "SubscribedMemberDetails";
            return View(model);
        }
        public ActionResult DownloadMemberToExcel(int CourseId = 0, bool IsSubscribed = false, string Date = "")
        {
            try
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
                }
                else
                {
                    startDate = DateTime.Today.AddDays(-7);
                    endDate = DateTime.Today.AddDays(1);
                }

                ViewBag.SubscribedMemberDetails = "SubscribedMemberDetails";
                List<CourseSubscriptionMemberDTO> model = new List<CourseSubscriptionMemberDTO>();
                model = UOF.IAdminMaster.GetAllSubscribedMemberExcel(CourseId, IsSubscribed, startDate, endDate);
                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string RepoetName = "MemberReport" + time + ".xlsx";
                string fileName = RepoetName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingAllMemberReport(stream, model, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        public ActionResult MemberDetailsBySearch(CourseSubscriptionMemberDTO model)
        {
            try
            {
                CourseSubscriptionMemberDTO memModel = new CourseSubscriptionMemberDTO();
                List<CourseDTO> courseList = UOF.ICommonLogic.GetAllCourseList();
                memModel.CourseList = courseList;

                //Bind Training Mode
                List<TrainingMode> trainingModeList = UOF.IAdminMaster.GetTrainingModeList();
                memModel.TrainingModeList = trainingModeList;

                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                     .Cast<EnumCourseType>();
                List<SelectListItem> itemctype = new List<SelectListItem>();

                var CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
                foreach (var item in CourseTypeList)
                {
                    itemctype.Add(new SelectListItem
                    {
                        Text = item.Text,
                        Value = item.Value.ToString()
                    });
                }
                itemctype.Insert(0, new SelectListItem { Text = "- Select Course Type -", Value = "-1" });
                ViewBag.CourseTypeList = itemctype;

                DateTime date = DateTime.Now;

                ViewData["CurrentDate"] = date.AddMonths(1);
                ViewBag.Message = Session["Message"];
                return View(memModel);
            }
            catch { return null; }

        }

        public ActionResult AllSubscribedMember(int page = 1, string sort = "ID", string sortDir = "asc", string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.AllSubscribedMember = "AllSubscribedMember";
            PagingDTO<CourseSubscriptionMemberDTO> model = new PagingDTO<CourseSubscriptionMemberDTO>();

            model = UOF.IAdminMaster.GetAllSubscribedMember(page, pageSize, textsrch, startDate, endDate);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return PartialView("_AllSubscribedMember", model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddSubscribedDetails(CourseSubscriptionMemberDTO model)
        {

            try
            {
                bool check = UOF.IAdminMaster.CheckMemberSubscription(model);
                if (check == true)
                {
                    Session["Message"] = "This Member Already Subscribed For This Course.";
                }
                else
                {
                    int CourseSubscriptionId = UOF.IAdminMaster.AddMemberSubscribedDetails(model);
                    if (CourseSubscriptionId > 0)
                    {
                        ViewBag.Message = "Details has been saved successfully";
                        ModelState.Clear();
                        return RedirectToAction("SubscribedMemberDetails");
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                //ts.Dispose();
            }
            return RedirectToAction("MemberDetailsBySearch");
        }

        [HttpGet]
        public ActionResult ViewSubscribed(Int64 id)
        {
            if (id != 0)
            {
                MemberDTO model = UOF.IAdminMaster.GetMemberProfile(id);
                return RedirectToAction("MemberDetailsBySearch", model);
            }
            return null;
        }


        public ActionResult AddMemberBatchList(int id, int page = 1, string sortDir = "asc", string textsrch = "")
        {
            ViewBag.SubscribedMemberDetails = "SubscribedMemberDetails";
            PagingDTO<MemberDTO> model = UOF.IAdminMaster.AddMemberBatchList(id, page, pageSize, textsrch);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult ViewAllCourseSubscribedDetails(Int64 mid = 0, string email = "", int page = 1)
        {
            if (mid != 0 || email != "")
            {
                ViewBag.ViewAllCourseSubscribedDetails = "ViewAllCourseSubscribedDetails";
                PagingDTO<CourseSubscriptionDTO> model = UOF.IAdminMaster.GetCourseSubscriptionDetailsList(mid, email, page, pageSize);

                if (model != null)
                {
                    ViewBag.page = model.Page;
                    ViewBag.mid = mid;
                }

                if (!string.IsNullOrEmpty(email))
                {
                    ViewBag.mid = UOF.IMember.Check_Member_Email_Exists(email);
                }
                if (email == "")
                    ViewBag.Link = Session["linkpage"];
                return View(model);
            }
            return null;
        }

        //  EditBatchMaster
        public ActionResult CourseMaster()
        {

            return View();
        }

        public ActionResult DeleteMemberCourseSubscribedDetails(int CourseSubscriptionId = 0, Int64 MemberId = 0, int page = 1)
        {
            bool status = UOF.IAdminMaster.DeleteMemberCourseSubscribedDetails(CourseSubscriptionId);
            if (status != true)
            {
                return RedirectToAction("SubscribedMemberDetails");
            }
            return RedirectToAction("ViewAllCourseSubscribedDetails", new { mid = MemberId, page = page });
        }
        public ActionResult DeleteSubscribedMembers(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                bool status = UOF.IAdminMaster.DeleteCourseSubscribedDetailsByMember(ids);
                if (status == true)
                {
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CoursePricesList(int page = 1, int CourseType = 0, int? CourseId = null)
        {
            ViewBag.CoursePricesList = "CoursePricesList";
            PagingDTO<CoursePrices_v1> model = new PagingDTO<CoursePrices_v1>();
            ViewBag.CourseList = UOF.ICourse.GetallCourseList();
            model = UOF.IAdminMaster.GetViewCoursePricesList(page, pageSize, CourseType, CourseId);
            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                      .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult CreateCoursePrices()
        {
            TempData["Message"] = "";
            CoursePrices_v1 CourseModel = new CoursePrices_v1();
            ViewBag.CreateCourse = "CreateCourse";
            ViewBag.CourseList = UOF.ICourse.GetCoursesExcludingSelfPaced(); ;

            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                      .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };

            IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                      .Cast<EnumCurrency>();
            ViewBag.Currencylist = from action in Currencylist
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.ToString()
                                   };
            return View(CourseModel);
        }

        [HttpPost]
        public ActionResult CreateCoursePrices(CoursePrices_v1 model)
        {
            try
            {
                bool status = UOF.IAdminMaster.CreateCoursePrices(model);
                if (status == true)
                {
                    ViewBag.Message = "Course Price has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("CoursePricesList");
        }

        [HttpGet]
        public ActionResult EditCoursePrices(int CoursePriceId = 0)
        {
            CoursePrices_v1 CurModel = new CoursePrices_v1();
            ViewBag.CoursePricesList = "CoursePricesList";
            CurModel = UOF.IAdminMaster.GetPriceById(CoursePriceId);
            ViewBag.CourseList = UOF.ICourse.GetallCourseList();
            CurModel.CourseId = CurModel.CourseId;

            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                          .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                      .Cast<EnumCurrency>();
            ViewBag.Currencylist = from action in Currencylist
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.ToString()
                                   };
            return View("CreateCoursePrices", CurModel);
        }


        [HttpPost, ValidateInput(false)]
        public ActionResult EditCoursePrices(CoursePrices_v1 model)
        {
            try
            {
                bool status = UOF.IAdminMaster.UpdatePriceList(model);

                if (status == true)
                {
                    ViewBag.message = "course has been updated successfully";
                    ModelState.Clear();
                    return RedirectToAction("CoursePricesList");
                }
                else
                {
                    ViewBag.message = "unable to update course this time. please try again later.";
                    return View("CreateCoursePrices", model);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                return View("CreateCoursePrices", model);
            }
        }
        ///// coupons///////////
        public ActionResult PassesList(int page = 1, string textsrch = "")
        {
            PagingDTO<DNTPass> model = new PagingDTO<DNTPass>();
            model = UOF.IAdminMaster.GetPassesList(page, pageSize, textsrch);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult CreatePasses()
        {
            ViewData["CurrentDate"] = DateTime.Now.AddDays(30);
            return View();
        }

        [HttpPost]
        public ActionResult CreatePasses(int Count, string ExpiryDate)
        {
            try
            {
                List<DNTPass> passses = new List<DNTPass>();
                DateTime expiryDate = Convert.ToDateTime(ExpiryDate);
                int j = 99;
                for (int i = 1; i <= Count; i++)
                {
                    DNTPass pass = new DNTPass();
                    pass.PassId = Utility.GenerateID().ToUpper();
                    pass.IsActive = true;
                    pass.ExpiryDate = expiryDate;

                    passses.Add(pass);
                }
                UOF.IAdminMaster.CreatePasses(passses);
            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("PassesList");
        }

        public ActionResult DeletePass(string Id)
        {
            UOF.IAdminMaster.DeletePass(Id);
            return RedirectToAction("PassesList");
        }

        public ActionResult CouponsList(int page = 1, int? type = null, string textsrch = "", int CourseId = 0)
        {
            ViewBag.CouponsList = "CouponsList";
            PagingDTO<Discount> model = new PagingDTO<Discount>();
            model = UOF.IAdminMaster.GetViewCouponsList(page, pageSize, type, textsrch, CourseId);
            ViewBag.Courses = UOF.ICommonLogic.AllGetCourseList();
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult CreateCoupons()
        {
            TempData["Message"] = "";
            ViewBag.CreateCourse = "CreateCoupons";
            List<DiscountType> dtypeList = UOF.IAdminMaster.GetDiscountTypeList();
            ViewBag.DiscountTypeList = dtypeList;
            ViewData["CurrentDate"] = DateTime.UtcNow;
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.courseList = courseList;
            return View();
        }

        [HttpPost]
        public ActionResult CreateCoupons(Discount model)
        {
            try
            {
                RandomGenerator generator = new RandomGenerator();

                // string str = generator.RandomString(6, false);
                model.CouponCode = generator.RandomPassword();

                bool status = UOF.IAdminMaster.CreateCoupon(model);
                if (status == true)
                {
                    ViewBag.Message = "Coupon has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("CouponsList");
        }
        public ActionResult EditCoupons(int id)
        {
            TempData["Message"] = "";
            ViewBag.CreateCourse = "EditCoupons";
            Discount model = UOF.IAdminMaster.getDiscountCouponDetails(id);
            List<DiscountType> dtypeList = UOF.IAdminMaster.GetDiscountTypeList();
            ViewBag.DiscountTypeList = dtypeList;
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.courseList = courseList;
            return View(model);
        }

        [HttpPost]
        public ActionResult EditCoupons(Discount model)
        {
            try
            {
                bool status = UOF.IAdminMaster.UpdateCoupon(model);
                if (status == true)
                {
                    ViewBag.Message = "Coupon has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("CouponsList");
        }

        public ActionResult DeleteCoupons(int Id)
        {
            bool status = UOF.IAdminMaster.DeleteCoupons(Id);
            return RedirectToAction("CouponsList");
        }

        public ActionResult PriceListDelete(int CoursePriceId)
        {
            bool status = UOF.IAdminMaster.DeletePriceList(CoursePriceId);
            return RedirectToAction("CoursePricesList");
        }

        [HttpGet]
        public ActionResult EditMemberCourseSubscribedDetails(int id, Int64 mid)
        {
            try
            {
                CourseSubscriptionDTO memModel = new CourseSubscriptionDTO();
                memModel = UOF.IAdminMaster.GetMemberCourseSubscribedDetails(id);
                List<TrainingMode> TrainingModeList = UOF.IAdminMaster.GetTrainingModeList();
                memModel.TrainingModeList = TrainingModeList;
                memModel.TrainingModeId = memModel.ModeId;
                ViewData["ExpiryDate"] = memModel.ExpiryDate;
                ViewData["SubscribeDate"] = memModel.SubscribeDate;

                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                     .Cast<EnumCourseType>();
                List<SelectListItem> itemctype = new List<SelectListItem>();

                var CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
                foreach (var item in CourseTypeList)
                {
                    itemctype.Add(new SelectListItem
                    {
                        Text = item.Text,
                        Value = item.Value.ToString()
                    });
                }
                itemctype.Insert(0, new SelectListItem { Text = "- Select Course Type -", Value = "-1" });
                ViewBag.CourseTypeList = itemctype;

                ViewBag.mid = mid;
                return View(memModel);

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;

            }

            return RedirectToAction("SubscribedMemberDetails");

        }
        [HttpPost, ValidateInput(false)]
        public ActionResult EditMemberCourseSubscribedDetails(CourseSubscriptionDTO model)
        {
            try
            {
                bool status = UOF.ICourse.UpdateMemberCourseSubscribedDetails(model);

                if (status == true)
                {

                    ModelState.Clear();
                }
                else
                {
                    ViewBag.message = "unable to update  this time. please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;

            }
            return RedirectToAction("SubscribedMemberDetails");
        }

        [HttpGet]
        public ActionResult AddCourseDetails(int id = 0)
        {
            try
            {
                CourseDetail model = new CourseDetail();

                if (id > 0)
                {
                    ViewBag.AddCourseDetails = "AddCourseDetails";
                    CourseDTO data = UOF.ICourse.GetCourseDetails(id);
                    model.CourseType = data.CourseType;
                    model.CourseId = data.CourseId;
                    model.CourseName = data.Name;
                }
                return View(model);
            }
            catch (Exception ex)
            {
                CourseDetail model = new CourseDetail();
                return View(model);
            }
        }
        [HttpPost]
        public ActionResult AddCourseDetails(CourseDetail model)
        {
            if (model.CourseDetailId == 0)
            {
                bool result = UOF.ICourse.AddCourseDetails(model);
                if (result == true)
                {
                    TempData["msg"] = "Added Successfully";
                    TempData["msgr"] = "";
                    TempData["flag"] = "1";
                }
                else
                {
                    TempData["msgr"] = "Error! Data not added";
                    TempData["msg"] = "";
                }
                return View(model);
            }
            else
            {
                bool result = UOF.ICourse.UpdateCourseDetails(model);
                if (result == true)
                {
                    TempData["msg"] = "Updated Successfully";
                    TempData["msgr"] = "";
                    TempData["flag"] = "1";
                }
                else
                {
                    TempData["msgr"] = "Error! Data not Updated";
                    TempData["msg"] = "";
                }
                return View(model);
            }
        }

        public ActionResult GetAllTypes(string type, int CourseId)
        {
            List<CourseDetail> data = UOF.ICourse.GetAllTypeList(type, CourseId);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetAllTypeDetails(int CourseDetailId)
        {
            CourseDetail data = UOF.ICourse.GetAllTypeDetails(CourseDetailId);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        //mentor
        [HttpGet]
        public ActionResult AddMentorDetails()
        {
            TempData["Message"] = "";
            MentorMaster MentorModel = new MentorMaster();

            List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
            MentorModel.GenderList = GenderList;
            List<SkillMaster> skList = UOF.IAdminMaster.GetAllSkillTypes();
            MentorModel.SkillsList = skList;

            return View(MentorModel);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddMentorDetails(MentorMaster model, string[] SkillName)
        {
            try
            {
                // Create a blob client for interacting with the blob service.
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["MentorImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                //blobContainer.SetPermissions(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });

                string pathurl = "";
                // string oldpic = CurrentUser.ProfilePic;
                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _mentorImageFolderLocation;
                    _mentorImageFolderLocation = ConfigurationManager.AppSettings["MentorImageFolder"].ToString();

                    //string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = "/" + _mentorImageFolderLocation + myfile;


                    //string directoryPath = Server.MapPath(string.Format("~/{0}/", _mentorImageFolderLocation));
                    //if (!Directory.Exists(directoryPath))
                    //{
                    //    Directory.CreateDirectory(directoryPath);
                    //}
                    //model.File.SaveAs(path);

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                }
                else
                {
                    pathurl = "";
                }
                model.ImageUrl = pathurl;
                if (model.GenderId == null || model.GenderId == 0)
                {
                    model.GenderId = 1;
                }
                model.Skills = SkillName != null ? string.Join(",", SkillName) : null;
                UOF.IMentorMaster.Add(model);
                int stat = UOF.SaveChanges();
                if (stat > 0)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            MentorMaster MenModel = new MentorMaster();

            List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
            MenModel.GenderList = GenderList;
            List<SkillMaster> skList = UOF.IAdminMaster.GetAllSkillTypes();
            MenModel.SkillsList = skList;
            return View(MenModel);
        }

        public ActionResult ViewAllMentor(int page = 1, string textsrch = "", int MentorId = 0)
        {
            TempData["Message"] = "";
            ViewBag.ViewAllMentor = "ViewAllMentor";
            PagingDTO<MentorMaster> model = UOF.ICourse.GetMentorDetails(page, pageSize, textsrch, MentorId);
            ViewBag.AuthorList = UOF.ICourse.GetMentorMasterList();
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult MentorDelete(int id, int page = 1)
        {

            // Create a blob client for interacting with the blob service.
            blobClient = storageAccount.CreateCloudBlobClient();
            blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["MentorImageFolder"].ToString());
            blobContainer.CreateIfNotExistsAsync();

            TempData["Message"] = "";
            //Basant_Rep
            var mobj = UOF.IMentorMaster.Get(id);
            if (mobj != null)
            {
                UOF.IMentorMaster.Remove(mobj);
                UOF.SaveChanges();
            }

            var photoName = "";
            photoName = ImgCloudPath + mobj.ImageUrl;

            Uri uri = new Uri(photoName);
            string filename = Path.GetFileName(uri.LocalPath);

            var blob = blobContainer.GetBlockBlobReference(filename);
            blob.DeleteIfExistsAsync();

            //string fullPath = Request.MapPath(photoName);

            //if (System.IO.File.Exists(fullPath))
            //{
            //    System.IO.File.Delete(fullPath);
            //}

            return RedirectToAction("ViewAllMentor", new { page = page });
        }

        [HttpGet]
        public ActionResult EditMentor(int id)
        {
            TempData["Message"] = "";
            MentorMaster model = UOF.ICourse.GetMentorDisplay(id);
            List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
            model.GenderList = GenderList;
            model.GenderId = model.GenderId;
            ///skill
            List<SkillMaster> skList = UOF.IAdminMaster.GetAllSkillTypes();
            model.SkillsList = skList;
            model.SelectedSkills = UOF.IMember.GetCourseSkill(id);
            List<SelectListItem> Select_skList = new List<SelectListItem>();
            foreach (var m in skList)
            {
                SelectListItem obj1 = new SelectListItem()
                {
                    Value = m.SkillId.ToString(),
                    Text = m.Name,
                    Selected = model.SelectedSkills.Where(e => e.SkillId == m.SkillId).Count() > 0 ? true : false
                };

                Select_skList.Add(obj1);
            }
            model.SkillList = Select_skList;
            return View(model);

        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditMentor(MentorMaster model, FormCollection SkillNamelist)
        {
            try
            {
                // Create a blob client for interacting with the blob service.
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["MentorImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                String SkillN = SkillNamelist["SkillNamelist"];
                string pathurl = "";
                bool oldflag = false;
                string oldimg = model.ImageUrl;
                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _mentorImageFolderLocation;
                    _mentorImageFolderLocation = ConfigurationManager.AppSettings["MentorImageFolder"].ToString();

                    //string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = "/" + _mentorImageFolderLocation + myfile;
                    //string directoryPath = Server.MapPath(string.Format("~/{0}/", _mentorImageFolderLocation));
                    //if (!Directory.Exists(directoryPath))
                    //{
                    //    Directory.CreateDirectory(directoryPath);
                    //}
                    //model.File.SaveAs(path);

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    oldflag = true;
                }
                else
                {
                    pathurl = model.ImageUrl.Replace(ImgCloudPath, "");
                }
                model.Skills = SkillN;
                model.ImageUrl = pathurl;
                UOF.IMentorMaster.Update(model);
                int stat = UOF.SaveChanges();
                if (stat > 0)
                {
                    if (oldflag == true)
                    {
                        Uri uri = new Uri(ImgCloudPath + oldimg);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();
                    }
                    TempData["Message"] = "Details has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewAllMentor");
        }

        public ActionResult ViewAllFAQ(int page = 1, string textsrch = "", int? CourseId = null, int CourseType = 0)
        {
            TempData["Message"] = "";
            ViewBag.ViewAllFAQ = "ViewAllFAQ";

            PagingDTO<FAQMaster> model = UOF.ICourse.GetFAQDetails(page, pageSize, textsrch, CourseId, CourseType);

            if (model != null)
            {
                model.CourseId = CourseId;
                model.Courses = UOF.ICommonLogic.GetAllCourseList();
                ViewBag.page = model.Page;
            }
            else
            {
                model = new PagingDTO<FAQMaster>();
                model.CourseId = CourseId;
                model.Courses = UOF.ICommonLogic.GetAllCourseList();
            }
            IEnumerable<EnumFaqType> CTypelist = Enum.GetValues(typeof(EnumFaqType))
                                                     .Cast<EnumFaqType>();
            List<SelectListItem> itemctype = new List<SelectListItem>();

            var CourseTypeList = from action in CTypelist
                                 select new SelectListItem
                                 {
                                     Text = action.ToString(),
                                     Value = ((int)action).ToString()
                                 };
            foreach (var item in CourseTypeList)
            {
                itemctype.Add(new SelectListItem
                {
                    Text = item.Text,
                    Value = item.Value.ToString()
                });
            }
            itemctype.Insert(0, new SelectListItem { Text = "- Select Course Type -", Value = "4" });
            ViewBag.CourseTypeList = itemctype;

            List<SelectListItem> items = new List<SelectListItem>();
            foreach (var item in model.Courses)
            {
                items.Add(new SelectListItem
                {
                    Text = item.Name,
                    Value = item.CourseId.ToString()
                });
            }

            items.Insert(0, new SelectListItem { Text = "- Select Course -", Value = "" });
            items.Insert(1, new SelectListItem { Selected = false, Text = "Default", Value = "0" });
            ViewData["ListItems"] = items;
            return View(model);
        }

        public ActionResult AddFAQDetails()
        {
            FAQMaster Model = new FAQMaster();
            ViewBag.ViewAllFAQ = "ViewAllFAQ";
            Model.courseList = UOF.ICommonLogic.GetCourseList();
            IEnumerable<EnumFaqType> CTypelist = Enum.GetValues(typeof(EnumFaqType))
                                                     .Cast<EnumFaqType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            return View(Model);
        }
        [HttpPost]
        public ActionResult AddFAQDetails(FAQMaster model)
        {
            try
            {
                if (model.CourseId == null)
                {
                    model.CourseId = 0;
                }
                bool status = UOF.ICourse.CreateFAQ(model);

                if (status == true)
                {
                    ViewBag.Message = "FAQ has been saved successfully";
                    ModelState.Clear();
                    model.FAQTitle = "";
                    model.Answer = "";
                    model.Sequence = "";
                }
                else
                {
                    ViewBag.Message = "Unable to add FAQ this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            IEnumerable<EnumFaqType> CTypelist = Enum.GetValues(typeof(EnumFaqType))
                                                     .Cast<EnumFaqType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            model.courseList = UOF.ICommonLogic.GetCourseList();
            return View(model);
        }

        public ActionResult EditFAQDetails(int id)
        {
            FAQMaster model = new FAQMaster();
            model = UOF.ICourse.GetFAQDetails(id);
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            IEnumerable<EnumFaqType> CTypelist = Enum.GetValues(typeof(EnumFaqType))
                                                     .Cast<EnumFaqType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            model.courseList = courseList;
            model.CourseId = model.CourseId;
            return View(model);
        }
        [HttpPost]
        public ActionResult EditFAQDetails(FAQMaster model)
        {
            try
            {
                if (model.CourseId == null)
                {
                    model.CourseId = 0;
                }
                bool status = UOF.ICourse.UpdateFAQDetails(model);

                if (status == true)
                {
                    ViewBag.Message = "FAQ has been saved successfully";
                    ModelState.Clear();
                    return RedirectToAction("ViewAllFAQ");
                }
                else
                {
                    ViewBag.Message = "Unable to Update FAQ this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            IEnumerable<EnumFaqType> CTypelist = Enum.GetValues(typeof(EnumFaqType))
                                                     .Cast<EnumFaqType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            model.courseList = courseList;
            return View(model);
        }
        public ActionResult FAQDelete(int id)
        {
            bool status = UOF.ICourse.DeleteFAQ(id);

            return RedirectToAction("ViewAllFAQ");
        }

        ///////Category/////////////
        public ActionResult CategoryList(int page = 1)
        {
            PagingDTO<CourseCategoryDTO> model = new PagingDTO<CourseCategoryDTO>();
            ViewBag.CategoryList = "CategoryList";
            model = UOF.ICourse.GetAllCategoryList(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult CreateCourseCategory()
        {
            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                       .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            return View();
        }

        [HttpPost]
        public ActionResult CreateCourseCategory(CourseCategoryDTO model)
        {
            try
            {
                bool status = UOF.ICourse.CreateCourseCategory(model);

                if (status == true)
                {
                    ViewBag.Message = "Course Category has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add Course Category this time. Please try again later.";
                }
                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                       .Cast<EnumCourseType>();
                ViewBag.CourseTypeList = from action in CTypelist
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }

        // [CustomAuthorizeAttribute(Roles = "Admin")]
        public ActionResult CourseCategoryDelete(int id, int page = 1)
        {
            UOF.ICourse.DeleteCourseCategory(id);
            return RedirectToAction("CategoryList", new { page = page });
        }

        // [CustomAuthorizeAttribute(Roles = "Admin")]
        [HttpGet]
        public ActionResult EditCourseCategory(int id)
        {
            if (id != 0)
            {
                CourseCategoryDTO model = UOF.ICourse.GetCourseCategory(id);
                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                       .Cast<EnumCourseType>();
                ViewBag.CourseTypeList = from action in CTypelist
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };
                return View(model);
            }
            return null;
        }

        // [CustomAuthorizeAttribute(Roles = "Admin")]
        [HttpPost, ValidateInput(false)]
        public ActionResult EditCourseCategory(CourseCategoryDTO model)
        {
            try
            {
                bool status = UOF.ICourse.UpdateCourseCategory(model);
                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                       .Cast<EnumCourseType>();
                ViewBag.CourseTypeList = from action in CTypelist
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };
                if (status == true)
                {
                    ViewBag.Message = "Course Category has been Update successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Course Category this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            return RedirectToAction("CategoryList");

        }

        [HttpGet]
        public ActionResult MapArticleToCategory(int id)
        {
            if (id != 0)
            {
                CourseCategoryDTO model = UOF.ICourse.GetCourseCategory(id);
                List<CategoryDTO> courseList = UOF.ICourse.GetArticleCategories();

                model.Categories = ViewBag.SelectedAreas = UOF.ICourse.getselectArticleList(id);
                List<SelectListItem> Select_List = new List<SelectListItem>();
                foreach (var c in courseList)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = c.CategoryID.ToString(),
                        Text = c.CategoryName,
                        Selected = model.Categories.Where(m => m.CategoryID == c.CategoryID).Count() > 0 ? true : false
                    };
                    Select_List.Add(obj);
                }
                model.artcatList = Select_List;
                return View(model);
            }
            return null;
        }

        [HttpGet]
        public ActionResult MapCategoryToCourse(int id)
        {
            if (id != 0)
            {
                CourseCategoryDTO model = UOF.ICourse.GetCourseCategory(id);
                List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();

                model.Courses = ViewBag.SelectedAreas = UOF.ICourse.GetCourses(id);
                List<SelectListItem> Select_List = new List<SelectListItem>();
                foreach (var c in courseList)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = c.CourseId.ToString(),
                        Text = c.Name,
                        Selected = model.Courses.Where(m => m.CourseId == c.CourseId).Count() > 0 ? true : false
                    };

                    Select_List.Add(obj);
                }
                model.CoursesList = Select_List;
                return View(model);
            }
            return null;
        }

        [HttpPost]
        public ActionResult MapCategoryToCourse(CourseCategoryDTO model, FormCollection CoursesNamel)
        {
            String updatedCourseId = CoursesNamel["CoursesNamel"];
            if (model.CourseCategoryId != 0)
            {
                List<int> updatedCourseIds = updatedCourseId.Split(',').Select(int.Parse).ToList();
                bool status = UOF.ICourse.CourseMapping(model, updatedCourseIds);
            }
            return RedirectToAction("MapCategoryToCourse", model.CourseCategoryId);
        }

        [HttpGet]
        public ActionResult MapCategoryToTechnology(int id)
        {
            if (id != 0)
            {
                CourseCategoryDTO model = UOF.ICourse.GetCourseCategory(id);
                List<CategoryDTO> categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course).ToList();

                model.Categories = ViewBag.SelectedAreas = UOF.ICourse.GetCategoryTechnologies(id);
                List<SelectListItem> Select_List = new List<SelectListItem>();
                foreach (var c in categoryList)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = c.CategoryID.ToString(),
                        Text = c.CategoryName,
                        Selected = model.Categories.Where(m => m.CategoryID == c.CategoryID).Count() > 0 ? true : false
                    };

                    Select_List.Add(obj);
                }
                model.CategoryList = Select_List;
                return View(model);
            }
            return null;
        }

        [HttpPost]
        public ActionResult MapCategoryToTechnology(int CourseCategoryId, FormCollection form)
        {
            string updatedTechId = form["TechnologiesName"];
            if (!string.IsNullOrEmpty(updatedTechId))
            {
                List<int> updatedTechIds = updatedTechId.Split(',').Select(int.Parse).ToList();
                bool status = UOF.ICourse.CourseCategoryTechnologyMapping(CourseCategoryId, updatedTechIds);
            }
            return RedirectToAction("CategoryList", "Course");
        }

        [HttpPost]
        public ActionResult MapArticleToCategory(CourseCategoryDTO model, FormCollection CategoryN)
        {
            String updatedCategory = CategoryN["CategoryN"];
            if (model.CourseCategoryId != 0)
            {
                bool status = UOF.ICourse.MapArticleToCategory(model, updatedCategory);
            }
            return RedirectToAction("MapArticleToCategory", model.CourseCategoryId);
        }

        public ActionResult CityWiseCourseList()
        {
            IEnumerable<CourseDTO> model = UOF.ICourse.GetAllCityWiseCourses();
            return View(model);
        }

        public ActionResult CreateCityWiseCourse()
        {
            CourseDTO model = new CourseDTO();
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            model.courseList = courseList;
            return View(model);
        }
        [HttpPost]
        public ActionResult CreateCityWiseCourse(CourseDTO model)
        {
            try
            {
                bool status = UOF.ICourse.CreateCityWiseCourse(model);

                if (status == true)
                {
                    return RedirectToAction("CityWiseCourseList");
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            CourseDTO modeldata = new CourseDTO();
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            modeldata.courseList = courseList;
            return View(modeldata);
        }

        public ActionResult EditCityWiseCourse(int id)
        {
            CourseDTO model = new CourseDTO();
            model = UOF.ICourse.GetCityWiseCourse(id);

            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            model.courseList = courseList;
            return View(model);
        }
        [HttpPost]
        public ActionResult EditCityWiseCourse(CourseDTO model)
        {
            try
            {
                bool status = UOF.ICourse.UpdateCityWiseCourse(model);

                if (status == true)
                {
                    return RedirectToAction("CityWiseCourseList");
                }
                else
                {
                    ViewBag.Message = "Unable to Update Course this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("CityWiseCourseList");
        }

        public ActionResult DeleteCityWiseCourse(int id)
        {
            bool status = UOF.ICourse.DeleteCityWiseCourse(id);


            return RedirectToAction("CityWiseCourseList");
        }

        //////////////Ads////////////////////
        public ActionResult AdsList(int page = 1)
        {
            PagingDTO<AdsMastersDTO> model = new PagingDTO<AdsMastersDTO>();
            ViewBag.AdsList = "AdsList";
            model = UOF.ICourse.GetAllAdsList(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult CreateAds()
        {
            AdsMastersDTO model = new AdsMastersDTO();
            List<CategoryDTO> CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
            List<PositionMasters> PositionList = UOF.ICourse.GetPosition();
            model.CategoryList = CategoryList;
            model.PositionList = PositionList;
            return View(model);
        }
        [HttpPost]
        public ActionResult CreateAds(AdsMastersDTO model)
        {
            try
            {
                bool status = UOF.ICourse.CreateAds(model);

                if (status == true)
                {
                    ViewBag.Message = "Ads has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            AdsMastersDTO modeldata = new AdsMastersDTO();
            List<CategoryDTO> CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
            List<PositionMasters> PositionList = UOF.ICourse.GetPosition();
            modeldata.CategoryList = CategoryList;
            modeldata.PositionList = PositionList;
            return View(modeldata);
        }

        public ActionResult EditAds(int id)
        {
            AdsMastersDTO model = new AdsMastersDTO();
            model = UOF.ICourse.GetAds(id);

            List<CategoryDTO> CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
            List<PositionMasters> PositionList = UOF.ICourse.GetPosition();
            model.CategoryList = CategoryList;
            model.PositionList = PositionList;
            return View(model);
        }

        [HttpPost]
        public ActionResult EditAds(AdsMastersDTO model)
        {
            try
            {
                bool status = UOF.ICourse.UpdateAds(model);

                if (status == true)
                {
                    ViewBag.Message = "Ad has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Course this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("AdsList");
        }

        public ActionResult DeleteAds(int id, int page = 1)
        {
            bool status = UOF.ICourse.DeleteAds(id);
            if (status == false)
            {
                TempData["Message"] = "Sorry! First delete all the images which are added in the Ads which you want to delete.";
            }
            return RedirectToAction("AdsList", new { page = page });
        }
        //////////PositionType///////////
        public ActionResult PositionList(int page = 1)
        {
            PagingDTO<PositionMasters> model = new PagingDTO<PositionMasters>();
            ViewBag.PositionList = "PositionList";
            model = UOF.ICourse.GetAllPositionList(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult CreatePosition()
        {
            PositionMasters model = new PositionMasters();
            List<PositionMasters> PositionList = UOF.ICourse.GetPosition();
            model.PositionList = PositionList;
            return View(model);
        }
        [HttpPost]
        public ActionResult CreatePosition(PositionMasters model)
        {
            try
            {
                bool status = UOF.ICourse.CreatePosition(model);

                if (status == true)
                {
                    ViewBag.Message = "Position  has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult EditPosition(int id)
        {
            PositionMasters model = new PositionMasters();
            model = UOF.ICourse.GetPosition(id);

            List<PositionMasters> PositionList = UOF.ICourse.GetPosition();
            model.PositionList = PositionList;
            return View(model);
        }

        [HttpPost]
        public ActionResult EditPosition(PositionMasters model)
        {
            try
            {
                bool status = UOF.ICourse.UpdatePosition(model);

                if (status == true)
                {
                    ViewBag.Message = "Position has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Course this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("PositionList");
        }
        public ActionResult DeletePosition(int id)
        {
            bool status = UOF.ICourse.DeletePosition(id);
            return RedirectToAction("PositionList");
        }
        ///////////////Ads Image /////////
        public ActionResult AdsImageList(int page = 1, int id = 0)
        {
            PagingDTO<AdsImageCollection> model = new PagingDTO<AdsImageCollection>();
            ViewBag.AdsList = "AdsList";
            model = UOF.ICourse.GetAllAdsImageList(page, pageSize, id);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return PartialView("_AdsImageList", model);
        }
        public ActionResult CreateAdsImage(int id)
        {
            AdsImageCollection model = new AdsImageCollection();
            List<AdsMastersDTO> AdsList = UOF.ICourse.GetAds();
            model.AdsList = AdsList;
            ViewBag.Catname = AdsList.Where(x => x.Id == id).Select(x => x.Catname).FirstOrDefault();
            ViewBag.AdsId = id;
            return View(model);
        }
        [HttpPost]
        public ActionResult CreateAdsImage(AdsImageCollection model)
        {
            ViewBag.AdsId = model.AdsId;
            try
            {
                string imageurl = "";
                // string oldpic = CurrentUser.ProfilePic;

                if (model.image != null && model.image.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.image.FileName); //file name  
                    var ext = Path.GetExtension(model.image.FileName); //getting the extension(ex-.jpg) 
                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = Regex.Replace(name, "[^0-9a-zA-Z]+", "").ToLower() + "-ads" + time + ext; //

                    string _adsImageFolderLocation;
                    _adsImageFolderLocation = ConfigurationManager.AppSettings["adsImageFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_adsImageFolderLocation), myfile);
                    imageurl = _adsImageFolderLocation + myfile;


                    string directoryPath = Server.MapPath(string.Format("~/{0}/", _adsImageFolderLocation));
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }

                    model.image.SaveAs(path);
                }
                else
                {
                    imageurl = "";
                }
                model.ImageURL = imageurl;
                UOF.IAdsImageCollection.Add(model);
                int flag = UOF.SaveChanges();
                if (flag > 0)
                {
                    ViewBag.Message = "Details has been saved successfully";
                    ModelState.Clear();

                }
                else
                {
                    ViewBag.Message = "Error!!";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            AdsImageCollection modeldata = new AdsImageCollection();
            List<AdsMastersDTO> AdsList = UOF.ICourse.GetAds();
            modeldata.AdsList = AdsList;
            return View(modeldata);
        }

        public ActionResult EditAdsImage(int id)
        {
            AdsImageCollection model = new AdsImageCollection();
            model = UOF.IAdsImageCollection.Get(id);
            ViewBag.AdId = model.AdsId;
            List<AdsMastersDTO> AdsList = UOF.ICourse.GetAds();
            model.AdsList = AdsList;
            return View(model);
        }

        [HttpPost]
        public ActionResult EditAdsImage(AdsImageCollection model)
        {

            try
            {
                string imgurl = "";

                if (model.image != null && model.image.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.image.FileName); //file name  
                    var ext = Path.GetExtension(model.image.FileName); //getting the extension(ex-.jpg)  
                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = Regex.Replace(model.Name, "[^0-9a-zA-Z]+", "") + "_" + Regex.Replace(name, "[^0-9a-zA-Z]+", "").ToLower() + "-ads" + time + ext; //
                    string _adsImageFolderLocation;
                    _adsImageFolderLocation = ConfigurationManager.AppSettings["adsImageFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_adsImageFolderLocation), myfile);
                    imgurl = _adsImageFolderLocation + myfile;


                    string directoryPath = Server.MapPath(string.Format("~/{0}/", _adsImageFolderLocation));
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }



                    string fullpath = Request.MapPath(model.ImageURL);
                    if (System.IO.File.Exists(fullpath))
                    {
                        System.IO.File.Delete(fullpath);
                    }
                    model.image.SaveAs(path);
                }
                else
                {
                    imgurl = model.ImageURL;
                }
                model.ImageURL = imgurl;
                UOF.IAdsImageCollection.Update(model);
                int flag1 = UOF.SaveChanges();
                if (flag1 > 0)
                {
                    ViewBag.Message = "Ad has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Course this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("CreateAdsImage", new { id = model.AdsId });
        }

        public ActionResult DeleteAdsImage(int id, int page = 1)
        {
            //Basant_Rep
            var mobj = UOF.IAdsImageCollection.Get(id);
            int AdId = mobj.AdsId;
            if (mobj != null)
            {
                UOF.IAdsImageCollection.Remove(mobj);
                UOF.SaveChanges();
            }
            var photoName = "";
            photoName = mobj.ImageURL;
            string fullPath = Request.MapPath(photoName);

            if (System.IO.File.Exists(fullPath))
            {
                System.IO.File.Delete(fullPath);
            }
            return RedirectToAction("CreateAdsImage", new { id = AdId });
        }
        public ActionResult ViewAllStudents(int page = 1, string textsrch = "", string Date = "", int CourseId = 0)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewAllStudents = "ViewAllStudents";
            PagingDTO<CourseSubscriptionMemberDTO> model = new PagingDTO<CourseSubscriptionMemberDTO>();

            model = UOF.IAdminMaster.GetAllSubscribedMember(page, pageSize, textsrch, startDate, endDate, CourseId);
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.courseList = courseList;
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            Session["linkpage"] = "ViewAllStudents";
            return View(model);
        }

        public JsonResult ViewAllStudentsExcel(int page = 1, string textsrch = "", string Date = "", int CourseId = 0)
        {
            try
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                ViewBag.ViewAllStudents = "ViewAllStudents";
                List<CourseSubscriptionMemberDTO> report = new List<CourseSubscriptionMemberDTO>();

                report = UOF.IAdminMaster.GetAllSubscribedMemberExcel(textsrch, startDate, endDate, CourseId);


                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string ReportName = "ViewAllStudentsReport" + time + ".xlsx";
                string fileName = ReportName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingAllStudentsReport(stream, report, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        ///////////////////////PPC Courses///////////

        public ActionResult ViewPPCCourses(int page = 1)
        {
            PagingDTO<PPCCourseDTO> model = new PagingDTO<PPCCourseDTO>();
            ViewBag.PPCCoursesList = "PPCCoursesList";
            model = UOF.ICourse.GetAllViewPPCCourses(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);

        }

        public ActionResult CreatePPCCourse()
        {
            PPCCourseDTO model = new PPCCourseDTO();
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            model.courseList = courseList;
            List<TrainingMode> TrainingModeList = UOF.IAdminMaster.GetTrainingModeList();
            model.TrainingModeList = TrainingModeList;
            List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
            model.MentorMasterList = MentorMasterList;
            List<SourceMaster> SourceList = UOF.ICourse.GetSourceMasterList();
            model.SourceList = SourceList;
            return View(model);
        }
        [HttpPost, ValidateInput(false)]
        public ActionResult CreatePPCCourse(PPCCourseDTO model, string[] Mentors)
        {
            try
            {
                string pathurl = "";
                // string oldpic = CurrentUser.ProfilePic;
                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _mentorImageFolderLocation;
                    _mentorImageFolderLocation = ConfigurationManager.AppSettings["ppcFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = _mentorImageFolderLocation + myfile;


                    string directoryPath = Server.MapPath(string.Format("~/{0}/", _mentorImageFolderLocation));
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }
                    model.File.SaveAs(path);
                }
                else
                {
                    pathurl = "";
                }
                model.ImageDemo = pathurl;
                bool status = UOF.ICourse.CreatePPCCourse(model, Mentors);

                if (status == true)
                {
                    return RedirectToAction("ViewPPCCourses");
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            PPCCourseDTO modeldata = new PPCCourseDTO();
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            modeldata.courseList = courseList;
            return View(modeldata);
        }

        public ActionResult EditPPCCourse(int id)
        {
            PPCCourseDTO model = new PPCCourseDTO();
            model = UOF.ICourse.GetPPCCourse(id);
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            model.courseList = courseList;
            List<TrainingMode> TrainingModeList = UOF.IAdminMaster.GetTrainingModeList();
            model.TrainingModeList = TrainingModeList;
            List<SourceMaster> SourceList = UOF.ICourse.GetSourceMasterList();
            model.SourceList = SourceList;
            List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
            model.MentorMasterList = MentorMasterList;
            model.SpeakersList = ViewBag.SelectedAuthors = UOF.ICourse.GetPPCSpeakers(id);
            List<SelectListItem> Select_List = new List<SelectListItem>();
            foreach (var m in MentorMasterList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = m.MentorId.ToString(),
                    Text = m.Name,
                    Selected = model.SpeakersList.Where(me => me.MentorId == m.MentorId).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }
            model.MentorMasterSelectlist = Select_List;
            ViewBag.SelectedModeIdValue = model.TrainingModeId;
            ViewBag.SelectedSourceIdValue = model.SourceId;
            return View(model);
        }
        [HttpPost, ValidateInput(false)]
        public ActionResult EditPPCCourse(PPCCourseDTO model, FormCollection MentorName)
        {
            try
            {
                string pathurl = "";

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _mentorImageFolderLocation;
                    _mentorImageFolderLocation = ConfigurationManager.AppSettings["ppcFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = _mentorImageFolderLocation + myfile;


                    string directoryPath = Server.MapPath(string.Format("~/{0}/", _mentorImageFolderLocation));
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }
                    string fullpath = Request.MapPath(model.ImageDemo);
                    if (System.IO.File.Exists(fullpath))
                    {
                        System.IO.File.Delete(fullpath);
                    }
                    model.File.SaveAs(path);
                }
                else
                {
                    pathurl = model.ImageDemo;
                }
                model.ImageDemo = pathurl;
                bool status = UOF.ICourse.UpdatePPCCourse(model);

                if (status == true)
                {
                    return RedirectToAction("ViewPPCCourses");
                }
                else
                {
                    ViewBag.Message = "Unable to Update Course this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ViewPPCCourses");
        }

        public ActionResult DeletePPCCourse(int id)
        {
            try
            {
                var oldimg = UOF.ICourse.DeletePPCCourse(id);
                var photoName = "";
                photoName = oldimg;
                string fullPath = Request.MapPath(photoName);

                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return RedirectToAction("ViewPPCCourses");
        }

        public JsonResult GetAllCourseUrl(int id)
        {
            try
            {
                string url = UOF.ICourse.GetCourseUrlDetails(id);
                if (url == null)
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    url = url.Substring(10);
                    return Json(url, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        ////////////////////////course topic /////////by amit 26/03/17//////////
        public ActionResult CourseTopicList(int page = 1, int CourseId = 0)
        {
            PagingDTO<CourseTopic> model = new PagingDTO<CourseTopic>();
            ViewBag.CourseTopicList = "CourseTopicList";
            model = UOF.ICourseTopic.GetCourseTopicList(page, pageSize, CourseId);
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.courseList = courseList;
            Session["TCourseId"] = CourseId;
            ViewBag.Message = TempData["Message"];
            if (model != null)
            {

                ViewBag.page = model.Page;
            }
            return View(model);

        }
        public ActionResult CourseSubTopicList(int page = 1, int TopicId = 0, int CId = 0)
        {
            ViewBag.page = page;
            ViewBag.TopicId = TopicId;

            ViewBag.Message = TempData["Message"];
            ViewBag.TCourseId = Session["TCourseId"] = CId;
            return View();

        }
        public ActionResult PreRecordedList(int page = 1, int TopicId = 0)
        {
            PagingDTO<CourseSubTopic> model = new PagingDTO<CourseSubTopic>();
            ViewBag.TCourseId = Session["TCourseId"];
            ViewBag.CourseSubTopicList = "CourseSubTopicList";
            if (TopicId != 0)
            {
                model = UOF.ICourseTopic.GetCourseSubTopicList(TopicId, page, pageSize);
            }
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            else { ViewBag.TopicId = TopicId; }
            return PartialView("_PreRecordedSubTopic", model);

        }

        public ActionResult RecordedList(int page = 1, int TopicId = 0)
        {
            PagingDTO<CourseSubTopicsBatch> model = new PagingDTO<CourseSubTopicsBatch>();
            ViewBag.CourseSubTopicList = "CourseSubTopicList";
            ViewBag.TCourseId = Session["TCourseId"];
            if (TopicId != 0)
            {
                model = UOF.ICourseTopic.GetCourseSubTopicBatchList(TopicId, page, pageSize);
            }
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            else { ViewBag.TopicId = TopicId; }
            return PartialView("_RecordedSubTopic", model);

        }
        public ActionResult CreateCourseTopic()
        {
            try
            {
                CourseTopic model = new CourseTopic();
                List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.courseList = courseList;

                model.CourseId = (int)Session["TCourseId"];
                return View(model);
            }
            catch (Exception ex)
            {
                CourseTopic model = new CourseTopic();
                ViewBag.Message = ex.Message;
                return View(model);
            }
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult CreateCourseTopic(CourseTopic model)
        {
            try
            {
                List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.courseList = courseList;
                ViewBag.TCourseId = Session["TCourseId"];

                UOF.ICourseTopic.Add(model);
                UOF.SaveChanges();
                return RedirectToAction("CourseTopicList", "Course", new { CourseId = model.CourseId });

            }
            catch (Exception ex)
            {
                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View(model);
            }
        }

        public ActionResult EditCourseTopic(int Topic, int page = 1)
        {
            try
            {
                CourseTopic model = new CourseTopic();
                model = UOF.ICourseTopic.GetTopic(Topic);
                List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.courseList = courseList;

                return View(model);
            }
            catch (Exception ex)
            {
                CourseTopic model = new CourseTopic();
                ViewBag.Message = ex.Message;
                return View(model);
            }


        }
        [HttpPost, ValidateInput(false)]
        public ActionResult EditCourseTopic(CourseTopic model)
        {
            try
            {
                UOF.ICourseTopic.Update(model);
                UOF.SaveChanges();
                bool result = UOF.ICourseTopic.CreateUpdateCoursePlayer(model.TopicId);
                return RedirectToAction("CourseTopicList", "Course", new { CourseId = model.CourseId });
            }
            catch (Exception ex)
            {
                List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.courseList = courseList;
                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View(model);
            }

        }
        public ActionResult CreateCourseSubTopic(int TopicId, int page = 1, int cid = 0)
        {
            try
            {
                CourseSubTopic model = new CourseSubTopic();
                model.IsLock = true;

                List<CourseTopic> courseTopicList = UOF.ICourseTopic.GetcourseTopicList(cid);
                ViewBag.courseTopicList = courseTopicList;

                ViewBag.TopicId = TopicId;
                ViewBag.CourseId = cid;

                IEnumerable<EnumTopicType> TopicType = Enum.GetValues(typeof(EnumTopicType))
                                                   .Cast<EnumTopicType>();
                ViewBag.TopicTypeList = from action in TopicType
                                        select new SelectListItem
                                        {
                                            Text = action.ToString(),
                                            Value = ((int)action).ToString()
                                        };

                IEnumerable<EnumIDELanguage> Languages = Enum.GetValues(typeof(EnumIDELanguage))
                                                   .Cast<EnumIDELanguage>();
                ViewBag.LanguageList = from action in Languages
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = action.ToString()
                                       };

                return View(model);
            }
            catch (Exception ex)
            {
                CourseSubTopic model = new CourseSubTopic();
                ViewBag.Message = ex.Message;
                return View(model);
            }
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult CreateCourseSubTopic(CourseSubTopic model)
        {
            try
            {
                bool status = UOF.ICourseTopic.CreateCourseSubTopic(model);
                return RedirectToAction("CourseSubTopicList", new { TopicId = model.TopicId, CourseId = model.CourseId });
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View(model);
            }
        }
        public ActionResult PR_EditCourseSubTopic(int id = 0, int TopicId = 0, int cid = 0, int page = 1)
        {
            try
            {
                CourseSubTopic model = new CourseSubTopic();
                model = UOF.ICourseTopic.GetPR_SubTopic(id);
                List<CourseTopic> courseTopicList = UOF.ICourseTopic.GetcourseTopicList(cid);

                ViewBag.courseTopicList = courseTopicList;
                ViewBag.TopicId = model.TopicId;
                ViewBag.CourseId = cid;

                IEnumerable<EnumTopicType> TopicType = Enum.GetValues(typeof(EnumTopicType))
                                                   .Cast<EnumTopicType>();
                ViewBag.TopicTypeList = from action in TopicType
                                        select new SelectListItem
                                        {
                                            Text = action.ToString(),
                                            Value = ((int)action).ToString()
                                        };

                IEnumerable<EnumIDELanguage> Languages = Enum.GetValues(typeof(EnumIDELanguage))
                                                   .Cast<EnumIDELanguage>();
                ViewBag.LanguageList = from action in Languages
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = action.ToString()
                                       };

                return View("CreateCourseSubTopic", model);
            }
            catch (Exception ex)
            {
                CourseSubTopic model = new CourseSubTopic();
                ViewBag.Message = ex.Message;
                return View("CreateCourseSubTopic", model);
            }
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult PR_EditCourseSubTopic(CourseSubTopic model)
        {
            try
            {
                bool status = UOF.ICourseTopic.PR_UpdateCourseSubTopic(model);
                if (status)
                    return RedirectToAction("CourseSubTopicList", new { TopicId = model.TopicId, CourseId = model.CourseId });
                else
                {
                    ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                    return View("CreateCourseSubTopic", model);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View("CreateCourseSubTopic", model);
            }
        }

        public ActionResult CourseTopicDelete(int id)
        {
            int status = UOF.ICourseTopic.DeleteCourseTopic(id);
            if (status == 1)
            { TempData["Message"] = "Unable to delete Course Topic this time. Please delete all sub topics first."; }
            else if (status == 2)
            { TempData["Message"] = ""; }
            else { TempData["Message"] = "Unable to Create Course Topic this time. Please try again later."; }
            int CourseId = (int)Session["TCourseId"];
            return RedirectToAction("CourseTopicList", new { CourseId = CourseId });
        }

        public ActionResult R_CourseSubTopicDelete(int id, int TopicId = 0, int page = 1)
        {
            bool status = UOF.ICourseTopic.DeleteCourseSubTopicBatch(id);
            ViewBag.TopicId = TopicId;
            if (status != true)
            {
                TempData["Message"] = "Please Delete all files in this SubTopic";
            }
            return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
        }


        public ActionResult PR_CourseSubTopicDelete(int id, int TopicId = 0, int page = 1)
        {
            bool status = UOF.ICourseTopic.DeleteCourseSubTopic(id);
            ViewBag.TopicId = TopicId;
            if (status != true)
            {
                TempData["Message"] = "Please Delete all files in this SubTopic";
            }
            return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
        }
        public ActionResult R_EditCourseSubTopic(int id = 0, int TopicId = 0, int page = 1)
        {
            try
            {
                CourseSubTopicsBatch model = new CourseSubTopicsBatch();
                model = UOF.ICourseTopic.GetR_SubTopic(id);
                List<CourseTopic> courseTopicList = UOF.ICourseTopic.GetcourseTopicList();
                ViewBag.courseTopicList = courseTopicList;
                ViewBag.CourseId = courseTopicList.Where(x => x.TopicId == model.TopicId).Select(x => x.CourseId).FirstOrDefault();
                ViewBag.TopicId = model.TopicId;
                return View(model);
            }
            catch (Exception ex)
            {
                CourseSubTopic model = new CourseSubTopic();
                ViewBag.Message = ex.Message;
                return View(model);
            }
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult R_EditCourseSubTopic(CourseSubTopicsBatch model)
        {
            try
            {
                CourseSubTopicsBatch model1 = new CourseSubTopicsBatch();
                List<CourseTopic> courseTopicList = UOF.ICourseTopic.GetcourseTopicList();
                ViewBag.courseTopicList = courseTopicList;
                ViewBag.CourseId = courseTopicList.Where(x => x.TopicId == model.TopicId).Select(x => x.CourseId).FirstOrDefault();
                if (model.BatchId != 0)
                {
                    bool status = UOF.ICourseTopic.R_UpdateCourseSubTopic(model);
                    ModelState.Clear();
                    ViewBag.Message = "Sub Topic has been saved successfully";
                    ViewBag.TopicId = model.TopicId;
                    return RedirectToAction("CourseSubTopicList", new { TopicId = model.TopicId });
                }
                else
                {
                    ViewBag.TopicId = model.TopicId;
                    ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                    return View(model1);
                }

            }
            catch (Exception ex)
            {
                CourseTopic model1 = new CourseTopic();
                ViewBag.TopicId = model.TopicId;
                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View(model1);

            }
        }
        public ActionResult BatchMapping(int id)
        {
            List<BatchMasters> BatchList = UOF.ICourseTopic.getCurAndUpComingBatchList(id);
            return Json(BatchList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UploadFilePdf(string id)
        {
            try
            {
                foreach (string file in Request.Files)
                {
                    string pathurl = "";
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        var fileName = Path.GetFileName(fileContent.FileName);   //file name  
                        var ext = Path.GetExtension(fileContent.FileName);   //getting the extension(ex-.jpg)  

                        string name = Path.GetFileNameWithoutExtension(fileName);
                        string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                        string myfile = id + "_" + time + ext; //

                        string _CoursePdfFolder;
                        _CoursePdfFolder = ConfigurationManager.AppSettings["CoursePdfFolder"].ToString();

                        string path = Path.Combine(Server.MapPath(_CoursePdfFolder), myfile);
                        pathurl = _CoursePdfFolder + myfile;

                        string directoryPath = Server.MapPath(string.Format("{0}", _CoursePdfFolder));
                        if (!Directory.Exists(directoryPath))
                        {
                            Directory.CreateDirectory(directoryPath);
                        }
                        fileContent.SaveAs(path);
                        //string fullPath = Request.MapPath(oldpic);

                        //if (System.IO.File.Exists(fullPath))
                        //{
                        //    System.IO.File.Delete(fullPath);
                        //}

                    }
                    bool stats = UOF.ICourseTopic.UpdateCoursePdf(id, pathurl);
                    //if (stats != true)
                    //{

                    //}
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed", JsonRequestBehavior.AllowGet);
            }

            return Json("File uploaded successfully", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UploadFileLivePdf(int id)
        {
            try
            {
                foreach (string file in Request.Files)
                {
                    string pathurl = "";
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        var fileName = Path.GetFileName(fileContent.FileName);   //file name  
                        var ext = Path.GetExtension(fileContent.FileName);   //getting the extension(ex-.jpg)  

                        string name = Path.GetFileNameWithoutExtension(fileName);
                        string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                        string myfile = id + "_" + time + ext; //

                        string _CoursePdfFolder;
                        _CoursePdfFolder = ConfigurationManager.AppSettings["CoursePdfFolder"].ToString();

                        string path = Path.Combine(Server.MapPath(_CoursePdfFolder), myfile);
                        pathurl = _CoursePdfFolder + myfile;

                        string directoryPath = Server.MapPath(string.Format("{0}", _CoursePdfFolder));
                        if (!Directory.Exists(directoryPath))
                        {
                            Directory.CreateDirectory(directoryPath);
                        }
                        fileContent.SaveAs(path);
                        //string fullPath = Request.MapPath(oldpic);

                        //if (System.IO.File.Exists(fullPath))
                        //{
                        //    System.IO.File.Delete(fullPath);
                        //}

                    }
                    bool stats = UOF.ICourseTopic.UpdateCourseLivePdf(id, pathurl);
                    //if (stats != true)
                    //{

                    //}
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed", JsonRequestBehavior.AllowGet);
            }

            return Json("File uploaded successfully", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UploadFileCode(string id)
        {
            try
            {
                foreach (string file in Request.Files)
                {
                    string pathurl = "";
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        var fileName = Path.GetFileName(fileContent.FileName);   //file name  
                        var ext = Path.GetExtension(fileContent.FileName);   //getting the extension(ex-.jpg)  

                        string name = Path.GetFileNameWithoutExtension(fileName);
                        string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                        string myfile = id + "_" + time + ext; //

                        string _CourseCodeFolder;
                        _CourseCodeFolder = ConfigurationManager.AppSettings["CourseCodeFolder"].ToString();

                        string path = Path.Combine(Server.MapPath(_CourseCodeFolder), myfile);
                        pathurl = _CourseCodeFolder + myfile;

                        string directoryPath = Server.MapPath(string.Format("{0}", _CourseCodeFolder));
                        if (!Directory.Exists(directoryPath))
                        {
                            Directory.CreateDirectory(directoryPath);
                        }
                        fileContent.SaveAs(path);
                        //string fullPath = Request.MapPath(oldpic);

                        //if (System.IO.File.Exists(fullPath))
                        //{
                        //    System.IO.File.Delete(fullPath);
                        //}

                    }
                    bool stats = UOF.ICourseTopic.UpdateCourseCode(id, pathurl);
                    if (stats != true)
                    {

                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed", JsonRequestBehavior.AllowGet);
            }

            return Json("File uploaded successfully", JsonRequestBehavior.AllowGet);
        }
        public ActionResult PR_CourseSubTopicPdfDelete(int id, int TopicId = 0, int page = 1)
        {
            string oldpath = UOF.ICourseTopic.PR_CourseSubTopicPdfDelete(id);
            if (oldpath != "")
            {
                try
                {
                    string fullPath = Request.MapPath(oldpath);

                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }
                }
                catch (Exception e)
                {
                    return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
                }

            }
            ViewBag.TopicId = TopicId;

            return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
        }

        public ActionResult R_CourseSubTopicPdfDelete(int id, int TopicId = 0, int page = 1)
        {
            string oldpath = UOF.ICourseTopic.R_CourseSubTopicPdfDelete(id);
            if (oldpath != "")
            {
                try
                {
                    string fullPath = Request.MapPath(oldpath);

                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }
                }
                catch (Exception e)
                {
                    return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
                }

            }
            ViewBag.TopicId = TopicId;

            return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
        }


        public ActionResult PR_CourseSubTopicCodeDelete(int id, int TopicId = 0, int page = 1)
        {
            string oldpath = UOF.ICourseTopic.PR_CourseSubTopicCodeDelete(id);
            if (oldpath != "")
            {
                try
                {
                    string fullPath = Request.MapPath(oldpath);

                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }
                }
                catch (Exception e)
                {
                    return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
                }

            }
            ViewBag.TopicId = TopicId;

            return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
        }

        public ActionResult R_CourseSubTopicCodeDelete(int id, int TopicId = 0, int page = 1)
        {
            string oldpath = UOF.ICourseTopic.R_CourseSubTopicCodeDelete(id);
            if (oldpath != "")
            {
                try
                {
                    string fullPath = Request.MapPath(oldpath);

                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }
                }
                catch (Exception e)
                {
                    return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
                }

            }
            ViewBag.TopicId = TopicId;

            return RedirectToAction("CourseSubTopicList", new { page = page, TopicId = TopicId });
        }

        // Course Sales 

        public ActionResult CourseSalesList(int page = 1)
        {
            PagingDTO<CourseSales_V1> model = new PagingDTO<CourseSales_V1>();
            ViewBag.CourseSalesList = "CourseSalesList";
            model = UOF.ICourse.GetAllCourseSalesList(page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult CreateCourseSalesList()
        {
            try
            {
                ViewData["CurrentDate"] = DateTime.UtcNow;
                return View();
            }
            catch (Exception e) { }
            return null;
        }

        [HttpPost]
        public ActionResult CreateCourseSalesList(CourseSales_V1 model)
        {
            try
            {
                bool status = UOF.ICourse.CreateCourseSales(model);
                return RedirectToAction("CourseSalesList");
            }
            catch (Exception e) { }
            return null;
        }

        public ActionResult DeleteCourseSales(int SaleId, int page = 1)
        {
            bool status = UOF.ICourse.DeleteCourseSales(SaleId);
            if (status == false)
            {
                TempData["Message"] = "Sorry!";
            }
            return RedirectToAction("CourseSalesList", new { page = page });
        }
        public ActionResult EditCourseSales(int SaleId)
        {
            try
            {
                ViewData["CurrentDate"] = DateTime.UtcNow;
                CourseSales_V1 model = new CourseSales_V1();
                model = UOF.ICourse.GetCoursesSalesDetails(SaleId);

                ViewBag.CreatedDate = model.CreatedDate;
                ViewBag.ExpiryDate = model.ExpiryDate;
                return View(model);
            }
            catch (Exception e) { }
            return null;
        }

        [HttpPost]
        public ActionResult EditCourseSales(CourseSales_V1 model)
        {
            try
            {
                bool status = UOF.ICourse.UpdateCourseSales(model);

                return RedirectToAction("CourseSalesList");
            }
            catch (Exception e) { }
            return null;
        }

        public ActionResult AddCertificate(long mid, int courseId = 0, int CertificateType = 0)
        {


            CertificateMaster model = new CertificateMaster();
            if (CertificateType == (int)EnumCertificateType.Course)
            {
                var data = UOF.ICourse.GetCertificate(mid);
                model.MemberId = data.MemberId;
                model.Name = data.Name;
                ViewBag.CertificateType = (int)EnumCertificateType.Course;
                ViewBag.courseList = UOF.ICommonLogic.GetCourseList();
            }
            else if (CertificateType == (int)EnumCertificateType.Article)
            {
                var dataMentor = UOF.ITutorial.GetAuthorsList(courseId);
                var tutoraildet = UOF.ITutorial.Get(courseId);
                model.authorsId = tutoraildet.Authors;
                model.Name = string.Join(", ", dataMentor.Select(x => x.Name));
                model.CourseName = tutoraildet.Title;
                IEnumerable<EnumMedalType> MTypelist = Enum.GetValues(typeof(EnumMedalType))
                                                     .Cast<EnumMedalType>();
                ViewBag.EnumMedalTypeList = from action in MTypelist
                                            select new SelectListItem
                                            {
                                                Text = action.ToString(),
                                                Value = ((int)action).ToString()
                                            };

                ViewBag.CertificateType = (int)EnumCertificateType.Article;
            }
            else { }

            model.CourseId = courseId;
            model.IssueDate = DateTime.Now;
            return View(model);
        }
        [HttpPost]
        public ActionResult AddCertificate(CertificateMaster model)
        {
            ViewBag.courseList = UOF.ICommonLogic.GetCourseList();
            bool data = UOF.ICourse.SaveCertificate(model);

            return RedirectToAction("CertificateList", new { mid = model.MemberId, courseId = model.CourseId, CertificateType = model.CertificateType });
        }

        public ActionResult CertificateList(long mid, int courseId = 0, int CertificateType = 0)
        {
            if (CertificateType == (int)EnumCertificateType.Course)
            {
                List<CertificateMaster> data = UOF.ICourse.GetCertificateList(mid, CertificateType);
                ViewBag.mid = mid;
                ViewBag.courseId = courseId;
                ViewBag.CertificateType = CertificateType;
                return View(data);
            }
            else if (CertificateType == (int)EnumCertificateType.Article)
            {
                List<CertificateMaster> data = UOF.ICourse.GetCertificateList(courseId, CertificateType);
                ViewBag.mid = 0;
                ViewBag.courseId = courseId;
                ViewBag.CertificateType = CertificateType;
                return View(data);

            }
            else
            {
                return null;
            }
        }
        public ActionResult CertificateDelete(long Id = 0, long mid = 0, int courseId = 0, int CertificateType = 0)
        {
            bool status = UOF.ICourse.CertificateDelete(Id);
            return RedirectToAction("CertificateList", new { mid = mid, courseId = courseId, CertificateType = CertificateType });
        }

        public ActionResult SendMailToAuthorCertificate(long Id = 0, long mid = 0, int courseId = 0, int CertificateType = 0)
        {
            try
            {
                MailClient.SendMail_ToAuthorCertificate(Id, mid, courseId, CertificateType);
            }
            catch (Exception e)
            {

            }

            return RedirectToAction("CertificateList", new { mid = mid, courseId = courseId, CertificateType = CertificateType });
        }


        public ActionResult PrintCertificate(long id = 0)
        {
            CertificateMaster data = UOF.ICourse.getCertificateView(id);
            return RedirectToAction("CertificateForPrint", data);

        }

        public ActionResult CertificateForPrint(CertificateMaster data1)
        {
            CertificateMaster data = UOF.ICourse.getCertificateView(data1.Id);
            if (data.IssueDate != null)
            {
                var d = data.IssueDate.Day;
                string d2d = d.ToString();
                string daySuffix =
                    (data.IssueDate.Day == 11 || data.IssueDate.Day == 12 || data.IssueDate.Day == 13) ? "th"
                    : (d2d == "1") ? "st"
                    : (d2d == "2") ? "nd"
                    : (d2d == "3") ? "rd"
                    : (d2d == "21") ? "st"
                    : (d2d == "31") ? "st"
                    : "th";
                data.disIssueDate = d2d + "<sup>" + daySuffix + "</sup>";
            }
            //return View(data);
            return new Rotativa.ViewAsPdf("CertificateForPrint", data)
            {
                FileName = data.Name + "_" + data.CourseName + ".pdf",
                PageMargins = new Rotativa.Options.Margins(1, 1, 0, 0),
                PageOrientation = Rotativa.Options.Orientation.Landscape,
            };
        }

        public ActionResult CertificateLists(int page = 1, string textsearch = "", int courseId = 0, string Date = "")
        {
            PagingDTO<CertificateMaster> model = new PagingDTO<CertificateMaster>();
            ViewBag.CertificateLists = "CertificateLists";
            DateTime? sDate = null;
            DateTime? eDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                sDate = Convert.ToDateTime(date[0].Trim());
                eDate = Convert.ToDateTime(date[1].Trim());
            }
            model = UOF.ICourse.GetCertificateLists(page, pageSize, textsearch, courseId, sDate, eDate);
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.courseList = courseList;
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult CertificateListDelete(long Id = 0, int courseId = 0)
        {
            bool status = UOF.ICourse.CertificateDelete(Id);
            return RedirectToAction("CertificateLists", new { courseId = courseId });
        }

        public ActionResult CourseCurriculumList(int page = 1, int CourseId = 0)
        {
            PagingDTO<MaterCourseCurriculum> model = new PagingDTO<MaterCourseCurriculum>();
            ViewBag.CourseCurriculumList = "CourseCurriculumList";
            if (CourseId != 0)
            {
                ViewBag.Coursename = UOF.ICourse.GetCourseDetails(CourseId).Name;
                ViewBag.CourseId = CourseId;
                model = UOF.ICourse.GetCourseCurriculumList(CourseId, page, pageSize);
            }
            if (model != null)
            {
                ViewBag.page = model.Page;
            }

            return View(model);
        }
        //
        public ActionResult AddCourseCurriculum(int CourseId = 0)
        {
            try
            {
                MaterCourseCurriculum model = new MaterCourseCurriculum();
                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                     .Cast<EnumCourseType>();
                ViewBag.CourseTypeList = from action in CTypelist
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };

                model.CourseId = CourseId;

                if (CourseId > 0)
                {
                    ViewBag.Coursename = UOF.ICourse.GetCourses(CourseId).Select(c => c.Name).FirstOrDefault();
                    ViewBag.SubCourseList = UOF.ICourse.GetCourseSelected(CourseId);
                }
                ViewBag.CourseId = CourseId;
                return View(model);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        [HttpPost]
        public ActionResult AddCourseCurriculum(MaterCourseCurriculum model)
        {
            try
            {
                bool stat = false;
                ViewBag.SubCourseList = UOF.ICourse.GetCourseSelected(model.CourseId);
                IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                     .Cast<EnumCourseType>();
                ViewBag.CourseTypeList = from action in CTypelist
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };
                stat = UOF.ICourse.AddCourseCurriculum(model);
                if (stat == true)
                {
                    ModelState.Clear();
                    ViewBag.Message = "Details has been saved successfully";
                    model.SubCourseId = model.SubCourseId;
                    return View(model);
                }
                else
                {
                    MaterCourseCurriculum model1 = new MaterCourseCurriculum();
                    ViewBag.Message = "";
                    return View(model1);
                }
            }
            catch (Exception ex)
            {

                return null;

            }
        }

        public JsonResult GetSubCourseDetails(int CourseId, int SubCourseId)
        {
            MaterCourseCurriculum data = new MaterCourseCurriculum();
            var msg = "";
            if (CourseId > 0 && SubCourseId > 0)
            {
                data = UOF.ICourse.GetCourseCurriculum(CourseId, SubCourseId);

                if (data != null)
                {
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
                return Json(false, JsonRequestBehavior.AllowGet);
            }
            return Json(false, msg, JsonRequestBehavior.AllowGet);
        }
        public ActionResult CourseCurriculumDelete(int CId = 0, int courseId = 0)
        {
            bool status = UOF.ICourse.CourseCurriculumDelete(CId);
            return RedirectToAction("CourseCurriculumList", new { courseId = courseId });
        }

        public ActionResult ViewCourseSales(int page = 1, int SaleId = 0, int CourseId = 0)
        {
            PagingDTO<CourseSalesList_V1> model = new PagingDTO<CourseSalesList_V1>();
            ViewBag.ViewCourseSales = "ViewCourseSales";
            model = UOF.ICourse.GetAllCourseSales(page, pageSize, SaleId);
            ViewBag.courseList = UOF.ICourse.GetCoursesExcludingSelfPaced();

            model.CourseId = CourseId;
            ViewBag.SaleId = SaleId;
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult AddCoursePriceSale(int CourseId = 0, int SaleId = 0)
        {
            try
            {
                bool status = UOF.ICourse.AddCoursePriceSale(SaleId, CourseId);
                if (status)
                    TempData["Message"] = "Added Successfully!";
                else
                    TempData["Message"] = "Already Exists!";
            }
            catch (Exception)
            {

            }
            return RedirectToAction("ViewCourseSales", new { SaleId = SaleId, CourseId = CourseId });
        }

        public ActionResult DeletePriceSale(int Id, int SaleId = 0, int page = 1)
        {
            bool status = UOF.ICourse.DeletePriceSale(Id);
            if (status == false)
            {
                TempData["Message"] = "Sorry!";
            }
            return RedirectToAction("ViewCourseSales", new { page = page, SaleId = SaleId });
        }

        public ActionResult GetDropDownByCategory(int CategoryId)
        {
            //Basant_Rep
            List<DropDownDTO> data = UOF.ICourse.GetDropDown(CategoryId, true);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetCourseArticles(int courseId)
        {
            List<DropDownDTO> data = UOF.ICourseTopic.GetCourseArticles(courseId);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

    }
}
