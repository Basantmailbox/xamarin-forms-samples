﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

using DNTShared;
using DNTShared.DTO;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class SmsController : BaseController
    {
        // GET: /Admin/Sms/
        int pageSize;
        public SmsController()
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;


        }
        public ActionResult Index()
        {
            return View();
        }
        //////////////////sms///////////////
        public ActionResult ViewSmsList(int page = 1, int? SmsTypeId = null, int? CourseId = null, string SmsType = "", int? AdminId = 0)
        {
            PagingSmsDTO<SmsDetailDTO> model = new PagingSmsDTO<SmsDetailDTO>();

            model =UOF.IEnquiry.GetAllSmsList(page, pageSize, SmsTypeId, CourseId, SmsType, AdminId);

            ViewBag.TypeIdSelectedValue = SmsTypeId;
            ViewBag.CourseIdSelectedValue = CourseId;
            if (model != null)
            {
                model.Courses = UOF.ICommonLogic.GetCourseList();
                model.smstypeList = UOF.IEnquiry.GetSmsTypeList();
                model.SalesList = UOF.IAdminMaster.GetMany(5);
                ViewBag.page = model.Page;
            }
            else
            {
                model = new PagingSmsDTO<SmsDetailDTO>();
                model.Courses = UOF.ICommonLogic.GetCourseList();
                model.smstypeList = UOF.IEnquiry.GetSmsTypeList();
                model.SalesList = UOF.IAdminMaster.GetMany(5);
                return View(model);
            }
            return View(model);

        }

        public ActionResult SmsSender()
        {
            SmsDetailDTO model = new SmsDetailDTO();
            return View(model);
        }

        [HttpPost]
        public ActionResult SmsSender(SmsDetailDTO model)
        {
            model.SalesMenId = (int)CurrentUser.UserId;
            bool status =UOF.ISms.SendSmsSenderMsg(model);
            if (status == true)
            { ViewBag.Message = "Message has been sent successfully"; }
            else
            { ViewBag.Message = "Message is not send"; }
            ModelState.Clear();
            return View();
        }
        public ActionResult DeleteBulkSms(string smsIds)
        {
            string[] ids = smsIds.Split(',');
            if (ids.Count() > 0)
            {
                UOF.ISms.DeleteBulkSms(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult SmsSettingList(int page = 1,int? CourseId=null,int ModeId = 0,int? SAdminId = 0)
        {
            try
            {
                PagingSmsDTO<SmsSettingDTO> model = UOF.ISms.GetSmsSettingDetails(page, pageSize,CourseId,ModeId, SAdminId);
                
                if (model != null)
                {
                    ViewBag.page = model.Page;
                   
                }
                ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
                model.SalesList = UOF.IAdminMaster.GetMany(5);
                ViewBag.ModeId = ModeId;
                return View(model);
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
            return View();
          
        }

        public ActionResult AddSmsSetting()
        {
            SmsSettingDTO model = new SmsSettingDTO();
            model.CourseList = UOF.ICommonLogic.GetAllCourseList();
            model.TrainingModeList = UOF.IAdminMaster.GetTrainingModeListFull();
           
            List<SelectListItem> Select_List = new List<SelectListItem>();
            model.SalesList = UOF.IAdminMaster.GetMany(5);
           // Select_List.Add(new SelectListItem() { Selected = false, Text = "Default", Value = "0" });
            foreach (var item in model.SalesList)
            {
                        SelectListItem obj = new SelectListItem()
                        {
                            Value = item.AdminId.ToString(),
                            Text = item.Name
                        };
                        Select_List.Add(obj);
              }
           
            model.SalesMaster = Select_List;
           
            return View(model);
        }
        [HttpPost]
        public ActionResult AddSmsSetting(SmsSettingDTO model, FormCollection SalesName)
        {
            try
            {
                String sId = SalesName["SalesName"];
                bool stat = UOF.ISms.AddSmsSetting(model, sId);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            SmsSettingDTO model1 = new SmsSettingDTO();
            model1.CourseList = UOF.ICommonLogic.GetAllCourseList();
            model1.TrainingModeList = UOF.IAdminMaster.GetTrainingModeListFull();
           
            List<SelectListItem> Select_List = new List<SelectListItem>();
            model1.SalesList = UOF.IAdminMaster.GetMany(5);
            // Select_List.Add(new SelectListItem() { Selected = false, Text = "Default", Value = "0" });
            foreach (var item in model1.SalesList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = item.AdminId.ToString(),
                    Text = item.Name
                };
                Select_List.Add(obj);
            }

            model1.SalesMaster = Select_List;
            
            return View(model1);
        }

        public ActionResult EditSmsSetting(int Cid,int Mid)
        {
            SmsSettingDTO model = new SmsSettingDTO();
            List<SmsSettingDTO> data = UOF.ISms.GetSmsSettingDeatil(Cid,Mid);
            model.CourseList = UOF.ICommonLogic.GetAllCourseList();
            model.CourseId = data.Select(c => c.CourseId).FirstOrDefault();
            model.TrainingModeList = UOF.IAdminMaster.GetTrainingModeListFull();
            model.TrainingModeId = data.Select(c => c.ModeId).FirstOrDefault();
            model.IsActive = data.Select(c => c.IsActive).FirstOrDefault();
             List<SelectListItem> Select_List = new List<SelectListItem>();
            List<AdminUserDTO> SalesList = UOF.IAdminMaster.GetMany(5);
            //model.SelectedList = ViewBag.SelectedList = data;
            foreach (var r in SalesList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = r.AdminId.ToString(),
                    Text = r.Name,
                    Selected = data.Where(me => me.SalesMenId == r.AdminId).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }
            model.SalesMaster = Select_List;
            return View(model);
        }
        [HttpPost]
        public ActionResult EditSmsSetting(SmsSettingDTO model, FormCollection SalesName)
        {
            try
            {
                String sId = SalesName["SalesName"];
                bool stat = UOF.ISms.UpdateSmsSetting(model, sId);
                if (stat != false)
                {
                    ModelState.Clear();
                }
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("SmsSettingList");
        }

        public ActionResult DeleteSmsSetting(int id)
        {
            bool status = UOF.ISms.deleteSmsSettingDetail(id);

            return RedirectToAction("SmsSettingList");
        }

        //public ActionResult ReceiveSms() 
        //{

        //}

    }
}
