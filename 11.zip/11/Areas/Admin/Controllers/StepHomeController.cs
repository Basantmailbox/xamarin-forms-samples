﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Web.Security;
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System.Configuration;
using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class StepHomeController : Controller
    {
        int pageSize;
        IUnitOfWork UOF;
        public StepHomeController()
        {
            UOF = new UnitOfWork();
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }

        [Authorize]
        void BindCategory()
        {
            var tblcatlist = UOF.ICategory.GetAll().OrderBy(x => x.CategoryName).ToList();
            List<StepCategory> catlist = new List<StepCategory>();

            StepCategory mobj = new StepCategory();
            mobj.CategoryID = 0;
            mobj.CategoryName = "Select";
            catlist.Add(mobj);
            foreach (var item in tblcatlist)
            {
                mobj = new StepCategory();
                mobj.CategoryID = item.CategoryID;
                mobj.CategoryName = item.CategoryName;

                catlist.Add(mobj);
            }
            ViewBag.Categories = catlist;
        }

        List<StepSubCategory> BindSubCategory(int? CatId)
        {
            var tblcatlist = UOF.IStepSubCategory.GetByCategoryId(CatId);
            List<StepSubCategory> catlist = new List<StepSubCategory>();

            StepSubCategory mobj = new StepSubCategory();
            mobj.SubCategoryID = 0;
            mobj.SubCategoryName = "Select";
            catlist.Add(mobj);
            foreach (var item in tblcatlist)
            {
                mobj = new StepSubCategory();
                mobj.SubCategoryID = item.SubCategoryID;
                mobj.SubCategoryName = item.SubCategoryName;

                catlist.Add(mobj);
            }
            ViewBag.SubCategories = catlist;
            return catlist;
        }

        List<StepTutorialSubCategoryDTO> BindTutorialSubCategory(int? CatId, bool isAddTutorial = true)
        {
            List<int?> subcat = UOF.IStepTutorial.GetByCategoryId(CatId);

            var tblcatlist = UOF.IStepTutorialSubCategories.GetByCategoryId(CatId);

            List<StepTutorialSubCategoryDTO> catlist = new List<StepTutorialSubCategoryDTO>();

            StepTutorialSubCategoryDTO mobj = new StepTutorialSubCategoryDTO();
            mobj.TutorialSubCategoryID = 0;
            mobj.TutorialSubCategoryName = "Select";
            catlist.Add(mobj);
            if (isAddTutorial)
            {
                foreach (var item in tblcatlist)
                {
                    if (subcat.Contains(item.TutorialSubCategoryID))
                    {
                        mobj = new StepTutorialSubCategoryDTO();
                        mobj.TutorialSubCategoryID = item.TutorialSubCategoryID;
                        mobj.TutorialSubCategoryName = item.TutorialSubCategoryName;

                        catlist.Add(mobj);
                    }
                }
            }
            else
            {
                foreach (var item in tblcatlist)
                {
                    mobj = new StepTutorialSubCategoryDTO();
                    mobj.TutorialSubCategoryID = item.TutorialSubCategoryID;
                    mobj.TutorialSubCategoryName = item.TutorialSubCategoryName;

                    catlist.Add(mobj);
                }
            }
            ViewBag.TutorialSubCategories = catlist;
            return catlist;
        }

        [Authorize]
        List<StepTutorialDTO> BindPost(int? cat)
        {
            List<StepTutorialDTO> tutlist = new List<StepTutorialDTO>();
            var tblcatlist = UOF.IStepTutorial.GetAll().Where(x => x.CategoryID == cat).Select(m => m).ToList().OrderBy(m => m.Title);

            StepTutorialDTO mobj = new StepTutorialDTO();
            mobj.ID = string.Empty;
            mobj.Title = "Select";
            tutlist.Add(mobj);

            foreach (var item in tblcatlist)
            {
                mobj = new StepTutorialDTO();
                mobj.ID = item.ID;
                mobj.Title = item.Title;

                tutlist.Add(mobj);
            }
            ViewBag.Tutorials = tutlist;
            return tutlist;
        }

        [Authorize]
        public JsonResult GetSubCategoryKeywords(int? SubCategoryId)
        {
            try
            {
                if (SubCategoryId != 0)
                {
                    var data = UOF.IStepSubCategory.GetAll().Where(c => c.SubCategoryID == SubCategoryId).Select(c => c.MetaKeywords).FirstOrDefault();
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        [Authorize]
        public JsonResult GetSubCategory(int? CategoryId)
        {
            try
            {
                if (CategoryId != 0)
                {
                    var data = BindSubCategory(CategoryId);
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        [Authorize]
        public JsonResult GetAddTutorialSubCategory(int? CategoryId)
        {
            try
            {
                if (CategoryId != 0)
                {
                    var data = BindTutorialSubCategory(CategoryId, false);
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                var str = ex.Message;
            }
            List<StepTutorialSubCategoryDTO> catlist = new List<StepTutorialSubCategoryDTO>();
            return Json(catlist);
        }

        [Authorize]
        public JsonResult GetTutorialSubCategory(int? CategoryId)
        {
            try
            {
                if (CategoryId != 0)
                {
                    var data = BindTutorialSubCategory(CategoryId, false);
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                var str = ex.Message;
            }
            List<StepTutorialSubCategoryDTO> catlist = new List<StepTutorialSubCategoryDTO>();
            return Json(catlist);
        }

        public JsonResult GetQuestion(int? QuestionId)
        {
            try
            {
                if (QuestionId != 0)
                {
                    var tutorial = UOF.IStepQuestionsAnswer.GetByQuestionId(QuestionId).Select(m => new { m.Question, m.Answer }).ToList();
                    return Json(tutorial, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        public JsonResult GetQuestionList(int? CategoryId)
        {
            try
            {
                if (CategoryId != 0)
                {
                    var data = BindQuestion(CategoryId);
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        [Authorize]
        public ActionResult AddTutorial()
        {
            BindCategory();
            BindTutorialSubCategory(null);
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddTutorial = "AddTutorial";
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddTutorial(StepTutorialDTO tutorial)
        {
            try
            {
                tutorial.ID = Utility.GenerateID();
                ModelState.Remove("ID");

                if (ModelState.IsValid && this.User.Identity.Name != null)
                {
                    StepTutorial mobj = new StepTutorial();

                    string CatName = UOF.IStepCategory.GetByCategoryID(tutorial.CategoryID).Select(m => m.CategoryName).SingleOrDefault();

                    string Desc;
                    mobj.ID = tutorial.ID;
                    mobj.CategoryID = tutorial.CategoryID;
                    mobj.SubCategoryID = tutorial.SubCategoryID;
                    mobj.ShortDescription = tutorial.ShortDescription;

                    Desc = tutorial.Description.Replace("\r\n", "<br>");
                    Desc = Regex.Replace(Desc, @"\s+", " ");
                    Desc = Desc.Replace("<br>", "\r\n");
                    mobj.Description = Desc;
                    mobj.DomainName = tutorial.DomainName;
                    mobj.PostedBy = this.User.Identity.Name;
                    mobj.PostedDate = tutorial.PostedDate;
                    mobj.Title = tutorial.Title;
                    mobj.Version = tutorial.Version;
                    mobj.MetaKeywords = tutorial.MetaKeywords;
                    mobj.TotalViews = 0;

                    UOF.IStepTutorial.Add(mobj);
                    UOF.SaveChanges();

                    ViewBag.Message = "Tutorial has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            BindCategory();
            BindTutorialSubCategory(null);
            //ViewBag.SubCategoryId = tutorial.CategoryID;
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddTutorial = "AddTutorial";
            return View();
        }

        [Authorize]
        public ActionResult EditTutorial()
        {
            BindCategory();
            BindPost(null);
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditTutorial = "EditTutorial";

            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditTutorial(StepTutorialDTO tutorial)
        {
            try
            {
                if (this.User.Identity.Name != null)
                {
                    StepTutorial mobj = UOF.IStepTutorial.GetDetailById(tutorial.ID);//.FirstOrDefault();
                    string Desc;

                    if (mobj.CategoryID > 0)
                    {
                        string CatName = UOF.ICategory.GetCategoryById(mobj.CategoryID).ToString();
                        mobj.ShortDescription = tutorial.ShortDescription;

                        Desc = tutorial.Description.Replace("\r\n", "<br>");
                        Desc = Regex.Replace(Desc, @"\s+", " ");
                        Desc = Desc.Replace("<br>", "\r\n");
                        mobj.Description = Desc;
                        mobj.PostedDate = tutorial.PostedDate;
                        mobj.UpdatedDate = DateTime.Now; //tutorial.UpdatedDate;
                        mobj.Title = tutorial.Title;
                        mobj.Version = tutorial.Version;
                        mobj.DomainName = tutorial.DomainName;
                        mobj.MetaKeywords = tutorial.MetaKeywords;
                        if (mobj.PostedBy == null || mobj.PostedBy == "")
                            mobj.PostedBy = this.User.Identity.Name;

                        UOF.SaveChanges();

                        ViewBag.Message = "Tutorial has been updated successfully";
                        ModelState.Clear();
                    }
                }
                else
                {
                    return RedirectToAction("Index", "Author");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                BindCategory();
                BindPost(tutorial.CategoryID);
            }
            BindCategory();
            ViewBag.CategoryId = tutorial.CategoryID;
            BindPost(tutorial.CategoryID);
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditTutorial = "EditTutorial";
            return View();
        }

        [Authorize]
        public JsonResult GetTutorial(string mID)
        {
            try
            {
                if (mID != "0")
                {
                    var tutorial = UOF.IStepTutorial.GetById(mID).Select(m => new { Description = m.Description, m.MetaKeywords, m.ShortDescription, m.Title, m.Version, m.DomainName }).ToList();
                    return Json(tutorial, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        public JsonResult GetTutorialList(int? CategoryId)
        {
            try
            {
                if (CategoryId != 0)
                {
                    var data = BindPost(CategoryId);
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            List<StepTutorialDTO> catlist = new List<StepTutorialDTO>();
            return Json(catlist);
        }

        [Authorize]
        public ActionResult AddQuestion()
        {
            BindCategory();
            BindSubCategory(null);
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddQuestion = "AddQuestion";
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddQuestion(StepQuestionDTO tutorial)
        {
            try
            {
                ModelState.Remove("QuestionID");
                if (ModelState.IsValid && this.User.Identity.Name != null)
                {
                    StepQuestionsAnswers mobj = new StepQuestionsAnswers();
                    string CatName = UOF.IStepCategory.GetByCategoryID(tutorial.CategoryID).Select(m => m.CategoryName).SingleOrDefault();

                    if (CatName.ToLower() == "c#")
                        CatName = "csharp";
                    else if (CatName.ToLower() == "c# windows apps")
                        CatName = "cswinapps";

                    string Desc;

                    mobj.CategoryID = tutorial.CategoryID;
                    mobj.Question = tutorial.Question;
                    mobj.ID = Utility.GenerateID();
                    mobj.SubCategoryID = tutorial.SubCategoryID;

                    Desc = tutorial.Answer.Replace("\r\n", "<br>");
                    Desc = Regex.Replace(Desc, @"\s+", " ");
                    Desc = Desc.Replace("<br>", "\r\n");
                    mobj.Answer = Desc;

                    mobj.PostedBy = this.User.Identity.Name;
                    mobj.PostedDate = tutorial.PostedDate;
                    mobj.TotalViews = 0;
                    UOF.IStepQuestionsAnswer.Add(mobj);
                    UOF.SaveChanges();

                    ViewBag.Message = "Question has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            BindCategory();
            BindSubCategory(tutorial.CategoryID);
            ViewBag.CategoryId = tutorial.CategoryID;
            ViewBag.SubCategoryId = tutorial.SubCategoryID;
            ViewBag.AddQuestion = "AddQuestion";
            return View();
        }

        private List<StepQuestionDTO> BindQuestion(int? CatId)
        {
            var data = UOF.IStepQuestionsAnswer.GetByCategoryId(CatId).OrderBy(x => x.Question);
            List<StepQuestionDTO> queslist = new List<StepQuestionDTO>();

            StepQuestionDTO mobj = new StepQuestionDTO();
            mobj.QuestionID = 0;
            mobj.Question = "Select";
            queslist.Add(mobj);
            foreach (var item in data)
            {
                mobj = new StepQuestionDTO();
                mobj.QuestionID = item.QuestionID;
                mobj.Question = item.Question;

                queslist.Add(mobj);
            }
            ViewBag.Questions = queslist;
            return queslist;
        }


        [Authorize]
        public ActionResult EditQuestion()
        {
            BindCategory();
            BindQuestion(null);
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditQuestion = "EditQuestion";

            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditQuestion(StepQuestionDTO tutorial)
        {
            try
            {
                if (this.User.Identity.Name != null)
                {
                    StepQuestionsAnswers mobj = UOF.IStepQuestionsAnswer.GetByQuestionId(tutorial.QuestionID).FirstOrDefault();
                    string Desc;

                    if (mobj.CategoryID > 0)
                    {
                        string CatName = UOF.IStepCategory.GetByCategoryID(mobj.CategoryID).Select(m => m.CategoryName).SingleOrDefault();

                        if (CatName.ToLower() == "c#")
                            CatName = "csharp";
                        else if (CatName.ToLower() == "c# windows apps")
                            CatName = "cswinapps";

                        mobj.Question = tutorial.Question;
                        //mobj.SubCategoryID = tutorial.SubCategoryID;

                        Desc = tutorial.Answer.Replace("\r\n", "<br>");
                        Desc = Regex.Replace(Desc, @"\s+", " ");
                        Desc = Desc.Replace("<br>", "\r\n");
                        mobj.Answer = Desc;

                        mobj.PostedDate = tutorial.PostedDate;
                        mobj.UpdatedDate = DateTime.Now; //tutorial.UpdatedDate;

                        if (mobj.PostedBy == null || mobj.PostedBy == "")
                            mobj.PostedBy = this.User.Identity.Name;

                        UOF.SaveChanges();

                        ViewBag.Message = "Question has been updated successfully";
                        ModelState.Clear();
                    }
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            BindCategory();
            ViewBag.CategoryId = tutorial.CategoryID;
            BindQuestion(tutorial.CategoryID);
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditQuestion = "EditQuestion";
            return View();
        }

        public ActionResult ViewQuery()
        {
            ViewBag.ViewQuery = "ViewQuery";

            List<QueryDTO> data = new List<QueryDTO>();

            const int pageSize = 100;

            data = UOF.IQuery.GetAll().ToList().OrderByDescending(m => m.SubmitDate).Take(pageSize).Select(x => new QueryDTO
            {
                Name = x.Name,
                EmailID = x.EmailID,
                ContactNo = x.ContactNo,
                City = x.City,
                // Subject = x.Subject,
                //CourseName = x.Name,
                //TrainingModeName = x.Name,
                Message = x.Message,
                SubmitDate = x.SubmitDate
            }).ToList();

            PagingDTO<QueryDTO> model = new PagingDTO<QueryDTO>();

            model.Data = data;

            return View(model);

        }

        [Authorize]
        public ActionResult ViewCategory()
        {
            ViewBag.ViewCategory = "ViewCategory";
            BindCategory();
            return View();
        }

        [Authorize]
        public JsonResult GetCategory(int mID)
        {
            try
            {
                if (mID != 0)
                {
                    var category = UOF.IStepCategory.GetByCategoryID(mID).Select(m => new { m.CategoryID, m.CategoryName, m.TutorialTitle, m.TutorialUrl, m.TutorialMetaKeywords, m.TutorialMetaDescription, m.QuestionTitle, m.QuestionUrl, m.QuestionMetaKeywords, m.QuestionMetaDescription, m.AnswerUrl, m.Logo }).ToList();
                    return Json(category, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        
        [Authorize]
        public ActionResult ViewSubCategory()
        {
            ViewBag.ViewSubCategory = "ViewSubCategory";
            BindSubCategory(null);
            BindCategory();
            return View();
        }

        [Authorize]
        [HttpPost, ValidateInput(false)]
        public ActionResult ViewSubCategory(StepSubCategory mSubcat)
        {
            try
            {
                ViewBag.ViewSubCategory = "ViewSubCategory";
                if (mSubcat.SubCategoryName != null && mSubcat.SubCategoryID != 0)
                {
                    var q = (from tbl in UOF.IStepSubCategory.GetAll()
                             where tbl.SubCategoryID == mSubcat.SubCategoryID
                             select tbl).FirstOrDefault();
                    q.SubCategoryName = mSubcat.SubCategoryName;
                    q.CategoryID = mSubcat.CategoryID;
                    q.MetaKeywords = mSubcat.MetaKeywords;
                    UOF.SaveChanges();

                    ModelState.Clear();
                    ViewBag.Message = "SubCategory has been updated successfully !!";

                }
                else if (mSubcat.SubCategoryName != null && mSubcat.SubCategoryID == 0)
                {
                    StepSubCategory tbl = new StepSubCategory();
                    tbl.SubCategoryName = mSubcat.SubCategoryName;
                    tbl.CategoryID = mSubcat.CategoryID;
                    tbl.MetaKeywords = mSubcat.MetaKeywords;
                    UOF.IStepSubCategory.Add(tbl);
                    UOF.SaveChanges();

                    ModelState.Clear();
                    ViewBag.Message = "SubCategory has been added successfully and SubCategory ID is : " + tbl.SubCategoryID.ToString();

                }
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }
            ViewBag.CategoryId = mSubcat.CategoryID;
            BindCategory();
            BindSubCategory(mSubcat.CategoryID);
            ViewBag.ViewSubCategory = "ViewSubCategory";
            return View();
        }

        [Authorize]
        public ActionResult ViewTutorialSubCategory()
        {
            ViewBag.ViewTutorialSubCategory = "ViewTutorialSubCategory";
            BindTutorialSubCategory(null, false);
            BindCategory();
            return View();
        }

        [Authorize]
        [HttpPost, ValidateInput(false)]
        public ActionResult ViewTutorialSubCategory(StepTutorialSubCategoryDTO mSubcat)
        {
            try
            {
                ViewBag.ViewTutorialSubCategory = "ViewTutorialSubCategory";
                if (mSubcat.TutorialSubCategoryName != null && mSubcat.TutorialSubCategoryID != 0)
                {
                    var q = (from tbl in UOF.IStepTutorialSubCategories.GetAll()
                             where tbl.TutorialSubCategoryID == mSubcat.TutorialSubCategoryID
                             select tbl).FirstOrDefault();
                    q.TutorialSubCategoryName = mSubcat.TutorialSubCategoryName;
                    q.CategoryID = mSubcat.CategoryID;

                    UOF.SaveChanges();

                    ModelState.Clear();
                    ViewBag.Message = "SubCategory has been updated successfully !!";

                }
                else if (mSubcat.TutorialSubCategoryName != null && mSubcat.TutorialSubCategoryID == 0)
                {
                    StepTutorialSubCategory tbl = new StepTutorialSubCategory();
                    tbl.TutorialSubCategoryName = mSubcat.TutorialSubCategoryName;
                    tbl.CategoryID = mSubcat.CategoryID;

                    UOF.IStepTutorialSubCategories.Add(tbl);
                    UOF.SaveChanges();

                    ModelState.Clear();
                    ViewBag.Message = "SubCategory has been added successfully and SubCategory ID is : " + tbl.TutorialSubCategoryID.ToString();

                }
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }
            ViewBag.CategoryId = mSubcat.CategoryID;
            BindCategory();
            BindTutorialSubCategory(mSubcat.CategoryID, false);
            ViewBag.ViewTutorialSubCategory = "ViewSubCategory";
            return View();
        }



        //////////////////// by amit////////////////

        public ActionResult QuestionList(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.QuestionList = "QuestionList";
            PagingDTO<StepQuestionDTO> model = UOF.ITutorial.GetAllQuestionList(page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult CategoryList(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.StepCategoryList = "StepCategoryList";
            PagingDTO<StepCategory> model = UOF.ITutorial.GetAllStepCategoryList(page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        //[Authorize]
        //public ActionResult AddCategory()
        //{
        //    ViewBag.AddCategory = "AddCategory";
           
        //    return View();
        //}
        //[Authorize]
        //[HttpPost, ValidateInput(false)]
        //public ActionResult AddCategory(StepCategoryViewModel mcat)
        //{
        //    try
        //    {
        //        ViewBag.AddCategory = "AddCategory";
        //            StepCategory tbl = new StepCategory();
        //           // tbl.CategoryID = mobjentity.StepCategories.Count() + 1;
        //            tbl.CategoryName = mcat.CategoryName;
        //            tbl.TutorialTitle = mcat.TutorialTitle;
        //            tbl.TutorialUrl = mcat.TutorialUrl;
        //            tbl.TutorialMetaKeywords = mcat.TutorialMetaKeywords;
        //            tbl.TutorialMetaDescription = mcat.TutorialMetaDescription;

        //            tbl.QuestionTitle = mcat.QuestionTitle;
        //            tbl.QuestionUrl = mcat.QuestionUrl;
        //            tbl.QuestionMetaKeywords = mcat.QuestionMetaKeywords;
        //            tbl.QuestionMetaDescription = mcat.QuestionMetaDescription;

        //            tbl.AnswerUrl = mcat.AnswerUrl;

        //            mobjentity.StepCategories.Add(tbl);
        //            mobjentity.SaveChanges();

        //            ModelState.Clear();
        //            ViewBag.Message = "Category has been added successfully and Category ID is : " + tbl.CategoryID.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        ModelState.Clear();
        //        ViewBag.Message = "There some internal error";
        //    }
           
        //    return View();

        //}

        //[Authorize]
        //public ActionResult EditCategory(int id)
        //{
        //    ViewBag.CategoryID = id;
        //    BindCategory();
        //    ViewBag.AddCategory = "EditCategory";

        //    if (id >0)
        //    {
        //        var cat = mobjentity.StepCategories.Where(m => m.CategoryID == id).ToList();


        //        foreach (var item in cat)
        //        {
        //            StepCategoryViewModel model = new StepCategoryViewModel();
        //            model.CategoryID = item.CategoryID;
        //            model.CategoryName = item.CategoryName;
        //            model.TutorialTitle = item.TutorialTitle;
        //            model.TutorialUrl = item.TutorialUrl;
        //            model.TutorialMetaKeywords = item.TutorialMetaKeywords;
        //            model.TutorialMetaDescription = item.TutorialMetaDescription;
        //            model.QuestionTitle = item.QuestionTitle;
        //            model.QuestionUrl = item.QuestionUrl;
        //            model.QuestionMetaKeywords = item.QuestionMetaKeywords;
        //            model.QuestionMetaDescription = item.QuestionMetaDescription;
        //            model.Logo = item.Logo;
        //            model.AnswerUrl = item.AnswerUrl;
        //            return View(model);
        //        }
        //    }
        //    return View();
        //}
        //[Authorize]
        //[HttpPost, ValidateInput(false)]
        //public ActionResult EditCategory(StepCategoryViewModel mcat)
        //{
        //    try
        //    {
        //        ViewBag.EditCategory = "EditCategory";
        //        var q = (from tbl in mobjentity.StepCategories
        //                 where tbl.CategoryID == mcat.CategoryID
        //                 select tbl).FirstOrDefault();
                
        //        q.CategoryName = mcat.CategoryName;
        //        q.TutorialTitle = mcat.TutorialTitle;
        //        q.TutorialUrl = mcat.TutorialUrl;
        //        q.TutorialMetaKeywords = mcat.TutorialMetaKeywords;
        //        q.TutorialMetaDescription = mcat.TutorialMetaDescription;
                
        //        q.QuestionTitle = mcat.QuestionTitle;
        //        q.QuestionUrl = mcat.QuestionUrl;
        //        q.QuestionMetaKeywords = mcat.QuestionMetaKeywords;
        //        q.QuestionMetaDescription = mcat.QuestionMetaDescription;
                
        //        q.AnswerUrl = mcat.AnswerUrl;

        //        mobjentity.SaveChanges();

        //        ModelState.Clear();
        //        ViewBag.Message = "Category has been updated successfully";
        //        return RedirectToAction("CategoryList");
        //    }
        //    catch (Exception ex)
        //    {
        //        ModelState.Clear();
        //        ViewBag.Message = "There some internal error";
        //    }

        //    return View();

        //}

        public ActionResult TutorialSubCategoryList(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.TutorialSubCategoryList = "TutorialSubCategoryList";
            PagingDTO<StepTutorialSubCategoryDTO> model = UOF.ITutorial.GetAllStepTutorialSubCategoryList(page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        
        [Authorize]
        public ActionResult EditTutorialSubCategory(int id)
        {
            ViewBag.CategoryID = id;
            //BindTutorialSubCategory(null, false);
            //BindCategory();
            ViewBag.TutorialSubCategoryList = "TutorialSubCategoryList";

            if (id >0)
            {
                var data = (from tsubcat in UOF.IStepTutorialSubCategories.GetAll()
                            join cat in UOF.IStepCategory.GetAll() on tsubcat.CategoryID equals cat.CategoryID where tsubcat.TutorialSubCategoryID==id
                 select new
                 {
                     tsubcat.TutorialSubCategoryID,
                     tsubcat.TutorialSubCategoryName,
                     cat.CategoryID,
                     cat.CategoryName,
                    
                 });


                foreach (var item in data)
                {
                    StepTutorialSubCategoryDTO model = new StepTutorialSubCategoryDTO();
              
                    model.TutorialSubCategoryName = item.TutorialSubCategoryName;
                    model.TutorialSubCategoryID = item.TutorialSubCategoryID;
                    model.CategoryID = item.CategoryID;
                    model.CategoryName = item.CategoryName;
                    return View(model);
                }
            }
            return View();
        }

        [Authorize]
        [HttpPost, ValidateInput(false)]
        public ActionResult EditTutorialSubCategory(StepTutorialSubCategoryDTO tcat)
        {
            try
            {
                ViewBag.TutorialSubCategoryList = "TutorialSubCategoryList";
                var q = (from tbl in UOF.IStepTutorialSubCategories.GetAll()
                         where tbl.TutorialSubCategoryID == tcat.TutorialSubCategoryID
                         select tbl).FirstOrDefault();

             
                q.TutorialSubCategoryName = tcat.TutorialSubCategoryName;
                           
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "Tutorial Sub Category has been updated successfully";
                return RedirectToAction("TutorialSubCategoryList");
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }

            return View();

        }


        public ActionResult StepSubCategoriesList(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.StepSubCategoriesList = "StepSubCategoriesList";
            PagingDTO<StepSubCategory> model = UOF.ITutorial.GetAllStepSubCategoryList(page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        
         [Authorize]
        public ActionResult EditStepSubCategories(int id)
        {
           // ViewBag.CategoryID = id;
            //BindTutorialSubCategory(null, false);
            //BindCategory();
            ViewBag.StepSubCategoriesList = "StepSubCategoriesList";

            if (id >0)
            {
                var data = (from tsubcat in UOF.IStepSubCategory.GetAll()
                            join cat in UOF.IStepCategory.GetAll() on tsubcat.CategoryID equals cat.CategoryID where tsubcat.SubCategoryID==id
                 select new
                 {
                     tsubcat.SubCategoryID,
                     tsubcat.SubCategoryName,
                     tsubcat.MetaKeywords,
                     cat.CategoryID,
                     cat.CategoryName,
                    
                 });


                foreach (var item in data)
                {
                    StepSubCategory model = new StepSubCategory();
              
                    model.SubCategoryID = item.SubCategoryID;
                    model.SubCategoryName = item.SubCategoryName;
                    model.CategoryID = item.CategoryID;
                    model.CategoryName = item.CategoryName;
                    model.MetaKeywords = item.MetaKeywords;
                    return View(model);
                }
            }
            return View();
        }

        [Authorize]
        [HttpPost, ValidateInput(false)]
         public ActionResult EditStepSubCategories(StepSubCategory tcat)
        {
            try
            {
                ViewBag.StepSubCategoriesList = "StepSubCategoriesList";
                var q = (from tbl in UOF.IStepSubCategory.GetAll()
                         where tbl.SubCategoryID == tcat.SubCategoryID
                         select tbl).FirstOrDefault();

             
                q.SubCategoryName = tcat.SubCategoryName;
                q.MetaKeywords = tcat.MetaKeywords;        
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "Sub Category has been updated successfully";
                return RedirectToAction("StepSubCategoriesList");
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }

            return View();

        }

        public ActionResult TutorialList(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.StepTutorialList = "StepTutorialList";
            PagingDTO<StepTutorialDTO> model = UOF.ITutorial.GetAllStepTutorialList(page, pageSize);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
    }
}

