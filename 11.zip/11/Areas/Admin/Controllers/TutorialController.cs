﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Web.Security;
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System.IO;
using System.Configuration;

using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;
using DNTWebUI.Models;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class TutorialController : BaseController
    {
        int pageSize;
        public string ImgCloudPath = "";
        static CloudBlobClient blobClient;
        static CloudBlobContainer blobContainer;
        CloudStorageAccount storageAccount;
        public TutorialController()

        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }


        public ActionResult Index()
        {
            return View();
        }

        void BindCategory()
        {
            ViewBag.Categories = UOF.ICategory.GetCategories();
        }


        void BindEventType()
        {
            //Basant_Rep
            var tbleventtypelist = UOF.IEventTypes.GetAll().OrderBy(x => x.EventTypeName);

            List<EventType> eventTypeList = new List<EventType>();

            EventType mobj = new EventType();
            mobj.EventTypeId = 0;
            mobj.EventTypeName = "Select";
            eventTypeList.Add(mobj);

            foreach (var item in tbleventtypelist)
            {
                mobj = new EventType();
                mobj.EventTypeId = item.EventTypeId;
                mobj.EventTypeName = item.EventTypeName;

                eventTypeList.Add(mobj);
            }
            ViewBag.EventType = eventTypeList;
        }


        [Authorize]
        void BindPost(string Name)
        {

            List<TutorialDTO> tutlist = new List<TutorialDTO>();
            if (Name != "Shailendra Chauhan")
            {
                //Basant_Rep mobjentity.Tutorials.Where(x => x.PostedBy == Name).Select(m => m).ToList().OrderBy(m => m.Title);
                var tblcatlist = UOF.ITutorial.GetMany(Name);

                TutorialDTO mobj = new TutorialDTO();
                mobj.ID = "0";
                mobj.Title = "Select";
                tutlist.Add(mobj);

                foreach (var item in tblcatlist)
                {
                    mobj = new TutorialDTO();
                    mobj.ID = item.ID;
                    mobj.Title = item.Title;

                    tutlist.Add(mobj);
                }
                ViewBag.Tutorials = tutlist;
            }
            else
            {
                //Basant_Rep  mobjentity.Tutorials.Select(m => m).ToList().OrderBy(m => m.Title);
                var tblcatlist = UOF.ITutorial.GetAll().OrderBy(m => m.Title);
                TutorialDTO mobj = new TutorialDTO();
                mobj.ID = "0";
                mobj.Title = "Select";
                tutlist.Add(mobj);

                foreach (var item in tblcatlist)
                {
                    mobj = new TutorialDTO();
                    mobj.ID = item.ID;
                    mobj.Title = item.Title;

                    tutlist.Add(mobj);
                }
                ViewBag.Tutorials = tutlist;
            }
        }

        [Authorize]
        public ActionResult AddTutorial()
        {

            BindCategory();
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddTutorial = "AddTutorial";
            TutorialDTO Model = new TutorialDTO();
            List<MentorMaster> AuthorMasterList = UOF.ICourse.GetMentorMasterList();
            Model.AuthorMasterList = AuthorMasterList;

            IEnumerable<EnumArticleType> ATypelist = Enum.GetValues(typeof(EnumArticleType))
                                                    .Cast<EnumArticleType>();
            ViewBag.ArticleTypeList = from action in ATypelist
                                      select new SelectListItem
                                      {
                                          Text = action.ToString(),
                                          Value = ((int)action).ToString()
                                      };

            IEnumerable<EnumArticleLevel> ALTypelist = Enum.GetValues(typeof(EnumArticleLevel))
                                                    .Cast<EnumArticleLevel>();
            ViewBag.ArticleLevelList = from action in ALTypelist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
            Model.Sequence = UOF.IAdminMaster.GetMaxSequence(1);
            return View(Model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddTutorial(TutorialDTO tutorial, string[] Authors)
        {
            try
            {
                if (this.CurrentUser.Name != null)
                {
                    bool isArticleURLAlreadyExists = UOF.ITutorial.Check_ArticleURL_Already_Exists(tutorial.ArticleUrl, 1);
                    if (isArticleURLAlreadyExists == true)
                    {
                        ViewBag.ArticleURL = "Article Url already exists. Please enter again.";
                        BindCategory();
                        return View(tutorial);
                    }

                    Tutorial mobj = new Tutorial();
                    //Basant_Rep .Where(m => m.CategoryID == tutorial.CategoryID).Select(m => m.CategoryName).SingleOrDefault();
                    string CatName = UOF.ICategory.Get(tutorial.CategoryID).CategoryName;

                    if (CatName.ToLower() == "c#")
                        CatName = "csharp";
                    else if (CatName.ToLower() == "c# windows apps")
                        CatName = "cswinapps";
                    
                    string Desc;
                    mobj.ID = Utility.GenerateID();
                    mobj.CategoryID = tutorial.CategoryID;
                    mobj.IsActive = tutorial.IsActive;
                    mobj.ShortDescription = tutorial.ShortDescription;
                    mobj.Authors = string.Join(",", Authors);
                    Desc = tutorial.Description.Replace("\r\n", "<br>");
                    Desc = Regex.Replace(Desc, @"\s+", " ");
                    Desc = Desc.Replace("<br>", "\r\n");
                    mobj.Description = Desc;
                    mobj.DomainName = tutorial.DomainName;
                    mobj.PostedBy = this.User.Identity.Name;
                    mobj.PostedDate = tutorial.PostedDate;
                    mobj.TutorialImage = tutorial.TutorialImage;
                    mobj.ShortTitle = tutorial.ShortTitle;
                    mobj.Title = tutorial.Title;
                    mobj.SchemaSEO = tutorial.SchemaSEO;
                    mobj.Version = tutorial.Version;
                    mobj.Tags = tutorial.Tags;
                    mobj.ArticleUrl = tutorial.ArticleUrl;
                    mobj.SourceCodeUrl = tutorial.SourceCodeUrl;
                    mobj.MetaKeywords = tutorial.MetaKeywords;

                    mobj.Url = "https://www.dotnettricks.com/learn/" + CatName.ToLower().Replace(" ", string.Empty).Replace(".", string.Empty);
                    mobj.TotalViews = 0;

                    mobj.ArticleLevel = tutorial.ArticleLevel;
                    mobj.ArticleType = tutorial.ArticleType;
                    mobj.Sequence = tutorial.Sequence;

                    UOF.ITutorial.Add(mobj);
                    UOF.SaveChanges();
                    //if (mobj.TutorialID != 0)
                    //{
                    //    string TUrl = ""; string Tfile = ""; var Textn = ""; string Tpath = ""; string FlagT = "";
                    //    if (tutorial.TImage != null && tutorial.TImage.ContentLength > 0)
                    //    {
                    //        FlagT = "T";
                    //        var fileName = Path.GetFileName(tutorial.TImage.FileName);  
                    //        Textn = Path.GetExtension(tutorial.TImage.FileName); 
                    //        string name = Path.GetFileNameWithoutExtension(fileName);
                    //    }
                    //    string _tutorialImageFolderLocation;
                    //    _tutorialImageFolderLocation = ConfigurationManager.AppSettings["ArticleImageFolder"].ToString();
                    //    if (FlagT == "T")
                    //    {
                    //        Tfile = Regex.Replace(tutorial.ShortTitle, "[^0-9a-zA-Z]+", "").ToLower() + "-header" + Textn; //
                    //        Tpath = Path.Combine(Server.MapPath(_tutorialImageFolderLocation), Tfile);
                    //        TUrl = _tutorialImageFolderLocation + Tfile;
                    //    }
                    //    string directoryPath = Server.MapPath(string.Format("~/{0}/", _tutorialImageFolderLocation));
                    //    if (!Directory.Exists(directoryPath))
                    //    {
                    //        Directory.CreateDirectory(directoryPath);
                    //    }
                    //    mobj.TutorialImage = TUrl;
                    //    if (mobj.TutorialImage != null)
                    //    {
                    //        if (TUrl != "")
                    //        {
                    //            tutorial.TImage.SaveAs(Tpath);
                    //        }
                    //        ModelState.Clear();
                    //    }
                    //}
                    //UOF.SaveChanges();
                    ViewBag.Message = "Tutorial has been saved successfully";
                    ModelState.Clear();
                    IEnumerable<EnumArticleType> ATypelist = Enum.GetValues(typeof(EnumArticleType))
                                                    .Cast<EnumArticleType>();
                    ViewBag.ArticleTypeList = from action in ATypelist
                                              select new SelectListItem
                                              {
                                                  Text = action.ToString(),
                                                  Value = ((int)action).ToString()
                                              };

                    IEnumerable<EnumArticleLevel> ALTypelist = Enum.GetValues(typeof(EnumArticleLevel))
                                                            .Cast<EnumArticleLevel>();
                    ViewBag.ArticleLevelList = from action in ALTypelist
                                               select new SelectListItem
                                               {
                                                   Text = action.ToString(),
                                                   Value = ((int)action).ToString()
                                               };
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;

            }
            BindCategory();
            TutorialDTO Model = new TutorialDTO();
            List<MentorMaster> AuthorMasterList = UOF.ICourse.GetMentorMasterList();
            Model.AuthorMasterList = AuthorMasterList;
            ViewBag.AddTutorial = "AddTutorial";
            return View(Model);
        }

        [Authorize]
        public ActionResult EditTutorial(String id)
        {
            ViewBag.id = id;
            BindCategory();
            ViewBag.EditTutorial = "EditTutorial";
            IEnumerable<EnumArticleType> ATypelist = Enum.GetValues(typeof(EnumArticleType))
                                                    .Cast<EnumArticleType>();
            ViewBag.ArticleTypeList = from action in ATypelist
                                      select new SelectListItem
                                      {
                                          Text = action.ToString(),
                                          Value = ((int)action).ToString()
                                      };

            IEnumerable<EnumArticleLevel> ALTypelist = Enum.GetValues(typeof(EnumArticleLevel))
                                                    .Cast<EnumArticleLevel>();
            ViewBag.ArticleLevelList = from action in ALTypelist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
            if (id != "0")
            {
                //Basant_Rep
                var tutorial = UOF.ITutorial.GetAll().Where(m => m.ID == id).Select(m => m).ToList();

                foreach (var item in tutorial)
                {
                    TutorialDTO model = new TutorialDTO();
                    model.Description = item.Description.Replace("img/", ImgCloudPath + "/img/");
                    model.MetaKeywords = item.MetaKeywords;
                    model.IsActive = (bool)item.IsActive;
                    model.ShortDescription = item.ShortDescription;
                    model.ShortTitle = item.ShortTitle;
                    model.Tags = item.Tags;
                    model.Title = item.Title;
                    model.SchemaSEO = item.SchemaSEO;
                    model.Version = item.Version;
                    model.Url = item.Url;
                    model.Authors = item.Authors;
                    model.ArticleUrl = item.ArticleUrl;
                    model.SourceCodeUrl = item.SourceCodeUrl;
                    model.PostedDate = item.PostedDate;
                    model.DomainName = item.DomainName;
                    model.TutorialImage = item.TutorialImage;
                    model.ArticleLevel = item.ArticleLevel;
                    model.ArticleType = item.ArticleType;
                    model.CategoryID = (int)item.CategoryID;
                    ViewData["PostedDate"] = item.PostedDate;
                    model.Sequence = item.Sequence;

                    List<MentorMaster> AuthorMasterList = UOF.ICourse.GetMentorMasterList();
                    model.AuthorMasterList = AuthorMasterList;
                    model.AuthorList = ViewBag.SelectedAuthors = UOF.ITutorial.GetArticleAuthors(id, 1);
                    List<SelectListItem> Select_List = new List<SelectListItem>();
                    foreach (var m in AuthorMasterList)
                    {
                        SelectListItem obj = new SelectListItem()
                        {
                            Value = m.MentorId.ToString(),
                            Text = m.Name,
                            Selected = model.AuthorList.Where(me => me.MentorId == m.MentorId).Count() > 0 ? true : false
                        };

                        Select_List.Add(obj);
                    }
                    model.AuthorMaster = Select_List;
                    return View(model);
                }

            }

            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditTutorial(TutorialDTO tutorial, FormCollection AuthorName)
        {
            String mId = AuthorName["AuthorName"];
            try
            {
                // string TUrl = ""; string Tfile = ""; var Textn = ""; string Tpath = ""; string FlagT = ""; string Toldpic = ""; string fT = "";
                if (this.User.Identity.Name != null)
                {
                    //Basant_Rep .Where(m => m.ID == tutorial.ID).FirstOrDefault();
                    Tutorial mobj = UOF.ITutorial.GetTutorialByTID(tutorial.ID);
                    string Desc;

                    if (mobj.CategoryID > 0)
                    {
                        string CatName = UOF.ICategory.Get(mobj.CategoryID).CategoryName;

                        if (CatName.ToLower() == "c#")
                            CatName = "csharp";
                        else if (CatName.ToLower() == "c# windows apps")
                            CatName = "cswinapps";

                        //Toldpic = mobj.TutorialImage;
                        //if (tutorial.TImage != null && tutorial.TImage.ContentLength > 0)
                        //{
                        //    FlagT = "T";
                        //    var fileName = Path.GetFileName(tutorial.TImage.FileName);
                        //    Textn = Path.GetExtension(tutorial.TImage.FileName);
                        //}
                        //string _articleImageFolderLocation;
                        //_articleImageFolderLocation = ConfigurationManager.AppSettings["ArticleImageFolder"].ToString();
                        //if (FlagT == "T")
                        //{
                        //    Tfile = Regex.Replace(tutorial.ShortTitle, "[^0-9a-zA-Z]+", "").ToLower() + "-header" + Textn; //
                        //    Tpath = Path.Combine(Server.MapPath(_articleImageFolderLocation), Tfile);
                        //    TUrl = _articleImageFolderLocation + Tfile;
                        //}
                        //else
                        //{
                        //    TUrl = Toldpic;
                        //    fT = "1";
                        //}
                        //string directoryPath = Server.MapPath(string.Format("~/{0}/", _articleImageFolderLocation));
                        //if (!Directory.Exists(directoryPath))
                        //{
                        //    Directory.CreateDirectory(directoryPath);
                        //}

                        mobj.ShortDescription = tutorial.ShortDescription;
                        Desc = tutorial.Description.Replace("\r\n", "<br>").Replace(ImgCloudPath + "/img/", "img/");
                        Desc = Regex.Replace(Desc, @"\s+", " ");
                        Desc = Desc.Replace("<br>", "\r\n");
                        mobj.Description = Desc;
                        mobj.DomainName = tutorial.DomainName;
                        mobj.IsActive = tutorial.IsActive;
                        mobj.PostedDate = tutorial.PostedDate;
                        mobj.UpdatedDate = DateTime.Now; //tutorial.UpdatedDate;
                        mobj.ShortTitle = tutorial.ShortTitle;
                        mobj.Title = tutorial.Title;
                        mobj.SchemaSEO = tutorial.SchemaSEO;
                        mobj.Version = tutorial.Version;
                        mobj.Tags = tutorial.Tags;
                        mobj.Authors = mId;
                        mobj.ArticleUrl = tutorial.ArticleUrl;
                        mobj.SourceCodeUrl = tutorial.SourceCodeUrl;
                        mobj.ArticleLevel = tutorial.ArticleLevel;
                        mobj.ArticleType = tutorial.ArticleType;
                        mobj.Sequence = tutorial.Sequence;
                        // mobj.TutorialImage = TUrl;
                        mobj.CategoryID = tutorial.CategoryID;
                        mobj.MetaKeywords = tutorial.MetaKeywords;
                        if (mobj.PostedBy == null || mobj.PostedBy == "")
                            mobj.PostedBy = this.User.Identity.Name;

                        mobj.Url = "https://www.dotnettricks.com/learn/" + CatName.ToLower().Replace(" ", string.Empty).Replace(".", string.Empty);

                        UOF.SaveChanges();
                        //if (mobj.TutorialImage != null)
                        //{
                        //    if (TUrl != "")
                        //    {
                        //        if (fT != "1")
                        //        {

                        //            string Lfullpath = Request.MapPath(Toldpic);
                        //            if (System.IO.File.Exists(Lfullpath))
                        //            {
                        //                System.IO.File.Delete(Lfullpath);
                        //            }
                        //            tutorial.TImage.SaveAs(Tpath);
                        //        }

                        //    }
                        //}

                        ViewBag.Message = "Tutorial has been updated successfully";
                        ModelState.Clear();
                        IEnumerable<EnumArticleType> ATypelist = Enum.GetValues(typeof(EnumArticleType))
                                                    .Cast<EnumArticleType>();
                        ViewBag.ArticleTypeList = from action in ATypelist
                                                  select new SelectListItem
                                                  {
                                                      Text = action.ToString(),
                                                      Value = ((int)action).ToString()
                                                  };

                        IEnumerable<EnumArticleLevel> ALTypelist = Enum.GetValues(typeof(EnumArticleLevel))
                                                                .Cast<EnumArticleLevel>();
                        ViewBag.ArticleLevelList = from action in ALTypelist
                                                   select new SelectListItem
                                                   {
                                                       Text = action.ToString(),
                                                       Value = ((int)action).ToString()
                                                   };
                        return RedirectToAction("TutorialList");
                    }
                }
                else
                {
                    return RedirectToAction("Index", "ProBlog");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            BindPost(this.User.Identity.Name);

            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.EditTutorial = "EditTutorial";
            return RedirectToAction("TutorialList");
        }

        [Authorize]
        public JsonResult GetTutorial(string mID)
        {
            try
            {
                if (mID != "0")
                {
                    var tutorial = UOF.ITutorial.GetAll().Where(q => q.ID == mID).Select(m => new { Description = m.Description, m.MetaKeywords, m.IsActive, m.ShortDescription, m.ShortTitle, m.Tags, m.Title, m.Version, m.SchemaSEO, m.Url }).ToList();
                    return Json(tutorial, JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        public ActionResult ViewSubscription(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            ViewBag.ViewSubscription = "ViewSubscription";

            var data = UOF.ISubscription.GetAll().OrderByDescending(m => m.SubscribeDate).ToList();
            List<Subscription> subscriptionList = new List<Subscription>();
            foreach (var item in data)
            {
                Subscription obj = new Subscription();
                obj.EmailID = item.EmailID;
                obj.SubscribeDate = item.SubscribeDate;
                obj.SubscribeUrl = item.SubscribeUrl;
                obj.IsVerified = item.IsVerified;
                obj.VerificationDate = item.VerificationDate;
                obj.MailSentCounter = item.MailSentCounter;

                subscriptionList.Add(obj);
            }


            PagingDTO<Subscription> model = new PagingDTO<Subscription>();
            model.TotalRows = subscriptionList.Count();
            model.PageSize = pageSize;
            model.Data = subscriptionList.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            return View(model);
        }

        public ActionResult BooksDownload(int page = 1, string sort = "ID", string sortDir = "asc")
        {
            try
            {
                ViewBag.BooksDownload = "BooksDownload";

                //Basant_Rep .Join(mobjentity.Members, b => b.MemberId, m => m.MemberId, (b, m) => new { b, m }).OrderByDescending(x => x.b.DownloadDate).Select(x => new
                var data = UOF.IBookDownload.GetAll().Join(UOF.IMember.GetAll(), b => b.MemberId, m => m.MemberId, (b, m) => new { b, m }).OrderByDescending(x => x.b.DownloadDate).Select(x => new
                {
                    x.b.ID,
                    x.b.BookName,
                    x.b.MemberId,
                    x.b.DownloadDate,
                    x.m.Name,
                    x.m.Email,
                    x.m.MobileNo
                }).ToList();

                List<BookDownloadDTO> bookDownloadList = new List<BookDownloadDTO>();
                foreach (var item in data)
                {
                    BookDownloadDTO bookModel = new BookDownloadDTO();
                    bookModel.ID = item.ID;
                    bookModel.BookName = item.BookName;
                    bookModel.MemberId = item.MemberId;
                    bookModel.Email = item.Email;
                    bookModel.Mobile = item.MobileNo;
                    bookModel.Name = item.Name;
                    bookModel.DownloadDate = item.DownloadDate;

                    bookDownloadList.Add(bookModel);

                }


                PagingDTO<BookDownloadDTO> model = new PagingDTO<BookDownloadDTO>();
                model.TotalRows = bookDownloadList.Count();
                model.PageSize = pageSize;
                model.Data = bookDownloadList.Skip((page - 1) * pageSize).Take(pageSize).Distinct().ToList();

                return View(model);
            }
            catch (Exception)
            { }
            return View();
        }

        [Authorize]
        public ActionResult ViewCategory()
        {
            ViewBag.ViewCategory = "ViewCategory";
            BindCategory();
            return View();
        }

        [Authorize]
        public ActionResult ViewBlogger()
        {
            ViewBag.ViewBlogger = "ViewBlogger";
            BindBlogger();
            return View();
        }

        [Authorize]
        public JsonResult GetBlogger(string mID)
        {
            try
            {
                if (mID != "0")
                {
                    var blogger = UOF.IUser.GetMany(mID);
                    return Json(blogger, JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        private void BindBlogger()
        {
            var tblbloggerlist = UOF.IUser.GetAll().OrderBy(x => x.Name).ToList();
            List<Users> bloggerlist = new List<Users>();

            Users mobj = new Users();
            mobj.UserName = "0";
            mobj.Name = "Select";
            bloggerlist.Add(mobj);
            foreach (var item in tblbloggerlist)
            {
                mobj = new Users();
                mobj.UserName = item.UserName;
                mobj.Name = item.Name;

                bloggerlist.Add(mobj);
            }
            ViewBag.Bloggers = bloggerlist;
        }


        public ActionResult SendVerificationMail(int id)
        {
            try
            {
                MemberDTO model = UOF.IMember.GetMember(id);
                if (model.MemberId > 0)
                {

                    bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(model);
                    if (mailStatus == true)
                    {
                        int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(model.MemberId);
                    }
                }
            }
            catch (Exception ex) { }
            return RedirectToAction("ViewUnVerifiedMembers");
        }

        public ActionResult SendSubscriptionVerificationMail(string id)
        {
            try
            {
                string _subscribeUrl = UOF.ICommonLogic.VerifyEmailSubscription(id);
                if (!string.IsNullOrEmpty(_subscribeUrl))
                {

                    bool status = MailClient.SendMail_Subscription(id, _subscribeUrl);
                    if (status == true)
                    {
                        int? totalSentMailCount = UOF.ICommonLogic.IncreaseSubscribeMailSentCounter(id);
                    }
                }
            }
            catch (Exception ex) { }
            return RedirectToAction("ViewSubscription");
        }

        // By Amit
        public ActionResult TutorialList(int page = 1, int CategoryId = 0, string textsrch = "", int AuthorId = 0, bool IsSourceCode = false, string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.TutorialList = "TutorialList";
            PagingTutorialDTO<TutorialDTO> model = UOF.ITutorial.GetAllTutorialList(page, pageSize, textsrch, CategoryId, AuthorId, IsSourceCode, startDate, endDate);
            if (model != null)
            {
                ViewBag.page = model.Page;
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.AuthorList = UOF.ICourse.GetMentorMasterList();
                model.CategoryLst = _categoryList;
                return View(model);
            }
            model = new PagingTutorialDTO<TutorialDTO>();
            List<CategoryDTO> _categoryList1 = UOF.ICategory.GetCategories().ToList();
            model.AuthorList = UOF.ICourse.GetMentorMasterList();
            model.CategoryLst = _categoryList1;
            return View(model);
        }



        public JsonResult TutorialListForExcel(int CategoryId = 0, string textsrch = "", int AuthorId = 0, bool IsSourceCode = false, string Date = "")
        {
            try
            {

                List<TutorialDTO> report = new List<TutorialDTO>();
                List<TutorialExcelDTO> reportAll = new List<TutorialExcelDTO>();
                DateTime? startDate = null;
                DateTime? endDate = null;
                ViewBag.TutorialList = "TutorialList";
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }

                if (AuthorId > 0)
                {
                    report = UOF.ITutorial.GetAllTutorialListExcel(startDate, endDate, textsrch, CategoryId, AuthorId, IsSourceCode);
                }
                else
                {
                    var aurlist = UOF.ICourse.GetMentorMasterList();
                    foreach (var item in aurlist)
                    {
                        report = UOF.ITutorial.GetAllTutorialListExcel(startDate, endDate, textsrch, CategoryId, item.MentorId, IsSourceCode);
                        if (report.Count > 0)
                        {
                            TutorialExcelDTO reponame = new TutorialExcelDTO();
                            foreach (var itemchek in report)
                            {
                                foreach (var item1 in itemchek.AuthorList)
                                {
                                    if (item1.MentorId == item.MentorId)
                                    {
                                        reponame.AuthorsName = item1.Name;
                                        reponame.AuthorsEmail = item1.EmailID;
                                    }
                                }
                                reponame.WordPrice += itemchek.WordPrice;

                            }
                            reponame.Date = startDate.Value.ToString("dd/MMM/yyyy") + "-" + endDate.Value.ToString("dd/MMM/yyyy");
                            reponame.totalArticle = report.Count();
                            reportAll.Add(reponame);
                        }

                    }


                }
                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string RepoetName = "AuthorReport" + time + ".xlsx";
                if (report.Count > 0 && AuthorId > 0)
                {
                    foreach (var item in report)
                    {
                        foreach (var item1 in item.AuthorList)
                        {
                            if (item1.MentorId == AuthorId)
                            {
                                RepoetName = item1.Name + time + ".xlsx";
                            }
                        }
                    }
                }
                else
                {
                    RepoetName = "AuthorReport-" + startDate.Value.ToString("dd-MMM-yyyy") + "_" + endDate.Value.ToString("dd-MMM-yyyy") + ".xlsx";
                }

                string fileName = RepoetName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    if (report.Count > 0 && AuthorId > 0)
                    {
                        objReceiving.GetReceivingAllArticleReport(stream, report, p_strPath);
                    }
                    else
                    {
                        objReceiving.GetReceivingAllAuthorAmountReport(stream, reportAll, p_strPath);
                    }
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
                // return File(bytes, "text/xls", fileName);
            }
            catch (Exception ex)
            {

                // throw ex;
            }
            return null;
        }

        [HttpGet]
        public ActionResult AddBlogger()
        {
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult AddBlogger(Users muser)
        {
            try
            {

                ViewBag.AddBlogger = "AddBlogger";

                Users tbl = new Users();
                tbl.Name = muser.Name;
                tbl.UserName = muser.NewUserName;
                tbl.Password = muser.Password;
                tbl.IsAdmin = false;
                tbl.IsActive = false;
                UOF.IUser.Add(tbl);
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "blogger has been added successfully";

            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }

            ViewBag.AddBlogger = "AddBlogger";
            return View();

        }

        public ActionResult BloggerList()
        {
            IEnumerable<Users> model = UOF.ITutorial.GetBloggerListDetails();
            return View(model);
        }

        [Authorize]
        public ActionResult UserDelete(string id)
        {
            try
            {
                if (id != null && id != "")
                {
                    Users data = UOF.IUser.GetSingle(id);
                    if (data != null)
                    {
                        data.IsActive = false;
                        UOF.SaveChanges();

                        ViewBag.Message = "blogger has been deleted successfully";
                        return RedirectToAction("BloggerList");
                    }
                    else { ViewBag.Message = "There some internal error"; }
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "There some internal error";
            }

            return View();

        }


        [HttpGet]
        public ActionResult EditBlogger(string id)
        {
            Users model = UOF.ITutorial.GetBloggerDetailById(id);
            ViewBag.EditBlogger = "EditBlogger";

            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditBlogger(Users model)
        {
            try
            {
                Users userobj = UOF.IUser.GetSingle(model.UserName);
                userobj.Name = model.Name;
                userobj.IsAdmin = model.IsAdmin;
                userobj.IsActive = model.IsActive;
                userobj.Password = model.Password;
                UOF.SaveChanges();
                ViewBag.Message = "User has been updated successfully";
                ModelState.Clear();
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BloggerList");

        }

        public ActionResult CategoryList(int page = 1, int CategoryId = 0)
        {
            ViewBag.CategoryList = "CategoryList";
            PagingDTO<CategoryDTO> model = UOF.ITutorial.GetAllCategoryList(page, pageSize, CategoryId);
            List<CategoryDTO> catlist = new List<CategoryDTO>();
            var tblcatlist = UOF.ICategory.GetAll();
            CategoryDTO mobj = new CategoryDTO();
            foreach (var item in tblcatlist)
            {
                mobj = new CategoryDTO();
                mobj.CategoryID = item.CategoryID;
                mobj.CategoryName = item.CategoryName + " (" + (item.CategoryType == (int)EnumCategoryType.Article ? EnumCategoryType.Article.ToString() : EnumCategoryType.Course.ToString()) + ")";

                catlist.Add(mobj);
            }

            model.CategoryList = catlist;
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        [HttpGet]
        public ActionResult AddCategory()
        {
            ViewBag.BookList = UOF.ICourse.GetallCourseList().Where(x => x.CourseType == (int)EnumCourseType.Books);
            ViewBag.SkillsList = UOF.IQuestionMaster.GetAllQuiz();
            ViewBag.CoursesList = UOF.ICourse.GetallCourseList();

            IEnumerable<EnumCategoryType> CategoryType = Enum.GetValues(typeof(EnumCategoryType))
                                                    .Cast<EnumCategoryType>();
            ViewBag.CategoryTypeList = from action in CategoryType
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };

            return View();
        }
        [Authorize]
        [HttpPost, ValidateInput(false)]
        public ActionResult AddCategory(CategoryDTO model, string[] Books, string[] Courses, string[] Skills)
        {
            try
            {

                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["BookFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                string pathurl = "";
                // string oldpic = CurrentUser.ProfilePic;

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _CategoryFolderPath;
                    _CategoryFolderPath = ConfigurationManager.AppSettings["BookFolder"].ToString();
                    pathurl = "/" + _CategoryFolderPath + myfile;

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                }
                else
                {
                    pathurl = "";
                }
                model.ImageUrl = pathurl;

                ViewBag.AddCategory = "AddCategory";
                Category tbl = new Category();
                tbl.CategoryType = model.CategoryType;
                tbl.CategoryName = model.CategoryName;
                tbl.Url = model.Url;
                tbl.Title = model.Title;
                tbl.MetaTitle = model.MetaTitle;
                tbl.MetaKeywords = model.MetaKeywords;
                tbl.MetaDescription = model.MetaDescription;
                tbl.CreatedDate = DateTime.Now;
                tbl.IsActive = model.IsActive;
                tbl.Books = Books != null ? string.Join(",", Books) : null;
                tbl.Courses = Courses != null ? string.Join(",", Courses) : null;
                tbl.Skills = Skills != null ? string.Join(",", Skills) : null;

                tbl.Beginners = model.Beginners;
                tbl.Intermediate = model.Intermediate;
                tbl.Advanced = model.Advanced;
                tbl.Questions = model.Questions;
                tbl.CourseDescription = model.CourseDescription;
                tbl.SkillPath = model.SkillPath;
                tbl.SkillContents = model.SkillContents;
                if (model.ImageUrl != null && model.ImageUrl != "")
                {
                    tbl.ImageUrl = model.ImageUrl;
                }
                tbl.DisplayName = model.CategoryName;
                UOF.ICategory.Add(tbl);
                UOF.SaveChanges();

                ModelState.Clear();
                ViewBag.Message = "Category has been added successfully";

            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }
            ViewBag.BookList = UOF.ICourse.GetallCourseList().Where(x => x.CourseType == (int)EnumCourseType.Books);
            ViewBag.SkillsList = UOF.IQuestionMaster.GetAllQuiz();
            ViewBag.CoursesList = UOF.ICourse.GetallCourseList();

            IEnumerable<EnumCategoryType> CategoryType = Enum.GetValues(typeof(EnumCategoryType))
                                                    .Cast<EnumCategoryType>();
            ViewBag.CategoryTypeList = from action in CategoryType
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
            return View();

        }
        [Authorize]
        public ActionResult EditCategory(int id)
        {
            IEnumerable<EnumCategoryType> CategoryType = Enum.GetValues(typeof(EnumCategoryType))
                                                    .Cast<EnumCategoryType>();
            ViewBag.CategoryTypeList = from action in CategoryType
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };

            try
            {
                ViewBag.id = id;
                BindPost(this.CurrentUser.Name);
                ViewBag.EditCategory = "EditCategory";

                if (id > 0)
                {
                    CategoryDTO model = new CategoryDTO();
                    var item = UOF.ICategory.GetAll().Where(m => m.CategoryID == id).Select(m => m).FirstOrDefault();
                    if (item != null)
                    {
                        model.CategoryID = item.CategoryID;
                        model.CategoryType = item.CategoryType;
                        model.CategoryName = item.CategoryName;
                        model.Title = item.Title;
                        model.MetaTitle = item.MetaTitle;
                        model.Url = item.Url;
                        model.MetaKeywords = item.MetaKeywords;
                        model.MetaDescription = item.MetaDescription;
                        model.IsActive = item.IsActive;
                        model.Books = item.Books;
                        model.Courses = item.Courses;
                        model.Skills = item.Skills;
                        model.Beginners = item.Beginners;
                        model.Intermediate = item.Intermediate;
                        model.Advanced = item.Advanced;
                        model.Questions = item.Questions;
                        model.CourseDescription = item.CourseDescription;
                        model.SkillPath = item.SkillPath;
                        model.DisplayName = item.CategoryName;
                        if (item.ImageUrl != null && item.ImageUrl != "")
                        {
                            model.ImageUrl = ImgCloudPath + item.ImageUrl;
                        }
                        else
                        {
                            model.ImageUrl = item.ImageUrl;
                        }
                        model.SkillContents = item.SkillContents;

                        ViewBag.BookList = UOF.ICourse.GetallCourseList().Where(x => x.CourseType == (int)EnumCourseType.Books);
                        ViewBag.SkillsList = UOF.IQuestionMaster.GetAllQuiz();
                        ViewBag.CoursesList = UOF.ICourse.GetallCourseList();
                        ///////////////////////////

                        List<Course> cklist = new List<Course>();
                        if (item.Books != null)
                        {
                            string[] datab = item.Books.Split(',');
                            foreach (string d in datab)
                            {
                                int b = Convert.ToInt32(d);
                                Course obj = new Course();
                                var bk = UOF.ICourse.Get(b);
                                obj.CourseId = bk.CourseId;
                                obj.Name = bk.Name;
                                cklist.Add(obj);
                            }
                        }
                        List<SelectListItem> Select_Listb = new List<SelectListItem>();
                        foreach (var m in ViewBag.BookList)
                        {
                            SelectListItem obj = new SelectListItem()
                            {
                                Value = m.CourseId.ToString(),
                                Text = m.Name,
                                Selected = cklist.Where(me => me.CourseId == m.CourseId).Count() > 0 ? true : false
                            };

                            Select_Listb.Add(obj);
                        }
                        model.BookMaster = Select_Listb;

                        /////////////////////////
                        ////////////courses///////////////

                        List<Course> clist = new List<Course>();
                        if (item.Courses != null)
                        {
                            string[] datac = item.Courses.Split(',');
                            foreach (string d in datac)
                            {
                                int c = Convert.ToInt32(d);
                                Course obj = new Course();
                                var ck = UOF.ICourse.Get(c);
                                obj.CourseId = ck.CourseId;
                                obj.Name = ck.Name;
                                clist.Add(obj);
                            }
                        }

                        List<SelectListItem> Select_Listc = new List<SelectListItem>();
                        foreach (var m in ViewBag.CoursesList)
                        {
                            SelectListItem obj = new SelectListItem()
                            {
                                Value = m.CourseId.ToString(),
                                Text = m.Name,
                                Selected = clist.Where(me => me.CourseId == m.CourseId).Count() > 0 ? true : false
                            };

                            Select_Listc.Add(obj);
                        }
                        model.CoursesMaster = Select_Listc;

                        /////////////////////////
                        /////////////skill//////////////

                        List<MockUpTestMaster> slist = new List<MockUpTestMaster>();
                        if (item.Skills != null)
                        {
                            string[] datas = item.Skills.Split(',');
                            foreach (string d in datas)
                            {
                                int s = Convert.ToInt32(d);
                                MockUpTestMaster obj = new MockUpTestMaster();
                                var sk = UOF.IMockUpTestMaster.Get(s);
                                obj.MockupTestId = sk.MockupTestId;
                                obj.MockupTestName = sk.MockupTestName;
                                slist.Add(obj);
                            }
                        }

                        List<SelectListItem> Select_Lists = new List<SelectListItem>();
                        foreach (var m in ViewBag.SkillsList)
                        {
                            SelectListItem obj = new SelectListItem()
                            {
                                Value = m.MockupTestId.ToString(),
                                Text = m.MockupTestName,
                                Selected = slist.Where(me => me.MockupTestId == m.MockupTestId).Count() > 0 ? true : false
                            };

                            Select_Lists.Add(obj);
                        }
                        model.SkillMaster = Select_Lists;

                        ///////////////////////
                    }
                    return View(model);

                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult EditCategory(CategoryDTO mcat, FormCollection BooksName, FormCollection CoursesName, FormCollection SkillsName)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["BookFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                String bId = BooksName["BooksName"];
                String cId = CoursesName["CoursesName"];
                String sId = SkillsName["SkillsName"];
                string pathurl = "";
                string oldpic = "";
                bool oldflag = false;

                ViewBag.EditCategory = "EditCategory";
                var q = (from tbl in UOF.ICategory.GetAll()
                         where tbl.CategoryID == mcat.CategoryID
                         select tbl).FirstOrDefault();
                Category testdt = UOF.ICategory.Get(mcat.CategoryID);
                if (testdt != null && testdt.ImageUrl != null && testdt.ImageUrl != "")
                {
                    oldpic = q.ImageUrl.Replace(ImgCloudPath, "");
                }
                if (mcat.File != null && mcat.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(mcat.File.FileName); //file name  
                    var ext = Path.GetExtension(mcat.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _CategoryFolderLocation;
                    _CategoryFolderLocation = ConfigurationManager.AppSettings["BookFolder"].ToString();

                    //string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = "/" + _CategoryFolderLocation + myfile;

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = mcat.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    oldflag = true;
                }
                else
                {
                    if (oldpic != null && oldpic != "")
                    {
                        pathurl = oldpic;
                    }
                    else {
                        pathurl = null;
                    }
                }
                mcat.ImageUrl = pathurl;
                q.CategoryType = mcat.CategoryType;
                q.CategoryName = mcat.CategoryName;
                q.Title = mcat.Title;
                q.MetaTitle = mcat.MetaTitle;
                q.Url = mcat.Url;
                q.MetaKeywords = mcat.MetaKeywords;
                q.MetaDescription = mcat.MetaDescription;
                q.IsActive = mcat.IsActive;
                q.Books = bId;
                q.Skills = sId;
                q.Courses = cId;
                q.Beginners = mcat.Beginners;
                q.Intermediate = mcat.Intermediate;
                q.Advanced = mcat.Advanced;
                q.Questions = mcat.Questions;
                q.CourseDescription = mcat.CourseDescription;
                q.SkillPath = mcat.SkillPath;
                q.SkillContents = mcat.SkillContents;
                q.DisplayName = mcat.CategoryName;
                q.ImageUrl = mcat.ImageUrl;
                UOF.SaveChanges();
                if (oldflag == true && oldpic != null && oldpic != "")
                {
                    Uri uri = new Uri(ImgCloudPath + oldpic);
                    string filename = Path.GetFileName(uri.LocalPath);
                    var blob = blobContainer.GetBlockBlobReference(filename);
                    blob.DeleteIfExistsAsync();
                }
                ModelState.Clear();
                return RedirectToAction("CategoryList");
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }
            IEnumerable<EnumCategoryType> CategoryType = Enum.GetValues(typeof(EnumCategoryType))
                                                    .Cast<EnumCategoryType>();
            ViewBag.CategoryTypeList = from action in CategoryType
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
            return View();

        }

        public ActionResult _PartialCounter()
        {
            try
            {
                DashboardCounterDTO model = UOF.ITutorial.GetDashboardCounters();
                return PartialView("_PartialCounter", model);
            }
            catch
            {
                return null;
            }
        }

        public ActionResult VoteMasterListMapping(int page = 1, string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.VoteMasterListMapping = "VoteMasterListMapping";
            ViewBag.CurrentDate = DateTime.Now.AddDays(30);
            PagingDTO<TutorialDTO> model = new PagingDTO<TutorialDTO>();
            model = UOF.ITutorial.GetVoteMasterListMapping(page, pageSize, textsrch, startDate, endDate);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult VoteMasterList(int page = 1, int mid = 0, string textsrch = "", string Date = "")
        {

            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.VoteMasterList = "VoteMasterList";
            ViewBag.CurrentDate = DateTime.Now.AddDays(7);
            PagingDTO<VoteMasterDTO> model = new PagingDTO<VoteMasterDTO>();
            model = UOF.ITutorial.GetVoteMasterList(page, pageSize, mid, textsrch, startDate, endDate);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult MailAuthorForArticlePost(int VoteID)
        {
            string msg;
            var VoteDetails = UOF.ITutorial.MailAuthorForArticlePost(VoteID);

            bool stat = MailClient.SendMail_PostAuthors(VoteDetails);
            if (stat == true)
            {
                bool status = UOF.ITutorial.SendMail_PostAuthors(VoteID);
                msg = "done";
            }
            else
            {
                msg = "Error in mail sent";
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult GetArticleByAjax(string arti = "")
        {
            try
            {
                List<VoteMasterDTO> model = new List<VoteMasterDTO>();
                if (arti != "")
                {
                    model = UOF.ITutorial.GetArticleByAjax(arti);
                }
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            { }
            return Json(null);
        }

        [HttpPost]
        public JsonResult AddMedalByAjax(VoteMasterDTO model)
        {
            try
            {
                if (model.VoteID > 0)
                {
                    bool stat = UOF.ITutorial.AddMedalByAjax(model);

                    return Json(stat, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            { }
            return Json(null);
        }


        public JsonResult AddArticleByAjax(int TutorialID = 0, string ExpiryDate = null)
        {
            try
            {
                bool stat = true;
                if (TutorialID != 0 && ExpiryDate != null)
                {
                    DateTime dat = DateTime.Parse(ExpiryDate);
                    stat = UOF.ITutorial.AddArticleByAjax(TutorialID, dat);
                }
                return Json(stat, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            { }
            return Json(null);
        }

        public ActionResult VoteListInActive(int page = 1, int id = 0, int mid = 0)
        {
            try
            {
                bool stat = UOF.ITutorial.ChangeArticleStatus(id);
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("VoteMasterList", new { mid = mid, page = page });
        }
        public ActionResult VoteListDelete(int page = 1, int id = 0, int mid = 0)
        {
            try
            {
                bool stat = UOF.ITutorial.DeleteArticleStatus(id);
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("VoteMasterList", new { mid = mid, page = page });
        }

        public ActionResult ViewAllVoterList(int page = 1, int id = 0, string Date = "", int mid = 0)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.CouponsList = "CouponsList";
            ViewBag.CurrentDate = DateTime.Now.AddDays(7);
            PagingDTO<VotersDTO> model = new PagingDTO<VotersDTO>();
            model = UOF.ITutorial.GetVoterList(page, pageSize, id, startDate, endDate);
            ViewBag.mid = mid;
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult VoteDelete(int page = 1, int id = 0, int mid = 0)
        {
            try
            {
                bool stat = UOF.ITutorial.DeleteVoter(id);
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("ViewAllVoterList", new { id = id, page = page });
        }

        [HttpPost]
        public ActionResult AddListArticlesByAjax(VoteMasterDTO model)
        {
            try
            {
                try
                {
                    bool stat = UOF.ITutorial.AddArticlesByAjax(model);
                    if (stat == true)
                    {
                        return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception ex)
                {
                }


            }
            catch (Exception w)
            {
            }
            return null;

        }

        public ActionResult VoteMasterListMappingList(int page = 1, string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.VoteMasterListMapping = "VoteMasterListMapping";
            ViewBag.CurrentDate = DateTime.Now.AddDays(30);
            PagingDTO<VoteMasterDTO> model = new PagingDTO<VoteMasterDTO>();
            model = UOF.ITutorial.GetVoteMasterListMappingList(page, pageSize, textsrch, startDate, endDate);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult VoteMapListInActive(int page = 1, int id = 0)
        {
            try
            {
                bool stat = UOF.ITutorial.ChangeMapStatus(id);
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("VoteMasterListMappingList", new { page = page });
        }
        public ActionResult VoteMapListDelete(int page = 1, int id = 0)
        {
            try
            {
                bool stat = UOF.ITutorial.DeleteMapStatus(id);
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("VoteMasterListMappingList", new { page = page });
        }

        public ActionResult MailAuthorforArticlePublish(int TutorialID)
        {
            string msg;
            TutorialDTO mList = UOF.ITutorial.GetAutorListForMail(TutorialID);

            bool stat = MailClient.SendMail_ArticlePublishAuthors(mList);
            if (stat == true)
            {
                bool status = UOF.ITutorial.SaveStatusMailAuthorForPublish(TutorialID);
                msg = "done";
            }
            else
            {
                msg = "Error in mail sent";
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
    }
}

