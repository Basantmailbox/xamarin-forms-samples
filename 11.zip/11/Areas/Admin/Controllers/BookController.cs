﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{    
    public class BookController : BaseController
    {
        public string ImgCloudPath = "";
        static CloudBlobClient blobClient;
        static CloudBlobContainer blobContainer;
        CloudStorageAccount storageAccount;

        int pageSize;
        public BookController()            
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        
        // GET: /Admin/Book/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewAllBooks()
        {
            IEnumerable<BookMasterDTO> model = UOF.IBookMasters.GetAllBookList(false);
            return View(model);
        }
        public ActionResult AddNewBook()
        {
            ViewBag.ViewAllBooks = "ViewAllBooks";
            ViewData["CurrentDate"] = DateTime.Now.ToShortDateString();
            BookMasterDTO model = new BookMasterDTO();
            BindDocument();
            List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
            model.MentorMasterList = MentorMasterList;

            return View(model);
        }
        void BindDocument()
        {
            var tblDocumentlist = UOF.IDocument.GetMany("book");

            List<DocumentDTO> DocumentList = new List<DocumentDTO>();

            DocumentDTO mobj = new DocumentDTO();
            mobj.DocumentId = 0;
            mobj.DocumentName = "- Select Document -";
            DocumentList.Add(mobj);

            foreach (var item in tblDocumentlist)
            {
                mobj = new DocumentDTO();
                mobj.DocumentId = item.DocumentId;
                mobj.DocumentName = item.DocumentName;

                DocumentList.Add(mobj);
            }
            ViewBag.documentlist = DocumentList;
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddNewBook(BookMasterDTO model, string[] Mentors)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["BookFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                BindDocument();
                string pathurl = "";
                // string oldpic = CurrentUser.ProfilePic;

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _BookFolderLocation;
                    _BookFolderLocation = ConfigurationManager.AppSettings["BookFolder"].ToString();
                    pathurl = "/" + _BookFolderLocation + myfile;

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                }
                else
                {
                    pathurl = "";
                }
                model.ImageUrl = pathurl;
                model.Mentors = string.Join(",", Mentors);
                bool stat = UOF.IBookMasters.AddNewBook(model);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();

                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
                TempData["Message"] = ex.Message + " - " + ex.StackTrace;
            }

            return RedirectToAction("ViewAllBooks");
            //return View();
        }

        [HttpGet]
        public ActionResult EditBook(int BookId)
        {
            TempData["Message"] = "";
            BookMasterDTO model = UOF.IBookMasters.GetBookMasterDisplay(BookId);
            ViewData["PostedDate"] = model.PostedDate;
            BindDocument();
            model.DocumentId = model.DocumentId;
            List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
            model.MentorMasterList = MentorMasterList;


            model.MentorList = ViewBag.SelectedMentors = UOF.IBookMasters.GetBookMentors(BookId);
            List<SelectListItem> Select_List = new List<SelectListItem>();
            foreach (var m in MentorMasterList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = m.MentorId.ToString(),
                    Text = m.Name,
                    Selected = model.MentorList.Where(me => me.MentorId == m.MentorId).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }
            model.MentorMaster = Select_List;
           return View(model);

        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditBook(BookMasterDTO model, FormCollection MentorName)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["BookFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                String mId = MentorName["MentorName"];
                string pathurl = "";
                string oldpic = "";
                bool oldflag = false;
                BookMaster testdt = UOF.IBookMasters.Get(model.BookId);
                if (testdt != null)
                {
                    oldpic = testdt.ImageUrl.Replace(ImgCloudPath, "");
                }

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _BookFolderLocation;
                    _BookFolderLocation = ConfigurationManager.AppSettings["BookFolder"].ToString();

                    //string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = "/" + _BookFolderLocation + myfile;
                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    oldflag = true;
                }
                else
                {
                    pathurl = oldpic;
                }
                model.ImageUrl = pathurl;
                model.Mentors = mId;
                bool stat = UOF.IBookMasters.UpdateBook(model);
                if (stat != false)
                {
                    if (oldflag == true)
                    {
                        Uri uri = new Uri(ImgCloudPath + oldpic);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();
                    }
                    TempData["Message"] = "Details has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewAllBooks");
        }
        public ActionResult BookDelete(int BookId)
        {
            TempData["Message"] = "";
            blobClient = storageAccount.CreateCloudBlobClient();
            blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["BookFolder"].ToString());
            blobContainer.CreateIfNotExistsAsync();

            var mobj = UOF.IBookMasters.Get(BookId);
            if (mobj != null)
            {
                UOF.IBookMasters.Remove(mobj);
                UOF.SaveChanges();
            }

            var photoName = "";
            photoName = ImgCloudPath + mobj.ImageUrl;

            Uri uri = new Uri(photoName);
            string filename = Path.GetFileName(uri.LocalPath);

            var blob = blobContainer.GetBlockBlobReference(filename);
            blob.DeleteIfExistsAsync();

            //photoName = mobj.ImageUrl;
            //string fullPath = Request.MapPath(photoName);

            //if (System.IO.File.Exists(fullPath))
            //{
            //    System.IO.File.Delete(fullPath);
            //}

            return RedirectToAction("ViewAllBooks");
        }

    }
}
