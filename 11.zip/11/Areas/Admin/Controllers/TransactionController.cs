﻿using DotNetTricks.COM.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;

using DNTShared;
using DNTShared.DTO;
using DNTData;
using DNTShared.Entities;
using System.IO;
using DNTWebUI.Models;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class TransactionController : BaseController
    {
        int pageSize;
        public TransactionController()

        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }


        public ActionResult TransactionDetailsList(int page = 1, int filterId = 1, string textsrch = "", string Date = "", int CourseId = 0)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.TransactionDetailsList = "TransactionDetailsList";
            PagingDTO<TransactionDTO> model = new PagingDTO<TransactionDTO>();
            if (CurrentUser.Roles.Contains("Subadmin"))
            {
                model = UOF.IAdminMaster.GetLimitedTransactionDetailsList(filterId, textsrch, CourseId);
            }
            else
            {
                model = UOF.IAdminMaster.GetTransactionDetailsList(page, pageSize, filterId, textsrch, startDate, endDate, CourseId);
            }
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.SelectedValue = filterId;
            }
            return View(model);
        }

        public ActionResult PaymentDetailsList(int page = 1, string textsrch = "", string Date = "", int CourseId = 0, int CourseType = 0, string PaymentGateway = "")
        {
            try
            {
                //setting current month range
                DateTime now = DateTime.Now;
                DateTime startDate = new DateTime(now.Year, now.Month, 1);
                //fixed last day payment issue
                DateTime endDate = startDate.AddMonths(1).AddDays(-1).AddHours(23).AddMinutes(59).AddSeconds(59);

                PagingDTO<TransactionDTO> model = new PagingDTO<TransactionDTO>();
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    //fixed last day payment issue
                    endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
                }

                ViewBag.PaymentDetailsList = "PaymentDetailsList";
                model = UOF.IAdminMaster.GetPaymentDetailsList(page, pageSize, textsrch, startDate, endDate, CourseId, CourseType, PaymentGateway);
                IEnumerable<EnumCourseType> EnumCourseTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                     .Cast<EnumCourseType>();
                ViewBag.CourseTypelist = from action in EnumCourseTypelist
                                         select new SelectListItem
                                         {
                                             Text = action.ToString(),
                                             Value = ((int)action).ToString()
                                         };
                IEnumerable<EnumPaymentMode> EnumPayModelist = Enum.GetValues(typeof(EnumPaymentMode))
                                                     .Cast<EnumPaymentMode>();
                ViewBag.EnumPayModelist = from action in EnumPayModelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = action.ToString(),
                                          };
                ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View(model);
            }
            catch (Exception ex)
            {
                // Response.Write(ex);
            }
            return View();
        }

        [HttpGet]
        public ActionResult CreateInstallment()
        {
            ViewBag.Message = "";
            ViewData["CurrentDate"] = DateTime.Now.AddDays(5).ToShortDateString();
            InstallmentDetailsDTO InstallmentModel = new InstallmentDetailsDTO();
            ViewBag.CreateInstallment = "CreateInstallment";
            InstallmentModel.CourseList = UOF.ICourse.GetCoursesExcludingSelfPaced().ToList();
            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            InstallmentModel.ServiceTax = Convert.ToDecimal(ConfigurationManager.AppSettings["TaxValue"]);
            InstallmentModel.STaxName = ConfigurationManager.AppSettings["TaxName"];


            IEnumerable<EnumCourseType> EnumCourseTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                    .Cast<EnumCourseType>();
            ViewBag.CourseTypelist = from action in EnumCourseTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };
            return View(InstallmentModel);
        }

        [HttpPost]
        public ActionResult CreateInstallment(InstallmentDetailsDTO model)
        {
            try
            {
                ViewBag.CreateInstallment = "CreateInstallment";
                ViewData["CurrentDate"] = DateTime.Now.ToShortDateString();
                model.TransactionId = Utility.GenerateUniqueNo();

                model.CreatedBy = (int)CurrentUser.UserId;

                bool result = UOF.ICommonLogic.SaveInstallmentTransDetails(model);
                var url = Url.Action("InstallmentDetailsList_V1");

                if (result == true)
                {
                    return Json(new { status = "success", url = url }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    ViewBag.Message = "Something happened. Please try again later.";
                }

                model.CourseList = UOF.ICourse.GetCoursesExcludingSelfPaced().ToList();
                return Json(new { status = ViewBag.Message, url = url }, JsonRequestBehavior.AllowGet);
                //return RedirectToAction("InstallmentDetailsList_V1");
            }
            catch (Exception ex)
            {
                return Json(new { msg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        //new
        public ActionResult InstallmentDetailsList_V1(int page = 1, string textsrch = "", int filterId = 1, string Date = "", int? SalesId = null)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            int userid = 0;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            else
            {
                startDate = DateTime.Today.AddDays(-7);
                endDate = DateTime.Today.AddDays(1);
            }
            ViewBag.InstallmentDetailsList = "InstallmentDetailsList";
            PagingDTO<InstallmentDetailsDTO> model = new PagingDTO<InstallmentDetailsDTO>();
            if (!CurrentUser.Roles.Contains("Admin") && !CurrentUser.Roles.Contains("Subadmin"))
            {
                userid = (int)CurrentUser.UserId;
            }
            model = UOF.IAdminMaster.GetInstallmentDetailsList_V1(page, pageSize, filterId, textsrch, startDate, endDate, userid, SalesId);
            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.SelectedValue = filterId;
                ViewBag.SelectedAdmin = SalesId;
            }
            return View(model);
        }
        //

        public ActionResult InstallmentDetailsList(int page = 1, string textsrch = "", int filterId = 1, string Date = "", int CourseId = 0, int? SalesId = null)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            int userid = 0;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.InstallmentDetailsList = "InstallmentDetailsList";
            PagingDTO<InstallmentDetailsDTO> model = new PagingDTO<InstallmentDetailsDTO>();
            if (!CurrentUser.Roles.Contains("Admin") && !CurrentUser.Roles.Contains("Subadmin"))
            {
                userid = (int)CurrentUser.UserId;
            }
            model = UOF.IAdminMaster.GetInstallmentDetailsList(page, pageSize, filterId, textsrch, startDate, endDate, CourseId, userid, SalesId);
            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.SelectedValue = filterId;
                ViewBag.SelectedAdmin = SalesId;
            }
            return View(model);
        }

        //end by rakesh
        [CustomAuthorizeAttribute(Roles = "Admin")]
        [HttpGet]
        public ActionResult EditTransactionDetails(int Id = 0)
        {
            TransactionDTO tranModel = new TransactionDTO();
            ViewBag.TransactionDetailsList = "TransactionDetailsList";
            tranModel = UOF.IAdminMaster.GetTransactionDetailsById(Id);

            IEnumerable<EnumTrainingMode> tmlist = Enum.GetValues(typeof(EnumTrainingMode))
                                                      .Cast<EnumTrainingMode>();
            ViewBag.TrainingModeList = from action in tmlist
                                       where action.ToString() != "Any"
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
            return View(tranModel);
        }

        [CustomAuthorizeAttribute(Roles = "Admin")]
        [HttpPost, ValidateInput(false)]
        public ActionResult EditTransactionDetails(TransactionDTO model)
        {
            try
            {
                bool status = UOF.IAdminMaster.UpdateTransactionDetails(model);
                IEnumerable<EnumTrainingMode> tmlist = Enum.GetValues(typeof(EnumTrainingMode))
                                                      .Cast<EnumTrainingMode>();
                ViewBag.TrainingModeList = from action in tmlist
                                           where action.ToString() != "Any"
                                           select new SelectListItem
                                           {
                                               Text = action.ToString(),
                                               Value = ((int)action).ToString()
                                           };
                if (status == true)
                {
                    ViewBag.message = "Transaction has been updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.message = "unable to Transaction this time. please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("TransactionDetailsList");
        }

        [Route("EditInstallment_V1/{Id}")]
        [HttpGet]
        public ActionResult EditInstallment_V1(int Id = 0)
        {
            InstallmentDetailsDTO InstallmentModel = new InstallmentDetailsDTO();
            ViewBag.InstallmentDetailsList = "InstallmentDetailsList";

            InstallmentModel = UOF.IAdminMaster.GetInstallmentv1DetailsById(Id);
            ViewData["CurrentDate"] = InstallmentModel.ExpiryDate;
            return View(InstallmentModel);
        }

        [Route("EditInstallment_V1/{Id}")]
        [HttpPost]
        public ActionResult EditInstallment_V1(InstallmentDetailsDTO model)
        {
            try
            {
                model.CreatedBy = (int)CurrentUser.UserId;
                // model.UID = Utility.GenerateUniqueId();
                bool status = UOF.IAdminMaster.UpdateInstallmentDetailsv1(model);

                if (status == true)
                {
                    ViewBag.message = "Installment has been updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.message = "unable to Installment this time. please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("InstallmentDetailsList_V1");
        }

        [Route("EditInstallment/{Id}")]
        [HttpGet]
        public ActionResult EditInstallment(int Id = 0)
        {
            InstallmentDetailsDTO InstallmentModel = new InstallmentDetailsDTO();
            ViewBag.InstallmentDetailsList = "InstallmentDetailsList";
            InstallmentModel = UOF.IAdminMaster.GetInstallmentDetailsById(Id);
            ViewData["CurrentDate"] = InstallmentModel.ExpiryDate;
            
            InstallmentModel.CourseList = UOF.ICourse.GetCoursesExcludingSelfPaced().ToList();
            InstallmentModel.InstallmentName = InstallmentModel.InstallmentName;
            return View("CreateInstallment", InstallmentModel);
        }

        [HttpPost, ValidateInput(false)]
        [Route("EditInstallment/{Id}")]
        public ActionResult EditInstallment(InstallmentDetailsDTO model)
        {
            try
            {
                model.UpdatedBy = (int)CurrentUser.UserId;
                bool status = UOF.IAdminMaster.UpdateInstallmentDetails(model);

                if (status == true)
                {
                    ViewBag.message = "Installment has been updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.message = "unable to Installment this time. please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("InstallmentDetailsList");
        }


        [HttpGet]
        public ActionResult DeleteInstallment_V1(int Id = 0, int page = 1)
        {
            bool status = UOF.IAdminMaster.DeleteInstallment_V1(Id);
            if (status == true)
            {
                return RedirectToAction("InstallmentDetailsList_V1", new { page = page });
            }
            return View();
        }

        [CustomAuthorizeAttribute(Roles = "Admin")]
        [Route("DeleteInstallment/{Id}")]
        [HttpGet]
        public ActionResult DeleteInstallment(int Id = 0, int page = 1)
        {
            bool status = UOF.IAdminMaster.DeleteInstallment(Id);
            if (status == true)
            {
                return RedirectToAction("InstallmentDetailsList", new { page = page });
            }
            return View();
        }

        [CustomAuthorizeAttribute(Roles = "Admin")]
        [Route("DeleteTransactionDetails/{Id}")]
        [HttpGet]
        public ActionResult DeleteTransactionDetails(int Id = 0, int page = 1)
        {
            bool status = UOF.IAdminMaster.DeleteTransaction(Id);
            if (status == true)
            {
                return RedirectToAction("TransactionDetailsList", new { page = page });
            }
            return View();
        }

        [CustomAuthorizeAttribute(Roles = "Admin")]
        [Route("DeleteTransactionDetailsNew/{Id}")]
        [HttpGet]
        public ActionResult DeleteTransactionDetailsNew(int Id = 0, int page = 1)
        {
            bool status = UOF.IAdminMaster.DeleteTransactionDetailsNew(Id);
            if (status == true)
            {
                return RedirectToAction("AllTransactionDetailsList", new { page = page });
            }
            return View();
        }

        //[ChildActionOnly]
        public ActionResult StatusInstallment()
        {
            return PartialView("_StatusInstallment");
        }

        [HttpPost]
        public ActionResult UpdateStatusInstallment(TransactionDTO model)
        {
            try
            {
                bool stat = UOF.IAdminMaster.UpdateStatusInstallment(model);
                if (stat == true)
                {
                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        public ActionResult StatusTransaction()
        {
            return PartialView("_StatusTransaction");
        }

        public ActionResult UpdateTransactionStatus1()
        {
            return PartialView("_UpdateTransactionStatus");
        }


        [HttpPost]
        public ActionResult UpdateStatusTransaction(TransactionDTO model)
        {
            try
            {
                bool stat = UOF.IAdminMaster.UpdateStatusTransaction(model);
                if (stat == true)
                {
                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult UpdateTransactionStatus(TransactionDTO model)
        {
            try
            {
                bool stat = UOF.ICommonLogic.UpdateTransactionStatus(model);
                if (stat == true)
                {
                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetPaymentInvoiceDetails(long id)
        {
            try
            {
                TransactionDTO data = UOF.IAdminMaster.getInvoiceChild(id);
                if (data != null)
                {
                    ModelState.Clear();
                    return Json(data.PaymentChildDetailList, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(data, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public ActionResult PrintInvoice(int id = 0)
        {
            try
            {
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                PaymentDTO model = UOF.IAdminMaster.GetPaymentDetailsById(id);
                if (model.StateCode > 0 && model.StateCode != null)
                {
                    var tax = UOF.IAdminMaster.getTaxRate((int)model.StateCode);
                    var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);

                    bool flag = false;
                    bool flagR = false;
                    if (tax != null)
                    {
                        model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                        if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                        {
                            if (model.Currency == "INR")
                            {
                                model.CGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                                model.SGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                                model.Price = Math.Round(model.Total / (model.CGSTR + model.SGSTR + 100) * 100, 2);
                                decimal CGST = Math.Round((model.Price * tax.Select(x => x.CGST).FirstOrDefault() / 100), 2);
                                decimal SGST = Math.Round((model.Price * tax.Select(x => x.SGST).FirstOrDefault() / 100), 2);
                                model.CGST = CGST;
                                model.SGST = SGST;
                                model.NetPrice = Math.Round((model.Price + CGST + SGST), 2);

                                if (model.Total > (model.Price + model.CGST + model.SGST))
                                {
                                    flagR = true;
                                    model.RoundOff = model.Total - (model.Price + model.CGST + model.SGST);
                                    ViewBag.sign = "+";
                                }
                                else if (model.Total < (model.Price + model.CGST + model.SGST))
                                {
                                    flagR = true;
                                    model.RoundOff = (model.Price + model.CGST + model.SGST) - model.Total;
                                    ViewBag.sign = "-";
                                }
                                flag = true;
                            }
                            else
                            {
                                model.Total = model.Total;
                            }
                        }
                        else
                        {
                            if (model.Currency == "INR")
                            {

                                model.IGSTR = tax.Select(x => x.IGST).FirstOrDefault();
                                model.Price = Math.Round(model.Total / (model.IGSTR + 100) * 100, 2);
                                decimal IGST = Math.Round((model.Price * model.IGSTR / 100), 2);

                                model.IGST = IGST;

                                model.NetPrice = Math.Round((model.Price + IGST), 2);
                                if (model.Total > (model.Price + model.IGST))
                                {
                                    flagR = true;
                                    model.RoundOff = model.Total - (model.Price + model.IGST);
                                    ViewBag.sign = "+";
                                }
                                else if (model.Total < (model.Price + model.IGST))
                                {
                                    flagR = true;
                                    model.RoundOff = (model.Price + model.IGST) - model.Total;
                                    ViewBag.sign = "-";
                                }
                                flag = false;
                            }
                            else
                            {
                                model.Total = model.Total;
                            }
                        }
                        if (flag == true)
                        {
                            ViewBag.taxstate = "CGSTSGST";
                        }
                        if (flagR == true)
                        {
                            ViewBag.Roundstate = "true";
                        }
                    }
                }
                else
                {
                    if (model.Currency == "INR")
                    {
                        bool flag = false;
                        bool flagR = false;
                        model.IGSTR = TaxUtility.TaxValue;
                        model.Price = Math.Round(model.Total / (model.IGSTR + 100) * 100, 2);
                        decimal IGST = Math.Round((model.Price * model.IGSTR / 100), 2);

                        model.IGST = IGST;

                        model.NetPrice = Math.Round((model.Price + IGST), 2);
                        if (model.Total > (model.Price + model.IGST))
                        {
                            model.RoundOff = model.Total - (model.Price + model.IGST);
                            ViewBag.sign = "+";
                            flagR = true;
                        }
                        else if (model.Total < (model.Price + model.IGST))
                        {
                            model.RoundOff = (model.Price + model.IGST) - model.Total;
                            ViewBag.sign = "-";
                            flagR = true;
                        }
                        flag = true;

                        if (flagR == true)
                        {
                            ViewBag.Roundstate = "true";
                        }
                    }
                    else
                    { model.Price = model.Total; }
                }
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                model.StateId = (model.StateCode != null && model.StateCode > 0) ? (int)model.StateCode : 0;
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                //ViewBag.taxstate = "";
                //ViewBag.Roundstate = "";
                //ViewBag.sign = "";
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        //
        [HttpPost]
        public ActionResult PrintInvoice(PaymentDTO data)
        {
            try
            {
                PaymentDTO model = UOF.IAdminMaster.GetPaymentDetailsById(data.Id);
                var tax = UOF.IAdminMaster.getTaxRate(data.StateId);
                var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                bool flag = false;
                bool flagR = false;
                if (tax != null)
                {
                    model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                    if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                    {
                        if (model.Currency == "INR")
                        {
                            model.CGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                            model.SGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                            model.Price = Math.Round(model.Total / (model.CGSTR + model.SGSTR + 100) * 100, 2);
                            model.CGST = Math.Round((model.Price * tax.Select(x => x.CGST).FirstOrDefault() / 100), 2);
                            model.SGST = Math.Round((model.Price * tax.Select(x => x.SGST).FirstOrDefault() / 100), 2);

                            model.NetPrice = Math.Round((model.Price + model.CGST + model.SGST), 2);

                            if (model.Total > (model.Price + model.CGST + model.SGST))
                            {
                                flagR = true;
                                model.RoundOff = model.Total - (model.Price + model.CGST + model.SGST);
                                ViewBag.sign = "+";
                            }
                            else if (model.Total < (model.Price + model.CGST + model.SGST))
                            {
                                flagR = true;
                                model.RoundOff = (model.Price + model.CGST + model.SGST) - model.Total;
                                ViewBag.sign = "-";
                            }
                            flag = true;
                        }
                        else
                        {
                            model.Total = model.Total;
                        }
                    }
                    else
                    {
                        if (model.Currency == "INR")
                        {

                            model.IGSTR = tax.Select(x => x.IGST).FirstOrDefault();
                            model.Price = Math.Round(model.Total / (model.IGSTR + 100) * 100, 2);
                            model.IGST = Math.Round((model.Price * model.IGSTR / 100), 2);

                            model.NetPrice = Math.Round((model.Price + model.IGST), 2);
                            if (model.Total > (model.Price + model.IGST))
                            {
                                flagR = true;
                                model.RoundOff = model.Total - (model.Price + model.IGST);
                                ViewBag.sign = "+";
                            }
                            else if (model.Total < (model.Price + model.IGST))
                            {
                                flagR = true;
                                model.RoundOff = (model.Price + model.IGST) - model.Total;
                                ViewBag.sign = "-";
                            }
                            flag = false;
                        }
                        else
                        {
                            model.Total = model.Total;
                        }
                    }
                    if (flag == true)
                    {
                        ViewBag.taxstate = "CGSTSGST";
                    }
                    if (flagR == true)
                    {
                        ViewBag.Roundstate = "true";
                    }
                }
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        [HttpGet]
        public ActionResult GenerateInvoiceForInstallment(int id = 0, int InstallmentID = 0)
        {
            try
            {
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                decimal NetPrice = 0;
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceForInstallmentById(id, InstallmentID, false);
                if (model.StateCode != null)
                {
                    var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                    var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);

                    if (tax != null)
                    {
                        bool flag = false;
                        bool flagR = false;
                        model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                        if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                        {
                            if (model.Currency == "INR")
                            {
                                model.CGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                                model.SGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                                model.Price = Math.Round(model.InstallmentDetails.Total / (model.CGSTR + model.SGSTR + 100) * 100, 2);
                                decimal CGST = Math.Round((model.InstallmentDetails.NetPrice * tax.Select(x => x.CGST).FirstOrDefault() / 100), 2);
                                decimal SGST = Math.Round((model.InstallmentDetails.NetPrice * tax.Select(x => x.SGST).FirstOrDefault() / 100), 2);
                                model.CGST = CGST;
                                model.SGST = SGST;
                                NetPrice = Math.Round((model.InstallmentDetails.NetPrice + CGST + SGST), 2);

                                if (model.InstallmentDetails.Total < Math.Round(model.InstallmentDetails.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = Math.Round(model.InstallmentDetails.Total) - model.InstallmentDetails.Total;
                                    ViewBag.sign = "+";
                                }
                                else if (model.InstallmentDetails.Total > Math.Round(model.InstallmentDetails.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = model.InstallmentDetails.Total - Math.Round(model.InstallmentDetails.Total);
                                    ViewBag.sign = "-";
                                }
                                flag = true;
                            }
                            else
                            {
                                model.Total = model.InstallmentDetails.Total;
                            }
                        }
                        else
                        {
                            if (model.Currency == "INR")
                            {

                                model.IGSTR = tax.Select(x => x.IGST).FirstOrDefault();
                                model.Price = Math.Round(model.Total / (model.IGSTR + 100) * 100, 2);
                                decimal IGST = Math.Round((model.Price * model.IGSTR / 100), 2);

                                model.IGST = IGST;

                                NetPrice = Math.Round((model.Price + IGST), 2);
                                if (model.Total < Math.Round(model.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = Math.Round(model.Total) - model.Total;
                                    ViewBag.sign = "+";
                                }
                                else if (model.Total > Math.Round(model.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = model.Total - Math.Round(model.Total);
                                    ViewBag.sign = "-";
                                }
                                flag = false;
                            }
                            else
                            {
                                model.Total = model.InstallmentDetails.Total;
                            }
                        }
                        if (flag == true)
                        {
                            ViewBag.taxstate = "CGSTSGST";
                        }
                        if (flagR == true)
                        {
                            ViewBag.Roundstate = "true";
                        }
                    }
                    else
                    {
                        bool flag1 = false;
                        bool flagR1 = false;
                        if (model.Currency == "INR")
                        {
                            model.IGSTR = TaxUtility.TaxValue;
                            model.Price = Math.Round(model.InstallmentDetails.Total / (model.IGSTR + 100) * 100, 2);
                            decimal IGST = Math.Round((model.InstallmentDetails.NetPrice * model.IGSTR / 100), 2);

                            model.IGST = IGST;

                            NetPrice = Math.Round((model.InstallmentDetails.NetPrice + IGST), 2);
                            if (model.InstallmentDetails.Total < Math.Round(model.InstallmentDetails.Total))
                            {
                                flagR1 = true;
                                model.RoundOff = Math.Round(model.InstallmentDetails.Total) - model.InstallmentDetails.Total;
                                ViewBag.sign = "+";
                            }
                            else if (model.InstallmentDetails.Total > Math.Round(model.InstallmentDetails.Total))
                            {
                                flagR1 = true;
                                model.RoundOff = Math.Round(model.InstallmentDetails.Total) - model.InstallmentDetails.Total;
                                ViewBag.sign = "-";
                            }
                            flag1 = true;

                            if (flagR1 == true)
                            {
                                ViewBag.Roundstate = "true";
                            }
                        }
                        else
                        {

                            if (model.InstallmentDetails.Total < Math.Round(model.InstallmentDetails.Total))
                            {
                                flagR1 = true;
                                model.RoundOff = Math.Round(model.Total) - model.Total;
                                ViewBag.sign = "+";
                            }
                            else if (model.InstallmentDetails.Total > Math.Round(model.InstallmentDetails.Total))
                            {
                                flagR1 = true;
                                model.RoundOff = model.InstallmentDetails.Total - Math.Round(model.InstallmentDetails.Total);
                                ViewBag.sign = "-";
                            }
                            if (flagR1 == true)
                            {
                                ViewBag.Roundstate = "true";
                            }
                            model.Price = model.InstallmentDetails.Total;
                        }
                    }
                }
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                model.StateCode = model.StateCode != null ? model.StateCode : "";
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                //ViewBag.taxstate = "";
                ViewBag.Amount = Math.Round(model.InstallmentDetails.Total);
                //ViewBag.sign = "";
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        [HttpPost]
        public ActionResult GenerateInvoiceForInstallment(TransactionDTO data)
        {
            try
            {
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                decimal NetPrice = 0;
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceForInstallmentById(data.Id, data.InstallmentID, false);
                if (data.StateCode != null)
                {
                    var tax = UOF.IAdminMaster.getTaxRateCode(data.StateCode.ToString());
                    var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);

                    bool flag = false;
                    bool flagR = false;

                    if (tax != null)
                    {
                        model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                        if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                        {
                            if (model.Currency == "INR")
                            {
                                model.CGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                                model.SGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                                decimal Price = Math.Round(model.InstallmentDetails.Total / (model.CGSTR + model.SGSTR + 100) * 100);
                                decimal CGST = Math.Round((Price * tax.Select(x => x.CGST).FirstOrDefault() / 100), 2);
                                decimal SGST = Math.Round((Price * tax.Select(x => x.SGST).FirstOrDefault() / 100), 2);
                                model.CGST = CGST;
                                model.SGST = SGST;
                                NetPrice = Price + CGST + SGST;
                                model.NetPrice = NetPrice;
                                if (NetPrice < Math.Round(model.InstallmentDetails.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = Math.Round(model.InstallmentDetails.Total) - NetPrice;
                                    ViewBag.sign = "+";
                                }
                                else if (NetPrice > Math.Round(model.InstallmentDetails.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = NetPrice - Math.Round(model.InstallmentDetails.Total);
                                    ViewBag.sign = "-";
                                }
                                flag = true;
                            }
                            else
                            {
                                model.InstallmentDetails.Total = model.InstallmentDetails.Total;
                            }
                        }
                        else
                        {
                            if (model.Currency == "INR")
                            {

                                model.IGSTR = tax.Select(x => x.IGST).FirstOrDefault();
                                decimal Price = Math.Round(model.InstallmentDetails.Total / (model.IGSTR + 100) * 100);
                                decimal IGST = Math.Round((Price * model.IGSTR / 100), 2);

                                model.IGST = IGST;

                                NetPrice = Price + IGST;
                                model.NetPrice = NetPrice;
                                if (NetPrice < Math.Round(model.InstallmentDetails.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = Math.Round(model.InstallmentDetails.Total) - NetPrice;
                                    ViewBag.sign = "+";
                                }
                                else if (NetPrice > Math.Round(model.InstallmentDetails.Total))
                                {
                                    flagR = true;
                                    model.RoundOff = NetPrice - Math.Round(model.InstallmentDetails.Total);
                                    ViewBag.sign = "-";
                                }
                                flag = false;
                            }
                            else
                            {
                                model.InstallmentDetails.Total = model.InstallmentDetails.Total;
                            }
                        }
                        if (flag == true)
                        {
                            ViewBag.taxstate = "CGSTSGST";
                        }
                        if (flagR == true)
                        {
                            ViewBag.Roundstate = "true";
                        }
                    }
                }
                else
                {
                    if (model.Currency == "INR")
                    {
                        bool flag = false;
                        bool flagR = false;
                        model.IGSTR = TaxUtility.TaxValue;
                        decimal Price = Math.Round(model.InstallmentDetails.Total / (model.IGSTR + 100) * 100);
                        decimal IGST = Math.Round((Price * model.IGSTR / 100), 2);

                        model.IGST = IGST;

                        NetPrice = Price + IGST;
                        model.NetPrice = NetPrice;
                        if (NetPrice < Math.Round(model.InstallmentDetails.Total))
                        {
                            flagR = true;
                            model.RoundOff = Math.Round(model.InstallmentDetails.Total) - NetPrice;
                            ViewBag.sign = "+";
                        }
                        else if (NetPrice > Math.Round(model.InstallmentDetails.Total))
                        {
                            flagR = true;
                            model.RoundOff = NetPrice - Math.Round(model.InstallmentDetails.Total);
                            ViewBag.sign = "-";
                        }
                        flag = true;

                        if (flagR == true)
                        {
                            ViewBag.Roundstate = "true";
                        }
                    }
                    else
                    {
                        bool flagR = false;

                        if (NetPrice < Math.Round(model.InstallmentDetails.Total))
                        {
                            flagR = true;
                            model.RoundOff = Math.Round(model.InstallmentDetails.Total) - NetPrice;
                            ViewBag.sign = "+";
                        }
                        else if (NetPrice > Math.Round(model.InstallmentDetails.Total))
                        {
                            flagR = true;
                            model.RoundOff = NetPrice - Math.Round(model.InstallmentDetails.Total);
                            ViewBag.sign = "-";
                        }
                        if (flagR == true)
                        {
                            ViewBag.Roundstate = "true";
                        }
                        model.InstallmentDetails.NetPrice = model.InstallmentDetails.Total;
                    }
                }
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                model.StateCode = model.StateCode != null ? model.StateCode : "";
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                //ViewBag.taxstate = "";
                ViewBag.Amount = Math.Round(model.Total);
                //ViewBag.sign = "";
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }



        [HttpGet]
        public ActionResult GenerateInvoice(int id = 0)
        {
            try
            {
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                decimal NetPrice = 0;
                TransactionDTO PaymentMaster = UOF.IAdminMaster.GetTransactionInvoiceById(id, false);
                if (PaymentMaster.StateCode != null)
                {

                    //TransactionDTO PaymentMaster = model;
                    PaymentMaster.CGSTPercent = 0;
                    PaymentMaster.IGSTPercent = 0;
                    PaymentMaster.SGSTPercent = 0;
                    PaymentMaster.CGST = 0;
                    PaymentMaster.SGST = 0;
                    PaymentMaster.IGST = 0;
                    PaymentMaster.RoundOff = 0;
                    PaymentMaster.Total = PaymentMaster.Total;
                    var tax = UOF.IAdminMaster.getTaxRateCode(PaymentMaster.StateCode);

                    var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                    if (tax != null)
                    {
                        PaymentMaster.StateCode = tax.Select(x => x.StateCode).FirstOrDefault();
                        if (GSTDNT == tax.Select(x => x.StateCode).FirstOrDefault())
                        {
                            ViewBag.taxstate = "CGSTSGST";
                            PaymentMaster.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                            PaymentMaster.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                            PaymentMaster.CGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.CGSTPercent) / 100, 2);
                            PaymentMaster.SGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.SGSTPercent) / 100, 2);
                            PaymentMaster.Price = Math.Round(PaymentMaster.NetPrice + PaymentMaster.CGST + PaymentMaster.SGST, 2);
                            PaymentMaster.ServiceTaxPercentage = PaymentMaster.CGSTPercent + PaymentMaster.SGSTPercent;
                            PaymentMaster.ServiceTax = PaymentMaster.CGST + PaymentMaster.SGST;

                        }
                        else
                        {
                            PaymentMaster.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                            PaymentMaster.IGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.IGSTPercent) / 100, 2);
                            PaymentMaster.Price = Math.Round((PaymentMaster.NetPrice + PaymentMaster.IGST), 2);

                        }


                        if (PaymentMaster.Total > PaymentMaster.Price)
                        {
                            PaymentMaster.RoundOff = PaymentMaster.Total - PaymentMaster.Price;
                        }
                        else if (PaymentMaster.Total < PaymentMaster.Price)
                        {
                            PaymentMaster.RoundOff = PaymentMaster.Price - PaymentMaster.Total;
                        }
                    }
                }

                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                PaymentMaster.StateCode = PaymentMaster.StateCode != null ? PaymentMaster.StateCode : "";
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                //ViewBag.taxstate = "";
                ViewBag.Amount = Math.Round(PaymentMaster.Total);
                //ViewBag.sign = "";
                return View(PaymentMaster);
            }
            catch (Exception ex)
            {
            }
            return null;
        }
        [HttpPost]
        public ActionResult GenerateInvoice(TransactionDTO data)
        {
            try
            {
                int tid = (int)data.Id;
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                decimal NetPrice = 0;
                TransactionDTO PaymentMaster = UOF.IAdminMaster.GetTransactionInvoiceById(tid, false);
                PaymentMaster.StateCode = PaymentMaster.StateCode != null ? data.StateCode : PaymentMaster.StateCode;
                if (PaymentMaster.StateCode != null)
                {

                    //TransactionDTO PaymentMaster = model;
                    PaymentMaster.CGSTPercent = 0;
                    PaymentMaster.IGSTPercent = 0;
                    PaymentMaster.SGSTPercent = 0;
                    PaymentMaster.CGST = 0;
                    PaymentMaster.SGST = 0;
                    PaymentMaster.IGST = 0;
                    PaymentMaster.RoundOff = 0;
                    PaymentMaster.Total = PaymentMaster.Total;
                    var tax = UOF.IAdminMaster.getTaxRateCode(PaymentMaster.StateCode);

                    var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                    if (tax != null)
                    {
                        PaymentMaster.StateCode = tax.Select(x => x.StateCode).FirstOrDefault();
                        if (GSTDNT == tax.Select(x => x.StateCode).FirstOrDefault())
                        {
                            ViewBag.taxstate = "CGSTSGST";
                            PaymentMaster.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                            PaymentMaster.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                            PaymentMaster.CGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.CGSTPercent) / 100, 2);
                            PaymentMaster.SGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.SGSTPercent) / 100, 2);
                            PaymentMaster.Price = Math.Round(PaymentMaster.NetPrice + PaymentMaster.CGST + PaymentMaster.SGST, 2);
                            PaymentMaster.ServiceTaxPercentage = PaymentMaster.CGSTPercent + PaymentMaster.SGSTPercent;
                            PaymentMaster.ServiceTax = PaymentMaster.CGST + PaymentMaster.SGST;

                        }
                        else
                        {
                            PaymentMaster.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                            PaymentMaster.IGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.IGSTPercent) / 100, 2);
                            PaymentMaster.Price = Math.Round((PaymentMaster.NetPrice + PaymentMaster.IGST), 2);

                        }


                        if (PaymentMaster.Total > PaymentMaster.Price)
                        {
                            PaymentMaster.RoundOff = PaymentMaster.Total - PaymentMaster.Price;
                        }
                        else if (PaymentMaster.Total < PaymentMaster.Price)
                        {
                            PaymentMaster.RoundOff = PaymentMaster.Price - PaymentMaster.Total;
                        }
                    }
                }

                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                PaymentMaster.StateCode = PaymentMaster.StateCode != null ? PaymentMaster.StateCode : "";
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                //ViewBag.taxstate = "";
                ViewBag.Amount = Math.Round(PaymentMaster.Total);
                //ViewBag.sign = "";
                return View(PaymentMaster);
            }
            catch (Exception ex)
            {
            }
            return null;
        }
        [HttpPost]
        public ActionResult SaveInvoice(PaymentDTO data)
        {
            try
            {
                PaymentDTO model = UOF.IAdminMaster.GetPaymentDetailsById(data.Id);
                bool status = UOF.IAdminMaster.saveInvoiceDataOld(model, data, CurrentUser.UserId);
                var tax = UOF.IAdminMaster.getTaxRate(data.StateId);
                var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();

                if (status == true)
                {
                    return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }
        // [HttpPost]
        //public ActionResult saveChildInvoice(PaymentDTO data)
        //{
        //    try
        //    {
        //        PaymentDTO model = UOF.IAdminMaster.GetPaymentChildDetailsById(data.Id);
        //        bool status = UOF.IAdminMaster.saveInvoiceData(model, data, CurrentUser.UserId);
        //        var tax = UOF.IAdminMaster.getTaxRate(data.StateId);
        //        var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
        //        ViewBag.PANDNT = TaxUtility.PANDNT;
        //        ViewBag.GSTDNT = TaxUtility.GSTDNT;
        //        ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();

        //        if (status == true)
        //        {
        //            return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
        //        }
        //        else
        //        {
        //            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public ActionResult UpdateInvoice(PaymentDTO data)
        {
            try
            {
                Session["editpage"] = "";
                var tax = UOF.IAdminMaster.getTaxRate(data.StateId);
                var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                if (tax != null)
                {
                    if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                    {
                        data.IGST = 0.0m;
                    }
                }
                bool status = UOF.IAdminMaster.UpdateInvoiceData(data, CurrentUser.UserId);
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                if (status == true)
                {
                    return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SaveInvoiceDetails(TransactionDTO data)
        {
            try
            {

                TransactionDTO model;
                if (data.IsInstallment == true)
                {
                    model = UOF.IAdminMaster.GetTransactionInvoiceForInstallmentById(data.Id, data.InstallmentID, false);
                }
                else
                {
                    model = UOF.IAdminMaster.GetTransactionInvoiceById(data.Id, false);
                }

                bool status = UOF.IAdminMaster.saveInvoiceDetails(model, data, CurrentUser.UserId);
                var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();

                if (status == true)
                {
                    return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult UpdateInvoiceDetails(TransactionDTO data)
        {
            try
            {
                Session["editpage"] = "";

                bool status = UOF.IAdminMaster.UpdateInvoiceDetails(data, CurrentUser.UserId);
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                if (status == true)
                {
                    return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult CancelInvoiceDetails(TransactionDTO data)
        {
            try
            {
                Session["editpage"] = "";

                bool status = UOF.IAdminMaster.CancelInvoiceDetails(data, CurrentUser.UserId);
                if (status == true)
                {
                    return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult CancelInstallmentInvoiceDetails(TransactionDTO data)
        {
            try
            {
                Session["editpage"] = "";

                bool status = UOF.IAdminMaster.CancelInstallmentInvoiceDetails(data, CurrentUser.UserId);
                if (status == true)
                {
                    return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult PrintInvoiceDetails(int id = 0, int page = 0)
        {
            try
            {
                ViewBag.page = page;
                //need to check method with KP
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceById(id, true);
                string TransactionId = model.TransactionId;

                if (model != null)
                {
                    var invoicedet = UOF.IAdminMaster.GetInvoiceDetailsById(TransactionId);
                    model.CGST = invoicedet.CGST;
                    model.SGST = invoicedet.SGST;
                    model.IGST = invoicedet.IGST;
                    model.PAN = invoicedet.PAN;
                    model.GST = invoicedet.GSTIN;

                    if (model.Currency == "INR")
                    {
                        int stcode = Convert.ToInt32(model.StateCode);
                        if (stcode > 0)
                        {
                            var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                            var GSTDNT = Convert.ToInt32(TaxUtility.GSTDNT.Substring(0, 2));

                            if (tax != null)
                            {
                                if (stcode == GSTDNT)
                                {
                                    ViewBag.taxstate = "CGSTSGST";
                                    model.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                                    model.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                                    model.CGST = Math.Round((model.NetPrice * model.CGSTPercent) / 100, 2);
                                    model.SGST = Math.Round((model.NetPrice * model.SGSTPercent) / 100, 2);
                                    model.Price = Math.Round(model.NetPrice + model.CGST + model.SGST, 2);
                                }
                                else
                                {
                                    ViewBag.taxstate = "";
                                    model.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                                    model.IGST = Math.Round((model.NetPrice * model.IGSTPercent) / 100, 2);
                                    model.Price = Math.Round((model.NetPrice + model.IGST), 2);
                                }
                            }
                        }

                        //roundoff
                        if (model.Total > model.Price)
                        {
                            model.RoundOff = model.Total - model.Price;
                        }
                        else if (model.Total < model.Price)
                        {
                            model.RoundOff = model.Price - model.Total;
                        }
                    }
                }
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        [HttpGet]
        [Route("PrintInvoiceDetailsByInstallment/{id}/{insId}")]
        public ActionResult PrintInvoiceDetailsByInstallment(int id = 0, int insId = 0, int page = 0)
        {
            try
            {
                ViewBag.page = page;
                //need to check method with KP
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceForInstallmentById(id, insId, true);
                string TransactionId = model.InstallmentDetails.UID;
                if (model != null)
                {
                    var invoicedet = UOF.IAdminMaster.GetInvoiceDetailsById(TransactionId);
                    model.CGST = invoicedet.CGST;
                    model.SGST = invoicedet.SGST;
                    model.IGST = invoicedet.IGST;
                    model.PAN = invoicedet.PAN;
                    model.GST = invoicedet.GSTIN;
                    model.NetPrice = model.InstallmentDetails.NetPrice;
                    model.Price = invoicedet.Price;
                    model.Total = invoicedet.Total;

                    if (model.Currency == "INR")
                    {
                        int stcode = Convert.ToInt32(model.StateCode);
                        if (stcode > 0)
                        {
                            var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                            var GSTDNT = Convert.ToInt32(TaxUtility.GSTDNT.Substring(0, 2));

                            if (tax != null)
                            {
                                if (stcode == GSTDNT)
                                {
                                    ViewBag.taxstate = "CGSTSGST";
                                    model.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                                    model.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                                    model.CGST = Math.Round((model.NetPrice * model.CGSTPercent) / 100, 2);
                                    model.SGST = Math.Round((model.NetPrice * model.SGSTPercent) / 100, 2);
                                    model.Price = Math.Round(model.NetPrice + model.CGST + model.SGST, 2);
                                }
                                else
                                {
                                    ViewBag.taxstate = "";
                                    model.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                                    model.IGST = Math.Round((model.NetPrice * model.IGSTPercent) / 100, 2);
                                    model.Price = Math.Round((model.NetPrice + model.IGST), 2);
                                }
                            }
                        }

                        //roundoff
                        if (model.Total > model.Price)
                        {
                            model.RoundOff = model.Total - model.Price;
                        }
                        else if (model.Total < model.Price)
                        {
                            model.RoundOff = model.Price - model.Total;
                        }
                    }
                    return View(model);
                }
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        //todo:delete
        [HttpPost]
        public ActionResult PrintInvoiceDetails(TransactionDTO data)
        {
            try
            {
                int idd = (int)data.Id;
                TransactionDTO model = UOF.IAdminMaster.GetTransactionInvoiceById(idd, true);
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                if (model != null)
                {

                    var invoicedet = UOF.IAdminMaster.GetInvoiceDetailsById(model.TransactionId);
                    model.CGST = invoicedet.CGST;
                    model.SGST = invoicedet.SGST;
                    model.IGST = invoicedet.IGST;
                    model.PAN = invoicedet.PAN;
                    model.GST = invoicedet.GSTIN;

                    int stcode = Convert.ToInt32(data.StateCode);
                    if (stcode > 0)
                    {
                        model.StateCode = UOF.IAdminMaster.getTaxRate(stcode).Select(x => x.StateCode).FirstOrDefault();

                        var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                        var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                        ViewBag.PANDNT = TaxUtility.PANDNT;
                        ViewBag.GSTDNT = TaxUtility.GSTDNT;
                        bool flag = false;
                        if (tax != null)
                        {
                            model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                            var stateCode = tax.Select(x => x.StateCode).FirstOrDefault();

                            //up state
                            if (stateCode == GSTDNT)
                            {
                                if (model.Currency == "INR")
                                {
                                    model.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                                    model.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                                    model.CGST = Math.Round((model.NetPrice * model.CGSTPercent) / 100, 2);
                                    model.SGST = Math.Round((model.NetPrice * model.SGSTPercent) / 100, 2);
                                    model.Price = Math.Round(model.NetPrice + model.CGST + model.SGST, 2);
                                    model.ServiceTaxPercentage = model.CGSTPercent + model.SGSTPercent;
                                    model.ServiceTax = model.CGST + model.SGST;
                                    flag = true;
                                    if (model.Total > model.Price)
                                    {
                                        model.RoundOff = model.Total - model.Price;
                                    }
                                    else if (model.Total < model.Price)
                                    {
                                        model.RoundOff = model.Price - model.Total;
                                    }
                                }
                                else
                                {
                                    model.Total = model.Total;
                                }
                            }
                            //other states
                            else
                            {
                                if (model.Currency == "INR")
                                {
                                    model.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                                    model.IGST = Math.Round((model.NetPrice * model.IGSTPercent) / 100, 2);
                                    model.Price = Math.Round((model.NetPrice + model.IGST), 2);
                                    flag = false;
                                    if (model.Total > model.Price)
                                    {
                                        model.RoundOff = model.Total - model.Price;
                                    }
                                    else if (model.Total < model.Price)
                                    {
                                        model.RoundOff = model.Price - model.Total;
                                    }
                                }
                                else
                                {
                                    model.Total = model.Total;
                                }
                            }
                            if (flag == true)
                            {
                                ViewBag.taxstate = "CGSTSGST";
                            }
                        }
                    }
                }
                else
                {
                    ViewBag.taxstate = "";
                }

                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                Session["editpage"] = "True";
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        //todo:delete
        [HttpPost]
        public ActionResult PrintInvoiceDetailsByInstallment(TransactionDTO data)
        {
            try
            {
                Session["editpage"] = ""; ViewBag.Roundstate = "";
                TransactionDTO model;
                string TransactionId;

                model = UOF.IAdminMaster.GetTransactionInvoiceForInstallmentById(data.Id, data.InstallmentID, true);
                TransactionId = model.InstallmentDetails.UID;

                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                if (model != null)
                {

                    var invoicedet = UOF.IAdminMaster.GetInvoiceDetailsById(TransactionId);
                    model.CGST = invoicedet.CGST;
                    model.SGST = invoicedet.SGST;
                    model.IGST = invoicedet.IGST;
                    model.PAN = invoicedet.PAN;
                    model.GST = invoicedet.GSTIN;

                    int stcode = Convert.ToInt32(data.StateCode);
                    if (stcode > 0)
                    {
                        model.StateCode = UOF.IAdminMaster.getTaxRate(stcode).Select(x => x.StateCode).FirstOrDefault();

                        var tax = UOF.IAdminMaster.getTaxRateCode(model.StateCode);
                        var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                        ViewBag.PANDNT = TaxUtility.PANDNT;
                        ViewBag.GSTDNT = TaxUtility.GSTDNT;
                        bool flag = false;
                        if (tax != null)
                        {
                            model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                            if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                            {
                                if (model.Currency == "INR")
                                {
                                    model.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                                    model.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                                    model.CGST = Math.Round((model.InstallmentDetails.NetPrice * model.CGSTPercent) / 100, 2);
                                    model.SGST = Math.Round((model.InstallmentDetails.NetPrice * model.SGSTPercent) / 100, 2);
                                    model.Price = Math.Round(model.InstallmentDetails.NetPrice + model.CGST + model.SGST, 2);
                                    model.ServiceTaxPercentage = model.CGSTPercent + model.SGSTPercent;
                                    model.ServiceTax = model.CGST + model.SGST;
                                    flag = true;
                                    if (model.InstallmentDetails.Total > model.Price)
                                    {
                                        model.RoundOff = model.InstallmentDetails.Total - model.Price;
                                    }
                                    else if (model.InstallmentDetails.Total < model.Price)
                                    {
                                        model.RoundOff = model.Price - model.InstallmentDetails.Total;
                                    }
                                }
                                else
                                {
                                    model.Total = model.InstallmentDetails.Total;
                                }
                            }
                            else
                            {
                                if (model.Currency == "INR")
                                {
                                    model.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                                    model.IGST = Math.Round((model.InstallmentDetails.NetPrice * model.IGSTPercent) / 100, 2);
                                    model.Price = Math.Round((model.InstallmentDetails.NetPrice + model.IGST), 2);
                                    flag = false;
                                    if (model.InstallmentDetails.Total > model.Price)
                                    {
                                        model.RoundOff = model.InstallmentDetails.Total - model.Price;
                                    }
                                    else if (model.InstallmentDetails.Total < model.Price)
                                    {
                                        model.RoundOff = model.Price - model.InstallmentDetails.Total;
                                    }
                                }
                                else
                                {
                                    model.Total = model.InstallmentDetails.Total;
                                }
                            }
                            if (flag == true)
                            {
                                ViewBag.taxstate = "CGSTSGST";


                            }
                        }
                    }
                }
                else { ViewBag.taxstate = ""; }
                ViewBag.Amount = Math.Round(model.InstallmentDetails.Total);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };

                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }

        [HttpGet]
        public ActionResult PrintEditInvoice(int id = 0)
        {
            try
            {
                Session["editpage"] = ""; ViewBag.Roundstate = "";
                PaymentDTO model = UOF.IAdminMaster.GetPaymentInvoiceById(id);
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                if (model != null)
                {
                    if (model.StateTaxId > 0)
                    {
                        var tax = UOF.IAdminMaster.getTaxRateDetails(model.StateTaxId);

                        model.CGSTR = tax.CGST;
                        model.SGSTR = tax.CGST;
                        model.IGSTR = tax.IGST;

                        if (model.IGST == 0.00M)
                        {
                            ViewBag.taxstate = "CGSTSGST";
                        }
                    }
                    if (model.RoundOff == 0.00m)
                    {
                        ViewBag.Roundstate = "";
                    }
                    else { ViewBag.Roundstate = "true"; }
                }
                else { ViewBag.taxstate = ""; }
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };

                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }
        [HttpPost]
        public ActionResult PrintEditInvoice(PaymentDTO data)
        {
            try
            {
                PaymentDTO model = UOF.IAdminMaster.GetPaymentInvoiceById(data.Id);
                var tax = UOF.IAdminMaster.getTaxRate(data.StateId);
                var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                bool flag = false;
                bool flagR = false;
                if (tax != null)
                {
                    model.StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                    model.RoundOff = 0.00m;
                    if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                    {
                        if (model.Currency == "INR")
                        {

                            model.CGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                            model.SGSTR = tax.Select(x => x.CGST).FirstOrDefault();
                            model.Price = Math.Round(model.Total / (model.CGSTR + model.SGSTR + 100) * 100, 2);
                            decimal CGST = Math.Round((model.Price * tax.Select(x => x.CGST).FirstOrDefault() / 100), 2);
                            decimal SGST = Math.Round((model.Price * tax.Select(x => x.SGST).FirstOrDefault() / 100), 2);
                            model.CGST = CGST;
                            model.SGST = SGST;
                            model.NetPrice = Math.Round((model.Price + CGST + SGST), 2);

                            if (model.Total > (model.Price + model.CGST + model.SGST))
                            {
                                flagR = true;
                                model.RoundOff = model.Total - (model.Price + model.CGST + model.SGST);
                            }
                            else if (model.Total < (model.Price + model.CGST + model.SGST))
                            {
                                flagR = true;
                                model.RoundOff = (model.Price + model.CGST + model.SGST) - model.Total;
                            }
                            flag = true;
                        }
                        else
                        {
                            model.Total = model.Total;
                        }
                    }
                    else
                    {
                        if (model.Currency == "INR")
                        {

                            model.IGSTR = tax.Select(x => x.IGST).FirstOrDefault();
                            model.Price = Math.Round(model.Total / (model.IGSTR + 100) * 100, 2);
                            decimal IGST = Math.Round((model.Price * model.IGSTR / 100), 2);

                            model.IGST = IGST;

                            model.NetPrice = Math.Round((model.Price + IGST), 2);
                            if (model.Total > (model.Price + model.IGST))
                            {
                                flagR = true;
                                model.RoundOff = model.Total - (model.Price + model.IGST);
                            }
                            else if (model.Total < (model.Price + model.IGST))
                            {
                                flagR = true;
                                model.RoundOff = (model.Price + model.IGST) - model.Total;
                            }
                            flag = false;
                        }
                        else
                        {
                            model.Total = model.Total;
                        }
                    }
                    if (flag == true)
                    {
                        ViewBag.taxstate = "CGSTSGST";
                    }
                    if (flagR == true)
                    {
                        ViewBag.Roundstate = "true";
                    }

                }
                IEnumerable<EnumInvoiceType> InTypelist = Enum.GetValues(typeof(EnumInvoiceType))
                                                     .Cast<EnumInvoiceType>();
                ViewBag.InvoiceTypelist = from action in InTypelist
                                          select new SelectListItem
                                          {
                                              Text = action.ToString(),
                                              Value = ((int)action).ToString()
                                          };
                Session["editpage"] = "True";
                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }
        [HttpGet]
        public ActionResult CreateCashPayment()
        {
            ViewBag.Message = "";
            ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
            IEnumerable<EnumPaymentMode> InPayTypelist = Enum.GetValues(typeof(EnumPaymentMode))
                                                    .Cast<EnumPaymentMode>();
            ViewBag.InPayTypelist = from action in InPayTypelist
                                    where (action.ToString() != "PayPal" && action.ToString() != "PayUMoney")
                                    select new SelectListItem
                                    {
                                        Text = action.ToString(),
                                        Value = action.ToString()
                                    };
            return View();
        }
        [HttpPost]
        public ActionResult CreateCashPayment(PaymentDTO data)
        {
            ViewBag.Message = "";
            ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();
            data.PaymentId = Utility.GenerateUniqueNo();
            data.TransactionId = Utility.GenerateUniqueNo();
            data.CreatedBy = (int)CurrentUser.UserId;
            var tax = UOF.IAdminMaster.getTaxRate(data.StateId);
            var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);

            if (tax != null)
            {
                var StateTaxId = (int)tax.Select(x => x.STid).FirstOrDefault();
                if (tax.Select(x => x.StateCode).FirstOrDefault() == GSTDNT)
                {
                    decimal CGST = (data.Total * tax.Select(x => x.CGST).FirstOrDefault() / 100);
                    decimal SGST = (data.Total * tax.Select(x => x.SGST).FirstOrDefault() / 100);
                    data.Price = data.Total - (CGST + SGST);

                }
                else
                {
                    decimal IGST = (data.Total * tax.Select(x => x.IGST).FirstOrDefault() / 100);
                    data.Price = data.Total - IGST;

                }
            }
            //data.Total = totalPrice;
            bool result = UOF.IAdminMaster.CreateCashPayment(data);
            ModelState.Clear();
            ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
            IEnumerable<EnumPaymentMode> InPayTypelist = Enum.GetValues(typeof(EnumPaymentMode))
                                                    .Cast<EnumPaymentMode>();
            ViewBag.InPayTypelist = from action in InPayTypelist
                                    where (action.ToString() != "PayPal" && action.ToString() != "PayUMoney")
                                    select new SelectListItem
                                    {
                                        Text = action.ToString(),
                                        Value = action.ToString()
                                    };
            return View();
        }


        public ActionResult CashPaymentRefund(int page = 1, string textsrch = "", string Date = "")
        {
            ViewBag.Message = "";
            try
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                PagingDTO<PaymentDTO> model = new PagingDTO<PaymentDTO>();
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }

                ViewBag.PaymentDetailsList = "CashPaymentRefund";
                model = UOF.IAdminMaster.GetCashPaymentRefundList(page, pageSize, textsrch, startDate, endDate);
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View(model);
            }
            catch (Exception ex)
            {
                // Response.Write(ex);
            }
            IEnumerable<EnumPaymentMode> InPayTypelist = Enum.GetValues(typeof(EnumPaymentMode))
                                                    .Cast<EnumPaymentMode>();
            ViewBag.InPayTypelist = from action in InPayTypelist
                                    where (action.ToString() != "PayPal" && action.ToString() != "PayUMoney")
                                    select new SelectListItem
                                    {
                                        Text = action.ToString(),
                                        Value = action.ToString()
                                    };
            return View();
        }
        [HttpGet]
        public ActionResult CreatePaymentRefund()
        {
            IEnumerable<EnumPaymentMode> InPayTypelist = Enum.GetValues(typeof(EnumPaymentMode))
                                                    .Cast<EnumPaymentMode>();
            ViewBag.InPayTypelist = from action in InPayTypelist
                                    where (action.ToString() != "PayPal" && action.ToString() != "PayUMoney")
                                    select new SelectListItem
                                    {
                                        Text = action.ToString(),
                                        Value = action.ToString()
                                    };
            return View();
        }
        [HttpPost]
        public ActionResult CreatePaymentRefund(PaymentDTO data)
        {
            try
            {
                bool result = UOF.IAdminMaster.CreatePaymentRefund(data, CurrentUser.UserId);
                if (result == true)
                {
                    ViewBag.message = "Data has been updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.message = "Unable to save data this time. please try again later.";
                }
                IEnumerable<EnumPaymentMode> InPayTypelist = Enum.GetValues(typeof(EnumPaymentMode))
                                                      .Cast<EnumPaymentMode>();
                ViewBag.InPayTypelist = from action in InPayTypelist
                                        where (action.ToString() != "PayPal" && action.ToString() != "PayUMoney")
                                        select new SelectListItem
                                        {
                                            Text = action.ToString(),
                                            Value = action.ToString()
                                        };
            }
            catch (Exception w)
            {

            }

            return View();
        }


        public JsonResult GetRefundInvoice(long TransactionId)
        {

            PaymentDTO data = UOF.IAdminMaster.GetRefundInvoiceFromPaymentInvoice(TransactionId);
            if (data != null)
            {
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpGet]
        public ActionResult PrintRefundInvoice(int id = 0)
        {
            try
            {
                PaymentDTO model = UOF.IAdminMaster.GetPaymentRefundById(id);
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;

                return View(model);
            }
            catch (Exception ex)
            {
            }
            return null;
        }


        ////////////////
        public ActionResult AllTransactionDetailsList(int page = 1, int filterId = 1, string textsrch = "", string Date = "", int CourseId = 0, string Currency = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
           
            PagingDTO<TransactionDTO> model = new PagingDTO<TransactionDTO>();
            model = UOF.IAdminMaster.GetAllTransactionDetailsList(page, pageSize, filterId, textsrch, startDate, endDate, Currency, false, false, CourseId,null);

            ViewBag.AllTransactionDetailsList = "AllTransactionDetailsList";
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                    .Cast<EnumCurrency>();
            ViewBag.Currencylist = from action in Currencylist
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.ToString()
                                   };
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.SelectedValue = filterId;
            }
            return View(model);
        }

        public ActionResult AllPaymentDetailsList(int page = 1, int filterId = 1, string textsrch = "", string Date = "", int CourseId = 0, string Currency = "", string Source = "")

        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
            }
            else
            {
                startDate = DateTime.Today;
                endDate = DateTime.Today.AddDays(1);
            }
            ViewBag.AllTransactionDetailsList = "AllTransactionDetailsList";
            PagingDTO<TransactionDTO> model = new PagingDTO<TransactionDTO>();
            if (CurrentUser.Roles.Contains("Subadmin"))
            {
                //model = UOF.IAdminMaster.GetLimitedTransactionDetailsList(filterId, textsrch, CourseId);
            }
            else
            {
                model = UOF.IAdminMaster.GetAllTransactionDetailsList(page, pageSize, filterId, textsrch, startDate.Value, endDate.Value, Currency, true, false, CourseId,Source);

            }
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                    .Cast<EnumCurrency>();
            ViewBag.Currencylist = from action in Currencylist
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.ToString()
                                   };


            ViewBag.Sourcelist = AppDropDowns.GetPaymentSource();

            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.SelectedValue = filterId;
                decimal totalINR = 0m;
                decimal totalUSD = 0m;
                foreach (var item in model.Data)
                {
                    if (item.Currency == "INR")
                    {
                        totalINR += Math.Round(item.Total);
                    }
                    else
                    {
                        totalUSD += Math.Round(item.Total);
                    }
                }
                decimal NetPrice = 0m;
                if (totalINR > 0)
                    NetPrice = Math.Round(totalINR / (100 + TaxUtility.TaxValue) * 100, 2);

                ViewBag.TotalInrDisp = NetPrice;
                ViewBag.TotalUsdDisp = totalUSD;
                ViewBag.totalGstDisp = totalINR - NetPrice;
            }
            return View(model);
        }

        public ActionResult AllFreePaymentDetailsList(int page = 1, int filterId = 1, string textsrch = "", string Date = "", int CourseId = 0, string Currency = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.AllFreePaymentDetailsList = "AllFreePaymentDetailsList";
            PagingDTO<TransactionDTO> model = new PagingDTO<TransactionDTO>();
            if (CurrentUser.Roles.Contains("Subadmin"))
            {
                //model = UOF.IAdminMaster.GetLimitedTransactionDetailsList(filterId, textsrch, CourseId);
            }
            else
            {
                model = UOF.IAdminMaster.GetAllTransactionDetailsList(page, pageSize, filterId, textsrch, startDate, endDate, Currency, true, true, CourseId,null);
            }
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                    .Cast<EnumCurrency>();
            ViewBag.Currencylist = from action in Currencylist
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.ToString()
                                   };
            ViewBag.Sourcelist = AppDropDowns.GetPaymentSource();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.SelectedValue = filterId;
            }
            return View(model);
        }

        public ActionResult GetCourseForInstallemnt(int ID, int coursetype, string Currency)
        {
            try
            {
                CoursePriceDTO data;
                if (coursetype == 1)
                {
                    data = UOF.ICommonLogic.GetCoursePrices(ID, Currency);
                    data.AfterSale = data.AfterSale == 0 ? data.Price : data.AfterSale;
                }
                else
                {
                    data = UOF.ICommonLogic.GetCoursePricesSelf(ID, Currency);
                    data.AfterSale = data.AfterSale == 0 ? data.Price : data.AfterSale;
                }
                if (data != null)
                {
                    ModelState.Clear();
                    return Json(new { data = data, msg = "success" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { data = data, msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        ///////Quotations/////////////
        public ActionResult Quotations(int page = 1)
        {
            PagingDTO<Quotation> model = new PagingDTO<Quotation>();
            ViewBag.QuotationsList = "QuotationsList";
            model = UOF.IAdminMaster.GetAllQuotationsList(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult CreateQuotations()
        {
            Quotation model = new Quotation();
            try
            {
                string code = UOF.IAdminMaster.GetQuotationCode();
                if (code != null)
                {
                    string[] codenew = code.Split('/');
                    string codeno = codenew[0].Substring(3);
                    int codeCount = Convert.ToInt32(codeno);
                    if (codeCount != 9)
                    {
                        if (codeCount.ToString().Length == 1)
                        {
                            codeCount++;
                            code = "DNT0" + codeCount.ToString();
                        }
                        else
                        {
                            codeCount++;
                            code = "DNT" + codeCount.ToString();
                        }
                    }
                    else
                    {
                        codeCount++;
                        code = "DNT" + codeCount.ToString();
                    }


                }
                else { code = "DNT01"; }
                model.QuotationNo = code + "/" + DateTime.Now.ToString("dd/MM/yyyy");
                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                      .Cast<EnumCurrency>();
                ViewBag.Currencylist = from action in Currencylist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = action.ToString()
                                       };

            }
            catch (Exception ex)
            {
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult CreateQuotations(Quotation data)
        {
            Quotation model = new Quotation();
            try
            {
                bool status = UOF.IAdminMaster.saveQuotation(data);
                return RedirectToAction("CreateQuotations");

            }
            catch (Exception ex)
            {
            }
            return View(model);
        }

        public ActionResult EditQuotations(int Id = 0)
        {
            Quotation model = new Quotation();
            try
            {
                model = UOF.IAdminMaster.GetQuotationDetails(Id);

                ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                IEnumerable<EnumCurrency> Currencylist = Enum.GetValues(typeof(EnumCurrency))
                                                      .Cast<EnumCurrency>();
                ViewBag.Currencylist = from action in Currencylist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = action.ToString()
                                       };

            }
            catch (Exception ex)
            {
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult EditQuotations(Quotation data)
        {
            Quotation model = new Quotation();
            try
            {
                bool status = UOF.IAdminMaster.updateQuotation(data);
                return RedirectToAction("Quotations");

            }
            catch (Exception ex)
            {
            }
            return View(model);
        }

        public ActionResult AddCoursetoQuotation(int ParentId = 0)
        {
            try
            {
                QuotationsChild model = new QuotationsChild();
                model.ParentId = ParentId;
                ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
                List<QuotationsChild> dlist = new List<QuotationsChild>();
                dlist = UOF.IAdminMaster.Quotations_ChildDetaillist(model.ParentId);
                model.qchildlist = dlist;
                return View(model);
            }
            catch (Exception e)
            {

            }
            return null;
        }
        [HttpPost]
        public ActionResult AddCoursetoQuotation(QuotationsChild model)
        {
            try
            {
                bool status = UOF.IAdminMaster.AddCoursetoQuotation(model);
                return RedirectToAction("AddCoursetoQuotation", new { ParentId = model.ParentId });
            }
            catch (Exception e)
            {

            }
            return null;
        }
        public ActionResult DeleteCourseQuotation(long ParentId = 0, long Idd = 0)
        {
            try
            {
                bool status = UOF.IAdminMaster.DeleteCourseQuotation(ParentId, Idd);
                return RedirectToAction("AddCoursetoQuotation", new { ParentId = ParentId });
            }
            catch (Exception e)
            {

            }
            return null;
        }


        public ActionResult ViewQuotationdetails(long Id = 0)
        {
            try
            {
                QuotationsAndChildDTO model = new QuotationsAndChildDTO();
                model = UOF.IAdminMaster.PreviewQuotationdetails(Id);
                if (model.QuotationsChildList.Count > 0)
                {
                    ViewBag.Amount = model.QuotationsChildList.Sum(item => item.Price);
                }
                ViewBag.PANDNT = TaxUtility.PANDNT;
                ViewBag.GSTDNT = TaxUtility.GSTDNT;
                return View(model);
            }
            catch (Exception n)
            {
            }
            return null;
        }

        public ActionResult ReportView()
        {
            try
            {
                DateTime startDate = DateTime.Now.AddDays(-7);
                DateTime endDate = DateTime.Now;

                SalesReportMasterDTO model = new SalesReportMasterDTO();
                model = UOF.IAdminMaster.spr_ProfitView(startDate, endDate);
                return View(model);
            }
            catch (Exception e)
            {
            }
            return View();
        }

        [HttpPost]
        public ActionResult ReportView(string Date = "")
        {
            try
            {
                DateTime startDate = DateTime.Now.AddDays(-7);
                DateTime endDate = DateTime.Now;
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                SalesReportMasterDTO model = new SalesReportMasterDTO();
                model = UOF.IAdminMaster.spr_ProfitView(startDate, endDate);
                return View(model);
            }
            catch (Exception e)
            {
            }
            return View();
        }

        [HttpPost]
        public JsonResult DownloadAllPaymentsToExcel(string Date = "", string textsrch = "", string Currency = "")
        {
            List<TransactionDTO> report = new List<TransactionDTO>();
            try
            {

                DateTime? startDate = null;
                DateTime? endDate = null;
                ViewBag.PaymentList = "PaymentList";
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                else
                {
                    startDate = DateTime.Today;
                    endDate = DateTime.Today.AddDays(1);
                }

                var getreport = UOF.IAdminMaster.DownloadAllPaymentsToExcel(textsrch, startDate.Value, endDate.Value, Currency); ;

                if (getreport != null)
                {
                    report = getreport;
                }
                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string ReportName = "PaymentReport" + time + ".xlsx";
                string fileName = ReportName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);

                    objReceiving.GetReceivingAllPaymentsReport(stream, report, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
