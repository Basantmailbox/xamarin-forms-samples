﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class AppSettingController : BaseController
    {
        public string ImgCloudPath = "";

        int pageSize;
        public AppSettingController()
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }

        

        public ActionResult Index(int page = 1)
        {
            PagingDTO<AppSetting> model = new PagingDTO<AppSetting>();
            ViewBag.CategoryList = "AppSettingList";
            model = UOF.IAppSetting.GetMany(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult InsertEntity()
        {
            return View();
        }
        
            [HttpPost]
        public ActionResult InsertEntity(AppSetting appSettingObj)
        {
            if (appSettingObj.AppSettingId == 0)
            {
                UOF.IAppSetting.InsertEntity(appSettingObj);
                return RedirectToAction("Index");
            }
            return View(appSettingObj);
        }

        [HttpGet]
        public ActionResult EditEntity(int appSettingId)
        {
            AppSetting model = UOF.IAppSetting.GetById(appSettingId);
            return View(model);
        }
        [HttpPost]
        public ActionResult EditEntity(AppSetting appSettingObj)
        {
            if (appSettingObj.AppSettingId > 0)
            {
                UOF.IAppSetting.UpdateEntity(appSettingObj);
               return RedirectToAction("Index");
            }
            return View(appSettingObj);
        }

        
    }
}
