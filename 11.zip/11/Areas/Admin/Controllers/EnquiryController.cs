﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebUI.Models;
using System.Net;
using OfficeOpenXml;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class EnquiryController : BaseController
    {

        // SmsRepository smsRepo = new SmsRepository();
        int pageSize;

        public EnquiryController()
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }

        private void QueryFollowupModalData()
        {
            //for modal popup
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            var Enquires = UOF.IEnquiryType.GetAll().ToList();
            Enquires.RemoveAt(0);
            ViewBag.EnquiryTypes = Enquires;
            ViewBag.EnquiryStatus = UOF.IEnquiryStatus.GetAll();
            var Enquiresfollop = UOF.IEnquiryType.GetAll().Where(i => i.IsActive == true).OrderBy(i => i.Description).ToList();
            Enquiresfollop.RemoveAt(0);
            ViewBag.Enquiresfollop = Enquiresfollop;
        }

        public ActionResult Index()
        {
            return View();
        }

        //query filters logic
        public PartialViewResult AjaxFilterEnquiryList(int page = 1, int ProviderId = 0, int ModeId = 1, int CourseId = 0, string textsrch = "", String Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyBySearch(page, pageSize, textsrch);
                if (model == null) { model = new PagingEnquiryDTO<QueryDTO>(); }
                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetMany(page, pageSize, ModeId, CourseId, ProviderId, startDate, endDate, OTPCheck);
                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            List<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll().ToList();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.TypeIdSelectedValue = ProviderId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;
            ViewBag.TypeId = ProviderId;
            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryList", model2);
            }

            return PartialView("_EnquiryList", model);
        }
        public PartialViewResult AjaxFilterAllEnquiryList(int page = 1, int ProviderId = 0, int ModeId = 0, int CourseId = 0, string textsrch = "", int AdminId = 0, string Date = "", string DomainName = "", int OTPCheck = 2, int Etype = 0)
        {

            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetAllBySearch(page, pageSize, textsrch, Etype);
                ViewBag.totalNumber = model != null ? model.TotalRows.ToString() : "0";
            }
            else
            {
                model = UOF.IEnquiry.GetAll(page, pageSize, ModeId, CourseId, ProviderId, AdminId, startDate, endDate, DomainName, OTPCheck, Etype);
                ViewBag.totalNumber = model != null ? model.TotalRows.ToString() : "0";
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            List<AdminUserDTO> SalesUser = UOF.IAdminMaster.GetMany(5);
            ViewBag.AdminSelectedValue = AdminId;
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.TypeIdSelectedValue = ProviderId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;
            ViewBag.TypeId = ProviderId;
            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;

            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                ViewBag.page = 1;

                return PartialView("_AllEnquiryList", model2);
            }

            return PartialView("_AllEnquiryList", model);
        }

        //only rendering view
        public ActionResult EnquiryList()
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            return View();
        }
        public ActionResult AllEnquiryList()
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.AdminList = UOF.IAdminMaster.GetMany(5);
            //  ViewBag.TrainingModeList = UOF.IAdminMaster.GetTrainingModeListFull();
            return View();
        }


        public ActionResult DeleteBulk(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IQuery.DeleteBulk(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        [ChildActionOnly]
        public ActionResult AssignQueryToUser()
        {
            AssignQueryDTO model = new AssignQueryDTO();
            model.AdminUsers = UOF.IAdminMaster.GetMany(5);
            return PartialView("_AssignQuery", model);
        }
        [ChildActionOnly]
        public ActionResult ReAssignQueryToUser()
        {
            AssignQueryDTO model = new AssignQueryDTO();
            model.AdminUsers = UOF.IAdminMaster.GetMany(5);
            return PartialView("_ReAssignQuery", model);
        }

        [HttpPost]
        public ActionResult AssignQuery(AssignQueryDTO _assignQueryViewModel)
        {
            if (_assignQueryViewModel.AdminId != 0)
            {
                try
                {
                    UOF.IQuery.AssignQuery(_assignQueryViewModel);
                    // return RedirectToAction("AllEnquiryList");
                    return Json("success", JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    return Json("fail", JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json("fail", JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        public ActionResult ReAssignQuery(AssignQueryDTO _assignQueryViewModel)
        {
            if (_assignQueryViewModel.AdminId != 0)
            {
                try
                {
                    _assignQueryViewModel.AssignBy = (int)CurrentUser.UserId;
                    UOF.IQuery.ReAssignQuery(_assignQueryViewModel);
                    //  Session["FullQuryBySalesList"] = "FullQuryBySalesList";
                    return Json("success", JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    // return RedirectToAction("AllSalesManRptAdmin");
                }
                return Json("fail", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("fail", JsonRequestBehavior.AllowGet);
            }
        }
        [ValidateInput(false)]
        public ActionResult ReassignEnquiry(int page = 1, int ProviderId = 0, int AdminId = 0, string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();

            model = UOF.IEnquiry.GetManyAssigned(page, pageSize, ProviderId, AdminId, startDate, endDate);

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            if (model != null)
            {
                model.AdminUsers = UOF.IAdminMaster.GetMany(5);
                model.EnqTypeList = EnquiryTypeList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.AdminUsers = UOF.IAdminMaster.GetMany(5);
                model2.EnqTypeList = EnquiryTypeList;
                return View(model2);
            }
            return View(model);

        }
        public ActionResult AddEnquiry()
        {
            QuickFollowupQueryDTO queryModel = new QuickFollowupQueryDTO();
            //Bind Courses
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            queryModel.CourseList = courseList;

            //Bind Training Mode
            List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
            queryModel.TrainingModeList = trainingModeList;
            queryModel.NextFollowupDate = DateTime.Now;
            //batch

            //List<BatchMasterViewModel> BatchList = AppUnitOfWork.Admins.getCurAndUpComingBatchList();
            //queryModel.BatchMasterList = BatchList;
            ViewBag.msg = TempData["msg"];
            queryModel.QSubject = "Self Query";
            return View(queryModel);
        }


        public PartialViewResult AjaxFilterEnquiryNewList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.New, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.New, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryNewList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryNewList", model);
        }


        public PartialViewResult AjaxFilterEnquiryPendingList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.Pending, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.Pending, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryPendingList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryPendingList", model);
        }

        public PartialViewResult AjaxFilterEnquiryInterestedList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.Interested, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.Interested, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryInterestedList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryInterestedList", model);
        }

        public PartialViewResult AjaxFilterEnquiryNotInterestedList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.NotInterested, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.NotInterested, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryNotInterestedList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryNotInterestedList", model);
        }

        public ActionResult New()//1
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 1;
            ViewBag.tabmenu = "New";
            return View();
        }
        public ActionResult Interested()//2
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 2;
            ViewBag.tabmenu = "Interested";
            return View();
        }
        public ActionResult NotInterested()//3
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 3;
            ViewBag.tabmenu = "NotInterested";
            return View();
        }
        public ActionResult Pending(int page = 1) //4
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 4;
            ViewBag.tabmenu = "Pending";
            return View();

        }

        public ActionResult Fake()//5
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 5;
            ViewBag.tabmenu = "Fake";
            return View();
        }
        public ActionResult Demo()//6
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 6;
            ViewBag.tabmenu = "Demo";
            return View();
        }
        public ActionResult Closed()//7
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            QueryFollowupModalData();
            ViewBag.EnquiryTypesId = 7;
            return View();
        }
        public ActionResult Student()
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            return View();
        }
        public PartialViewResult AjaxFilterStudentList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.Completed, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.Completed, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryStudentList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryStudentList", model);
        }

        public PartialViewResult AjaxFilterEnquiryFakeList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.Fake, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.Fake, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryFakeList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryFakeList", model);
        }
        public PartialViewResult AjaxFilterEnquiryClosedList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.Closed, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.Closed, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryClosedList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryClosedList", model);
        }

        public PartialViewResult AjaxFilterEnquiryDemoList(int page = 1, int ModeId = 1, int CourseId = 0, string textsrch = "", int Batch = 0, string Date = "", int OTPCheck = 2)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            {
                page = 1;
                model = UOF.IEnquiry.GetManyByEnquiryType(page, pageSize, textsrch, EnumEnquiryType.Demo, Convert.ToInt32(CurrentUser.UserId));

                ViewBag.totalNumber = model.TotalRows.ToString();
            }
            else
            {
                model = UOF.IEnquiry.GetManyByNewEnquiry(page, pageSize, ModeId, CourseId, Batch, EnumEnquiryType.Demo, Convert.ToInt32(CurrentUser.UserId), startDate, endDate, OTPCheck);

                ViewBag.totalNumber = model.TotalRows.ToString();
            }

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();

            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                model2.Courses = courseList;
                return PartialView("_EnquiryDemoList", model2);
            }
            QueryFollowupModalData();
            return PartialView("_EnquiryDemoList", model);
        }
        //get remarks data on mouse over
        public JsonResult GetRemarksJ(string enquiryId)
        {
            List<QueryRemarkDTO> queryRemarkViewModel = UOF.IQueryRemark.GetByQueryC(Convert.ToInt32(enquiryId), Convert.ToInt32(CurrentUser.UserId));
            StringBuilder remarksStrc = new StringBuilder();
            if (queryRemarkViewModel.Count > 0)
            {
                ViewBag.countValue = queryRemarkViewModel.Count;
                remarksStrc.Append("<b style='Color:Red'>Comments</b>");
                remarksStrc.Append("</br>");
                foreach (QueryRemarkDTO queryRemarkVM in queryRemarkViewModel)
                {

                    remarksStrc.Append("<b>" + queryRemarkVM.UserName + "</b>" + " : ");
                    remarksStrc.Append(queryRemarkVM.FollowUpDate);
                    remarksStrc.Append("</br>" + queryRemarkVM.Remarks);

                    remarksStrc.Append("<hr style='margin-top: 0px;'/>");

                }
            }
            else
            {
                remarksStrc.Append("No Any Comments.");
                remarksStrc.Append("</br>");
                remarksStrc.Clear();
                ViewBag.countValue = 0;
            }

            List<QueryRemarkDTO> queryRemarkViewModel1 = UOF.IQueryRemark.GetByQuery(Convert.ToInt32(enquiryId), Convert.ToInt32(CurrentUser.UserId));

            if (queryRemarkViewModel1.Count > 0)
            {
                ViewBag.countValue = queryRemarkViewModel1.Count;
                remarksStrc.Append("<b style='Color:Red'>Remarks</b>");
                remarksStrc.Append("</br>");
                foreach (QueryRemarkDTO queryRemarkVM in queryRemarkViewModel1)
                {

                    remarksStrc.Append("<b>" + queryRemarkVM.UserName + "</b>" + " : ");
                    remarksStrc.Append(queryRemarkVM.FollowUpDate);
                    remarksStrc.Append("</br>" + queryRemarkVM.Remarks);

                    remarksStrc.Append("<hr style='margin-top: 0px;'/>");

                }
            }
            else
            {
                remarksStrc.Append("No Any Remarks.");
                remarksStrc.Append("</br>");
                ViewBag.countValue = 0;
            }
            return Json(remarksStrc.ToString(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetRemarksAdmin(string enquiryId)
        {
            List<QueryRemarkDTO> queryRemarkViewModel = UOF.IQueryRemark.GetByQueryCAdmin(Convert.ToInt32(enquiryId));
            StringBuilder remarksStrc = new StringBuilder();
            if (queryRemarkViewModel.Count > 0)
            {
                ViewBag.countValue = queryRemarkViewModel.Count;
                remarksStrc.Append("<b style='Color:Red'>Comments</b>");
                remarksStrc.Append("</br>");
                foreach (QueryRemarkDTO queryRemarkVM in queryRemarkViewModel)
                {

                    remarksStrc.Append("<b>" + queryRemarkVM.UserName + "</b>" + " : ");
                    remarksStrc.Append(queryRemarkVM.FollowUpDate);
                    remarksStrc.Append("</br>" + queryRemarkVM.Remarks);

                    remarksStrc.Append("<hr style='margin-top: 0px;'/>");

                }
            }
            else
            {
                remarksStrc.Append("No Any Comments.");
                remarksStrc.Append("</br>");
                remarksStrc.Clear();
                ViewBag.countValue = 0;
            }

            List<QueryRemarkDTO> queryRemarkViewModel1 = UOF.IQueryRemark.GetByQueryAdmin(Convert.ToInt32(enquiryId));

            if (queryRemarkViewModel1.Count > 0)
            {
                ViewBag.countValue = queryRemarkViewModel1.Count;
                remarksStrc.Append("<b style='Color:Red'>Remarks</b>");
                remarksStrc.Append("</br>");
                foreach (QueryRemarkDTO queryRemarkVM in queryRemarkViewModel1)
                {

                    remarksStrc.Append("<b>" + queryRemarkVM.UserName + "</b>" + " : ");
                    remarksStrc.Append(queryRemarkVM.FollowUpDate);
                    remarksStrc.Append("</br>" + queryRemarkVM.Remarks);

                    remarksStrc.Append("<hr style='margin-top: 0px;'/>");

                }
            }
            else
            {
                remarksStrc.Append("No Any Remarks.");
                remarksStrc.Append("</br>");
                ViewBag.countValue = 0;
            }
            return Json(remarksStrc.ToString(), JsonRequestBehavior.AllowGet);
        }
        ////
        //[HttpPost]
        //public ActionResult UpdateFollowup(QueryRemarkUpdateDTO queryRemarateUpdateVM, DateTime? Date = null)
        //{
        //       return Json("test", JsonRequestBehavior.AllowGet);
        //}


        //update followup status
        [HttpPost]
        public ActionResult UpdateFollowup(QueryRemarkUpdateDTO queryRemarateUpdateVM, DateTime? NextFollowupDate = null)
        {
            DateTime? Date = NextFollowupDate;
            queryRemarateUpdateVM.NextFollowupDate = Date != null ? Date.GetValueOrDefault() : queryRemarateUpdateVM.NextFollowupDate;
            queryRemarateUpdateVM.EnquiryTypeId = queryRemarateUpdateVM.EnquiryTypeIdf;
            queryRemarateUpdateVM.Batch = queryRemarateUpdateVM.Batchf;
            if (queryRemarateUpdateVM.QueryId > 0)
            {
                QueryRemarkDTO _queryRemarkViewModel = new QueryRemarkDTO();
                QueryDTO queryViewModel = new QueryDTO();
                queryViewModel.CourseId = queryRemarateUpdateVM.QCourseId;
                queryViewModel.EnquiryStatusId = queryRemarateUpdateVM.EnquiryStatusId != null ? (int)queryRemarateUpdateVM.EnquiryStatusId : 0;
                queryViewModel.EnquiryTypeId = (int)queryRemarateUpdateVM.EnquiryTypeId;
                queryViewModel.FollowUpDate = DateTime.UtcNow;
                if (queryRemarateUpdateVM.EnquiryTypeId == 6 || queryRemarateUpdateVM.EnquiryTypeId == 5 || queryRemarateUpdateVM.EnquiryTypeId == 7)
                {
                    queryViewModel.FollowUpDateNext = DateTime.UtcNow;
                }
                else
                {
                    queryViewModel.FollowUpDateNext = queryRemarateUpdateVM.NextFollowupDate;
                }
                queryViewModel.BatchId = queryRemarateUpdateVM.Batch;
                queryViewModel.ID = queryRemarateUpdateVM.QueryId;
                if (queryRemarateUpdateVM.EnquiryTypeId == 7)
                {
                    if (queryRemarateUpdateVM.Status == 8)
                    {
                        queryViewModel.EnquiryTypeId = queryRemarateUpdateVM.Status;
                    }
                    queryViewModel.CloseRemark = queryRemarateUpdateVM.Remarks;
                    queryViewModel.CloseFlag = (int)queryRemarateUpdateVM.OldEnquiryType;
                }

                UOF.IQuery.UpdateWithRemark(queryViewModel);
                if (queryRemarateUpdateVM.EnquiryTypeId == 6 || queryRemarateUpdateVM.EnquiryTypeId == 5 || queryRemarateUpdateVM.EnquiryTypeId == 7)
                {
                    _queryRemarkViewModel.NextFollowUpDate = DateTime.UtcNow;
                    _queryRemarkViewModel.RemarkType = 1;
                }
                else
                {
                    _queryRemarkViewModel.NextFollowUpDate = queryRemarateUpdateVM.NextFollowupDate;
                    _queryRemarkViewModel.RemarkType = queryRemarateUpdateVM.isremark;
                }

                _queryRemarkViewModel.QueryId = queryRemarateUpdateVM.QueryId;
                _queryRemarkViewModel.Remarks = queryRemarateUpdateVM.Remarks;
                _queryRemarkViewModel.BatchId = queryRemarateUpdateVM.Batch;
                _queryRemarkViewModel.UserId = Convert.ToInt32(CurrentUser.UserId);
                if (queryRemarateUpdateVM.Status == 8)
                {
                    queryRemarateUpdateVM.EnquiryTypeId = queryRemarateUpdateVM.Status;
                }
                _queryRemarkViewModel.EnquiryTypes = (int)queryRemarateUpdateVM.EnquiryTypeId;
                UOF.IQueryRemark.Insert(_queryRemarkViewModel);

                if (queryRemarateUpdateVM.RemarkUpdateBy == "FullQuryBySalesList")
                {
                    Session["RemarkUpdateBy"] = queryRemarateUpdateVM.RemarkUpdateBy;
                    return Json(queryRemarateUpdateVM.QueryId, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(queryRemarateUpdateVM.QueryId, JsonRequestBehavior.AllowGet);
                    // return RedirectToAction(queryRemarateUpdateVM.RemarkUpdateBy); //for redirection
                }
            }
            else
            {
                return Json(queryRemarateUpdateVM.QueryId, JsonRequestBehavior.AllowGet);
                // return RedirectToAction("New");
            }
        }

        //adding new query in db
        [HttpPost]
        public JsonResult SaveQuickFollowupEnquiry(QuickFollowupQueryDTO _quickQueryVM)
        {
            try
            {
                bool isQueryValid = UOF.IQuery.IsQEnquiryValid(_quickQueryVM.QEmailID, _quickQueryVM.QCourseId);
                if (isQueryValid)
                {
                    _quickQueryVM.UserId = (int)CurrentUser.UserId;
                    int queryId = UOF.IQuery.SaveQuickFollowupQuery(_quickQueryVM);
                    if (queryId >= 0)
                    {
                        QueryRemarkDTO _queryRemarkViewModel = new QueryRemarkDTO();

                        _queryRemarkViewModel.NextFollowUpDate = DateTime.UtcNow;
                        _queryRemarkViewModel.QueryId = queryId;
                        _queryRemarkViewModel.Remarks = _quickQueryVM.QRemarks;
                        _queryRemarkViewModel.UserId = Convert.ToInt32(CurrentUser.UserId);
                        _queryRemarkViewModel.BatchId = _quickQueryVM.BatchId;
                        UOF.IQueryRemark.Insert(_queryRemarkViewModel);
                    }

                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        public ActionResult BatchMappingAjax(int id)
        {
            List<BatchMasterDTO> BatchList = UOF.IAdminMaster.GetCurAndUpComingBatchList(id);
            // queryModel.BatchMasterList = BatchList;CourseId);
            return Json(BatchList, JsonRequestBehavior.AllowGet);
        }
        public ActionResult CheckRegisterMemberOrNot(string email)
        {
            long id = UOF.IMember.Check_Member_Email_Exists(email);
            if (id != 0)
            {
                return Json(new { msg = id }, JsonRequestBehavior.AllowGet);
            }
            else
            { return Json(new { msg = 0 }, JsonRequestBehavior.AllowGet); }
            // queryModel.BatchMasterList = BatchList;CourseId);

        }

        [HttpPost]
        public JsonResult RegisterMemberToBatch(QueryDTO model)
        {
            try
            {
                bool status = UOF.IQuery.MemberRegisteredToBatch(model);
                if (status == true)
                {
                    return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);

            }

        }
        [HttpPost]
        public JsonResult SaveClosingComments(QueryDTO comt)
        {
            try
            {
                bool status = UOF.IQuery.UpdateCommentsOnQuery(comt);
                if (status == true)
                {

                    return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);

            }

        }
        public ActionResult AllSalesManRpt()
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            //  ViewBag.CourseList = AppUnitOfWork.CommonLogics.GetCourseList();
            ViewBag.AdminList = UOF.IAdminMaster.GetMany(5);
            QueryFollowupModalData();
            return View();
        }
        public ActionResult AllSalesManRptAdmin()
        {
            ViewBag.EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.AdminList = UOF.IAdminMaster.GetMany(5);

            ViewBag.EnquiryStatus = UOF.IEnquiryStatus.GetAll();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            var Enquires = UOF.IEnquiryType.GetAll().ToList();

            ViewBag.EnquiryTypes = Enquires;
            ViewBag.EnquiryStatus = UOF.IEnquiryStatus.GetAll();
            var Enquiresfollop = UOF.IEnquiryType.GetAll().ToList();
            Enquiresfollop.RemoveAt(0);
            ViewBag.Enquiresfollop = Enquiresfollop;
            return View();
        }
        public PartialViewResult AjaxFilterAllSalesManRpt(int page = 1, int CourseId = 0, int Batch = 0, int AdminId = 0, string Date = "", string textsrch = "", int? EnquiryTypeId = null)
        {
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            if (!string.IsNullOrEmpty(textsrch))
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                if (textsrch != "" && textsrch != null)
                {
                    page = 1;
                    model = UOF.IEnquiry.GetAllSalesManReportBySearch(page, pageSize, textsrch);

                }
                else
                {
                    model = UOF.IEnquiry.GetAllSalesManReport(page, pageSize, AdminId, CourseId, Batch, startDate, endDate, textsrch, EnquiryTypeId);

                }

                IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

                List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.CourseSelectedValue = CourseId;
                ViewBag.CourseId = CourseId;

                if (model != null)
                {
                    ViewBag.totalNumber = model.TotalRows.ToString();
                    model.EnqTypeList = EnquiryTypeList;
                    model.Courses = courseList;
                    ViewBag.page = model.Page;
                }
                else
                {
                    PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                    model2.EnqTypeList = EnquiryTypeList;
                    model2.Courses = courseList;
                    return PartialView("_EnquirySalesManRpt", model2);
                }
            }
            QueryFollowupModalData();

            return PartialView("_EnquirySalesManRpt", model);
        }

        public PartialViewResult AjaxFilterAllSalesManRptAdmin(int page = 1, int CourseId = 0, int Batch = 0, int AdminId = 0, string Date = "", string textsrch = "", int? EnquiryTypeId = null, int ModeId = 0)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            QueryFollowupModalData();
            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.CourseId = CourseId;

            //var report = UOF.IAdminMaster.getSalesReport(startDate, endDate);

            if (EnquiryTypeId != null)
            {
                PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
                if (textsrch != "" && textsrch != null)
                {
                    page = 1;
                    model = UOF.IEnquiry.GetAllSalesManReportBySearch(page, pageSize, textsrch);

                }
                else
                {
                    model = UOF.IEnquiry.GetAllSalesManReport(page, pageSize, AdminId, CourseId, Batch, startDate, endDate, textsrch, EnquiryTypeId, ModeId);

                }

                if (model != null)
                {
                    ViewBag.totalNumber = model.TotalRows.ToString();
                    model.EnqTypeList = EnquiryTypeList;
                    ViewBag.page = model.Page;
                }
                return PartialView("_EnquirySalesManRptAdmin", model);
            }
            else
            {
                List<QueryDTO> model1 = new List<QueryDTO>();
                model1 = UOF.IEnquiry.GetAllSalesReportBySearch(page, pageSize, startDate, endDate, AdminId, ModeId, CourseId);
                return PartialView("_EnquirySalesAdminCount", model1);
            }

        }

        //[ChildActionOnly]
        //public ActionResult SendSmsToUsers()
        //{
        //    AssignQueryViewModel model = new AssignQueryViewModel();
        //    model.AdminUsers = AppUnitOfWork.Admins.GetMany(5);
        //    return PartialView("_AssignQuery", model);
        //}

        public ActionResult SendSMSToUsers()
        {
            SmsDetailDTO model = new SmsDetailDTO();
            return PartialView("_DemoSmsSend", model);
        }
        public JsonResult SendDemoSMS(SmsDetailDTO model)
        {
            bool status = UOF.ISms.SendSmsForDemo(model);
            if (status == true)
            {
                ViewBag.Message = "Message has been sent successfully";
                ModelState.Clear();
                return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                ViewBag.Message = "Message is not send";
                return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
            }
        }

        //public ActionResult AllSalesReport()
        //{
        //    ViewBag.EnquiryTypeList = AppUnitOfWork.EnquiryProviders.GetMany();
        //  //  ViewBag.CourseList = AppUnitOfWork.CommonLogics.GetCourseList();
        //    ViewBag.AdminList = AppUnitOfWork.Admins.GetMany(5);
        //    QueryFollowupModalData();
        //    return View();
        //}
        //public ActionResult AllSalesReport(int page = 1, string Date = "", string textsrch = "")
        //{
        //    DateTime? startDate = null;
        //    DateTime? endDate = null;
        //    if (!Date.Contains("Invalid") && Date != "")
        //    {
        //        string[] date = Date.Split('-');
        //        startDate = Convert.ToDateTime(date[0].Trim());
        //        endDate = Convert.ToDateTime(date[1].Trim());
        //    }
        //    List<QueryDTO> model = new List<QueryDTO>();

        //    model = UOF.IEnquiry.GetAllSalesReportBySearch(page, pageSize, startDate, endDate, textsrch);

        //    return View(model);
        //}

        public ActionResult GetAllQuryList(int page = 1, string usr = "", int AdminId = 0, string entype = "", string Date = "", int CourseId = 0, string textsrch = "")
        {
            try
            {
                PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                if (usr != "")
                {
                    AdminId = Convert.ToInt32(usr);
                    model.AdminId = Convert.ToInt32(usr);
                }
                else
                {

                    model.AdminId = AdminId;
                }
                model = UOF.IEnquiry.GetEnquiryReportList(page, pageSize, AdminId, entype, startDate, endDate, CourseId, textsrch);

                ViewBag.totalNumber = model.TotalRows.ToString();
                QueryFollowupModalData();
                return View("_GetAllQuryList", model);
            }
            catch (Exception e)
            {
                return View();
            }


        }

        public ActionResult GetFullQuryList(int page = 1, string usr = "", string DisDate = "", string textsrch = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!DisDate.Contains("Invalid") && DisDate != "")
            {
                string[] date = DisDate.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();

            model = UOF.IEnquiry.GetFullSalesManReport(page, pageSize, usr, startDate, endDate, textsrch);
            ViewBag.totalNumber = model.TotalRows.ToString();

            IEnumerable<EnquiryProvider> EnquiryTypeList = UOF.IEnquiryProvider.GetAll();

            if (model != null)
            {
                model.EnqTypeList = EnquiryTypeList;
                ViewBag.page = model.Page;
            }
            else
            {
                PagingEnquiryDTO<QueryDTO> model2 = new PagingEnquiryDTO<QueryDTO>();
                model2.EnqTypeList = EnquiryTypeList;
                return View(model2);
            }
            QueryFollowupModalData();
            return View(model);
        }
        public ActionResult ReferandEarnList(int page = 1, string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingEnquiryDTO<ReferAndEarn> model = new PagingEnquiryDTO<ReferAndEarn>();
            model = UOF.IEnquiry.GetAllReferandEarn(page, pageSize, textsrch, startDate, endDate);
            ViewBag.totalNumber = model != null ? model.TotalRows.ToString() : "0";

            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult DeleteBulkRefer_Earn(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IEnquiry.DeleteRefer_Earn(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult RollBackQuery(int id, string comtbx)
        {
            bool stat = UOF.IQuery.UpdateRollBackCommentsOnQuery(id, comtbx);
            if (stat == true)
            {
                return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
            }
            else
            { return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet); }
            // queryModel.BatchMasterList = BatchList;CourseId);

        }
        [HttpPost]
        public JsonResult ChangeEmailContactToQuery(QueryDTO model)
        {
            try
            {
                bool status = UOF.IQuery.ChangeEmailContactToQuery(model);
                if (status == true)
                {
                    return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                }
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);

            }

        }


        ////////////////////////EnquirySettingList /////////by amit 08/04/17//////////
        public ActionResult EnquirySettingList(int page = 1, int CourseId = 0)
        {
            PagingDTO<EnquirySetting> model = new PagingDTO<EnquirySetting>();
            ViewBag.EnquirySettingList = "EnquirySettingList";
            model = UOF.IEnquirySetting.GetEnquirySettingList(CourseId, page, pageSize);

            List<Course> courseList = UOF.ICourse.GetCourseList();
            ViewBag.courseList = courseList;
            List<TrainingMode> TrainingModeList = UOF.IAdminMaster.GetTrainingModeListFull();
            ViewBag.TrainingModeList = TrainingModeList;
            ViewBag.Message = TempData["Message"];
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View("EnquirySettingList", model);

        }


        public ActionResult CreateEnquirySetting(int CourseId = 0, int? TrainingModeId = null)
        {
            try
            {
                EnquirySetting obj = new EnquirySetting();
                obj.CourseId = CourseId;
                int mode = 1;
                if (TrainingModeId == null)
                {
                    obj.ModeId = mode;
                }
                else
                {
                    obj.ModeId = (int)TrainingModeId;
                }
                obj.Counter = 0;
                UOF.IEnquirySetting.Add(obj);
                UOF.SaveChanges();
                ModelState.Clear();

                return RedirectToAction("EnquirySettingList");
            }
            catch (Exception ex)
            {

                ViewBag.Message = "Unable to Create this time. Please try again later.";
                return RedirectToAction("EnquirySettingList");
            }

        }
        public ActionResult DeleteEnquirySetting(int id)
        {
            UOF.IEnquirySetting.Remove(id);
            int stat = UOF.SaveChanges();
            if (stat == 0)
            { ViewBag.Message = "Unable to Delete this time. Please try again later."; }
            return RedirectToAction("EnquirySettingList");
        }

        public ActionResult DownloadToExcel(string EnquiryType = null)
        {
            List<QueryDTO> report = new List<QueryDTO>();
            if (EnquiryType != null)
            {
                switch (EnquiryType)
                {
                    case "New":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.New);

                        break;
                    case "Interested":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.Interested);
                        break;
                    case "NotInterested":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.NotInterested);
                        break;
                    case "Pending":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.Pending);
                        break;
                    case "Fake":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.Fake);
                        break;
                    case "Demo":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.Demo);
                        break;
                    case "Closed":
                        report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.Closed);
                        break;
                    default:
                        return new HttpStatusCodeResult(404);

                }


                //     List<QueryDTO> report = UOF.IEnquiry.GetManyByEnquiryType(CurrentUser.UserId, EnumEnquiryType.New);

                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string ReportName = "SalesReport" + time + ".xlsx";
                string fileName = ReportName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    switch (EnquiryType)
                    {
                        case "New":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.New);
                            break;
                        case "Interested":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.Interested);
                            break;
                        case "NotInterested":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.NotInterested);
                            break;
                        case "Pending":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.Pending);
                            break;
                        case "Fake":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.Fake);
                            break;
                        case "Demo":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.Demo);
                            break;
                        case "Closed":
                            objReceiving.GetReceiving(stream, report, p_strPath, EnumEnquiryType.Closed);
                            break;



                    }
                    bytes = stream.ToArray();
                }
                // byte[] bytes = client.DownloadData(fullPath);
                return File(bytes, "text/xls", fileName);
            }
            return null;
        }

        public JsonResult DownloadAllSalesManToExcel(int CourseId = 0, int Batch = 0, int AdminId = 0, string Date = "", string textsrch = "", int? EnquiryTypeId = null, int ModeId = 0)
        {
            try
            {
                List<QueryDTO> report = new List<QueryDTO>();
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                report = UOF.IEnquiry.GetAllSalesManReportToExcel(AdminId, CourseId, Batch, startDate, endDate, textsrch, EnquiryTypeId, ModeId);

                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string RepoetName = "SalesManReport" + time + ".xlsx";
                string fileName = RepoetName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingSalesReport(stream, report, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
                // return File(bytes, "text/xls", fileName);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        [HttpGet]
        public virtual ActionResult DownloadExcel(string file)
        {
            string StaticImgPath = string.Empty;
            StaticImgPath = WebConfigSetting.DownloadExcel;
            string fullPath = Path.Combine(StaticImgPath, file); //TODO  @"D:/Reports/"+ file;//

            WebClient client = new WebClient();
            byte[] bytes = client.DownloadData(fullPath);
            return File(bytes, "text/xls", file);


        }

        public ActionResult AssignQueryRefToQuery(string queryIds, int AdminId = 0)
        {
            try
            {
                if (queryIds != null)
                {
                    if (AdminId > 0)
                    {
                        bool status = UOF.IQuery.AssignQueryRefToQuery(queryIds, AdminId);

                        return RedirectToAction("ReferandEarnList");
                    }
                }

            }
            catch (Exception e)
            {
            }
            return RedirectToAction("ReferandEarnList");
        }


        public ActionResult FullQuryBySalesList(int page = 1, string Date = "", string textsrch = "", int? EnquiryTypeId = null)
        {
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            var Enquires = UOF.IEnquiryType.GetAll().ToList();
            ViewBag.EnquiryTypes = Enquires;

            var Enquiresfollop = UOF.IEnquiryType.GetAll().ToList();
            Enquiresfollop.RemoveAt(0);
            ViewBag.Enquiresfollop = Enquiresfollop;

            ViewBag.EnquiryStatus = UOF.IEnquiryStatus.GetAll();
            if (Date != "")
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');

                    Session["page"] = page;
                }
            }
            else
            {
                Session["startDate"] = "";
                Session["endDate"] = "";
            }

            return View();
        }
        public JsonResult AssignQueryContactToQuery(string queryIds, int CourseId = 0, int ModeId = 0)
        {
            try
            {
                if (queryIds != null)
                {
                    if (ModeId > 0)
                    {
                        bool status = UOF.IQuery.AssignQueryContactToQuery(queryIds, CourseId, ModeId);

                        return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                    }
                }

            }
            catch (Exception e)
            {
            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);

        }

        public PartialViewResult AjaxFullQuryBySalesList(int page = 1, string Date = "", string textsrch = "", int? EnquiryTypeId = null)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                if (date.Length > 1)
                {
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
            }
            PagingEnquiryDTO<QueryDTO> model = new PagingEnquiryDTO<QueryDTO>();
            //if (textsrch != "" && textsrch != null)
            //{
            //    page = 1;
            //    model = UOF.IEnquiry.GetAllSalesManReportBySearch(page, pageSize, textsrch);
            //}
            //else
            //{
            model = UOF.IEnquiry.GetAllSalesManReport(page, pageSize, (int)CurrentUser.UserId, 0, 0, startDate, endDate, textsrch, EnquiryTypeId);
            //}

            if (model != null)
            {
                ViewBag.totalNumber = model.TotalRows.ToString();
                ViewBag.page = model.Page;
            }
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            var Enquires = UOF.IEnquiryType.GetAll().ToList();
            ViewBag.EnquiryTypes = Enquires;

            var Enquiresfollop = UOF.IEnquiryType.GetAll().ToList();
            Enquiresfollop.RemoveAt(0);
            ViewBag.Enquiresfollop = Enquiresfollop;

            ViewBag.EnquiryStatus = UOF.IEnquiryStatus.GetAll();
            if (Date != "")
            {
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');
                    Session["startDate"] = startDate = Convert.ToDateTime(date[0].Trim());
                    if (date.Length > 1)
                    {
                        Session["endDate"] = endDate = Convert.ToDateTime(date[1].Trim());
                    }
                    Session["EnquiryTypeId"] = EnquiryTypeId;
                    Session["page"] = page;
                }
            }
            else
            {
                Session["EnquiryTypeId"] = "";
                Session["startDate"] = "";
                Session["endDate"] = "";

            }

            return PartialView(model);
        }

        public JsonResult GetReviewsAdmin(string enquiryId)
        {
            List<ReAssignQueryViewModel> queryRemarkViewModel = UOF.IQueryRemark.GetByQueryReviews(Convert.ToInt32(enquiryId));

            if (queryRemarkViewModel.Count > 0)
            {
                //return PartialView("_Reviews", queryRemarkViewModel);
                return Json(new { queryRemarkViewModel }, JsonRequestBehavior.AllowGet);
            }
            return null;
        }


        public ActionResult ScholarshipsList(int page = 1, string Date = "", string textsrch = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingDTO<Scholarship> model = new PagingDTO<Scholarship>();
            ViewBag.CommentsList = "ForumList";
            model = UOF.IQuery.GetAllScholarshipList(page, pageSize, startDate, endDate, textsrch);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult DeleteBulkScholarships(string sIds)
        {
            string[] ids = sIds.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IQuery.DeleteBulkScholarshipList(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult AssignQueryCorporateToQuery(string queryIds, int CourseId = 0, int ModeId = 0)
        {
            try
            {
                if (queryIds != null)
                {
                    if (ModeId > 0)
                    {
                        bool status = UOF.IQuery.AssignQueryCorporateToQuery(queryIds, CourseId, ModeId);

                        return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                    }
                }

            }
            catch (Exception e)
            {
            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);

        }

        public ActionResult UploadExcel(FormCollection formCollection, int CourseId = 0)
        {
            try
            {

                if (Request != null)
                {

                    HttpPostedFileBase file = Request.Files["UploadedFile"];
                    if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
                    {
                        string fileName = file.FileName;
                        string fileContentType = file.ContentType;
                        byte[] fileBytes = new byte[file.ContentLength];
                        var data = file.InputStream.Read(fileBytes, 0, Convert.ToInt32(file.ContentLength));
                        var qList = new List<Query>();
                        using (var package = new ExcelPackage(file.InputStream))
                        {
                            var currentSheet = package.Workbook.Worksheets;
                            var workSheet = currentSheet.First();
                            var noOfCol = workSheet.Dimension.End.Column;
                            var noOfRow = workSheet.Dimension.End.Row;
                            for (int rowIterator = 2; rowIterator <= noOfRow; rowIterator++)
                            {
                                if (workSheet.Cells[rowIterator, 1].Value != null && workSheet.Cells[rowIterator, 2].Value != null && workSheet.Cells[rowIterator, 3].Value != null)
                                {
                                    var q = new Query();
                                    q.Name = workSheet.Cells[rowIterator, 1].Value.ToString();
                                    q.EmailID = workSheet.Cells[rowIterator, 2].Value.ToString();
                                    q.ContactNo = workSheet.Cells[rowIterator, 3].Value.ToString();
                                    q.Message = workSheet.Cells[rowIterator, 4].Value != null ? workSheet.Cells[rowIterator, 4].Value.ToString() : "";
                                    qList.Add(q);
                                }
                            }
                        }

                        bool stat = UOF.IEnquiry.UpdateExcel(qList, CourseId, CurrentUser.UserId);
                        if (stat == true)
                        {
                            TempData["msg"] = "Uploaded Successfully";
                        }
                        else
                        {
                            TempData["msg"] = "Not Uploaded";

                        }
                    }
                }
            }
            catch (Exception w)
            {
            }
            return RedirectToAction("AddEnquiry");
        }
        public ActionResult AllCartList(int page = 1, string Date = "", string textsrch = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingDTO<ShoppingCartDTO> model = new PagingDTO<ShoppingCartDTO>();
            ViewBag.AllCartList = "AllCartList";
            model = UOF.IQuery.GetAllCartList(page, pageSize, startDate, endDate, textsrch);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        //
    }
}
