﻿
using DotNetTricks.COM.Security;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    /// <summary>
    /// Author : Basant Kumar
    /// Created Date : 4 Sep 2016
    /// </summary>   
    [RouteArea("Admin")]
    public class EnquiryStatusController : BaseController
    {
         
        int pageSize;
        public EnquiryStatusController()
             
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }
        public ActionResult Index()
        {
            IEnumerable<EnquiryStatus> model = UOF.IEnquiryStatus.GetAll();
            return View(model);
        }

    }
}
