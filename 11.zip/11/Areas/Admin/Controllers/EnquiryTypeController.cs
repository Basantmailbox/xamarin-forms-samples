﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;


using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    /// <summary>
    /// Author : Basant Kumar
    /// Created Date : 4 Sep 2016
    /// </summary>   
    [RouteArea("Admin")]
    public class EnquiryTypeController : BaseController
    {
        //

        int pageSize;
        public EnquiryTypeController()

        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;


        }
        public ActionResult EnquiryTypeList()
        {
            IEnumerable<EnquiryType> model = UOF.IEnquiryType.GetAll().ToList().Where(i => i.IsActive == true).OrderBy(i=>i.Description);
            return View(model);
        }


        public ActionResult CreateEnquiryType()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateEnquiryType(EnquiryType model)
        {
            try
            {
                UOF.IEnquiryType.Add(model);
                if (UOF.SaveChanges() > 0)
                {
                    ViewBag.Message = "EnquiryType  has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            return View();
        }

        public ActionResult EditEnquiryType(int id)
        {
            EnquiryType model = new EnquiryType();
            model = UOF.IEnquiryType.Get(id);

            return View(model);
        }
        [HttpPost]
        public ActionResult EditEnquiryType(EnquiryType model)
        {
            try
            {
                UOF.IEnquiryType.Update(model);

                if (UOF.SaveChanges() > 0)
                {
                    ViewBag.Message = "EnquiryType has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update EnquiryType this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("EnquiryTypeList");
        }

    }
}
