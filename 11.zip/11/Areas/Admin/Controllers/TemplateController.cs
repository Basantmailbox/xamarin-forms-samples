﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;



using DNTShared;
using DNTShared.DTO;
namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class TemplateController : BaseController
    {
        //
        // GET: /Admin/Template/

        int pageSize;
        public TemplateController()
            
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewEmailTemplateList(int page = 1)
        {
            PagingDTO<EmailTemplateDTO> model = new PagingDTO<EmailTemplateDTO>();
            ViewBag.ViewEmailTemplateList = "ViewEmailTemplateList";
            model = UOF.IEmailTemplate.GetViewEmailTemplateList(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);

        }

        [HttpGet]
        public ActionResult CreateTemplate()
        {
            TempData["Message"] = "";
            return View();

        }

        [HttpPost, ValidateInput(false)]
        public ActionResult CreateTemplate(EmailTemplateDTO model)
        {
            try
            {
                bool stat = UOF.IEmailTemplate.SaveEmailTemplate(model);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewEmailTemplateList");
        }
        [HttpGet]
        public ActionResult EditTemplate(int id)
        {
            TempData["Message"] = "";
            EmailTemplateDTO model = UOF.IEmailTemplate.GetEmailTemplate(id);
            return View(model);

        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditTemplate(EmailTemplateDTO model)
        {
            try
            {
                bool stat = UOF.IEmailTemplate.UpdateEmailTemplate(model);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewEmailTemplateList");
        }

        public ActionResult TemplateDelete(int id)
        {
            try
            {
                bool stat = UOF.IEmailTemplate.DeleteEmailTemplate(id);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been deleted successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewEmailTemplateList");
        }
        
        public ActionResult ViewCustomEmailList()
        {
            try
            {
                

            }
            catch (Exception ex)
            {

            }
            return View();
        }
        
    }
}
