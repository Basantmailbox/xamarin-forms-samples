﻿using DNTData;
using DNTShared;
using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class CommentController : Controller
    {
        IUnitOfWork AppUnitOfWork;

        // GET: /Admin/Comment/
         int pageSize;
        public CommentController()
        {
             AppUnitOfWork= new UnitOfWork();
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CommentsList(int page = 1, string Date = "",string textsrch="")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingDTO<CommentMasterDTO> model = new PagingDTO<CommentMasterDTO>();
            ViewBag.CommentsList = "CommentsList";
            model = AppUnitOfWork.ICommentMaster.GetAllCommentsList(page, pageSize, startDate, endDate, textsrch);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult EditComments(Guid id)
        {
            CommentMasterDTO model = new CommentMasterDTO();
            model = AppUnitOfWork.ICommentMaster.GetComments(id);
            return View(model);
        }

        [HttpPost]
        public ActionResult EditComments(CommentMasterDTO model)
        {
            try
            {
                bool status = AppUnitOfWork.ICommentMaster.UpdateComments(model);

                if (status == true)
                {
                    ViewBag.Message = "Comment has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Comment this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("CommentsList");
        }

        public ActionResult DeleteBulkComments(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.DeleteBulkComments(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult VerifyBulkComments(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.VerifyBulkComments(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        //public ActionResult DeleteComments(Guid id, int page = 1)
        //{
        //    bool status = AppUnitOfWork.CommentMasters.deleteComments(id);
        //    if (status == false)
        //    {
        //        TempData["Message"] = "Sorry! Something is getting worng. Please try again later.";
        //    }
        //    return RedirectToAction("CommentsList", new { page = page });
        //}
       
        public ActionResult ReplyList(int page = 1, string Date = "", string textsrch="")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingDTO<ReplyOnCommentDTO> model = new PagingDTO<ReplyOnCommentDTO>();
            ViewBag.ReplyList = "ReplyList";
            model = AppUnitOfWork.ICommentMaster.GetAllReplyList(page, pageSize, startDate, endDate,textsrch);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult EditReply(Guid id)
        {
            ReplyOnCommentDTO model = new ReplyOnCommentDTO();
            model = AppUnitOfWork.ICommentMaster.GetReply(id);
            return View(model);
        }

        [HttpPost]
        public ActionResult EditReply(ReplyOnCommentDTO model)
        {
            try
            {
                bool status = AppUnitOfWork.ICommentMaster.UpdateReply(model);

                if (status == true)
                {
                    ViewBag.Message = "Reply has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Reply this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ReplyList");
        }

        //public ActionResult DeleteReply(Guid id, int page = 1)
        //{
        //    bool status = AppUnitOfWork.CommentMasters.deleteReply(id);
        //    if (status == false)
        //    {
        //        TempData["Message"] = "Sorry! Something is getting worng. Please try again later.";
        //    }
        //    return RedirectToAction("ReplyList", new { page = page });
        //}

        ///////////////Deepak/////////////
        public ActionResult VerifyBulkReply(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.VerifyBulkReply(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult DeleteBulkReply(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.DeleteBulkReply(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        
    }
}
