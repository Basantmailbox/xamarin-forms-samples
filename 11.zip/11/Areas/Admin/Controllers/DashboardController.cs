﻿using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

using DNTShared;
using DNTShared.Entities;
using DNTShared.DTO;
using DNTWebCore;
using DNTWebUI.Models;
using DNTWebUI.Models.Security;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class DashboardController : BaseController
    {
        //private readonly DataContext mobjentity = new DataContext();
        int pageSize;
        int pageSizeQuery;
        public string ImgCloudPath = "";
        static CloudBlobClient blobClient;
        static CloudBlobContainer blobContainer;
        CloudStorageAccount storageAccount;
        public DashboardController()
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

            string _pageSizeQuery = Convert.ToString(ConfigurationManager.AppSettings["pageSizeQuery"]);
            int PSQ;
            bool resultQ = Int32.TryParse(_pageSizeQuery, out PSQ);
            pageSizeQuery = (resultQ == true) ? PSQ : 100;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("SignOut", "Account", new { area = "Admin" });
        }

        void BindCategory()
        {
            //Basant_Rep
            var tblcatlist = UOF.ICategory.GetAll().OrderBy(x => x.CategoryName);
            List<CategoryDTO> catlist = new List<CategoryDTO>();

            CategoryDTO mobj = new CategoryDTO();
            mobj.CategoryID = 0;
            mobj.CategoryName = "Select";
            catlist.Add(mobj);
            foreach (var item in tblcatlist)
            {
                mobj = new CategoryDTO();
                mobj.CategoryID = item.CategoryID;
                mobj.CategoryName = item.CategoryName;

                catlist.Add(mobj);
            }
            ViewBag.Categories = catlist;
        }

        void BindEventType()
        {
            //Basant_Rep
            var tbleventtypelist = UOF.IEventTypes.Get(true);

            List<EventType> eventTypeList = new List<EventType>();

            EventType mobj = new EventType();
            mobj.EventTypeId = 0;
            mobj.EventTypeName = "- Select Event Type -";
            eventTypeList.Add(mobj);

            foreach (var item in tbleventtypelist)
            {
                mobj = new EventType();
                mobj.EventTypeId = item.EventTypeId;
                mobj.EventTypeName = item.EventTypeName;

                eventTypeList.Add(mobj);
            }
            ViewBag.EventType = eventTypeList;
        }

        public ActionResult ViewSubscription(int page = 1, string sort = "ID", string sortDir = "asc", string Date = "", bool? status = null)
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewSubscription = "ViewSubscription";
            PagingDTO<Subscription> model = UOF.IAdminMaster.GetAllSubscriptionList(page, pageSize, startDate, endDate, status);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult BooksDownload(int page = 1, string sort = "ID", string sortDir = "asc", int? BookId = null, string textsrch = "")
        {
            try
            {
                ViewBag.BooksDownload = "BooksDownload";
                ViewBag.BookIdSelectedValue = BookId;
                PagingBookDTO<BookDownloadDTO> model = new PagingBookDTO<BookDownloadDTO>();
                model = UOF.IAdminMaster.GetAllbookDownloadList(page, pageSize, BookId, textsrch);
                model.BooksList = UOF.IAdminMaster.GetAllBooks();
                model.BookId = BookId;
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                ViewBag.SelectedValue = BookId;
                return View(model);
            }
            catch (Exception)
            { }
            return null;
        }

        public JsonResult BooksDownloadExcel(int? BookId = null, string textsrch = "")
        {
            try
            {
                ViewBag.BooksDownload = "BooksDownload";
                ViewBag.BookIdSelectedValue = BookId;
                List<BookDownloadDTO> model = new List<BookDownloadDTO>();
                model = UOF.IAdminMaster.GetAllbookDownloadListExcel(BookId, textsrch);

                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string ReportName = "ViewBooksDownloadReport" + time + ".xlsx";
                string fileName = ReportName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetAllbookDownloadListReport(stream, model, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();

                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public ActionResult ViewCategory()
        {

            ViewBag.ViewCategory = "ViewCategory";
            BindCategory();
            return View();

        }

        public JsonResult GetCategory(int mID)
        {
            try
            {
                if (mID != 0)
                {
                    List<CategoryDTO> category = UOF.IEvent.GetCategory(mID);
                    return Json(category, JsonRequestBehavior.AllowGet);

                }
            }
            catch (Exception ex)
            {

            }
            return Json(null);
        }

        [HttpPost]
        public ActionResult ViewCategory(CategoryDTO mcat)
        {
            try
            {
                ViewBag.ViewCategory = "ViewCategory";
                if (mcat.CategoryName != null && mcat.CategoryID != 0)
                {
                    bool status = UOF.IEvent.UpdateCategory(mcat);
                    if (status == true)
                    {
                        ModelState.Clear();
                        ViewBag.Message = "Category has been updated successfully !!";
                    }
                }
                else if (mcat.CategoryName != null && mcat.CategoryID == 0)
                {
                    int categoryId = UOF.IEvent.AddCategory(mcat);
                    if (categoryId > 0)
                    {
                        ModelState.Clear();
                        ViewBag.Message = "Category has been added successfully and Category ID is : " + categoryId.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ViewBag.Message = "There some internal error";
            }
            BindCategory();
            ViewBag.ViewCategory = "ViewCategory";
            return View();

        }

        public ActionResult DeleteBulkSubscription(string emailIds)
        {
            string[] ids = emailIds.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IAdminMaster.DeleteBulkSubscription(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ContactDelete(int id, int page = 1)
        {
            UOF.IEvent.DeleteContact(id);
            return RedirectToAction("ViewContact", new { page = page });
        }

        public ActionResult CallbackRequestDelete(int id, int page = 1)
        {
            UOF.IEvent.DeleteCallback(id);
            return RedirectToAction("ViewCallbackRequest", new { page = page });
        }

        public ActionResult LatestNewsDelete(int id, int page = 1, int filterId = 1)
        {
            UOF.IEvent.DeleteLatestNews(id);
            return RedirectToAction("ViewLatestNews", new { page = page, filterId = filterId });
        }

        public ActionResult BooksDownloadUserDelete(int id, int page = 1)
        {
            UOF.IEvent.DeleteBookDownloadUser(id);
            return RedirectToAction("BooksDownload", new { page = page });
        }

        public ActionResult QueryDelete(int id, int page = 1, int CourseId = 0, int ModeId = 1)
        {
            UOF.IEvent.DeleteQuery(id);
            return RedirectToAction("ViewQuery", new { page = page, CourseId = CourseId, ModeId = ModeId });
        }

        public ActionResult ViewQuery(int page = 1, string sort = "ID", string sortDir = "asc", int CourseId = 0, int ModeId = 1, int GroupType = 0, string textsrch = "")
        {
            PagingDTO<QueryDTO> model = new PagingDTO<QueryDTO>();
            if (textsrch != "" && textsrch != null)
            { model = UOF.IEvent.GetAllQueryListBySearch(page, pageSizeQuery, CourseId, ModeId, textsrch); }
            else
            {
                model = UOF.IEvent.GetAllQueryList(page, pageSizeQuery, CourseId, ModeId);
            }
            if (model != null)
            {
                if (GroupType == 1)
                {
                    model.Data.GroupBy(x => x.EmailID).Select(x => x);
                }
                if (GroupType == 2)
                {
                    model.Data.GroupBy(x => x.ContactNo).Select(x => x);
                }
            }
            //get the course list from db
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();

            ViewBag.ViewQuery = "ViewQuery";
            ViewBag.CourseSelectedValue = CourseId;
            ViewBag.ModeIdSelectedValue = ModeId;
            ViewBag.CourseId = CourseId;
            ViewBag.GroupType = GroupType;
            ViewBag.ModeId = ModeId;

            if (model != null)
            {
                model.Courses = courseList;
                ViewBag.page = model.Page;
            }
            else
            {
                ViewBag.CourseList = courseList;
            }
            return View(model);

        }

        public ActionResult ViewContact(int page = 1, string sort = "ID", string sortDir = "asc", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewContact = "ViewContact";
            PagingDTO<Contact> model = UOF.IEvent.GetContacts(page, pageSize, startDate, endDate);
            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.CourseList = UOF.ICommonLogic.GetCourseList();
            Session["page"] = model.Page;
            return View(model);
        }

        public ActionResult DeleteBulkContactQueries(string contactId)
        {
            string[] ids = contactId.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IEvent.DeleteBulkContactQueries(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult ViewCallbackRequest(int page = 1, string sort = "ID", string sortDir = "asc", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewCallbackRequest = "ViewCallbackRequest";
            PagingDTO<CallbackRequestDTO> model = UOF.IAdminMaster.GetAllCallbackRequestList(page, pageSize, startDate, endDate);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);

        }

        public ActionResult DeleteBulkCallbackRequest(string CallbackRequestId)
        {
            string[] ids = CallbackRequestId.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IAdminMaster.DeleteBulkCallbackRequest(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpGet]
        public ActionResult AddEvent()
        {
            BindEventType();
            ViewData["CurrentDate"] = DateTime.Now.ToShortDateString();
            ViewBag.AddTutorial = "AddEvent";
            EventDTO Model = new EventDTO();
            List<MentorMaster> SpeakersMasterList = UOF.ICourse.GetMentorMasterList();
            Model.SpeakersMasterList = SpeakersMasterList;
            return View(Model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddEvent(EventDTO model, string[] EventSpeakers)
        {
            try
            {
                string pathurl = "";
                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _eventFolderLocation;
                    _eventFolderLocation = ConfigurationManager.AppSettings["eventFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_eventFolderLocation), myfile);
                    pathurl = _eventFolderLocation + myfile;


                    string directoryPath = Server.MapPath(string.Format("~/{0}/", _eventFolderLocation));
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }

                    model.File.SaveAs(path);
                }
                else
                {
                    pathurl = "";
                }
                model.EventImage = pathurl;
                string username = CurrentUser.Name;
                bool status = UOF.IEvent.AddEvent(model, username, EventSpeakers);

                if (status == true)
                {
                    ViewBag.Message = "Event has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add event this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            BindEventType();
            EventDTO Model = new EventDTO();
            List<MentorMaster> SpeakersMasterList = UOF.ICourse.GetMentorMasterList();
            Model.SpeakersMasterList = SpeakersMasterList;
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddEvent = "AddEvent";
            return View(Model);
        }

        public ActionResult ViewEventRegistrations(int page = 1, string sort = "ID", string sortDir = "asc", int? EventId = null, int? EventTypeId = null, string textsrch = "")
        {
            try
            {
                PagingEventDTO<EventRegistrationDTO> model = new PagingEventDTO<EventRegistrationDTO>();
                ViewBag.EventSelectedValue = EventId;
                ViewBag.EventTypeSelectedValue = EventTypeId;
                EventId = EventId == null ? EventId = 0 : EventId;
                EventTypeId = EventTypeId == null ? EventTypeId = 0 : EventTypeId;
                if (textsrch != "" && textsrch != null)
                { model = UOF.IEvent.GetEventRegsitrationDetailsBySearch(page, pageSize, EventId, EventTypeId, textsrch); }
                else
                {
                    model = UOF.IEvent.GetEventRegsitrationDetails(page, pageSize, EventId, EventTypeId);
                }

                //get the event list from db
                List<EventDTO> eventList = UOF.IEvent.GetAllEventName();
                model.EventList = eventList;
                List<EventType> eventTypeList = UOF.IEvent.GetAllEventType();
                model.EventTypeList = eventTypeList;

                ViewBag.ViewEventRegistration = "ViewEventRegistration";
                return View(model);
            }
            catch (Exception)
            {
                return null;
            }

        }

        public JsonResult DownloadEventRegistrationsToExcel(int? EventId = null, int? EventTypeId = null, string textsrch = "")
        {
            try
            {
                List<EventRegistrationDTO> report = new List<EventRegistrationDTO>();
                report = UOF.IEvent.DownloadEventRegistrationsToExcel(EventId, EventTypeId, textsrch);

                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string ReportName = "EventRegistrationsReport" + time + ".xlsx";
                string fileName = ReportName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingEventRegistrationsReport(stream, report, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
                // return File(bytes, "text/xls", fileName);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public ActionResult EventRegistrationDelete(int id)
        {
            bool status = UOF.IEvent.DeleteEventRegistration(id);
            return RedirectToAction("ViewEventRegistrations");
        }

        [HttpGet]
        public ActionResult AddLatestNews()
        {
            ViewBag.AddLatestNews = "AddLatestNews";
            ViewData["CurrentDate"] = DateTime.Now.ToShortDateString();
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddLatestNews(LatestNews model, DateTime DateExp)
        {
            try
            {
                model.ExpiryDate = DateExp;
                string username = CurrentUser.Name;
                bool status = UOF.IEvent.AddLatestNews(model, username);
                if (status == true)
                {
                    ViewBag.Message = "Latest News has been saved successfully";
                    ModelState.Clear();
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            ViewBag.AddEvent = "AddLatestNews";
            ViewData["CurrentDate"] = DateTime.Now.ToShortDateString();
            return View();
        }

        [HttpGet]
        [TimeZoneFliter]
        public ActionResult EditLatestNews(int id)
        {
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            var timeOffSet = zone.Id;
            ViewBag.EditLatestNews = "EditLatestNews";
            LatestNews model = UOF.IEvent.GetLatestNewsById(id, timeOffSet);
            if (model != null)
            {
                ViewData["DateExp"] = model.ExpiryDate;
                ViewBag.NewsFullDetail = model.NewsText + ";" + model.ExpiryDate.ToString("f", System.Globalization.CultureInfo.CreateSpecificCulture("en-US")).TrimEnd() + ";" + model.PostedBy;
                return View(model);
            }
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditLatestNews(LatestNews model, DateTime DateExp)
        {
            try
            {
                string User = CurrentUser.Name;
                model.ExpiryDate = DateExp;
                var UpdatedNewsDetail = model.NewsText + ";" + model.ExpiryDate.ToString("f", System.Globalization.CultureInfo.CreateSpecificCulture("en-US")).TrimEnd();
                bool status = UOF.IEvent.UpdateLatestNews(model, User);
                if (status == true)
                {
                    MailClient.SendMail_EditLatestNews(model.NewsFullDetail, UpdatedNewsDetail, User);
                    ViewBag.Message = "Latest News has been updated successfully";
                    ModelState.Clear();

                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            ViewBag.EditLatestNews = "EditLatestNews";
            return RedirectToAction("ViewLatestNews");
        }
        [TimeZoneFliter]
        public ActionResult ViewLatestNews(int page = 1, string sort = "NewsID", string sortDir = "asc", int filterId = 1)
        {
            ViewBag.ViewLatestNews = "ViewLatestNews";
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            var timeOffSet = zone.Id;
            PagingDTO<LatestNews> model = UOF.IAdminMaster.GetViewLatestNews(page, pageSize, filterId, timeOffSet);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.SelectedValue = filterId;
            ViewBag.filterId = filterId;
            return View(model);

        }

        public ActionResult ViewAllMembers(int page = 1, string sort = "MemberId", string sortDir = "asc", int FilterId = 1, string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
            }
            else
            {
                startDate = DateTime.Today;
                endDate = DateTime.Today.AddDays(1);
            }
            ViewBag.ViewAllMember = "ViewAllMember";
            try
            {
                PagingMemberSubscriptionDTO<MemberDTO> model = new PagingMemberSubscriptionDTO<MemberDTO>();
                if (textsrch != "" && textsrch != null)
                { model = UOF.IMember.GetAllMemberListBySearch(page, pageSize, FilterId, textsrch, startDate, endDate); }
                else
                {
                    model = UOF.IMember.GetAllMemberList(page, pageSize, FilterId, startDate, endDate);
                }
                
                //Bind Filter Options
                List<FilterOptionsDTO> filterOptionList = new List<FilterOptionsDTO>();
                filterOptionList.Add(new FilterOptionsDTO { FilterId = 1, Name = "Registered Member" });
                filterOptionList.Add(new FilterOptionsDTO { FilterId = 2, Name = "Deactivated Member" });
                filterOptionList.Add(new FilterOptionsDTO { FilterId = 4, Name = "UnRegistered Member" });
                filterOptionList.Add(new FilterOptionsDTO { FilterId = 3, Name = "All Member" });
                if (model != null)
                {
                    model.FilterOptionList = filterOptionList;
                    model.FilterId = FilterId;

                    if (model != null)
                    {
                        ViewBag.page = model.Page;
                    }
                    return View(model);
                }
                else
                {
                    model = new PagingMemberSubscriptionDTO<MemberDTO>();
                    model.FilterOptionList = filterOptionList;
                    model.FilterId = FilterId;

                    if (model != null)
                    {
                        ViewBag.page = model.Page;
                    }
                    return View(model);
                }

            }
            catch (Exception)
            {

                return null;
            }


        }

        [HttpPost]
        public JsonResult DownloadAllMemberToExcelList(int FilterId = 1, string Date = "", string textsrch = "")
        {
            try
            {
                List<MemberDTO> report = new List<MemberDTO>();
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
               report = UOF.IMember.GetAllMemberListExcel(FilterId, textsrch, startDate, endDate);


                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string RepoetName = "MemberReport" + time + ".xlsx";
                string fileName = RepoetName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingAllMemberReport(stream, report, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
                // return File(bytes, "text/xls", fileName);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public ActionResult MemberDelete(int id, int page = 1, int filterId = 4)
        {
            bool status = UOF.IEvent.DeleteMember(id);
            return RedirectToAction("ViewAllMembers", new { page = page, filterId = filterId });
        }
        //Deactivate Member
        public ActionResult MemberDeactivate(int id, int page = 1, int filterId = 1)
        {
            bool status = UOF.IEvent.DeactivateMember(id);

            return RedirectToAction("ViewAllMembers", new { page = page, filterId = filterId });
        }

        //Activate Member
        public ActionResult MemberActivate(int id, int page = 1, int filterId = 2)
        {
            bool status = UOF.IEvent.ActivateMember(id);

            return RedirectToAction("ViewAllMembers", new { page = page, filterId = filterId });
        }

        public ActionResult ViewUnVerifiedMembers(int page = 1, string sort = "MemberId", string sortDir = "asc", int filterId = 4, string textsrch = "", string Date = "")
        {
            try
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                ViewBag.ViewUnVerifiedMember = "ViewUnVerifiedMember";
                PagingDTO<MemberDTO> model = new PagingDTO<MemberDTO>();
                if (textsrch != "" && textsrch != null)
                { model = UOF.IMember.GetAllMemberListBySearch(page, pageSize, filterId, textsrch, startDate, endDate); }
                else
                {
                    model = UOF.IMember.GetAllMemberList(page, pageSize, filterId, startDate, endDate);
                }

                //PagedMemberViewModel model = new PagedMemberViewModel();
                //model = memberRepo.GetAllMemberList(page, pageSize, filterId); // 4 - for un-verified members
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }

                return View(model);
            }
            catch (Exception)
            { }
            return null;
        }

        //public ActionResult SendVerificationMail(int id, int page = 1)
        //{
        //    try
        //    {
        //        MemberViewModel model = memberRepo.GetMember(id);
        //        if (model.MemberId > 0)
        //        {
        //            MailSender obj = new MailSender();
        //            bool mailStatus = obj.SendMail_ConfirmMemberRegistrationEmail(model);
        //            if (mailStatus == true)
        //            {
        //                int? totalSentMailCount = memberRepo.IncreaseMailSentCounter(model.MemberId);
        //            }
        //        }
        //    }
        //    catch (Exception ex) { }
        //    return RedirectToAction("ViewUnVerifiedMembers", new { page = page });
        //}


        //public ActionResult SendSubscriptionVerificationMail(string id, int page = 1)
        //{
        //    try
        //    {
        //        string _subscribeUrl = AppUnitOfWork.CommonLogics.VerifyEmailSubscription(id);
        //        if (!string.IsNullOrEmpty(_subscribeUrl))
        //        {
        //            MailSender obj = new MailSender();
        //            bool status = obj.SendMail_Subscription(id, _subscribeUrl);
        //            if (status == true)
        //            {
        //                int? totalSentMailCount = AppUnitOfWork.CommonLogics.IncreaseSubscribeMailSentCounter(id);
        //            }
        //        }
        //    }
        //    catch (Exception ex) { }
        //    return RedirectToAction("ViewSubscription", new { page = page });
        //}

        public ActionResult DeleteBulkUnverifiedMember(string ids)
        {
            string[] memids = ids.Split(',');
            if (ids.Count() > 0)
            {
                for (int i = 0; i < memids.Length; i++)
                {
                    int id = Convert.ToInt32(memids[i]);
                    string profilePicPath = UOF.IEvent.DeleteUnverifiedMember(id);
                    string fullPath = Request.MapPath(profilePicPath);

                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }
                }
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        //public ActionResult DeleteUnverified(int id, int page = 1)
        //{
        //    TempData["Message"] = "";

        //    string profilePicPath = AppUnitOfWork.Events.DeleteUnverifiedMember(id);
        //    string fullPath = Request.MapPath(profilePicPath);

        //    if (System.IO.File.Exists(fullPath))
        //    {
        //        System.IO.File.Delete(fullPath);
        //    }

        //    return RedirectToAction("ViewUnVerifiedMembers", new { page = page });

        //}

        [HttpGet]
        public ActionResult AddBatchDetails()
        {
            BatchesInfoDTO BatchModel = BindBatchDropdown();
            string date = DateTime.Now.ToShortDateString();
            //ViewData["CurrentDate"] = DateTime.Now.ToString("dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
            ViewData["CurrentDate"] = DateTime.Now.ToShortDateString();
            return View(BatchModel);

        }

        private BatchesInfoDTO BindBatchDropdown()
        {
            BatchesInfoDTO BatchModel = new BatchesInfoDTO();
            ViewBag.EditBatch = "AddBatchDetails";
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            BatchModel.CourseList = courseList;

            //Bind Training Mode
            List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
            BatchModel.TrainingModeList = trainingModeList;
            return BatchModel;
        }




        //[HttpGet]
        //public ActionResult BatchDelete(int id)
        //{
        //    bool status = AppUnitOfWork.Admins.BatchDelete(id);
        //    return RedirectToAction("ViewUpcomingBatches");
        //}


        [HttpGet]
        public ActionResult AddTestimonialDetails()
        {
            TempData["Message"] = "";
            TestimonialDTO TestModel = new TestimonialDTO();
            ViewBag.AddTestimonialDetails = "Add Testimonial Details";
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            TestModel.courseList = courseList;
            List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
            TestModel.genderList = GenderList;
            TestModel.Reviews = 4.5m;
            return View(TestModel);


        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddTestimonialDetails(TestimonialDTO model)
        {
            try
            {

                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["testimonialImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                string pathurl = "";
                // string oldpic = CurrentUser.ProfilePic;

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _testimonialImageFolderLocation;
                    _testimonialImageFolderLocation = ConfigurationManager.AppSettings["testimonialImageFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_testimonialImageFolderLocation), myfile);
                    pathurl = "/" + _testimonialImageFolderLocation + myfile;

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                }
                else
                {
                    pathurl = "";
                }
                model.ImageUrl = pathurl;
                model.CreatedBy = (int)CurrentUser.UserId;
                bool stat = UOF.IAdminMaster.AddTestimonial(model);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();

                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            TestimonialDTO testModel = new TestimonialDTO();
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            testModel.courseList = courseList;
            List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
            testModel.genderList = GenderList;
            return View(testModel);

            // return RedirectToAction("ViewAllTestimonial");
        }

        public ActionResult ViewAllTestimonial(int page = 1, int CourseId = 0, string Date = "", string textsrch = "")
        {
            TempData["Message"] = "";
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewAllTestimonial = "ViewAllTestimonial";
            int adminid = 0;
            if (!CurrentUser.Roles.Contains("Admin") && !CurrentUser.Roles.Contains("Developer"))
            {
                adminid = (int)CurrentUser.UserId;
            }
            PagingDTO<TestimonialDTO> model = UOF.IAdminMaster.GetTestimonialDetails(page, pageSize, textsrch, CourseId, startDate, endDate, adminid);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();
            return View(model);
        }

        public ActionResult TestimonialDelete(int id, int page = 1)
        {
            TempData["Message"] = "";
            blobClient = storageAccount.CreateCloudBlobClient();
            blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["testimonialImageFolder"].ToString());
            blobContainer.CreateIfNotExistsAsync();

            var mobj = UOF.ITestimonial.Get(id);
            if (mobj != null)
            {
                UOF.ITestimonial.Remove(mobj);
                UOF.SaveChanges();
            }

            var photoName = "";
            photoName = ImgCloudPath + mobj.ImageUrl;

            Uri uri = new Uri(photoName);
            string filename = Path.GetFileName(uri.LocalPath);

            var blob = blobContainer.GetBlockBlobReference(filename);
            blob.DeleteIfExistsAsync();
            return RedirectToAction("ViewAllTestimonial", new { page = page });
        }

        [HttpGet]
        public ActionResult EditTestimonial(int id)
        {
            TempData["Message"] = "";
            TestimonialDTO model = UOF.ICommonLogic.GetTestimonialDisplay(id);
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            model.courseList = courseList;
            model.CourseId = model.CourseId;
            List<GenderMaster> GenderList = UOF.IMember.GetGenderList();
            model.genderList = GenderList;
            model.GenderId = model.GenderId;
            model.LinkType = model.LinkType;
            return View(model);

        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditTestimonial(TestimonialDTO model)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["testimonialImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                string pathurl = "";
                string oldpic = "";
                bool oldflag = false;
                Testimonial testdt = UOF.ITestimonial.Get(model.TestimonialId);
                if (testdt != null)
                {
                    oldpic = testdt.ImageUrl.Replace(ImgCloudPath, "");
                }

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _testimonialImageFolderLocation;
                    _testimonialImageFolderLocation = ConfigurationManager.AppSettings["testimonialImageFolder"].ToString();

                    //string path = Path.Combine(Server.MapPath(_mentorImageFolderLocation), myfile);
                    pathurl = "/" + _testimonialImageFolderLocation + myfile;
                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    oldflag = true;
                }
                else
                {
                    pathurl = oldpic;
                }
                model.ImageUrl = pathurl;
                model.UpdatedBy = (int)CurrentUser.UserId;
                bool stat = UOF.IAdminMaster.UpdateTestimonial(model);
                if (stat != false)
                {
                    if (oldflag == true)
                    {
                        Uri uri = new Uri(ImgCloudPath + oldpic);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();
                    }
                    TempData["Message"] = "Details has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewAllTestimonial");
        }

        public ActionResult EventList(int page = 1, string sort = "EventID", string sortDir = "asc", int EventTypeId = 0, int EventStatusId = 0)
        {
            PagingEventDTO<EventDTO> model = new PagingEventDTO<EventDTO>();
            ViewBag.ViewAllEvents = "ViewAllEvents";
            BindEventType();
            ViewData["CurrentDate"] = DateTime.Now;

            model = UOF.IEvent.GetAllEventList(page, pageSize, EventTypeId, EventStatusId);
            ViewBag.EventTypeIdSelectedValue = EventTypeId;
            ViewBag.EventStatusIdSelectedValue = EventStatusId;
            ViewBag.EventTypeId = EventTypeId;
            ViewBag.EventStatusId = EventStatusId;
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult EventDelete(int id, int page = 1, int EventTypeId = 0, int EventStatusId = 0)
        {
            try
            {
                Event mobj = UOF.IEvent.Get(id);

                if (mobj != null)
                {

                    UOF.IEvent.Remove(mobj);
                    UOF.SaveChanges();
                }
                var photoName = "";
                photoName = mobj.EventImage;
                string fullPath = Request.MapPath(photoName);

                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }

                return RedirectToAction("EventList", new
                {
                    page = page,
                    EventTypeId = EventTypeId,
                    EventStatusId = EventStatusId
                });
            }
            catch (Exception)
            {
                return RedirectToAction("EventList", new
                {
                    page = page,
                    EventTypeId = EventTypeId,
                    EventStatusId = EventStatusId
                });
            }

        }

        [HttpGet]
        public ActionResult EditEvent(int id)
        {
            ViewBag.id = id;
            BindEventType();
            // ViewData["CurrentDate"] = DateTime.Now;

            if (id != 0)
            {
                var eventdt = UOF.IEvent.Get(id);
                if (eventdt != null)
                {
                    EventDTO model = new EventDTO();
                    model.EventID = eventdt.EventID;
                    model.EventTitle = eventdt.EventTitle;
                    model.EventJoiningLink = eventdt.EventJoiningLink;
                    model.EventDescription = eventdt.EventDescription;
                    model.EventAddress = eventdt.EventAddress;
                    model.EventTypeId = eventdt.EventTypeId;
                    model.EventImage = eventdt.EventImage;
                    model.EventDisplayDateTime = eventdt.EventDisplayDateTime;
                    model.EventDate = Utility.ConvertDateFrom_UTC_to_IST(eventdt.EventDate);
                    model.PostedDate = Utility.ConvertDateFrom_UTC_to_IST(eventdt.PostedDate);
                    model.ShortDescription = eventdt.ShortDescription;
                    model.MetaKeywords = eventdt.MetaKeywords;
                    model.PostedBy = eventdt.PostedBy;
                    model.UpdatedDate = eventdt.UpdatedDate;
                    model.Url = eventdt.Url;
                    model.MetaDescription = eventdt.MetaDescription;
                    model.TotalViews = eventdt.TotalViews;
                    model.IsActive = eventdt.IsActive;
                    model.EventSpeakers = eventdt.EventSpeakers;
                    model.IsRegistrationClosed = eventdt.IsRegistrationClosed;
                    model.DomainName = eventdt.DomainName;
                    ViewData["PostedDate"] = Utility.ConvertDateFrom_UTC_to_IST(eventdt.PostedDate);
                    ViewData["EventDate"] = Utility.ConvertDateFrom_UTC_to_IST(eventdt.EventDate);

                    List<MentorMaster> SpeakersMasterList = UOF.ICourse.GetMentorMasterList();
                    model.SpeakersMasterList = SpeakersMasterList;
                    model.SpeakersList = ViewBag.SelectedAuthors = UOF.IEvent.GetEventSpeakers(id);
                    List<SelectListItem> Select_List = new List<SelectListItem>();
                    foreach (var m in SpeakersMasterList)
                    {
                        SelectListItem obj = new SelectListItem()
                        {
                            Value = m.MentorId.ToString(),
                            Text = m.Name,
                            Selected = model.SpeakersList.Where(me => me.MentorId == m.MentorId).Count() > 0 ? true : false
                        };

                        Select_List.Add(obj);
                    }
                    model.SpeakersMaster = Select_List;
                    return View(model);

                }
            }
            return null;
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditEvent(EventDTO model, FormCollection SpeakersName)
        {
            String mId = SpeakersName["SpeakersName"];
            try
            {
                string pathurl = "";
                string oldpic = "";
                Event edt = UOF.IEvent.Get(model.EventID);
                if (edt != null)
                {
                    oldpic = edt.EventImage;
                }

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _eventFolderLocation;
                    _eventFolderLocation = ConfigurationManager.AppSettings["eventFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_eventFolderLocation), myfile);
                    pathurl = _eventFolderLocation + myfile;


                    string directoryPath = Server.MapPath(string.Format("~/{0}/", _eventFolderLocation));
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }

                    model.File.SaveAs(path);

                    string fullpath = Request.MapPath(oldpic);
                    if (System.IO.File.Exists(fullpath))
                    {
                        System.IO.File.Delete(fullpath);
                    }
                }
                else
                {
                    pathurl = oldpic;
                }

                //TO DO: move this code into repository
                Event mobj = UOF.IEvent.Get(model.EventID);
                mobj.EventImage = pathurl;
                mobj.EventTitle = model.EventTitle;
                mobj.EventDescription = model.EventDescription;
                mobj.EventAddress = model.EventAddress;
                mobj.EventTypeId = model.EventTypeId;
                mobj.EventDate = model.EventDate;
                mobj.EventSpeakers = mId;
                mobj.EventJoiningLink = model.EventJoiningLink;
                mobj.EventDisplayDateTime = model.EventDisplayDateTime;
                mobj.PostedDate = model.PostedDate;
                mobj.ShortDescription = model.ShortDescription;
                mobj.MetaKeywords = model.MetaKeywords;
                mobj.PostedBy = CurrentUser.Name;
                mobj.IsRegistrationClosed = model.IsRegistrationClosed;

                string eventName = UOF.IEventTypes.Get(model.EventTypeId).EventTypeName;

                // mobj.Url = "/Events/" + eventName + "/" + mobj.ID + "-" + model.EventTitle.ToLower().Replace(" ", "-").Replace(".", string.Empty).Replace(",", string.Empty).Replace("&", "").Replace("@", "").Replace("#", "");
                mobj.DomainName = model.DomainName;
                mobj.MetaDescription = model.MetaDescription;
                UOF.SaveChanges();
                ViewBag.Message = "Event has been updated successfully";
                ModelState.Clear();
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("EventList");

        }

        public ActionResult AddBookDetails()
        {

            ViewBag.AddBookDetails = "Add Book Details";
            ViewData["CurrentDate"] = DateTime.Now;
            return View();

        }

        [HttpGet]
        public ActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordDTO model)
        {
            try
            {
                if (CurrentUser != null)
                {
                    model.Email = CurrentUser.Email;

                    bool validateCurrentPasswordStatus = UOF.IAdminMaster.ValidateAdminCurrentPassword(CurrentUser.Email, model.OldPassword);
                    if (validateCurrentPasswordStatus == true)
                    {

                        bool status = UOF.IAdminMaster.ChangePassword(model);
                        if (status == true)
                        {
                            FormsAuthentication.SignOut();
                            return RedirectToAction("PasswordChangedSuccessfully", "Account", new { area = "Admin" });
                        }
                        else
                        {
                            ModelState.AddModelError("", "Something happened, Please try again later.");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Current Password does not matched.");
                    }
                }
                else
                {

                    //do something here
                }
            }
            catch (Exception)
            { }
            return View(model);
        }

        [HttpGet]
        public ActionResult ViewAdminProfile()
        {
            if (CurrentUser != null)
            {
                AdminMasterDTO model = new AdminMasterDTO();
                model.AdminId = (int)CurrentUser.UserId;
                model.Name = CurrentUser.Name;
                model.Email = CurrentUser.Email;
                model.MobileNo = CurrentUser.MobileNo;
                model.ProfilePic = ImgCloudPath + CurrentUser.ProfilePic;
                return View(model);
            }
            return View();
        }

        [HttpGet]
        public ActionResult EditAdminProfile()
        {
            if (CurrentUser != null)
            {
                AdminProfileDTO model = new AdminProfileDTO();
                model.AdminId = (int)CurrentUser.UserId;
                model.Name = CurrentUser.Name;
                model.Email = CurrentUser.Email;
                model.MobileNo = CurrentUser.MobileNo;
                model.ProfilePic = ImgCloudPath + CurrentUser.ProfilePic;
                return View(model);
            }
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult UploadFile()
        {
            string _imgname = string.Empty;
            if (System.Web.HttpContext.Current.Request.Files.AllKeys.Any())
            {
                if (CurrentUser != null)
                {
                    blobClient = storageAccount.CreateCloudBlobClient();
                    blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["adminImageFolder"].ToString());
                    blobContainer.CreateIfNotExistsAsync();

                    string pathurl = "";
                    bool oldflag = false;
                    string oldpic = CurrentUser.ProfilePic.Replace(ImgCloudPath, "");
                    var pic = System.Web.HttpContext.Current.Request.Files["MyImages"];
                    if (pic.ContentLength > 0)
                    {
                        var fileName = Path.GetFileName(pic.FileName);   //file name  
                        var ext = Path.GetExtension(pic.FileName);   //getting the extension(ex-.jpg)  

                        string name = Path.GetFileNameWithoutExtension(fileName);
                        string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                        string myfile = CurrentUser.UserId + time + ext; //

                        string _adminImageFolderLocation;
                        _adminImageFolderLocation = ConfigurationManager.AppSettings["adminImageFolder"].ToString();

                        // string path = Path.Combine(Server.MapPath(_adminImageFolderLocation), myfile);
                        pathurl = "/" + _adminImageFolderLocation + myfile;
                        CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                        using (var fileStream = pic.InputStream)
                        {
                            blockBlob.UploadFromStream(fileStream);
                        }

                        Uri uri = new Uri(ImgCloudPath + oldpic);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();

                        _imgname = myfile;
                    }
                    else
                    {
                        pathurl = oldpic;
                    }
                    string ProfilePic = pathurl;

                    AdminProfileDTO adminModel = UOF.IAdminMaster.UpdateAdminProfilePic(CurrentUser.UserId, ProfilePic);
                    if (adminModel != null)
                    {
                        TempData["Message"] = "Profile has been Updated Successfully.";
                        //set cookie here

                        CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                        serializeModel.UserId = adminModel.AdminId;
                        serializeModel.Name = adminModel.Name;
                        serializeModel.MobileNo = adminModel.MobileNo;
                        serializeModel.Email = adminModel.Email;
                        //  serializeModel.Password = CurrentUser.Password;
                        serializeModel.Roles = CurrentUser.Roles;
                        serializeModel.ProfilePic = adminModel.ProfilePic;

                        string userData = JsonConvert.SerializeObject(serializeModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                 1,
                                 CurrentUser.Name,
                                 DateTime.Now,
                                 DateTime.Now.AddMinutes(30),
                                 false,
                                 userData);

                        string encTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                        Response.Cookies.Add(faCookie);

                        //set cookie ends here

                        ModelState.Clear();

                    }

                }
            }
            return Json(Convert.ToString(_imgname), JsonRequestBehavior.AllowGet);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditAdminProfile(AdminProfileDTO model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (CurrentUser != null)
                    {
                        AdminProfileDTO adminModel = UOF.IAdminMaster.UpdateAdminProfile(model);
                        if (adminModel != null)
                        {
                            TempData["Message"] = "Details has been saved successfully";
                            //set cookie here

                            CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                            serializeModel.UserId = adminModel.AdminId;
                            serializeModel.Name = adminModel.Name;
                            serializeModel.MobileNo = adminModel.MobileNo;
                            serializeModel.Email = adminModel.Email;
                            // serializeModel.Password = CurrentUser.Password;
                            serializeModel.Roles = CurrentUser.Roles;
                            serializeModel.ProfilePic = adminModel.ProfilePic;

                            string userData = JsonConvert.SerializeObject(serializeModel);
                            FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                     1,
                                     CurrentUser.Name,
                                     DateTime.Now,
                                     DateTime.Now.AddMinutes(30),
                                     false,
                                     userData);

                            string encTicket = FormsAuthentication.Encrypt(authTicket);
                            HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                            Response.Cookies.Add(faCookie);

                            //set cookie ends here

                            ModelState.Clear();

                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Something happened. Please try again later.");
                }
            }
            catch (Exception ex)
            {
                // Response.Write(ex);
            }

            return RedirectToAction("ViewAdminProfile", "Dashboard");
        }

        public ActionResult _PartialCallBackList()
        {
            IEnumerable<CallbackRequestDTO> model = UOF.ICommonLogic.GetCallBackDetailsList();

            return PartialView("_PartialCallBackList", model);
        }

        public ActionResult _PartialEnquiryList()
        {
            IEnumerable<QueryDTO> model = UOF.ICommonLogic.GetQueryDetailsList();

            return PartialView("_PartialEnquiryList", model);
        }

        public ActionResult _PartialCounter()
        {
            try
            {
                DashboardCounterDTO model = UOF.ICommonLogic.GetDashboardCounters();
                return PartialView("_PartialCounter", model);
            }
            catch
            {
                return null;
            }
        }
        public ActionResult _PartialCounterAccount()
        {
            try
            {
                DashboardCounterDTO model = UOF.ICommonLogic.GetDashboardCounters();
                return PartialView("_PartialCounterAccount", model);
            }
            catch
            {
                return null;
            }
        }

        public ActionResult _PartialCounterSales()
        {
            try
            {
                DashboardCounterDTO model = UOF.IEnquiry.GetDashboardCounters(CurrentUser.UserId);
                return PartialView("_PartialCounterSales", model);
            }
            catch
            {
                return null;
            }
        }

        public ActionResult AllMemberList(int cont = 0, int filterId = 0, int SelectId = 0, int CourseId = 0)
        {
            try
            {
                MemberEmailCampaignDTO model = new MemberEmailCampaignDTO();
                if (cont > 0)
                {
                    model = UOF.IAdminMaster.GetAllRegisteredMemberEmailList(cont, filterId, SelectId, CourseId);

                    if (model.TotalCounts <= model.AllRegisteredMember)
                    {
                        ViewData["Message"] = model.TotalCounts + " out of " + model.AllRegisteredMember;
                    }
                    else
                    {
                        ViewData["Message"] = model.AllRegisteredMember + " out of " + model.AllRegisteredMember;
                    }
                }
                ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.SelectedCourseId = CourseId;
                ViewBag.SelectedValue = filterId;
                ViewBag.SelectedSelectId = SelectId;
                return View(model);
            }
            catch (Exception ex)
            { return View(); }


        }
        public ActionResult DownloadAllMemberToExcel(int cont = 0, int filterId = 0, int SelectId = 0, int CourseId = 0)
        {
            try
            {
                MemberEmailCampaignDTO model = new MemberEmailCampaignDTO();
                if (cont > 0)
                {
                    model = UOF.IAdminMaster.GetAllRegisteredMemberEmailList(cont, filterId, SelectId, CourseId);

                    if (model.TotalCounts <= model.AllRegisteredMember)
                    {
                        ViewData["Message"] = model.TotalCounts + " out of " + model.AllRegisteredMember;
                    }
                    else
                    {
                        ViewData["Message"] = model.AllRegisteredMember + " out of " + model.AllRegisteredMember;
                    }
                }
                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string RepoetName = "CampaignReport" + time + ".xlsx";
                string fileName = RepoetName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingCampaignReport(stream, model, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);
                ViewBag.courseList = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.SelectedCourseId = CourseId;
                ViewBag.SelectedValue = filterId;
                ViewBag.SelectedSelectId = SelectId;
                return View(model);
            }
            catch (Exception ex)
            { return View(); }


        }
        public ActionResult StatisticsList()
        {
            IEnumerable<Counter> model = UOF.ICommonLogic.GetStatisticsList();

            return View(model);
        }

        [HttpGet]
        public ActionResult StatisticsEdit(int id = 0)
        {
            Counter model = UOF.ICommonLogic.GetStatDisplay(id);
            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult StatisticsEdit(Counter model)
        {
            try
            {
                Counter countobj = UOF.ICounter.Get(model.CounterId);
                countobj.Trained = model.Trained;
                countobj.Batches = model.Batches;
                countobj.UpdatedDate = DateTime.Now;
                UOF.SaveChanges();
                ViewBag.Message = "Counter has been updated successfully";
                //ModelState.Clear();
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            return RedirectToAction("StatisticsList");

        }




        public ActionResult ViewEventRegisteredMail(int EventId = 0, int EventTypeId = 0, int Search = 0)
        {
            try
            {
                EventRegistrationEmailDTO model = UOF.IEvent.GetAllRegsiteredMemberDetails(EventId, Search);

                List<EventDTO> eventList = UOF.IEvent.GetAllEventName();
                model.EventList = eventList;
                List<EventType> eventTypeList = UOF.IEvent.GetAllEventType();
                model.EventTypeList = eventTypeList;

                ViewBag.EventRegisteredMail = "EventRegistrationsMail";
                ViewBag.EventSelectedValue = EventId;
                ViewBag.EventTypeSelectedValue = EventTypeId;
                ViewData["Message"] = model.TotalCounts;
                ViewBag.Search = Search;
                return View(model);

            }
            catch (Exception ex)
            { }
            return null;

        }
        public ActionResult GetAllEventsList(int EventTypeId)
        {
            List<EventDTO> data = UOF.IEvent.GetAll().Where(c => c.EventTypeId == EventTypeId).Select(x => new EventDTO
            {
                EventID = x.EventID,
                EventTitle = x.EventTitle
            }).ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }


        public ActionResult MockUpTestMaster()
        {

            return View();
        }
        public ActionResult QuestionMaster()
        {

            return View();
        }
        public ActionResult ViewContactBySearch(int page = 1, string sort = "ID", string sortDir = "asc", string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.CourseList = UOF.ICommonLogic.GetCourseList();
            if (textsrch != null && textsrch != "")
            {
                ViewBag.ViewContact = "ViewContact";
                PagingDTO<Contact> model = UOF.IEvent.GetContactsBySearch(page, pageSize, textsrch);

                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View("ViewContact", model);
            }
            else
            {
                ViewBag.ViewContact = "ViewContact";
                PagingDTO<Contact> model = UOF.IEvent.GetContacts(page, pageSize, startDate, endDate);

                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View("ViewContact", model);
            }
        }

        [HttpGet]
        public ActionResult AddMember()
        {
            ViewBag.AddMember = "AddMember";
            return View();
        }

        [HttpPost]
        public ActionResult AddMember(Member2DTO modelData)
        {
            ViewBag.AddMember = "AddMember";
            try
            {
                if (ModelState.IsValid)
                {
                    //Check already existing email
                    bool isMemberEmailAlreadyExists = UOF.IMember.Check_Member_Email_Already_Exists(modelData.Email);
                    if (isMemberEmailAlreadyExists == true)
                    {
                        ModelState.AddModelError("Email", "Email Id already exists. Please choose some other Email Id.");
                        return View(modelData);
                    }

                    MemberDTO model = UOF.IMember.MemberRegistrationByAdmin(modelData);
                    try
                    {
                        bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(model);
                        if (mailStatus == true)
                        {
                            int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(model.MemberId);
                        }
                        ViewBag.Message = "Member Account created Successfully.";
                        ModelState.Clear();
                    }
                    catch (Exception ex) { }
                }
                else
                {
                    ModelState.AddModelError("", "Please fill the form with correct data.");
                }
            }
            catch (Exception ex) { }

            return View();
        }

        [HttpPost]
        public JsonResult AddMemberByAdmin(Member2DTO modelData)
        {
            try
            {
                MemberDTO model = UOF.IMember.MemberRegistrationByAdminForSubscribe(modelData);
                try
                {
                    //ForgotPasswordHistoryViewModel mod = new ForgotPasswordHistoryViewModel();
                    //mod.EmailId = model.Email;
                    //string resetUrl = AppUnitOfWork.CommonLogics.AddForgotPasswordData(mod);
                    //MailSender obj = new MailSender();
                    //bool mailStatus = obj.SendMail_ResetPasswordByAdmin(mod, resetUrl);
                    //if (mailStatus == true)
                    //{
                    //    int? totalSentMailCount = memberRepo.IncreaseMailSentCounter(model.MemberId);
                    //}
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex) { }
            }
            catch (Exception ex) { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        public ActionResult EventTypes()
        {
            IEnumerable<EventType> model = UOF.IEvent.GetAllEventTypes();
            ViewBag.ViewEventTypes = "EventTypes";
            return View(model);
        }
        public ActionResult CreateEventType()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateEventType(EventType model)
        {
            try
            {
                bool status = UOF.IEvent.CreateEventType(model);

                if (status == true)
                {
                    ViewBag.Message = "Type has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add Type this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult EditEventType(int Id)
        {
            EventType model = new EventType();
            model = UOF.IEvent.GetEventType(Id);
            return View(model);
        }
        [HttpPost]
        public ActionResult EditEventType(EventType model)
        {
            try
            {
                bool status = UOF.IEvent.UpdateEventType(model);

                if (status == true)
                {
                    ViewBag.Message = "Type has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Type this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("EventTypes");
        }
        public ActionResult EventTypeDelete(int id)
        {
            bool status = UOF.IEvent.DeleteEventType(id);


            return RedirectToAction("EventTypes");
        }



        //[HttpGet]
        //public ActionResult PassedBatchDelete(int id)
        //{
        //    bool status = AppUnitOfWork.Admins.BatchDelete(id);
        //    return RedirectToAction("ViewPassedBatches");
        //}

        public ActionResult ViewAllAdminMaster(int page = 1)
        {
            TempData["Message"] = "";

            PagingDTO<AdminMasterDTO> model = UOF.IAdminMaster.GetAdminDetails(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult AddAdminDetails()
        {
            TempData["Message"] = "";
            AdminMasterDTO AdminModel = new AdminMasterDTO();
            ViewBag.ViewAllAdmin = "View All Admin";
            List<RoleMastersDTO> RoleMasterList = UOF.IAdminMaster.GetRoleList();
            AdminModel.RoleMasterList = RoleMasterList;
            return View(AdminModel);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddAdminDetails(AdminMasterDTO model, string[] Roles)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["adminImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                string pathurl = "";
                // string oldpic = CurrentUser.ProfilePic;

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _adminImageFolderLocation;
                    _adminImageFolderLocation = ConfigurationManager.AppSettings["adminImageFolder"].ToString();

                    string path = Path.Combine(Server.MapPath(_adminImageFolderLocation), myfile);
                    pathurl = "/" + _adminImageFolderLocation + myfile;

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                }
                else
                {
                    pathurl = "";
                }
                model.ProfilePic = pathurl;
                bool stat = UOF.IAdminMaster.AddAdmin(model, Roles);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ViewAllAdminMaster");
        }

        [HttpGet]
        public ActionResult EditAdmin(int id)
        {
            TempData["Message"] = "";
            AdminMasterDTO model = UOF.IAdminMaster.GetAdminDetail(id);
            List<RoleMastersDTO> RoleMasterList = UOF.IAdminMaster.GetRoleList();
            model.RoleMasterList = RoleMasterList;
            model.RoleList = ViewBag.SelectedRoles = UOF.IAdminMaster.GetRoleListById(id);
            List<SelectListItem> Select_List = new List<SelectListItem>();
            foreach (var r in RoleMasterList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = r.RoleId.ToString(),
                    Text = r.RoleName,
                    Selected = model.RoleList.Where(me => me.RoleId == r.RoleId).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }
            model.RoleMaster = Select_List;
            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditAdmin(AdminMasterDTO model, FormCollection RoleName)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["adminImageFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                String rId = RoleName["RoleName"];
                string pathurl = "";
                string oldpic = "";
                bool oldflag = false;
                AdminMaster testdt = UOF.IAdminMaster.Get(model.AdminId);
                if (testdt != null)
                {
                    oldpic = testdt.ProfilePic;
                }

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = CurrentUser.UserId + time + ext; //

                    string _adminImageFolderLocation;
                    _adminImageFolderLocation = ConfigurationManager.AppSettings["adminImageFolder"].ToString();

                    pathurl = "/" + _adminImageFolderLocation + myfile;
                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    oldflag = true;
                }
                else
                {
                    pathurl = oldpic;
                }
                model.ProfilePic = pathurl;
                bool stat = UOF.IAdminMaster.UpdateAdmin(model, rId);
                if (stat != false)
                {
                    if (oldflag == true)
                    {
                        Uri uri = new Uri(ImgCloudPath + oldpic);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();
                    }
                    TempData["Message"] = "Details has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewAllAdminMaster");
        }

        public ActionResult DeleteAdminMaster(int id)
        {
            bool status = UOF.IAdminMaster.DeleteAdmin(id);

            return RedirectToAction("ViewAllAdminMaster");
        }

        public ActionResult ViewJobs(int page = 1)
        {
            ViewBag.ViewJobs = "ViewJobs";

            PagingDTO<Job> model = UOF.IJob.GetJobDetailsAdmin(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult ViewAppliedJobs(int page = 1, int id = 0)
        {
            ViewBag.ViewJobs = "ViewAppliedJobs";

            PagingDTO<AppliedJob> model = UOF.IJob.GetAppliedJobDetails(page, pageSize, id);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult AddJob()
        {
            ViewData["CurrentDate"] = DateTime.Now;
            ViewBag.AddJob = "AddJob";
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddJob(Job model)
        {
            try
            {
                bool status = UOF.IJob.CreateJob(model);
                if (status == true)
                {
                    ViewBag.Message = "Job has been saved successfully";
                    ModelState.Clear();
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            ViewBag.AddJob = "AddJob";
            return View();
        }

        [HttpGet]
        [TimeZoneFliter]
        public ActionResult EditJob(int id)
        {
            try
            {
                var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
                double minutes2 = Convert.ToDouble(defaultzone);
                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

                var timeOffSet = zone.Id;
                ViewBag.EditJob = "EditJob";
                Job model = UOF.IJob.GetJobById(id);
                int addHours = 0;
                var IsDayLight = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
                if (IsDayLight != null)
                {
                    addHours = IsDayLight.AppValue == "0" ? 0 : 1;
                }
                ViewData["ExpiryDate"] = model.ExpiryDate = model.ExpiryDate.ToClientTimeDate1(timeOffSet.ToString(),addHours);

                return View(model);
            }
            catch (Exception w)
            {
                return null;
            }

        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditJob(Job model)
        {
            try
            {
                bool status = UOF.IJob.UpdateJob(model);
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            ViewBag.EditJob = "EditJob";
            return RedirectToAction("ViewJobs");
        }

        public ActionResult DeleteJob(int id, int page = 1)
        {
            bool status = UOF.IJob.DeleteJob(id);
            if (status == true)
            {
                ViewBag.Message = "Successfully Deleted!";
            }
            return RedirectToAction("ViewJobs", new { page = page });
        }
        public ActionResult DeleteAppliedJob(int id, int page = 1)
        {
            bool status = UOF.IJob.DeleteAppliedJobs(id);
            if (status == true)
            {
                ViewBag.Message = "Successfully Deleted!";
            }
            return RedirectToAction("ViewAppliedJobs", new { page = page });
        }

        public ActionResult SendMailForSubscription(string emailIds, int page = 1)
        {
            string[] ids = emailIds.Split(',');
            if (ids.Count() > 0)
            {
                for (int i = 0; i < ids.Length; i++)
                {
                    string id = ids[i];
                    try
                    {
                        string _subscribeUrl = UOF.ICommonLogic.VerifyEmailSubscription(id);
                        if (!string.IsNullOrEmpty(_subscribeUrl))
                        {
                            bool status = MailClient.SendMail_Subscription(id, _subscribeUrl);
                            if (status == true)
                            {
                                int? totalSentMailCount = UOF.ICommonLogic.IncreaseSubscribeMailSentCounter(id);
                            }
                        }
                    }
                    catch (Exception ex) { }
                }
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult SendMailUnverifiedMember(string Ids, int page = 1)
        {
            string[] ids = Ids.Split(',');
            if (ids.Count() > 0)
            {
                for (int i = 0; i < ids.Length; i++)
                {
                    long id = Convert.ToInt64(ids[i]);
                    try
                    {
                        MemberDTO model = UOF.IMember.GetMember(id);
                        if (model.MemberId > 0)
                        {
                            bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(model);
                            if (mailStatus == true)
                            {
                                int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(model.MemberId);
                            }
                        }
                    }
                    catch (Exception ex) { }
                }
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ViewAllRoles(int page = 1)
        {
            TempData["Message"] = "";
            ViewBag.ViewAllRoles = "ViewAllRoles";

            PagingDTO<RoleMastersDTO> model = UOF.IAdminMaster.GetRoleDetails(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        [HttpGet]
        public ActionResult AddRoles()
        {
            TempData["Message"] = "";
            RoleMastersDTO RoleModel = new RoleMastersDTO();
            ViewBag.ViewAllRole = "View Role";
            return View(RoleModel);
        }
        [HttpPost]
        public ActionResult AddRoles(RoleMastersDTO model)
        {
            try
            {
                bool status = UOF.IAdminMaster.CreateRoles(model);

                if (status == true)
                {
                    ViewBag.Message = "Role has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add Role this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult EditRole(int Id)
        {
            RoleMastersDTO model = new RoleMastersDTO();
            model = UOF.IAdminMaster.GetRoleById(Id);
            return View(model);
        }
        [HttpPost]
        public ActionResult EditRole(RoleMastersDTO model)
        {
            try
            {
                bool status = UOF.IAdminMaster.UpdateRole(model);

                if (status == true)
                {
                    ViewBag.Message = "Role has been updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Role this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ViewAllRoles");
        }

        public ActionResult DeleteRole(int id, int page = 1)
        {
            bool status = UOF.IAdminMaster.DeleteRole(id);
            if (status == true)
            {
                ViewBag.Message = "Successfully Deleted!";
            }
            return RedirectToAction("ViewAllRoles", new { page = page });
        }

        public ActionResult CacheDetail()
        {
            return View();
        }

        public ActionResult CacheManage()
        {
            CacheService.ClearCache();
            Response.Cache.SetNoStore();
            Response.Cache.SetNoServerCaching();
            TempData["msg"] = "Cache is Cleaned";
            return RedirectToAction("CacheDetail");
        }
        public ActionResult DeleteExcelFile()
        {
            try
            {
                var path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel));
                string[] filePaths = Directory.GetFiles(path);
                foreach (string filePath in filePaths)
                    System.IO.File.Delete(filePath);

                TempData["msg"] = "Excel File is Cleaned";
            }
            catch (Exception e)
            {
                TempData["msg"] = "Excel File is not Cleaned";

            }

            return RedirectToAction("CacheDetail");
        }

        public ActionResult DeleteMemberPic(Int64 id)
        {
            try
            {
                //MemberDTO model = UOF.IMember.GetMember(id);
                if (id > 0)
                {
                    UOF.IMember.UpdateMemberProfilePic(id, null);
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex) { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }

        //Skill Types
        public ActionResult SkillTypes(int page = 1, int SkillId = 0)
        {
            try
            {
                ViewBag.SkillTypes = "Skill Types";
                PagingDTO<SkillMaster> model = new PagingDTO<SkillMaster>();
                model = UOF.IAdminMaster.GetAllSkillMasterList(page, pageSize, SkillId);
                ViewBag.skillList = UOF.ICourse.GetCourseSkillList();
                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View(model);
            }
            catch (Exception)
            {
            }
            return null;
        }
        public ActionResult CreateSkillType()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateSkillType(SkillMaster model)
        {
            try
            {
                bool status = UOF.IAdminMaster.CreateSkillType(model);

                if (status == true)
                {
                    ViewBag.Message = "Type has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add Type this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult EditSkillType(int Id)
        {
            SkillMaster model = new SkillMaster();
            model = UOF.IAdminMaster.GetSkillType(Id);
            return View(model);
        }
        [HttpPost]
        public ActionResult EditSkillType(SkillMaster model)
        {
            try
            {
                bool status = UOF.IAdminMaster.UpdateSkillType(model);

                if (status == true)
                {
                    ViewBag.Message = "Type has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Type this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("SkillTypes");
        }
        public ActionResult SkillTypeDelete(int id)
        {
            bool status = UOF.IAdminMaster.DeleteSkillType(id);


            return RedirectToAction("SkillTypes");
        }


        [TimeZoneFliter]
        public ActionResult ViewCorporate(int page = 1, string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewCorporate = "ViewCorporate";
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            string timeOffSet = zone.Id;
            PagingDTO<CorporateEnquiry> model = UOF.IQuery.GetCorporate(page, pageSize, textsrch, startDate, endDate, timeOffSet);
            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            if (model != null)
            {
                ViewBag.page = model.Page;
                Session["page"] = model.Page;
            }
            ViewBag.CourseList = UOF.ICommonLogic.GetCourseList();

            return View(model);
        }

        public ActionResult DeleteBulkCorporateQueries(string Ids)
        {
            string[] ids = Ids.Split(',');
            if (ids.Count() > 0)
            {
                UOF.IAdminMaster.DeleteBulkCorporate(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }


        [TimeZoneFliter]
        public ActionResult ViewPostJobs(int page = 1, string textsrch = "", string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            ViewBag.ViewCorporate = "ViewPostJobs";
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            var timeOffSet = zone.Id;
            PagingDTO<PostJobs> model = UOF.IQuery.GetPostJobs(page, pageSize, textsrch, startDate, endDate, timeOffSet);
            ViewBag.AdminUsers = UOF.IAdminMaster.GetMany(5);
            if (model != null)
            {
                ViewBag.page = model.Page;
                Session["page"] = model.Page;
            }
            ViewBag.CourseList = UOF.ICommonLogic.GetCourseList();

            return View(model);
        }

        [HttpGet]
        public ActionResult DeletePostjobs(int page = 1, int id = 0)
        {
            bool status = UOF.IQuery.DeletePostjobs(id);
            return RedirectToAction("ViewPostJobs", new { page = page });

        }

        public ActionResult CoursePricesList(int page = 1, int CourseType = 3, int? CourseId = null)
        {
            ViewBag.CoursePricesList = "CoursePricesList";
            PagingDTO<CoursePrices_v1> model = new PagingDTO<CoursePrices_v1>();
            ViewBag.CourseList = UOF.ICommonLogic.AllGetCourseList();
            model = UOF.IAdminMaster.GetViewCoursePricesList(page, 10, CourseType, CourseId);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

    }
}
