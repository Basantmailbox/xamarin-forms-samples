﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;



using DNTShared.Entities;
using DNTShared;
using DNTShared.DTO;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{    
    [RouteArea("Admin")]
    public class DocumentController : BaseController
    {
        // GET: /Admin/Document/
        public string ImgCloudPath = "";
        static CloudBlobClient blobClient;
        static CloudBlobContainer blobContainer;
        CloudStorageAccount storageAccount;
        int pageSize;
        public DocumentController()            
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewAllDocumentsList(int page = 1, string sort = "DocumentId", string sortDir = "asc", int DocumentTypeId = 0, int CourseId = 0)
        {
            PagingBatchDocDTO<DocumentDTO> model = new PagingBatchDocDTO<DocumentDTO>();
            ViewBag.ViewAllDocumentsList = "ViewAllDocumentsList";
            BindDocumentType();
            model = UOF.IDocument.GetViewAllDocumentsList(page, pageSize, DocumentTypeId, CourseId);
            //List<DocumentTypeViewModel> documentTypeList = AppUnitOfWork.Documents.GetDocumentTypeList();
            ////model.documentTypeList = documentTypeList;
            if (model != null)
            {
                model.CourseId = CourseId;
                model.Courses = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.SelectedValue = DocumentTypeId;
                ViewBag.DocumentTypeId = DocumentTypeId;
                ViewBag.page = model.Page;
            }
            else
            {
                model = new PagingBatchDocDTO<DocumentDTO>();
                model.CourseId = CourseId;
                model.Courses = UOF.ICommonLogic.AllGetCourseList();
                ViewBag.SelectedValue = DocumentTypeId;
                ViewBag.DocumentTypeId = DocumentTypeId;
            }
            return View(model);

        }

        void BindDocumentType()
        {
            var tblDocumenttypelist = UOF.IDocumentType.GetAll().OrderBy(x => x.DocumentTypeName);

            List<DocumentDTO> DocumentTypeList = new List<DocumentDTO>();

            DocumentDTO mobj = new DocumentDTO();
            mobj.DocumentTypeId = 0;
            mobj.DocumentTypeName = "- Select Document Type -";
            DocumentTypeList.Add(mobj);

            foreach (var item in tblDocumenttypelist)
            {
                mobj = new DocumentDTO();
                mobj.DocumentTypeId = item.DocumentTypeId;
                mobj.DocumentTypeName = item.DocumentTypeName;

                DocumentTypeList.Add(mobj);
            }
            ViewBag.documentType = DocumentTypeList;
        }
        public ActionResult CreateDocuments()
        {
            TempData["Message"] = "";
            DocumentDTO DocModel = new DocumentDTO();
            ViewBag.ViewAllDocumentsList = "ViewAllDocumentsList";
            ViewBag.courseList = UOF.ICourse.GetCoursesExcludingSelfPaced();

            List<DocumentType> documentTypeList = UOF.IDocument.GetDocumentTypeList();
            DocModel.documentTypeList = documentTypeList;

            return View(DocModel);
        }

        //[HttpPost]
        //public JsonResult SaveDocument(DocumentViewModel model)
        //{
        //    try
        //    {
        //        int DocumentId = AppUnitOfWork.Documents.SaveDocumentDetails(model);
        //      return Json(new { DocumentId = DocumentId }, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(new { DocumentId = 0 }, JsonRequestBehavior.AllowGet);
        //    }

        //}
        [HttpPost, ValidateInput(false)]
        public ActionResult CreateDocuments(DocumentDTO model)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                string pathurl = "";

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  
                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = "";
                    if (model.DocumentTypeId != 3)
                    {
                        
                         myfile = CurrentUser.UserId + time + ext;
                    }
                    else 
                    {
                        myfile = name + ext; 
                    }
                    string _documentFolderFolderLocation;
                    _documentFolderFolderLocation = ConfigurationManager.AppSettings["documentFolder"].ToString();

                    //string path = Path.Combine(Server.MapPath(_documentFolderFolderLocation), myfile);
                    pathurl = "/" + _documentFolderFolderLocation + myfile;

                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    //pathurl = _documentFolderFolderLocation + myfile;


                    //string directoryPath = Server.MapPath(string.Format("~/{0}/", _documentFolderFolderLocation));
                    //if (!Directory.Exists(directoryPath))
                    //{
                    //    Directory.CreateDirectory(directoryPath);
                    //}

                    //model.File.SaveAs(path);
                }
                else
                {
                    pathurl = "";
                }
                model.DocumentUrl = pathurl;
                bool stat = UOF.IDocument.SaveDocumentDetails(model);
                if (stat != false)
                {
                    TempData["Message"] = "Details has been saved successfully";
                    ModelState.Clear();

                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            DocumentDTO DocModel = new DocumentDTO();
            ViewBag.ViewAllDocumentsList = "ViewAllDocumentsList";
            List<CourseDTO> courseList = UOF.ICommonLogic.AllGetCourseList();
            DocModel.courseList = courseList;

            List<DocumentType> documentTypeList = UOF.IDocument.GetDocumentTypeList();
            DocModel.documentTypeList = documentTypeList;

            return View(DocModel);

            // return RedirectToAction("ViewAllTestimonial");
        }

         [Route("DocumentDelete/{id}/{DocumentTypeId}/{page}")]
        public ActionResult DocumentDelete(int id, int DocumentTypeId = 0,int page = 1)
        {
            TempData["Message"] = "";
            blobClient = storageAccount.CreateCloudBlobClient();
            blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
            blobContainer.CreateIfNotExistsAsync();
            //Basant_Rep
            var mobj = UOF.IDocument.Get(id);
            if (mobj != null)
            {
                UOF.IDocument.Remove(mobj);
                UOF.SaveChanges();
            }

            var docUrl = "";
            docUrl = ImgCloudPath+mobj.DocumentUrl;
            Uri uri = new Uri(docUrl);
            string filename = Path.GetFileName(uri.LocalPath);

            var blob = blobContainer.GetBlockBlobReference(filename);
            blob.DeleteIfExistsAsync();

            return RedirectToAction("ViewAllDocumentsList", new { page = page ,
                                                                  DocumentTypeId = DocumentTypeId,
            });
        }

        [HttpGet]

        [Route("EditDocument/{DocumentId}")]
        public ActionResult EditDocument(int DocumentId)
        {
            TempData["Message"] = "";
            DocumentDTO DocModel = new DocumentDTO();
            ViewBag.ViewAllDocumentsList = "ViewAllDocumentsList";

            DocModel = UOF.IDocument.GetDocumentById(DocumentId);
            ViewBag.courseList = UOF.ICourse.GetCoursesExcludingSelfPaced();
            DocModel.CourseId = DocModel.CourseId;
            List<DocumentType> documentTypeList = UOF.IDocument.GetDocumentTypeList();
            DocModel.documentTypeList = documentTypeList;

            return View(DocModel);
          
        }

        [HttpPost, ValidateInput(false)]
        [Route("EditDocument/{DocumentId}")]
        public ActionResult EditDocument(DocumentDTO model)
        {
            try
            {
                blobClient = storageAccount.CreateCloudBlobClient();
                blobContainer = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                blobContainer.CreateIfNotExistsAsync();

                string pathurl = "";
                string oldurl = "";
                bool oldflag = false;
                //Basant_Rep
                Document docdt = UOF.IDocument.Get(model.DocumentId);
                if (docdt != null)
                {
                    oldurl = docdt.DocumentUrl.Replace(ImgCloudPath, "");
                }

                if (model.File != null && model.File.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(model.File.FileName); //file name  
                    var ext = Path.GetExtension(model.File.FileName); //getting the extension(ex-.jpg)  

                    string name = Path.GetFileNameWithoutExtension(fileName);
                    string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string myfile = "";
                    if (model.DocumentTypeId != 3)
                    {
                        myfile = CurrentUser.UserId + time + ext;
                    }
                    else
                    {
                        myfile = name + ext;
                    }

                    string _documentFolderFolderLocation;
                    _documentFolderFolderLocation = ConfigurationManager.AppSettings["documentFolder"].ToString();

                    pathurl = "/" + _documentFolderFolderLocation + myfile;
                    CloudBlockBlob blockBlob = blobContainer.GetBlockBlobReference(myfile);
                    using (var fileStream = model.File.InputStream)
                    {
                        blockBlob.UploadFromStream(fileStream);
                    }
                    oldflag = true;
                }
                else
                {
                    pathurl = oldurl;
                }
                model.DocumentUrl = pathurl;
                bool stat = UOF.IDocument.UpdateDocument(model);
                if (stat != false)
                {
                    if (oldflag == true)
                    {
                        Uri uri = new Uri(ImgCloudPath + oldurl);
                        string filename = Path.GetFileName(uri.LocalPath);

                        var blob = blobContainer.GetBlockBlobReference(filename);
                        blob.DeleteIfExistsAsync();
                    }
                    TempData["Message"] = "Details has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["Message"] = "Error!!";
                }

            }
            catch (Exception ex)
            {

            }
            return RedirectToAction("ViewAllDocumentsList");
        }

        public ActionResult ViewAllDocumentsTypeList()
        {
            IEnumerable<DocumentType> model = UOF.IDocument.GetAllDocumentTypes();
            return View(model);

        }


        public ActionResult CreateDocumentsType()
        {
                return View();
        }
        [HttpPost]
        public ActionResult CreateDocumentsType(DocumentType model)
        {
            try
            {
                bool status = UOF.IDocument.CreateDocumentType(model);

                if (status == true)
                {
                    ViewBag.Message = "Document Type has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add Document Type this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }

        public ActionResult EditDocumentType(int DocumentTypeId)
        {
            DocumentType model = new DocumentType();
            model=UOF.IDocument.GetDocumentType(DocumentTypeId);
            return View(model);
        }
        [HttpPost]
        public ActionResult EditDocumentType(DocumentType model)
        {
            try
            {
                bool status = UOF.IDocument.UpdateDocumentType(model);

                if (status == true)
                {
                    ViewBag.Message = "Document Type has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Document Type this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View();
        }
        public ActionResult DocumentTypeDelete(int id)
        {
            bool status = UOF.IDocument.DeleteDocumentType(id);

            
            return RedirectToAction("ViewAllDocumentsTypeList");
        }

        public ActionResult GetAllDocumentsByCourse(int CourseId)
        {
            //Basant_Rep
            List<Document> data = UOF.IDocument.GetMany("assignment", CourseId);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        

    }
}
