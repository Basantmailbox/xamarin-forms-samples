﻿using DNTData;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using DNTWebCore;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebUI.Models;
using DNTWebUI.Models.Security;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class BatchController : BaseController
    {
        //
        // GET: /Admin/Batch/


        int pageSize;
        public BatchController()
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CreateBatchMaster()
        {
            try
            {
                BatchMasterDTO BatchModel = new BatchMasterDTO();
                ViewBag.BatchMaster = "BatchMaster";
                List<CourseDTO> courseList = UOF.ICommonLogic.GetCoursesByType((int)EnumCourseType.Instructorled).OrderBy(c => c.Name).ToList();
                BatchModel.CourseList = courseList;

                //Bind Training Mode
                List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
                BatchModel.TrainingModeList = trainingModeList;

                List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
                BatchModel.MentorList = MentorMasterList;

                ViewData["CurrentDate"] = DateTime.Now;

                string code = UOF.IAdminMaster.GetBatchCode();
                if (code != null)
                {
                    string codeno = code.Substring(3);
                    int codeCount = Convert.ToInt32(codeno);
                    if (codeCount != 9)
                    {
                        if (codeCount.ToString().Length == 1)
                        {
                            codeCount++;
                            code = "DNT0" + codeCount.ToString();
                        }
                        else
                        {
                            codeCount++;
                            code = "DNT" + codeCount.ToString();
                        }
                    }
                    else
                    {
                        codeCount++;
                        code = "DNT" + codeCount.ToString();
                    }


                }
                else { code = "DNT01"; }

                IEnumerable<EnumDaysType> DTypelist = Enum.GetValues(typeof(EnumDaysType))
                                                     .Cast<EnumDaysType>();
                ViewBag.DTypelist = from action in DTypelist
                                    select new SelectListItem
                                    {
                                        Text = action.ToString(),
                                        Value = ((int)action).ToString()
                                    };

                BatchModel.BatchCode = code;
                var lstzone = TimeZoneInfo.GetSystemTimeZones();
                ViewBag.listzone = from action in lstzone
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.BaseUtcOffset.ToString()
                                   };
                return View(BatchModel);
            }
            catch (Exception)
            {
                return null;
            }

        }

        [HttpPost]
        public ActionResult CreateBatchMaster(BatchMasterDTO model, string[] Dayslist)
        {
            try
            {
                bool status = UOF.IAdminMaster.AddBatchMaster(model, Dayslist);

                ViewBag.BatchMaster = "BatchMaster";
                List<CourseDTO> courseList = UOF.ICommonLogic.GetCoursesByType((int)EnumCourseType.Instructorled);
                model.CourseList = courseList;

                //Bind Training Mode
                List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
                model.TrainingModeList = trainingModeList;
                List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
                model.MentorList = MentorMasterList;

                ViewData["CurrentDate"] = DateTime.Now;

                if (status == true)
                {
                    ViewBag.Message = "Batch has been saved successfully";
                    ModelState.Clear();
                    CacheService.ClearCache();
                }
                else
                {
                    ViewBag.Message = "Unable to add Batch this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            return RedirectToAction("BatchMaster");
        }

        [TimeZoneFliter]
        [HttpGet]
        [Route("EditBatchMaster/{batchid}")]
        public ActionResult EditBatchMaster(int batchid = 0)
        {
            try
            {
                var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
                double minutes2 = Convert.ToDouble(defaultzone);

                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
                var timeOffSet = zone.Id;
                BatchMasterDTO BatchModel = new BatchMasterDTO();
                ViewBag.BatchMaster = "BatchMaster";
                BatchModel = UOF.IAdminMaster.GetBatchDetails(batchid);
                if (BatchModel != null)
                {
                    int addHour = 0;
                    var appSettingObj = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
                    if (appSettingObj != null)
                    {
                        addHour = appSettingObj.AppValue == "1" ? 1 : 0;
                    }

                    ViewData["StartDate"] = BatchModel.StartDate.ToClientTimeDate1(timeOffSet.ToString(), addHour);
                    BatchModel.BatchTiming = BatchModel.BatchTiming.ToClientTimeDate1(timeOffSet.ToString(), addHour);

                }

                ViewData["EndDate"] = BatchModel.EndDate;
                List<MentorMaster> MentorMasterList = UOF.ICourse.GetMentorMasterList();
                BatchModel.MentorList = MentorMasterList;

                List<CourseDTO> courseList = UOF.ICommonLogic.GetCoursesByType((int)EnumCourseType.Instructorled);
                BatchModel.CourseList = courseList;

                //Bind Training Mode
                List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
                BatchModel.TrainingModeList = trainingModeList;
                ViewData["CurrentDate"] = DateTime.Now;
                ViewBag.BatchTiming = BatchModel.BatchTiming.Hour.ToString() + ":" + BatchModel.BatchTiming.Minute.ToString();
                ViewBag.FullDetail = BatchModel.BatchName + ";" + BatchModel.StartDate + ";" + BatchModel.EndDate + ";" + BatchModel.BatchTiming + ";" + BatchModel.TrainingMode + ";" + BatchModel.PostedBy + ";" + BatchModel.Url;

                //Bind days
                IEnumerable<EnumDaysType> DTypelist = Enum.GetValues(typeof(EnumDaysType))
                                                     .Cast<EnumDaysType>();
                var Dayslist = (from action in DTypelist
                                select new SelectListItem
                                {
                                    Text = action.ToString(),
                                    Value = ((int)action).ToString()
                                }).ToList();

                string[] day = { "-" };
                if (BatchModel.BatchDays != null)
                {
                    day = BatchModel.BatchDays.Split(',');
                }
                var types = new List<SelectListItem>();
                var contday = "";
                for (var i = 0; i < day.Length; i++)
                {
                    switch (day[i])
                    {
                        case "0":
                            // contday += EnumDaysType.Monday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Monday.ToString(), Value = "0" });
                            break;
                        case "1":
                            contday += EnumDaysType.Tuesday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Tuesday.ToString(), Value = "1" });
                            break;
                        case "2":
                            contday += EnumDaysType.Wednesday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Wednesday.ToString(), Value = "2" });
                            break;
                        case "3":
                            contday += EnumDaysType.Thursday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Thursday.ToString(), Value = "3" });
                            break;
                        case "4":
                            contday += EnumDaysType.Friday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Friday.ToString(), Value = "4" });
                            break;
                        case "5":
                            contday += EnumDaysType.Saturday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Saturday.ToString(), Value = "5" });
                            break;
                        case "6":
                            contday += EnumDaysType.Sunday;
                            types.Add(new SelectListItem() { Text = EnumDaysType.Sunday.ToString(), Value = "6" });
                            break;
                        default:
                            contday += "-";
                            break;
                    }

                    //alert(contday)
                }

                List<SelectListItem> Select_List = new List<SelectListItem>();
                foreach (var m in Dayslist)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = m.Value,
                        Text = m.Text,
                        Selected = types.Where(me => me.Value == m.Value).Count() > 0 ? true : false
                    };

                    Select_List.Add(obj);
                }
                BatchModel.DTypelist = Select_List;
                //Bind zone
                var lstzone = TimeZoneInfo.GetSystemTimeZones();
                ViewBag.listzone = from action in lstzone
                                   select new SelectListItem
                                   {
                                       Text = action.ToString(),
                                       Value = action.BaseUtcOffset.ToString()
                                   };
                return View(BatchModel);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        [TimeZoneFliter]
        [HttpPost]
        [ValidateInput(false)]
        [Route("EditBatchMaster/{batchid}")]
        public ActionResult EditBatchMaster(BatchMasterDTO model, FormCollection Dayslist)
        {
            try
            {
                String Dayslt = Dayslist["Dayslist"];
                string User = CurrentUser.Name;
                var NewDetail = model.StartDate + ";" + model.EndDate + ";" + model.BatchTiming;

                bool status = UOF.IAdminMaster.UpdateBatchMaster(model, Dayslt);
                if (status == true)
                {
                    ViewBag.Message = "Batch has been updated successfully";
                    MailClient.SendMail_EditBatchDetail(model.FullDetail, NewDetail, model.CourseId, User, model.TrainingModeId, model.Url);
                    ModelState.Clear();
                    CacheService.ClearCache();
                }
                else
                {
                    ViewBag.Message = "Unable to update Batch this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchMaster");
        }

        public ActionResult BatchMasterDelete(int id, int page = 1)
        {
            UOF.IAdminMaster.DeleteBatchMaster(id);
            return RedirectToAction("BatchMaster", new { page = page });
        }

        [TimeZoneFliter]
        public ActionResult Batches()
        {
            List<BatchMasterDTO> model = new List<BatchMasterDTO>();
            ViewBag.BatchMaster = "BatchMaster";
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

            var timeOffSet = zone.Id;
            model = UOF.IAdminMaster.getAllBatchListSales(timeOffSet);

            return View(model);

        }

        [TimeZoneFliter]
        public ActionResult BatchMaster(int page = 1, int filterId = 2, int CourseId = 0, int BatchId = 0, int ModeId = 1)
        {
            PagingDTO<BatchMasterDTO> model = new PagingDTO<BatchMasterDTO>();
            ViewBag.BatchMaster = "BatchMaster";
            model.CourseId = CourseId;
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

            var timeOffSet = zone.Id;
            model = UOF.IAdminMaster.getAllBatchList(page, pageSize, filterId, CourseId, BatchId, ModeId, timeOffSet);

            ViewBag.Courses = UOF.ICommonLogic.AllGetCourseList();
            ViewBag.BatchList = UOF.IBatchMaster.GetBatchCodeList();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.ModeId = ModeId;
            }
            ViewBag.SelectedValue = filterId;
            return View(model);

        }

        public ActionResult ManageAssessment(int page = 1, int batchId = 0, int CourseId = 0)
        {
            ViewBag.ManageAssessment = "ManageAssessment";
            PagingDTO<AssignedMockUpTestDTO> model = UOF.IQuestionMaster.GetBatchAssessmentDetails(page, pageSize, batchId);
            if (model != null)
            {
                ViewBag.page = model.Page;
                model.CourseId = CourseId;
                ViewBag.batchId = batchId;
            }
            return View(model);
        }

        public ActionResult ViewAllSubscribedMemberList(int id = 0, int page = 1, string textsearch = "")
        {

            ViewBag.BatchMaster = "BatchMaster";
            PagingDTO<CourseSubscriptionDTO> model = UOF.IAdminMaster.GetAllSubscriptionDetailsList(id, page, pageSize, textsearch);

            if (model != null)
            {
                ViewBag.page = model.Page;
                TempData["batchid"] = id;
                Session["batchid"] = id;
                ViewBag.BatchId = id;
            }
            else
            {

                ViewBag.BatchId = id;
            }
            return View(model);

        }

        public ActionResult SubscribedMemberToBatch(int page = 0, int MemberId = 0, int batchid = 0)
        {
            int id = 0;
            try
            {
                bool isMemberAlreadyExists = UOF.IAdminMaster.IsMemberAlreadyAddedInBatch(MemberId, batchid);
                if (isMemberAlreadyExists == false)
                {
                    bool status = UOF.IAdminMaster.AddBatchMemberSubscribedDetails(MemberId, batchid);
                    if (status == true)
                    {
                        id = batchid;
                        TempData["msgr"] = "";
                        TempData["msg"] = "Member added Successfully in this Batch!";
                    }
                }
                else
                {
                    id = batchid;
                    TempData["msg"] = "";
                    TempData["msgr"] = "Selected Member has been already added into this batch!";
                }

                return RedirectToAction("ViewAllSubscribedMemberList", new { id = id, page = page });
            }
            catch (Exception ex)
            { }

            return RedirectToAction("ViewAllSubscribedMemberList", new { id = id });
        }

        [ChildActionOnly]
        public ActionResult GetMemberListAddedInBatch(int page = 0, int batchid = 0)
        {
            ViewBag.BatchMaster = "BatchMaster";
            batchid = (int)Session["batchid"];
            List<CourseSubscriptionMemberDTO> model = UOF.IAdminMaster.GetMemberListAddedInBatch(batchid, page, pageSize);

            return PartialView("_GetMemberListAddedInBatch", model);
        }

        public ActionResult DeleteMemberFromBatch(int CourseSubscriptionId = 0, int batchid = 0)
        {
            bool status = UOF.IAdminMaster.DeleteMemberFromBatchMapping(CourseSubscriptionId, batchid);
            if (status == true)
            {
                return RedirectToAction("ViewAllSubscribedMemberList", new { id = batchid });
            }
            return View("BatchMaster");
        }

        [Route("ViewMembersInBatch/{batchid}")]
        public ActionResult ViewMembersInBatch(int page = 1, int batchid = 0)
        {
            ViewBag.BatchMaster = "BatchMaster";
            //batchid = (int)Session["batchid"];
            PagingBatchDocDTO<CourseSubscriptionMemberDTO> model = UOF.IAdminMaster.ViewMemberListAddedInBatch(batchid, page, pageSize);
            if (model != null)
            {

                ViewBag.page = model.Page;
                TempData["BatchName"] = model.BatchName;
            }
            else
            {

                ViewBag.BatchId = batchid;
            }

            return View(model);
        }

        [Route("BatchSchedule/{batchid}")]
        public ActionResult BatchSchedule(int batchid = 0)
        {
            BatchMasterDTO model = new BatchMasterDTO();
            model = UOF.IAdminMaster.GetBatchDetails(batchid);
            return View(model);
        }
        //Created by bharat 

        public ActionResult BatchScheduleEvents(List<BatchEventSchedule> model)
        {
            try
            {

                bool status = UOF.IAdminMaster.AddBatchEventShedule(model);


                if (status == true)
                {

                    ModelState.Clear();
                    return Json("Success");
                }
                else
                {
                    return Json("failed");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchSchedule");
        }

        [TimeZoneFliter]
        public JsonResult GetBatchSchedule(int batchid)
        {
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);

            IEnumerable<BatchEventSchedule> model = UOF.IAdminMaster.GetBatchEventSchedule(batchid);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            var timeOffSet = zone.Id;
            try
            {
                if (model.Count() != 0 && model != null)
                {
                    int addHours = 0;
                    var IsDayLight = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
                    if (IsDayLight != null)
                    {
                        addHours = IsDayLight.AppValue == "0" ? 0 : 1;
                    }
                    model = model.Select(x =>
                    {
                        x.StartDate = x.StartDateTime.ToClientTimeDate1(timeOffSet.ToString(), addHours).ToString("ddd MMM d yyyy HH: mm:ss 'GMT'");
                        return x;
                    });
                    return Json(model, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (System.Exception)
            {
                return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult UpdateBatchScheduleEvents(List<BatchEventSchedule> model)
        {
            try
            {
                bool status = UOF.IAdminMaster.UpdateBatchEventShedule(model);
                if (status == true)
                {
                    if (model[0].EventName == "Canceled" && model[0].OldEventName != "Canceled")
                    {

                        int batid = model[0].BatchId;
                        var allmemberMail = UOF.IAdminMaster.GetAllBatchMemberMail(batid);
                        if (!string.IsNullOrEmpty(allmemberMail))
                        {
                            MailClient.SendMail_ForBatchSchedule(model, allmemberMail);
                        }
                    }
                    ModelState.Clear();
                    return Json("Success");
                }
                else
                {
                    return Json("failed");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchSchedule");
        }

        public ActionResult UpdateOnMoveBatchScheduleEvents(List<BatchEventSchedule> model)
        {
            try
            {

                bool status = UOF.IAdminMaster.UpdateOnMoveBatchEventShedule(model);


                if (status == true)
                {

                    ModelState.Clear();
                    return Json("Success");
                }
                else
                {
                    return Json("failed");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchSchedule");
        }

        public ActionResult DeleteBatchScheduleEvents(List<BatchEventSchedule> model)
        {
            try
            {
                bool status = UOF.IAdminMaster.DeleteBatchEventShedule(model.FirstOrDefault());
                if (status == true)
                {
                    ModelState.Clear();
                    return Json("Success");
                }
                else
                {
                    return Json("failed");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchSchedule");
        }


        public ActionResult DeleteAssessment(int MockupTestAssignedBatchDetailId = 0, int batchId = 0)
        {
            try
            {
                bool status = UOF.IAdminMaster.DeleteMockupTestAssignedBatchDetail(MockupTestAssignedBatchDetailId, batchId);

                if (status == true)
                {
                    return RedirectToAction("ManageAssessment", new { batchId = batchId });
                }
                else
                {
                    ViewBag.Msg = "Sorry Plz try again later!!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ManageAssessment");
        }

        [HttpGet]
        public ActionResult EditAssessment(int MockupTestAssignedBatchDetailId = 0)
        {
            try
            {
                AssignedMockUpTestDTO model = new AssignedMockUpTestDTO();

                model = UOF.IAdminMaster.GetMokeUpAssessmentDetail(MockupTestAssignedBatchDetailId);

                ViewData["FromDate"] = model.FromDate;
                ViewData["ToDate"] = model.ToDate;
                ViewData["AssignmentFromDate"] = model.AssignmentFromDate;
                ViewData["AssignmentToDate"] = model.AssignmentToDate;
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        [HttpPost]
        public ActionResult EditAssessment(AssignedMockUpTestDTO model)
        {

            try
            {
                bool status = UOF.IAdminMaster.UpdateAssessment(model);

                if (status == true)
                {
                    TempData["msg"] = "Assessment has been updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    TempData["msgr"] = "Unable to update Assessment this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ManageAssessment", new { batchId = model.BatchId });
        }

        /////////live video
        public ActionResult LiveCourseTopicList(int page = 1, int CourseId = 0, int BatchId = 0)
        {
            try
            {
                Session["BatchId"] = null;
                Session["CourseId"] = null;
                PagingDTO<CourseLiveSessionVideo> model = new PagingDTO<CourseLiveSessionVideo>();
                ViewBag.BatchId = BatchId;
                ViewBag.CourseId = CourseId;
                ViewBag.LiveCourseTopicList = "LiveCourseTopicList";
                model = UOF.ICourseTopic.LiveCourseTopicList(page, pageSize, CourseId, BatchId);
                Session["BatchId"] = BatchId;
                Session["CourseId"] = CourseId;
                ViewBag.BatchCode = UOF.IBatchMaster.GetbatchCode(BatchId);
                return View(model);
            }
            catch (Exception ex)
            {
                CourseLiveSessionVideo model = new CourseLiveSessionVideo();
                ViewBag.Message = ex.Message;
                return View(model);
            }


        }
        //public ActionResult LiveTopicPdfDelete(int id,int CourseId = 0 ,int BatchId = 0, int page = 1)
        //{
        //    string oldpath = UOF.ICourseTopic.LiveTopicPdfDelete(id);
        //    if (oldpath != "")
        //    {
        //        try
        //        {
        //            string fullPath = Request.MapPath(oldpath);

        //            if (System.IO.File.Exists(fullPath))
        //            {
        //                System.IO.File.Delete(fullPath);
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            return RedirectToAction("LiveCourseTopicList", new { page = page, CourseId = CourseId, BatchId = BatchId });
        //        }

        //    }
        //    return RedirectToAction("LiveCourseTopicList", new { page = page, CourseId = CourseId, BatchId = BatchId });
        //}
        public ActionResult LiveCourseTopic(int CourseId = 0, int BatchId = 0)
        {
            CourseLiveSessionVideo model = new CourseLiveSessionVideo();
            ViewBag.LiveCourseTopicList = "LiveCourseTopicList";
            model.IsLock = true;

            ViewBag.CourseId = CourseId;
            ViewBag.BatchId = BatchId;
            ViewBag.BatchCode = UOF.IBatchMaster.GetbatchCode(BatchId);

            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult LiveCourseTopic(CourseLiveSessionVideo model)
        {
            try
            {

                bool status = UOF.ICourseTopic.CreateCourseLiveSessionVideo(model);

                ModelState.Clear();

                ViewBag.Message = "Topic has been saved successfully";
                // ViewBag.LiveTopicList = UOF.ICourseTopic.GetLiveCourseTopicList(model.CourseId,model.BatchId);
                ViewBag.CourseId = model.CourseId;
                ViewBag.BatchId = model.BatchId;
                return RedirectToAction("LiveCourseTopicList", new { CourseId = model.CourseId, BatchId = model.BatchId });
            }
            catch (Exception ex)
            {

                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View(model);

            }
        }
        [HttpGet]
        public ActionResult GetLiveTopicIdDetails(int LiveTopicId = 0)
        {
            try
            {
                CourseLiveSessionVideo data = new CourseLiveSessionVideo();
                data = UOF.ICourseTopic.GetLiveTopicIdDetails(LiveTopicId);
                ViewBag.CourseId = data.CourseId;
                ViewBag.BatchId = data.BatchId;
                ViewBag.BatchCode = UOF.IBatchMaster.GetbatchCode(data.BatchId);
                return View(data);
            }
            catch (Exception ex)
            {

                ViewBag.Message = "Unable to Get Course Topic this time. Please try again later.";
                return View();
            }
        }
        [HttpPost, ValidateInput(false)]
        public ActionResult GetLiveTopicIdDetails(CourseLiveSessionVideo model)
        {
            try
            {

                bool status = UOF.ICourseTopic.CreateCourseLiveSessionVideo(model);

                ModelState.Clear();

                ViewBag.Message = "Topic has been saved successfully";

                ViewBag.CourseId = model.CourseId;
                ViewBag.BatchId = model.BatchId;
                return RedirectToAction("LiveCourseTopicList", new { CourseId = model.CourseId, BatchId = model.BatchId });
            }
            catch (Exception ex)
            {

                ViewBag.Message = "Unable to Create Course Topic this time. Please try again later.";
                return View(model);

            }
        }
        public ActionResult LiveTopicDelete(int id, int page = 1)
        {
            UOF.ICourseTopic.LiveTopicDelete(id);
            int BatchId = (int)Session["BatchId"];
            int CourseId = (int)Session["CourseId"];
            return RedirectToAction("LiveCourseTopicList", new { page = page, CourseId = CourseId, BatchId = BatchId });
        }


        public ActionResult DownloadBatchMemberToExcel(int page = 1, int Batchid = 0)
        {
            ViewBag.BatchMaster = "BatchMaster";
            //batchid = (int)Session["batchid"];
            List<CourseSubscriptionMemberDTO> model = UOF.IAdminMaster.ViewMemberListAddedInBatchForExcel(Batchid);

            byte[] bytes = null;
            string time = DateTime.Now.ToString("yyyyMMddHHmmss");
            string ReportName = "MemberReport" + time + ".xlsx";
            string fileName = ReportName;
            using (var stream = new MemoryStream())
            {
                ExportManager objReceiving = new ExportManager();
                // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                string path = string.Empty;
                path = Server.MapPath(WebConfigSetting.DownloadExcel);
                if (!Directory.Exists(path))
                {
                    DirectoryInfo di = Directory.CreateDirectory(path);
                }
                string p_strPath = Path.Combine(path, fileName);
                objReceiving.GetReceivingMemberReport(stream, model, p_strPath);
                bytes = stream.ToArray();
            }
            // byte[] bytes = client.DownloadData(fullPath);
            return File(bytes, "text/xls", fileName);
        }

        public ActionResult AssessmentMasters(int page = 1, int batchid = 0, int CourseId = 0, int IsActive = 1)
        {
            try
            {
                ViewBag.AssessmentMasters = "AssessmentMasters";
                Session["CID"] = CourseId;
                PagingDTO<AssessmentMastersDTO> model = new PagingDTO<AssessmentMastersDTO>();
                model = UOF.IQuestionMaster.GetAllAssessmentMasters(page, pageSize, CourseId, batchid, IsActive);
                if (model != null)
                {
                    model.Courses = UOF.ICommonLogic.GetAllCourseList();
                    model.CourseId = CourseId;
                    ViewBag.page = model.Page;
                }
                else
                {
                    model = new PagingDTO<AssessmentMastersDTO>();
                    model.Courses = UOF.ICommonLogic.GetAllCourseList();
                    model.CourseId = CourseId;
                }
                ViewBag.isactive = IsActive;
                ViewBag.batch = UOF.IBatchMaster.GetbatchName(batchid);
                ViewBag.batchid = batchid;
                ViewData["CurrentDate"] = DateTime.Now;
                ViewData["NextMonthDate"] = DateTime.Now.AddMonths(1);
                return View(model);

            }
            catch (Exception ex)
            {

            }
            return View();
        }

        public ActionResult AssignAssessmentToBatch(AssessmentMastersDTO model)
        {
            string msg;
            bool isAssessmentAlreadyAssigned = UOF.IQuestionMaster.IsMockupTestAlreadyAssignedToBatch(model.AssessmentId, model.BatchID);
            if (isAssessmentAlreadyAssigned == true)
            {
                msg = "This Assessment is already assigned to selected batch.";
            }
            else
            {
                bool status = UOF.IQuestionMaster.AssignMockupTestToBatch(model.AssessmentId, model.BatchID, model);
                if (status == true)
                {
                    msg = "done";
                    var mailList = UOF.ICommonLogic.GetMemberListForMail(model.BatchID);

                    bool stat = MailClient.SendMail_MockUpAssign(mailList, model.AssessmentId);
                    if (stat == true)
                    {
                        msg = "done";
                    }
                    else
                    {
                        msg = "Mockup Test is not assigned to selected batch";
                    }

                }
                else { msg = "Mockup Test is not assigned to selected batch"; }
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
            // return RedirectToAction("AssessmentMapping", new { BatchId = batchId, AssessmentId = AssessmentId, courseId = courseId });
        }

        public ActionResult MailVideoToAllBatchMember(int BatchId, int LiveTopicId)
        {
            string msg;
            var mailList = UOF.ICommonLogic.GetMemberListForMail(BatchId);

            bool stat = MailClient.SendMail_LiveBatchVideo(mailList, BatchId, LiveTopicId);
            if (stat == true)
            {
                bool status = UOF.IBatchMaster.MailVideoToAllBatchMember(BatchId, LiveTopicId);
                msg = "done";
            }
            else
            {
                msg = "Error in mail sent";
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
            // return RedirectToAction("AssessmentMapping", new { BatchId = batchId, AssessmentId = AssessmentId, courseId = courseId });
        }

        public static IEnumerable<SelectListItem> GetCountryList()
        {
            IList<SelectListItem> items = new List<SelectListItem>
            {
                new SelectListItem{Text = "United States", Value = "B"},

            };
            return items;
        }

        public ActionResult MakeSelfPlacedBatch(int BatchId = 0, int CourseId = 0, int page = 0)
        {
            try
            {
                bool status = UOF.IBatchMaster.MakeSelfPlacedBatch(BatchId, CourseId);

                if (status == true)
                {
                    return RedirectToAction("BatchMaster", new { page = page });
                }
                else
                {
                    ViewBag.Msg = "Sorry Plz try again later!!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchMaster");
        }

        public ActionResult IsSelfPlacedBatch(int BatchId = 0, int CourseId = 0, int page = 0)
        {
            try
            {
                bool status = UOF.IBatchMaster.IsSelfPlacedBatch(BatchId, CourseId);

                if (status == true)
                {
                    return RedirectToAction("BatchMaster", new { page = page });
                }
                else
                {
                    ViewBag.Msg = "Sorry Plz try again later!!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("BatchMaster");
        }
    }
}
