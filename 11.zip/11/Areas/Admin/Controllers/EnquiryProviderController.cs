﻿
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Web.Helpers;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;


using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    /// <summary>
    /// Author : Basant Kumar
    /// Created Date : 4 Sep 2016
    /// </summary>

    [RouteArea("Admin")]
    public class EnquiryProviderController : BaseController
    {


        int pageSize;
        public EnquiryProviderController()

        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;


        }

        public ActionResult Index()
        {
            IEnumerable<EnquiryProvider> model = UOF.IEnquiryProvider.GetAll();
            return View(model);

        }


        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(EnquiryProvider model)
        {
            try
            {
                UOF.IEnquiryProvider.Add(model);

                if (UOF.SaveChanges() > 0)
                {
                    ViewBag.Message = "EnquiryProvider  has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to add this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }

            return View();
        }

        public ActionResult Edit(int id)
        {
            EnquiryProvider model = new EnquiryProvider();
            model = UOF.IEnquiryProvider.Get(id);

            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(EnquiryProvider model)
        {
            try
            {
                UOF.IEnquiryProvider.Update(model);

                if (UOF.SaveChanges() > 0)
                {
                    ViewBag.Message = "EnquiryProvider has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update EnquiryProvider this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("Index");
        }

        //public ActionResult EnquiryList(int page = 1, int providerId = 0, int ModeId = 1)
        //{
        //    PagedQueryViewModel model = new PagedQueryViewModel();

        //    model = enquiryRepo.GetAllQueryList(page, pageSize, providerId, ModeId);
        //    ViewBag.EnquiryList = "EnquiryList";

        //    List<EnquiryProviderViewModel> EnquiryProviderList = enquiryRepo.GetEnquiryProviders();

        //    ViewBag.ViewQuery = "ViewQuery";
        //    ViewBag.ProviderIdSelectedValue = providerId;
        //    ViewBag.ModeIdSelectedValue = ModeId;
        //    ViewBag.ModeId = ModeId;

        //    if (model != null)
        //    {
        //        model.EnqProviderList = EnquiryProviderList;
        //        ViewBag.page = model.Page;
        //    }
        //    else
        //    {
        //        PagedQueryViewModel model2 = new PagedQueryViewModel();
        //        model2.EnqProviderList = EnquiryProviderList;
        //        return View(model2);
        //    }
        //    return View(model);

        //}

    }
}
