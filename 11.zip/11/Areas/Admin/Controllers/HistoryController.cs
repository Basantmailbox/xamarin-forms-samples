﻿using DotNetTricks.COM.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;

using DNTShared;
using DNTShared.DTO;
using DNTData;
using DNTShared.Entities;
using System.IO;
using DNTWebUI.Models;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class HistoryController : BaseController
    {
        int pageSize;
        public HistoryController()

        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
        }

        public ActionResult CourseSubscription(int page = 1, string textsrch = "", int CourseId = 0, string Date = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (!Date.Contains("Invalid") && Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim()).AddHours(23).AddMinutes(59).AddSeconds(59);
            }
            else
            {
                startDate = DateTime.Today.AddDays(-7);
                endDate = DateTime.Today.AddDays(1);
            }

            ViewBag.SubscribedMemberDetails = "CourseSubscription";
            PagingDTO<CourseSubscriptionMemberDTO> model = UOF.IHistory.GetCourseSubscription(page, pageSize, textsrch, CourseId, true, startDate, endDate);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            ViewBag.Date = Date;
            //ViewBag.Courses = UOF.ICommonLogic.AllGetCourseList();


            IEnumerable<EnumCourseType> CTypelist = Enum.GetValues(typeof(EnumCourseType))
                                                    .Cast<EnumCourseType>();
            ViewBag.CourseTypeList = from action in CTypelist
                                     select new SelectListItem
                                     {
                                         Text = action.ToString(),
                                         Value = ((int)action).ToString()
                                     };


            Session["Message"] = null;
            Session["linkpage"] = "CourseSubscription";
            return View(model);
        }

    }
}
