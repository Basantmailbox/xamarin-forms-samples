﻿using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebUI.Models.Security;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class AccountController : BaseController
    {
        public AccountController()
        {
        }
        [HttpGet]
        [AllowAnonymous]
      [TimeZoneFliter]
        public ActionResult Index()
        {
            if (CurrentUser != null && CurrentUser.Email != "" && CurrentUser.UserId != 0)
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }
            return View();
        }
        [TimeZoneFliter]
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Index(LoginDTO model)
        {
            if (model.Email.Trim() != "" && model.Password.Trim() != "")
            {
                try
                {
                    AdminMasterDTO adminData = UOF.IAdminMaster.AuthenticateAdmin(model.Email, model.Password);
                    if (adminData != null)
                    {
                        if (adminData.IsVerified != true)
                        {
                            ModelState.AddModelError("", "The admin account is not verified. Please verifiy you account.");
                            return View(model);
                        }
                        if (adminData.IsActive != true)
                        {
                            ModelState.AddModelError("", "The admin account is de-activated. Please contact website administrator.");
                            return View(model);
                        }

                        CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
                        serializeModel.UserId = adminData.AdminId;
                        serializeModel.Name = adminData.Name;
                        serializeModel.MobileNo = adminData.MobileNo;
                        serializeModel.Email = adminData.Email;
                       // serializeModel.Password = adminData.Password;
                        serializeModel.Roles = adminData.Roles;
                        serializeModel.ProfilePic = adminData.ProfilePic;
                        serializeModel.ProfilePicDomain = adminData.ProfilePicDomain;
                        string userData = JsonConvert.SerializeObject(serializeModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                 1,
                                 adminData.Name,
                                 DateTime.Now,
                                 DateTime.Now.AddMinutes(60),
                                 false,
                                 userData);

                        string encTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                        Response.Cookies.Add(faCookie);
                        return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The Email or Password provided is incorrect");
                        return View();
                    }
                }
                catch (Exception ex)
                {
                }
            }
            // If we got this far, something failed, redisplay form
            return View(model);

        }

        public ActionResult SignOut()
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Account", new { area = "Admin" });
        }

        public ActionResult UnAuthorized()
        {
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        // [Route("/forgot-password")]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult ForgotPassword(ForgotPasswordHistory model)
        {
            try
            {
                bool result = UOF.IAdminMaster.IsAdminEmailExists(model.EmailId);
                if (result == true)
                {
                    //add data
                    string resetUrl = UOF.IAdminMaster.AddForgotPasswordData(model);
                    if (!string.IsNullOrEmpty(resetUrl))
                    {
                        bool status = MailClient.SendMail_ResetPassword(model, resetUrl);
                        if (status == true)
                        {
                            return RedirectToAction("PasswordResetLinkSent", "Account");
                        }
                        else
                        {
                            return PartialView("~/Views/Shared/_Message.cshtml");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "This email address is not registered with us!");
                    return View();
                }
            }
            catch (Exception) { }
            return View();
        }

        //  [Route("/password-reset-link-sent")]
        public ActionResult PasswordResetLinkSent()
        {
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        // [Route("/reset-password")]
        public ActionResult ResetPassword(string repeml)
        {
            try
            {
                string email = UOF.IAdminMaster.ValidateForgotPasswordRequest(repeml);
                if (!string.IsNullOrEmpty(email))
                {
                    ResetPasswordDTO model = new ResetPasswordDTO();
                    model.EmailId = email;
                    model.EncryptedKey = repeml;
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ForgotPassword", "Account");
                }
            }
            catch (Exception)
            { }
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult ResetPassword(ResetPasswordDTO model)
        {
            bool status = UOF.IAdminMaster.ResetPassword(model);
            if (status == true)
            {
                return RedirectToAction("PasswordResetSuccessfully", "Account");
            }
            else
            {
                return PartialView("~/Views/Shared/_Message.cshtml");
            }
        }

        //  [Route("password-reset-successfully")]
        [AllowAnonymous]
        public ActionResult PasswordResetSuccessfully()
        {
            return View();
        }

        //  [Route("password-changed-successfully")]
        [AllowAnonymous]
        public ActionResult PasswordChangedSuccessfully()
        {
            return View();
        }
    }
}
