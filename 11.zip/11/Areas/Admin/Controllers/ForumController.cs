﻿using DNTData;
using DNTShared;
using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNTShared.Entities;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class ForumController : Controller
    {
        IUnitOfWork AppUnitOfWork;

        // GET: /Admin/Comment/
         int pageSize;
        public ForumController()
        {
             AppUnitOfWork= new UnitOfWork();
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ForumList(int page = 1, string Date = "",string textsrch="")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingDTO<ForumMasterDTO> model = new PagingDTO<ForumMasterDTO>();
            ViewBag.CommentsList = "ForumList";
            model = AppUnitOfWork.ICommentMaster.GetAllForumList(page, pageSize, startDate, endDate, textsrch);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        public ActionResult ForumReplyList(int page = 1, string id = "",string Date = "", string textsrch = "")
        {
            DateTime? startDate = null;
            DateTime? endDate = null;
            if (Date != "")
            {
                string[] date = Date.Split('-');
                startDate = Convert.ToDateTime(date[0].Trim());
                endDate = Convert.ToDateTime(date[1].Trim());
            }
            PagingDTO<ReplyOnForumDTO> model = new PagingDTO<ReplyOnForumDTO>();
            ViewBag.CommentsList = "ForumReplyList";
           
            Guid id1 = Guid.Empty;
            if (id != "")
            { id1 = new Guid(id); }
            model = AppUnitOfWork.ICommentMaster.GetAllForumReplyList(page, pageSize, startDate, endDate, textsrch, id1);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }

        
        public ActionResult EditForum(Guid id)
        {
            ForumMaster model = new ForumMaster();
            model = AppUnitOfWork.ICommentMaster.GetForum(id);
            return View(model);
        }

        [HttpPost]
        public ActionResult EditForum(ForumMaster model)
        {
            try
            {
                bool status = AppUnitOfWork.ICommentMaster.UpdateForum(model);

                if (status == true)
                {
                    ViewBag.Message = "Forum has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Forum this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ForumList");
        }

        public ActionResult DeleteBulkForum(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.DeleteBulkForum(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult VerifyBulkForum(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.VerifyBulkForum(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult DeleteBulkReplyForum(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.DeleteBulkReplyForum(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult VerifyBulkReplyForum(string queryIds)
        {
            string[] ids = queryIds.Split(',');
            if (ids.Count() > 0)
            {
                AppUnitOfWork.ICommentMaster.VerifyBulkReplyForum(ids);
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        ////////////////////////adspopup///////////////////////
        public ActionResult AdsPopUpList(int page = 1, string textsrch = "")
        {
            PagingDTO<AdsPopUpMaster> model = new PagingDTO<AdsPopUpMaster>();
            ViewBag.CommentsList = "AdsPopUpList";
            model = AppUnitOfWork.ICommentMaster.GetAllAdsPopUpList(page, pageSize, textsrch);
            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);
        }
        public ActionResult AddAdsPopUp()
        {
            AdsPopUpMaster model = new AdsPopUpMaster();
            List<CategoryDTO> ctList = AppUnitOfWork.ICategory.GetCategories().ToList();
            List<SelectListItem> Select_List = new List<SelectListItem>();
            foreach (var s in ctList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = s.CategoryName,
                    Text = s.CategoryName,
                    // Selected = model.SelectedSkills.Where(m => m.SkillId == s.SkillId).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }
            model.categoryList = Select_List;
            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddAdsPopUp(AdsPopUpMaster model,string[] Categories)
        {
            try
            {
                model.Categories = string.Join(",", Categories);
                bool status = AppUnitOfWork.ICommentMaster.SaveAdsPopUp(model);
                List<CategoryDTO> ctList = AppUnitOfWork.ICategory.GetCategories().ToList();
                List<SelectListItem> Select_List = new List<SelectListItem>();
                foreach (var s in ctList)
                {
                    SelectListItem obj = new SelectListItem()
                    {
                        Value = s.CategoryName,
                        Text = s.CategoryName,
                       // Selected = model.SelectedSkills.Where(m => m.SkillId == s.SkillId).Count() > 0 ? true : false
                    };

                    Select_List.Add(obj);
                }
                model.categoryList = Select_List;

                if (status == true)
                {
                    ViewBag.Message = "AdsPopUp has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to save AdsPopUp this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("AdsPopUpList");
        }
        public ActionResult EditAdsPopUp(Guid id)
        {
            AdsPopUpMaster model = new AdsPopUpMaster();
            model = AppUnitOfWork.ICommentMaster.GetAdsPopUp(id);
            List<CategoryDTO> ctList = AppUnitOfWork.ICategory.GetCategories().ToList();
            model.catList = AppUnitOfWork.ICommentMaster.GetCategoriesSelectedList(id);
            List<SelectListItem> Select_List = new List<SelectListItem>();
            foreach (var s in ctList)
            {
                SelectListItem obj = new SelectListItem()
                {
                    Value = s.CategoryName,
                    Text = s.CategoryName,
                     Selected = model.catList.Where(m => m.CategoryName == s.CategoryName).Count() > 0 ? true : false
                };

                Select_List.Add(obj);
            }
            model.categoryList = Select_List;
            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditAdsPopUp(AdsPopUpMaster model, FormCollection Categoryname)
        {
            try
            {
                String CId = Categoryname["Categoryname"];
                model.Categories = CId;
                bool status = AppUnitOfWork.ICommentMaster.UpdateAdsPopUp(model);

                if (status == true)
                {
                    ViewBag.Message = "AdsPopUp has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update AdsPopUp this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("AdsPopUpList");
        }

        public ActionResult DeleteBulkAdsPopUp(Guid id)
        {
            try
            {
                bool status = AppUnitOfWork.ICommentMaster.DeleteBulkAdsPopUp(id);

                if (status == true)
                {
                    ViewBag.Message = "AdsPopUp has been saved successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to delete AdsPopUp this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("AdsPopUpList");
        }
        public ActionResult EditReplyForum(Guid id)
        {
            ReplyOnForum model = new ReplyOnForum();
            model = AppUnitOfWork.ICommentMaster.GetReplyForum(id);
            return View(model);
        }
        [HttpPost]
        public ActionResult EditReplyForum(ReplyOnForum model)
        {
            try
            {
                bool status = AppUnitOfWork.ICommentMaster.UpdateReplyForum(model);

                if (status == true)
                {
                    ViewBag.Message = "Reply has been Updated successfully";
                    ModelState.Clear();
                }
                else
                {
                    ViewBag.Message = "Unable to Update Reply this time. Please try again later.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return RedirectToAction("ForumReplyList");
        }


        //////////////////////////////////////
    }
}
