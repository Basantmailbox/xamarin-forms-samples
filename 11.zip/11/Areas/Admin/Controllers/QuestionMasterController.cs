﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNTData;
using System.Configuration;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using System.IO;
using DNTWebUI.Models;

namespace DotNetTricks.COM.Areas.Admin.Controllers
{
    public class QuestionMasterController : BaseController
    {
        int pageSize;
        int pageSizeQuery;

        public QuestionMasterController()

        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;

            string _pageSizeQuery = Convert.ToString(ConfigurationManager.AppSettings["pageSizeQuery"]);
            int PSQ;
            bool resultQ = Int32.TryParse(_pageSizeQuery, out PSQ);
            pageSizeQuery = (resultQ == true) ? PSQ : 100;
        }
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult CreateQuestion()
        {
            try
            {
                ViewBag.CreateQuestion = "CreateQuestion";
                QuestionMasterDTO model = BindAddQuestionFormDropdownlist();
                return View(model);
            }
            catch (Exception ex)
            { }

            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult CreateQuestion(QuestionMasterDTO qModel)
        {
            try
            {
                QuestionMasterDTO model = BindAddQuestionFormDropdownlist();

                ViewBag.CreateQuestion = "CreateQuestion";
                bool status = UOF.IQuestionMaster.AddQuestion(qModel);
                if (status == true)
                {
                    return RedirectToAction("CreateQuestion");
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        private QuestionMasterDTO BindAddQuestionFormDropdownlist()
        {
            QuestionMasterDTO model = new QuestionMasterDTO();
            List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
            model.CategoryList = _categoryList;

            List<QuestionDifficultyLevel> _difficultyLevelList = UOF.IAdminMaster.GetDifficultyLevelList();
            model.DifficultyLevelList = _difficultyLevelList;
            return model;
        }

        public ActionResult ViewAllQuestions(int page = 1, string sort = "QuestionId", string sortDir = "asc", string textsrch = "", int CategoryID = 0)
        {
            try
            {
                ViewBag.ViewAllQuestions = "ViewAllQuestions";
                PagingDTO<QuestionMasterDTO> model = new PagingDTO<QuestionMasterDTO>();
                if (textsrch != "" && textsrch != null || CategoryID != 0)
                { model = UOF.IQuestionMaster.GetQuestionsListBySearch(page, pageSizeQuery, CategoryID, textsrch); }
                else
                {
                    model = UOF.IQuestionMaster.GetQuestionsList(page, pageSizeQuery, CategoryID);
                }
                if (model != null)
                {
                    ViewBag.page = model.Page;
                    List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                    model.CategoryList = _categoryList;
                    return View(model);
                }
                PagingDTO<QuestionMasterDTO> model1 = new PagingDTO<QuestionMasterDTO>();
                List<CategoryDTO> _categoryList1 = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model1.CategoryList = _categoryList1;
                return View(model1);
            }
            catch (Exception ex)
            { return null; }

        }

        [HttpGet]
        public ActionResult AddMockUpTest()
        {
            try
            {
                MockUpTestMasterDTO model = new MockUpTestMasterDTO();

                List<QuestionPaperTotalQuestionDTO> _TotalQuestionList = UOF.IQuestionMaster.GetTotalQuestionList();
                model.TotalQuestionList = _TotalQuestionList;
                //Get Question Paper Durations List
                List<QuestionPaperDuration> _TotalDurationList = UOF.IQuestionMaster.GetTotalDurationList();
                model.TotalDurationList = _TotalDurationList;

                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course).ToList();
                model.CategoryList = _categoryList;
                model.CourseList = new List<DropDownDTO>();

                IEnumerable<EnumTestType> TestTypelist = Enum.GetValues(typeof(EnumTestType))
                                                    .Cast<EnumTestType>();
                ViewBag.TestTypeList = from action in TestTypelist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
                IEnumerable<EnumDifficultyType> DifficultyTypelist = Enum.GetValues(typeof(EnumDifficultyType)).Cast<EnumDifficultyType>();
                ViewBag.DifficultyTypelist = from action in DifficultyTypelist
                                             select new SelectListItem
                                             {
                                                 Text = action.ToString(),
                                                 Value = ((int)action).ToString()
                                             };

                return View(model);
            }
            catch (Exception)
            { }
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult AddMockUpTest(MockUpTestMasterDTO _model)
        {
            try
            {
                _model.CreatedBy = CurrentUser.Name;
                MockUpTestMasterDTO _questionPaperData = UOF.IQuestionMaster.AddMockUpTestDetails(_model);
                if (_questionPaperData != null)
                {
                    return RedirectToAction("ViewAllMockupTest");
                }

                MockUpTestMasterDTO model = new MockUpTestMasterDTO();
                //Get Question Paper Instructions List
                List<QuestionPaperTotalQuestionDTO> _TotalQuestionList = UOF.IQuestionMaster.GetTotalQuestionList();
                model.TotalQuestionList = _TotalQuestionList;

                //Get Question Paper Durations List
                List<QuestionPaperDuration> _TotalDurationList = UOF.IQuestionMaster.GetTotalDurationList();
                model.TotalDurationList = _TotalDurationList;

                //Get Course List
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryList = _categoryList;
                model.CourseList = new List<DropDownDTO>();

                IEnumerable<EnumTestType> TestTypelist = Enum.GetValues(typeof(EnumTestType))
                                                   .Cast<EnumTestType>();
                ViewBag.TestTypeList = from action in TestTypelist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
                IEnumerable<EnumDifficultyType> DifficultyTypelist = Enum.GetValues(typeof(EnumDifficultyType)).Cast<EnumDifficultyType>();
                ViewBag.DifficultyTypelist = from action in DifficultyTypelist
                                             select new SelectListItem
                                             {
                                                 Text = action.ToString(),
                                                 Value = ((int)action).ToString()
                                             };
                return View(model);
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        public ActionResult AddQuestionInQuestionMockupTest(int page = 1, int? CategoryID = null, int MockupTestId = 0)
        {
            try
            {
                ViewBag.ViewAllMockupTest = "ViewAllMockupTest";
                PagingQuestionDTO<MockupTestMasterQuestionMappingDTO> model = new PagingQuestionDTO<MockupTestMasterQuestionMappingDTO>();

                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryList = _categoryList;
                ViewBag.CategorySelectedValue = CategoryID;
                CategoryID = CategoryID == null ? CategoryID = 0 : CategoryID;
                PagingQuestionDTO<QuestionMasterDTO> QList = UOF.IQuestionMaster.GetQuestionsList(page, pageSize, CategoryID);
                if (QList != null)
                {
                    model.QuestionList = QList.Data;
                    model.TotalRows = QList.TotalRows;
                    ViewBag.page = QList.Page;
                    model.PageSize = QList.PageSize;
                    TempData["MockupTestId"] = MockupTestId;
                    TempData["DifficultyLevelId"] = TempData["DifficultyLevelId"];
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return RedirectToAction("ViewAllMockupTest");
        }

        public ActionResult AddQuestionToSubTopic(int page = 1, int? CategoryID = null, int SubTopicId = 0, int TopicId = 0)
        {
            try
            {
                ViewBag.ViewAllMockupTest = "ViewAllMockupTest";
                PagingQuestionDTO<MockupTestMasterQuestionMappingDTO> model = new PagingQuestionDTO<MockupTestMasterQuestionMappingDTO>();

                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryList = _categoryList;
                ViewBag.CategorySelectedValue = CategoryID;
                CategoryID = CategoryID == null ? CategoryID = 0 : CategoryID;
                PagingQuestionDTO<QuestionMasterDTO> QList = UOF.IQuestionMaster.GetQuestionsList(page, pageSize, CategoryID);
                if (QList != null)
                {
                    model.QuestionList = QList.Data;
                    model.TotalRows = QList.TotalRows;
                    ViewBag.page = QList.Page;
                    model.PageSize = QList.PageSize;
                    TempData["SubTopicId"] = SubTopicId;
                    if (TopicId > 0)
                        Session["TopicId"] = TopicId;
                    TempData["DifficultyLevelId"] = TempData["DifficultyLevelId"];
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        [ChildActionOnly]
        public ActionResult GetQuestionsForSubTopic(int SubTopicId = 0)
        {
            List<StudyModeQuizQuestionsDTO> model = UOF.IQuestionMaster.GetQuestionsForSubTopic(SubTopicId);

            return PartialView("_GetQuestionsForSubTopic", model);
        }

        public ActionResult AddQuestionQuestionPaperDetails(int page = 0, int CategoryID = 0, int MockupTestId = 0, int QuestionId = 0)
        {
            try
            {
                bool result = UOF.IQuestionMaster.CanQuestionBeAddedQuestionPaper(MockupTestId);
                if (result == true)
                {
                    bool isQuestionAlreadyExists = UOF.IQuestionMaster.IsQuestionAlreadyAddedInQuestionPaper(MockupTestId, QuestionId);
                    if (isQuestionAlreadyExists == false)
                    {
                        bool status = UOF.IQuestionMaster.AddQuestionInQuestionPaperDetails(MockupTestId, QuestionId);
                        if (status == true)
                        {

                            TempData["msgr"] = "";
                            TempData["msg"] = "Question added Successfully in this Question Paper!";
                        }
                    }
                    else
                    {

                        TempData["msg"] = "";
                        TempData["msgr"] = "Selected question has been already added into this Question Paper!";
                    }
                }
                else
                {
                    TempData["msgr"] = "Can not add more questions in this Question Paper!";
                }
                return RedirectToAction("AddQuestionInQuestionMockupTest", new { MockupTestId = MockupTestId, page = page, CategoryID = CategoryID });
            }
            catch (Exception ex)
            { }
            return RedirectToAction("ViewAllMockupTest", "QuestionMaster");
        }

        public ActionResult AddQuestionToSubTopicDetails(int page = 0, int CategoryID = 0, int SubTopicId = 0, int QuestionId = 0)
        {
            try
            {
                bool status = UOF.IQuestionMaster.AddQuestionToSubTopicDetails(SubTopicId, QuestionId);
                if (status == true)
                {

                    TempData["msgr"] = "";
                    TempData["msg"] = "Question added Successfully in this Question Paper!";
                }
                else
                {
                    TempData["msg"] = "Question already added!";
                }
                return RedirectToAction("AddQuestionToSubTopic", new { SubTopicId = SubTopicId, page = page, CategoryID = CategoryID });
            }
            catch (Exception ex)
            { }
            return RedirectToAction("AddQuestionToSubTopic", new { SubTopicId = SubTopicId, page = page, CategoryID = CategoryID });
        }

        public ActionResult ViewAllMockupTest(int page = 1, int CategoryID = 0, int TestType = 0)
        {
            try
            {
                ViewBag.ViewAllMockupTest = "ViewAllMockupTest";

                PagingDTO<MockUpTestMasterDTO> model = new PagingDTO<MockUpTestMasterDTO>();
                model = UOF.IQuestionMaster.GetAllMockupTestDetails(page, pageSize, CategoryID, TestType);

                if (model != null)
                {
                    model.CategoryList = UOF.ICategory.GetCategories().ToList();
                    model.CategoryID = CategoryID;
                    ViewBag.page = model.Page;
                }
                else
                {
                    model = new PagingDTO<MockUpTestMasterDTO>();
                    model.CategoryList = UOF.ICategory.GetCategories().ToList();
                    model.CategoryID = CategoryID;
                }
                return View(model);

            }
            catch (Exception ex)
            { }
            return View();
        }

        [ChildActionOnly]
        public ActionResult GetQuestionPaperQuestionList(int MockupTestId = 0)
        {
            List<MockupTestMasterQuestionMappingDTO> model = UOF.IQuestionMaster.GetQuestionPaperQuestionDetails(MockupTestId);

            return PartialView("_GetQuestionPaperQuestionList", model);
        }

        public ActionResult DeleteQuestionFromQuestionPaper(int MockupTestId = 0, int QuestionId = 0)
        {
            bool status = UOF.IQuestionMaster.DeleteQuestionPaperQuestionMapping(MockupTestId, QuestionId);
            if (status == true)
            {
                return RedirectToAction("AddQuestionInQuestionMockupTest", new { MockupTestId = MockupTestId });
            }
            return View("ViewAllMockupTest");
        }

        public ActionResult DeleteQuestionFromSubTopic(int SubTopicId = 0, int QuestionId = 0)
        {
            bool status = UOF.IQuestionMaster.DeleteQuestionFromSubTopic(SubTopicId, QuestionId);
            return RedirectToAction("AddQuestionToSubTopic", new { SubTopicId = SubTopicId });
        }

        [HttpGet]
        public ActionResult EditMockupTest(int id)
        {
            if (id != 0)
            {
                MockUpTestMasterDTO model = UOF.IQuestionMaster.EditMockupTest(id);

                List<QuestionPaperTotalQuestionDTO> _TotalQuestionList = UOF.IQuestionMaster.GetTotalQuestionList();
                model.TotalQuestionList = _TotalQuestionList;

                List<QuestionPaperDuration> _TotalDurationList = UOF.IQuestionMaster.GetTotalDurationList();
                model.TotalDurationList = _TotalDurationList;

                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course).ToList();
                model.CategoryList = _categoryList;

                IEnumerable<EnumTestType> TestTypelist = Enum.GetValues(typeof(EnumTestType))
                                                    .Cast<EnumTestType>();
                ViewBag.TestTypeList = from action in TestTypelist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
                IEnumerable<EnumDifficultyType> DifficultyTypelist = Enum.GetValues(typeof(EnumDifficultyType)).Cast<EnumDifficultyType>();
                ViewBag.DifficultyTypelist = from action in DifficultyTypelist
                                             select new SelectListItem
                                             {
                                                 Text = action.ToString(),
                                                 Value = ((int)action).ToString()
                                             };

                //Get Course List
                List<DropDownDTO> _courseList = UOF.ICourse.GetDropDown(model.CategoryID, true);
                model.CourseList = _courseList;

                return View("AddMockUpTest", model);

            }
            return null;
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult EditMockupTest(MockUpTestMasterDTO _model)
        {
            try
            {
                MockUpTestMasterDTO model = new MockUpTestMasterDTO();
                _model.UpdatedBy = CurrentUser.Name;
                //by rakesh
                bool status = UOF.IQuestionMaster.EditMockupTestDetails(_model);

                if (status != false)
                {
                    return RedirectToAction("ViewAllMockupTest");
                }
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course).ToList();
                model.CategoryList = _categoryList;

                IEnumerable<EnumTestType> TestTypelist = Enum.GetValues(typeof(EnumTestType))
                                                    .Cast<EnumTestType>();
                ViewBag.TestTypeList = from action in TestTypelist
                                       select new SelectListItem
                                       {
                                           Text = action.ToString(),
                                           Value = ((int)action).ToString()
                                       };
                IEnumerable<EnumDifficultyType> DifficultyTypelist = Enum.GetValues(typeof(EnumDifficultyType)).Cast<EnumDifficultyType>();
                ViewBag.DifficultyTypelist = from action in DifficultyTypelist
                                             select new SelectListItem
                                             {
                                                 Text = action.ToString(),
                                                 Value = ((int)action).ToString()
                                             };

                //Get Course List
                List<DropDownDTO> _courseList = UOF.ICourse.GetDropDown(model.CategoryID, true);
                model.CourseList = _courseList;
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }
        public ActionResult ViewQuestionAddedInMockupTest(int page = 1, int MockupTestId = 0)
        {
            try
            {
                PagingDTO<MockupTestMasterQuestionMappingDTO> model = UOF.IQuestionMaster.GetViewQuestionAddedInMockupTest(MockupTestId, page, pageSize);

                if (model != null)
                {
                    ViewBag.page = model.Page;
                }
                return View(model);

            }
            catch (Exception ex)
            { }
            return View();
        }

        public ActionResult AssessmentMapping(int page = 1, int BatchId = 0, int AssessmentId = 0, int courseId = 0)
        {
            try
            {
                TempData["AssignmentId"] = "";
                PagingBatchDocDTO<CourseSubscriptionMemberDTO> model = new PagingBatchDocDTO<CourseSubscriptionMemberDTO>();
                if (BatchId > 0)
                {
                    model = UOF.IAdminMaster.ViewMemberListAddedInBatch(BatchId, page, pageSize);
                    if (model != null)
                    {
                        ViewBag.page = model.Page;
                    }
                }
                TempData["AssessmentId"] = AssessmentId;
                if (AssessmentId != 0)
                {
                    var ass = UOF.IAssessmentMaster.Get(AssessmentId);
                    if (ass != null)
                    {
                        var AssignmentId = ass.AssessmentId;
                        if (AssignmentId == 0)
                        {
                            TempData["AssignmentId"] = "";
                        }
                        else
                        {
                            TempData["AssignmentId"] = AssignmentId;
                        }
                        model.MockupTestTitle = ass.MockupTestTitle;
                    }
                    else
                    {
                        TempData["AssignmentId"] = "";
                        model.MockupTestTitle = "Not Assigned";

                    }
                }

                TempData["batchId"] = BatchId;
                TempData["courseId"] = courseId;

                ViewData["CurrentDate"] = DateTime.Now;
                ViewData["NextMonthDate"] = DateTime.Now.AddMonths(1);
                List<BatchMasterDTO> BatchList = UOF.IQuestionMaster.GetAllBatchesListByCourse(courseId);
                model.BatchMasterList = BatchList;
                return View(model);
            }
            catch (Exception ex)
            { }

            return View();
        }
        public JsonResult AssessmentMappingAjax(int page = 1, int BatchId = 0, int AssessmentId = 0, int courseId = 0)
        {
            try
            {
                PagingBatchDocDTO<CourseSubscriptionMemberDTO> model = new PagingBatchDocDTO<CourseSubscriptionMemberDTO>();
                if (BatchId > 0)
                {
                    model = UOF.IAdminMaster.ViewMemberListAddedInBatch(BatchId, page, pageSize);
                    if (model != null)
                    {
                        ViewBag.page = model.Page;
                    }
                }
                TempData["AssessmentId"] = AssessmentId;
                TempData["batchId"] = BatchId;
                TempData["courseId"] = courseId;


                ViewData["CurrentDate"] = DateTime.Now;
                ViewData["NextMonthDate"] = DateTime.Now.AddMonths(1);
                List<BatchMasterDTO> BatchList = UOF.IQuestionMaster.GetAllBatchesListByCourse(courseId);
                model.BatchMasterList = BatchList;
                return Json(model, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            { }
            return Json(null);
        }

        public ActionResult ViewAllMockupTests(int page = 1, int CategoryID = 0)
        {
            PagingDTO<MockUpTestMasterDTO> model = new PagingDTO<MockUpTestMasterDTO>();
            model = UOF.IQuestionMaster.GetAllMockupTestDetails(page, pageSize, CategoryID, 0);

            return View(model);
        }

        public ActionResult DeleteQuestion(int id = 0, int page = 1)
        {
            bool status = UOF.IQuestionMaster.DeleteQuestion(id);
            if (status == true)
            {
                return RedirectToAction("ViewAllQuestions", new { page = page });
            }
            return View("ViewAllQuestions");

        }

        [HttpGet]
        public ActionResult EditQuestion(int id = 0)
        {
            try
            {
                ViewBag.ViewAllQuestions = "ViewAllQuestions";
                QuestionMasterDTO model = new QuestionMasterDTO();
                model = UOF.IQuestionMaster.EditQuestionById(id);
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryList = _categoryList;

                List<QuestionDifficultyLevel> _difficultyLevelList = UOF.IAdminMaster.GetDifficultyLevelList();
                model.DifficultyLevelList = _difficultyLevelList;

                model.CategoryID = model.CategoryID;
                model.DifficultyLevelId = model.DifficultyLevelId;
                model.CorrectOption = model.CorrectOption;
                return View(model);
            }
            catch (Exception ex)
            { }

            return View();
        }

        [HttpPost]
        public ActionResult EditQuestion(QuestionMasterDTO qModel)
        {
            try
            {
                QuestionMasterDTO model = BindAddQuestionFormDropdownlist();

                ViewBag.ViewAllQuestions = "ViewAllQuestions";
                bool status = UOF.IQuestionMaster.UpdateQuestionById(qModel);
                if (status == true)
                {
                    return RedirectToAction("ViewAllQuestions");
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        public ActionResult DeleteQuestionAddedInMockupTest(int MockupTestId = 0, int page = 1)
        {
            bool status = UOF.IQuestionMaster.DeleteQuestionAddedInMockupTest(MockupTestId);
            if (status == false)
            {
                TempData["Message"] = "Sorry! First delete all questions";
            }
            return RedirectToAction("ViewAllMockupTest", new { page = page });
        }

        public ActionResult MockupTestResult(int page = 1, int BatchId = 0, int MockupTestId = 0, int CourseId = 0)
        {
            try
            {
                PagingBatchDocDTO<MockUpTestAttemptedStatusDTO> model = new PagingBatchDocDTO<MockUpTestAttemptedStatusDTO>();
                if (MockupTestId != 0)
                {
                    //attempted list
                    model = UOF.IQuestionMaster.GetAllMockUpTestResultStatus(page, pageSize, BatchId, MockupTestId);
                }

                List<BatchMasterDTO> BatchList = UOF.ICommonLogic.GetAllBatchList();
                if (model != null)
                {
                    model.CourseId = CourseId;
                    ViewBag.SelectedCourseValue = CourseId;
                    model.Courses = UOF.ICommonLogic.AllGetCourseList();
                    model.BatchMasterList = BatchList;
                    ViewBag.SelectedValue = BatchId;
                }
                else
                {
                    model = new PagingBatchDocDTO<MockUpTestAttemptedStatusDTO>();
                    model.CourseId = CourseId;
                    ViewBag.SelectedCourseValue = CourseId;
                    model.Courses = UOF.ICommonLogic.AllGetCourseList();
                    model.BatchMasterList = BatchList;
                    ViewBag.SelectedValue = BatchId;
                }
                ViewBag.SelectedValue = BatchId;
                ViewBag.SelectedValueMockupTest = MockupTestId;
                ViewBag.MockupDetails = UOF.IQuestionMaster.MockUpTestDetails(BatchId, MockupTestId);

                return View(model);
            }
            catch (Exception)
            {
                return null;
            }

        }
        public ActionResult GetAllMockupTestMaster(int BatchId)
        {
            List<MockUpTestMasterDTO> result = UOF.IMockUpTestAttemptedStatus.GetByBatchId(BatchId);

            var data = result.GroupBy(test => test.MockupTestId)
                   .Select(grp => grp.First())
                   .ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AssessmentInstructionList(int page = 1)
        {
            PagingDTO<AssessmentInstruction> model = new PagingDTO<AssessmentInstruction>();
            ViewBag.AssessmentInstructionList = "AssessmentInstructionList";
            model = UOF.IQuestionMaster.getAssessmentInstructionList(page, pageSize);

            if (model != null)
            {
                ViewBag.page = model.Page;
            }
            return View(model);

        }

        public ActionResult InstructionDelete(int id = 0, int page = 1)
        {
            try
            {
                bool isAlreadyExists = UOF.IQuestionMaster.IsAssessmentInstruction(id);
                if (isAlreadyExists == true)
                {
                    TempData["msgr"] = "Please remove mockup test first!";
                    TempData["msg"] = "";

                }
                else
                {
                    bool status = UOF.IQuestionMaster.InstructionDelete(id);
                    if (status == false)
                    {
                        TempData["msg"] = "";
                        TempData["msgr"] = " Sorry try again later!";
                    }
                    else
                    {
                        TempData["msg"] = "";
                        TempData["msgr"] = "";
                    }
                }

            }
            catch (Exception)
            {
            }
            return RedirectToAction("AssessmentInstructionList", new { page = page });
        }


        [HttpGet]
        public ActionResult CreateAssessmentInstruction()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateAssessmentInstruction(AssessmentInstruction model)
        {
            try
            {
                ViewBag.AssessmentInstructionList = "AssessmentInstructionList";
                bool Data = UOF.IQuestionMaster.CreateAssessmentInstruction(model);
                if (Data == true)
                {
                    return RedirectToAction("AssessmentInstructionList");
                }
                else { }
            }
            catch (Exception ex)
            { }
            return null;
        }
        [HttpGet]
        public ActionResult EditInstruction(int id)
        {

            try
            {
                ViewBag.AssessmentInstructionList = "AssessmentInstructionList";
                AssessmentInstruction model = new AssessmentInstruction();
                model = UOF.IQuestionMaster.EditInstruction(id);
                return View(model);
            }
            catch (Exception ex)
            { }

            return View();
        }

        [HttpPost]
        public ActionResult EditInstruction(AssessmentInstruction model)
        {
            try
            {
                bool status = UOF.IQuestionMaster.UpdateInstruction(model);
                if (status == true)
                {
                    return RedirectToAction("AssessmentInstructionList");
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }
        [HttpGet]
        public ActionResult DeleteMockUpTestAttemptedStatus(int id = 0, int BatchId = 0, int MockupTestId = 0, int page = 1)
        {
            bool status = UOF.IQuestionMaster.DeleteMockUpTestAttemptedStatus(id);
            return RedirectToAction("MockupTestResult", new { BatchId = BatchId, MockupTestId = MockupTestId, page = page });

        }

        ///AssessmentMasters

        public ActionResult AssessmentMasters(int page = 1, int CourseId = 0, int batchid = 0, int IsActive = 1)
        {
            try
            {
                ViewBag.AssessmentMasters = "AssessmentMasters";
                Session["CID"] = CourseId;
                PagingDTO<AssessmentMastersDTO> model = new PagingDTO<AssessmentMastersDTO>();
                model = UOF.IQuestionMaster.GetAllAssessmentMasters(page, pageSize, CourseId, batchid, IsActive);
                if (model != null)
                {
                    model.Courses = UOF.ICommonLogic.GetAllCourseList();
                    model.CourseId = CourseId;
                    ViewBag.page = model.Page;
                }
                else
                {
                    model = new PagingDTO<AssessmentMastersDTO>();
                    model.Courses = UOF.ICommonLogic.GetAllCourseList();
                    model.CourseId = CourseId;
                }
                ViewBag.isactive = IsActive;
                return View(model);

            }
            catch (Exception ex)
            {

            }
            return View();
        }


        //   CreateAssessmentMasters
        [HttpGet]
        public ActionResult CreateAssessmentMasters()
        {
            try
            {
                AssessmentMastersDTO model = new AssessmentMastersDTO();

                ////Get Question Paper Instructions List
                List<AssessmentInstruction> _instructionList = UOF.IQuestionMaster.GetQuestionPaperInstructionList();
                model.AssessmentInstructionList = _instructionList;
                int CategoryID = 1;
                List<MockUpTestMasterDTO> MockUpTestList = UOF.IQuestionMaster.getAllMockUpTestListByCategory(CategoryID);
                model.MockUpTestList = MockUpTestList;

                List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
                model.courseList = courseList;
                int CourseId = 1;
                List<DocumentDTO> DocumentList = UOF.IDocument.GetAllDocumentsList(CourseId);
                model.DocumentList = DocumentList;

                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryList = _categoryList;

                ViewBag.AssessmentMasters = "AssessmentMasters";
                return View(model);
            }
            catch (Exception)
            { }
            return View();
        }

        [HttpPost]
        public ActionResult CreateAssessmentMasters(AssessmentMastersDTO _model)
        {
            try
            {
                AssessmentMastersDTO model = new AssessmentMastersDTO();

                ////Get Question Paper Instructions List
                List<AssessmentInstruction> _instructionList = UOF.IQuestionMaster.GetQuestionPaperInstructionList();
                model.AssessmentInstructionList = _instructionList;
                int CategoryID = 1;
                List<MockUpTestMasterDTO> MockUpTestList = UOF.IQuestionMaster.getAllMockUpTestListByCategory(CategoryID);
                model.MockUpTestList = MockUpTestList;

                List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
                model.courseList = courseList;
                int CourseId = 1;
                List<DocumentDTO> DocumentList = UOF.IDocument.GetAllDocumentsList(CourseId);
                model.DocumentList = DocumentList;
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryList = _categoryList;

                _model.CreatedBy = CurrentUser.Name;
                bool stat = UOF.IQuestionMaster.AddAssessmentDetails(_model);
                if (stat == true)
                {
                    return RedirectToAction("AssessmentMasters");
                }
                return View(model);
            }
            catch (Exception ex)
            { return View(); }


        }


        [HttpGet]
        public ActionResult EditAssessment(int id)
        {
            if (id != 0)
            {
                AssessmentMastersDTO model = UOF.IQuestionMaster.EditAssessmentMaster(id);
                ViewBag.AssessmentMasters = "AssessmentMasters";
                List<AssessmentInstruction> _instructionList = UOF.IQuestionMaster.GetQuestionPaperInstructionList();
                model.AssessmentInstructionList = _instructionList;

                int CategoryID = 1;
                List<MockUpTestMasterDTO> MockUpTestList = UOF.IQuestionMaster.getAllMockUpTestListByCategory(CategoryID);
                model.MockUpTestList = MockUpTestList;
                List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
                model.courseList = courseList;
                int CourseId = 1;
                List<DocumentDTO> DocumentList = UOF.IDocument.GetAllDocumentsList(CourseId);
                model.DocumentList = DocumentList;
                List<CategoryDTO> _categoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                model.CategoryID = model.CategoryID;
                model.CategoryList = _categoryList;
                return View(model);

            }
            return null;
        }

        [HttpPost]
        public ActionResult EditAssessment(AssessmentMastersDTO _model)
        {
            try
            {
                AssessmentMastersDTO model = new AssessmentMastersDTO();
                ViewBag.AssessmentMasters = "AssessmentMasters";
                _model.UpdatedBy = CurrentUser.Name;
                bool status = UOF.IQuestionMaster.EditAssessmentDetails(_model);

                if (status != false)
                {
                    return RedirectToAction("AssessmentMasters");
                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }
        public ActionResult GetAllMockupTestByCategory(int CategoryID)
        {
            List<MockUpTestMasterDTO> data = UOF.IMockUpTestAttemptedStatus.GetByCategoryID(CategoryID);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAllBatchMaster(int CourseId)
        {
            List<BatchMasterDTO> result = UOF.IBatchMaster.GetByCourseId(CourseId);

            var data = result.GroupBy(test => test.BatchId)
                   .Select(grp => grp.First())
                   .ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }


        public ActionResult StatusAssessment(int id, bool stat)
        {
            try
            {
                AssessmentMastersDTO model = new AssessmentMastersDTO();
                ViewBag.AssessmentMasters = "AssessmentMasters";
                model.UpdatedBy = CurrentUser.Name;
                model.AssessmentId = id;
                model.IsActive = stat;
                bool status = UOF.IQuestionMaster.StatusAssessment(model);

                if (status != false)
                {
                    return RedirectToAction("AssessmentMasters", new { CourseId = Session["CID"] });

                }
                return View(model);
            }
            catch (Exception ex)
            { }
            return View();
        }

        public ActionResult SheetQuestionAnswerDetails(int id = 0)
        {
            try
            {
                IEnumerable<MockupTestQuestionOptionAnswerDTO> model = UOF.IQuestionMaster.GetSheetQuestionAnswerDetails(id);
                ViewBag.title = UOF.IQuestionMaster.getMockUpTitleName(id);
                ViewBag.id = id;
                return View("_SheetQuestionAnswerDetails", model);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public ActionResult MockupQuizResult(int page = 1, int CategoryID = 0, int MockupTestId = 0, string Date = "", string textsearch = "")
        {
            try
            {

                DateTime? startDate = null;
                DateTime? endDate = null;
                if (Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }
                PagingBatchDocDTO<MockUpTestAttemptedStatusDTO> model = new PagingBatchDocDTO<MockUpTestAttemptedStatusDTO>();
                //attempted list
                model = UOF.IQuestionMaster.GetAllMockUpQuizResultStatus(page, pageSize, MockupTestId, startDate, endDate, textsearch);


                ViewBag.CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Article).ToList();
                if (model != null)
                {
                    model.CategoryID = CategoryID;
                }
                ViewBag.SelectedValueMockupTest = MockupTestId;
                if (MockupTestId > 0)
                {
                    ViewBag.MockupDetails = UOF.IQuestionMaster.GetMockupQuizDetailsById(MockupTestId).MockupTestTitle;

                }
                else { ViewBag.flag = "1"; }

                return View(model);
            }
            catch (Exception)
            {
                return null;
            }

        }

        public ActionResult DownloadQuizToExcel(int MockupTestId = 0, int CategoryID = 0, string Date = "")
        {
            try
            {
                DateTime? startDate = null;
                DateTime? endDate = null;
                if (!Date.Contains("Invalid") && Date != "")
                {
                    string[] date = Date.Split('-');
                    startDate = Convert.ToDateTime(date[0].Trim());
                    endDate = Convert.ToDateTime(date[1].Trim());
                }

                ViewBag.SubscribedMemberDetails = "SubscribedMemberDetails";
                List<MockUpTestAttemptedStatusDTO> model = new List<MockUpTestAttemptedStatusDTO>();
                model = UOF.IQuestionMaster.GetAllDownloadQuizToExcel(MockupTestId, CategoryID, startDate, endDate);
                byte[] bytes = null;
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string RepoetName = "QuizExcelReport" + time + ".xlsx";
                string fileName = RepoetName;
                using (var stream = new MemoryStream())
                {
                    ExportManager objReceiving = new ExportManager();
                    // string path = Path.Combine(Server.MapPath(WebConfigSetting.DownloadExcel), fileName);
                    string path = string.Empty;
                    path = Server.MapPath(WebConfigSetting.DownloadExcel);
                    if (!Directory.Exists(path))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                    string p_strPath = Path.Combine(path, fileName);
                    objReceiving.GetReceivingAllQuizReport(stream, model, p_strPath);
                    bytes = stream.ToArray();
                }
                fileName = WebConfigSetting.DownloadExcel + fileName;
                return Json(new { msg = "done", fileName }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            { return View(); }


        }
        public ActionResult GetAllMockupQuizMaster(int CategoryID)
        {
            List<MockUpTestMasterDTO> result = UOF.IMockUpTestAttemptedStatus.GetQuizByCategoryID(CategoryID);

            var data = result.GroupBy(test => test.MockupTestId)
                   .Select(grp => grp.First())
                   .ToList();

            return Json(data, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public ActionResult DeleteMockUpQuizAttemptedStatus(int page = 1, int CategoryID = 0, int MockupTestId = 0, int id = 0)
        {
            bool status = UOF.IQuestionMaster.DeleteMockUpQuizAttemptedStatus(id);
            return RedirectToAction("MockupQuizResult", new { page = page, CategoryID = CategoryID, MockupTestId = MockupTestId });

        }

        public ActionResult GetStudyModeQuizzes(int courseId)
        {
            List<DropDownDTO> data = UOF.IMockUpTestMaster.GetStudyModeQuizzes(courseId);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}