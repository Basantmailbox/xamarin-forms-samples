﻿using System;
using System.Linq;
using System.Security.Principal;

namespace DotNetTricks.COM.Security
{
    public class CustomPrincipal : IPrincipal
    {
        public IIdentity Identity { get; private set; }

        public bool IsInRole(string _role)
        {
            string[] roleArray = _role.Split(',');
            foreach (string role in roleArray)
            {
                if (Roles.Any(r => r.Contains(role.Trim())))
                {
                    return true;
                }
            }

            return false;
        }

        public CustomPrincipal(string Username)
        {
            this.Identity = new GenericIdentity(Username);
        }

        public Int64 UserId { get; set; }
        public string Name { get; set; }       
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string CurrentLocation { get; set; }
        public string[] Roles { get; set; }
        public string ProfilePic { get; set; }

        public string ProfilePicDomain { get; set; }
        public int MembershipId { get; set; }
        public DateTime MembershipExpiry { get; set; }
    }

    public class CustomPrincipalSerializeModel
    {
        public Int64 UserId { get; set; }
        public string Name { get; set; }        
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string CurrentLocation { get; set; }
        public string[] Roles { get; set; }
        public string ProfilePic { get; set; }
        public string ProfilePicDomain { get; set; }
        public int MembershipId { get; set; }
        public DateTime MembershipExpiry { get; set; }
    }
}