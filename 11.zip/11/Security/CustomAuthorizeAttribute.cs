﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace DotNetTricks.COM.Security
{
    public class CustomAuthorizeAttribute : AuthorizeAttribute
    {
        protected virtual CustomPrincipal CurrentUser
        {
            get { return HttpContext.Current.User as CustomPrincipal; }
        }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            bool skipAuthorization = filterContext.ActionDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true) || filterContext.ActionDescriptor.ControllerDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true);
                 
            if (filterContext.HttpContext.Request.IsAuthenticated && !skipAuthorization)
            {
                if (!String.IsNullOrEmpty(Roles))
                {
                    if (!CurrentUser.IsInRole(Roles))
                    {
                        filterContext.Result = new RedirectToRouteResult(new
                     RouteValueDictionary(new { controller = "Account", action = "UnAuthorized", area = "" }));
                    }
                }
            }
            else if (!skipAuthorization)
            {
                var path = filterContext.HttpContext.Request.Path;

                if (path.Contains("Admin") || path.Contains("admin"))
                {
                    filterContext.Result = new RedirectToRouteResult(new
                     RouteValueDictionary(new { controller = "Account", action = "Index", area = "Admin" })); //returns to admin login url
                }
                else
                {
                    base.OnAuthorization(filterContext); //returns to member login url
                }
            }
        }
    }
}