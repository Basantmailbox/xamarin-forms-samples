﻿using System.Web.Mvc;

namespace DotNetTricks.COM.Security
{
    public abstract class BaseViewPage : WebViewPage
    {
        public virtual CustomPrincipal CurrentUser
        {
            get { return base.User as CustomPrincipal; }
        }
    }
    public abstract class BaseViewPage<TModel> : WebViewPage<TModel>
    {
        public virtual CustomPrincipal CurrentUser
        {
            get { return base.User as CustomPrincipal; }
        }
    }
}