﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.IO;
using DNTData;
using System.Configuration;
using DNTShared.DTO;
using DNTShared.Entities;
using System.Globalization;
using DNTWebUI.Models.Security;
using DNTShared;

namespace DotNetTricks.COM.Controllers
{
    public class AdsController : BaseController
    {
        public string _ImageServerUrl = string.Empty;
        IUnitOfWork AppUnitOfWork;

        public AdsController()
        {
            AppUnitOfWork = new UnitOfWork();
            _ImageServerUrl = ConfigurationManager.AppSettings["ImageServerUrl"].ToString();

        }

        [Route("~/ad/{mode}/{source}/{url}")]
        public ActionResult Index(string mode, string source, string url)
        {
            string tcamp = null;
            PPCCourseDTO model = AppUnitOfWork.ICommonLogic.GetCourseAdsDataDetails(mode, source, tcamp, url);
            ViewBag.type = source + "_" + mode;
            ViewBag.mode = mode;
            Session["ppcpage"] = "yes";
            Session["master"] = "";
           // TempData["flag"] = "true";
            if (model == null)
            {
                return RedirectToAction("InstructorledCourses", "Home");
            }
            else
            {
                model.SubCourseDetailsList = AppUnitOfWork.ICourse.GetSubCourseDetailsList(model.CourseId);
            }
            ViewBag.cid = model.CourseId;
            return View(model);
        }


        [Route("~/ad/{mode}/{source}/{tcamp}/{url}")]
        public ActionResult bootcamp(string mode, string source, string tcamp, string url)
        {
            PPCCourseDTO model = AppUnitOfWork.ICommonLogic.GetCourseAdsDataDetails(mode, source, tcamp, url);
            ViewBag.type = source + "_" + mode;
            ViewBag.mode = mode;
            Session["ppcpage"] = "yes";
            Session["master"] = "";
            if (model == null)
            {
                return RedirectToAction("InstructorledCourses", "Home");
            }
            else
            {
                model.SubCourseDetailsList = AppUnitOfWork.ICourse.GetSubCourseDetailsList(model.CourseId);
            }
            ViewBag.cid = model.CourseId;
            return View(model);
        }


        [ChildActionOnly]
        public ActionResult CourseEnquiry(int id = 0, string type = "", int mode = 0, int EnquiryType = 0)
        {
            QueryDTO queryModel = new QueryDTO();
            ////Bind Courses
            List<CourseDTO> courseList = AppUnitOfWork.ICommonLogic.GetCourseList();
            queryModel.CourseList = courseList;
            queryModel.CourseId = id;
            ViewBag.Type = type;
            ViewBag.EnquiryType = EnquiryType;
            queryModel.EnquiryTypeId = EnquiryType;
            queryModel.TrainingModeId = mode;
            //Bind Training Mode
            List<TrainingMode> trainingModeList = AppUnitOfWork.ICommonLogic.GetTrainingModeList();
            queryModel.TrainingModeList = trainingModeList;
            //Subject
            queryModel.Subject = "Training - Course Page";

            return PartialView("_AdsCourseEnquiry", queryModel);
        }


        /////////////////////
        [ChildActionOnly]
        public ActionResult _Testimonial(int CourseId)
        {
            List<TestimonialDTO> model = AppUnitOfWork.ICommonLogic.GetRecentTestimonialDetails(CourseId);
            if (model.Count() == 0)
            {
                model = AppUnitOfWork.ICommonLogic.GetRecentTestimonialDetails(0);
            }

            if (model.Count == 0)
            {
                ViewData["flag"] = "1";
            }
            return PartialView("_AdsTestimonial", model);
        }

        [HttpPost]
        public JsonResult SavePPCEnquiry(QueryDTO model)
        {
            try
            {
                int quid = 0;
                if (model.ID == 0)
                {
                    quid = AppUnitOfWork.IQuery.SavePPCQuery(model);
                }
                else
                {
                    quid = AppUnitOfWork.IQuery.UpdatePPCQuery(model);
                }

                ModelState.Clear();
                if (quid > 0)
                {
                    MailClient.SendMail_PPCEnquiry(model);
                    return Json(new { msg = "done", quid }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDownloadEnquiry(DownloadSyllabusDTO model)
        {
            try
            {
                int count = AppUnitOfWork.IQuery.GetEnquiryInfo(model);
                if (count <= 2)
                {
                    int quid = 0;
                    if (model.ID == 0)
                    {
                        quid = AppUnitOfWork.IQuery.SyllabusDownloadPPC(model);
                    }
                    else
                    {
                        quid = AppUnitOfWork.IQuery.SyllabusDownloadPPCUpdate(model);
                    }

                    ModelState.Clear();
                    //if (quid > 1)
                    //{
                    //    int otp = AppUnitOfWork.IQuery.GenerateNewOtp(quid);
                    //    if (otp != 0)
                    //    {
                    //        int otpid = otp;
                            return Json(new { msg = "done", quid }, JsonRequestBehavior.AllowGet);
                       // }
                    //    else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
                    //}
                    //else if (quid == 1)
                    //{
                    //    return Json(new { msg = "exist" }, JsonRequestBehavior.AllowGet);
                    //}
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [Route("~/ads/thankyou/{id:int}")]
        public ActionResult ThankYou(int id = 0)
        {
            try
            {
                if (id > 0)
                {
                    PPCCourseDTO model = AppUnitOfWork.ICommonLogic.GetCourseDataDetails(id);
                    if (model != null)
                    {
                        ViewBag.url = _ImageServerUrl + AppUnitOfWork.IDocument.GetAll().Where(d => d.CourseId == id && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();
                        return View(model);
                    }
                }
                else
                {
                    return Redirect("https://www.dotnettricks.com/");
                }
            }
            catch (Exception es)
            {

            }
            return Redirect("https://www.dotnettricks.com/");
        }

        public ActionResult ThankYouBooks(int id = 0)
        {
            if (id > 0)
            {
                PPCCourseDTO model = AppUnitOfWork.ICommonLogic.GetCourseDataDetails(id);
                ViewBag.url = _ImageServerUrl + AppUnitOfWork.IDocument.GetAll().Where(d => d.CourseId == id && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();

                return View(model);
            }
            else
            {
                return Redirect("https://www.dotnettricks.com/");
            }
        }
        public ActionResult DownloadSyllabus(int CourseId = 0, string Type = "", int mode = 0, int EnquiryType = 0)
        {
            try
            {
                var DocumentUrl = AppUnitOfWork.IDocument.GetAll().Where(d => d.CourseId == CourseId && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();
                ViewBag.DCourseId = CourseId;
                ViewBag.Type = Type;
                ViewBag.EnquiryType = EnquiryType;
                ViewBag.DocumentUrl = DocumentUrl;
                ViewBag.TrainingModeId = mode;
                return PartialView("_AdsDownloadsyllabus");
            }
            catch (Exception ex)
            {
                ViewBag.DocumentUrl = null;
            }
            return null;
        }
        public ActionResult Mentors(int id = 0)
        {
            IEnumerable<MentorMaster> model = AppUnitOfWork.ICourse.GetPPCMentorList(id);
            if (model != null)
            {
                ViewBag.flag = "1";
                return PartialView("_MentorPage", model);
            }
            else
            {
                List<MentorMaster> model1 = new List<MentorMaster>();
                return PartialView("_MentorPage", model1);
            }
        }
        [HttpPost]
        public JsonResult VerifyOtp(DownloadSyllabusDTO model)
        {
            try
            {
                bool check = AppUnitOfWork.IQuery.verifyOtpInfo(model);
                if (check == true)
                {
                    ModelState.Clear();
                    var url = AppUnitOfWork.IDocument.GetAll().Where(d => d.CourseId == model.DCourseId && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();
                    var ext = Path.GetExtension(url);

                    if (ext == ".pdf" || ext == ".PDF")
                    {
                        url = _ImageServerUrl + url;
                        return Json(new { msg = "success", url }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { msg = "success", url }, JsonRequestBehavior.AllowGet);
                    }
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult VerifyOtpQury(DownloadSyllabusDTO model)
        {
            try
            {
                bool check = AppUnitOfWork.IQuery.verifyOtpInfo(model);
                if (check == true)
                {

                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);

                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GenerateAgainOtp(DownloadSyllabusDTO model)
        {
            try
            {
                int otp = AppUnitOfWork.IQuery.GenerateAgainOtp(model.OtpId);
                if (otp != 0)
                {
                    int otpid = otp;
                    return Json(new { msg = "done", otpid }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult SaveDownloadEnquiryAfterLogin(DownloadSyllabusDTO model)
        {
            try
            {
                int count = AppUnitOfWork.IQuery.GetEnquiryInfo(model);
                if (count <= 2)
                {
                    int quid = 0;
                    if (model.ID == 0)
                    {
                        quid = AppUnitOfWork.IQuery.SyllabusDownloadPPC(model);
                    }
                    else
                    {
                        quid = AppUnitOfWork.IQuery.SyllabusDownloadPPCUpdate(model);
                    }

                    ModelState.Clear();
                    // return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);

                    var url = AppUnitOfWork.IDocument.GetAll().Where(d => d.CourseId == model.DCourseId && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();

                    //TO DO:
                    var ext = Path.GetExtension(url);
                    url = _ImageServerUrl + url;
                    if (ext == ".pdf" || ext == ".PDF")
                    {
                        return Json(new { msg = "success", url }, JsonRequestBehavior.AllowGet);
                        //return File(url, "application/pdf", "Syllabus" + ".pdf");
                    }
                    else
                    {
                        return Json(new { msg = "success", url }, JsonRequestBehavior.AllowGet);
                        //return File(url, "application/zip", "Syllabus" + ".zip");
                    }
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveAdsMasterCallBack(QueryDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetEnquiryCount(model);
                if (count == 0)
                {
                    model.Name = "N/A";
                    model.Message = "PPC-Curriculum";
                    model.TrainingModeId = (int)EnumTrainingMode.Online;
                    UOF.IQuery.SaveQuery(model);
                    try
                    {
                        //   MailClient.SendMail_Enquiry(model);
                    }
                    catch (Exception ex)
                    {
                    }
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }

                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

    }
}