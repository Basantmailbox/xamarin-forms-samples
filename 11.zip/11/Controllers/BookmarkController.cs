﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class BookmarkController : BaseController
    {

        public JsonResult SetBookmarks(int courseId, int subTopicId)
        {
            if (subTopicId > 0)
            {
                //TODO
                if (CurrentUser != null)
                {
                Bookmark entityObj = new Bookmark();
                entityObj.CourseId = courseId;
                entityObj.CourseType = (int)DNTShared.EnumCourseType.Books;
                entityObj.MemberId = CurrentUser.UserId; // 61431 TODO
                    entityObj.ModuleId = subTopicId;
                entityObj = UOF.IBookmark.InsertEntity(entityObj);
                return Json(new { IsSuccess = true, MSG = "Topic Bookmarked" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { IsSuccess = false, MSG = "Please Login" }, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(new { IsSuccess = false, MSG = "Please try again" }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}