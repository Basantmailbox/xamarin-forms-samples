﻿using DNTData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebCore;
using DNTWebCore.Enum;
using System.Text.RegularExpressions;

namespace DotNetTricks.COM.Controllers
{
    public class LearnController : Controller
    {
        public const int PageSize = 20;
        public string _baseUrl = string.Empty;
        IUnitOfWork UOF;

        public LearnController()
        {
            UOF = new UnitOfWork();
            _baseUrl = WebConfigSetting.BaseURL;
        }
        private TutorialPathDTO GetTutorial(string url)
        {
            TutorialPathDTO tut = UOF.ITutorial.GetTutorialPath(url);
            int wc = WordsCount(tut.Description);
            tut.ReadTime = wc / 200;
            tut.ReadTime = tut.ReadTime == 0 ? 1 : tut.ReadTime;

            if (tut.Description != null)
            {

                ViewBag.Title = tut.Title;
                ViewBag.TutorialID = tut.TutorialID;
                ViewBag.Keywords = tut.MetaKeywords;
                ViewBag.CatID = tut.CategoryID;
                string str = tut.ShortDescription.Remove(0, 3);
                ViewBag.Description = str.Remove(str.IndexOf('<'), 4);
                if ((bool)RouteData.Values["IsRefreshed"] == false)
                {
                    TutorialDTO tot = new TutorialDTO();
                    tot.TotalViews = tut.TotalViews + 1;
                    UOF.ITutorial.updateTotalViews(tut.TutorialID, (long)tot.TotalViews);
                }

                ViewBag.Canonical = tut.ArticleUrl;
                return tut;
            }
            else
            {
                return null;
            }
        }
        public int WordsCount(string str)
        {
            return Regex.Matches(str, @"((\w+(\s?)))").Count;
        }
        private PagingDTO<TutorialDTO> GetTutorialListByCategory(string cat, int page)
        {
            PagingDTO<TutorialDTO> tutorial = new PagingDTO<TutorialDTO>();
            var lstcat = UOF.ICategory.GetByCategory(cat);
            if (lstcat != null)
            {
                ViewBag.Title = lstcat.Title;
                ViewBag.Keywords = lstcat.MetaKeywords;
                ViewBag.Description = lstcat.MetaDescription;
                ViewBag.Header = lstcat.MetaDescription;
                tutorial = UOF.ITutorial.GetAllTutorialListByCategory(lstcat.CategoryID, page, PageSize);

                //tutorial.Data = lst;
                //tutorial.PageSize = Convert.ToInt32(Math.Ceiling((float)UOF.ITutorial.GetCountByCategoryId(lstcat.CategoryID) / PageSize));
                //tutorial.Page = page;

                return tutorial;
            }
            else
            {
                return null;
            }
        }
        private PagingDTO<TutorialDTO> GetTutorialList(int page)
        {
            PagingDTO<TutorialDTO> tutorial = new PagingDTO<TutorialDTO>();
            tutorial = UOF.ITutorial.GetTutorialList(page, PageSize);
            return tutorial;
        }

        [Route("getalltutorial/{page:int}")]
        public ActionResult GetAllTutorialList(int page)
        {
            try
            {
                PagingDTO<TutorialDTO> tutorial = new PagingDTO<TutorialDTO>();

                tutorial = UOF.ITutorial.GetTutorialList(page, PageSize);

                return Json(tutorial, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }

        [Route("~/learn")]
        public ActionResult Index(int page = 1)
        {
            var data = GetTutorialList(page);

            if (data.Data.Count() > 0)
            {
                ViewBag.Count = data.Data.Select(x => x.AuthorList).Count();
                return View(data);
            }
            else
                return RedirectToAction("NotFound", "Error");
        }

        [Route("~/articles")]
        public ActionResult Articles()
        {
            return View();
        }

        [Route("~/interview-questions")]
        public ActionResult InterviewQuestions(int page = 1)
        {
            PagingDTO<TutorialDTO> data = new PagingDTO<TutorialDTO>();
            data = UOF.ITutorial.GetQuestionList(page, PageSize);

            if (data.Data.Count() > 0)
            {
                ViewBag.Count = data.Data.Select(x => x.AuthorList).Count();
                return View(data);
            }
            else
                return RedirectToAction("NotFound", "Error");
        }

        [Route("~/learn/{cat}/{page:int?}")]

        public ActionResult ListByCategory(string cat, int page = 1)
        {
            // ViewBag.cat = cat;
            // var data = GetTutorialListByCategory(cat, page);
            var data = UOF.ITutorial.GetCategoryPath(cat);
            if (data == null)
                return RedirectToAction("NotFound", "Error");
            else
                return View(data);
        }

        [Route("getallarticles/{cat}/{page:int?}")]
        public ActionResult GetAllArticles(string cat, int page = 1)
        {
            try
            {
                PagingDTO<TutorialDTO> tutorial = new PagingDTO<TutorialDTO>();

                tutorial = GetTutorialListByCategory(cat, page);

                return Json(tutorial, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }

        protected List<TutorialDTO> GetRelatedArticles(string cat, string url)
        {
            var cachedata = CacheService.GetCacheList<TutorialDTO>(cat);
            if (cachedata == null)
            {
                IEnumerable<TutorialDTO> data = UOF.ITutorial.GetRelatedTutorial(cat, url);
                cachedata = CacheService.SetCacheList<TutorialDTO>(cat, data, (int)CacheDuration.FullDay);
            }
            return cachedata.ToList();
        }

        [DetectPageRefreshFilter]
        [Route("~/learn/{cat}/{url}")]

        public ActionResult Article(string cat, string url)
        {
            url = "/learn/" + cat + "/" + url;

            string catUrl = "";
            if (!string.IsNullOrEmpty(cat))
                catUrl = "/learn/" + cat.ToLower();

            var data = GetTutorial(url);
            ViewBag.Count = data.AuthorList.Count();
            if (data == null)
            {
                return RedirectToAction("NotFound", "Error");
            }
            else
            {
                ViewBag.CurrentArticle = url;
                ViewBag.CurrentCat = catUrl;
                data.TutList = GetRelatedArticles(cat, catUrl);
                ViewBag.arttype = data.TutList.Where(c => c.ArticleUrl == url).Select(s => s.ArticleType).FirstOrDefault();
            }
            return View(data);
        }

        [Route("~/mentors/{url}")]
        public ActionResult AuthorProfile(string url, int page = 1)

        {
            try
            {
                PagingDTO<TutorialDTO> model = new PagingDTO<TutorialDTO>();
                var urlfull = "/mentors/" + url;
                ViewBag.urlfull = urlfull;
                var lstMen = UOF.IMentorMaster.GetMentorByUrl(urlfull);
                if (lstMen != null)
                {

                    //  model = UOF.ITutorial.GetAllTutorialListByMentor(lstMen.MentorId, page, PageSize);
                    model.MentorDetails = lstMen;
                    return View(model);
                }
                return RedirectToAction("NotFound", "Error");

            }
            catch (Exception)
            {
                return null;
            }
        }


        public ActionResult getAuthorArticles(string urlfull, int page = 1)
        {
            try
            {
                PagingDTO<TutorialDTO> model;
                var lstMen = UOF.IMentorMaster.GetMentorByUrl(urlfull);
                if (lstMen != null)
                {
                    model = UOF.ITutorial.GetAllTutorialListByMentor(lstMen.MentorId, page, PageSize);
                    if (model == null)
                        model = new PagingDTO<TutorialDTO>();
                    model.MentorDetails = lstMen;
                    return PartialView("_getAuthorArticles", model);
                }
                return RedirectToAction("NotFound", "Error");
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [Route("getallAuthorArticles/{MentorId:int}/{page:int?}")]
        public ActionResult getallAuthorArticles(int MentorId, int page = 1)
        {
            try
            {
                PagingDTO<TutorialDTO> model = new PagingDTO<TutorialDTO>();

                var lstMen = UOF.IMentorMaster.Get(MentorId);
                if (lstMen != null)
                {
                    model = UOF.ITutorial.GetAllTutorialListByMentor(lstMen.MentorId, page, PageSize);
                    model.MentorDetails = lstMen;
                }
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult getAuthorEvents(int MentorId, int page = 1)
        {
            try
            {
                PagingDTO<EventDTO> model = new PagingDTO<EventDTO>();
                ViewBag.MentorId = MentorId;
                model = UOF.IEvent.GetAllEventsListByMentor(MentorId, page, PageSize);
                return PartialView("_getAuthorEvents", model);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public ActionResult getAuthorBooks(int MentorId, int page = 1)
        {
            try
            {
                PagingDTO<CourseDTO> model = new PagingDTO<CourseDTO>();
                ViewBag.MentorId = MentorId;
                model = UOF.IBookMasters.GetAllBooksListByMentor(MentorId, page, PageSize);
                return PartialView("_getAuthorBooks", model);
            }
            catch (Exception)
            {
                return null;
            }
        }
        [Route("getallAuthorBooks/{MentorId:int}/{page:int?}")]
        public ActionResult getallAuthorBooks(int MentorId, int page = 1)
        {
            try
            {
                PagingDTO<CourseDTO> model = new PagingDTO<CourseDTO>();
                ViewBag.MentorId = MentorId;
                model = UOF.IBookMasters.GetAllBooksListByMentor(MentorId, page, PageSize);
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }
        [Route("getallAuthorEvents/{MentorId:int}/{page:int?}")]
        public ActionResult getallAuthorEvents(int MentorId, int page = 1)
        {
            try
            {
                PagingDTO<EventDTO> model = new PagingDTO<EventDTO>();
                ViewBag.MentorId = MentorId;
                model = UOF.IEvent.GetAllEventsListByMentor(MentorId, page, PageSize);
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult Author(int TutorialID = 0)
        {
            IEnumerable<MentorMaster> model = UOF.ITutorial.GetAuthorsList(TutorialID);
            if (model != null)
            {
                ViewBag.flag = "1";
                return PartialView("_AuthorPage", model);
            }
            else
            {
                List<MentorMaster> model1 = new List<MentorMaster>();
                return PartialView("_AuthorPage", model1);
            }
        }
    }
}
