﻿using DNTData;
using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Helpers;
using System.Web.Http;

namespace DotNetTricks.COM.Controllers
{
    public class DNTServiceController : ApiController
    {
        IUnitOfWork _iUnitOfWork;
        public IUnitOfWork UOF
        {
            get
            {
                if (_iUnitOfWork == null)
                    _iUnitOfWork = new UnitOfWork();
                return _iUnitOfWork;
            }
        }

        [HttpPost]
        public string UploadProfilePic()
        {
            string userId = HttpContext.Current.Request.Form["userId"];
            string oldpic = HttpContext.Current.Request.Form["oldpic"];
            var pic = HttpContext.Current.Request.Files["MyImages"];
            string pathurl = "";

            if (pic != null)
            {
                var fileName = Path.GetFileName(pic.FileName);   //file name  
                var ext = Path.GetExtension(pic.FileName);

                string name = Path.GetFileNameWithoutExtension(fileName);
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string myfile = userId + time + ext; //

                string _memberImageFolderLocation;
                _memberImageFolderLocation = ConfigurationManager.AppSettings["memberImageFolder"].ToString();

                string path = Path.Combine(HttpContext.Current.Server.MapPath(_memberImageFolderLocation), myfile);
                pathurl = _memberImageFolderLocation + myfile;

                string directoryPath = HttpContext.Current.Server.MapPath(string.Format("{0}", _memberImageFolderLocation));
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }
                string _comPath = path;
                path = _comPath;
                pic.SaveAs(path);
                MemoryStream ms = new MemoryStream();
                WebImage img = new WebImage(_comPath);

                if (img.Width > 200)
                    img.Resize(200, 200);
                img.Save(_comPath);
                string fullPath = HttpContext.Current.Request.MapPath(oldpic);

                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                }
            }
            else
            {
                pathurl = oldpic;
            }
            return pathurl;
        }

        [HttpGet]
        public List<MockupTestQuestionOptionAnswerDTO> GetMockupTestQuestions(int id = 0)
        {
            return UOF.IQuestionMaster.GetMockupTestQuestionDetails(id);
        }

        //studymode quiz
        [HttpGet]
        public List<QuizDTO> GetStudyModeQuizQuestions(int id = 0)
        {
            return UOF.IQuestionMaster.GetStudyModeQuizQuestions(id);
        }

        [HttpPost]
        [HttpOptions]
        public int SaveMockupTestQuestions(MockUpTestAttemptedStatusDTO model)
        {
            int result = UOF.IQuestionMaster.AddTestResult(model);
            return result;
        }

        [HttpPost]
        [HttpOptions]
        public int SaveMockupQuizQuestions(MockUpTestAttemptedStatusDTO model)
        {           
            int result = UOF.IQuestionMaster.AddQuizResult(model);
            return result;
        }
    }
}
