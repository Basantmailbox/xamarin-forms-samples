﻿using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;

namespace DotNetTricks.COM.Controllers
{
    public class CommentController : BaseController
    {
        int pageSize;
        int pageSizeComment;

        public CommentController()
        {
            pageSize = WebConfigSetting.PageSize / 3;
            pageSizeComment = WebConfigSetting.PageSize;
        }

        public ActionResult Index()
        {
            return View();
        }
        [ChildActionOnly]
        [HttpGet]
        public ActionResult CommentArea(int page = 1, int TutorialID = 0, bool IsBook = false)
        {
            PagingDTO<CommentMasterDTO> model = UOF.ICommentMaster.GetallComments(page, pageSizeComment, TutorialID, IsBook);
            ViewBag.TutorialID = TutorialID;
            ViewBag.IsBook = IsBook;
            ViewBag.TotalComment = model.Data.Where(x => x.IsVerified == true && x.IsBook == IsBook).Count();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageSizeComment;
            }
            if (CurrentUser == null)
            {
                ViewBag.user = 0;

            }
            else { ViewBag.user = CurrentUser.UserId; }
            return PartialView("_CommentArea", model);
        }

        [Route("comment/getcommentarea/{page:int}/{TutorialID:int}/{IsBook:bool}")]
        public ActionResult GetCommentArea(int page = 1, int TutorialID = 0, bool IsBook = false)
        {
            PagingDTO<CommentMasterDTO> model = UOF.ICommentMaster.GetallComments(page, pageSizeComment, TutorialID, IsBook);
            ViewBag.TutorialID = TutorialID;
            ViewBag.IsBook = IsBook;
            ViewBag.TotalComment = model.Data.Where(x => x.IsVerified == true && x.IsBook == IsBook).Count();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageSizeComment;
            }
            if (CurrentUser == null)
            {
                ViewBag.user = 0;

            }
            else { ViewBag.user = CurrentUser.UserId; }
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveComment(CommentMasterDTO model)
        {
            if (CurrentUser != null)
            {
                bool status = UOF.ICommentMaster.SaveComments(model, CurrentUser.UserId);
                if (status == true)
                {
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveReply(ReplyOnCommentDTO model)
        {
            if (CurrentUser != null)
            {
                bool status = UOF.ICommentMaster.SaveReply(model, CurrentUser.UserId);
                if (status == true)
                {
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

    }
}
