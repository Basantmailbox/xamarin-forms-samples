﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebUI.Models.Security;
using DNTWebCore;
using System.Linq;
using System.IO;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;
using System.Configuration;

namespace DotNetTricks.COM.Controllers
{
    //TO DO: Delete (Old eBooks)
    public class BooksController : BaseController
    {
        public string _baseUrl = string.Empty;

        static CloudBlobClient blobClient;
        CloudStorageAccount storageAccount;

        public BooksController()
        {
            _baseUrl = WebConfigSetting.BaseURL;
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
        }

        [Route("~/books")]
        public ActionResult Index()
        {
            var source = Request.QueryString["s"];
            var code = Request.QueryString["c"];
            if (source != null)
            {
                Session["URLSource"] = source;
            }
            if (code != null)
            {
                Session["ReferralCode"] = code;
            }

            TempData["flag"] = "true";
            return View(UOF.ICommonLogic.GetCategoryWiseCourses("USD", (int)EnumCourseType.Books));
        }

        public ActionResult Mentors(int id = 0)
        {
            IEnumerable<MentorMaster> model = UOF.IBookMasters.GetBookMentorList(id);
            if (model != null)
            {
                ViewBag.flag = "1";
                return PartialView("_AuthorPage", model);

            }
            else
            {
                List<MentorMaster> model1 = new List<MentorMaster>();

                return PartialView("_AuthorPage", model1);
            }
        }

        [TimeZoneFliter]
        [Route("books/{url}")]
        public ActionResult BookDetail(string url)
        {
            var source = Request.QueryString["s"];
            var code = Request.QueryString["c"];
            if (source != null)
            {
                Session["URLSource"] = source;
            }
            if (code != null)
            {
                Session["ReferralCode"] = code;
            }

            var currency = Session["currency"].ToString();
            ViewBag.CourseURL = url;
            url = "/books/" + url;

            Session["master"] = "";
            TempData["flag"] = "true"; //For hiding testimonial slider
            CourseDTO model = UOF.ICommonLogic.GetCourseDataDetails(url, currency);

            if (model == null || model.CourseType != (int)EnumCourseType.Books)
            {
                return RedirectToAction("Index");
            }
            ViewBag.cid = model.CourseId;
            string key = "homeCourselist";

            var Courses = CacheService.GetCacheList<CourseDTO>(key);
            if (Courses != null && Courses.Count() > 0)
                ViewBag.Books = Courses.Where(x => x.CourseType == (int)EnumCourseType.Books).Take(14).ToList();

            return View(model);
        }

        [TimeZoneFliter]
        public ActionResult BookPrice(int id)
        {
            var currency = Session["currency"].ToString();
            CoursePriceDTO model = new CoursePriceDTO();
            if (CurrentUser != null)
            {
                model = UOF.ICommonLogic.GetCoursePricesSelf(id, currency, CurrentUser.UserId);
            }
            else
            {
                model = UOF.ICommonLogic.GetCoursePricesSelf(id, currency);
            }

            ViewBag.courseId = id;
            return PartialView("_Book_Price", model);
        }


        [Route("books/preview/{id}")]
        public ActionResult EBookProview(string id)
        {
            DocumentDTO docData = new DocumentDTO();
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    docData = UOF.IDocument.GetDocumentById(Convert.ToInt32(id));

                    if (docData != null)
                    {
                        docData.DocumentUrl = "<iframe src='https://docs.google.com/viewer?url=" + docData.DocumentUrl + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
                    }
                }
                //if (CurrentUser != null)
                //{

                //    int Documentid = Convert.ToInt32(id);

                //    //UOF.ICommonLogic.AddBookDownloadDetails(CurrentUser.UserId, Documentid);

                //    DocumentDTO data = UOF.IDocument.GetDocumentById(Documentid);
                //    var ext = Path.GetExtension(data.DocumentUrl);
                //    var filename = Path.GetFileName(data.DocumentUrl);
                //    blobClient = storageAccount.CreateCloudBlobClient();

                //    CloudBlobContainer container = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                //    CloudBlockBlob blob = container.GetBlockBlobReference(filename);

                //    Stream blobStream = blob.OpenRead();
                //    if (ext == ".pdf" || ext == ".PDF")
                //    {
                //        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".pdf");
                //    }
                //    else
                //    {
                //        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".zip");
                //    }

                //}

                return View(docData);
            }

            catch (Exception e)
            {
                return null;
            }

        }
    }
}
