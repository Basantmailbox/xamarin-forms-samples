﻿using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class IndustrialTrainingController : Controller
    {
        [Route("~/6-month-industrial-training")]
        public ActionResult Index()
        {
            return View();
        }

        [Route("~/industrial/noida/six-months-dot-net-training")]
        public ActionResult DotNetTraining()
        {
            return View();
        }

        [Route("~/industrial/noida/six-months-seo-ppc-training")]
        public ActionResult SeoPpcTraining()
        {
            return View();
        }

        [Route("~/industrial/noida/six-months-android-training")]
        public ActionResult AndroidTraining()
        {
            return View();
        }
        [Route("~/industrial/noida/six-months-mean-training")]
        public ActionResult MeanTraining()
        {
            return View();
        }
    }
}
