﻿using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using DNTData;
using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using System.Net.NetworkInformation;

namespace DotNetTricks.COM.Controllers
{
    public class AccountController : BaseController
    {
        public string _baseUrl = string.Empty;
        public string _CookieDomain = string.Empty;
        public AccountController()
        {
            _baseUrl = WebConfigSetting.BaseURL;
        }
        private void SetLoginDeviceHistory(int userId, int roleId)
        {
            LoginHistory loginHistoryObj = new LoginHistory();
            loginHistoryObj.LoginUserId = userId;
            loginHistoryObj.RoleId = roleId;
            loginHistoryObj.LastLoginAt = DateTime.Now;

            //original IP will be updated by Proxy/Load Balancer.
            string originalIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (!string.IsNullOrEmpty(originalIP))
            {
                string[] ipRange = originalIP.Split(',');
                int le = ipRange.Length - 1;
                loginHistoryObj.IPAddress = ipRange[0];
            }
            else
            {
                loginHistoryObj.IPAddress = Request.ServerVariables["REMOTE_ADDR"];
            }

            loginHistoryObj.IsMobileDevice = Request.Browser.IsMobileDevice;
            if (loginHistoryObj.IsMobileDevice)
            {
                //If need Mobile Device Name
                //string strmanu = Request.Browser.MobileDeviceManufacturer.ToLower().ToString();
                loginHistoryObj.BrowserName = Request.Browser.Browser;
            }
            else
            {
                loginHistoryObj.BrowserName = Request.Browser.Browser;
            }

            //Get Client MAC Address
            foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus == OperationalStatus.Up)
                {
                    loginHistoryObj.MACAddress += nic.GetPhysicalAddress().ToString();
                    break;
                }
            }
            UOF.ILoginHistory.Insert(loginHistoryObj);
        }

        private void GenerateTicket(MemberDTO member)
        {
            CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel();
            serializeModel.UserId = member.MemberId;
            serializeModel.Name = member.Name;
            serializeModel.MobileNo = member.ContactNo;
            serializeModel.Email = member.Email;
            serializeModel.Roles = member.Roles;
            serializeModel.CurrentLocation = member.CurrentLocation;
            serializeModel.ProfilePic = member.ProfilePic;
            serializeModel.ProfilePicDomain = member.ProfilePicDomain;
            serializeModel.MembershipId = member.MembershipId;
            serializeModel.MembershipExpiry = member.MembershipExpiry;

            string userData = JsonConvert.SerializeObject(serializeModel);
            FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                     1,
                     member.Name,
                     DateTime.Now,
                     DateTime.Now.AddMinutes(60),
                     true,
                     userData);

            string encTicket = FormsAuthentication.Encrypt(authTicket);
            HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
            //faCookie.Domain = _CookieDomain;
            Response.Cookies.Add(faCookie);
            SetLoginDeviceHistory(Convert.ToInt32(member.MemberId), 3); //3 for member
        }

        [HttpGet]
        [Route("~/member-login")]
        public ActionResult Login(string ReturnUrl)
        {
            ViewBag.ReturnUrl = ReturnUrl;
            if (CurrentUser != null && CurrentUser.Email != "")
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Member" });
            }
            if (ReturnUrl != null)
            {
                if (ReturnUrl.Contains("StartQuiz"))
                {
                    var id = ReturnUrl.Split('/')[4];
                    Session["QuizId"] = id;
                }
                else { Session["QuizId"] = null; }
            }
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(LoginDTO model, string url)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    MemberDTO member = UOF.IMember.AuthenticateMember(model.Email, model.Password);
                    if (member != null)
                    {
                        if (member.IsVerified != true)
                        {
                            return Json("The member account is not verified. Please verify you account.", JsonRequestBehavior.AllowGet);
                        }
                        else if (member.IsActive != true)
                        {
                            return Json("The member account is de-activated. Please contact website administrator.", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            GenerateTicket(member);

                            //if (Session["eventid"] != null)
                            //{
                            //    return RedirectToAction("JoinEvent", "Events", new { area = "Member" });
                            //}
                            if (Session["QuizId"] != null)
                            {
                                var id = Session["QuizId"];
                                return RedirectToAction("StartQuiz", "Test", new { area = "Member", id = id });
                            }
                            else if (!string.IsNullOrEmpty(url))
                            {
                                return Redirect(url);
                            }
                            else
                            {
                                return Json("success", JsonRequestBehavior.AllowGet);
                            }
                        }
                    }
                    else
                    {
                        return Json("The Email or Password provided is incorrect!", JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return Json("Internal error!", JsonRequestBehavior.AllowGet);
        }

        //[HttpGet]
        //public ActionResult IDUserLogin(string email, string password)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            MemberDTO member = UOF.IMember.AuthenticateMember(email, password);
        //            if (member != null)
        //            {
        //                if (member.IsVerified != true)
        //                {
        //                    return Json("The member account is not verified. Please verify you account.", JsonRequestBehavior.AllowGet);
        //                }
        //                else if (member.IsActive != true)
        //                {
        //                    return Json("The member account is de-activated. Please contact website administrator.", JsonRequestBehavior.AllowGet);
        //                }
        //                else
        //                {
        //                    GenerateTicket(member);

        //                    //if (Session["eventid"] != null)
        //                    //{
        //                    //    return RedirectToAction("JoinEvent", "Events", new { area = "Member" });
        //                    //}
        //                    if (Session["QuizId"] != null)
        //                    {
        //                        var id = Session["QuizId"];
        //                        return RedirectToAction("StartQuiz", "Test", new { area = "Member", id = id });
        //                    }
        //                    //else if (!string.IsNullOrEmpty(url))
        //                    //{
        //                    //    return Redirect(url);
        //                    //}
        //                    else
        //                    {
        //                        return Json("success", JsonRequestBehavior.AllowGet);
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                return Json("The Email or Password provided is incorrect!", JsonRequestBehavior.AllowGet);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //    return Json("Internal error!", JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public ActionResult UserSignUp(MemberDTO model, string url)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //Check already existing email
                    bool isMemberEmailAlreadyExists = UOF.IMember.Check_Member_Email_Already_Exists(model.Email);
                    if (isMemberEmailAlreadyExists == true)
                    {
                        return Json("Email Id already exists. Please login.", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        MemberDTO mObj = UOF.IMember.MemberRegistration(model, false);
                        try
                        {

                            bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(mObj);
                            if (mailStatus == true)
                            {
                                int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(mObj.MemberId);
                            }
                            return Json("success", JsonRequestBehavior.AllowGet);

                            //Need to Check (27th Nov 2019) : Register unVerified user for Event
                            //if (Session["eventid"] != null)
                            //{
                            //    return RedirectToAction("EventMemberRegistration", "Account");
                            //}
                            //if (Session["QuizId"] != null)
                            //{
                            //    var id = Session["QuizId"];
                            //    return RedirectToAction("StartQuiz", "Test", new { area = "Member", id = id });
                            //}
                            //else if (!string.IsNullOrEmpty(url))
                            //{
                            //    return Redirect(url);
                            //}
                            //else
                            //{
                            //    return Json("success", JsonRequestBehavior.AllowGet);
                            //}
                        }
                        catch (Exception ex) { }
                    }
                }
                else
                {
                    return Json("Please correct errors!", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json("There is internal error!", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Route("~/member-login")]
        public ActionResult Login(LoginDTO model, string ReturnUrl)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    MemberDTO member = UOF.IMember.AuthenticateMember(model.Email, model.Password);
                    if (member != null)
                    {
                        if (member.IsVerified != true)
                        {
                            ModelState.AddModelError("", "The member account is not verified. Please verify you account.");
                            return View(model);
                        }
                        else if (member.IsActive != true)
                        {
                            ModelState.AddModelError("", "The member account is de-activated. Please contact website administrator.");
                            return View(model);
                        }
                        else
                        {
                            GenerateTicket(member);
                            if (Session["eventid"] != null)
                            {
                                return RedirectToAction("JoinEvent", "Events", new { area = "Member" });
                            }
                            else if (Session["QuizId"] != null)
                            {
                                var id = Session["QuizId"];
                                return RedirectToAction("StartQuiz", "Test", new { area = "Member", id = id });
                            }
                            else if (!string.IsNullOrEmpty(ReturnUrl))
                            {
                                return Redirect(ReturnUrl);
                            }
                            else
                            {
                                return RedirectToAction("Index", "Dashboard", new { area = "Member" });
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "The Email or Password provided is incorrect!");
                        return View();
                    }
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
            }
            // If we got this far, something failed, redisplay form
            return View(model);
        }

        [HttpGet]
        [Route("~/member-registration")]
        public ActionResult SignUp(string ReturnUrl)
        {
            ViewBag.ReturnUrl = ReturnUrl;
            if (ReturnUrl != null)
            {
                if (ReturnUrl.Contains("StartQuiz"))
                {
                    var id = ReturnUrl.Split('/')[4];
                    Session["QuizId"] = id;
                }
                else { Session["QuizId"] = null; }
            }
            return View();
        }

        [HttpPost]
        [Route("~/member-registration")]
        public ActionResult SignUp(MemberDTO modelData, string ReturnUrl)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //Check already existing email
                    bool isMemberEmailAlreadyExists = UOF.IMember.Check_Member_Email_Already_Exists(modelData.Email);
                    if (isMemberEmailAlreadyExists == true)
                    {
                        ModelState.AddModelError("", "Email Id already exists. Please login.");
                        return View(modelData);
                    }
                    else
                    {

                        MemberDTO model = UOF.IMember.MemberRegistration(modelData, false);
                        try
                        {
                            bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(model);
                            if (mailStatus == true)
                            {
                                int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(model.MemberId);
                            }

                            //Register unVerified user for Event
                            if (Session["eventid"] != null)
                            {
                                return RedirectToAction("EventMemberRegistration", "Account");
                            }
                            else if (Session["QuizId"] != null)
                            {
                                var id = Session["QuizId"];
                                return RedirectToAction("StartQuiz", "Test", new { area = "Member", id = id });
                            }
                            else if (!string.IsNullOrEmpty(ReturnUrl))
                            {
                                return Redirect(ReturnUrl);
                            }
                        }
                        catch (Exception ex) { }
                    }
                    return RedirectToAction("MemberRegistration", "Account");
                }
                else
                {
                    ModelState.AddModelError("", "Please fill the form with correct data.");
                }
            }
            catch (Exception ex) { }
            return View(modelData);
        }

        public ActionResult SignOut()
        {
            string[] Roles = CurrentUser != null ? CurrentUser.Roles : new string[] { "" };
            Session.Clear();
            Session.Abandon();

            ClearCookie(FormsAuthentication.FormsCookieName);
            //ClearAllCookie();
            FormsAuthentication.SignOut();

            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();

            if (Roles.Contains("Admin"))
            {
                return RedirectToAction("Index", "Account", new { area = "Admin" });
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        [Route("~/trial-started")]
        public ActionResult TrialStarted()
        {
            return View();
        }

        [Route("~/free-trial")]
        public ActionResult FreeTrial()
        {
            return View();
        }

        [Route("~/redeem-pass")]
        public ActionResult RedeemPass()
        {
            TempData["flag"] = "true";
            return View();
        }

        [HttpPost]
        public JsonResult CheckPass(string PassId)
        {
            try
            {
                bool data = UOF.ICommonLogic.CheckPass(PassId);
                if (data)
                {
                    Session["PassId"] = PassId;
                    return Json(new { msg = "success", data }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    Session["PassId"] = "";
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [Route("~/redeem-pass-started")]
        public ActionResult RedeemPassStarted()
        {
            TempData["flag"] = "true";
            return View();
        }

        [HttpPost]
        [Route("~/redeem-pass-started")]
        public ActionResult RedeemPassStarted(MemberDTO model, bool IsRegistered)
        {
            if (IsRegistered)
            {
                MemberDTO member = UOF.IMember.AuthenticateMember(model.Email, model.Password);
                if (member != null)
                {
                    if (member.IsVerified != true)
                    {
                        ModelState.AddModelError("", "The member account is not verified. Please verify you account.");
                        return View();
                    }
                    else if (member.IsActive != true)
                    {
                        ModelState.AddModelError("", "The member account is de-activated. Please contact website administrator.");
                        return View();
                    }
                    else
                    {
                        string PassId = Session["PassId"] as string;
                        //assigning membership
                        member.MembershipId = AssisgnOneMonthMembership(member.MemberId, member.Email, PassId);

                        if (member.MembershipId > 0)
                        {
                            GenerateTicket(member);
                            TempData["IsRegistered"] = "true";
                            return RedirectToAction("ConfirmRedeemPass", "Account");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "The Email or Password provided is incorrect!");
                    return View();
                }
            }
            else
            {
                //Check already existing email
                bool isMemberEmailAlreadyExists = UOF.IMember.Check_Member_Email_Already_Exists(model.Email);
                if (isMemberEmailAlreadyExists == true)
                {
                    ModelState.AddModelError("", "Email Id already registered. Please use option registered user.");
                    return View();
                }
                else
                {
                    MemberDTO member = UOF.IMember.MemberRegistration(model, false);
                    try
                    {
                        //do pass only member instance
                        bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(member);
                        if (mailStatus == true)
                        {
                            string PassId = Session["PassId"] as string;
                            //assigning membership
                            member.MembershipId = AssisgnOneMonthMembership(member.MemberId, member.Email, PassId);

                            int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(member.MemberId);
                            TempData["IsRegistered"] = "false";
                            return RedirectToAction("ConfirmRedeemPass", "Account");
                        }
                    }
                    catch (Exception ex) { }
                }
            }
            return View();
        }

        [Route("~/confirm-redeem-pass")]
        public ActionResult ConfirmRedeemPass()
        {
            return View();
        }

        private int AssisgnTrialMembership(Int64 memberId)
        {
            int subsId = UOF.IMember.GetMembershipDetails(memberId).MembershipId;
            if (subsId > 0 && subsId != (int)EnumMembership.Trial)
            {
                ModelState.AddModelError("", "You are already a subscribed member. You don't need subscription!");
            }
            else if (subsId == (int)EnumMembership.Trial)
            {
                ModelState.AddModelError("", "You already having a trial subscription!");
            }
            else
            {
                CourseSubscriptionMemberDTO subs = new CourseSubscriptionMemberDTO();
                subs.MemberId = memberId;
                subs.TrainingModeId = (int)EnumTrainingMode.SelfPlaced;
                subs.CourseId = (int)EnumMembership.Trial;
                subs.CourseType = (int)EnumCourseType.Membership;
                subs.SubscribeDate = DateTime.Now;
                subs.ExpiryDate = DateTime.Now.AddDays(7);
                subs.IsActive = true;
                subs.VideoAccess = 0;
                subs.SubscriptionType = false;
                return UOF.IAdminMaster.AddMemberSubscribedDetails(subs);
            }
            return 0;
        }

        private int AssisgnOneMonthMembership(Int64 memberId, string Email, string PassId)
        {
            int subsId = UOF.IMember.GetMembershipDetails(memberId).MembershipId;
            if (subsId > 0)
            {
                ModelState.AddModelError("", "You are already a subscribed member. You can't redeem pass!");
            }
            else
            {
                CourseSubscriptionMemberDTO subs = new CourseSubscriptionMemberDTO();
                subs.MemberId = memberId;
                subs.Email = Email;
                subs.TrainingModeId = (int)EnumTrainingMode.SelfPlaced;
                subs.CourseId = (int)EnumMembership.Monthly;
                subs.CourseType = (int)EnumCourseType.Membership;
                subs.SubscribeDate = DateTime.Now;
                subs.ExpiryDate = DateTime.Now.AddDays(30);
                subs.IsActive = true;
                subs.VideoAccess = 0;
                subs.SubscriptionType = false;
                return UOF.IAdminMaster.RedeemPass(subs, PassId);
            }
            return 0;
        }

        [HttpPost]
        [Route("~/free-trial")]
        public ActionResult FreeTrial(MemberDTO model, bool IsRegistered)
        {
            if (IsRegistered)
            {
                MemberDTO member = UOF.IMember.AuthenticateMember(model.Email, model.Password);
                if (member != null)
                {
                    if (member.IsVerified != true)
                    {
                        ModelState.AddModelError("", "The member account is not verified. Please verify you account.");
                        return View();
                    }
                    else if (member.IsActive != true)
                    {
                        ModelState.AddModelError("", "The member account is de-activated. Please contact website administrator.");
                        return View();
                    }
                    else
                    {
                        //assigning membership
                        member.MembershipId = AssisgnTrialMembership(member.MemberId);

                        if (member.MembershipId > 0)
                        {
                            GenerateTicket(member);
                            TempData["IsRegistered"] = "true";
                            return RedirectToAction("TrialStarted", "Account");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "The Email or Password provided is incorrect!");
                    return View();
                }
            }
            else
            {
                //Check already existing email
                bool isMemberEmailAlreadyExists = UOF.IMember.Check_Member_Email_Already_Exists(model.Email);
                if (isMemberEmailAlreadyExists == true)
                {
                    ModelState.AddModelError("", "Email Id already registered. Please use option registered user.");
                    return View();
                }
                else
                {
                    MemberDTO member = UOF.IMember.MemberRegistration(model, false);
                    try
                    {
                        //do pass only member instance
                        bool mailStatus = MailClient.SendMail_ConfirmMemberRegistrationEmail(member);
                        if (mailStatus == true)
                        {
                            //assigning membership
                            member.MembershipId = AssisgnTrialMembership(member.MemberId);
                            int? totalSentMailCount = UOF.IMember.IncreaseMailSentCounter(member.MemberId);
                            TempData["IsRegistered"] = "false";
                            return RedirectToAction("TrialStarted", "Account");
                        }
                    }
                    catch (Exception ex) { }
                }
            }
            return View();
        }

        public ActionResult UnAuthorized()
        {
            return View();
        }

        [Route("~/member-registration-pending")]
        public ActionResult MemberRegistration()
        {
            return View();
        }

        [Route("~/event-registration-successful")]
        public ActionResult EventMemberRegistration()
        {
            return View();
        }

        public ActionResult ConfirmMemberRegistration(string encaml)
        {
            //string _email = AESEncription.Decryptstring(encaml);
            bool result = UOF.IMember.VerifyMemberAccountEmail(encaml);
            if (result == true)
            {
                return RedirectToAction("SuccessfullyRegister", "Account");
            }
            else
            {
                return PartialView("~/Views/Shared/_Message.cshtml");
            }
        }

        [Route("~/member-registration-successful")]
        public ActionResult SuccessfullyRegister()
        {
            return View();
        }

        [HttpGet]
        [Route("~/forgot-password")]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [Route("~/forgot-password")]
        public ActionResult ForgotPassword(ForgotPasswordHistory model)
        {
            try
            {
                bool result = UOF.IMember.IsMemberEmailExists(model.EmailId);
                if (result == true)
                {
                    //add data
                    string resetUrl = UOF.ICommonLogic.AddForgotPasswordData(model);
                    if (!string.IsNullOrEmpty(resetUrl))
                    {
                        bool status = MailClient.SendMail_ResetPassword(model, resetUrl);
                        if (status == true)
                        {
                            return RedirectToAction("PasswordResetLinkSent", "Account");
                        }
                        else
                        {
                            return PartialView("~/Views/Shared/_Message.cshtml");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "This email address is not registered with us!");
                    return View();
                }
            }
            catch (Exception ex)
            {
                // Elmah.ErrorSignal.FromCurrentContext().Raise(ex);
            }
            return View();
        }

        [Route("~/password-reset-link-sent")]
        public ActionResult PasswordResetLinkSent()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ResetPassword(string repeml)
        {
            try
            {
                var detail = UOF.IMember.ValidateForgotPasswordRequest(repeml);
                if (!string.IsNullOrEmpty(detail.EmailId))
                {
                    DateTime otherDate = detail.RequestedDate.AddMinutes(30);//link expiry time 30 min
                    ResetPasswordDTO model = new ResetPasswordDTO();
                    model.EmailId = detail.EmailId;
                    model.EncryptedKey = repeml;
                    if (otherDate >= DateTime.Now)
                    {
                        ViewBag.expire = true;
                    }
                    else { ViewBag.expire = false; }
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ForgotPassword", "Account");
                }
            }
            catch (Exception)
            { }
            return View();
        }

        [HttpPost]
        public ActionResult ResetPassword(ResetPasswordDTO model)
        {
            bool status = UOF.IMember.ResetPassword(model);
            if (status == true)
            {
                return RedirectToAction("PasswordResetSuccessfully", "Account");
            }
            else
            {
                return PartialView("~/Views/Shared/_Message.cshtml");
            }
        }

        [Route("~/password-reset-successfully")]
        public ActionResult PasswordResetSuccessfully()
        {
            return View();
        }

        [Route("~/password-changed-successfully")]
        public ActionResult PasswordChangedSuccessfully()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ResetMemberPassword(string encaml)
        {
            ResetMemberPasswordDTO model = UOF.IMember.VerifyMemberAccountEmailByAdmin(encaml);
            if (model != null)
            {
                return View(model);
            }
            else
            {
                ViewBag.Message1 = "The resource you are looking for is not available.";
            }
            return View();
        }

        [HttpPost]
        public ActionResult ResetMemberPassword(ResetMemberPasswordDTO model)
        {
            bool result = UOF.IMember.ActivateMember(model);
            if (result == true)
            {
                ViewBag.Message = "Your password has been reset successfully.";
                ModelState.Clear();
            }
            return View();
        }

        public ActionResult DownloadSyllabus(int CourseId = 0, string Url = "")
        {
            try
            {
                if (CourseId == 0)
                {
                    ViewBag.DCourseId = CourseId;
                    ViewBag.DocumentUrl = Url;
                    return PartialView("_Downloadsyllabus");
                }
                var DocumentUrl = UOF.IDocument.GetAll().Where(d => d.CourseId == CourseId && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();
                ViewBag.DCourseId = CourseId;
                ViewBag.DocumentUrl = DocumentUrl;
                return PartialView("_Downloadsyllabus");
            }
            catch (Exception ex)
            {
                ViewBag.DocumentUrl = null;
            }
            return null;
        }

        public void ClearCookie(string CookieName)
        {
            if (System.Web.HttpContext.Current.Request.Cookies[CookieName] != null)
            {
                HttpCookie aCookie = System.Web.HttpContext.Current.Request.Cookies[CookieName];
                aCookie.Expires = DateTime.Now.AddDays(-10);
                aCookie.Value = "";
                //aCookie.Domain = System.Configuration.ConfigurationManager.AppSettings.Get("CookieDomain");
                System.Web.HttpContext.Current.Response.Cookies.Add(aCookie);
            }
        }

        public void ClearAllCookie()
        {
            try
            {
                HttpCookie aCookie;
                string cookieName;
                int limit = System.Web.HttpContext.Current.Request.Cookies.Count;
                for (int i = 0; i < limit; i++)
                {
                    cookieName = System.Web.HttpContext.Current.Request.Cookies[i].Name;
                    //if (cookieName == "dntgurusite")
                    //    continue;

                    aCookie = new HttpCookie(cookieName);
                    aCookie.Expires = DateTime.Now.AddDays(-10);
                    aCookie.Value = "";
                    //  aCookie.Domain = ConfigurationManager.AppSettings.Get("CookieDomain");
                    System.Web.HttpContext.Current.Response.Cookies.Add(aCookie);
                }
            }
            catch (Exception exc)
            {
            }
        }



        [HttpPost]
        public ActionResult ExternalLogin(ExternalLoginDto modelData, string ReturnUrl)
        {

            bool isMemberEmailAlreadyExists = UOF.IMember.Check_Member_Email_Already_Exists(modelData.Email);
            if (isMemberEmailAlreadyExists == true)
            {
                MemberDTO model = UOF.IMember.GetMember(modelData.Email);
                if (model != null)
                {
                    GenerateTicket(model);
                    return Json("Exist", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("Error", JsonRequestBehavior.AllowGet);
                }
                //return RedirectToAction("Index", "Dashboard", new { area = "Member" });
            }
            else
            {
                if (!string.IsNullOrEmpty(modelData.Email) && !string.IsNullOrEmpty(modelData.Name))
                {
                    MemberDTO memberDto = new MemberDTO();
                    memberDto.Name = modelData.Name;
                    memberDto.Email = modelData.Email;
                    memberDto.ProfilePic = modelData.ProfilePic;
                    memberDto.ProviderName = modelData.ProviderName;
                    memberDto.Password = "Password@1";// Default Password for External Login

                    MemberDTO model = UOF.IMember.MemberRegistration(memberDto, true);
                    if (model != null)
                    {
                        GenerateTicket(model);
                        return Json("New", JsonRequestBehavior.AllowGet);
                        // return RedirectToAction("Index", "Dashboard", new { area = "Member" });
                    }
                    else
                    {
                        return Json("Error", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("Error", JsonRequestBehavior.AllowGet);
                }
            }

        }


    }
}
