﻿using DNTWebUI.Models;
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;

namespace DNTWebUI.Controllers
{
    public class IDEController : ApiController
    {
        HttpClient client;
        public CustomPrincipal CurrentUser => HttpContext.Current.User as CustomPrincipal;

        public IDEController()
        {
            client = new HttpClient();
        }

        private IHttpActionResult RunCode(CodeModel model, string apiAddress)
        {
            string data = JsonConvert.SerializeObject(model);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            var response = client.PostAsync(apiAddress + "/main", content).Result;
            if (response.IsSuccessStatusCode)
            {
                if (model.language == "csharp")
                {
                    string[] result = JsonConvert.DeserializeObject<string[]>(response.Content.ReadAsStringAsync().Result);
                    return Ok(result);
                }
                else
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    return Ok(result);
                }
            }
            else
            {
                return Ok("");
            }
        }

        [HttpPost]
        public IHttpActionResult Main(CodeModel model)
        {
            if (CurrentUser != null)
                model.file = CurrentUser.UserId.ToString();
            else
                model.file = "output";

            switch (model.language)
            {
                case "csharp":
                    if (model.code.Contains("Console.Read"))
                        return Ok("You are not allowed to use any console input methods like Read(), ReadLine() and ReadKey() etc.");
                    else
                        return RunCode(model, IDEUtility.CSharpApi);
                case "python":
                    return RunCode(model, IDEUtility.PythonApi);
                case "javascript":
                case "typescript":
                    return RunCode(model, IDEUtility.JavaScriptApi);
                default:
                    return Ok("");
            }
        }
    }
}
