﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared.DTO;
using DNTWebCore;
using DNTWebCore.Enum;
using DNTShared.Entities;
using DNTWebUI.Models.Security;
using DNTData;

namespace DotNetTricks.COM.Controllers
{
    public class ChildActionController : BaseController
    {
        //cache categorylist
        protected IEnumerable<CategoryDTO> GetCategories()
        {
            string key = "categorylist";
            var cachedata = CacheService.GetCacheList<CategoryDTO>(key);
            if (cachedata == null)
            {
                IEnumerable<CategoryDTO> data = UOF.ICommonLogic.GetArticleCategoriesForMenu();
                cachedata = CacheService.SetCacheList<CategoryDTO>(key, data, (int)CacheDuration.FullDay);
            }
            return cachedata.ToList();
        }

        [ChildActionOnly]
        public ActionResult Category(int id = 0)
        {
            return PartialView("_Category", GetCategories());
        }

        [ChildActionOnly]
        public ActionResult MenuCategory()
        {
            return PartialView("_CatergoriesMenu", GetCategories());
        }

        [ChildActionOnly]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult RecentArticles()
        {
            var data = UOF.ICommonLogic.GetRecentArticles();
            return PartialView("_Recent", data);
        }

        [ChildActionOnly]
        [HttpGet]
        // [OutputCache(Duration = (int)CacheDuration.OneHour)]
        public ActionResult NewsForAds()
        {
            try
            {
                IndexDisplayDataDTO model = this.GetIndexDisplayData();
                return PartialView("_NewsForAds", model);
            }
            catch (Exception e)
            {

            }
            return null;
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.OneHour)]
        public ActionResult StickyFooter()
        {
            return PartialView("_StickyFooter");
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult LatestNewsNotify()
        {
            IndexDisplayDataDTO model = this.GetIndexDisplayData();

            TempData["TotalNewsCount"] = model.newsList.Count.ToString();
            TempData["UpcomingBatches"] = model.UpcomingBatches;
            TempData["JobOpenings"] = model.JobOpenings;
            return PartialView("_LatestNewsNotify", model);
        }

        [Route("CourseDetails/{url}")]
        // [OutputCache(Duration = (int)CacheDuration.FullDay, VaryByParam = "url")]
        public ActionResult CourseDetails(string url)
        {
            url = "/training/" + url;
            CourseDTO model = UOF.ICommonLogic.GetCourseDataDetails(url, "USD");
            ViewBag.CourseId = model.CourseId;
            return PartialView("_CourseDetails", model);
        }

        [HttpGet]
        [ChildActionOnly]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult bookList()
        {
            IEnumerable<BookMasterDTO> model = UOF.IBookMasters.GetAllBookList();
            return PartialView("_bookList", model);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult StepByStepMenu()
        {
            List<CategoryDTO> StepbyStepList = UOF.ICommonLogic.GetStepByStepMenuList();
            return PartialView("_StepByStepMenu", StepbyStepList);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult PopUpAds()
        {
            var url = Request.RequestContext.HttpContext.Request.RawUrl;
            AdsPopUpMaster model = UOF.ICommentMaster.GetAdsPopUpMasterDetail(url);
            return PartialView("_PopUpAds", model);
        }

        [HttpPost]
        public JsonResult GetCourseDetailsCariList(MaterCourseCurriculum d)
        {
            try
            {
                List<MaterCourseCurriculum> data = new List<MaterCourseCurriculum>();
                if (d.CourseId > 0)
                {
                    data = UOF.ICourse.GetSubCourseDetailsList(d.CourseId);

                    if (data != null)
                    {
                        return Json(data, JsonRequestBehavior.AllowGet);
                    }
                    return Json(false, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ModalDemo(int CourseId = 0, string Url = "")
        {
            try
            {
                ViewBag.DCourseId = CourseId;
                return PartialView("_DemoVedioEnquiry");
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        [ChildActionOnly]
        [HttpGet]

        // [OutputCache(Duration = (int)CacheDuration.OneHour)]
        public ActionResult _StaticCoursesPriceList()
        {
            var currency = "USD";
            ViewBag.Currency = currency;
            string key = "categorylist" + currency;
            ViewBag.CoursePriceList = UOF.ICommonLogic.GetAllCoursePriceList(currency, 10);
            return PartialView("_StaticCoursesPriceList");
        }


        [ChildActionOnly]
        public ActionResult LocalCourseEnquiry(int id = 0, string type = "", int mode = 0, int EnquiryType = 0)
        {
            QueryDTO queryModel = new QueryDTO();
            ////Bind Courses
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            queryModel.CourseList = courseList;
            queryModel.CourseId = id;
            ViewBag.Type = type;
            ViewBag.EnquiryType = EnquiryType;
            queryModel.EnquiryTypeId = EnquiryType;
            queryModel.TrainingModeId = mode;
            //Bind Training Mode
            List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
            queryModel.TrainingModeList = trainingModeList;
            //Subject
            queryModel.Subject = type + "- Course Page";

            return PartialView("_LocalCourseEnquiry", queryModel);
        }

        [HttpPost]
        public JsonResult SaveLocalEnquiry(QueryDTO model)
        {
            try
            {
                int quid = 0;
                if (model.ID == 0)
                {
                    quid = UOF.IQuery.SavePPCQuery(model);
                }
                else
                {
                    quid = UOF.IQuery.UpdatePPCQuery(model);
                }

                ModelState.Clear();
                if (quid > 0)
                {
                    MailClient.SendMail_PPCEnquiry(model);
                    return Json(new { msg = "done", quid }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
    }
}
