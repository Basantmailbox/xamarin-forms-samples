﻿using DotNetTricks.COM.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared.DTO;
using DNTData;
using DNTWebUI.Models.Security;
using DNTShared.Entities;
using Newtonsoft.Json;

namespace DNTWebUI.Controllers
{
    public class ShoppingCartController : BaseController
    {
        [TimeZoneFliter]
        // GET: ShoppingCard
        [Route("cart")]
        public ActionResult Index()
        {
            try
            {
                Session["DiscountMaster"] = null;

                if (CurrentUser != null)
                {
                    var Currency = Session["currency"].ToString();
                    ViewBag.Currency = Currency;
                    var model = UOF.ICommonLogic.GetShoppingCartDTO((int)CurrentUser.UserId, Currency);
                    if (TempData["Discount"] != null)
                    {
                        ViewBag.CouponCode = TempData["CouponCode"];
                        ViewBag.Discount = TempData["Discount"];
                        DiscountMasterDTO disc = (DiscountMasterDTO)TempData["DiscountMaster"];
                        ViewBag.DiscountMaster = TempData["DiscountMaster"];
                        if (disc.CouponApplied == true)
                        {
                            if (disc.Discount.DiscountTypeId == 2)
                            {
                                foreach (var item in model)
                                {
                                    if (disc.Discount_AppliedToCourse.Any(p => p.CourseId == item.CourseId))
                                    {
                                        if (disc.Discount.DiscountPercentage < 100)
                                        {
                                            var discount = (item.NetPrice * disc.Discount.DiscountPercentage) / 100;

                                            if (discount < disc.Discount.MaximumDiscountAmount)
                                            {

                                                item.NetPrice = item.NetPrice - discount;
                                                item.TotalDiscountPercentageAmount = discount;
                                                item.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                                                item.DiscountId = disc.Discount.Id;
                                                item.CouponCode = disc.Discount.CouponCode;
                                                var totaldisc = item.Price - item.NetPrice;
                                                item.DiscountPercentage = (totaldisc / item.Price) * 100;
                                            }

                                            else
                                            {
                                                item.NetPrice = item.NetPrice - disc.Discount.MaximumDiscountAmount;
                                                item.TotalDiscountPercentageAmount = disc.Discount.MaximumDiscountAmount;
                                                item.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                                                item.DiscountId = disc.Discount.Id;
                                                item.CouponCode = disc.Discount.CouponCode;
                                                var totaldisc = item.Price - item.NetPrice;
                                                item.DiscountPercentage = (totaldisc / item.Price) * 100;
                                            }
                                        }
                                        else
                                        {
                                            item.TotalDiscountPercentageAmount = item.NetPrice;
                                            item.NetPrice = 0;
                                      
                                            item.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                                            item.DiscountId = disc.Discount.Id;
                                            item.CouponCode = disc.Discount.CouponCode;
                                            var totaldisc = item.Price;
                                            item.DiscountPercentage = 100;


                                        }
                                    }
                                }
                            }
                            Session["DiscountMaster"] = TempData["DiscountMaster"];
                        }
                    }
                    return View(model);
                }
            }
            catch (Exception e)
            {
            }
            return View();
        }

        [Route("cart/addItem")]
        public JsonResult AddToCart(int? CourseId, int? CourseType, int? Quantity)
        {
            ShoppingCart cart = UOF.ICommonLogic.AddItemToShoppingCartDTO(CourseId.Value, CourseType.Value, (int)CurrentUser.UserId, Quantity.Value);

            var result = JsonConvert.SerializeObject(cart, Formatting.Indented,
                              new JsonSerializerSettings
                              {
                                  ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                              });

            return Json(new { result }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Coupon(FormCollection collection)
        {

            string var1 = collection["var1"];
            //  List<ShoppingCartDTO> Cart = (List<ShoppingCartDTO>)Session["ShoppingCartDTO"];
            var Currency = Session["currency"].ToString();
            ViewBag.Currency = Currency;
            var model = UOF.ICommonLogic.GetShoppingCartDTO((int)CurrentUser.UserId, Currency);
            DiscountMasterDTO disc = UOF.ICommonLogic.DiscountAppliedCart(var1, Currency, model);

            TempData["CouponCode"] = var1;
            TempData["Discount"] = true;
            TempData["DiscountMaster"] = disc;


            return RedirectToAction("Index");
        }
        
        [HttpPost]
        public ActionResult RemoveCoupon(FormCollection collection)
        {

            string var1 = collection["var1"];
            return RedirectToAction("Index");
        }
        
        [HttpPost]
        public ActionResult DeleteItemCart(int id)
        {
            try
            {
                bool status = UOF.ICommonLogic.DeleteItemInCart(id);

                if (status == true)
                {
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        [Route("cart/checkout")]
        public ActionResult Checkout()
        {
            try
            {
                if (CurrentUser != null && Session["ShoppingCartDTO"] != null)
                {
                    TempData["flag"] = "true";
                    var Currency = Session["currency"].ToString();
                    DiscountMasterDTO disc = null;
                  
                    List<ShoppingCartDTO> Cart = (List<ShoppingCartDTO>)Session["ShoppingCartDTO"];
                    if (Session["DiscountMaster"] != null)
                    { disc = (DiscountMasterDTO)Session["DiscountMaster"]; }

                    if (Cart.Count != 0)
                    {

                        int id = Cart[0].CourseId;
                        int ctype = Cart[0].CourseType;
                        //   CoursePrice obj = UOF.ICommonLogic.GetCoursePrice(id, ctype);
                        PaymentMasterDTO_V1 PaymentMaster = new PaymentMasterDTO_V1();
                        ViewBag.Currency = Currency;
                        PaymentMaster.ShoppingCartDataID = Cart[0].ShoppingCartDataID;
                        PaymentMaster.Payments = new List<PaymentDTO_V1>();
                        PaymentMaster.CouponCode = disc != null ? disc.Discount.CouponCode : "";
                        foreach (var item in Cart)
                        {
                            PaymentDTO_V1 model = new PaymentDTO_V1();
                            model.CourseId = item.CourseId;
                            model.Name = item.name;
                            model.Price = item.Price;
                            model.IsOnSale = item.IsOnSale;
                            model.SalePercentage = item.SalePercentage;
                            model.SaleOffAmount = item.SaleOffAmount;
                            model.AfterSale = item.AfterSale;
                            model.NetPrice = item.NetPrice;
                            model.TotalDiscountPercentageAmount = item.TotalDiscountPercentageAmount;
                            model.TotalDiscountPercentage = item.TotalDiscountPercentage;
                            model.DiscountId = item.DiscountId;
                            model.CouponCode = item.CouponCode;
                            model.CourseType = item.CourseType;
                            PaymentMaster.DiscountId = item.DiscountId;
                            PaymentMaster.Price += item.Price;
                            PaymentMaster.NetPrice += item.NetPrice;
                            PaymentMaster.Payments.Add(model);
                        }

                        if (disc != null)
                        {
                            if (disc.CouponApplied == true && disc.Discount_AppliedToCourse == null && disc.Discount != null)
                            {
                                  if (disc.Discount.DiscountPercentage < 100)
                                {                                 
                                
                                var disco = (PaymentMaster.NetPrice * disc.Discount.DiscountPercentage) / 100;
                                if (disco < disc.Discount.MaximumDiscountAmount)
                                {
                                    PaymentMaster.NetPrice = PaymentMaster.NetPrice - disco;
                                    PaymentMaster.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                                    PaymentMaster.TotalDiscountPercentageAmount = disco;
                                    PaymentMaster.Discount_Applied = true;
                                }
                                else
                                {
                                    PaymentMaster.NetPrice = PaymentMaster.NetPrice - disc.Discount.MaximumDiscountAmount;
                                    PaymentMaster.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                                    PaymentMaster.TotalDiscountPercentageAmount = disc.Discount.MaximumDiscountAmount;
                                    PaymentMaster.Discount_Applied = true;
                                }
                            }
                                else
                                {
                                    PaymentMaster.TotalDiscountPercentageAmount = PaymentMaster.NetPrice;
                                    PaymentMaster.NetPrice = 0;
                                    PaymentMaster.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                                   
                                    PaymentMaster.Discount_Applied = true;

                                }

                        }
                            if (disc.Discount.DiscountPercentage >= 100 && PaymentMaster.NetPrice <= 0)
                            {
                                PaymentMaster.TotalDiscountPercentageAmount = PaymentMaster.NetPrice;
                                PaymentMaster.NetPrice = 0;
                                PaymentMaster.TotalDiscountPercentage = disc.Discount.DiscountPercentage;
                            }
                                PaymentMaster.DiscountId = disc.Discount.Id;

                        }
                     
                        else
                        {
                            PaymentMaster.TotalDiscountPercentage = 0;
                            PaymentMaster.TotalDiscountPercentageAmount = 0;

                        }
                        if (Currency == "INR")
                        {
                            PaymentMaster.ServiceTaxPercentage = TaxUtility.TaxValue;
                            PaymentMaster.ServiceTax = Math.Round((PaymentMaster.NetPrice * TaxUtility.TaxValue) / 100);
                            PaymentMaster.Total = Math.Round(PaymentMaster.ServiceTax + PaymentMaster.NetPrice);
                            PaymentMaster.TotalSaving = PaymentMaster.Price - PaymentMaster.NetPrice;
                        }
                        else
                        {
                            PaymentMaster.ServiceTax = 0;
                            PaymentMaster.Total = Math.Round(PaymentMaster.NetPrice);
                            PaymentMaster.TotalSaving = PaymentMaster.Price - PaymentMaster.NetPrice;

                        }
                        TempData["PaymentModel"] = PaymentMaster;
                        ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                        return View(PaymentMaster);

                    }
                    else
                    {
                        return RedirectToAction("InstructorledCourses", "Home");
                    }

                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public JsonResult CheckoutState(string StateCode)
        {
            try
            {
                if (CurrentUser != null && Session["ShoppingCartDTO"] != null)
                {
                    TempData["flag"] = "true";
                    var Currency = Session["currency"].ToString();

                    var tax = UOF.IAdminMaster.getTaxRateCode(StateCode);
                    var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                    PaymentMasterDTO_V1 PaymentMaster = (PaymentMasterDTO_V1)Session["ShoppingCartDTO"];
                    PaymentMaster.CGSTPercent = 0;
                    PaymentMaster.IGSTPercent = 0;
                    PaymentMaster.SGSTPercent = 0;
                    PaymentMaster.CGST = 0;
                    PaymentMaster.SGST = 0;
                    PaymentMaster.IGST = 0;
                    PaymentMaster.RoundOff = 0;
                    PaymentMaster.Total = PaymentMaster.Total;
                    if (GSTDNT==StateCode)
                    {
                        PaymentMaster.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                        PaymentMaster.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();
                        PaymentMaster.CGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.CGSTPercent) / 100,2);
                        PaymentMaster.SGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.SGSTPercent) / 100,2);
                        PaymentMaster.Price = Math.Round(PaymentMaster.NetPrice + PaymentMaster.CGST + PaymentMaster.SGST,2);
                    }
                    else
                    {
                        PaymentMaster.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                        PaymentMaster.IGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.IGSTPercent) / 100,2);
                        PaymentMaster.Price = Math.Round((PaymentMaster.NetPrice + PaymentMaster.IGST),2);    
                    }

                    if (PaymentMaster.Total > PaymentMaster.Price)
                    {
                        PaymentMaster.RoundOff = PaymentMaster.Total - PaymentMaster.Price;
                    }
                    else if (PaymentMaster.Total < PaymentMaster.Price)
                    {
                        PaymentMaster.RoundOff =  PaymentMaster.Price - PaymentMaster.Total;
                    }
                    
                    TempData["PaymentModel"] = PaymentMaster;
                    ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                    return Json(PaymentMaster, JsonRequestBehavior.AllowGet);
                }
                else { return Json(false, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception e)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        
        public ActionResult GetCartDetails()
        {
            try
            {
                if (CurrentUser != null)
                {
                    var currency = Session["currency"].ToString();
                    var model = UOF.ICommonLogic.GetShoppingCartDTO((int)CurrentUser.UserId, currency);
                    return Json(model, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception e)
            {
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
    }
}