﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTData;
using DNTShared;
using DNTShared.DTO;
using DNTWebCore;
using System.Globalization;

namespace DotNetTricks.COM.Controllers
{
    public class TutorialController : Controller
    {
        public const int PageSize = 15;
        public string _baseUrl = string.Empty;
        IUnitOfWork UOF;

        public TutorialController()
        {
            UOF = new UnitOfWork();
            _baseUrl = WebConfigSetting.BaseURL;
            ViewBag.StepbyStepList = UOF.ICommonLogic.GetStepByStepMenuList();
        }
        private StepTutorialDTO GetTutorial(string subcat, string cat)
        {
            StepTutorialDTO tutorial = new StepTutorialDTO();
            ViewBag.Title = "Step By Step Tutorial";
            ViewBag.SubTitle = "Step By Step Tutorial";
            if (cat == "csharp")
                cat = "c#";
            if (subcat != null)
            {
                var q = UOF.ITutorial.GetAllDetailTutorial(subcat, cat);
                if (!string.IsNullOrEmpty(q.ID))
                {
                    long count = 0;
                    ViewBag.Title = q.TutorialSubCategoryName + " | " + q.TutorialTitle;
                    ViewBag.SubTitle = q.TutorialTitle;
                    tutorial.Title = q.TutorialSubCategoryName;
                    tutorial.CategoryID = Convert.ToInt32(q.CategoryID);
                    tutorial.Description = q.Description;
                    tutorial.PostedBy = q.PostedBy;
                    tutorial.strPostedDate = Convert.ToDateTime(q.PostedDate).ToString("dd MMM yyyy");
                    tutorial.strUpdatedDate = q.UpdatedDate != null ? Convert.ToDateTime(q.UpdatedDate).ToString("dd MMM yyyy") : "";
                    tutorial.MetaKeywords = q.MetaKeywords;
                    tutorial.Version = q.Version;

                    //ViewBag.Canonical = tutorial.Url = q.Url + "/" + q.ID + "-" + q.Title.ToLower().Replace(' ', '-') + ".html";
                    ViewBag.Keywords = q.MetaKeywords;
                    tutorial.DomainName = q.DomainName;
                    if (!string.IsNullOrEmpty(q.ShortDescription))
                    {
                        string str = q.ShortDescription.Remove(0, 3);
                        ViewBag.Description = str.Remove(str.IndexOf('<'), 4);
                    }
                    else
                    {
                        ViewBag.Description = "";
                    }
                    if ((bool)RouteData.Values["IsRefreshed"] == false)
                    {
                        var t = UOF.IStepTutorial.GetById(q.ID).FirstOrDefault();
                        if (t != null)
                        {
                            t.TotalViews = t.TotalViews + 1;
                            UOF.ITutorial.SaveTotalViews(t.TutorialID, (long)t.TotalViews);
                            count = (long)t.TotalViews;
                        }
                    }
                    tutorial.TotalViews = count > 0 ? count : q.TotalViews;
                    return tutorial;
                }
                else
                    return null;
            }
            else
                return null;
        }
          
        [ChildActionOnly]
        public ActionResult TutorialMenu()
        {
            string[] strUrl = Request.Url.AbsolutePath.ToString().Split('/');
            string cat = strUrl.Length > 3 ? strUrl[3].ToString() : string.Empty;
            string SelectSubcat = strUrl.Length > 4 ? strUrl[4].ToString() : "all";
            StepTutorialMenuDTO tutorial = UOF.ITutorial.Gettutorailmenu(cat, SelectSubcat);
            if (tutorial != null)
            {
                return PartialView("_TutorialMenu", tutorial);
            }
            return PartialView("_TutorialMenu", null);
        }

        [ChildActionOnly]
        public ActionResult Header()
        {
            try
            {
                var currency = "USD";

                var defaultzone = "-330";
                if (Session.Count > 0)
                {
                    defaultzone = Session["timezoneoffset"] != null ? Session["timezoneoffset"].ToString() : "-330";

                }


                double minutes2 = Convert.ToDouble(defaultzone);

                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
                var timeOffSet = zone.Id;
                if (timeOffSet == "India Standard Time")
                {
                    RegionInfo ri = new RegionInfo("en-IN");
                    currency = ri.ISOCurrencySymbol;
                    Session["currency"] = currency;
                }
                else
                {
                    RegionInfo ri = new RegionInfo("en-US");
                    currency = ri.ISOCurrencySymbol;
                    Session["currency"] = currency;
                }


                ViewBag.Currency = currency;
                List<CourseCategoryDTO> courseList = UOF.ICommonLogic.GetCategorywiseMenuList();
                return PartialView("_StepByStepHeader", courseList);
            }
            catch (Exception)
            {
                throw;
            }

        }

        [DetectPageRefreshFilter]
        [Route("~/learn/stepbystep/{cat}/{subcat}")]
        public ActionResult Article(string cat, string subcat = "introduction")
        {
            var data = GetTutorial(subcat, cat);
            if (data == null)
            {
                return RedirectToAction("Index");
            }
            else
            {
                if (data.DomainName != _baseUrl)
                {
                    Response.Redirect(data.DomainName + "/learn/stepbystep/" + cat + "/" + subcat);
                }
            }
            return View(data);
        }

        [Route("~/tutorial/{cat}/{url}")] //old articles from www.dotnet-tricks.com
        public ActionResult OldArticle(string cat, string url)
        {           
            var redirectUrl = UOF.ICommonLogic.GetOldArticle(cat, url);
            if (redirectUrl == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                Response.Redirect(_baseUrl + redirectUrl);
            }
            return RedirectToAction("Index", "Home");
        }
    }
}
