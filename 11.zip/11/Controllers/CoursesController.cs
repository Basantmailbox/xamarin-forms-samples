﻿using DNTData;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using Microsoft.WindowsAzure.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class CoursesController : BaseController
    {
        public string ImgCloudPath = "";
        CloudStorageAccount storageAccount;

        public CoursesController()
        {
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
        }
        // GET: Courses
        [Route("~/courses")]
        public ActionResult Index()
        {
            TempData["flag"] = "true";
            return View(UOF.ICommonLogic.GetCategoryWiseSelfPacedCourses());
        }

        [Route("~/courses/technology")]
        public ActionResult Technologies()
        {
            List<CategoryCourseDTO> model = UOF.ICourse.GetCoursesByCategory().ToList();
            return View(model);
        }

        [Route("~/courses/{cat}")]
        public ActionResult CoursesByCategory(string cat)
        {
            string catUrl = "";
            if (!string.IsNullOrEmpty(cat))
                catUrl = "/courses/" + cat.ToLower();

            CategoryDTO model = UOF.ICommonLogic.GetTechnologyCourses(catUrl);

            if (model == null)
            {
                return RedirectToAction("Index", "Courses");
            }
            return View(model);
        }

        [Route("courses/{cat}/{url}")]
        public ActionResult CourseDetails(string cat, string url)
        {
            url = "/courses/" + cat + "/" + url;
            ViewBag.Category = cat.ToLower();
            string catUrl = "";
            if (!string.IsNullOrEmpty(cat))
                catUrl = "/courses/" + cat.ToLower();

            CourseDTO model = UOF.ICommonLogic.GetCourseDataDetails(url, "USD");
            CategoryDTO courses = UOF.ICommonLogic.GetTechnologyCourses(catUrl);

            //getting auto calculated duration
            var duration = courses.CategoryCourses.Where(x => x.CourseId == model.CourseId && x.CourseType == (int)EnumCourseType.SelfPlaced).Select(c => c.Duration).FirstOrDefault();
            if (duration != null)
                model.Duration = duration;

            model.CurPreRecTopiclist = UOF.ICourse.GetCourseVedioDetails(model.CourseId);
            if (courses != null)
            {
                ViewBag.imageUrl = courses.ImageUrl;
                List<CourseDTO> relatedvideos = new List<CourseDTO>();
                var CategortCourse = courses.CategoryCourses.Where(x => x.CourseId != model.CourseId && x.CourseType == (int)EnumCourseType.SelfPlaced).ToList();
                foreach (var item in CategortCourse)
                {
                    var getcoursedetails = UOF.ICommonLogic.GetCourseDataDetails(item.URL, "USD");
                    if (getcoursedetails != null)
                    {
                        relatedvideos.Add(getcoursedetails);
                    }
                }
                model.RelatedVideos = relatedvideos;
            }

            return View(model);
        }

        [Route("~/player/{cat}/{url}/{subTopicId:int?}")]
        public ActionResult Player(string cat, string url, int? subTopicId = 0)
        {
            url = "/courses/" + cat + "/" + url;
            string encUrl = AESEncription.Base64Encode(url);

            HttpCookie cookie1 = new HttpCookie("d_a", encUrl);
            Response.Cookies.Add(cookie1);

            HttpCookie cookie2 = new HttpCookie("s_id", Convert.ToString(subTopicId));
            Response.Cookies.Add(cookie2);

            return View();
        }

        [Route("~/player/data")]
        public JsonResult PlayerData()
        {
            try
            {
                //csharp-advanced-concepts
                string value = Request.Cookies.Get("d_a") != null ? Request.Cookies.Get("d_a").Value : "";
                string url = value == "" ? "/courses/angular/angular-fundamentals" : AESEncription.Base64Decode(value);

                PlayerDTO model = new PlayerDTO();
                if (CurrentUser != null)
                {
                    model = UOF.ICourse.GetPlayerDetails(url, CurrentUser.UserId);
                }
                else
                {
                    model = UOF.ICourse.GetPlayerDetails(url);
                }
                //set model values after setting player data
                model.CourseUrl = url;
                if (CurrentUser != null)
                {
                    model.UserId = CurrentUser.UserId;
                    model.MembershipId = CurrentUser.MembershipId;
                    if (CurrentUser.MembershipId == 0 || CurrentUser.MembershipExpiry <= DateTime.Now)
                    {
                        var membership = UOF.IMember.GetMembershipDetails(CurrentUser.UserId);
                        model.MembershipId = membership.ExpiryDate >= DateTime.Now ? membership.MembershipId : 0;
                    }
                }
                else
                {
                    model.UserId = 0;
                    model.MembershipId = 0;
                }

                string subTopicId = Request.Cookies.Get("s_id") != null ? Request.Cookies.Get("s_id").Value : "0";
                if (subTopicId != "0")
                {
                    model.SubTopicId = Convert.ToInt64(subTopicId);
                }
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }
        }

        [Route("~/paths/{url}")]
        public ActionResult PathDetails(string url)
        {
            ViewBag.CourseURL = url;
            url = "/paths/" + url;

            CourseDTO model = UOF.ICommonLogic.GetPathDetails(url);

            if (model == null)
            {
                return RedirectToAction("Index", "Courses");
            }

            ViewBag.cid = model.CourseId;
            return View(model);
        }

        [Route("~/roadmap")]
        public ActionResult Roadmap()
        {
            List<Course> model = UOF.ICourse.GetUpcomingCourses().ToList();
            return View(model);
        }

        public ActionResult GetDropDown(int CategoryId)
        {
            List<DropDownDTO> data = UOF.ICourse.GetDropDown(CategoryId, true);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetDropDownByCategory(int CategoryId)
        {
            List<DropDownDTO> data = UOF.ICourse.GetDropDown(CategoryId, true);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
    }
}