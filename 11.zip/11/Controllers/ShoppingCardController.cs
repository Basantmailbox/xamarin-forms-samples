﻿using DotNetTricks.COM.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNTWebUI.Controllers
{
    public class ShoppingCardController : BaseController
    {
        // GET: ShoppingCard
        public ActionResult Index()
        {
            if (CurrentUser != null)
            {
                var model = UOF.ICommonLogic.GetShoppingCartDTO((int)CurrentUser.UserId);
            return View(model); }

            return View();
        }
    }
}