﻿using DotNetTricks.COM.PaymentGateway;
using DNTData;
using System;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;
using DNTShared.DTO;
using DNTShared.Entities;
using System.Collections.Generic;
using System.Linq;
using DNTShared;
using System.Web.Security;
using System.Web;

namespace DotNetTricks.COM.Controllers
{
    public class PaymentController : BaseController
    {
        string msgTryAgain = "<style>*{padding:0;margin:0;}</style><div style='border-top: 4px solid #2196F3;margin:0 px;'><center><div style='padding:5px; font-size:12px;text-align:center;width:120px;background-color:#2196F3;border-bottom-left-radius:6px;border-bottom-right-radius:6px;font-family: Arial, Helvetica, sans-serif;color:#fff'><a href='/'style='color: #fff;text-decoration: none;'>Please try again after login!</a></div></center></div>";

        private string Generatehash512(string text)
        {
            byte[] message = Encoding.UTF8.GetBytes(text);
            UnicodeEncoding UE = new UnicodeEncoding();
            byte[] hashValue;
            SHA512Managed hashString = new SHA512Managed();
            string hex = "";
            hashValue = hashString.ComputeHash(message);
            foreach (byte x in hashValue)
            {
                hex += String.Format("{0:x2}", x);
            }
            return hex;
        }

        private string GenerateUniqueNo()
        {
            DateTime date = DateTime.Now;
            string uniqueID = String.Format("{0:0000}{1:00}{2:00}{3:00}{4:00}{5:00}{6:000}", date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second, date.Millisecond);
            return uniqueID.Substring(2, uniqueID.Length - 2); //15 digit number : 171014072704579
        }

        [Route("~/pro-membership")]
        public ActionResult PricingDetails()
        {
            var source = Request.QueryString["s"];
            var code = Request.QueryString["c"];
            if (source != null)
            {
                Session["URLSource"] = source;
            }
            if (code != null)
            {
                Session["ReferralCode"] = code;
            }

            TempData["flag"] = "true";
            ViewBag.MonthlyPrice = UOF.ICommonLogic.GetCoursePricesSelf((int)EnumMembership.Monthly, "USD");
            ViewBag.HalfYearlyPrice = UOF.ICommonLogic.GetCoursePricesSelf((int)EnumMembership.Halfyearly, "USD");
            ViewBag.YearlyPrice = UOF.ICommonLogic.GetCoursePricesSelf((int)EnumMembership.Yearly, "USD");
            return View();
        }

        [Route("~/order-summary")]
        public ActionResult Index()
        {
            if (CurrentUser != null)
            {
                if (Session["CourseId"] != null)
                {
                    int id = Convert.ToInt32(Session["CourseId"]);
                    int ctype = Convert.ToInt32(Session["CourseType"]);
                    CoursePrice obj = UOF.ICommonLogic.GetCoursePrice(id, ctype);

                    PaymentDTO model = new PaymentDTO();

                    model.CourseType = ctype;
                    model.CourseId = obj.CourseId;
                    model.CourseName = obj.CourseName;
                    //INR
                    model.TotalINR = obj.NetPriceINR;
                    model.STaxNameINR = TaxUtility.TaxName;

                    model.NetPriceINR = Math.Round(obj.NetPriceINR / (TaxUtility.TaxValue + 100) * 100, 2);
                    model.ServiceTaxINR = Math.Round(model.NetPriceINR * TaxUtility.TaxValue / 100, 2);

                    model.PriceUSD = obj.PriceUSD;
                    model.NetPriceUSD = obj.NetPriceUSD;
                    model.DiscountUSD = obj.DiscountUSD;
                    model.TotalUSD = obj.NetPriceUSD;

                    TempData["PaymentModel"] = model;
                    ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                    return View(model);
                }
                else
                {
                    return RedirectToAction("InstructorledCourses", "Home");
                }
            }
            else
            {
                return RedirectToAction("Login", "Account", new { ReturnUrl = Url.Action("Index", "Payment") });
            }
        }

        [Route("~/orders-summary")]
        public ActionResult Orders()
        {
            if (CurrentUser != null && CurrentUser.Email != "" && Session["ShoppingCartDTO"] != null)
            {
                List<ShoppingCartDTO> Cart = (List<ShoppingCartDTO>)Session["ShoppingCartDTO"];
                if (Cart.Count != 0)
                {
                    // int id = Cart[0].CourseId;
                    // int ctype = Cart[0].CourseType;
                    // CoursePrice obj = UOF.ICommonLogic.GetCoursePrice(id, ctype);

                    PaymentMasterDTO PaymentMaster = new PaymentMasterDTO();
                    PaymentMaster.ShoppingCartDataID = Cart[0].ShoppingCartDataID;
                    PaymentMaster.Payments = new List<PaymentDTO>();
                    PaymentMaster.NetTotalPriceINR = 0;
                    decimal TotalINR = 0;
                    decimal ToTalUSD = 0;
                    foreach (var item in Cart)
                    {
                        PaymentDTO model = new PaymentDTO();
                        model.CourseType = item.CourseType;
                        model.CourseId = item.CourseId;
                        model.CourseName = item.name;
                        //INR
                        model.TotalINR = item.NetPrice;
                        model.STaxNameINR = TaxUtility.TaxName;
                        PaymentMaster.NetTotalPriceINR = PaymentMaster.NetTotalPriceINR + item.NetPrice;
                        model.NetPriceINR = Math.Round(item.NetPrice / (TaxUtility.TaxValue + 100) * 100, 2);
                        model.ServiceTaxINR = Math.Round(model.NetPriceINR * TaxUtility.TaxValue / 100, 2);

                        TotalINR = TotalINR + item.NetPrice;
                        PaymentMaster.Payments.Add(model);
                    }

                    ViewBag.TotalINR = TotalINR;
                    PaymentMaster.NetPriceINR = Math.Round(TotalINR / (TaxUtility.TaxValue + 100) * 100, 2);
                    PaymentMaster.ServiceTaxINR = Math.Round(PaymentMaster.NetPriceINR * TaxUtility.TaxValue / 100, 2);
                    PaymentMaster.STaxNameINR = TaxUtility.TaxName;
                    PaymentMaster.TotalUSD = ToTalUSD;

                    TempData["PaymentModel"] = PaymentMaster;
                    ViewBag.StateCodeList = UOF.IAdminMaster.GetStateCodeList();
                    return View(PaymentMaster);
                }
                else
                {
                    return RedirectToAction("InstructorledCourses", "Home");
                }
            }
            else
            {
                return RedirectToAction("Login", "Account", new { ReturnUrl = Url.Action("Index", "Payment") });
            }
        }

        [HttpPost]
        public void PaymentIn(PaymentMasterDTO_V1 data)
        {
            try
            {
                if (CurrentUser != null && CurrentUser.Email != "" && TempData["PaymentModel"] != null)
                {
                    PaymentMasterDTO_V1 model = TempData.Peek("PaymentModel") as PaymentMasterDTO_V1;

                    Session["TransactionId"] = model.TransactionId = GenerateUniqueNo();
                    model.Currency = "INR";
                    model.Status = "initiated";
                    model.PaymentGateway = "PayUMoney";
                    model.CreatedDate = DateTime.Now;

                    model.CustomerName = CurrentUser.Name;
                    model.Email = CurrentUser.Email;
                    model.ContactNo = CurrentUser.MobileNo;

                    model.StateCode = data.StateCode;
                    model.RoundOff = data.RoundOff;
                    model.Address = data.Address;
                    //Payment gateway settings
                    PayUmoney payU = new PayUmoney();
                    string url = payU.Url;
                    string surl = payU.SuccessUrl;
                    string furl = payU.FailUrl;
                    string key = payU.Key;
                    string salt = payU.Salt;
                    string serviceProvider = payU.ServiceProvider;
                    string productinfo = "";
                    string paymentProductInfo = "";
                    for (int i = 0; i < model.Payments.Count; i++)
                    {
                        if (i < model.Payments.Count - 1)
                            productinfo += model.Payments[i].Name.ToString() + ", ";
                        else
                            productinfo += model.Payments[i].Name.ToString();
                    }

                    //product chars length creating isssue
                    if (productinfo.Length > 100)
                    {
                        paymentProductInfo = productinfo.Substring(0, 97) + "...";
                    }
                    else
                    {
                        paymentProductInfo = productinfo;
                    }

                    var membership = model.Payments.Where(c => (c.CourseId == (int)EnumMembership.Monthly || c.CourseId == (int)EnumMembership.Yearly)).Select(c => c.CourseId).OrderByDescending(c => c).FirstOrDefault();

                    if (membership != 0)
                    {
                        Session["MembershipId"] = membership;
                    }
                    FormPost form = new FormPost();
                    //posting all the parameters required for integration.
                    form.Url = url;
                    form.Add("key", key);

                    form.Add("txnid", model.TransactionId);
                    form.Add("amount", model.Total.ToString());
                    form.Add("productinfo", paymentProductInfo);
                    form.Add("firstname", model.CustomerName);
                    form.Add("phone", model.ContactNo);
                    form.Add("email", model.Email);

                    form.Add("surl", surl);
                    form.Add("furl", furl);
                    form.Add("curl", furl);
                    form.Add("service_provider", serviceProvider);


                    string hashString = key + "|" + model.TransactionId + "|" + model.Total.ToString() + "|" + paymentProductInfo + "|" + model.CustomerName + "|" + model.Email + "|||||||||||" + salt;
                    //eg: string hashString = "3Q5c3q|2590640|3053.00|OnlineBooking|vimallad|ladvimal@gmail.com|||||||||||mE2RxRwx";
                    string hash = Generatehash512(hashString);
                    form.Add("hash", hash);

                    if (Session["URLSource"] != null)
                    {
                        model.URLSource = Session["URLSource"].ToString();
                    }
                    if (Session["ReferralCode"] != null)
                    {
                        model.ReferralCode = Session["ReferralCode"].ToString();
                    }

                    //saving details into db
                    if (UOF.ICommonLogic.SavePaymentDetails(model))
                    {
                        if (model.Total <= 0 && model.TotalDiscountPercentage >= 100)
                        {

                            TransactionDTO Transactionmodel = new TransactionDTO();
                            Transactionmodel.TransactionId = model.TransactionId;
                            Transactionmodel.Total = model.Total;
                            Transactionmodel.PaymentGateway = "PayUMoney";
                            Transactionmodel.Status = "success";
                            Transactionmodel.Email = model.Email;
                            Transactionmodel.UpdatedDate = DateTime.Now;
                            Transactionmodel.MemberId = CurrentUser.UserId;
                            Transactionmodel.Currency = "INR";
                            Transactionmodel.CourseName = productinfo;
                            Response.Redirect(Url.Action("SuccessInDiscount", "Payment", Transactionmodel));
                        }
                        else
                        {
                            form.Post();
                        }
                    }
                }
                else
                {
                    Response.Write(msgTryAgain);
                }
            }
            catch (Exception ex)
            {
                Response.Write(msgTryAgain);
            }
        }

        public ActionResult SuccessInDiscount(TransactionDTO model)
        {
            try
            {
                if (model.Currency == "INR")

                {
                    ViewBag.Message = "Your payment has been received successfully!";

                    if (!UOF.ICommonLogic.ConfirmPaymentStatusINR(model))
                    {

                        ViewBag.Message += "Although, due to some technical issues it's not get updated in our side. We will contact you soon..";
                    }
                    if (model.Status == "success")
                    {
                        PaymentDTO mod = new PaymentDTO();
                        mod.Email = model.Email;
                        mod.CourseName = model.CourseName;
                        MailClient.SendMail_SuccessfullFreeSubscribe(mod);
                    }

                }
                else
                {
                    model.MemberId = CurrentUser.UserId;
                    UOF.ICommonLogic.ConfirmPaymentMasterDetailsUSD(model);
                    switch (model.Status)
                    {
                        case "processed":
                        case "completed":
                            ViewBag.Message = "Your payment has been received successfully!";

                            PaymentDTO mod = new PaymentDTO();
                            mod.Email = model.Email;
                            mod.CourseName = model.CourseName;
                            MailClient.SendMail_SuccessfullFreeSubscribe(mod);
                            break;
                        case "pending":
                            ViewBag.Message = "Your Paypal payment status!";
                            model.Status = "Pending, Your payment is under review by PayPal. Once it release by Paypal, we will confirm you! For more information, contact us +91-11-330 34100";
                            break;
                        default:
                            ViewBag.Message = "Your Paypal payment status!";
                            break;
                    }

                    return View("SuccessInUSDDiscount", model);
                }
                return View(model);


            }
            catch (Exception ex)
            {
                ViewBag.Message = "Please Try Again...";
            }
            return View();
        }

        [HttpPost]
        public ActionResult SuccessIn(FormCollection form)
        {
            try
            {
                if (form.Keys.Count > 0 && Session["TransactionId"].ToString() == form["txnid"].ToString())
                {
                    PayUmoney payU = new PayUmoney();
                    string salt = payU.Salt;

                    string[] merc_hash_vars_seq;
                    string merc_hash_string = string.Empty;
                    string merc_hash = string.Empty;
                    string order_id = string.Empty;
                    string hash_seq = payU.Hash_Seq;

                    //success/pending/failure
                    if (form["status"].ToString() == "success")
                    {
                        merc_hash_vars_seq = hash_seq.Split('|');
                        Array.Reverse(merc_hash_vars_seq);

                        merc_hash_string = salt + "|" + form["status"].ToString();

                        foreach (string merc_hash_var in merc_hash_vars_seq)
                        {
                            merc_hash_string += "|";
                            merc_hash_string = merc_hash_string + (form[merc_hash_var] != null ? form[merc_hash_var] : "");
                        }

                        merc_hash = Generatehash512(merc_hash_string).ToLower();

                        if (merc_hash != form["hash"])
                        {
                            ViewBag.Message = "Payment amount did not matched";
                        }
                        else
                        {
                            TransactionDTO model = new TransactionDTO();

                            model.Total = Convert.ToDecimal(form["amount"]);
                            model.PaymentGateway = "PayUMoney";
                            model.Status = form["status"];
                            model.TransactionId = form["txnid"];
                            model.UpdatedDate = DateTime.Now;
                            model.CustomerName = form["firstname"];
                            model.Currency = "INR";
                            model.CourseName = form["productinfo"];
                            model.Email = form["email"];
                            model.PaymentId = form["payuMoneyId"];
                            model.MemberId = CurrentUser.UserId;

                            ViewBag.Message = "Your payment has been received successfully!";

                            if (!UOF.ICommonLogic.ConfirmPaymentStatusINR(model))
                            {
                                ViewBag.Message += "Although, due to some technical issues it's not get updated in our side. We will contact you soon..";
                            }
                            if (Session["MembershipId"] != null && CurrentUser != null && CurrentUser.UserId > 0)
                            {
                                var CookieName = FormsAuthentication.FormsCookieName;
                                if (System.Web.HttpContext.Current.Request.Cookies[CookieName] != null)
                                {
                                    HttpCookie aCookie = System.Web.HttpContext.Current.Request.Cookies[CookieName];
                                    aCookie.Expires = DateTime.Now.AddDays(-10);
                                    aCookie.Value = "";
                                    System.Web.HttpContext.Current.Response.Cookies.Add(aCookie);
                                }
                                FormsAuthentication.SignOut();
                            }
                            if (model.Status == "success")
                            {
                                MailClient.SendMail_SuccessfullPayment(model);
                            }
                            return View(model);
                        }
                    }
                    else
                    {
                        ViewBag.Message = "Your payment is not succeed.";
                    }
                }
                else
                {
                    ViewBag.Message = "Sorry, we didn't receive any response from payment gateway.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Please Try Again...";
            }
            return View();
        }

        public ActionResult FailIn()
        {
            return View();
        }

        [HttpPost]
        public void PaymentUsd(PaymentMasterDTO_V1 data)
        {
            try
            {
                if (CurrentUser != null && TempData["PaymentModel"] != null)
                {
                    PaymentMasterDTO_V1 model = TempData.Peek("PaymentModel") as PaymentMasterDTO_V1;

                    Session["TransactionId"] = model.TransactionId = GenerateUniqueNo();
                    model.Currency = "USD";
                    model.Status = "initiated";
                    model.PaymentGateway = "PayPal";
                    model.CreatedDate = DateTime.Now;

                    model.CustomerName = CurrentUser.Name;
                    model.Email = CurrentUser.Email;
                    model.ContactNo = CurrentUser.MobileNo;
                    model.StateCode = null;
                    model.Address = data.Address;

                    PayPal payPal = new PayPal();

                    string url = payPal.Url;
                    string surl = payPal.SuccessUrl;
                    string furl = payPal.FailUrl;
                    string business = payPal.BusinessEmail;

                    //posting all the parameters required for integration.
                    FormPost form = new FormPost();

                    form.Url = url;
                    form.Add("cmd", "_xclick");
                    form.Add("charset", "utf-8");
                    form.Add("business", business);
                    form.Add("rm", "2"); //return method post

                    form.Add("invoice", model.TransactionId);

                    string productinfo = "";
                    string paymentProductInfo = "";
                    for (int i = 0; i < model.Payments.Count; i++)
                    {
                        if (i < model.Payments.Count - 1)
                            productinfo += model.Payments[i].Name.ToString() + ", ";
                        else
                            productinfo += model.Payments[i].Name.ToString();
                    }

                    if (productinfo.Length > 100)
                    {
                        paymentProductInfo = productinfo.Substring(0, 97) + "...";
                    }
                    else
                    {
                        paymentProductInfo = productinfo;
                    }
                    var membership = model.Payments.Where(c => (c.CourseId == (int)EnumMembership.Monthly || c.CourseId == (int)EnumMembership.Yearly)).Select(c => c.CourseId).OrderByDescending(c => c).FirstOrDefault();

                    if (membership != 0)
                    {
                        Session["MembershipId"] = membership;
                    }

                    //form.Add("item_number", model.CourseId);
                    form.Add("item_name", paymentProductInfo);
                    form.Add("amount", model.Total.ToString());
                    // form.Add("quantity", "1");
                    form.Add("currency_code", model.Currency);

                    form.Add("first_name", model.CustomerName);
                    form.Add("email", model.Email);
                    form.Add("no_note", "1"); //Do not prompt for note
                    form.Add("no_shipping", "1"); //Do not prompt for shipping address
                    form.Add("cbt", "Return to Dot Net Tricks");

                    form.Add("return ", surl);
                    form.Add("cancel_return ", furl);

                    if (Session["URLSource"] != null)
                    {
                        model.URLSource = Session["URLSource"].ToString();
                    }
                    if (Session["ReferralCode"] != null)
                    {
                        model.ReferralCode = Session["ReferralCode"].ToString();
                    }

                    //saving details into db
                    if (UOF.ICommonLogic.SavePaymentDetails(model))
                    {
                        if (model.Total <= 0 && model.TotalDiscountPercentage >= 100)
                        {
                            TransactionDTO Transactionmodel = new TransactionDTO();
                            Transactionmodel.TransactionId = model.TransactionId;
                            Transactionmodel.Total = model.Total;
                            Transactionmodel.PaymentGateway = "PayPal";
                            Transactionmodel.Status = "success";
                            Transactionmodel.Email = model.Email;
                            Transactionmodel.UpdatedDate = DateTime.Now;
                            Transactionmodel.MemberId = CurrentUser.UserId;
                            Transactionmodel.Currency = "USD";
                            Transactionmodel.CourseName = productinfo;

                            Response.Redirect(Url.Action("SuccessInDiscount", "Payment", Transactionmodel));
                        }
                        else
                        {
                            form.Post();
                        }
                        //form.Post();
                    }
                }
                else
                {
                    Response.Write(msgTryAgain);
                }
            }
            catch (Exception ex)
            {
                Response.Write(msgTryAgain);
            }
        }

        [HttpPost]
        public ActionResult SuccessUsd(FormCollection form)
        {
            try
            {
                if (form.Keys.Count > 0 && Session["TransactionId"].ToString() == form["invoice"].ToString())
                {
                    TransactionDTO model = new TransactionDTO();
                    model.Total = Convert.ToDecimal(form["mc_gross"]);

                    //Pending|Processed|Completed|Failed
                    model.Status = form["payment_status"].ToLower();
                    model.TransactionId = form["invoice"];
                    model.PaymentId = form["txn_id"];
                    model.UpdatedDate = DateTime.Now;

                    model.CustomerName = form["first_name"];
                    model.Currency = "USD";
                    model.Email = form["payer_email"];

                    //for course payment
                    if (Session["IsInstallment"] == null)
                    {
                        model.MemberId = CurrentUser.UserId;
                        UOF.ICommonLogic.ConfirmPaymentMasterDetailsUSD(model);
                    }
                    //for installment payment
                    else if (Session["IsInstallment"] != null && Session["IsInstallment"].ToString() == "1")
                    {
                        UOF.ICommonLogic.ConfirmInstallmentDetailsUSDV1(model);
                    }
                    //showing message and sending mail
                    switch (model.Status)
                    {
                        case "processed":
                        case "completed":
                            ViewBag.Message = "Your payment has been received successfully!";

                            MailClient.SendMail_SuccessfullPayment(model);
                            break;
                        case "pending":
                            ViewBag.Message = "Your Paypal payment status!";
                            model.Status = "Pending, Your payment is under review by PayPal. Once it release by Paypal, we will confirm you! For more information, contact us +91-11-330 34100";
                            break;
                        default:
                            ViewBag.Message = "Your Paypal payment status!";
                            break;
                    }

                    if (Session["MembershipId"] != null && CurrentUser != null && CurrentUser.UserId > 0)
                    {
                        var CookieName = FormsAuthentication.FormsCookieName;
                        if (System.Web.HttpContext.Current.Request.Cookies[CookieName] != null)
                        {
                            HttpCookie aCookie = System.Web.HttpContext.Current.Request.Cookies[CookieName];
                            aCookie.Expires = DateTime.Now.AddDays(-10);
                            aCookie.Value = "";
                            System.Web.HttpContext.Current.Response.Cookies.Add(aCookie);
                        }
                        FormsAuthentication.SignOut();
                    }

                    return View(model);
                }
                else
                {
                    ViewBag.Message = "Sorry, we didn't receive any response from payment gateway.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "There is an internal issue.";
            }
            return View();
        }

        public ActionResult FailUsd()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SubscribeFree(PaymentDTO model)
        {
            try
            {
                if (CurrentUser != null)
                {
                    model.UpdatedDate = DateTime.Now;
                    model.CustomerName = CurrentUser.Name;
                    model.CourseId = model.CourseId;
                    model.CourseName = model.CourseName;
                    model.Email = CurrentUser.Email;
                    model.MemberId = CurrentUser.UserId;
                    CourseSubscriptionMemberDTO memdet = new CourseSubscriptionMemberDTO();
                    memdet.CourseId = model.CourseId;
                    memdet.MemberId = CurrentUser.UserId;
                    bool status = UOF.IAdminMaster.CheckMemberSubscription(memdet);
                    if (status == false)
                    {
                        if (UOF.ICommonLogic.ConfirmFreeSubscribeDetails(model))
                        {
                            MailClient.SendMail_SuccessfullFreeSubscribe(model);

                        }

                    }
                    if (Session["CourseId"] != null)
                        Session.Remove("CourseId");
                    return RedirectToAction("Index", "Dashboard", new { area = "Member" });
                }
                else
                {
                    return Redirect("https://www.dotnettricks.com/");
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
