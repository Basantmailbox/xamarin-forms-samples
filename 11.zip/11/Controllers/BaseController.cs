﻿using DNTData;
using DNTShared;
using DNTShared.DTO;
using DNTWebCore;
using DNTWebCore.Enum;
using DNTWebUI.Models.Security;
using DotNetTricks.COM.Security;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    //[TimeZoneFliter]
    public class BaseController : Controller
    {
        public CustomPrincipal CurrentUser
        {
            get
            {
                return HttpContext.User as CustomPrincipal;
            }
        }

        IUnitOfWork _IUnitOfWork;
        public IUnitOfWork UOF
        {
            get
            {
                if (_IUnitOfWork == null)
                    _IUnitOfWork = new UnitOfWork();
                return _IUnitOfWork;
            }
        }

        //cache IndexDisplayData
        protected IndexDisplayDataDTO GetIndexDisplayData()
        {
            var defaultzone = "-330";
            if (Session.Count > 0)
            {
                defaultzone = Session["timezoneoffset"] != null ? Session["timezoneoffset"].ToString() : "-330";
            }

            double minutes2 = Convert.ToDouble(defaultzone);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
            var timeOffSet = zone.Id;

            string key = "indexdisplaydata";
            var cachedata = CacheService.GetCacheObject<IndexDisplayDataDTO>(key);
            if (cachedata == null)
            {
                IndexDisplayDataDTO data = UOF.ICommonLogic.GetIndexDisplayData(timeOffSet);
                cachedata = CacheService.SetCacheObject<IndexDisplayDataDTO>(key, data, (int)CacheDuration.FullDay);
            }
            return cachedata;
        }

        //caching courses with categories
        protected List<CourseCategoryDTO> GetCategorywiseCourses()
        {
            try
            {
                var currency = "USD";
                var defaultzone = "-330";
                if (Session.Count > 0)
                {
                    defaultzone = Session["timezoneoffset"] != null ? Session["timezoneoffset"].ToString() : "-330";

                }
                double minutes2 = Convert.ToDouble(defaultzone);
                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
                var timeOffSet = zone.Id;
                if (timeOffSet == "India Standard Time")
                {
                    RegionInfo ri = new RegionInfo("en-IN");
                    currency = ri.ISOCurrencySymbol;
                    Session["currency"] = currency;
                }
                else
                {
                    RegionInfo ri = new RegionInfo("en-US");
                    currency = ri.ISOCurrencySymbol;
                    Session["currency"] = currency;
                }

                //  var currency = Session["currency"].ToString();
                currency = "USD";
                ViewBag.Currency = currency;
                string key = "categorylist" + currency;

                List<CourseCategoryDTO> data = UOF.ICommonLogic.GetCategorywiseMenuList();
                return data;

            }
            catch (Exception ex)
            {
            }
            return null;
        }

        protected List<CourseDTO> Getall_Courses()
        {
            string key = "Courselist";
            var cachedata = CacheService.GetCacheList<CourseDTO>(key);
            if (cachedata == null)
            {
                List<CourseDTO> data = UOF.ICommonLogic.GetAllCourseList();
                cachedata = CacheService.SetCacheList<CourseDTO>(key, data, (int)CacheDuration.FullDay);
            }
            return cachedata.ToList();
        }

        protected List<CourseCategoryDTO> GetFreeCategorywiseCourses()
        {
            string key1 = "categorylistfree";
            var cachedata = CacheService.GetCacheList<CourseCategoryDTO>(key1);
            if (cachedata == null)
            {
                IEnumerable<CourseCategoryDTO> data = UOF.ICommonLogic.GetFreeCategorywiseMenuList();
                cachedata = CacheService.SetCacheList<CourseCategoryDTO>(key1, data, (int)CacheDuration.FullDay);
            }
            return cachedata.ToList();
        }

        //get all courses based on GetCategorywiseCourses method
        protected List<CourseDTO> GetAllCoursesList()
        {
            List<CourseDTO> courseList = new List<CourseDTO>();

            var categorywiseCourses = GetCategorywiseCourses();
            foreach (var category in categorywiseCourses)
            {
                foreach (var course in category.Courses)
                {
                    var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                    CourseDTO obj = new CourseDTO
                    {
                        CourseId = course.CourseId,
                        Name = course.Name,
                        URL = course.URL,
                        DomainName = course.DomainName,
                        SmallBanner = course.SmallBanner,
                        MobileBanner = course.MobileBanner,
                        Sequence = course.Sequence,
                        Reviews = course.Reviews,
                        Learners = course.Learners,
                        CourseFeatures = course.CourseFeatures,
                        CourseDetailList = Feature,
                        IsFree = course.IsFree,
                    };
                    courseList.Add(obj);
                }
            }
            return courseList;
        }
        //get all free courses based on GetCategorywiseCourses method
        protected List<CourseDTO> GetAllFreeCoursesList()
        {
            var categorywiseCourses = GetFreeCategorywiseCourses();
            List<CourseDTO> courseList = new List<CourseDTO>();
            foreach (var category in categorywiseCourses)
            {
                foreach (var course in category.Courses)
                {
                    var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                    CourseDTO obj = new CourseDTO
                    {
                        CourseId = course.CourseId,
                        Name = course.Name,
                        URL = course.URL,
                        DomainName = course.DomainName,
                        SmallBanner = course.SmallBanner,
                        MobileBanner = course.MobileBanner,
                        Sequence = course.Sequence,
                        Reviews = course.Reviews,
                        Learners = course.Learners,
                        CourseFeatures = course.CourseFeatures,
                        CourseDetailList = Feature,
                        IsFree = course.IsFree,
                    };
                    courseList.Add(obj);
                }
            }
            return courseList;
        }

        //All courses for front page        
        protected List<CourseDTO> GetMaster_CoursesList()
        {
            var Courses = Getall_Courses();
            List<CourseDTO> courseList = new List<CourseDTO>();
            foreach (var course in Courses.Where(x => x.CourseType == (int)EnumCourseType.Instructorled).ToList())
            {
                var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                CourseDTO obj = new CourseDTO
                {
                    CourseId = course.CourseId,
                    Name = course.Name,
                    URL = course.URL,
                    DomainName = course.DomainName,
                    SmallBanner = course.SmallBanner,
                    MobileBanner = course.MobileBanner,
                    Sequence = course.Sequence,
                    Reviews = course.Reviews,
                    Learners = course.Learners,
                    CourseFeatures = course.CourseFeatures,
                    CourseDetailList = Feature,
                    IsFree = course.IsFree,
                    CourseType = course.CourseType,
                    CourseCount = course.CoursesList != null ? course.CoursesList.Split(',').Count() : 0,
                    SkillsCount = course.SkillName != null ? course.SkillName.Split(',').Count() : 0,
                };
                courseList.Add(obj);

            }
            return courseList;
        }

        protected List<CourseDTO> GetAll_CoursesList()
        {
            var Courses = Getall_Courses();
            List<CourseDTO> courseList = new List<CourseDTO>();
            foreach (var course in Courses.Where(x => x.IsFree == 0).ToList())
            {
                var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                CourseDTO obj = new CourseDTO
                {
                    CourseId = course.CourseId,
                    Name = course.Name,
                    URL = course.URL,
                    DomainName = course.DomainName,
                    SmallBanner = course.SmallBanner,
                    MobileBanner = course.MobileBanner,
                    Sequence = course.Sequence,
                    Reviews = course.Reviews,
                    Learners = course.Learners,
                    CourseFeatures = course.CourseFeatures,
                    CourseDetailList = Feature,
                    IsFree = course.IsFree,
                    CourseType = course.CourseType,
                    CoursePricesSelfDTO = UOF.ICommonLogic.GetCoursePricesSelf(course.CourseId, ""),
                };
                courseList.Add(obj);
            }
            return courseList;
        }
        protected List<CourseDTO> GetBootCamp_CoursesList()
        {
            var Courses = Getall_Courses();
            List<CourseDTO> courseList = new List<CourseDTO>();
            foreach (var course in Courses.Where(x => x.CourseType == (int)EnumCourseType.BootCamp).ToList())
            {
                var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                CourseDTO obj = new CourseDTO
                {
                    CourseId = course.CourseId,
                    Name = course.Name,
                    URL = course.URL,
                    DomainName = course.DomainName,
                    SmallBanner = course.SmallBanner,
                    MobileBanner = course.MobileBanner,
                    Sequence = course.Sequence,
                    Reviews = course.Reviews,
                    Learners = course.Learners,
                    CourseFeatures = course.CourseFeatures,
                    CourseDetailList = Feature,
                    IsFree = course.IsFree,
                    CourseType = course.CourseType,
                };
                courseList.Add(obj);

            }
            return courseList;
        }
        protected List<CourseDTO> GetAll_CoursesListNotMaster(string currency)
        {
            var Courses = Getall_Courses().Where(x => x.IsFree == 0 && x.CourseType == (int)EnumCourseType.SelfPlaced).ToList();
            List<CourseDTO> courseList = new List<CourseDTO>();
            foreach (var course in Courses)
            {
                var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                CourseDTO obj = new CourseDTO
                {
                    CourseId = course.CourseId,
                    Name = course.Name,
                    URL = course.URL,
                    DomainName = course.DomainName,
                    SmallBanner = course.SmallBanner,
                    MobileBanner = course.MobileBanner,
                    Sequence = course.Sequence,
                    Reviews = course.Reviews,
                    Learners = course.Learners,
                    CourseFeatures = course.CourseFeatures,
                    CourseDetailList = Feature,
                    IsFree = course.IsFree,
                    CourseType = course.CourseType,
                    CoursePricesSelfDTO = UOF.ICommonLogic.GetCoursePricesSelf(course.CourseId, currency),
                };
                courseList.Add(obj);

            }
            return courseList;
        }

        protected List<CourseDTO> Get_All_CoursesList(string currency)
        {
            //caching data
            string key = "homeCourselist";
            var cachedata = CacheService.GetCacheList<CourseDTO>(key);
            if (cachedata == null)
            {
                var Courses = Getall_Courses();
                List<CourseDTO> courseList = new List<CourseDTO>();
                foreach (var course in Courses)
                {
                    //add course features
                    var Feature = UOF.ICommonLogic.GetAllFeature(course.CourseId);
                    CourseDTO obj = new CourseDTO
                    {
                        CourseId = course.CourseId,
                        Name = course.Name,
                        URL = course.URL,
                        SmallBanner = course.SmallBanner,
                        MobileBanner = course.MobileBanner,
                        Sequence = course.Sequence,
                        Mentors = course.Mentors,
                        CourseDetailList = Feature,
                        CourseType = course.CourseType,
                        CourseCount = course.CoursesList != null ? course.CoursesList.Split(',').Count() : 0,
                        SkillsCount = course.SkillName != null ? course.SkillName.Split(',').Count() : 0,
                        //VideoTypeId = course.VideoTypeId,
                       // VideoTypeName = course.VideoTypeName,
                        DifficultyTypeId = course.DifficultyTypeId,
                        DifficultyTypeName = course.DifficultyTypeName,
                        DifficultyLevelId = course.DifficultyLevelId,
                        DifficultyLevelName = course.DifficultyLevelName,
                        Duration = course.Duration,
                        CourseNewStatus = course.CourseNewStatus
                    };
                    courseList.Add(obj);
                }
                cachedata = CacheService.SetCacheList<CourseDTO>(key, courseList, (int)CacheDuration.FullDay);
            }
            return cachedata.ToList();
        }

    }
}
