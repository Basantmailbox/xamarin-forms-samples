﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebUI.Models.Security;

namespace DotNetTricks.COM.Controllers
{
    [RoutePrefix("events")]
    public class EventsController : BaseController
    {
        int pageSize;
        int pageSizeAttendee = 50;
        public string _baseUrl = string.Empty;

        public EventsController()
        {
            string _pageSize = Convert.ToString(WebConfigSetting.PageSize);
            int PS;
            bool result = Int32.TryParse(_pageSize, out PS);
            pageSize = (result == true) ? PS : 15;
            _baseUrl = WebConfigSetting.BaseURL;
        }
        [HttpGet]
        [TimeZoneFliter]
        [Route("~/events/{id:int?}")]
        public ActionResult Events(int id = 1)
        {
            var currency = Session["currency"].ToString();
            ViewBag.Currency = currency;

            List<EventDTO> model = new List<EventDTO>();
            model = UOF.IEvent.GetAllEventsPassed(id, pageSize);

            List<EventDTO> upmodel = new List<EventDTO>();
            upmodel = UOF.IEvent.GetUpcomingAllEvents();
            PagingDTO<EventDTO> obj = new PagingDTO<EventDTO>();
            obj.upcomingevents = upmodel;
            obj.Data = model;
            obj.Page = id;
            if (model != null)
            {
                obj.PageSize = Convert.ToInt32(model.Select(x => x.TotalCounts).FirstOrDefault() / pageSize);
            }
            else
            {
                obj.PageSize = 0;
            }
            return View(obj);
        }

        [Route("{eventType}/{url}")]
        public ActionResult Event(string eventType, string url)
        {
            try
            {


                TempData["flag"] = "true";
                string id = url.Split('-')[0];
                if (id != "")
                {
                    EventDTO model = new EventDTO();
                    model = UOF.IEvent.GetEventDetailsByID(id);

                    //if (model.DomainName != _baseUrl)
                    //{
                    //    var eventurl = model.DomainName + "/events" + "/" + eventType.ToLower() + "/" + url;
                    //    Response.Redirect(eventurl);

                    //}
                    //else
                    //{

                    //TempData["IsTrialMember"] = "true";

                    //if (CurrentUser != null)
                    //{
                    //    var memberDetails = UOF.IMember.GetMembershipData(CurrentUser.UserId);
                    //    if (memberDetails != null)
                    //    {
                    //        if (memberDetails.ExpiryDate >= DateTime.Now)
                    //        {
                    //            TempData["IsTrialMember"] = "true";
                    //        }
                    //        else
                    //        {
                    //            TempData["IsTrialMember"] = "false";
                    //        }
                    //    }
                    //    else
                    //    {
                    //        TempData["IsTrialMember"] = "false";
                    //    }
                    //}


                    //model.EventRegistrations = UOF.IEvent.GetRegisterMemberListForEvent(model.EventID);
                    //model.TotalCounts = model.EventRegistrations.Count();
                    //ViewBag.Canonical = model.Url;
                    //ViewBag.eventid = model.EventID;
                    //ViewBag.EventypeName = eventType;
                    if (model.EventID > 0 && model.EventDate >= DateTime.Today)
                    {

                        model.EventRegistrations = UOF.IEvent.GetRegisterMemberListForEvent(model.EventID);
                        model.TotalCounts = model.EventRegistrations.Count();
                        Session["eventid"] = model.EventID;
                        ViewBag.eventid = model.EventID;
                        ViewBag.Canonical = model.Url;
                        ViewBag.EventypeName = eventType;
                        return View(model);
                    }
                    else
                    {
                        return View(model);
                    }
                }
                else { return RedirectToAction("Events"); }
            }
            catch (Exception w)
            {
                return RedirectToAction("Events");
            }
        }

        [Route("register-event")]
        public ActionResult RegisterEvent()
        {
            if (CurrentUser != null)
            {
                return RedirectToAction("JoinEvent", "Events", new { area = "Member" });
            }
            return RedirectToAction("SignUp", "Account");
        }

        [Route("ViewAttendeListForEvent/{eventid:int?}/{page:int?}")]
        public ActionResult ViewAttendeListForEvent(int eventid = 0, int page = 1)
        {
            if (eventid != 0)
            {
                List<EventRegistrationDTO> model = new List<EventRegistrationDTO>();
                ViewBag.eventtype = UOF.IEvent.GetEventTypeName(eventid);

                model = UOF.IEvent.GetRegisterMemberListForEvent(eventid, page, pageSizeAttendee);
                if (model.Count != 0)
                {
                    int totalEventCount = UOF.IEvent.GetTotalRegisterMemberForEvent(eventid);
                    PagingDTO<EventRegistrationDTO> obj = new PagingDTO<EventRegistrationDTO>();

                    obj.Data = model;
                    obj.Page = page;
                    ViewBag.totalMember = totalEventCount;
                    obj.PageSize = Convert.ToInt32(Math.Ceiling((double)totalEventCount / pageSizeAttendee));
                    ViewBag.eventId = eventid;
                    return View(obj);
                }
                else { return RedirectToAction("upcoming-events"); }
            }
            else
            {
                return RedirectToAction("upcoming-events");
            }
        }

        public ActionResult Speakers(int EventID = 0)
        {
            IEnumerable<MentorMaster> model = UOF.IEvent.GetSpeakersList(EventID);
            if (model != null)
            {
                ViewBag.flag = "1";
                return PartialView("_SpeakersPage", model);
            }
            else
            {
                List<MentorMaster> model1 = new List<MentorMaster>();
                return PartialView("_SpeakersPage", model1);
            }
        }
    }
}