﻿using System;
using System.Web.Mvc;
using DNTData;
using DotNetTricks.COM.PaymentGateway;
using System.Text;
using System.Security.Cryptography;
using DNTShared.DTO;
using System.Linq;

namespace DotNetTricks.COM.Controllers
{
    public class PaymentInstallmentController : Controller
    {
        IUnitOfWork AppUnitOfWork;
        public PaymentInstallmentController()
        {
            AppUnitOfWork = new UnitOfWork();
        }
        private string Generatehash512(string text)
        {
            byte[] message = Encoding.UTF8.GetBytes(text);
            UnicodeEncoding UE = new UnicodeEncoding();
            byte[] hashValue;
            SHA512Managed hashString = new SHA512Managed();
            string hex = "";
            hashValue = hashString.ComputeHash(message);
            foreach (byte x in hashValue)
            {
                hex += String.Format("{0:x2}", x);
            }
            return hex;
        }

        private string GenerateUniqueNo()
        {
            DateTime date = DateTime.Now;
            string uniqueID = String.Format("{0:0000}{1:00}{2:00}{3:00}{4:00}{5:00}{6:000}", date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second, date.Millisecond);
            return uniqueID.Substring(2, uniqueID.Length - 2); //15 digit number : 171014072704579
        }

        //[Route("~/payment/installment/{id}")]
        //public ActionResult Index(string id)
        //{
        //    if (!string.IsNullOrEmpty(id))
        //    {
        //        InstallmentDetailsDTO model = AppUnitOfWork.ICommonLogic.GetInstallmentDetails(id);

        //        if (model != null)
        //        {
        //            //check here for the expire Date and Already done Payment
        //            if (model.IsPaymentDone == true)
        //            {
        //                ViewBag.Message = "The payment link has been expired. Please send us a mail on info@dotnettricks.com for the new payment url."; //"Payment already done.";
        //                return View();
        //            }
        //            if (model.ExpiryDate < DateTime.Now)
        //            {
        //                ViewBag.Message = "The payment link has been expired. Please send us a mail on info@dotnettricks.com for the new payment url.";
        //                return View();
        //            }

        //            //INR
        //            if (model.Currency == "INR")
        //            {
        //                model.Total = model.Total;
        //                model.STaxName = TaxUtility.TaxName;
        //                model.Price = Math.Round(model.Total / (TaxUtility.TaxValue + 100) * 100, 2);
        //                model.ServiceTax = Math.Round(model.Price * TaxUtility.TaxValue / 100, 2);
        //            }
        //            else {
        //                model.Price = model.Total;
        //            }

        //            TempData["InstallmentModel"] = model;
        //            ViewBag.StateCodeList = AppUnitOfWork.IAdminMaster.GetStateCodeList();
        //            return View(model);
        //        }
        //        else
        //        {
        //            ViewBag.Message = "You've requested the wrong payment url.";
        //            return View();
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "You've requested the wrong payment url.";
        //        return View();
        //    }
        //}
        [Route("~/payment/installment/{id}")]
        public ActionResult Index(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                InstallmentDetailsDTO model = AppUnitOfWork.ICommonLogic.GetInstallmentDetailsV1(id);

                if (model != null)
                {
                    //check here for the expire Date and Already done Payment
                    if (model.IsPaymentDone == true)
                    {
                        ViewBag.Message = "The payment link has been expired. Please send us a mail on info@dotnettricks.com for the new payment url."; //"Payment already done.";
                        return View();
                    }
                    if (model.ExpiryDate < DateTime.Now)
                    {
                        ViewBag.Message = "The payment link has been expired. Please send us a mail on info@dotnettricks.com for the new payment url.";
                        return View();
                    }

                    TempData["InstallmentModel"] = model;
                    Session["InstallmentDetailsDTO"] = model;
                    Session["currency"] = model.Currency;
                    ViewBag.StateCodeList = AppUnitOfWork.IAdminMaster.GetStateCodeList();
                    return View(model);
                }
                else
                {
                    ViewBag.Message = "You've requested the wrong payment url.";
                    return View();
                }
            }
            else
            {
                ViewBag.Message = "You've requested the wrong payment url.";
                return View();
            }
        }

        [HttpPost]
        public void PaymentIn(InstallmentDetailsDTO data)
        {
            try
            {
                System.Web.HttpContext.Current.Response.Write("<div style='text-align:center;font-family: Arial, Helvetica, sans-serif;'>We are processing your request. Please wait...</div>");

                if (TempData["InstallmentModel"] != null)
                {
                    InstallmentDetailsDTO model = TempData["InstallmentModel"] as InstallmentDetailsDTO;

                    Session["TransactionId"] = model.UID;
                    model.Status = "initiated";
                    model.PaymentGateway = "PayUMoney";
                    model.StateCode = data.StateId;
                    model.Address = data.BillAddress;
                    //Payment gateway settings
                    PayUmoney payU = new PayUmoney();
                    string url = payU.Url;
                    string surl = payU.InsSuccessUrl;
                    string furl = payU.InsFailUrl;
                    string key = payU.Key;
                    string salt = payU.Salt;
                    string serviceProvider = payU.ServiceProvider;

                    FormPost form = new FormPost();
                    //posting all the parameters required for integration.
                    form.Url = url;
                    form.Add("key", key);

                    form.Add("txnid", model.UID);
                    form.Add("amount", model.Total.ToString());
                    form.Add("productinfo", model.CourseName);
                    form.Add("firstname", model.CustomerName);
                    form.Add("phone", model.ContactNo);
                    form.Add("email", model.Email);

                    form.Add("surl", surl);
                    form.Add("furl", furl);
                    form.Add("curl", furl);
                    form.Add("service_provider", serviceProvider);
                    string hashString = key + "|" + model.UID + "|" + model.Total.ToString() + "|" + model.CourseName + "|" + model.CustomerName + "|" + model.Email + "|||||||||||" + salt;
                    // string hashString = key + "|" + model.TransactionId + "|" + model.Price.ToString() + "|" +model.CourseName + "|" + model.CustomerName + "|" + model.Email + "|||||||||||" + salt;
                    //eg: string hashString = "3Q5c3q|2590640|3053.00|OnlineBooking|vimallad|ladvimal@gmail.com|||||||||||mE2RxRwx";
                    string hash = Generatehash512(hashString);
                    form.Add("hash", hash);

                    //saving details into db
                    if (AppUnitOfWork.ICommonLogic.UpdateInstallmentDetailsv1(model))
                    {
                        form.Post();
                    }
                }
                else
                {
                    Response.Write("Please try after sometime");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        public ActionResult SuccessIn(FormCollection form)
        {
            try
            {
                if (form.Keys.Count > 0 && Session["TransactionId"].ToString() == form["txnid"])
                {
                    PayUmoney payU = new PayUmoney();
                    string salt = payU.Salt;

                    string[] merc_hash_vars_seq;
                    string merc_hash_string = string.Empty;
                    string merc_hash = string.Empty;
                    string order_id = string.Empty;
                    string hash_seq = payU.Hash_Seq;

                    //success/pending/failure
                    if (form["status"].ToString() == "success")
                    {
                        merc_hash_vars_seq = hash_seq.Split('|');
                        Array.Reverse(merc_hash_vars_seq);

                        merc_hash_string = salt + "|" + form["status"].ToString();

                        foreach (string merc_hash_var in merc_hash_vars_seq)
                        {
                            merc_hash_string += "|";
                            merc_hash_string = merc_hash_string + (form[merc_hash_var] != null ? form[merc_hash_var] : "");
                        }

                        merc_hash = Generatehash512(merc_hash_string).ToLower();

                        if (merc_hash != form["hash"])
                        {
                            //Response.Write("<br/>Hash value did not matched");
                            ViewBag.Message = "Payment amount did not matched";
                        }
                        else
                        {
                            InstallmentDetailsDTO model = new InstallmentDetailsDTO();

                            model.Total = Convert.ToDecimal(form["amount"]);
                            model.PaymentGateway = "PayUMoney";
                            model.Status = form["status"];
                            model.TransactionId = form["txnid"];
                            model.UpdatedDate = DateTime.Now;
                            model.CustomerName = form["firstname"];
                            model.Currency = "INR";
                            model.Email = form["email"];
                            model.PaymentId = form["payuMoneyId"];

                            ViewBag.Message = "Your payment has been received successfully!";
                            if (!AppUnitOfWork.ICommonLogic.ConfirmInstallmentDetails(model))
                            {
                                ViewBag.Message += "Although, due to some technical issues it's not get updated in our side. We will contact you soon..";
                            }
                            if (Session["CourseId"] != null)
                                Session.Remove("CourseId");
                            return View(model);
                        }
                    }
                    else
                    {
                        ViewBag.Message = "Your payment is not succeeded.";
                    }
                }
                else
                {
                    ViewBag.Message = "Sorry, we didn't receive any response from payment gateway.";
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = "There is an internal issue.";
            }
            return View();
        }

        public ActionResult FailIn()
        {
            return View();
        }

        [HttpPost]
        public void PaymentUsd(InstallmentDetailsDTO data)
        {
            try
            {
                System.Web.HttpContext.Current.Response.Write("<div style='text-align:center;font-family: Arial, Helvetica, sans-serif;'>We are processing your request. Please wait...</div>");
                if (TempData["InstallmentModel"] != null)
                {
                    InstallmentDetailsDTO model = TempData["InstallmentModel"] as InstallmentDetailsDTO;
                    Session["TransactionId"] = model.UID;

                    //since success method is same for course fee and installment
                    //So, add flag to distinguish
                    Session["IsInstallment"] = "1";

                    model.Currency = "USD";
                    model.Status = "initiated";
                    model.PaymentGateway = "PayPal";
                    model.CreatedDate = DateTime.Now;

                    model.CustomerName = model.CustomerName;
                    model.Email = model.Email;
                    model.ContactNo = model.ContactNo;
                    model.StateCode = 0;
                    model.Address = data.BillAddress;

                    PayPal payPal = new PayPal();

                    string url = payPal.Url;
                    string surl = payPal.SuccessUrl;
                    string furl = payPal.FailUrl;
                    string business = payPal.BusinessEmail;

                    //posting all the parameters required for integration.
                    FormPost form = new FormPost();

                    form.Url = url;
                    form.Add("cmd", "_xclick");
                    form.Add("charset", "utf-8");
                    form.Add("business", business);
                    form.Add("rm", "2"); //return method post

                    form.Add("invoice", model.UID);
                    form.Add("item_number", model.UID);
                    form.Add("item_name", model.CourseName);
                    form.Add("amount", model.Price.ToString());

                    //form.Add("amount", "1");
                    form.Add("quantity", "1");
                    form.Add("currency_code", model.Currency);

                    form.Add("first_name", model.CustomerName);
                    form.Add("email", model.Email);
                    form.Add("no_note", "1"); //Do not prompt for note
                    form.Add("no_shipping", "1"); //Do not prompt for shipping address
                    form.Add("cbt", "Return to Dot Net Tricks");

                    form.Add("return ", surl);
                    form.Add("cancel_return ", furl);

                    //update details db
                    if (AppUnitOfWork.ICommonLogic.UpdateInstallmentDetailsv1(model))
                    {
                        form.Post();
                    }
                }
                else
                {
                    Response.Write("Please try after sometime");
                }
            }
            catch (Exception ex)
            {
                Response.Write("Please try after sometime");
            }
        }

        public ActionResult FailUsd()
        {
            return View();
        }


        [HttpPost]
        public JsonResult CheckoutState(string StateCode)
        {
            try
            {
                TempData["flag"] = "true";
                var Currency = Session["currency"].ToString();

                var tax = AppUnitOfWork.IAdminMaster.getTaxRateCode(StateCode);
                var GSTDNT = TaxUtility.GSTDNT.Substring(0, 2);
                InstallmentDetailsDTO PaymentMaster = (InstallmentDetailsDTO)Session["InstallmentDetailsDTO"];
                PaymentMaster.CGSTPercent = 0;
                PaymentMaster.IGSTPercent = 0;
                PaymentMaster.SGSTPercent = 0;
                PaymentMaster.CGST = 0;
                PaymentMaster.SGST = 0;
                PaymentMaster.IGST = 0;
                PaymentMaster.RoundOff = 0;
                                
                if (GSTDNT == StateCode)
                {
                    PaymentMaster.CGSTPercent = tax.Select(x => x.CGST).FirstOrDefault();
                    PaymentMaster.SGSTPercent = tax.Select(x => x.SGST).FirstOrDefault();                    
                    PaymentMaster.CGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.CGSTPercent) / 100, 2);
                    PaymentMaster.SGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.SGSTPercent) / 100, 2);
                    PaymentMaster.Price = Math.Round(PaymentMaster.NetPrice + PaymentMaster.CGST + PaymentMaster.SGST, 2);

                    PaymentMaster.ServiceTaxPercentage = PaymentMaster.CGSTPercent + PaymentMaster.SGSTPercent;
                    PaymentMaster.ServiceTax = PaymentMaster.CGST + PaymentMaster.SGST;
                }
                else
                {
                    PaymentMaster.IGSTPercent = tax.Select(x => x.IGST).FirstOrDefault();
                    PaymentMaster.IGST = Math.Round((PaymentMaster.NetPrice * PaymentMaster.IGSTPercent) / 100, 2);
                    PaymentMaster.Price = Math.Round((PaymentMaster.NetPrice + PaymentMaster.IGST), 2);

                    PaymentMaster.ServiceTaxPercentage = PaymentMaster.IGSTPercent;
                    PaymentMaster.ServiceTax = PaymentMaster.IGST;
                }

                if (PaymentMaster.Total > PaymentMaster.Price)
                {
                    PaymentMaster.RoundOff = PaymentMaster.Total - PaymentMaster.Price;
                }
                else if (PaymentMaster.Total < PaymentMaster.Price)
                {
                    PaymentMaster.RoundOff = PaymentMaster.Price - PaymentMaster.Total;
                }

                TempData["PaymentModel"] = PaymentMaster;
                ViewBag.StateCodeList = AppUnitOfWork.IAdminMaster.GetStateCodeList();
                return Json(PaymentMaster, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {

            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
    }
}
