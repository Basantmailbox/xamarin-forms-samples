﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebCore;
using DNTWebCore.Enum;
using DNTWebUI.Models.Security;
using Newtonsoft.Json;

namespace DotNetTricks.COM.Controllers
{
    public class TrainingController : BaseController
    {
        public string _baseUrl = "";
        public string _ImageServerUrl = "";

        public TrainingController()
        {
            _baseUrl = WebConfigSetting.BaseURL;
        }

        [Route("~/instructor-led-courses")]
        public ActionResult Index()
        {
            var source = Request.QueryString["s"];
            var code = Request.QueryString["c"];
            if (source != null)
            {
                Session["URLSource"] = source;
            }
            if (code != null)
            {
                Session["ReferralCode"] = code;
            }

            TempData["flag"] = "true";
            return View(UOF.ICommonLogic.GetCategoryWiseCourses("USD", (int)EnumCourseType.Instructorled));
        }
        
        //cache Article
        [TimeZoneFliter]
        protected CourseDTO GetArticle(string url)
        {
            string key = url;
            var currency = Session["currency"].ToString();
            var cachedata = CacheService.GetCacheObject<CourseDTO>(key);
            if (cachedata == null)
            {
                CourseDTO data = UOF.ICommonLogic.GetCourseDataDetails(url, currency);
                cachedata = CacheService.SetCacheObject<CourseDTO>(key, data, (int)CacheDuration.FullDay);
            }
            return cachedata;
        }
   
        [Route("training/{city}/{url}")]
        public ActionResult CityWiseDetails(string city, string url)
        {
            ViewBag.CourseURL = url;
            //   url = "/training/" + url;
            Session["master"] = "";
            TempData["flag"] = "true"; //For hiding testimonial slider

            CourseDTO model = UOF.ICommonLogic.GetCityCourseDataDetails(city, url);
            if (model == null)
            {
                return RedirectToAction("InstructorledCourses", "Home");
            }

            else
            {
                if (CurrentUser != null)
                {
                    ViewBag.subscribe = UOF.ICourseTopic.CheckSubscription(model.CourseId, 0, CurrentUser.UserId);
                }
                //if (model.DomainName != _baseUrl)
                //{
                //    Response.Redirect(model.DomainName + model.URL);
                //}

                if (model.CourseType == (int)EnumCourseType.SelfPlaced)
                {
                    model.CurPreRecTopiclist = UOF.ICourse.GetCourseVedioDetails(model.CourseId);
                    if (model.CurPreRecTopiclist != null)
                    {
                        TimeSpan sum = TimeSpan.Parse("00:00:00");
                        int c = 0;
                        foreach (var item in model.CurPreRecTopiclist)
                        {
                            sum = sum.Add(item.TotalTime);
                            c += item.Subtopics.Count();
                        }
                        ViewBag.AllTimeDuration = sum;
                        ViewBag.Lectures = c;

                    }
                }
                else
                {
                    model.SubCourseDetailsList = UOF.ICourse.GetSubCourseDetailsList(model.CourseId);
                }
            }
            model.UrlList = UOF.ICommonLogic.GetAllUrl(city, model.URL);
            ViewBag.cid = model.CourseId;
            return View(model);
        }

        [Route("course/enrollads")]
        public ActionResult EnrollAds(int CourseId, int CourseType)
        {
            Session["CourseId"] = CourseId;
            Session["CourseType"] = CourseType;
            return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
        }

        [TimeZoneFliter]
        [Route("course/enroll")]
        public ActionResult Enroll(int CourseId, int CourseType)
        {
            var currency = Session["currency"].ToString();
            Session["CourseId"] = CourseId;
            Session["CourseType"] = CourseType;
            ShoppingCart cart = UOF.ICommonLogic.AddItemToShoppingCartDTO(CourseId, CourseType, (int)CurrentUser.UserId, 1);
            var model = UOF.ICommonLogic.GetShoppingCartDTO((int)CurrentUser.UserId, currency);
            return RedirectToAction("Index", "ShoppingCart");
        }

        [Route("training/getstartedself/{id:int?}")]
        public ActionResult GetStartedSelfPaced(int id = 0)
        {
            if (CurrentUser != null)
            {
                if (CurrentUser.MembershipExpiry >= DateTime.Now)
                {
                    return RedirectToAction("CourseDetails", "CourseSubscription", new { id = id, csid = CurrentUser.MembershipId, Area = "member" });
                }
                else
                {
                    Int64 courseSubsId;
                    Int64 memberId = CurrentUser.UserId;
                    List<int> Subscriptions = UOF.IMember.GetMemberCourseSubscriptions(memberId, out courseSubsId, id).ToList();

                    if (Subscriptions != null && Subscriptions.Any(s => s == (int)EnumCourseType.SelfPlaced))
                    {
                        return RedirectToAction("ViewSubscribedCourseDetails", "CourseSubscription", new { id = courseSubsId, Area = "member" });
                    }
                }
            }
            return RedirectToAction("PricingDetails", "Payment");
        }

        [Route("training/getstarted/{id:int?}/{free:int?}")]
        public ActionResult GetStartedNow(int id = 0, int free = 0)
        {
            if (CurrentUser != null)
            {
                if (CurrentUser.MembershipExpiry >= DateTime.Now)
                {
                    return RedirectToAction("CourseDetails", "CourseSubscription", new { id = id, csid = CurrentUser.MembershipId, Area = "member" });
                }
                else if (free > 0)
                {
                    return RedirectToAction("CourseDetails", "CourseSubscription", new { id = id, csid = 1, Area = "member" });
                }
                else
                {
                    Int64 memberSubsId;
                    Int64 memberId = CurrentUser.UserId;
                    List<int> Subscriptions = UOF.IMember.CheckMemberSubscription(memberId, out memberSubsId).ToList();

                    if (Subscriptions.Count > 0)
                    {
                        return RedirectToAction("ViewSubscribedCourseDetails", "CourseSubscription", new { id = memberSubsId, Area = "member" });
                    }
                }
            }
            return RedirectToAction("PricingDetails", "Payment");
        }

        [ChildActionOnly]
        public ActionResult Query()
        {
            QueryDTO queryModel = new QueryDTO();

            //Bind Training Mode
            List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
            queryModel.TrainingModeList = trainingModeList;
            //Subject
            queryModel.Subject = "Training - Home Page";

            return PartialView("_Query", queryModel);
        }

        [TimeZoneFliter]
        public ActionResult PriceDetails(int id)
        {
            var currency = Session["currency"].ToString();
            CoursePriceDTO model = UOF.ICommonLogic.GetCoursePrices(id, currency);
            ViewBag.courseId = id;
            return PartialView("_PriceDetails", model);
        }

        [TimeZoneFliter]
        public ActionResult BootPriceDetails(int id)
        {
            var currency = Session["currency"].ToString();
            CoursePriceDTO model = UOF.ICommonLogic.GetCoursePrices(id, currency);
            ViewBag.courseId = id;
            return PartialView("_BootPriceDetails", model);
        }

        [TimeZoneFliter]
        public ActionResult InterviewPriceDetails(int id)
        {
            var currency = Session["currency"].ToString();
            CoursePriceDTO model = UOF.ICommonLogic.GetCoursePrices(id, currency);
            ViewBag.courseId = id;
            return PartialView("_InterviewPriceDetails", model);
        }

        [TimeZoneFliter]
        public ActionResult PriceSelfPaced(int id)
        {
            var currency = Session["currency"].ToString();
            CoursePriceDTO model = UOF.ICommonLogic.GetCoursePricesSelf(id, currency);
            ViewBag.courseId = id;
            return PartialView("_Price-Self-Paced", model);
        }

        [TimeZoneFliter]
        public ActionResult PriceSelfPacedLoc(int id)
        {
            var currency = Session["currency"].ToString();
            CoursePriceDTO model = UOF.ICommonLogic.GetCoursePricesSelf(id, currency);
            ViewBag.courseId = id;
            return PartialView("_Price-Self-Paced-Loc", model);
        }

        public ActionResult Mentors(int id = 0)
        {
            IEnumerable<MentorMaster> model = UOF.ICourse.GetMentorList(id);
            if (model != null)
            {
                ViewBag.flag = "1";
                return PartialView("_MentorPage", model);
            }
            else
            {
                List<MentorMaster> model1 = new List<MentorMaster>();
                return PartialView("_MentorPage", model1);
            }
        }

        public static int GetIso8601WeekOfYear(DateTime time)
        {
            // Seriously cheat.  If its Monday, Tuesday or Wednesday, then it'll 
            // be the same week# as whatever Thursday, Friday or Saturday are,
            // and we always get those right
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(time);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                time = time.AddDays(3);
            }

            // Return the week of our adjusted day
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(time, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        static DateTime YearWeekDayToDateTime(int year, DayOfWeek day, int week)
        {
            DateTime startOfYear = new DateTime(year, 1, 1);

            // The +7 and %7 stuff is to avoid negative numbers etc.
            int daysToFirstCorrectDay = (((int)day - (int)startOfYear.DayOfWeek) + 7) % 7;

            startOfYear.AddDays(7 * (week - 1) + daysToFirstCorrectDay);

            return startOfYear.AddDays(7 * (week - 1) + daysToFirstCorrectDay);
        }

        static string GetBatchDays(string BatchDays, TimeSpan time1, DateTime day1,int addHour, string countryZone = null)
        {
            if (BatchDays != null)
            {
                var batchDays = BatchDays.Split(',');
                string batch = string.Empty;
                int week = GetIso8601WeekOfYear(day1);
                //var k = countryZone.Split('-');
                //countryZone = k[0];
                //string Id = k[1];
               
                foreach (var item in batchDays)
                {
                    DayOfWeek day = DayOfWeek.Sunday;
                    switch (item.ToString())
                    {
                        case "0":
                            day = DayOfWeek.Monday;
                            break;
                        case "1":
                            day = DayOfWeek.Tuesday;
                            break;
                        case "2":
                            day = DayOfWeek.Wednesday;
                            break;
                        case "3":
                            day = DayOfWeek.Thursday;
                            break;
                        case "4":
                            day = DayOfWeek.Friday;
                            break;
                        case "5":
                            day = DayOfWeek.Saturday;
                            break;
                        case "6":
                            day = DayOfWeek.Sunday;
                            break;
                    }
                    DateTime batchdate = YearWeekDayToDateTime(DateTime.UtcNow.Year, day, week);
                    batchdate = batchdate.Add(time1);
                    if (batch == string.Empty)
                    {
                        batch = batchdate.ToClientTimeDate1(countryZone.ToString(), addHour).DayOfWeek.ToString();
                    }
                    else { batch = batch + "," + batchdate.ToClientTimeDate1(countryZone.ToString(), addHour).DayOfWeek.ToString(); }
                }
                return batch;
            }
            return "";
        }

        [Route("getbatchdetailslist")]
        [HttpGet]
        //[TimeZoneFliter]
        public ActionResult BatchDetailsList(int Id = 0, string countryZone = null)
        {
            try
            {
                var SelectedZone = countryZone;//.Replace(":", "");
                var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
                double minutes2 = Convert.ToDouble(defaultzone);

                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();


                int week = GetIso8601WeekOfYear(DateTime.UtcNow);
                IEnumerable<BatchMasterDTO> model = UOF.ICourse.GetBatchesDetailsList(Id);

                var timeOffSet = zone.Id;
                ViewBag.timeOffSet = timeOffSet;

           

                if (countryZone != null && countryZone != "")
                {
                    timeOffSet = countryZone;
                }
                if (model.Count() != 0 && model != null)
                {
                    int addHour = 0;
                    var appSettingObj = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
                    if (appSettingObj != null)
                    {
                        addHour = appSettingObj.AppValue == "1" ? 1 : 0;
                    }
                    model = model.Select(x =>
                    {
                        x.StartDate = x.StartDate.ToClientTimeDate1(timeOffSet.ToString(), addHour);
                        x.BatchDays = GetBatchDays(x.BatchDays, x.BatchTiming.TimeOfDay, x.StartDate, addHour,timeOffSet.ToString());
                        x.EndDate = x.EndDate.Value.ToClientTimeDate1(timeOffSet.ToString(), addHour);
                        x.DispStartDate = x.StartDate.ToClientTime1(timeOffSet.ToString(), addHour);
                        x.DispEndDate = x.EndDate.Value.ToClientTime1(timeOffSet.ToString(), addHour);
                        x.BatchTiming = x.BatchTiming.ToClientTimeDate1(timeOffSet.ToString(), addHour);
                        x.BatchStartTimingDisplay = x.BatchTiming.ToString("MM/dd/yyyy HH:mm");
                        x.BatchEndTiming = x.BatchEndTiming.ToClientTimeDate1(timeOffSet.ToString(),addHour);
                        x.BatchEndTimingDisplay = x.BatchEndTiming.ToString("MM/dd/yyyy HH:mm");
                        return x;
                    });
                    ViewBag.flag = "1";
                    return Json(model, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (System.Exception)
            {
                return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult FaqDetails(int Id = 0, int ctype = 0)
        {
            List<FAQMaster> model = UOF.ICourse.GetFAQList(Id, ctype);
            if (model.Count() != 0 && model != null)
            {
                var mas = Session["master"].ToString();
                int c = mas != "" ? Convert.ToInt32(mas) : 0;
                if ((int)EnumCourseType.Instructorled == c)
                {
                    ViewBag.CourseType = (int)EnumCourseType.Instructorled;
                }
                else
                {
                    ViewBag.CourseType = (int)EnumCourseType.Instructorled;
                }
                ViewBag.flag = "1";
                return PartialView("_FaqDetails", model);
            }
            else
            {
                return PartialView("_FaqDetails");
            }
        }

        [TimeZoneFliter]
        [Route("training/masters-program/{url}")]
        public ActionResult MasterDetails(string url)
        {
            var source = Request.QueryString["s"];
            var code = Request.QueryString["c"];
            if (source != null)
            {
                Session["URLSource"] = source;
            }
            if (code != null)
            {
                Session["ReferralCode"] = code;
            }

            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);

            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

            var timeOffSet = zone.Id;
            Session["zoneId"] = timeOffSet;


            var currency = Session["currency"].ToString();
            ViewBag.CourseURL = url;
            url = "/training/masters-program/" + url;
            Session["master"] = "1";
            TempData["flag"] = "true"; //For hiding testimonial slider
            CourseDTO model = UOF.ICommonLogic.GetCourseDataDetails(url, currency);

            if (model == null || model.CourseType == (int)EnumCourseType.SelfPlaced)
            {
                return RedirectToAction("InstructorledCourses", "Home");
            }
            else
            {
                if (CurrentUser != null)
                {
                    ViewBag.subscribe = UOF.ICourseTopic.CheckSubscription(model.CourseId, 0, CurrentUser.UserId);
                }
                model.SubCourseDetailsList = UOF.ICourse.GetSubCourseDetailsList(model.CourseId);

            }
            ViewBag.cid = model.CourseId;
            return View(model);
        }

        [TimeZoneFliter]
        [Route("training/one-to-one/{url}")]
        public ActionResult OneToOneDetails(string url)
        {
            var currency = Session["currency"].ToString();
            ViewBag.CourseURL = url;
            url = "/one-to-one/" + url;
            Session["master"] = "";
            TempData["flag"] = "true"; //For hiding testimonial slider
            CourseDTO model = UOF.ICommonLogic.GetCourseDataDetails(url, currency);

            if (model == null || model.CourseType == (int)EnumCourseType.Instructorled || model.CourseType == (int)EnumCourseType.SelfPlaced)
            {
                return RedirectToAction("InstructorledCourses", "Home");
            }
            else
            {
                //if (CurrentUser != null)
                //{
                //    ViewBag.subscribe = UOF.ICourseTopic.CheckSubscription(model.CourseId, 0, CurrentUser.UserId);
                //}

                model.CurPreRecTopiclist = UOF.ICourse.GetCourseVedioDetails(model.CourseId);
                if (model.CurPreRecTopiclist != null)
                {
                    TimeSpan sum = TimeSpan.Parse("00:00:00");
                    int c = 0;
                    foreach (var item in model.CurPreRecTopiclist)
                    {
                        sum = sum.Add(item.TotalTime);
                        c += item.Subtopics.Count();
                    }
                    ViewBag.AllTimeDuration = sum;
                    ViewBag.Lectures = c;

                }
            }
            ViewBag.cid = model.CourseId;
            return View(model);
        }
                
        [TimeZoneFliter]
        [Route("interview-preparation/{url}")]
        public ActionResult InterviewPreparation(string url)
        {
            var currency = Session["currency"].ToString();
            ViewBag.CourseURL = url;
            url = "/interview-preparation/" + url;
            Session["master"] = "";
            TempData["flag"] = "true"; //For hiding testimonial slider
            CourseDTO model = UOF.ICommonLogic.GetCourseDataDetails(url, currency);
            
            model.CurPreRecTopiclist = UOF.ICourse.GetCourseVedioDetails(model.CourseId);
            if (model.CurPreRecTopiclist != null)
            {
                TimeSpan sum = TimeSpan.Parse("00:00:00");
                int c = 0;
                foreach (var item in model.CurPreRecTopiclist)
                {
                    sum = sum.Add(item.TotalTime);
                    c += item.Subtopics.Count();
                }
                ViewBag.AllTimeDuration = sum;
                ViewBag.Lectures = c;

            }
            ViewBag.cid = model.CourseId;
            return View(model);
        }

        [HttpPost]
        public ActionResult CallBackForDemo(int? CourseId, string ContactNo)
        {
            try
            {
                return Json(new { msg = "true" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            { }
            return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
        }
    }
}