﻿using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class SkillTestsController : BaseController
    {
        [Route("~/skill-tests")]
        public ActionResult Index()
        {
            CourseDTO data = new CourseDTO();
            data.quizlist = UOF.IQuestionMaster.GetAllQuiz();
            data.CourseCategories = GetCategorywiseCourses();
            data.CategoryLst = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course).ToList();
            data.MemberList = UOF.IQuestionMaster.GetMockTestScore(58, 15);// Default 58 Angular Category Id as today this course is MOST

            UpdateScore(data.MemberList);
            return View(data);
        }

        [Route("~/skill-tests/{Url}")]
        public ActionResult SkillTest(string Url)

        {
            try
            {
                MockUpTestMasterDTO quizlist = UOF.IQuestionMaster.GetSkillDetails(Url);
                ViewBag.MockupTestId = quizlist.MockupTestId;
                quizlist.CategoryList = UOF.ICategory.GetCategoriesByType((int)EnumCategoryType.Course).ToList();
                quizlist.MemberList = UOF.IQuestionMaster.GetMockTestScore(quizlist.CategoryID, 7);

                UpdateScore(quizlist.MemberList);

                if (quizlist != null)
                {
                    return View(quizlist);
                }

            }
            catch (Exception w)
            {
            }
            return RedirectToAction("Index");
        }

        private void UpdateScore(List<MockUpTestAttemptedStatusDTO> MemberList)
        {
            List<float> scoreDeci = MemberList.Select(s => s.Totalscore).Distinct().OrderByDescending(s=>s).ToList();
            Dictionary<int, float> scoreDictionary = new Dictionary<int, float>();
            int rowIndex = 1;
            foreach (var item in scoreDeci)
            {
                
                scoreDictionary.Add(rowIndex, item);
                rowIndex = rowIndex + 1;
            }
            foreach (var item in MemberList)
            {
                item.TScore = scoreDictionary.FirstOrDefault(x => x.Value == item.Totalscore).Key;
                item.TPercentage = item.percentage.ToString().Contains(".00") ? item.percentage.ToString().Replace(".00", "") : item.percentage.ToString();
            }
        }
        [Route("~/fillskill/{id:int}")]
        public ActionResult FillSkill(int id)
        {
            try
            {
                ViewBag.MockupTestId = id;
                ViewBag.skList = UOF.IAdminMaster.GetAllSkillTypes();

                return View();
            }
            catch (Exception w)
            {
            }
            return RedirectToAction("Index");
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult TestYourSkillEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Query - Test Skill Page";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_CorporateEnquiry", contactModel);
        }
        [HttpPost]
        public ActionResult GetSkillTestScore(int categoryId, int takeTop = 7)
        {
            List<MockUpTestAttemptedStatusDTO> mockUpTestMasterDTOs = UOF.IQuestionMaster.GetMockTestScore(categoryId, takeTop);
            List<decimal> scoreDeci = mockUpTestMasterDTOs.Select(s => s.Scores).Distinct().ToList();

            UpdateScore(mockUpTestMasterDTOs);
            //foreach (var item in mockUpTestMasterDTOs)
            //{

            //    item.percentage
            //}

            return Json(mockUpTestMasterDTOs, JsonRequestBehavior.AllowGet);
        }
    }
}