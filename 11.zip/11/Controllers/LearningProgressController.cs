﻿using System;
using System.Web.Mvc;
using DNTShared.Entities;


namespace DotNetTricks.COM.Controllers
{
    public class LearningProgressController : BaseController
    {
        // GET: LearningProgress
        public ActionResult Insert()
        {
            return View();
        }

        [Route("~/learningProgress/insert/{CourseId}/{TopicId}/{TopicType}")]
        ///[HttpPost]
        public JsonResult InsertData(int CourseId, int TopicId, int TopicType)
        {
            try
            {
                //TODO
                if (CurrentUser != null)
                {
                    if (CourseId > 0 && TopicId > 0 && TopicType > 0)
                    {
                        LearningProgress learningProgress = new LearningProgress();
                        learningProgress.CourseId = CourseId;
                        learningProgress.TopicId = TopicId;
                        learningProgress.TopicType = TopicType;
                        learningProgress.MemberId = CurrentUser.UserId;
                        //learningProgress.MemberId = 61431; //TODO
                        learningProgress.LearntDate = DateTime.Now;
                        var resultOb = UOF.ILearningProgress.InsertEntity(learningProgress);
                        return Json(new { IsSuccess = true }, JsonRequestBehavior.AllowGet);

                    }
                    else
                    {
                        return Json(new { IsSuccess = false }, JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json(new { IsSuccess = false }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new { IsSuccess = false }, JsonRequestBehavior.AllowGet);
            }
        }

        //[Route("~/learningProgress/insert")]
        //[HttpGet]
        //public JsonResult InsertData(LearningProgress learningProgress)
        //{
        //    try
        //    {

        //        if (ModelState.IsValid)
        //        {
        //            //if (CurrentUser != null)
        //            //{
        //            //    learningProgress.MemberId = CurrentUser.UserId;
        //            learningProgress.MemberId = 33;
        //            UOF.ILearningProgress.InsertEntity(learningProgress);
        //            //}
        //        }

        //        return Json(new { IsSuccess = true }, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json(new { IsSuccess = false }, JsonRequestBehavior.AllowGet);
        //    }
        //}

    }
}