﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNTData;
using System.IO;
using System.Net;
using System.Configuration;
using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
using DNTWebCore;
using DNTWebCore.Enum;
using DNTWebUI.Models.Security;
using System.Globalization;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage;

namespace DotNetTricks.COM.Controllers
{
    public class HomeController : BaseController
    {
        SmsClient sms = new SmsClient();
        int pageSize;
        int pageSizeJobs;
        public string _ImageServerUrl = string.Empty;
        public string ImgCloudPath = string.Empty;
        static CloudBlobClient blobClient;
        CloudStorageAccount storageAccount;

        public HomeController()
        {
            pageSize = WebConfigSetting.PageSize;
            pageSizeJobs = WebConfigSetting.PageSize;
            _ImageServerUrl = ConfigurationManager.AppSettings["ImageServerUrl"].ToString();
            ImgCloudPath = WebConfigSetting.ImgCloudPath;
            storageAccount = CloudStorageAccount.Parse(WebConfigSetting.StorageDefaultConnection);
        }

        public ActionResult Index()
        {
            string currency = "USD";
            Session["currency"] = currency;
            //data caching
            IndexDisplayDataDTO d = new IndexDisplayDataDTO();
            d.CourseDTO = Get_All_CoursesList(currency);
            ViewBag.Categories = UOF.ICourse.GetCoursesByCategory();
            ViewBag.Currency = currency;
            return View(d);
        }

        [HttpPost]
        public ActionResult Index(string courseSearch)
        {
            try
            {
                if (!string.IsNullOrEmpty(courseSearch))
                {
                    CourseDTO courseDetails = UOF.ICommonLogic.GetSearchCourseDetails(courseSearch);

                    if (courseDetails != null)
                    {
                        string[] url1 = courseDetails.URL.Split('/');
                        return RedirectToAction("Details", "Training", new { url = url1[2] });
                    }
                }
            }
            catch
            {
                return RedirectToAction("InstructorledCourses", "Home");

            }
            return RedirectToAction("InstructorledCourses", "Home");
        }

        [Route("~/contact-us")]
        public ActionResult ContactUs()
        {
            return View();
        }

        [Route("~/about-us")]
        public ActionResult AboutUs()
        {
            return View();
        }

        [Route("~/about-shailendra-chauhan")]
        public ActionResult Founder()
        {
            TempData["flag"] = "true";
            return View();
        }

        [Route("~/search")]
        public ActionResult Search()
        {
            return View();
        }

        [Route("~/refer-and-earn")]
        public ActionResult ReferAndEarn()
        {
            TempData["flag"] = "true";
            return View();
        }

        [Route("~/corporate-training")]
        public ActionResult CorporateTraining()
        {
            TempData["flag"] = "true";
            return View();
        }

        [Route("~/online-training")]
        public ActionResult OnlineTraining()
        {
            return View();
        }

        [Route("~/classroom-training")]
        public ActionResult ClassroomTraining()
        {
            return View();
        }

        [Route("~/skill-bootcamp")]
        public ActionResult BootCampTraining()
        {
            return View(GetCategorywiseCourses());
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult _AllCourses()
        {
            string currency = ViewBag.Currency = "USD";
            var data = GetAll_CoursesListNotMaster(currency);
            return PartialView("_AllCourses", data);
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult _MasterCourses()
        {
            var data = GetMaster_CoursesList();
            return PartialView("_MasterCourses", data);
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult _BootCampCourses()
        {
            var data = GetBootCamp_CoursesList();
            return PartialView("_BootCampCourses", data);
        }

        public ActionResult _AllFreeCourses()
        {
            var data = GetAllFreeCoursesList();
            return PartialView("_AllFreeCourses", data);
        }

        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public JsonResult GetAllCourses()
        {
            try
            {
                var data = GetAllCoursesList();
                List<SearchCourseDTO> Courses = new List<SearchCourseDTO>();
                foreach (var item in data)
                {
                    SearchCourseDTO obj = new SearchCourseDTO();
                    obj.label = item.Name;
                    obj.value = item.URL;

                    Courses.Add(obj);
                }
                return Json(Courses, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [Route("~/privacy-policy")]
        public ActionResult PrivacyPolicy()
        {
            return View();
        }

        [Route("~/refund-policy")]
        public ActionResult RefundPolicy()
        {
            return View();
        }

        [Route("~/terms-and-conditions")]
        public ActionResult TermsandConditions()
        {
            return View();
        }

        [Route("~/become-an-instructor")]
        public ActionResult BecomeAnInstructor()
        {
            TempData["flag"] = "true";
            return View();
        }

        [Route("~/professional-empowerment")]
        public ActionResult ProfessionalEmpowerment()
        {
            TempData["flag"] = "true";
            return View();
        }

        [HttpGet]
        public ActionResult GetEmpoweredQuery()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "GetEmpowered:-";
            ViewBag.btnTitle = "Apply Now to Discuss your Concern";
            return PartialView("_CommonEnquiry", contactModel);
        }

        [HttpGet]
        public ActionResult RecruitingQuery()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Recruiting:-";
            ViewBag.btnTitle = "Share Your Details";
            return PartialView("_CommonEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult CourseEnquiry(int id = 0)
        {
            QueryDTO queryModel = new QueryDTO();


            ////Bind Courses
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            queryModel.CourseList = courseList;
            queryModel.CourseId = id;

            //Bind Training Mode
            List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
            queryModel.TrainingModeList = trainingModeList;
            //Subject
            queryModel.Subject = "Training - Course Page";

            return PartialView("_CourseEnquiry", queryModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult BecomeAMentor()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Become An Instructor Page";
            ViewBag.btnTitle = "SUBMIT INTEREST";
            return PartialView("_MentorEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult ContactUsEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Contact Us - Contact Page";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_ContactUsEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult ReferEarn()
        {
            ReferAndEarn model = new ReferAndEarn();
            ////Bind Courses
            List<CourseDTO> courseList = UOF.ICommonLogic.GetCourseList();
            model.CourseList = courseList;
            return PartialView("_ReferAndEarn", model);
        }

        [HttpPost]
        public JsonResult SaveReferAndEarn(ReferAndEarn model)
        {
            try
            {
                UOF.IQuery.SaveReferAndEarn(model);

                try
                {

                    MailClient.SendMail_ReferEarn(model);
                }
                catch (Exception ex)
                {

                }
                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveContactEnquiry(ContactDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetContactCount(model);
                if (count == 0)
                {
                    UOF.IQuery.SaveContactForm(model);
                    try
                    {
                        if (model.isauthor == "true")
                        {
                            UOF.IQuery.SendAuthorMsg(model);
                            MailClient.SendMail_Author(model);
                        }
                        else
                        {
                            UOF.IQuery.SendContactMsg(model);
                            MailClient.SendMail_Contact_BecomeMentor(model);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveEnquiry(QueryDTO model)
        {
            try
            {
                // CreateCookie();
                int count = UOF.IQuery.GetEnquiryCount(model);
                if (count == 0)
                {
                    UOF.IQuery.SaveQuery(model);
                    //  AppUnitOfWork.Queries.SendQueryMsg(model);
                    try
                    {
                        //send quick enquiry mail

                        MailClient.SendMail_Enquiry(model);
                    }
                    catch (Exception ex)
                    {
                    }
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }

                ModelState.Clear();

            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult QuickEnquiry()
        {
            QuickQueryDTO queryModel = new QuickQueryDTO();
            //Bind Courses            
            List<CourseDTO> courseList = new List<CourseDTO>();

            courseList = UOF.ICommonLogic.GetCourseList();
            queryModel.CourseList = courseList;
            List<TrainingMode> trainingModeList = new List<TrainingMode>();
            trainingModeList = UOF.ICommonLogic.GetTrainingModeList();

            //Bind Training Mode
            queryModel.TrainingModeList = trainingModeList;
            //Subject
            queryModel.QSubject = "Training - Home Page";
            return PartialView("_QuickEnquiry", queryModel);
        }

        [HttpPost]
        public JsonResult SaveQuickEnquiry(QuickQueryDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetQEnquiryCount(model);
                if (count == 0)
                {
                    UOF.IQuery.SaveQuickQuery(model);
                    // AppUnitOfWork.Queries.SendQuickQueryMsg(model);

                    try
                    {
                        //send quick enquiry mail
                        MailClient.SendMail_QuickEnquiry(model);
                    }
                    catch (Exception ex)
                    { }
                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult SaveEnquiryCourse(QueryDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetEnquiryCount(model);
                if (count == 0)
                {
                    UOF.IQuery.SaveCourseQuery(model);
                    // AppUnitOfWork.Queries.SendQueryMsg(model);
                    try
                    {
                        //send quick enquiry mail
                        MailClient.SendMail_Enquiry(model);
                    }
                    catch (Exception ex)
                    {
                    }
                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDownloadEnquiry(DownloadSyllabusDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetEnquiryInfo(model);

                if (count <= 1)
                {
                    if (CurrentUser != null)
                    {
                        bool check = UOF.ICourseTopic.CheckSubscription(model.DCourseId, 0, CurrentUser.UserId);
                        if (check == false)
                        {
                            UOF.IQuery.SaveDownloadEnquiry(model);
                        }
                    }
                    ModelState.Clear();
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDownloadEnquirynew(DownloadSyllabusDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetEnquiryInfo(model);

                if (count <= 1)
                {
                    int quid = 0;
                    if (model.ID == 0)
                    {
                        quid = UOF.IQuery.SaveDownloadEnquiry(model);
                    }

                    else
                    {
                        quid = UOF.IQuery.SaveDownloadEnquiryUpdate(model);
                    }
                    ModelState.Clear();
                    if (quid > 1)
                    {
                        var url = UOF.IDocument.GetAll().Where(d => d.CourseId == model.DCourseId && d.DocumentTypeId == 3).Select(d => d.DocumentUrl).FirstOrDefault();
                        var ext = Path.GetExtension(url);

                        if (ext == ".pdf" || ext == ".PDF")
                        {
                            url = ImgCloudPath + url;
                            return Json(new { msg = "success", url }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(new { msg = "success", url }, JsonRequestBehavior.AllowGet);
                        }
                        //int otp = UOF.IQuery.GenerateNewOtp(quid);
                        //if (otp != 0)
                        //{
                        //    int otpid = otp;
                        //    return Json(new { msg = "done", otpid, quid }, JsonRequestBehavior.AllowGet);
                        //}
                        //else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
                    }
                    else if (quid == 1)
                    {
                        return Json(new { msg = "exist" }, JsonRequestBehavior.AllowGet);
                    }
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SavedemoEnquiry(DownloadSyllabusDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetEnquiryInfo(model);

                if (count <= 1)
                {
                    int quid = 0;
                    if (model.ID == 0)
                    {
                        quid = UOF.IQuery.SaveDemoEnquiry(model);
                    }

                    else
                    {
                        quid = UOF.IQuery.SaveDemoEnquiryUpdate(model);
                    }
                    ModelState.Clear();

                    return Json(new { msg = "done", quid }, JsonRequestBehavior.AllowGet);

                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {

            }
            return null;
            //  return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult DownloadCourseAgenda(int id)
        {
            try
            {
                if (id != 0)
                {
                    Document data = UOF.ICommonLogic.GetDocumentUrl(id);
                    var ext = Path.GetExtension(data.DocumentUrl);
                    var filename = Path.GetFileName(data.DocumentUrl);
                    blobClient = storageAccount.CreateCloudBlobClient();

                    CloudBlobContainer container = blobClient.GetContainerReference(ConfigurationManager.AppSettings["documentFolder"].ToString());
                    CloudBlockBlob blob = container.GetBlockBlobReference(filename);

                    Stream blobStream = blob.OpenRead();
                    if (ext == ".pdf" || ext == ".PDF")
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".pdf");
                    }
                    else
                    {
                        return File(blobStream, blob.Properties.ContentType, data.DocumentName + ".zip");
                    }

                }
            }
            catch (Exception es)
            {
                return null;
            }
            return null;
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult CallbackRequest()
        {
            CallbackRequestDTO callModel = new CallbackRequestDTO();
            //Bind Courses

            List<CourseDTO> courseList = new List<CourseDTO>();
            courseList = UOF.ICommonLogic.GetCourseList();
            // cache.StringSet("courseList", JsonConvert.SerializeObject(courseList));
            // }



            callModel.CourseList = courseList;
            return PartialView("_CallbackRequest", callModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult CallbackRequest2()
        {
            CallbackRequestDTO callModel = new CallbackRequestDTO();
            //Bind Courses

            List<CourseDTO> courseList = new List<CourseDTO>();
            courseList = UOF.ICommonLogic.GetCourseList();
            // cache.StringSet("courseList", JsonConvert.SerializeObject(courseList));
            // }
            callModel.CourseList = courseList;
            return PartialView("_CallbackRequest2", callModel);
        }

        [HttpPost]
        public ActionResult SaveCallbackRequest(CallbackRequestDTO model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.ContactNo1))
                {
                    bool sts = model.ContactNo1.All(char.IsDigit);
                    if (sts == true)
                    {
                        // string lblIPddress = GetLanIPAddress();
                        // model.IpAddress = lblIPddress;
                        int count = UOF.IQuery.GetEnquiryCount(model);
                        if (count <= 1)
                        {

                            int quid = 0;
                            if (model.QID == 0)
                            {
                                quid = UOF.IQuery.SaveCallbackRequest(model);
                            }
                            else
                            { quid = UOF.IQuery.UpdateCallbackRequest(model); }

                            //queryRepo.SendQueryMsg(model, true);

                            ModelState.Clear();
                            int otp = UOF.IQuery.GenerateNewOtp(quid);
                            if (otp != 0)
                            {
                                int otpid = otp;
                                return Json(new { msg = "done", otpid, quid }, JsonRequestBehavior.AllowGet);
                            }
                            else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }

                        }
                    }
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveCallbackRequest2(CallbackRequestDTO2 model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.ContactNo2))
                {
                    bool sts = model.ContactNo2.All(char.IsDigit);
                    if (sts == true)
                    {
                        // string lblIPddress = GetLanIPAddress();
                        // model.IpAddress = lblIPddress;
                        int count = UOF.IQuery.GetEnquiryCount(model);
                        if (count <= 1)
                        {

                            int quid = 0;
                            if (model.QID == 0)
                            {
                                quid = UOF.IQuery.SaveCallbackRequest2(model);
                            }
                            else
                            { quid = UOF.IQuery.UpdateCallbackRequest2(model); }

                            //queryRepo.SendQueryMsg(model, true);

                            ModelState.Clear();
                            int otp = UOF.IQuery.GenerateNewOtp(quid);
                            if (otp != 0)
                            {
                                int otpid = otp;
                                return Json(new { msg = "done", otpid, quid }, JsonRequestBehavior.AllowGet);
                            }
                            else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }

                        }
                    }
                }
                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);

        }

        //by amit
        public String GetLanIPAddress()
        {
            string varIPAddress = string.Empty;
            string varIpAddress = string.Empty;
            varIpAddress = System.Web.HttpContext.Current.Request.Params["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(varIpAddress))
            {
                if (System.Web.HttpContext.Current.Request.Params["HTTP_X_FORWARDED_FOR"] != null)
                {
                    varIpAddress = System.Web.HttpContext.Current.Request.Params["HTTP_X_FORWARDED_FOR"];
                }
            }
            if (varIPAddress == "" || varIPAddress == null)
            {
                if (System.Web.HttpContext.Current.Request.Params["REMOTE_ADDR"] != null)
                {
                    varIpAddress = System.Web.HttpContext.Current.Request.Params["REMOTE_ADDR"];
                }
            }

            foreach (IPAddress currentIPAddress in Dns.GetHostAddresses(Dns.GetHostName()))
            {
                if (currentIPAddress.AddressFamily.ToString() == System.Net.Sockets.AddressFamily.InterNetwork.ToString())
                {
                    string varIpAddressIp = currentIPAddress.ToString();
                    varIpAddress = System.Net.Dns.GetHostEntry(Request.UserHostAddress).HostName + "(" + varIpAddressIp + ")";
                    break;
                }
            }
            return varIpAddress;
        }

        [ChildActionOnly]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult CommonTopMenu()
        {
            return PartialView("_CommonTopMenu", GetCategorywiseCourses());
        }

        #region Subscription
        [HttpPost]
        public ActionResult Subscription(string EmailID)
        {
            try
            {
                Subscription model = new Subscription();
                model.EmailID = EmailID.ToLower().Trim();

                bool? isSubscribedEmailAlreadyExists = UOF.ICommonLogic.IsSubscribedEmailAlreadyExists(EmailID);
                if (isSubscribedEmailAlreadyExists == true)
                {
                    ViewBag.isSubscribedEmailAlreadyExists = true;
                    ModelState.Clear();
                    return Json(new { msg = "alreadyexists" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    string _subscribeUrl = UOF.ICommonLogic.AddSubscription(model);
                    if (!string.IsNullOrEmpty(_subscribeUrl))
                    {

                        bool status = MailClient.SendMail_Subscription(EmailID, _subscribeUrl);
                        if (status == true)
                        {
                            int? totalSentMailCount = UOF.ICommonLogic.IncreaseSubscribeMailSentCounter(EmailID);
                            return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(new { msg = "emailsentfail" }, JsonRequestBehavior.AllowGet);
                        }
                    }
                }
            }
            catch (Exception ex)
            { }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ConfirmSubscription(string encml)
        {
            //string _email = AESEncription.Decryptstring(encml);
            bool result = UOF.ICommonLogic.VerifySubscribeEmail(encml);
            if (result == true)
            {
                return RedirectToAction("SuccessfullySubscribed", "Home");
            }
            else
            {
                return PartialView("~/Views/Shared/_Message.cshtml");
            }

        }

        [Route("~/subscribed-successfully")]
        public ActionResult SuccessfullySubscribed()
        {
            return View();
        }
        #endregion

        //Learning Solutions
        [ChildActionOnly]
        [HttpGet]
        public ActionResult CampusTrainingEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Query - Campus Training Page";
            ViewBag.btnTitle = "SUBMIT QUERY";

            return PartialView("_ContactUsEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult ClassroomTrainingEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Query - Classroom Training Page";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_ContactUsEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult CorporateTrainingEnquiry()
        {
            CorporateEnquiry contactModel = new CorporateEnquiry();
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_CorporateEnquiry", contactModel);
        }
        [ChildActionOnly]
        [HttpGet]
        public ActionResult Technical_RecruitersEnquiry()
        {
            PostJobs contactModel = new PostJobs();
            ViewBag.btnTitle = "Post Job";
            return PartialView("_Technical_RecruitersEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult HandsOnTrainingEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Query - HandsOn Training Page";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_ContactUsEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult IndustrialTrainingEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Query - Industrial Training Page";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_ContactUsEnquiry", contactModel);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult OnlineTrainingEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Query - Online Training Page";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_ContactUsEnquiry", contactModel);
        }

        [HttpGet]
        [Route("~/batch-details")]
        [TimeZoneFliter]
        public ActionResult Batchlist()
        {
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);

            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

            var timeOffSet = zone.Id;
            Session["zoneId"] = timeOffSet;
            return View();
        }
        public static int GetIso8601WeekOfYear(DateTime time)
        {
            // Seriously cheat.  If its Monday, Tuesday or Wednesday, then it'll 
            // be the same week# as whatever Thursday, Friday or Saturday are,
            // and we always get those right
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(time);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                time = time.AddDays(3);
            }

            // Return the week of our adjusted day
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(time, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        static DateTime YearWeekDayToDateTime(int year, DayOfWeek day, int week)
        {
            DateTime startOfYear = new DateTime(year, 1, 1);

            // The +7 and %7 stuff is to avoid negative numbers etc.
            int daysToFirstCorrectDay = (((int)day - (int)startOfYear.DayOfWeek) + 7) % 7;
            return startOfYear.AddDays(7 * (week - 1) + daysToFirstCorrectDay);
        }


        static string GetBatchDays(string BatchDays, TimeSpan time1, DateTime day1, int addHours, string countryZone = null)
        {
            if (BatchDays != null)
            {
                var batchDays = BatchDays.Split(',');
                string batch = string.Empty;
                int week = GetIso8601WeekOfYear(day1);

                foreach (var item in batchDays)
                {
                    DayOfWeek day = DayOfWeek.Sunday;
                    switch (item.ToString())
                    {
                        case "0":
                            day = DayOfWeek.Monday;
                            break;
                        case "1":
                            day = DayOfWeek.Tuesday;
                            break;
                        case "2":
                            day = DayOfWeek.Wednesday;
                            break;
                        case "3":
                            day = DayOfWeek.Thursday;
                            break;
                        case "4":
                            day = DayOfWeek.Friday;
                            break;
                        case "5":
                            day = DayOfWeek.Saturday;
                            break;
                        case "6":
                            day = DayOfWeek.Sunday;
                            break;
                    }
                    DateTime batchdate = YearWeekDayToDateTime(DateTime.UtcNow.Year, day, week);
                    batchdate = batchdate.Add(time1);
                    if (batch == string.Empty)
                    {
                        batch = batchdate.ToClientTimeDate1(countryZone.ToString(), addHours).DayOfWeek.ToString();
                    }
                    else { batch = batch + "," + batchdate.ToClientTimeDate1(countryZone.ToString(), addHours).DayOfWeek.ToString(); }
                }
                return batch;
            }
            return "";
        }

        [HttpGet]
        [TimeZoneFliter]
        public ActionResult BatchDetailsList(string countryZone = null)
        {
            var SelectedZone = countryZone;//.Replace(":", "");
            var defaultzone = HttpContext.Session["timezoneoffset"].ToString();
            double minutes2 = Convert.ToDouble(defaultzone);

            int week = GetIso8601WeekOfYear(DateTime.UtcNow);
            IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
            var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();

            var timeOffSet = zone.Id;
            Session["zoneId"] = timeOffSet;
            ViewBag.timeOffSet = timeOffSet;
            if (countryZone != null && countryZone != "")
            {
                timeOffSet = countryZone;
            }

            string currency = "";
            if (timeOffSet == "India Standard Time")
            {
                RegionInfo ri = new RegionInfo("en-IN");
                currency = ri.ISOCurrencySymbol;
            }
            else
            {
                RegionInfo ri = new RegionInfo("en-US");
                currency = ri.ISOCurrencySymbol;
            }
            IEnumerable<BatchMasterDTO> model = UOF.ICommonLogic.GetBatchesUpcomingDetailsList(currency);

            try
            {
                if (model.Count() != 0 && model != null)
                {
                    int addHours = 0;
                    var IsDayLight = UOF.IAppSetting.GetByAppKey("IS_DAY_LIGHT");
                    if (IsDayLight != null)
                    {
                        addHours = IsDayLight.AppValue == "0" ? 0 : 1;
                    }
                    model = model.Select(x =>
                    {
                        x.StartDate = x.StartDate.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                        x.BatchDays = GetBatchDays(x.BatchDays, x.BatchTiming.TimeOfDay, x.StartDate, addHours, timeOffSet.ToString());
                        x.EndDate = x.EndDate.Value.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                        x.DispStartDate = x.StartDate.ToClientTime1(timeOffSet.ToString(), addHours);
                        x.DispEndDate = x.EndDate.Value.ToClientTime1(timeOffSet.ToString(), addHours);
                        x.BatchTiming = x.BatchTiming.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                        x.BatchStartTimingDisplay = x.BatchTiming.ToString("MM/dd/yyyy HH:mm");
                        x.BatchEndTiming = x.BatchEndTiming.ToClientTimeDate1(timeOffSet.ToString(), addHours);
                        x.BatchEndTimingDisplay = x.BatchEndTiming.ToString("MM/dd/yyyy HH:mm");

                        return x;
                    });
                    ViewBag.flag = "1";
                    return Json(model, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception)
            {
                return Json(new { msg = "false" }, JsonRequestBehavior.AllowGet);
            }

        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult PopUpBatchEnquiry(int courseid, int modeid)
        {
            return View();
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult BatchEnquiry(int id = 0)
        {
            QueryDTO queryModel = new QueryDTO();

            queryModel.CourseList = GetAllCoursesList();
            queryModel.CourseId = id;

            //Bind Training Mode
            List<TrainingMode> trainingModeList = UOF.ICommonLogic.GetTrainingModeList();
            queryModel.TrainingModeList = trainingModeList;

            //Subject
            return PartialView("_BatchEnquiry", queryModel);
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult _Testimonial(int cid = 0)
        {
            string key = "Testimonial" + cid;
            List<TestimonialDTO> model = UOF.ICommonLogic.GetRecentTestimonialDetails(cid);
            if (model.Count() == 0)
            {
                model = UOF.ICommonLogic.GetRecentTestimonialDetails(0);
            }
            return PartialView("_Testimonial", model);
        }

        [ChildActionOnly]
        [HttpGet]
        [OutputCache(Duration = (int)CacheDuration.FullDay)]
        public ActionResult _TestimonialMaster(int cid = 0)
        {
            List<TestimonialDTO> model = UOF.ICommonLogic.GetRecentTestimonialDetails(cid);
            if (model.Count() == 0)
            {
                model = UOF.ICommonLogic.GetRecentTestimonialDetails(0);
            }
            return PartialView("_TestimonialMaster", model);
        }
        [Route("~/reviews/{id:int?}")]
        public ActionResult Testimonials(int id = 1)
        {
            TempData["flag"] = "true"; //For hiding testimonial slider
            PagingDTO<TestimonialDTO> model = new PagingDTO<TestimonialDTO>();
            model = UOF.ICommonLogic.GetTestimonialList(id, pageSize);
            if (model != null)
            {
                int totalTestimonialCount = UOF.ICommonLogic.GetTotalMemberForTestimonial();
                return View(model);
            }
            else { return RedirectToAction("Index", "Home"); }

        }

        [Route("~/GetAllTestimonialist/{page:int}")]
        [HttpPost]
        public ActionResult GetAllTestimonialist(int page)
        {
            try
            {
                PagingDTO<TestimonialDTO> model = new PagingDTO<TestimonialDTO>();
                model = UOF.ICommonLogic.GetTestimonialList(page, pageSize);

                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }

        public ActionResult _Ads(int CatId = 0, string AdsName = "", string type = "")
        {
            AdsMastersDTO model = new AdsMastersDTO();
            model = UOF.ICommonLogic.GetAdsByCategory(CatId, AdsName, type);
            return PartialView("_Ads", model);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult SidebarBatchesDetails()
        {
            string key = "batchlist";
            var cachedata = CacheService.GetCacheList<BatchMasterDTO>(key);
            if (cachedata == null)
            {
                IEnumerable<BatchMasterDTO> data = UOF.ICommonLogic.GetBatchesDetailsList();
                cachedata = CacheService.SetCacheList<BatchMasterDTO>(key, data, (int)CacheDuration.FullDay);
            }
            return PartialView("_SidebarBatchesDetails", cachedata);
        }

        [Route("~/jobs")]
        public ActionResult Jobs(int page = 1)
        {
            TempData["flag"] = "true";
            PagingDTO<Job> model = new PagingDTO<Job>();
            model = UOF.IJob.GetJobDetails(page, pageSizeJobs);
            model.AllJobListActive = UOF.IJob.GetJobDetails().Where(x => x.ExpiryDate >= DateTime.Now).ToList();
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageSizeJobs;
            }
            return View(model);
        }

        public ActionResult GetJobs(int page)
        {
            TempData["flag"] = "true";
            PagingDTO<Job> model = UOF.IJob.GetJobDetails(page, pageSizeJobs);
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageSizeJobs;
            }
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        [Route("~/jobs/detail/{id:int}")]
        public ActionResult JobDetail(int id = 0)
        {
            TempData["flag"] = "true";
            Job model = UOF.IJob.GetJobById(id);
            return View(model);
        }

        [Route("~/ourTeam")]
        public ActionResult OurTeam(int id = 1)
        {
            TempData["flag"] = "true"; //For hiding testimonial slider
            List<TestimonialDTO> model = new List<TestimonialDTO>();
            model = UOF.ICommonLogic.GetTestimonialLists(id, pageSize);
            if (model.Count != 0)
            {
                int totalTestimonialCount = UOF.ICommonLogic.GetTotalMemberForTestimonial();
                PagingDTO<TestimonialDTO> obj = new PagingDTO<TestimonialDTO>();

                obj.Data = model;
                obj.Page = id;
                obj.PageSize = Convert.ToInt32(Math.Ceiling((double)totalTestimonialCount / pageSize));
                //ViewBag.testimonialid = testimonialid;
                return View(obj);
            }
            else { return RedirectToAction("Index", "Home"); }
        }

        public PartialViewResult _JobApply(int Id)
        {
            try
            {
                Job model = UOF.IJob.GetJobById(Id);
                return PartialView("_JobApply", model);
            }
            catch (Exception)
            {
                throw;
            }
        }
        public ActionResult ApplyJob(Job model, string UsrName, string Email, string Contact, HttpPostedFileBase file)
        {
            try
            {
                string pathurl = "";
                //TO CHECK FIle Permission issue
                //if (file != null && file.ContentLength > 0)
                //{
                //    var fileName = Path.GetFileName(file.FileName); //file name  
                //    var ext = Path.GetExtension(file.FileName); //getting the extension(ex-.jpg)  

                //    string name1 = Path.GetFileNameWithoutExtension(fileName);
                //    string myfile = name1 + ext;

                //    string _tempFolderLocation;
                //    _tempFolderLocation = ConfigurationManager.AppSettings["tempFolderLocation"].ToString();

                //    string path = Path.Combine(Server.MapPath(_tempFolderLocation), myfile);
                //    pathurl = _tempFolderLocation + myfile;

                //    string directoryPath = Server.MapPath(string.Format("~/{0}/", _tempFolderLocation));

                //    if (!Directory.Exists(directoryPath))
                //    {
                //        Directory.CreateDirectory(directoryPath);
                //    }
                //    file.SaveAs(path);
                //}
                //else
                //{
                //    pathurl = "";
                //}
                UOF.IJob.SaveAppliedJob(model, UsrName, Email, Contact);
                MailClient.SendMail_job(model, UsrName, Email, Contact, pathurl);
                TempData["Message"] = "Congratulation, You have been successfully applied for given Job!";
                return RedirectToAction("JobDetail", new { id = model.JobId });
            }
            catch (Exception ex) { }
            return RedirectToAction("Jobs");
        }

        [HttpPost]
        public JsonResult getNewotp(ContactDTO model)
        {
            try
            {
                string datanew = new Random().Next(1000, 9999).ToString();
                string data = "$143!" + datanew + "dnt8546n";
                if (data != "")
                {
                    string msg = "Your OTP for Dot Net Tricks is " + datanew;
                    Session["data"] = data;

                    try
                    {
                        if (model.code == "+91-")
                        {
                            sms.SendEnquiryInfo(msg, model.ContactNo);
                        }

                        MailClient.SendMail_OtpCont(model, datanew);
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    return Json(new { msg = "done" }, JsonRequestBehavior.AllowGet);
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }


            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public JsonResult VerifyOtpcont(string OTPContText)
        {
            try
            {
                string sess = Session["data"].ToString();
                if (!string.IsNullOrEmpty(sess))
                {
                    string[] temp = sess.Split('!');
                    var data = temp[1].Substring(0, 4);
                    if (data == OTPContText)
                    {

                        ModelState.Clear();
                        Session["data"] = "";
                        return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);

                    }
                }
                else { return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet); }
            }
            catch (Exception ex)
            {
                return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
            }

            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveVideoEnquiry(DownloadSyllabusDTO model)
        {
            try
            {
                model.DName = CurrentUser.Name;
                model.DEmailID = CurrentUser.Email;
                model.DCity = CurrentUser.CurrentLocation;
                model.DContactNo = CurrentUser.MobileNo;
                model.msg = "Watching video";
                int count = UOF.IQuery.CheckEnquiryExistence(model);

                if (count == 0)
                {
                    if (CurrentUser != null)
                    {
                        UOF.IQuery.SaveDownloadEnquiryForVideo(model);
                    }
                    ModelState.Clear();

                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }

                else
                {
                    return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
                }

            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [Route("~/scholarship-for-students")]
        public ActionResult Scholarship()
        {
            ViewBag.CourseList = UOF.ICommonLogic.GetCourseList();
            return View();
        }
        [ChildActionOnly]
        [HttpGet]
        public ActionResult ScholarshipEnquiry()
        {
            Scholarship contactModel = new Scholarship();
            //Subject
            ViewBag.CourseList = UOF.ICommonLogic.GetCourseList();
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_ScholarshipEnquiry", contactModel);
        }


        [HttpPost]
        public JsonResult SaveScholarshipEnquiry(Scholarship model)
        {
            try
            {
                int count = UOF.IQuery.GetScholarshipCount(model);
                if (count == 0)
                {
                    UOF.IQuery.SaveScholarshipForm(model);
                    try
                    {
                        MailClient.SendMail_Scholarship(model);
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [ChildActionOnly]
        [HttpGet]
        public ActionResult DevelopmentEnquiry()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.Subject = "Development Enq:-";
            ViewBag.btnTitle = "SUBMIT QUERY";
            return PartialView("_CommonEnquiry", contactModel);
        }

        [Route("~/software-consulting-services")]
        public ActionResult Development()
        {
            TempData["flag"] = "true";
            return View();
        }

        [Route("~/technical-recruiting-service")]
        public ActionResult Recruiting()
        {
            TempData["flag"] = "true";
            return View();
        }

        [HttpPost]
        public JsonResult SaveCorporateEnquiry(CorporateEnquiry model)
        {
            try
            {
                int count = UOF.IQuery.GetCorporateCount(model);
                if (count == 0)
                {
                    UOF.IQuery.SaveCorporateForm(model);
                    UOF.IQuery.SendCorporateMsg(model);
                    try
                    {

                        MailClient.SendMail_Corporate(model);
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                }
                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save_Technical_RecruitersEnquiry(PostJobs model)
        {
            try
            {
                UOF.IQuery.SaveTechnicalRecruitersEnquiry(model);
                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }


        [Route("~/certificate/verify")]
        public ActionResult Certificate()
        {
            TempData["flag"] = "true";
            Session["dataId"] = "";
            return View();
        }
        [HttpGet]
        public JsonResult CheckCertificatecode(string Certificatecode)
        {
            try
            {
                var data = UOF.ICourse.CheckCertificatecode(Certificatecode);
                if (data != null)
                {
                    Session["dataId"] = data.Id;
                    ModelState.Clear();
                    return Json(new { msg = "success", data }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    Session["dataId"] = "";
                }
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PrintCertificate()
        {
            try
            {
                var id1 = Session["dataId"].ToString();
                if (id1 != "")
                {
                    var id = Convert.ToInt64(id1);
                    CertificateMaster data = UOF.ICourse.getCertificateView(id);
                    return RedirectToAction("CertificateForPrint", data);
                }
                else
                {
                    return RedirectToAction("Certificate");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("Certificate");
            }
        }

        public ActionResult CertificateForPrint(CertificateMaster data1)
        {
            try
            {
                CertificateMaster data = UOF.ICourse.getCertificateView(data1.Id);
                Session["dataId"] = "";
                if (data.IssueDate != null)
                {
                    var d = data.IssueDate.Day;
                    string d2d = d.ToString();
                    string daySuffix =
                        (data.IssueDate.Day == 11 || data.IssueDate.Day == 12 || data.IssueDate.Day == 13) ? "th"
                        : (d2d == "1") ? "st"
                        : (d2d == "2") ? "nd"
                        : (d2d == "3") ? "rd"
                        : "th";
                    data.disIssueDate = d2d + "<sup>" + daySuffix + "</sup>";
                }
                return new Rotativa.ViewAsPdf("CertificateForPrint", data)
                {
                    FileName = data.Name + "_" + data.CourseName + ".pdf",
                    PageMargins = new Rotativa.Options.Margins(1, 1, 0, 0),
                    PageOrientation = Rotativa.Options.Orientation.Landscape,
                };

            }
            catch (Exception w)
            {
            }
            return RedirectToAction("Certificate");
        }

        [Route("~/become-an-author")]
        public ActionResult BecomeAnAuthor()
        {
            TempData["flag"] = "true";
            return View();
        }

        [HttpGet]
        public ActionResult BecomeAuthor()
        {
            Contact contactModel = new Contact();
            //Subject
            contactModel.isauthor = "true";
            contactModel.Subject = "BecomeAuthor:-";
            ViewBag.btnTitle = "Apply Now";
            return PartialView("_CommonEnquiry", contactModel);
        }

        [Route("~/sitemap")]
        public ActionResult SiteMap()
        {
            ViewBag.coursemenu = UOF.ICommonLogic.GetCategorywiseMenuList();
            ViewBag.quizlist = UOF.IQuestionMaster.GetAllQuiz();
            return View();
        }

        [Route("~/articles-of-the-month")]
        public ActionResult MonthlyArticles()
        {
            TempData["flag"] = "true";
            List<VoteMasterDTO> model = new List<VoteMasterDTO>();
            model = UOF.ITutorial.GetallArticlesList();
            ViewBag.Mid = model != null ? model.Select(x => x.MID).FirstOrDefault() : 0;
            ViewBag.OldArticleWithMedal = UOF.ITutorial.GetallOldMedalArticlesList();
            return View(model);
        }
        public JsonResult AddVoteToArticleByAjax(string vid = "", int mid = 0)
        {
            try
            {
                int stat = 0;
                if (vid != "")
                {
                    if (CurrentUser != null)
                    {
                        stat = UOF.ITutorial.AddVoteToArticleByAjax(vid, CurrentUser.UserId, mid);
                    }
                }
                return Json(stat, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            { }
            return Json(null);
        }


        [Route("~/mentors")]
        public ActionResult Mentors(int page = 1)
        {
            TempData["flag"] = "true";
            int pageMentor = 20;
            PagingDTO<MentorMaster> model = new PagingDTO<MentorMaster>();
            model = UOF.IMentorMaster.GetMentorsDetails(page, pageMentor);
            if (model != null)
            {
                ViewBag.page = model.Page;
                ViewBag.pageCount = pageMentor;
            }
            return View(model);
        }

        [Route("getMentorlist/{page:int}")]
        public ActionResult GetMentorlist(int page)
        {
            try
            {
                int pageMentor = 20;
                PagingDTO<MentorMaster> model = new PagingDTO<MentorMaster>();
                model = UOF.IMentorMaster.GetMentorsDetails(page, pageMentor);
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }

        }

        [HttpPost]
        public JsonResult SaveMasterCallBack(QueryDTO model)
        {
            try
            {
                int count = UOF.IQuery.GetEnquiryCount(model);
                if (count == 0)
                {
                    model.Name = "N/A";
                    model.Message = "Curriculum";
                    model.TrainingModeId = (int)EnumTrainingMode.Online;
                    UOF.IQuery.SaveQuery(model);
                    try
                    {
                        //   MailClient.SendMail_Enquiry(model);
                    }
                    catch (Exception ex)
                    {
                    }
                    return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
                }

                ModelState.Clear();
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveSkillsProfile(string[] skill, string[] Expertise)
        {
            try
            {
                Int64 memberId = CurrentUser.UserId;
                UOF.IMember.SaveSkillsProfile(skill, Expertise, memberId);
                return Json(new { msg = "success" }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {

            }
            return Json(new { msg = "fail" }, JsonRequestBehavior.AllowGet);
        }
    }
}