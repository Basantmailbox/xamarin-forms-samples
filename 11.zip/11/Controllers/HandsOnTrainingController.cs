﻿using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class HandsOnTrainingController : Controller
    {
        [Route("~/hands-on-training")]
        public ActionResult Index()
        {
            return View();
        }

        [Route("~/handson/noida/hands-on-training-program")]
        public ActionResult HandsOnTrainingNoida()
        {
            return View();
        }       
    }
}
