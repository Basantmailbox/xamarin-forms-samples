﻿using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class CampusTrainingController : Controller
    {
        [Route("~/campus-training")]
        public ActionResult Index()
        {
            return View();
        }

        [Route("~/campus/noida/campus-training-program")]
        public ActionResult CampusTrainingNoida()
        {
            return View();
        }       
    }
}
