﻿using System.Web.Mvc;

namespace DotNetTricks.COM.Controllers
{
    public class ErrorController : Controller
    {
        [Route("~/error/index")]
        public ActionResult Index()
        {
            TempData["flag"] = "true"; 
            return View();
        }

        [Route("~/error/notfound")]
        public ActionResult NotFound()
        {
            TempData["flag"] = "true";
            return View();
        }
    }
}
