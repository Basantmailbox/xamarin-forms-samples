﻿using DNTData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Syndication;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace DotNetTricks.COM.Controllers
{
    public class FeedResult : ActionResult
    {
        public Encoding ContentEncoding { get; set; }
        public string ContentType { get; set; }

        private readonly SyndicationFeedFormatter feed;
        public SyndicationFeedFormatter Feed
        {
            get { return feed; }
        }

        public FeedResult(SyndicationFeedFormatter feed)
        {
            this.feed = feed;
        }

        public override void ExecuteResult(ControllerContext context)
        {
            if (context == null)
                throw new ArgumentNullException("context");

            HttpResponseBase response = context.HttpContext.Response;
            response.ContentType = !string.IsNullOrEmpty(ContentType) ? ContentType : "application/rss+xml";

            if (ContentEncoding != null)
                response.ContentEncoding = ContentEncoding;

            if (feed != null)
                using (var xmlWriter = new XmlTextWriter(response.Output))
                {
                    xmlWriter.Formatting = Formatting.Indented;
                    feed.WriteTo(xmlWriter);
                }
        }
    }

    public class RssFeedController : Controller
    {
        public ActionResult Index()
        {
            DataContext mobjentity = new DataContext();

            var postItems = mobjentity.Tutorials.Where(t => t.IsActive == true).OrderByDescending(p => p.PostedDate).Take(25)
                .Select(p => new { p.Title, p.ShortDescription, Url = "https://www.dotnettricks.com" + p.ArticleUrl });

            List<SyndicationItem> FeedList = new List<SyndicationItem>();
            foreach (var item in postItems)
            {
                FeedList.Add(new SyndicationItem(item.Title, item.ShortDescription.Replace("<p>", "").Replace("</p>", ""), new Uri(item.Url)));
            }

            string strCopyright = "© " + DateTime.Now.Year.ToString() + " copyrights reserved";

            var feed = new SyndicationFeed("Dot Net Tricks", "Master in-demand job skills with linear and project-based courses. Dot Net Tricks offers the interactive learning platform that helps the professionals to earn a valuable hands-on experience and start a amazing career in .NET, JavaScript, Cloud, DevOps, Big Data, ML, AI, Mobile development, Digital marketing and more.", new Uri("https://www.dotnettricks.com"), FeedList)
            {
                Copyright = new TextSyndicationContent(strCopyright),
                Language = "en-US"
            };

            return new FeedResult(new Rss20FeedFormatter(feed));
        }
    }
}
