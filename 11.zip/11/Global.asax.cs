﻿using DNTWebCore;
using DotNetTricks.COM;
using DotNetTricks.COM.App_Start;
using DotNetTricks.COM.Security;
using Newtonsoft.Json;
using System;
using System.Configuration;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace DNTWebUI
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            //Remove All Engine
            ViewEngines.Engines.Clear();
            //Add Customize Razor C# Engine
            ViewEngines.Engines.Add(new RazorCSharpViewEngine());

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            //GlobalConfiguration.Configure(WebApiConfig.Register);
            BundleTable.EnableOptimizations = true;
        }

        protected void Application_PostAuthenticateRequest(Object sender, EventArgs e)
        {
            HttpCookie authCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket authTicket = FormsAuthentication.Decrypt(authCookie.Value);

                if (!authTicket.Expired) //check for ticket expiration
                {
                    CustomPrincipalSerializeModel serializeModel = JsonConvert.DeserializeObject<CustomPrincipalSerializeModel>(authTicket.UserData);
                    CustomPrincipal newUser = new CustomPrincipal(authTicket.Name);

                    newUser.UserId = serializeModel.UserId;
                    newUser.Name = serializeModel.Name;
                    newUser.Email = serializeModel.Email;
                    newUser.MobileNo = serializeModel.MobileNo;
                    newUser.Roles = serializeModel.Roles;
                    newUser.CurrentLocation = serializeModel.CurrentLocation;
                    newUser.ProfilePic = serializeModel.ProfilePic;
                    newUser.ProfilePicDomain = serializeModel.ProfilePicDomain;
                    newUser.MembershipId = serializeModel.MembershipId;
                    newUser.MembershipExpiry = serializeModel.MembershipExpiry;

                    HttpContext.Current.User = newUser;
                }
                else
                {
                    FormsAuthentication.SignOut();
                    Response.Redirect("~/member-login");
                }
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            #region[Force HTTPS]
            var uri = HttpContext.Current.Request.Url;
            if (uri.Authority != null && uri.Authority.Contains("dotnettricks.com"))
            {
                try
                {
                    var addHstsHeader = true;
                    if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["HSTSHeader"]))
                        bool.TryParse(ConfigurationManager.AppSettings["HSTSHeader"], out addHstsHeader);
                    if (addHstsHeader && HttpContext.Current.Request.IsSecureConnection)  //Add HSTS header in respose
                    {
                        Response.AddHeader("Strict-Transport-Security", "max-age=2592000");//30 days
                    }
                    else if (!HttpContext.Current.Request.IsSecureConnection) //Redirect to https link
                    {
                        HttpContext.Current.Response.Clear();
                        HttpContext.Current.Response.Redirect($"https://{uri.Authority}{uri.PathAndQuery}");
                    }
                }
                catch (Exception ex)
                { }
            }
            #endregion

            string baseUrl = "https://www.dotnettricks.com"; //for old site
            string url = Request.Url.AbsoluteUri;
            string redirectUrl = "";

            if (!string.IsNullOrEmpty(url))
            {
                url = url.ToLowerInvariant();
            }

            switch (url)
            {
                case "https://www.dotnettricks.com/self-paced-courses":
                case "http://www.dotnettricks.com/self-paced-courses":
                    redirectUrl = "https://www.dotnettricks.com/courses";
                    break;

                case "https://www.dotnettricks.com/home/contactus":
                    redirectUrl = "https://www.dotnettricks.com/contact-us";
                    break;
                case "https://www.dotnettricks.com/home/aboutus":
                    redirectUrl = "https://www.dotnettricks.com/about-us";
                    break;

                case "https://www.dotnettricks.com/become-a-mentor":
                    redirectUrl = "https://www.dotnettricks.com/become-an-instructor";
                    break;
                case "https://www.dotnettricks.com/skill-challenge":
                    redirectUrl = "https://www.dotnettricks.com/skill-tests";
                    break;
                //Start Courses
                case "https://www.dotnettricks.com/training/mvc-development":
                case "https://www.dotnettricks.com/training/asp-net-mvc-development":
                    redirectUrl = "https://www.dotnettricks.com/training/the-complete-aspnet-mvc";
                    break;
                case "https://www.dotnettricks.com/training/asp-net-core-development":
                    redirectUrl = "https://www.dotnettricks.com/training/the-complete-aspnet-core";
                    break;
                case "https://www.dotnettricks.com/training/microsoft-azure-certification":
                case "https://www.dotnettricks.com/training/implementing-microsoft-azure-infrastructure-solutions":
                    redirectUrl = "https://www.dotnettricks.com/training/masters-program/microsoft-azure";
                    break;
                case "https://www.dotnettricks.com/training/android":
                case "https://www.dotnettricks.com/training/details/android-development":
                    redirectUrl = "https://www.dotnettricks.com/training/android-development";
                    break;
                case "https://www.dotnettricks.com/training/angularjs":
                case "https://www.dotnettricks.com/training/angular-development":
                    redirectUrl = "https://www.dotnettricks.com/training/masters-program/angular";
                    break;
                case "https://www.dotnettricks.com/training/dotnet":
                    redirectUrl = "https://www.dotnettricks.com/training/dotnet-development";
                    break;
                case "https://www.dotnettricks.com/training/mvcangularjs":
                case "https://www.dotnettricks.com/training/mvcangularjs-development":
                case "https://www.dotnettricks.com/training/details/mvc-development":
                case "https://www.dotnettricks.com/training/mvc-angularjs-development":
                    redirectUrl = "https://www.dotnettricks.com/training/masters-program/mvc-angular";
                    break;
                case "https://www.dotnettricks.com/training/react-redux-development":
                    redirectUrl = "https://www.dotnettricks.com/training/masters-program/react-redux";
                    break;
                case "https://www.dotnettricks.com/training/hybridapps":
                case "https://www.dotnettricks.com/training/details/hybrid-apps-development":
                    redirectUrl = "https://www.dotnettricks.com/training/hybrid-apps-development";
                    break;
                case "https://www.dotnettricks.com/training/hadoop":
                    redirectUrl = "https://www.dotnettricks.com/training/bigdata-hadoop-development-cum-administration";
                    break;
                case "https://www.dotnettricks.com/training/java":
                case "https://www.dotnettricks.com/training/details/java-j2ee-development":
                    redirectUrl = "https://www.dotnettricks.com/training/java-j2ee-development";
                    break;
                case "https://www.dotnettricks.com/training/mean":
                case "https://www.dotnettricks.com/training/details/mean-stack-development":
                case "https://www.dotnettricks.com/training/details/training/mean-stack-development":
                case "https://www.dotnettricks.com/training/mean-stack-development":
                    redirectUrl = "https://www.dotnettricks.com/training/masters-program/mean-stack-development";
                    break;
                case "https://www.dotnettricks.com/training/wcf":
                    redirectUrl = "https://www.dotnettricks.com/training/wcf-development";
                    break;
                case "https://www.dotnettricks.com/training/javascript-fundamentals":
                    redirectUrl = "https://www.dotnettricks.com/training/javascript-essentials";
                    break;
                case "https://www.dotnettricks.com/training/csharp-fundamentals":
                    redirectUrl = "https://www.dotnettricks.com/training/csharp-essentials";
                    break;
                case "https://www.dotnettricks.com/training/linq-fundamentals":
                    redirectUrl = "https://www.dotnettricks.com/training/linq-essentials";
                    break;
                case "https://www.dotnettricks.com/training/typescript-fundamentals":
                    redirectUrl = "https://www.dotnettricks.com/training/typescript-essentials";
                    break;
                case "https://www.dotnettricks.com/training/nodejs":
                    redirectUrl = "https://www.dotnettricks.com/training/nodejs-development";
                    break;
                case "https://www.dotnettricks.com/training/details/advanced-csharp-development":
                case "https://www.dotnettricks.com/training/dotnet-development":
                    redirectUrl = "https://www.dotnettricks.com/training/csharp-essentials";
                    break;
                case "https://www.dotnettricks.com/training/the-complete-aws-cloud-platform":
                    redirectUrl = "https://www.dotnettricks.com/training/the-complete-aws-solution-architect";
                    break;
                case "https://www.dotnettricks.com/training/the-complete-aspnet-mvc":
                    redirectUrl = "https://www.dotnettricks.com/training/the-complete-aspnet-mvc-angularjs";
                    break;
                case "https://www.dotnettricks.com/learn/visualstudio/visual-studio-2008-2010-2011-2012-keyboard-shortcuts-keys":
                    redirectUrl = "https://www.dotnettricks.com/learn/visualstudio/visual-studio-useful-keyboard-shortcut-keys";
                    break;

                //End Courses
                case "https://www.dotnettricks.com/learn/angularjs/understanding-ng-repeat-special-variables-":
                    redirectUrl = "https://www.dotnettricks.com/learn/angularjs/understanding-ng-repeat-special-variables";
                    break;
                case "https://www.dotnettricks.com/learn/css/css-to-show-only-horizontal-and-vertical-scroll-bar-in-div":
                    redirectUrl = "https://www.dotnettricks.com/learn/stylesheet/css-to-show-only-horizontal-and-vertical-scroll-bar-in-div";
                    break;
                case "https://www.dotnettricks.com/learn/css/css-to-force-long-text-and-urls-to-wrap-on-all-browser":
                    redirectUrl = "https://www.dotnettricks.com/learn/stylesheet/css-to-force-long-text-and-urls-to-wrap-on-all-browser";
                    break;
                case "https://www.dotnettricks.com/learn/css/css-inline-block-and-none-display-style":
                    redirectUrl = "https://www.dotnettricks.com/learn/stylesheet/css-inline-block-and-none-display-style";
                    break;
                case "https://www.dotnettricks.com/learn/csharp/introduction-to-csharp-sharp":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/introduction-to-csharp";
                    break;
                case "https://www.dotnettricks.com/learn/css/html-color-codes":
                    redirectUrl = "https://www.dotnettricks.com/learn/stylesheet/html-color-codes";
                    break;
                case "https://www.dotnettricks.com/learn/css/introduction-to-css":
                    redirectUrl = "https://www.dotnettricks.com/learn/stylesheet/introduction-to-css";
                    break;

                case "https://www.dotnettricks.com/blogs/craigbowesblog/archive/2008/12/10/720.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/Downloads/tabid/57/Default.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/craigbowesblog/archive/2006/09/09/105.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/craigbowesblog/archive/2009/05/06/742.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/48.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/craigbowesblog/archive/2005/10/01/39.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/craigbowesblog/archive/2006/04/13/46.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/andrewcainblog/archive/2006/04/18/ELMAH_for_ASPNET2_0.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/roberhinojosablog/archive/2006/11/08/113.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/roberhinojosablog":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/blogs/craigbowesblog/archive/2009/02/14/739.aspx":
                    redirectUrl = "https://www.dotnettricks.com";
                    break;
                case "https://www.dotnettricks.com/industrial-training":
                    redirectUrl = "https://www.dotnettricks.com/6-month-industrial-training";
                    break;
                case "https://www.dotnettricks.com/industrial-training/noida/six-months-dot-net":
                    redirectUrl = "https://www.dotnettricks.com/industrial/noida/six-months-dot-net-training";
                    break;
                case "https://www.dotnettricks.com/industrial-training/noida/six-months-android":
                    redirectUrl = "https://www.dotnettricks.com/industrial/noida/six-months-android-training";
                    break;

                case "https://www.dotnettricks.com/industrial-training/noida/six-months-seo-ppc":
                    redirectUrl = "https://www.dotnettricks.com/industrial/noida/six-months-seo-ppc-training";
                    break;
                case "https://www.dotnettricks.com/industrial-training/noida/six-months-mean":
                    redirectUrl = "https://www.dotnettricks.com/industrial/noida/six-months-mean-training";
                    break;

                case "https://www.dotnettricks.com/learn/windowsazure/understanding-cloud-computing-and-windows-azure":
                    redirectUrl = "https://www.dotnettricks.com/learn/azure/understanding-cloud-computing-and-microsoft-azure";
                    break;
                case "https://www.dotnettricks.com/learn/windowsazure":
                    redirectUrl = "https://www.dotnettricks.com/learn/azure";
                    break;
                case "https://www.dotnettricks.com/learn/hybridmobileapps/understanding-mobile-apps-development-options":
                    redirectUrl = "https://www.dotnettricks.com/ionic/hybridmobileapps/understanding-mobile-apps-development-options";
                    break;
                case "https://www.dotnettricks.com/learn/windowsazure/understanding-components-of-windows-azure":
                case "https://www.dotnettricks.com/learn/azure/understanding-microsoft-azure-services":
                    redirectUrl = "https://www.dotnettricks.com/learn/azure/getting-started-with-microsoft-azure-platform";
                    break;

                case "https://www.dotnettricks.com/learn/windowsphoneapps/how-to-enable-the-computer-keyboard-for-windows-phone-8-emulator":
                    redirectUrl = "https://www.dotnettricks.com/learn/cswinapps/how-to-enable-the-computer-keyboard-for-windows-phone-8-emulator";
                    break;
                case "https://www.dotnettricks.com/learn/windowsphoneapps/onetime-oneway-and-twoway-binding-for-windows-phone":
                    redirectUrl = "https://www.dotnettricks.com/learn/cswinapps/onetime-oneway-and-twoway-binding-for-windows-phone";
                    break;
                case "https://www.dotnettricks.com/learn/windowsphoneapps/hello-world-windows-phone-8-app":
                    redirectUrl = "https://www.dotnettricks.com/learn/cswinapps/hello-world-windows-phone-8-app";
                    break;
                case "https://www.dotnettricks.com/learn/windowsphoneapps/windows-phone-8-emulator-configuration":
                    redirectUrl = "https://www.dotnettricks.com/learn/cswinapps/windows-phone-8-emulator-configuration";
                    break;
                case "https://www.dotnettricks.com/learn/windowsphoneapps/a-glimpse-into-windows-phone-sdk-80":
                    redirectUrl = "https://www.dotnettricks.com/learn/cswinapps/a-glimpse-into-windows-phone-sdk-80";
                    break;
                case "https://www.dotnettricks.com/learn/mvc6":
                    redirectUrl = "https://www.dotnettricks.com/learn/aspnetcore";
                    break;
                case "https://www.dotnettricks.com/-introduction-to-asp.net-vnext-and-mvc-6.html":
                case "https://www.dotnettricks.com/RnoSZ/TSnhZ/VdUlZ/WVnUZ/MVeTZ/Tutorial/mvc6/5R9E190514-Introduction-to-ASP.NET-vNext-and-MVC-6.html":
                case "https://www.dotnettricks.com/XmYiZ/YiUKZ/Tutorial/mvc6/5R9E190514-Introduction-to-ASP.NET-vNext-and-MVC-6.html":
                case "https://www.dotnettricks.com/learn/mvc6/introduction-to-aspnet-vnext-and-mvc-6":
                    redirectUrl = "https://www.dotnettricks.com/learn/aspnetcore/introduction-to-aspnet-core";
                    break;
                case "https://www.dotnettricks.com/skill-assessments":
                    redirectUrl = "https://www.dotnettricks.com/skill-challenge";
                    break;
                case "https://www.dotnettricks.com/Home/Testimonials":
                    redirectUrl = "https://www.dotnettricks.com/reviews";
                    break;
                case "https://www.dotnettricks.com/events/upcoming-events":
                    redirectUrl = "https://www.dotnettricks.com/events";
                    break;
                case "https://www.dotnettricks.com/events/past-events":
                    redirectUrl = "https://www.dotnettricks.com/events";
                    break;
                case "https://www.dotnettricks.com/software-development-services":
                    redirectUrl = "https://www.dotnettricks.com/software-consulting-services";
                    break;

                // Old Site Url :Start
                case "http://dotnet-tricks.com/index":
                case "http://dotnet-tricks.com/home/advertise":
                case "https://www.dotnet-tricks.com/home/advertise":
                case "https://www.dotnettricks.com/home/projects":
                case "https://www.dotnettricks.com/home/tools":
                    redirectUrl = "https://www.dotnettricks.com/";
                    break;
                case "https://www.dotnettricks.com/home/search":
                case "http://dotnet-tricks.com/home/search":
                    redirectUrl = "https://www.dotnettricks.com/search";
                    break;
                case "https://www.dotnettricks.com/home/nodejsinterviewbook":
                    redirectUrl = baseUrl + "/books/nodejs/interview";
                    break;
                case "https://www.dotnettricks.com/home/mvcinterviewbook":
                    redirectUrl = baseUrl + "/books/mvc/interview";
                    break;
                case "https://www.dotnettricks.com/home/linqinterviewbook":
                case "https://www.dotnet-tricks.com/home/linqinterviewbook":
                    redirectUrl = baseUrl + "/books/linq/interview";
                    break;
                case "https://www.dotnettricks.com/home/angularjsinterviewbook":
                    redirectUrl = baseUrl + "/books/angularjs/interview";
                    break;
                case "https://www.dotnettricks.com/home/dotnetinterviewbook":
                case "https://www.dotnettricks.com/Home/Interviewfaq":
                    redirectUrl = baseUrl + "/free-ebooks";
                    break;
                case "https://www.dotnettricks.com/home/about":
                    redirectUrl = baseUrl + "/about-shailendra-chauhan";
                    break;
                case "https://www.dotnettricks.com/stepbystep/home/archive":
                case "https://www.dotnettricks.com/home/archive": redirectUrl = baseUrl + "/learn"; break;
                case "https://www.dotnettricks.com/tutorial/aspnetlist":
                case "https://www.dotnettricks.com/tutorial/ajaxlist":
                case "https://www.dotnettricks.com/learn/ajax": redirectUrl = baseUrl + "/learn/aspnet"; break;
                case "https://www.dotnettricks.com/tutorial/adonetlist": redirectUrl = baseUrl + "/learn/adonet"; break;
                case "https://www.dotnettricks.com/tutorial/csharplist": redirectUrl = baseUrl + "/learn/csharp"; break;
                case "https://www.dotnettricks.com/tutorial/jquerymobilelist": redirectUrl = baseUrl + "/learn/jquerymobile"; break;
                case "https://www.dotnettricks.com/tutorial/entityframeworklist": redirectUrl = baseUrl + "/learn/entityframework"; break;
                case "https://www.dotnettricks.com/tutorial/fluentnhibernatelist": redirectUrl = baseUrl + "/learn/fluentnhibernate"; break;
                case "https://www.dotnettricks.com/tutorial/linqlist": redirectUrl = baseUrl + "/learn/linq"; break;
                case "https://www.dotnettricks.com/tutorial/mvclist": redirectUrl = baseUrl + "/learn/mvc"; break;
                case "https://www.dotnettricks.com/tutorial/nhibernatelist": redirectUrl = baseUrl + "/learn/nhibernate"; break;
                case "https://www.dotnettricks.com/tutorial/oopslist": redirectUrl = baseUrl + "/learn/oops"; break;
                case "https://www.dotnettricks.com/tutorial/backbonelist": redirectUrl = baseUrl + "/learn/backbone"; break;
                case "https://www.dotnettricks.com/tutorial/sqlserverlist": redirectUrl = baseUrl + "/learn/sqlserver"; break;

                case "https://www.dotnettricks.com/tutorial/angularjslist": redirectUrl = baseUrl + "/learn/angularjs"; break;
                case "https://www.dotnettricks.com/tutorial/tfslist": redirectUrl = baseUrl + "/learn/tfs"; break;
                case "https://www.dotnettricks.com/tutorial/visualstudiolist": redirectUrl = baseUrl + "/learn/visualstudio"; break;
                case "https://www.dotnettricks.com/tutorial/mongodblist": redirectUrl = baseUrl + "/learn/mongodb"; break;
                case "https://www.dotnettricks.com/tutorial/webservicelist":
                case "https://www.dotnettricks.com/learn/webservice":
                case "https://www.dotnettricks.com/tutorial/wcflist": redirectUrl = baseUrl + "/learn/wcf"; break;
                case "https://www.dotnettricks.com/tutorial/mvc6list": redirectUrl = baseUrl + "/learn/mvc6"; break;
                case "https://www.dotnettricks.com/tutorial/angularmaterialdesignlist": redirectUrl = baseUrl + "/learn/angularmaterialdesign"; break;
                case "https://www.dotnettricks.com/tutorial/hybridmobileappslist": redirectUrl = baseUrl + "/learn/hybridmobileapps"; break;
                case "https://www.dotnettricks.com/tutorial/jquerylist": redirectUrl = baseUrl + "/learn/jquery"; break;
                case "https://www.dotnettricks.com/tutorial/csslist": redirectUrl = baseUrl + "/learn/css"; break;
                case "https://www.dotnettricks.com/tutorial/javascriptlist": redirectUrl = baseUrl + "/learn/javascript"; break;
                case "https://www.dotnettricks.com/tutorial/clist": redirectUrl = baseUrl + "/learn/c	"; break;
                case "https://www.dotnettricks.com/tutorial/androidlist": redirectUrl = baseUrl + "/learn/android"; break;
                case "https://www.dotnettricks.com/tutorial/unittestinglist": redirectUrl = baseUrl + "/learn/unittesting"; break;
                case "https://www.dotnettricks.com/tutorial/netframeworklist": redirectUrl = baseUrl + "/learn/netframework"; break;
                case "https://www.dotnettricks.com/tutorial/phonegaplist": redirectUrl = baseUrl + "/learn/phonegap"; break;
                case "https://www.dotnettricks.com/tutorial/windowsphoneappslist":
                case "https://www.dotnet-tricks.com/Tutorial/windowsphoneappslist":
                case "https://www.dotnet-tricks.com/learn/windowsphoneapps":
                case "https://www.dotnettricks.com/tutorial/cswinappslist": redirectUrl = baseUrl + "/learn/cswinapps"; break;
                case "https://www.dotnettricks.com/tutorial/knockoutlist": redirectUrl = baseUrl + "/learn/knockout"; break;
                case "https://www.dotnettricks.com/tutorial/webapilist": redirectUrl = baseUrl + "/learn/webapi"; break;
                case "https://www.dotnettricks.com/tutorial/dependencyinjectionlist": redirectUrl = baseUrl + "/learn/dependencyinjection"; break;
                case "https://www.dotnettricks.com/tutorial/designpatternslist": redirectUrl = baseUrl + "/learn/designpatterns"; break;
                case "https://www.dotnettricks.com/tutorial/wpflist": redirectUrl = baseUrl + "/learn/wpf"; break;
                case "https://www.dotnettricks.com/tutorial/windowsazurelist": redirectUrl = baseUrl + "/learn/windowsazure"; break;
                case "https://www.dotnettricks.com/tutorial/nodejslist": redirectUrl = baseUrl + "/learn/nodejs"; break;
                case "https://www.dotnettricks.com/tutorial/ioniclist": redirectUrl = baseUrl + "/learn/ionic"; break;

                //articles 
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270026-what-is-the-difference-between-constant,-readonly-and-static.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/difference-between-constant-and-readonly-and-static";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/mvc/y3x0270006-what-is-domain-driven-design-and-development.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/designpatterns";
                    break;
                case "https://www.dotnettricks.com/stepbystep/question/linq/general":
                    redirectUrl = "https://www.dotnettricks.com/learn/linq";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/7td6140315-which-one-is-fast,-switch-or-if-else-if-ladder.html":
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/7td6140315-which-one-is-fast":
                case "https://www.dotnettricks.com/XddoZ/VTObZ/Tutorial/csharp/PVO1280414-Understanding-decision-making-":
                case "https://www.dotnettricks.com/PaOeZ/MihUZ/Tutorial/csharp/PVO1280414-Understanding-decision-making-":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/understanding-decision-making-statements-in-csharp";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270019-what-is-data-type.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/stepbystep/csharp/datatype";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270016-explain-the-new-features-of-c":
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270004-what-is-c":
                    redirectUrl = "https://www.dotnettricks.com/learn/stepbystep/csharp/introduction";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270025-what-is-the-difference-between-int,-int16,-int32-and-int64.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/difference-between-int-int16-int32-and-int64";
                    break;
                case "https://www.dotnettricks.com/tutorial/mvc/wknq12011":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc";
                    break;
                case "https://www.dotnettricks.com/stepbystep/question/mvc/general":
                    redirectUrl = "https://www.dotnettricks.com/learn/stepbystep/mvc/introduction";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/mvc/y3x0270013-what-is-difference-between-asp.net-webform-and-asp.net-mvc.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/difference-between-aspnet-webform-and-aspnet-mvc";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270027-what-is-the-difference-between-var-data-type-and-anonymous-type.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/differences-between-object-var-and-dynamic-type";
                    break;
                case "https://www.dotnettricks.com/-understanding-inversion-of-control,-dependency-injection-and-service-locator.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/dependencyinjection/understanding-inversion-of-control-dependency-injection-and-service-locator";
                    break;
                case "https://www.dotnettricks.com/stepbystep/answer/mvc/y3x0270011-explain-evolution-history-of-asp.net-mvc.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/stepbystep/mvc/introduction"; break;
                case "https://www.dotnettricks.com/answer/csharp/y3x0270029-what-is-the-upcasting-and-downcasting.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/understanding-type-casting-or-type-conversion-in-csharp"; break;
                case "https://www.dotnettricks.com/fstepbystep/fanswer/fmvc/fy3x0270008-what-is-mvvm-pattern.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/designpatterns/understanding-mvc-mvp-and-mvvm-design-patterns"; break;
                case "https://www.dotnettricks.com/stepbystep/answer/csharp/y3x0270015-explain-evolution-history-of-c#.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/stepbystep/csharp/introduction"; break;
                case "https://www.dotnettricks.com/stepbystep/answer/angularjs/k2ns030215-what-is-angularjs.html":
                case "https://www.dotnettricks.com/ZaOcZ/YUnbZ/ZoeUZ/Tutorial/angularjs/H917260512-What-is-AngularJS-and-Why-to-use-it":
                    redirectUrl = "https://www.dotnettricks.com/learn/angularjs/what-is-angularjs-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/tutorial/linq/vk7i020215-introduction.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/linq/introduction-to-linq"; break;
                case "https://www.dotnettricks.com/tutorial/angularjs/kmma100215-cookies.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/angularjs/understanding-cookies-in-angularjs"; break;
                case "https://www.dotnettricks.com/-understanding-$watch(),-$watchgroup()-and-$watchcollection()-methods-of-scope.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/angularjs/understanding-watch-watchgroup-and-watchcollection-methods-of-scope"; break;
                case "https://www.dotnettricks.com/-definition,-use-of-group-by-and-having-clause.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/sqlserver/definition-use-of-group-by-and-having-clause"; break;
                case "https://www.dotnettricks.com/-difference-between-cte-and-temp-table-and-table-variable.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/sqlserver/difference-between-cte-and-temp-table-and-table-variable"; break;
                case "https://www.dotnettricks.com/-what-is-backbone.js-and-why-to-use-it?.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/backbone/what-is-backbonejs-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/-introduction-to-c-sharp.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/csharp/introduction-to-csharp"; break;
                case "https://www.dotnettricks.com/-what-is-knockout.js-and-how-is-it-different-from-jquery?.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/knockout/what-is-knockoutjs-and-how-is-it-different-from-jquery"; break;
                case "https://www.dotnettricks.com/-understanding-angularjs-factory,-service-and-provider.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/angularjs/understanding-angularjs-factory-service-and-provider"; break;
                case "https://www.dotnettricks.com/-html-submission-by-validateinput-and-allowhtml-attribute-in-mvc4.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/html-submission-by-validateinput-and-allowhtml-attribute-in-mvc4"; break;
                case "https://www.dotnettricks.com/-configuring-visual-studio-2015-to-develop-hybrid-mobile-apps.html":
                case "https://www.dotnettricks.com/learn/hybridmobileapps/configuring-visual-studio-2015-to-develop-hybrid-mobile-apps":
                    redirectUrl = "https://www.dotnettricks.com/learn/ionic/configuring-visual-studio-2015-to-develop-hybrid-mobile-apps"; break;
                case "https://www.dotnettricks.com/-different-types-of-sql-keys.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/sqlserver/different-types-of-sql-keys"; break;
                case "https://www.dotnettricks.com/-layouts,-renderbody,-rendersection-and-renderpage-in-asp.net-mvc.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/layouts-renderbody-rendersection-and-renderpage-in-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/-angularjs-form-validation-with-bootstrap.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/angularjs/angularjs-form-validation-with-bootstrap"; break;
                case "https://www.dotnettricks.com/-difference-between-wcf-and-web-api-and-wcf-rest-and-web-service.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/webapi/difference-between-wcf-and-web-api-and-wcf-rest-and-web-service"; break;
                case "https://www.dotnettricks.com/-top-10-visual-studio-keyboard-shorcuts.html": redirectUrl = "https://www.dotnettricks.com/learn/visualstudio/top-10-visual-studio-keyboard-shorcuts"; break;
                case "https://www.dotnettricks.com/-constant-in-c-language.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/stepbystep/c/constantsandliterals"; break;
                case "https://www.dotnettricks.com/-disable-cut,-copy-and-paste-in-textbox-using-jquery,-javascript.html":
                case "https://www.dotnettricks.com/jMOSj/iXhOl/Tutorial/jquery/D9UO110612-Disable-cut,-copy-and-paste-in-textbox-using-jquery,-javascript.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/jquery/disable-cut-copy-and-paste-in-textbox-using-jquery-javascript"; break;
                case "https://www.dotnettricks.com/-handling-multiple-submit-buttons-on-the-same-form---mvc-razor.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/handling-multiple-submit-buttons-on-the-same-form-mvc-razor"; break;
                case "https://www.dotnettricks.com/-understanding-entity-framework-code-first-migrations.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/entityframework/understanding-entity-framework-code-first-migrations"; break;
                case "https://www.dotnettricks.com/-understanding-case-expression-in-sql-server-with-example.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/sqlserver/understanding-case-expression-in-sql-server-with-example"; break;
                case "https://www.dotnettricks.com/-understanding-.net-framework-4.5-architecture.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/netframework/understanding-net-framework-45-architecture"; break;
                case "https://www.dotnettricks.com/-understanding-internationalization-in-asp.net-mvc.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/understanding-internationalization-in-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/-crud-operations-using-jquery-dialog,-entity-framework-and-asp.net-mvc.html":
                case "https://www.dotnettricks.com/Tutorial/mvc/42R0171112-CRUD-Operations-using-jQuery-dialog,-Entity-Framework-and-ASP.NET-MVC.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/crud-operations-using-jquery-dialog-entity-framework-and-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/tutorial/aspnet/bptf281212-difference-between-httpget-and-httppost-method.html.":
                case "https://www.dotnettricks.com/tutorial/aspnet/bptf281212-difference-between-httpget-and-httppost-method.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/aspnet/difference-between-httpget-and-httppost-method"; break;
                case "http://dotnet-tricks.com/learn/mvc/aspnet-mvc-request-life-cycle": redirectUrl = "https://www.dotnettricks.com/learn/mvc/aspnet-mvc-request-life-cycle"; break;
                case "http://dotnet-tricks.com/web/20160324015129/https://www.dotnettricks.com/tutorial/mvc/g54g220114-custom-authentication-and-authorization-in-asp.net-mvc.html":
                    redirectUrl = "https://www.dotnettricks.com/learn/mvc/custom-authentication-and-authorization-in-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/design_pattern/flyweight_pattern.com/design_patterns/builder/c-sharp-dot-net":
                    redirectUrl = baseUrl + "/learn/designpatterns/flyweight-design-pattern-dotnet";
                    break;
                case "https://www.dotnettricks.com/-sql-server-exception-handling-by-try%e2%80%a6catch.html":
                case "https://www.dotnettricks.com/tutorial/sqlserver/o3p3120412-sql-server-exception-handling-by-try%25e2%2580%25a6catch.html":
                    redirectUrl = baseUrl + "/learn/sqlserver/sql-server-exception-handling-by-try-catch"; break;

                case "https://www.dotnettricks.com/home/training":
                case "https://www.dotnettricks.com/all-courses":
                case "https://www.dotnettricks.com/Home/InstructorledCourses":
                    redirectUrl = baseUrl + "/instructor-led-courses"; break;
                case "https://www.dotnettricks.com/ebook/linq":
                    redirectUrl = baseUrl + "/books/linq/interview"; break;
                case "https://www.dotnettricks.com/-difference-between-asp.net-webform-and-asp.net-mvc.html": redirectUrl = baseUrl + "/learn/mvc/difference-between-aspnet-webform-and-aspnet-mvc"; break;

                case "https://www.dotnettricks.com/-understanding-asp.net-mvc-scaffolding.html": redirectUrl = baseUrl + "/learn/mvc/understanding-aspnet-mvc-scaffolding"; break;

                case "https://www.dotnettricks.com/-understanding-mvc,-mvp-and-mvvm-design-patterns.html":
                    redirectUrl = baseUrl + "/learn/designpatterns/understanding-mvc-mvp-and-mvvm-design-patterns"; break;
                case "https://www.dotnettricks.com/-get-nth-highest-and-lowest-salary-of-an-employee.html":
                    redirectUrl = baseUrl + "/learn/sqlserver/get-nth-highest-and-lowest-salary-of-an-employee"; break;
                case "https://www.dotnettricks.com/-understanding-asp.net-mvc-filters-and-attributes.html":
                    redirectUrl = baseUrl + "/learn/mvc/understanding-aspnet-mvc-filters-and-attributes"; break;
                case "https://www.dotnettricks.com/-download-microsoft-visual-studio-express.html": redirectUrl = baseUrl + "/learn/visualstudio/download-microsoft-visual-studio-express"; break;
                case "https://www.dotnettricks.com/-server-side-model-validation-in-mvc-razor.html":
                    redirectUrl = baseUrl + "/learn/mvc/server-side-model-validation-in-mvc-razor"; break;
                case "https://www.dotnettricks.com/-viewdata-vs-viewbag-vs-tempdata-vs-session.html":
                    redirectUrl = baseUrl + "/learn/mvc/viewdata-vs-viewbag-vs-tempdata-vs-session"; break;
                case "https://www.dotnettricks.com/-understanding-html-helpers-in-asp.net-mvc.html":
                    redirectUrl = baseUrl + "/learn/mvc/understanding-html-helpers-in-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/-brief-history-of-node.js-and-io.js.html": redirectUrl = baseUrl + "/learn/nodejs/brief-history-of-nodejs-and-iojs"; break;

                case "https://www.dotnettricks.com/tutorial/sqlserver?id=hqv8310312&title=sql%20server%20-%20definition,%20use%20of%20group%20by%20and%20having%20clause":
                    redirectUrl = baseUrl + "/learn/sqlserver/definition-use-of-group-by-and-having-clause"; break;
                case "https://www.dotnettricks.com/-difference-between-ado.net-and-linq-to-sql.html":
                    redirectUrl = baseUrl + "/learn/linq/difference-between-adonet-and-linq-to-sql"; break;
                case "https://www.dotnettricks.com/-difference-between-razor-view-engine-and-aspx-view-engine.html":
                case "https://www.dotnettricks.com/VdKiZ/SXgfZ/UZdnZ/MOTRZ/XQXZZ/VgZMZ/LXUbZ/YmNmZ/KTMTZ/VWLeZ/Tutorial/mvc/91JM151212-Difference-Between-Razor-View-Engine-and-ASPX-View-Engine.html":
                    redirectUrl = baseUrl + "/learn/mvc/difference-between-razor-view-engine-and-aspx-view-engine"; break;
                case "https://www.dotnettricks.com/-custom-validation-for-checkbox-in-mvc-razor.html":
                    redirectUrl = baseUrl + "/learn/mvc/custom-validation-for-checkbox-in-mvc-razor"; break;
                case "https://www.dotnettricks.com/-enable-intellisense-in-sql-server-2005,-2008.html":
                    redirectUrl = baseUrl + "/learn/sqlserver/enable-intellisense-in-sql-server-2005-2008"; break;
                case "https://www.dotnettricks.com/-comparing-linq-with-stored-procedure.html": redirectUrl = baseUrl + "/learn/linq/comparing-linq-with-stored-procedure"; break;
                case "https://www.dotnettricks.com/-how-to-upload-a-file-in-mvc4.html": redirectUrl = baseUrl + "/learn/mvc/how-to-upload-a-file-in-mvc4"; break;
                case "https://www.dotnettricks.com/-difference-between-primary-key-and-foreign-key.html":
                    redirectUrl = baseUrl + "/learn/sqlserver/difference-between-primary-key-and-foreign-key"; break;
                case "https://www.dotnettricks.com/-a-brief-version-history-of-.net-framework.html":
                    redirectUrl = baseUrl + "/learn/netframework/a-brief-version-history-of-net-framework"; break;
                case "https://www.dotnettricks.com/home/book":
                    redirectUrl = baseUrl + "/free-ebooks"; break;
                case "https://www.dotnettricks.com/-different-types-of-sql-joins.html":
                    redirectUrl = baseUrl + "/learn/sqlserver/different-types-of-sql-joins"; break;
                case "https://www.dotnettricks.com/-visual-studio-debug-vs-release-mode.html": redirectUrl = baseUrl + "/learn/visualstudio/visual-studio-debug-vs-release-mode"; break;
                case "https://www.dotnettricks.com/-remove-duplicate-records-from-a-table-in-sql-server.html": redirectUrl = baseUrl + "/learn/sqlserver/remove-duplicate-records-from-a-table-in-sql-server"; break;
                case "https://www.dotnettricks.com/-get-file-size-before-upload-using-jquery.html":
                case "https://www.dotnettricks.com/NNYUZ/LSNXZ/Tutorial/jquery/HHLN180712-Get-file-size-before-upload-using-jquery.html":
                    redirectUrl = baseUrl + "/learn/jquery/get-file-size-before-upload-using-jquery"; break;
                case "https://www.dotnettricks.com/-creating-and-querying-mongo-database-with-mongo-shell.html": redirectUrl = baseUrl + "/learn/mongodb/creating-and-querying-mongo-database-with-mongo-shell"; break;
                case "https://www.dotnettricks.com/-html-color-codes.html": redirectUrl = baseUrl + "/learn/stylesheet/html-color-codes"; break;
                case "https://www.dotnettricks.com/-different-types-of-sql-server-views.html": redirectUrl = baseUrl + "/learn/sqlserver/different-types-of-sql-server-views"; break;
                case "https://www.dotnettricks.com/-disable-right-click-on-web-page-and-images.html": redirectUrl = baseUrl + "/learn/aspnet/disable-right-click-on-web-page-and-images"; break;
                case "https://www.dotnettricks.com/-hello-world-windows-phone-8-app.html": redirectUrl = baseUrl + "/learn/windowsphoneapps/hello-world-windows-phone-8-app"; break;
                case "https://www.dotnettricks.com/-remove-unsent-database-email-from-sql-server.html": redirectUrl = baseUrl + "/learn/sqlserver/remove-unsent-database-email-from-sql-server"; break;
                case "https://www.dotnettricks.com/-custom-validation-for-cascading-dropdownlist-in-mvc-razor.html": redirectUrl = baseUrl + "/learn/mvc/custom-validation-for-cascading-dropdownlist-in-mvc-razor"; break;
                case "https://www.dotnettricks.com/-a-glimpse-into-windows-apps-and-windows-store.html": redirectUrl = baseUrl + "/learn/cswinapps/a-glimpse-into-windows-apps-and-windows-store"; break;
                case "https://www.dotnettricks.com/-c-sharp-anonymous-method.html": redirectUrl = baseUrl + "/learn/csharp/c-sharp-anonymous-method"; break;
                case "https://www.dotnettricks.com/-asp.net-enter-key-to-submit-form.html": redirectUrl = baseUrl + "/learn/aspnet/aspnet-enter-key-to-submit-form"; break;
                case "https://www.dotnettricks.com/-node.js-installation-guide.html": redirectUrl = baseUrl + "/learn/nodejs/nodejs-installation-guide"; break;
                case "https://www.dotnettricks.com/-understanding-cloud-computing-and-windows-azure.html": redirectUrl = baseUrl + "/learn/windowsazure/understanding-cloud-computing-and-windows-azure"; break;
                case "https://www.dotnettricks.com/-sql-server-cursor-alternatives.html": redirectUrl = baseUrl + "/learn/sqlserver/sql-server-cursor-alternatives"; break;
                case "https://www.dotnettricks.com/-windows-phone-8-emulator-configuration.html": redirectUrl = baseUrl + "/learn/windowsphoneapps/windows-phone-8-emulator-configuration"; break;
                case "https://www.dotnettricks.com/-basics-of-sql-commands.html": redirectUrl = baseUrl + "/learn/sqlserver/basics-of-sql-commands"; break;
                case "https://www.dotnettricks.com/-mvc-areas-with-example.html": redirectUrl = baseUrl + "/learn/mvc/mvc-areas-with-example"; break;
                case "https://www.dotnettricks.com/-introduction-to-n-hibernate.html": redirectUrl = baseUrl + "/learn/fluentnhibernate/introduction-to-fluent-nhibernate"; break;
                case "https://www.dotnettricks.com/-drop-all-tables,-stored-procedure,-views-and-triggers.html": redirectUrl = baseUrl + "/learn/sqlserver/drop-all-tables-stored-procedure-views-and-triggers"; break;
                case "https://www.dotnettricks.com/-enhancing-webgrid-with-ajax-in-mvc4.html": redirectUrl = baseUrl + "/learn/mvc/enhancing-webgrid-with-ajax-in-mvc4"; break;
                case "https://www.dotnettricks.com/tutorial/csharp?id=oito200612&title=c": redirectUrl = baseUrl + "/learn/csharp/c-sharp-delegates-and-plug-in-methods-with-delegates"; break;
                case "https://www.dotnettricks.com/-securing-asp.net-web-api-using-basic-authentication.html": redirectUrl = baseUrl + "/learn/webapi/securing-aspnet-web-api-using-basic-authentication"; break;
                case "https://www.dotnettricks.com/-understanding-relationship-between-cts-and-cls.html": redirectUrl = baseUrl + "/learn/netframework/understanding-relationship-between-cts-and-cls"; break;
                case "https://www.dotnettricks.com/-introduction-to-asp.net.html": redirectUrl = baseUrl + "/learn/aspnet/introduction-to-aspnet"; break;
                case "https://www.dotnettricks.com/-after-trigger,-instead-of-trigger-example.html": redirectUrl = baseUrl + "/learn/sqlserver/after-trigger-instead-of-trigger-example"; break;
                case "https://www.dotnettricks.com/-variable-in-c-language.html": redirectUrl = baseUrl + "/learn/stepbystep/c/variable"; break;
                case "https://www.dotnettricks.com/-introduction-to-tfs.html": redirectUrl = baseUrl + "/learn/tfs/introduction-to-tfs"; break;
                case "https://www.dotnettricks.com/-ienumerable-vs-iqueryable.html":
                case "https://www.dotnettricks.com/OmXkZ/LfOaZ/Tutorial/linq/I8SY160612-IEnumerable-VS-IQueryable.html":
                case "https://www.dotnettricks.com/Tutorial/linq/I8SY160612-IEnumerable-VS-IQueryable.html":
                    redirectUrl = baseUrl + "/learn/linq/ienumerable-vs-iqueryable"; break;
                case "https://www.dotnettricks.com/-what-is-node.js-and-why-to-use-it?.html": redirectUrl = baseUrl + "/learn/nodejs/what-is-nodejs-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/tutorial/c/igdd030616-constants/literals.html": redirectUrl = baseUrl + "/learn/stepbystep/c/constantsandliterals"; break;
                case "https://www.dotnettricks.com/-understanding-viewmodel-in-asp.net-mvc.html":
                case "https://www.dotnettricks.com/NpkdZ/NmclZ/Tutorial/mvc/QHQT270712-Understanding-ViewModel-in-ASP.NET-MVC.html":
                    redirectUrl = baseUrl + "/learn/mvc/understanding-viewmodel-in-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/-understanding-angularjs-directive.html": redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-directive"; break;
                case "https://www.dotnettricks.com/-a-glimpse-into-windows-phone-sdk-8.0.html": redirectUrl = baseUrl + "/learn/windowsphoneapps/a-glimpse-into-windows-phone-sdk-80"; break;
                case "https://www.dotnettricks.com/-resolve-ambiguous-controller-error-by-routes.html": redirectUrl = baseUrl + "/learn/mvc/resolve-ambiguous-controller-error-by-routes"; break;
                case "https://www.dotnettricks.com/-bundling-and-minification-in-mvc3-and-asp.net-4.0.html": redirectUrl = baseUrl + "/learn/mvc/bundling-and-minification-in-mvc3-and-aspnet-40"; break;
                case "https://www.dotnettricks.com/tutorial/plinqlist": redirectUrl = baseUrl + "/learn/linq"; break;
                case "https://www.dotnettricks.com/-understanding-prototype-in-javascript.html": redirectUrl = baseUrl + "/learn/javascript/understanding-prototype-in-javascript"; break;
                case "https://www.dotnettricks.com/-difference-between-primary-key-and-unique-key.html": redirectUrl = baseUrl + "/learn/sqlserver/difference-between-primary-key-and-unique-key"; break;
                case "https://www.dotnettricks.com/-understanding-message-exchange-patterns-(mep)-in-wcf.html": redirectUrl = baseUrl + "/learn/wcf/understanding-message-exchange-patterns-mep-in-wcf"; break;
                case "https://www.dotnettricks.com/-difference-between-gridview-and-datagrid-and-listview.html": redirectUrl = baseUrl + "/learn/aspnet/difference-between-gridview-and-datagrid-and-listview"; break;
                case "https://www.dotnettricks.com/tutorial/dlinqlist": redirectUrl = baseUrl + "/learn/linq"; break;
                case "https://www.dotnettricks.com/-introduction-to-wcf.html": redirectUrl = baseUrl + "/learn/wcf/introduction-to-wcf"; break;
                case "https://www.dotnettricks.com/-different-types-of-sql-server-triggers.html": redirectUrl = baseUrl + "/learn/sqlserver/different-types-of-sql-server-triggers"; break;
                case "https://www.dotnettricks.com/-mongo-db-comparison-operators.html": redirectUrl = baseUrl + "/learn/mongodb/mongo-db-comparison-operators"; break;
                case "https://www.dotnettricks.com/-different-types-of-sql-server-functions.html": redirectUrl = baseUrl + "/learn/sqlserver/different-types-of-sql-server-functions"; break;
                case "https://www.dotnettricks.com/-setting-default-submit-button-in-mvc3-razor-using-jquery.html": redirectUrl = baseUrl + "/learn/mvc/setting-default-submit-button-in-mvc3-razor-using-jquery"; break;
                case "https://www.dotnettricks.com/-understanding-$emit,-$broadcast-and-$on-in-angularjs.html": redirectUrl = baseUrl + "/learn/angularjs/understanding-emit-broadcast-and-on-in-angularjs"; break;
                case "https://www.dotnettricks.com/-c-sharp-var-data-type-and-anonymous-type.html": redirectUrl = baseUrl + "/learn/csharp/c-sharp-var-data-type-and-anonymous-type"; break;
                case "https://www.dotnettricks.com/-how-to-create-repository-on-tfs---cloud.html": redirectUrl = baseUrl + "/learn/tfs/how-to-create-repository-on-tfs-csharploud"; break;
                case "https://www.dotnettricks.com/-understanding-jquery-mobile-pages.html": redirectUrl = baseUrl + "/learn/jquerymobile/understanding-jquery-mobile-pages"; break;
                case "https://www.dotnettricks.com/-node.js-vs.-other-server-side-frameworks.html": redirectUrl = baseUrl + "/learn/nodejs/nodejs-vs-other-server-side-frameworks"; break;
                case "https://www.dotnettricks.com/-sql-server-exceptions-working.html": redirectUrl = baseUrl + "/learn/sqlserver/sql-server-exceptions-working"; break;
                case "https://www.dotnettricks.com/tutorial/plinqlist?id=7y94040212": redirectUrl = baseUrl + "/learn/linq"; break;

                case "https://www.dotnettricks.com/stepbystep/tutorial/c/constants/literals/introduction": redirectUrl = baseUrl + "/learn/stepbystep/c/constantsandliterals"; break;
                case "https://www.dotnettricks.com/-partial-view-in-asp.net-mvc3-razor.html": redirectUrl = baseUrl + "/learn/mvc/partial-view-in-aspnet-mvc3-razor"; break;
                case "https://www.dotnettricks.com/-microsoft-access-connection-strings.html": redirectUrl = baseUrl + "/learn/adonet/microsoft-access-connection-strings"; break;
                case "https://www.dotnettricks.com/-difference-between-asp.net-mvc-and-asp.net-web-api.html": redirectUrl = baseUrl + "/learn/webapi/difference-between-aspnet-mvc-and-aspnet-web-api"; break;
                case "https://www.dotnettricks.com/-asp.net-mvc-request-life-cycle.html": redirectUrl = baseUrl + "/learn/mvc/aspnet-mvc-request-life-cycle"; break;
                case "https://www.dotnettricks.com/-difference-between-function-and-method.html": redirectUrl = baseUrl + "/learn/oops/difference-between-function-and-method"; break;
                case "https://www.dotnettricks.com/-understanding-ajax-helpers-in-asp.net-mvc.html": redirectUrl = baseUrl + "/learn/mvc/understanding-ajax-helpers-in-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/-difference-between-ref-and-out-parameters.html": redirectUrl = baseUrl + "/learn/csharp/difference-between-ref-and-out-parameters"; break;
                case "https://www.dotnettricks.com/-sql-server-xml-data-type.html": redirectUrl = baseUrl + "/learn/sqlserver/sql-server-xml-data-type"; break;
                case "https://www.dotnettricks.com/-donut-caching-and-donut-hole-caching-with-asp.net-mvc-4.html": redirectUrl = baseUrl + "/learn/mvc/donut-caching-and-donut-hole-caching-with-aspnet-mvc-4"; break;
                case "https://www.dotnettricks.com/-mvc-data-annotations-for-model-validation.html": redirectUrl = baseUrl + "/learn/mvc/mvc-data-annotations-for-model-validation"; break;
                case "https://www.dotnettricks.com/-introduction-to-css.html": redirectUrl = baseUrl + "/learn/stylesheet/introduction-to-css"; break;
                case "https://www.dotnettricks.com/-web-api-crud-operations-with-knockout.html": redirectUrl = baseUrl + "/learn/knockout/web-api-crud-operations-with-knockout"; break;
                case "https://www.dotnettricks.com/-understanding-angularjs-routing.html": redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-routing"; break;
                case "https://www.dotnettricks.com/-introduction-to-sql-server.html": redirectUrl = baseUrl + "/learn/sqlserver/introduction-to-sql-server"; break;
                case "https://www.dotnettricks.com/-sql-server-basics-of-cursors.html": redirectUrl = baseUrl + "/learn/sqlserver/sql-server-basics-of-cursors"; break;
                case "https://www.dotnettricks.com/-stop-auto-fill-in-browsers-for-textbox.html": redirectUrl = baseUrl + "/learn/aspnet/stop-auto-fill-in-browsers-for-textbox"; break;
                case "https://www.dotnettricks.com/-what-is-android-and-why-to-use-it?.html": redirectUrl = baseUrl + "/learn/android/what-is-android-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/-understanding-var-and-ienumerable-with-linq.html": redirectUrl = baseUrl + "/learn/linq/understanding-var-and-ienumerable-with-linq"; break;
                case "https://www.dotnettricks.com/-a-brief-history-of-asp.net-mvc-framework.html": redirectUrl = baseUrl + "/learn/mvc/a-brief-history-of-aspnet-mvc-framework"; break;
                case "https://www.dotnettricks.com/-what-is-unit-testing-and-why-to-use-it?.html": redirectUrl = baseUrl + "/learn/unittesting/what-is-unit-testing-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/-calling-cross-domain-wcf-service-using-jquery.html": redirectUrl = baseUrl + "/learn/wcf/calling-cross-domain-wcf-service-using-jquery"; break;
                case "https://www.dotnettricks.com/-introduction-to-asp.net-mvc.html": redirectUrl = baseUrl + "/learn/mvc/introduction-to-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/-what-is-angularjs-and-why-to-use-it?.html": redirectUrl = baseUrl + "/learn/angularjs/what-is-angularjs-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/-difference-between-finalize-and-dispose-method.html": redirectUrl = baseUrl + "/learn/netframework/difference-between-finalize-and-dispose-method"; break;
                case "https://www.dotnettricks.com/-what-is-mongodb-and-why-to-use-it?.html": redirectUrl = baseUrl + "/learn/mongodb/what-is-mongodb-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/-safe-type-casting-with-is-and-as-operator.html": redirectUrl = baseUrl + "/learn/csharp/safe-type-casting-with-is-and-as-operator"; break;
                case "https://www.dotnettricks.com/-create-xml-from-database-using-linq.html": redirectUrl = baseUrl + "/learn/linq/create-xml-from-database-using-linq"; break;
                case "https://www.dotnettricks.com/-understanding-wpf-architecture.html": redirectUrl = baseUrl + "/learn/wpf/understanding-wpf-architecture"; break;
                case "https://www.dotnettricks.com/-sql-server-different-types-of-cursors.html": redirectUrl = baseUrl + "/learn/sqlserver/sql-server-different-types-of-cursors"; break;
                case "https://www.dotnettricks.com/-understanding-angularjs-scope-life-cycle.html":
                case "https://www.dotnettricks.com/OklfZ/KlLgZ/Tutorial/angularjs/a9T0291214-Understanding-AngularJS-scope-life-cycle.html":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-scope-life-cycle"; break;
                case "https://www.dotnettricks.com/-turn-off-asp.net-custom-errors-in-web.config.html": redirectUrl = baseUrl + "/learn/aspnet/turn-off-aspnet-custom-errors-in-webconfig"; break;
                case "https://www.dotnettricks.com/-how-to-enable-and-disable-client-side-validation-in-mvc.html": redirectUrl = baseUrl + "/learn/mvc/how-to-enable-and-disable-client-side-validation-in-mvc"; break;
                case "https://www.dotnettricks.com/-understanding-linq-standard-query-operators.html": redirectUrl = baseUrl + "/learn/linq/understanding-linq-standard-query-operators"; break;
                case "https://www.dotnettricks.com/-a-brief-version-history-of-asp.net.html": redirectUrl = baseUrl + "/learn/aspnet/a-brief-version-history-of-aspnet"; break;
                case "https://www.dotnettricks.com/tutorial/sqlserver/rlid060512-sql-server-different-types-of-cursors.html%0d*/": redirectUrl = baseUrl + "/learn/sqlserver/sql-server-different-types-of-cursors"; break;
                case "https://www.dotnettricks.com/learn/csharp/difference-between-responseredirect-and-servertransfer":
                    redirectUrl = baseUrl + "/learn/aspnet/difference-between-responseredirect-and-servertransfer"; break;
                case "https://www.dotnettricks.com/learn/angularmaterialdesign/what-is-angular-material-design-and-why-to-use-it": redirectUrl = baseUrl + "/learn/angularmaterial/what-is-angular-material-design-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/learn/angularmaterialdesign":
                    redirectUrl = baseUrl + "/learn/angularmaterial"; break;
                case "https://www.dotnettricks.com/learn/node/getting-started-with-expressjs":
                    redirectUrl = baseUrl + "/learn/nodejs/getting-started-with-expressjs"; break;
                case "https://www.dotnettricks.com/SQfNZ/OlmfZ/TQNXZ/Tutorial/linq/RJX7120714-Understanding-Expression-and-Expression-Trees.html":
                    redirectUrl = baseUrl + "/learn/linq/understanding-expression-and-expression-trees"; break;
                case "https://www.dotnettricks.com/OablZ/TZmZZ/ZPniZ/RkYfZ/UTbTZ/QdLMZ/Tutorial/linq/6DJI160714-Difference-between-Deferred-execution-and-Immediate-execution.html":
                    redirectUrl = baseUrl + "/learn/linq/difference-between-deferred-execution-and-immediate-execution"; break;
                case "https://www.dotnettricks.com/VlUKZ/VTlXZ/ZnUVZ/Tutorial/linq/UXPF181012-SQL-Joins-with-C":
                    redirectUrl = baseUrl + "/learn/linq/sql-joins-with-csharp-linq"; break;
                case "https://www.dotnettricks.com/KfNeZ/RigWZ/XiRNZ/KXkeZ/WiRUZ/PUaiZ/RNWeZ/UbkiZ/TSQpZ/Tutorial/hybridmobileapps/WQPF200714-Understanding-Mobile-Apps-Development-Options-(Native,-HTML5-or-Hybrid).html":
                    redirectUrl = baseUrl + "/hybridmobileapps/understanding-mobile-apps-development-options"; break;
                case "https://www.dotnettricks.com/XackZ/mioSi/Tutorial/designpatterns/R9R4060613-Prototype-Design-Pattern---C":
                    redirectUrl = baseUrl + "/learn/designpatterns/prototype-design-pattern-dotnet"; break;
                case "https://www.dotnettricks.com/learn/webservice/introduction-to-web-service":
                    redirectUrl = baseUrl + "/learn/wcf/introduction-to-web-service"; break;
                case "https://www.dotnettricks.com/learn/webservice/understanding-ws-star-standards-and-specifications":
                    redirectUrl = baseUrl + "/learn/wcf/understanding-ws-star-standards-and-specifications"; break;
                case "https://www.dotnettricks.com/learn/ajax/introduction-to-ajax":
                    redirectUrl = baseUrl + "/learn/aspnet/introduction-to-ajax"; break;
                case "https://www.dotnettricks.com/learn/ajax/understanding-basic-controls-of-aspnet-ajax":
                    redirectUrl = baseUrl + "/learn/aspnet/understanding-basic-controls-of-aspnet-ajax"; break;

                case "https://www.dotnettricks.com/learn/csharp/interview-questions-and-answers":
                    redirectUrl = baseUrl + "/learn/csharp/top-20-csharp-interview-questions-and-answers"; break;

                case "https://www.dotnettricks.com/learn/angularjs/interview-questions-and-answers":
                    redirectUrl = baseUrl + "/learn/angularjs/top-20-angularjs-interview-questions-and-answers"; break;

                case "https://www.dotnettricks.com/learn/aws/top-10-reasons-why-you-should-get-upskilled-on-aws-in-2018":
                    redirectUrl = baseUrl + "/learn/aws/top-10-reasons-why-you-should-get-upskilled-on-aws-in-2019"; break;

                case "https://www.dotnettricks.com/learn/azure/virtual-network-gateway-architecture":
                    redirectUrl = baseUrl + "/learn/azure/what-is-microsoft-azure-virtual-network-and-architecture"; break;
                // Old Site Url end

                //Step by step start
                case "https://www.dotnet-tricks.com/stepbystep/home/archive/2":
                    redirectUrl = baseUrl + "/learn"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/linq":
                case "https://www.dotnettricks.com/stepbystep/tutorial/linq/introduction":
                case "https://www.dotnettricks.com/learn/stepbystep/linq/introduction":
                    redirectUrl = baseUrl + "/learn/linq/introduction-to-linq"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/webapi":
                case "https://www.dotnettricks.com/learn/stepbystep/webapi/introduction":
                case "https://www.dotnettricks.com/LcLZZ/LYiPZ/StepByStep/Tutorial/webapi/introduction":
                case "https://www.dotnettricks.com/learn/webapi/what-is-web-api-and-why-to-use-it-":
                case "https://www.dotnettricks.com/-what-is-web-api-and-why-to-use-it-?.html":
                case "https://www.dotnettricks.com/stepbystep/tutorial/webapi/introduction":
                    redirectUrl = baseUrl + "/learn/webapi/what-is-web-api-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/introduction":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/introduction":
                    redirectUrl = baseUrl + "/learn/angularjs/what-is-angularjs-and-why-to-use-it"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/mvc":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/mvc":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/modules":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/modules":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/expressions":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/expressions":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/filters":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/filters":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/scope":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/scope":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/controllers":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/controllers":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/events":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/events":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-features-of-angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/directives":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/directives":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-directive"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/bootstrapprocess":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/bootstrapprocess":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-bootstrap-process"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/inheritance":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/inheritance":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-scope-inheritance-in-angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/databinding":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/databinding":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-data-binding-in-angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/formvalidation":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/formvalidation":
                    redirectUrl = baseUrl + "/learn/angularjs/angularjs-form-validation-with-bootstrap"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/templates":
                case "https://www.dotnettricks.com/XQgoZ/StepByStep/Tutorial/angularjs/templates":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/templates":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-templates"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/routing":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/routing":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-routing"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/services":
                case "https://www.dotnettricks.com/LYhPZ/StepByStep/Tutorial/angularjs/services":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/services":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-angularjs-factory-service-and-provider"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/dependencyinjection":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/dependencyinjection":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-dependency-injection-in-angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/cookies":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/cookies":
                case "https://www.dotnettricks.com/fPeWe/ghoYi/XjKWS/WoSZh/RQjQp/mlKTO/XdlZR/StepByStep/Tutorial/angularjs/cookies":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-cookies-in-angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/jqlite":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/jqlite":
                    redirectUrl = baseUrl + "/learn/angularjs/understanding-jqlite-or-jquery-lite"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/eventbasedcommunication":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/eventbasedcommunication": redirectUrl = baseUrl + "/learn/angularjs/understanding-emit-broadcast-and-on-in-angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/internationalization":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/internationalization":
                case "https://www.dotnettricks.com/stepbystep/tutorial/angularjs/animation":
                case "https://www.dotnettricks.com/QVPRZ/StepByStep/Tutorial/angularjs/animation":
                case "https://www.dotnettricks.com/learn/stepbystep/angularjs/animation":
                    redirectUrl = baseUrl + "/learn/angularjs"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/mvc":
                case "https://www.dotnettricks.com/stepbystep/tutorial/mvc/introduction":
                case "https://www.dotnettricks.com/learn/stepbystep/mvc/introduction":
                case "https://www.dotnettricks.com/learn/mvc/introduction-to-aspnet-mvc":
                    redirectUrl = baseUrl + "/learn/mvc/introduction-aspnet-mvc"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c":
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/introduction":
                case "https://www.dotnettricks.com/learn/stepbystep/c/introduction":
                    redirectUrl = baseUrl + "/learn/c/introduction-to-c-language"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/variable":
                case "https://www.dotnettricks.com/YaWVZ/UjdkZ/StepByStep/Tutorial/c/variable":
                case "https://www.dotnettricks.com/learn/stepbystep/c/variable":
                    redirectUrl = baseUrl + "/learn/c/variable-in-c-language"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/datatype":
                case "https://www.dotnettricks.com/learn/stepbystep/c/datatype":
                case "https://www.dotnettricks.com/WVdVZ/StepByStep/Tutorial/c/datatype":
                    redirectUrl = baseUrl + "/learn/c/data-types-in-c-language"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/operators":
                case "https://www.dotnettricks.com/learn/stepbystep/c/operators":
                    redirectUrl = baseUrl + "/learn/c/operators"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/conditionalstatements":
                case "https://www.dotnettricks.com/learn/stepbystep/c/conditionalstatements":
                    redirectUrl = baseUrl + "/learn/c/conditional-statements-if-else-switch-ladder"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/loops":
                case "https://www.dotnettricks.com/learn/stepbystep/c/loops":
                    redirectUrl = baseUrl + "/learn/c/loops"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/c/constantsandliterals":
                case "https://www.dotnettricks.com/LiNkZ/YQPeZ/Tutorial/c/2UY7251012-Constant-in-C-language.html":
                case "https://www.dotnettricks.com/learn/stepbystep/c/constantsandliterals":
                    redirectUrl = baseUrl + "/learn/c/constant-in-c-language"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/csharp":
                case "https://www.dotnettricks.com/stepbystep/tutorial/csharp/introduction":
                case "https://www.dotnettricks.com/learn/stepbystep/csharp/introduction":
                    redirectUrl = baseUrl + "/learn/csharp/introduction-to-csharp"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/csharp/datatype":
                case "https://www.dotnettricks.com/learn/stepbystep/csharp/datatype":
                    redirectUrl = baseUrl + "/learn/csharp/datatype"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript":
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/introduction":
                case "https://www.dotnettricks.com/learn/stepbystep/javascript/introduction":
                    redirectUrl = baseUrl + "/learn/javascript/introduction"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/dom":
                case "https://www.dotnettricks.com/learn/stepbystep/javascript/dom":
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/bom":
                case "https://www.dotnettricks.com/learn/stepbystep/javascript/bom":
                    redirectUrl = baseUrl + "/learn/javascript/dom-bom"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/datatype":
                case "https://www.dotnettricks.com/learn/stepbystep/javascript/datatype":
                    redirectUrl = baseUrl + "/learn/javascript/datatypes"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/variable":
                case "https://www.dotnettricks.com//learn/stepbystep/javascript/variable":
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/variablescope":
                case "https://www.dotnettricks.com/learn/stepbystep/javascript/variablescope":
                    redirectUrl = baseUrl + "learn/javascript/variable-scope-hoisting"; break;
                case "https://www.dotnettricks.com/stepbystep/tutorial/javascript/number":
                case "https://www.dotnettricks.com/learn/stepbystep/javascript/number":
                case "https://www.dotnettricks.com/VOffZ/StepByStep/Tutorial/javascript/number":
                    redirectUrl = baseUrl + "/learn/javascript/numbers"; break;
                case "https://www.dotnettricks.com/TZkoZ/NfRiZ/Tutorial/sqlserver/aDJT100412-Stored-Procedure-Plan-Recompilation-and-Performance-Tuning.html":
                    redirectUrl = baseUrl + "/learn/sqlserver/stored-procedure-plan-recompilation-and-performance-tuning"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/modulesandnamespaces":
                    redirectUrl = baseUrl + "learn/typescript/modules-namespaces"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/objecttypes":
                    redirectUrl = baseUrl + "/learn/typescript"; break;

                case "https://www.dotnettricks.com/learn/fluentnhibernate/introduction-to-fluent-nhibernate":
                case "https://www.dotnettricks.com/learn/fluentnhibernate":
                    redirectUrl = baseUrl + "/learn/entityframework/introduction-to-fluent-nhibernate"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/introduction":
                    redirectUrl = baseUrl + "/learn/typescript/getting-started-guide"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/primitivetypes":
                    redirectUrl = baseUrl + "/learn/typescript/datatypes"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/decorators":
                    redirectUrl = baseUrl + "https://www.dotnettricks.com/learn/typescript/decorators"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/generics":
                    redirectUrl = baseUrl + "https://www.dotnettricks.com/learn/typescript/generics"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/functions":
                    redirectUrl = baseUrl + "https://www.dotnettricks.com/learn/typescript/functions"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/environmentsetup":
                    redirectUrl = baseUrl + "/learn/typescript/getting-started-with-typescript-using-visual-studio-code"; break;
                case "https://www.dotnettricks.com/learn/stepbystep/typescript/statements":
                    redirectUrl = baseUrl + "/learn/typescript/variable"; break;
                //Step by step end
                //mentors
                case "https://www.dotnettricks.com/mentor/akshay":
                    redirectUrl = baseUrl + "/mentors/akshay-deshmukh"; break;
                case "https://www.dotnettricks.com/mentor/amit":
                    redirectUrl = baseUrl + "/mentors/amit-kumar"; break;
                case "https://www.dotnettricks.com/mentor/anurag":
                    redirectUrl = baseUrl + "/mentors/anurag-sinha"; break;
                case "https://www.dotnettricks.com/mentor/debasis":
                    redirectUrl = baseUrl + "/mentors/debasis-saha"; break;
                case "https://www.dotnettricks.com/mentor/deep":
                    redirectUrl = baseUrl + "/mentors/deep-gautam"; break;
                case "https://www.dotnettricks.com/mentor/girdhar":
                    redirectUrl = baseUrl + "/mentors/girdhar-singh"; break;
                case "https://www.dotnettricks.com/mentor/gowtham":
                    redirectUrl = baseUrl + "/mentors/gowtham-k"; break;
                case "https://www.dotnettricks.com/mentor/jignesh":
                    redirectUrl = baseUrl + "/mentors/jignesh-trivedi"; break;
                case "https://www.dotnettricks.com/mentor/jinal":
                    redirectUrl = baseUrl + "/mentors/jinal-shah"; break;
                case "https://www.dotnettricks.com/mentor/manav":
                    redirectUrl = baseUrl + "/mentors/manav-pandya"; break;
                case "https://www.dotnettricks.com/mentor/ramees":
                    redirectUrl = baseUrl + "/mentors/mohammed-ramees"; break;
                case "https://www.dotnettricks.com/mentor/monalisa":
                    redirectUrl = baseUrl + "/mentors/monalisa-das"; break;
                case "https://www.dotnettricks.com/mentor/nishu":
                    redirectUrl = baseUrl + "/mentors/nishu-goel"; break;
                case "https://www.dotnettricks.com/mentor/rahul":
                    redirectUrl = baseUrl + "/mentors/rahul-jain"; break;
                case "https://www.dotnettricks.com/mentor/rupesh":
                    redirectUrl = baseUrl + "/mentors/rupesh-roy"; break;
                case "https://www.dotnettricks.com/mentor/satya":
                    redirectUrl = baseUrl + "/mentors/satyaprakash-samantaray"; break;
                case "https://www.dotnettricks.com/mentor/shailendra":
                    redirectUrl = baseUrl + "/mentors/shailendra-chauhan"; break;
                case "https://www.dotnettricks.com/mentor/shashangka":
                    redirectUrl = baseUrl + "/mentors/shashangka-shekhar"; break;
                case "https://www.dotnettricks.com/mentor/sonny":
                    redirectUrl = baseUrl + "/mentors/sonny-recio"; break;
                case "https://www.dotnettricks.com/mentor/srashti":
                    redirectUrl = baseUrl + "/mentors/srashti-jain"; break;
                case "https://www.dotnettricks.com/mentor/sriram":
                    redirectUrl = baseUrl + "/mentors/sriram-hariharan"; break;
                case "https://www.dotnettricks.com/mentor/yash":
                    redirectUrl = baseUrl + "/mentors/yash-pal"; break;

                /////////book///////
                case "https://www.dotnettricks.com/free-ebooks":
                    redirectUrl = baseUrl + "/books"; break;
                case "https://www.dotnettricks.com/books/mvc/interview":
                    redirectUrl = baseUrl + "/books/mvc-interview-questions-and-answers-book-pdf"; break;
                case "https://www.dotnettricks.com/books/linq/interview":
                    redirectUrl = baseUrl + "/books/linq-interview-questions-and-answers-book-pdf"; break;
                case "https://www.dotnettricks.com/books/angularjs/interview":
                    redirectUrl = baseUrl + "/books/angularjs-interview-questions-and-answers-book-pdf"; break;
                case "https://www.dotnettricks.com/books/nodejs/interview":
                    redirectUrl = baseUrl + "/books/nodejs-interview-questions-and-answers-book-pdf"; break;
                case "https://www.dotnettricks.com/books/typescript/training":
                    redirectUrl = baseUrl + "/books/typescript-interview-questions-and-answers-book-pdf"; break;
            }

            if (!string.IsNullOrEmpty(redirectUrl))
            {
                Response.RedirectPermanent(redirectUrl, true);
            }
        }
    }
}
