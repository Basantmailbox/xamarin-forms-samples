﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace DotNetTricks.COM.PaymentGateway
{
    public class CCAvenue
    {
        public string MerchantId
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CCAvenueMerchantId");
            }
        }

        public string Url
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CCAvenueUrl");
            }
        }

        public string SuccessUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CCAvenueSuccessUrl");
            }
        }

        public string FailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CCAvenueFailUrl");
            }
        }

        public string WorkingKey
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CCAvenueWorkingKey");
            }
        }

        public string AccessCode
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CCAvenueAccessCode");
            }
        }
    }
}