﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace DotNetTricks.COM.PaymentGateway
{
    public class PayPal
    {
        public string Url
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PaypalUrl");
            }
        }

        public string SuccessUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PaypalSuccessUrl");
            }
        }

        public string SuccessInstalUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PaypalSuccessInstalUrl");
            }
        }

        public string FailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PaypalFailUrl");
            }
        }

        public string BusinessEmail
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PaypalEmail");
            }
        }
    }
}