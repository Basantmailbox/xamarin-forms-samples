﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace DotNetTricks.COM.PaymentGateway
{
    public class PayUmoney
    {
        public string Url
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuUrl");
            }
        }

        public string SuccessUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuSuccessUrl");
            }
        }

        public string InsSuccessUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuInsSuccessUrl");
            }
        }
        
        public string FailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuFailUrl");
            }
        }
        public string InsFailUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuInsFailUrl");
            }
        }
        public string Key
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuKey");
            }
        }

        public string Salt
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuSalt");
            }
        }
        public string Hash_Seq
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuHash_seq");
            }
        }        

        public string ServiceProvider
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("PayuServiceProvider");
            }
        }
    }
}