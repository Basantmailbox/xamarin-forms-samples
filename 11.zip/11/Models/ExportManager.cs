﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using OfficeOpenXml.Table;
using System.Net;
using System.Web;
using DNTShared.DTO;
using DNTShared;
using DNTData;

namespace DNTWebUI.Models
{
    /// <summary>
    /// Export manager
    /// </summary>
    public partial class ExportManager
    {
        #region Fields
        string _companyName;
        string _companyUrl;
        #endregion

        #region Ctor
        public ExportManager(string companyName, string companyUrl)
        {
            _companyName = "DotNetTricks";
            _companyUrl = "https://www.dotnettricks.com";
        }

        public ExportManager()
        {
            // TODO: Complete member initialization
        }
        #endregion

        public void ExcelBorderLine(ExcelWorksheet worksheet, int row, int col)
        {
            worksheet.Cells[row, col].Style.Border.Top.Style = ExcelBorderStyle.Thin;
            worksheet.Cells[row, col].Style.Border.Left.Style = ExcelBorderStyle.Thin;
            worksheet.Cells[row, col].Style.Border.Right.Style = ExcelBorderStyle.Thin;
            worksheet.Cells[row, col].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
        }

        public void GetReceiving(Stream stream, List<QueryDTO> data, string p_strPath, EnumEnquiryType type)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                var worksheet = xlPackage.Workbook.Worksheets.Add("SalesReportEnquiry");

                //Create Headers and format them
                var properties = ReportsHeader.GetReceive(type);

                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 2;
                int inc = 1;
                foreach (var order in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.EmailID;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.ContactNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.City;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.CourseName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.TrainingMode;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.SubmitDateDisplay;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    if (EnumEnquiryType.Demo == type)
                    {

                        worksheet.Cells[row, col].Value = order.FollowUpDateDisplay;
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                    }
                    if (EnumEnquiryType.Interested == type || EnumEnquiryType.Pending == type)
                    {

                        worksheet.Cells[row, col].Value = order.FollowUpDateNextDisplay;
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                    }

                    worksheet.Cells[row, col].Value = order.DomainName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Value = order.Remarks;
                    ExcelBorderLine(worksheet, row, col);
                    col++;
                    //worksheet.Cells[row, col].Value = order.ChallanNo;
                    //ExcelBorderLine(worksheet, row, col);
                    //col++;

                    //worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                    //worksheet.Cells[row, col].Value = order.ChallanDate;
                    //ExcelBorderLine(worksheet, row, col);
                    //col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(2, 1);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} SalesReport", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} SalesReport", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} SalesReport", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} SalesReport", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }
        public void GetReceivingSalesReport(Stream stream, List<QueryDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "SalesManReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveSales();

                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 2;
                int inc = 1;
                foreach (var order in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.EmailID;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.ContactNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.CourseName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;
                    worksheet.Cells[row, col].Value = order.TrainingMode;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.EnquiryTypeName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.saleman;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.SubmitDateDisplay;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.FollowUpDateDisplay;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Remarks;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(2, 1);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} SalesReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} SalesReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} SalesReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} SalesReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetReceivingMemberReport(Stream stream, List<CourseSubscriptionMemberDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "BatchMemberReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveBatchMember();

                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, 1].Value = data.Select(x => x.BatchName);
                    worksheet.Cells["A1:G1"].Merge = true;
                    worksheet.Cells[1, 1].Style.Font.Bold = true;
                    worksheet.Cells[1, 1].Style.Font.Size = 20;
                    worksheet.Cells[2, i + 1].Value = properties[i];
                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;

                    ExcelBorderLine(worksheet, 2, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 3;
                int inc = 1;
                foreach (var order in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.MobileNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.TrainingMode;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.DisSubscribeDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.DisExpiryDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Member Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }
        public void GetReceivingEventRegistrationsReport(Stream stream, List<EventRegistrationDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "EventRegistrationsReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetEventRegistrations();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, 1].Value = "Event :- " + data.Select(x => x.EventTitle).FirstOrDefault();
                    worksheet.Cells["A1:F1"].Merge = true;
                    worksheet.Cells[1, 1].Style.Font.Bold = true;
                    worksheet.Cells[1, 1].Style.Font.Size = 15;
                    worksheet.Cells[2, i + 1].Value = properties[i];
                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;

                    ExcelBorderLine(worksheet, 2, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 3;
                int inc = 1;

                foreach (var order in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.EmailId;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.MobileNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Value = order.EventDisplayDateTime;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                    worksheet.Cells[row, col].Value = order.RegistrationDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} EventRegistrationsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} EventRegistrationsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} EventRegistrationsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} EventRegistrationsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetReceivingAllStudentsReport(Stream stream, List<CourseSubscriptionMemberDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "AllStudentsReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetAllStudents();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, 1].Value = "Course :- " + data.Select(x => x.CourseName).FirstOrDefault();
                    worksheet.Cells["A1:F1"].Merge = true;
                    worksheet.Cells[1, 1].Style.Font.Bold = true;
                    worksheet.Cells[1, 1].Style.Font.Size = 15;
                    worksheet.Cells[2, i + 1].Value = properties[i];
                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;

                    ExcelBorderLine(worksheet, 2, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 3;
                int inc = 1;

                foreach (var order in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.MobileNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Value = order.TotalCourse;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                    worksheet.Cells[row, col].Value = order.CreatedDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} AllStudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} AllStudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} AllStudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} AllStudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetAllbookDownloadListReport(Stream stream, List<BookDownloadDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "AllbookDownload" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetAllBookDetails();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, 1].Value = "Book :- " + data.Select(x => x.BookName).FirstOrDefault();
                    worksheet.Cells["A1:F1"].Merge = true;
                    worksheet.Cells[1, 1].Style.Font.Bold = true;
                    worksheet.Cells[1, 1].Style.Font.Size = 15;
                    worksheet.Cells[2, i + 1].Value = properties[i];
                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;

                    ExcelBorderLine(worksheet, 2, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 3;
                int inc = 1;

                foreach (var book in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = book.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = book.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Value = book.Mobile;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                    worksheet.Cells[row, col].Value = book.DownloadDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} AllbookDownloadReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} AllbookDownloadReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} AllbookDownloadReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} AllbookDownloadReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetReceivingCampaignReport(Stream stream, MemberEmailCampaignDTO data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "CampaignReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveCampaign();

                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 2;
                int inc = 1;
                foreach (var order in data.Members)
                {
                    int col = 1;


                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(2, 1);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} CampaignReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} CampaignReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} CampaignReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Campaign Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} CampaignReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetReceivingAllMemberReport(Stream stream, List<CourseSubscriptionMemberDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "MemberReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveMemberCampaign();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);
                }
                string ordernumber = string.Empty;

                int row = 3;
                int inc = 1;

                foreach (var order in data)
                {
                    int col = 1;

                    //worksheet.Cells[row, col].Value = inc;
                    //ExcelBorderLine(worksheet, row, col);
                    //col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.ContactNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Value = order.CurrentLocation;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} StudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} StudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} StudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} StudentsReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetReceivingAllQuizReport(Stream stream, List<MockUpTestAttemptedStatusDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "QuizReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveQuizList();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, 1].Value = "Quiz :- " + data.Select(x => x.MockupTestName).FirstOrDefault();
                    worksheet.Cells["A1:F1"].Merge = true;
                    worksheet.Cells[1, 1].Style.Font.Bold = true;
                    worksheet.Cells[1, 1].Style.Font.Size = 15;
                    worksheet.Cells[2, i + 1].Value = properties[i];
                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;

                    ExcelBorderLine(worksheet, 2, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 3;
                int inc = 1;

                foreach (var item in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = item.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = item.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Value = item.MobileNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;


                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                    worksheet.Cells[row, col].Value = item.TestTakenDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = item.Totalscore;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} AllQuizReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} AllQuizReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} AllQuizReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Sales Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} AllQuizReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }


        public void GetReceivingAllMemberReport(Stream stream, List<MemberDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "MemberReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveMember();

                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);
                }

                string ordernumber = string.Empty;

                int row = 2;
                int inc = 1;
                foreach (var order in data)
                {
                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Name;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Email;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.ContactNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                    worksheet.Cells[row, col].Value = order.CreatedDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    if (order.IsVerified == null && order.IsActive == false)
                    {
                        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                        worksheet.Cells[row, col].Value = "";
                        ExcelBorderLine(worksheet, row, col);
                        col++;

                        worksheet.Cells[row, col].Value = "un-verified";
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                    }
                    else if (order.IsVerified == true && order.IsActive == true)
                    {
                        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                        worksheet.Cells[row, col].Value = order.VerificationDate;
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                        worksheet.Cells[row, col].Value = "verified and active";
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                    }
                    else if (order.IsVerified == true && order.IsActive == false)
                    {
                        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
                        worksheet.Cells[row, col].Value = order.VerificationDate;
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                        worksheet.Cells[row, col].Value = "de-active";
                        ExcelBorderLine(worksheet, row, col);
                        col++;
                    }

                    row++;
                    inc++;
                }

                worksheet.View.FreezePanes(2, 1);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Member Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} MemberReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }


        public void GetReceivingAllArticleReport(Stream stream, List<TutorialDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "AuthorReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);
                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveArticleHeader();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);

                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml("#E9F2FC");
                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
                    fillHEADER.PatternType = ExcelFillStyle.Solid;
                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
                }
                string ordernumber = string.Empty;

                int row = 2;
                int inc = 1;
                decimal totalAmt = 0;
                foreach (var order in data)
                {

                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Title;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = WebConfigSetting.BaseURL + order.ArticleUrl;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    var ArticleType = "";
                    if (order.ArticleType == (int)EnumArticleType.Beginners)
                    {
                        ArticleType += EnumArticleType.Beginners+ ":- DNT" + order.ArticleLevel;
                    }
                    if (order.ArticleType == (int)EnumArticleType.Intermediate)
                    {
                        ArticleType += EnumArticleType.Intermediate + ":- DNT" + order.ArticleLevel;
                    }
                    if (order.ArticleType == (int)EnumArticleType.Advanced)
                    {
                        ArticleType += EnumArticleType.Advanced + ":- DNT" + order.ArticleLevel;
                    }
                    worksheet.Cells[row, col].Value = ArticleType;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.WordCount;
                    ExcelBorderLine(worksheet, row, col);
                    col++;
                    worksheet.Cells[row, col].Value = "₹ " + order.WordPrice;
                    ExcelBorderLine(worksheet, row, col);           
                    col++;
                    //worksheet.Cells[row, col].Value = order.CurrentLocation;
                    //ExcelBorderLine(worksheet, row, col);
                    //col++;

                    row++;
                    inc++;
                    totalAmt += order.WordPrice;
                }
                worksheet.Cells[row, 5].Value = "Total Amount:- ";
                ExcelBorderLine(worksheet, row, 5);

                worksheet.Cells[row, 6].Value = "₹ "+totalAmt;
                ExcelBorderLine(worksheet, row, 6);    

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Author Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }

        public void GetReceivingAllAuthorAmountReport(Stream stream, List<TutorialExcelDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "AuthorReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);
                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveAllAuhtorArticleHeader();
                for (int i = 0; i < properties.Length; i++)
                {
                    worksheet.Cells[1, i + 1].Value = properties[i];
                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 1, i + 1);

                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml("#E9F2FC");
                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
                    fillHEADER.PatternType = ExcelFillStyle.Solid;
                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
                }
                string ordernumber = string.Empty;

                int row = 2;
                int inc = 1;
                decimal totalAmt = 0;
                foreach (var order in data)
                {

                    int col = 1;

                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.AuthorsName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.AuthorsEmail;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.Date;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.totalArticle;
                    ExcelBorderLine(worksheet, row, col);
                    col++;
                    worksheet.Cells[row, col].Value = "₹ " + order.WordPrice;
                    ExcelBorderLine(worksheet, row, col);
                    col++;
                    //worksheet.Cells[row, col].Value = order.CurrentLocation;
                    //ExcelBorderLine(worksheet, row, col);
                    //col++;

                    row++;
                    inc++;
                    totalAmt += order.WordPrice;
                }
                worksheet.Cells[row, 5].Value = "Total Amount:- ";
                ExcelBorderLine(worksheet, row, 5);

                worksheet.Cells[row, 6].Value = "₹ " + totalAmt;
                ExcelBorderLine(worksheet, row, 6);

                worksheet.View.FreezePanes(3, 2);

                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Author Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} AuthorReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }
        //public void GetVI(Stream stream, IList<VIItemDto> data, VIReportDto model, string paths, string p_strPath)
        //{
        //    try
        //    {
        //        if (stream == null)
        //            throw new ArgumentNullException("stream");

        //        WebClient client = new WebClient();
        //        using (var xlPackage = new ExcelPackage(stream))
        //        {
        //            // get handle to the existing worksheet
        //            var worksheet = xlPackage.Workbook.Worksheets.Add("VI Report");

        //            worksheet.Cells["A1:K1"].Merge = true;
        //            worksheet.Cells["A1:K1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //            worksheet.Cells["A1:K1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //            worksheet.Cells["A1"].Value = "VI Status - " + model.LocationName;
        //            worksheet.Cells["A1"].Style.Font.Bold = true;
        //            worksheet.Cells["A1"].Style.Font.Size = 18;
        //            string HEXARECEIVE = "#F2F2F2";
        //            Color _color = System.Drawing.ColorTranslator.FromHtml(HEXARECEIVE);
        //            var fillColor2 = worksheet.Cells["A1"].Style.Fill;
        //            fillColor2.PatternType = ExcelFillStyle.Solid;
        //            fillColor2.BackgroundColor.SetColor(_color);

        //            //Create Headers and format them
        //            var properties = ReportsHeader.GetVI();


        //            string HEXAHEADER = "#8DB4E2";

        //            for (int i = 0; i < properties.Length; i++)
        //            {
        //                worksheet.Cells[2, i + 1].Value = properties[i];
        //                worksheet.Cells[2, i + 1].Style.Font.Bold = true;
        //                Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //                var fillHEADER = worksheet.Cells[2, i + 1].Style.Fill;
        //                fillHEADER.PatternType = ExcelFillStyle.Solid;
        //                fillHEADER.BackgroundColor.SetColor(_colorHEADER);

        //            }

        //            string ordernumber = string.Empty;

        //            int row = 3;
        //            int inc = 0;
        //            foreach (var order in data)
        //            {
        //                int col = 1;

        //                worksheet.Cells[row, col].Value = ++inc;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.SerialNo1;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.CTDIRMANo;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.ModelName;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.Product_Desc;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.CTDI_RONo;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.LocationRecName;
        //                col++;

        //                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //                worksheet.Cells[row, col].Value = order.MaterialRecDate;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.VIfailDescription;
        //                col++;

        //                worksheet.Cells[row, col].Value = order.Remarks1;
        //                col++;

        //                if (model.TblDocumentsDtos.Count() > 0)
        //                {
        //                    var v = model.TblDocumentsDtos.Any(x => x.InvLocId == order.InvLocId);
        //                    if (v)
        //                    {
        //                        var fileName = model.TblDocumentsDtos.SingleOrDefault(x => x.InvLocId == order.InvLocId).FileName.Distinct().Take(1);

        //                        foreach (var imgName in fileName)
        //                        {

        //                            try
        //                            {
        //                                worksheet.Row(row).Height = 83.00d;
        //                                System.Drawing.Image image = System.Drawing.Image.FromStream(new MemoryStream(client.DownloadData(paths + imgName)));
        //                                var picture = worksheet.Drawings.AddPicture("" + imgName + "", image);
        //                                int c = col;
        //                                int r = row;
        //                                picture.From.Column = c - 1;
        //                                picture.From.Row = r - 1;
        //                                picture.SetSize(110, 110);
        //                                picture.From.ColumnOff = Pixel2MTU(2);
        //                                picture.From.RowOff = Pixel2MTU(2);
        //                            }
        //                            catch
        //                            {
        //                                worksheet.Cells[row, col].Value = "NA";
        //                            }
        //                        }
        //                    }
        //                    else
        //                    {
        //                        worksheet.Cells[row, col].Value = "NA";
        //                    }

        //                    col++;
        //                }
        //                else
        //                {
        //                    worksheet.Cells[row, col].Value = "NA";
        //                    col++;
        //                }


        //                row++;
        //            }

        //            worksheet.View.FreezePanes(2, 1);

        //            worksheet.Cells[string.Format("A1:K{0}", row - 1)].AutoFitColumns();
        //            //worksheet.Cells[string.Format("A1:K{0}", row - 1)].Style.Border.Top.Style = ExcelBorderStyle.Thin;
        //            xlPackage.Workbook.Properties.Title = string.Format("{0} VI", "CTDI");
        //            xlPackage.Workbook.Properties.Author = _companyName;
        //            xlPackage.Workbook.Properties.Subject = string.Format("{0} VI", "CTDI");
        //            xlPackage.Workbook.Properties.Keywords = string.Format("{0} VI", "CTDI");
        //            xlPackage.Workbook.Properties.Category = "VI Report";
        //            xlPackage.Workbook.Properties.Comments = string.Format("{0} VI", "CTDI");
        //            xlPackage.Workbook.Properties.Company = "CTDI";
        //            //xlPackage.Save();
        //            if (File.Exists(p_strPath))
        //                File.Delete(p_strPath);

        //            using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //            {
        //                xlPackage.SaveAs(fs);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public int Pixel2MTU(int pixels)
        //{
        //    int mtus = pixels * 9525;
        //    return mtus;
        //}


        //public void GetDailyRepairRandR(Stream stream, IList<DailyRepairReporItemDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {
        //        // get handle to the existing worksheet
        //        var worksheet1 = xlPackage.Workbook.Worksheets.Add("HUAWEI");

        //        //Create Headers and format them
        //        var properties1 = CTDI.Shared.ReportsHeader.GetDailyRepair();
        //        worksheet1.Row(1).Height = 30.00d;
        //        worksheet1.Cells["A1:AK1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //        for (int i = 0; i < properties1.Length; i++)
        //        {
        //            worksheet1.Cells[1, i + 1].Value = properties1[i];
        //            worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        //            ExcelBorderLine(worksheet1, 1, i + 1);

        //            string HEXAHEADER = "#8DB4E2";
        //            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //            var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //            fillHEADER.PatternType = ExcelFillStyle.Solid;
        //            fillHEADER.BackgroundColor.SetColor(_colorHEADER);

        //        }

        //        string ordernumber = string.Empty;

        //        int row = 2;
        //        int inc = 1;
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet1.Cells[row, col].Value = inc;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CTDI_RONo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductDese;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.LocationRecAddress;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CTDIRMANo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SerialNo1;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductNo;
        //            col++;

        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //            col++;

        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.PreAlertRaisedDate;
        //            col++;

        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.DispatchDate;
        //            col++;

        //            if (order.MonthYear.HasValue)
        //            {
        //                worksheet1.Cells[row, col].Value = order.MonthYear.Value.ToString("MMM") + "'" + order.MonthYear.Value.ToString("yy");
        //            }
        //            else
        //            {
        //                worksheet1.Cells[row, col].Value = "";
        //            }
        //            col++;


        //            worksheet1.Cells[row, col].Value = order.RepairStatus;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.FinalRepairStatus;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TAT;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TATSLA;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.VIStatus;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.VIInspComnt;
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CarrierName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CarrierDocketNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.FailureCode;
        //            col++;


        //            worksheet1.Cells[row, col].Value = order.CorrectiveAction;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Location;
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = "";
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RMARequestedBy;
        //            col++;


        //            row++;
        //            inc++;
        //        }

        //        worksheet1.View.FreezePanes(2, 1);

        //        worksheet1.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();


        //        xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} Daily Repair R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} Daily Repair R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "Daily Repair R&R Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} Daily Repair R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        //        //xlPackage.Save();
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}

        //private void DailyRepairRandR4NEC(ExcelPackage xlPackage, IList<DailyRepairReporItemDto> data)
        //{
        //    // get handle to the existing worksheet
        //    var worksheet = xlPackage.Workbook.Worksheets.Add("NEC");

        //    //Create Headers and format them
        //    var properties = new string[]
        //            {
        //                 "Sl. No.",
        //                                    "RO NO.",
        //                                    "Unit Description",
        //                                    "Model",
        //                                    "Circle",
        //                                    "Serial Number",
        //                                    "RMA #",
        //                                    "Date of Received",
        //                                    "Date of Dispatch",
        //                                    "Month-Year",
        //                                    "Repair Status",
        //                                    "Status(IQC)",
        //                                    "TAT",
        //                                    "TAT SLA defined",
        //                                    "IN TAT/Out of TAT",
        //                                    "Receiving Inspection Status",
        //                                    "Pre-alert Raised date",
        //                                    "Reason for OOT",
        //                                    "Courier Details",
        //                                    "Courier Docket no",
        //                                    "General Fault Description Reported",
        //                                    "Corrective Action",
        //                                    "SAC Sign by TTSL authority Name",
        //                                    "Labour Charges",
        //                                    "Material Charges",
        //                                    "Total Repair Charges",
        //                                    "Labour  TransactionId",
        //                                    "Material TransactionId",
        //                                    "Total TransactionId"
        //            };
        //    worksheet.Row(1).Height = 30.00d;
        //    worksheet.Cells["A1:AF1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    for (int i = 0; i < properties.Length; i++)
        //    {
        //        worksheet.Cells[1, i + 1].Value = properties[i];
        //        worksheet.Cells[1, i + 1].Style.Font.Bold = true;

        //        ExcelBorderLine(worksheet, 1, i + 1);
        //        if (properties[i] == "Date of Dispatch" || properties[i] == "Month-Year" || properties[i] == "Receiving Inspection Status" || properties[i] == "Pre-alert Raised date" || properties[i] == "Reason for OOT" || properties[i] == "SAC Sign by TTSL authority Name" || properties[i] == "Labour Charges" || properties[i] == "Material Charges")
        //        {
        //            string HEXAHEADER = "#FFFF00";
        //            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //            var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //            fillHEADER.PatternType = ExcelFillStyle.Solid;
        //            fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        }
        //        else
        //        {
        //            string HEXAHEADER = "#8DB4E2";
        //            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //            var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //            fillHEADER.PatternType = ExcelFillStyle.Solid;
        //            fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        }
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;
        //    foreach (var order in data)
        //    {
        //        int col = 1;

        //        worksheet.Cells[row, col].Value = inc;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CTDI_RONo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.ProductDese;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.ModelName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.LocationRecAddress;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.SerialNo1;
        //        col++;



        //        worksheet.Cells[row, col].Value = order.CTDIRMANo;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.UnitRecDate;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.DispatchDate;
        //        col++;

        //        if (order.MonthYear.HasValue)
        //        {
        //            worksheet.Cells[row, col].Value = order.MonthYear.Value.ToString("MMM") + "'" + order.MonthYear.Value.ToString("yy");
        //        }
        //        else
        //        {
        //            worksheet.Cells[row, col].Value = "";
        //        }
        //        col++;

        //        worksheet.Cells[row, col].Value = order.RepairStatus;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.FinalRepairStatus;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TAT;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TATSLA;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        //        col++;

        //        worksheet.Cells[row, col].Value = order.VIInspComnt;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.PreAlertRaisedDate;
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CarrierName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CarrierDocketNo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.FailureCode;
        //        col++;


        //        worksheet.Cells[row, col].Value = order.CorrectiveAction;
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;


        //        row++;
        //        inc++;
        //    }

        //    worksheet.View.FreezePanes(2, 1);

        //    worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();


        //}

        //private void DailyRepairRandR4Huawei(ExcelPackage xlPackage, IList<DailyRepairReporItemDto> data)
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add("HUAWEI");

        //    //Create Headers and format them
        //    var properties1 = new string[]
        //            {
        //                                    "Sl. No.",
        //                                    "RO NO.",
        //                                    "Unit Description",
        //                                    "Family",
        //                                    "Source Circle",
        //                                    "RMA #",
        //                                    "Serial Number",
        //                                    "Part Code",
        //                                    "Date of Received",
        //                                    "Pre-alert Raised date",
        //                                    "Dispatch Date",
        //                                    "Month-Year",
        //                                    "Repair Status",
        //                                    "Status(IQC)",
        //                                    "TAT",
        //                                    "TAT SLA defined",
        //                                    "IN TAT/Out of TAT",
        //                                    "VI STATUS",
        //                                    "Visual Inspection Comments",
        //                                    "Software Version",
        //                                    "Reason for OOT",
        //                                    "REMARKS",
        //                                    "Courier Details",
        //                                    "Courier Docket no",
        //                                    "General fault description reported",
        //                                    "Corrective Action",
        //                                    "Dispatch Circle",
        //                                    "WCC Sign by TTSL authority Name",
        //                                    "Labour Charges",
        //                                    "Material Charges",
        //                                    "Total Repair Charges",
        //                                    "Labour  TransactionId",
        //                                    "Material TransactionId",
        //                                    "Remarks",
        //                                    "Tester Ready Date",
        //                                    "Learning Period Closed Date",
        //                                    "Technology & BTS Model",
        //                                    "RMA Requested by"
        //            };
        //    worksheet1.Row(1).Height = 30.00d;
        //    worksheet1.Cells["A1:AK1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    for (int i = 0; i < properties1.Length; i++)
        //    {
        //        worksheet1.Cells[1, i + 1].Value = properties1[i];
        //        worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 1, i + 1);
        //        //if (properties1[i] == "Visual Inspection Comments"
        //        //    || properties1[i] == "Reason for OOT" || properties1[i] == "REMARKS" || properties1[i] == "WCC Sign by TTSL authority Name"
        //        //    || properties1[i] == "Labour Charges" || properties1[i] == "Material Charges" || properties1[i] == "Remarks")
        //        //{
        //        //    string HEXAHEADER = "#FFFF00";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else if (properties1[i] == "Labour Charges")
        //        //{
        //        //    string HEXAHEADER = "#DA9694";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else if (properties1[i] == "RMA Requested by")
        //        //{
        //        //    string HEXAHEADER = "#B1A0C7";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else
        //        //{
        //        string HEXAHEADER = "#8DB4E2";
        //        Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        // }
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;
        //    foreach (var order in data)
        //    {
        //        int col = 1;

        //        worksheet1.Cells[row, col].Value = inc;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CTDI_RONo;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ProductDese;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ModelName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.LocationRecAddress;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CTDIRMANo;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SerialNo1;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ProductNo;
        //        col++;

        //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //        col++;

        //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet1.Cells[row, col].Value = order.PreAlertRaisedDate;
        //        col++;

        //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet1.Cells[row, col].Value = order.DispatchDate;
        //        col++;

        //        if (order.MonthYear.HasValue)
        //        {
        //            worksheet1.Cells[row, col].Value = order.MonthYear.Value.ToString("MMM") + "'" + order.MonthYear.Value.ToString("yy");
        //        }
        //        else
        //        {
        //            worksheet1.Cells[row, col].Value = "";
        //        }
        //        col++;


        //        worksheet1.Cells[row, col].Value = order.RepairStatus;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.FinalRepairStatus;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TAT;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TATSLA;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.VIStatus;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.VIInspComnt;
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CarrierName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CarrierDocketNo;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.FailureCode;
        //        col++;


        //        worksheet1.Cells[row, col].Value = order.CorrectiveAction;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.Location;
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = "";
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.RMARequestedBy;
        //        col++;


        //        row++;
        //        inc++;
        //    }

        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        //}


        //public void RandR(Stream stream, IList<RandRReportItemDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {
        //        var worksheet1 = xlPackage.Workbook.Worksheets.Add("R_and_R");
        //        //Create Headers and format them
        //        var headerList = CTDI.Shared.ReportsHeader.GetRandR4Huawei();


        //        worksheet1.Row(1).Height = 30.00d;
        //        worksheet1.Cells["A1:AK1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //        for (int i = 0; i < headerList.Length; i++)
        //        {
        //            worksheet1.Cells[1, i + 1].Value = headerList[i];
        //            worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        //            ExcelBorderLine(worksheet1, 1, i + 1);

        //            string HEXAHEADER = "#8DB4E2";
        //            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //            var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //            fillHEADER.PatternType = ExcelFillStyle.Solid;
        //            fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //            // }
        //        }

        //        string ordernumber = string.Empty;

        //        int row = 2;
        //        int inc = 1;
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet1.Cells[row, col].Value = inc;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CTDI_RONo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductDese;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.LocationRecName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CTDIRMANo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SerialNo1;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductNo;
        //            col++;

        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //            col++;

        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.PreAlertRaisedDate;
        //            col++;

        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.DispatchDate;
        //            col++;

        //            if (order.MonthYear.HasValue)
        //            {
        //                worksheet1.Cells[row, col].Value = order.MonthYear.Value.ToString("MMM") + "'" + order.MonthYear.Value.ToString("yy");
        //            }
        //            else
        //            {
        //                worksheet1.Cells[row, col].Value = "";
        //            }
        //            col++;


        //            worksheet1.Cells[row, col].Value = order.RepairStatus;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TAT;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TATSLA;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.VIStatus;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.VIRemarks;
        //            col++;

        //            //worksheet1.Cells[row, col].Value = order.softVers;
        //            //col++;

        //            worksheet1.Cells[row, col].Value = order.ReasonForOOT;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReceivingRemarks;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CarrierName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CarrierDocketNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.GeneralFaultDesc;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.CorrectiveAction;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.LocationRecName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.WCCSignByTTSLAuthorityName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.LabourCharges;
        //            col++;


        //            worksheet1.Cells[row, col].Value = order.MaterialCharges;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.LabourInvoice;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.MaterialInvoice;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TesterReadyDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.LearningPeriodClosedDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TechnologyAndBTSModel;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RMARequestedBy;
        //            col++;

        //            row++;
        //            inc++;
        //        }

        //        worksheet1.View.FreezePanes(2, 1);

        //        worksheet1.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();






        //        xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "R&R Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} R&R", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}

        ////public void RandR(Stream stream, RandRReportDto data, string p_strPath, ReportOEMType reportOEMType)
        ////{
        ////    if (stream == null)
        ////        throw new ArgumentNullException("stream");

        ////    using (var xlPackage = new ExcelPackage(stream))
        ////    {
        ////        if (reportOEMType == ReportOEMType.NEC)
        ////        {
        ////            RandR4NEC(xlPackage, data.ReportItemsNECDtos, ReportOEMType.NEC.ToString());
        ////        }
        ////        else if (reportOEMType == ReportOEMType.HUAWEI)
        ////        {
        ////            RandR4Huawei(xlPackage, data.ReportItemsHuaweiDtos, ReportOEMType.HUAWEI.ToString());
        ////        }
        ////        else if (reportOEMType == ReportOEMType.NSN)
        ////        {
        ////            RandR4NSN(xlPackage, data.ReportItems4NSNDtos, ReportOEMType.NSN.ToString());
        ////        }

        ////        xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Author = _companyName;
        ////        xlPackage.Workbook.Properties.Subject = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Keywords = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Category = "R&R Report";
        ////        xlPackage.Workbook.Properties.Comments = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Company = "CTDI";
        ////        //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        ////        //xlPackage.Save();
        ////        if (File.Exists(p_strPath))
        ////            File.Delete(p_strPath);

        ////        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////        {
        ////            xlPackage.SaveAs(fs);
        ////        }
        ////    }
        ////}

        //public void RandR4NEC(ExcelPackage xlPackage, IList<RandRReportItemDto> data, string sheetName)
        //{
        //    // get handle to the existing worksheet
        //    var worksheet = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    var properties = CTDI.Shared.ReportsHeader.GetRandR4NEC();


        //    //"STATUS(IQC)",  "Total Repair Charges",       
        //    worksheet.Row(1).Height = 30.00d;
        //    worksheet.Cells["A1:AF1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    for (int i = 0; i < properties.Length; i++)
        //    {
        //        worksheet.Cells[1, i + 1].Value = properties[i];
        //        worksheet.Cells[1, i + 1].Style.Font.Bold = true;

        //        //ExcelBorderLine(worksheet, 1, i + 1);
        //        //if (properties[i] == "Reason for OOT" || properties[i] == "SAC Sign by TTSL authority Name" || properties[i] == "Labour Charges" || properties[i] == "Material Charges")
        //        //{
        //        //    string HEXAHEADER = "#FFFF00";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else
        //        //{
        //        string HEXAHEADER = "#8DB4E2";
        //        Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;
        //    foreach (var order in data)
        //    {
        //        int col = 1;

        //        worksheet.Cells[row, col].Value = inc;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CTDI_RONo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.ProductDese;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.ModelName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.LocationRecName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.SerialNo1;
        //        col++;



        //        worksheet.Cells[row, col].Value = order.CTDIRMANo;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.UnitRecDate;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.DispatchDate;
        //        col++;

        //        if (order.MonthYear.HasValue)
        //        {
        //            worksheet.Cells[row, col].Value = order.MonthYear.Value.ToString("MMM") + "'" + order.MonthYear.Value.ToString("yy");
        //        }
        //        else
        //        {
        //            worksheet.Cells[row, col].Value = "";
        //        }
        //        col++;

        //        worksheet.Cells[row, col].Value = order.RepairStatus;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TAT;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TATSLA;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        //        col++;

        //        worksheet.Cells[row, col].Value = order.VIRemarks;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.PreAlertRaisedDate;
        //        col++;

        //        worksheet.Cells[row, col].Value = "";
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CarrierName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CarrierDocketNo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.GeneralFaultDesc;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CorrectiveAction;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.SACSignByTTSLAuthorityName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.LabourCharges;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.MaterialCharges;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.LabourInvoice;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.MaterialInvoice;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.TotalInvoice;
        //        col++;

        //        row++;
        //        inc++;
        //    }

        //    worksheet.View.FreezePanes(2, 1);

        //    worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        //}

        //public void RandR4Huawei(ExcelPackage xlPackage, IList<RandRReportItemDto> data, string sheetName)
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    var headerList = CTDI.Shared.ReportsHeader.GetRandR4Huawei();
        //    //  "Total Repair Charges",  "STATUS(IQC)", 
        //    worksheet1.Row(1).Height = 30.00d;
        //    worksheet1.Cells["A1:AK1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    for (int i = 0; i < headerList.Length; i++)
        //    {
        //        worksheet1.Cells[1, i + 1].Value = headerList[i];
        //        worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 1, i + 1);
        //        //if (headerList[i] == "Reason for OOT" || headerList[i] == "REMARKS" || headerList[i] == "Labour Charges" || headerList[i] == "Material Charges" || headerList[i] == "Remarks")
        //        //{
        //        //    string HEXAHEADER = "#FFFF00";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else if (headerList[i] == "Labour Charges")
        //        //{
        //        //    string HEXAHEADER = "#DA9694";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else if (headerList[i] == "RMA Requested by")
        //        //{
        //        //    string HEXAHEADER = "#B1A0C7";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else if (headerList[i] == "Technology & BTS Model")
        //        //{
        //        //    string HEXAHEADER = "#c77a7a";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else
        //        //{
        //        string HEXAHEADER = "#8DB4E2";
        //        Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        // }
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;
        //    foreach (var order in data)
        //    {
        //        int col = 1;

        //        worksheet1.Cells[row, col].Value = inc;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CTDI_RONo;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ProductDese;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ModelName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.LocationRecName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CTDIRMANo;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SerialNo1;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ProductNo;
        //        col++;

        //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //        col++;

        //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet1.Cells[row, col].Value = order.PreAlertRaisedDate;
        //        col++;

        //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet1.Cells[row, col].Value = order.DispatchDate;
        //        col++;

        //        if (order.MonthYear.HasValue)
        //        {
        //            worksheet1.Cells[row, col].Value = order.MonthYear.Value.ToString("MMM") + "'" + order.MonthYear.Value.ToString("yy");
        //        }
        //        else
        //        {
        //            worksheet1.Cells[row, col].Value = "";
        //        }
        //        col++;


        //        worksheet1.Cells[row, col].Value = order.RepairStatus;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TAT;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TATSLA;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.VIStatus;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.VIRemarks;
        //        col++;

        //        //worksheet1.Cells[row, col].Value = order.softVers;
        //        //col++;

        //        worksheet1.Cells[row, col].Value = order.ReasonForOOT;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.ReceivingRemarks;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CarrierName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CarrierDocketNo;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.GeneralFaultDesc;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.CorrectiveAction;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.LocationRecName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.WCCSignByTTSLAuthorityName;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.LabourCharges;
        //        col++;


        //        worksheet1.Cells[row, col].Value = order.MaterialCharges;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.LabourInvoice;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.MaterialInvoice;
        //        col++;

        //        //worksheet1.Cells[row, col].Value = order.remarks;
        //        //col++;

        //        worksheet1.Cells[row, col].Value = order.TesterReadyDate;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.LearningPeriodClosedDate;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.TechnologyAndBTSModel;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.RMARequestedBy;
        //        col++;


        //        row++;
        //        inc++;
        //    }

        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        //}

        //public void RandR4NSN(ExcelPackage xlPackage, IList<RandRReportItem4NSNDto> data, string sheetName)
        //{
        //    // get handle to the existing worksheet
        //    var worksheet = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    var properties = CTDI.Shared.ReportsHeader.GetRandR4NSN();
        //    worksheet.Row(1).Height = 30.00d;
        //    worksheet.Cells["A1:Z1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    for (int i = 0; i < properties.Length; i++)
        //    {
        //        worksheet.Cells[1, i + 1].Value = properties[i];
        //        worksheet.Cells[1, i + 1].Style.Font.Bold = true;

        //        ExcelBorderLine(worksheet, 1, i + 1);
        //        string HexaHeader = "#8DB4E2";

        //        //if (properties[i] == "customer priority" || properties[i] == "Repair date" || properties[i] == "Repair TAT" || properties[i] == "Avg TAT")
        //        //{
        //        //    HexaHeader = "#FFFF00";
        //        //    //Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    //var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //        //    //fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    //fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        //else
        //        //{
        //        //    string HEXAHEADER = "#8DB4E2";
        //        //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        //    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //        //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        //}
        //        Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HexaHeader);
        //        var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;
        //    foreach (var order in data)
        //    {
        //        int col = 1;

        //        worksheet.Cells[row, col].Value = inc;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CTDIRONo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.Category;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.Model;
        //        col++;

        //        worksheet.Cells[row, col].Value = order._2G_3G;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.OEM;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CircleOrLocation;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.Serial_Number;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.RMA;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.DateOfReceived;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.DateOfDispatch;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CustomerPriority;
        //        col++;

        //        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //        worksheet.Cells[row, col].Value = order.RepairDate;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.RepairTAT;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.AvgTAT;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.Status;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.ReceivingInspectionStatus;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CourierDetails;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.CourierDocketNo;
        //        col++;


        //        worksheet.Cells[row, col].Value = order.GeneralFaultDescriptionReported;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.SACSignByTTSLAuthorityName;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.LabourInvoiceNo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.RepairedCharges;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.MaterialInvoiceNo;
        //        col++;

        //        worksheet.Cells[row, col].Value = order.MaterialCharges;
        //        col++;

        //        row++;
        //        inc++;
        //    }

        //    worksheet.View.FreezePanes(2, 1);

        //    worksheet.Cells[string.Format("A1:Z{0}", row - 1)].AutoFitColumns();

        //}

        ////public void RandR4AllOEM(Stream stream, RandRReportDto data, string p_strPath)
        ////{
        ////    if (stream == null)
        ////        throw new ArgumentNullException("stream");

        ////    using (var xlPackage = new ExcelPackage(stream))
        ////    {

        ////        List<string> oemsLst = data.ReportItemsHuaweiDtos.Select(q => q.ProductType).Distinct().ToList();
        ////        if (oemsLst.Count() > 0)
        ////        {
        ////            foreach (string item in oemsLst)
        ////            {
        ////                RandR4Huawei(xlPackage, data.ReportItemsHuaweiDtos.Where(q => q.ProductType == item).ToList(), item + "_Huawei");
        ////            }
        ////        }

        ////        xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Author = _companyName;
        ////        xlPackage.Workbook.Properties.Subject = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Keywords = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Category = "R&R Report";
        ////        xlPackage.Workbook.Properties.Comments = string.Format("{0} R&R", "CTDI");
        ////        xlPackage.Workbook.Properties.Company = "CTDI";
        ////        if (File.Exists(p_strPath))
        ////            File.Delete(p_strPath);
        ////        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////        {
        ////            xlPackage.SaveAs(fs);
        ////        }
        ////    }
        ////}
        ////        public void ExportPicklistToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.PicklistReportModel.ReceivingData> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("Inventory");

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                        "Picklist ID","MR #","Product Type","OEM","Product Family",
        ////                        "Category","Part #","Description",
        ////                        "Qty","Bin","Serial #","Repair Order #"                
        ////                    };

        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = properties[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = order.PicklistID;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.MRNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.productName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.oem;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_desc;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = "1";
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.Bin;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RO;
        ////                    col++;

        ////                    row++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Picklist", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Picklist", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Picklist", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Picklist Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Picklist", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public void ExportPickingToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.IssuedModel.ReceivingData> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("Picking");

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                        "Picker Name","Picklist ID","Product Type","OEM","Product Family",
        ////                        "Category","Part #","Description",
        ////                        "Qty","Serial #",
        ////                        "Repair Order #","Pick Date","Location"                
        ////                    };

        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = properties[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = order.pickerName;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.PicklistID;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.productName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.oem;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_desc;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = "1";
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RO;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.PickDate;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.location;
        ////                    col++;

        ////                    row++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Issued", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Issued", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Issued", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Issued Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Issued", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public void ExportROLookUpToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.ROLookUpModel.ReceivingData> data)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("RO Look Up");

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                        "Product Type","OEM","Product Family","Category","Part #","Description",
        ////                        "Qty","Bin","Unit Price","Serial #","Repair Order #","Status"               
        ////                    };

        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = properties[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = order.productName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.oem;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_desc;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = "1";
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.bin;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.unit_price;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RO;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.status;
        ////                    col++;


        ////                    row++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Receiving", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Receiving", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Receiving", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "RO lookup Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Receiving", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                xlPackage.Save();
        ////            }
        ////        }

        ////        public void ExportReadytoShipToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.ReadytoShipModel.ReceivingData> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("Ready to Ship");

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                        "Product Type","OEM","Product Family",
        ////                        "Category","Part #","Description",
        ////                        "Serial #","Qty","Bin","CTDI RMA/Order #",
        ////                        "Customer RMA #","Repair Order #","Unit Price",
        ////                        "Location","Remarks"                  
        ////                    };

        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = properties[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = order.productName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.oem;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_desc;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = "1";
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.bin;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.CTDI_RMA;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Customer_RMA;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RO;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.unit_price;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.location;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.remarks;
        ////                    col++;

        ////                    row++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} ReadyToShip", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} ReadyToShip", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} ReadyToShip", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Ready to ship Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} ReadyToShip", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public int Pixel2MTU(int pixels)
        ////        {
        ////            int mtus = pixels * 9525;
        ////            return mtus;
        ////        }

        ////        public void ExportVIReportToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.VIReportModel.ReceivingData> data, VIReportModel model, string paths, string p_strPath)
        ////        {
        ////            try
        ////            {
        ////                if (stream == null)
        ////                    throw new ArgumentNullException("stream");

        ////                WebClient client = new WebClient();
        ////                using (var xlPackage = new ExcelPackage(stream))
        ////                {
        ////                    // get handle to the existing worksheet
        ////                    var worksheet = xlPackage.Workbook.Worksheets.Add("VI Report");

        ////                    worksheet.Cells["A1:K1"].Merge = true;
        ////                    worksheet.Cells["A1:K1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////                    worksheet.Cells["A1:K1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////                    worksheet.Cells["A1"].Value = "VI Status - " + model.Loc;
        ////                    worksheet.Cells["A1"].Style.Font.Bold = true;
        ////                    worksheet.Cells["A1"].Style.Font.Size = 18;
        ////                    string HEXARECEIVE = "#F2F2F2";
        ////                    Color _color = System.Drawing.ColorTranslator.FromHtml(HEXARECEIVE);
        ////                    var fillColor2 = worksheet.Cells["A1"].Style.Fill;
        ////                    fillColor2.PatternType = ExcelFillStyle.Solid;
        ////                    fillColor2.BackgroundColor.SetColor(_color);

        ////                    //Create Headers and format them
        ////                    var properties = new string[]
        ////                    {
        ////                        "S.R","Unit Sr.No.","RMA No.","Model",
        ////                        "Unit Description","RO No.","WH",
        ////                        "Rec.date","VI Status","Remark","Photo1"
        ////                    };

        ////                    string HEXAHEADER = "#8DB4E2";

        ////                    for (int i = 0; i < properties.Length; i++)
        ////                    {
        ////                        worksheet.Cells[2, i + 1].Value = properties[i];
        ////                        worksheet.Cells[2, i + 1].Style.Font.Bold = true;
        ////                        Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                        var fillHEADER = worksheet.Cells[2, i + 1].Style.Fill;
        ////                        fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                        fillHEADER.BackgroundColor.SetColor(_colorHEADER);

        ////                    }

        ////                    string ordernumber = string.Empty;

        ////                    int row = 3;
        ////                    int inc = 0;
        ////                    foreach (var order in data)
        ////                    {
        ////                        int col = 1;

        ////                        worksheet.Cells[row, col].Value = ++inc;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.ctdiRMANo;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.modelName;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.unitDesc;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.RO;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.location;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                        worksheet.Cells[row, col].Value = order.recvDate;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.VIfailDescription;
        ////                        col++;

        ////                        worksheet.Cells[row, col].Value = order.Remarks1;
        ////                        col++;

        ////                        if (model.tblDoc.Count() > 0)
        ////                        {
        ////                            var v = model.tblDoc.Any(x => x.RepairOrdNbr == order.RO);
        ////                            if (v)
        ////                            {
        ////                                var fileName = model.tblDoc.SingleOrDefault(x => x.RepairOrdNbr == order.RO).FileName.Distinct().Take(1);

        ////                                foreach (var imgName in fileName)
        ////                                {

        ////                                    try
        ////                                    {
        ////                                        worksheet.Row(row).Height = 83.00d;
        ////                                        System.Drawing.Image image = System.Drawing.Image.FromStream(new MemoryStream(client.DownloadData(paths + imgName)));
        ////                                        var picture = worksheet.Drawings.AddPicture("" + imgName + "", image);
        ////                                        int c = col;
        ////                                        int r = row;
        ////                                        picture.From.Column = c - 1;
        ////                                        picture.From.Row = r - 1;
        ////                                        picture.SetSize(110, 110);
        ////                                        picture.From.ColumnOff = Pixel2MTU(2);
        ////                                        picture.From.RowOff = Pixel2MTU(2);
        ////                                    }
        ////                                    catch
        ////                                    {
        ////                                        worksheet.Cells[row, col].Value = "NA";
        ////                                    }
        ////                                }
        ////                            }
        ////                            else
        ////                            {
        ////                                worksheet.Cells[row, col].Value = "NA";
        ////                            }

        ////                            col++;
        ////                        }
        ////                        else
        ////                        {
        ////                            worksheet.Cells[row, col].Value = "NA";
        ////                            col++;
        ////                        }


        ////                        row++;
        ////                    }

        ////                    worksheet.View.FreezePanes(2, 1);

        ////                    worksheet.Cells[string.Format("A1:K{0}", row - 1)].AutoFitColumns();
        ////                    //worksheet.Cells[string.Format("A1:K{0}", row - 1)].Style.Border.Top.Style = ExcelBorderStyle.Thin;
        ////                    xlPackage.Workbook.Properties.Title = string.Format("{0} VI", "CTDI");
        ////                    xlPackage.Workbook.Properties.Author = _companyName;
        ////                    xlPackage.Workbook.Properties.Subject = string.Format("{0} VI", "CTDI");
        ////                    xlPackage.Workbook.Properties.Keywords = string.Format("{0} VI", "CTDI");
        ////                    xlPackage.Workbook.Properties.Category = "VI Report";
        ////                    xlPackage.Workbook.Properties.Comments = string.Format("{0} VI", "CTDI");
        ////                    xlPackage.Workbook.Properties.Company = "CTDI";
        ////                    //xlPackage.Save();
        ////                    if (File.Exists(p_strPath))
        ////                        File.Delete(p_strPath);

        ////                    using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                    {
        ////                        xlPackage.SaveAs(fs);
        ////                    }
        ////                }
        ////            }
        ////            catch (Exception ex)
        ////            {
        ////                throw ex;
        ////            }
        ////        }

        ////        public void ExportShippingToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.ShippingModel.ReceivingData> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("Shipping");

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {

        ////                       "Pack #","PACK RO #","Product Type","OEM","Product Family",
        ////                        "Category","Part #","Description",
        ////                        "Serial #","Stock Type","Unit Price","Carrier","Carrier Method","Tracking #","Ship to Name",
        ////                        "Ship to Address1","Ship to Address2","Ship to City","Ship to State","Ship to country","Ship to Zip","Contact #","STN DC Number",
        ////                         "STN DC Date","Time of Dispatch","Road Permit #","Transaction Type"
        ////                    };

        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = properties[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = order.packNumber;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.RO;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.productName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.oem;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_desc;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.stockType;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.unit_price;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.carrier;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.carrierMethod;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.tracking;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.shiptoName;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.ShiptoAddress1;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.ShiptoAddress2;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.shiptoCity;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.shiptoState;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.shiptoCountry;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.shiptoZip;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.ContactNumber;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.STN_DC_Number;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.STN_DC_Date;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.TimeofDispatch;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.RoadPermit;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.TransactionType;
        ////                    col++;

        ////                    row++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Shipping", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Shipping", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Shipping", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Shipping Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Shipping", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public void ExportRDEToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.RDEReportModel.ReceivingData> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("RDE Report");

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                         "Product Type",
        ////                                            "OEM",
        ////                                            "Product Family",
        ////                                            "Category",
        ////                                            "Part #",
        ////                                            "Description",
        ////                                            "Serial #",
        ////                                            "Repair Order #",
        ////                                            "Status",
        ////                                            "Part Code Description",
        ////                                            "Rework By",
        ////                                            "Test By",
        ////                                            "Challan Name",
        ////                                            "Challan Date",                                            
        ////                                            "Carrier Docket #",
        ////                                            "Shipment Receive Date",
        ////                                            "Unit Receive Date",
        ////                                            "CTDI RMA/Order #",
        ////                                            "Customer RMA #",
        ////                                            "Location", 
        ////                                            "Circle", 
        ////                                            "Firmware Version",
        ////                                            "Modem Card-1 Serial #",
        ////                                            "Modem Card-2 Serial #",
        ////                                            "Control Card Serial #",
        ////                                            "INTF/Framer Card",
        ////                                            "Power Card",
        ////                                            "Optical Card",
        ////                                            "Customer Reported Fault",                                          
        ////                                            "Corrective Action",
        ////                                            "Receiving inspection Status",
        ////                                            "Unit Status",
        ////                                            "RDE Close Date"
        ////                    };

        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = properties[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = order.productName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.oem;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.part_desc;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RO;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.status;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.partCodeDesc;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.reworkBy;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.testBy;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.challanNbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.challanDate;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.CarrierDocketNumber;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.materialReceivedate;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.UnitReceiveDate;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.ord_nbr;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.custRMA;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.location;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.state;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.firmwareVersion;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modemCard1;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.modemCard2;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.controlCard;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.interfaceFramerCard;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.powerCard;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Opticalcard;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.custReportedfault;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.correctiveAction;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.receiveInspectionStatus;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.unitStatus;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.rdeClosedate;
        ////                    col++;

        ////                    row++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} RDE", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} RDE", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} RDE", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "RDE Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} RDE", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public void ExportRANDRToXlsxForHuawei(ExcelPackage xlPackage, IList<CTDI.WEB.Models.Report.RANDRReportModel.ReceivingData> data, string sheetName = "HUAWEI")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            var headerList = CTDI.Shared.ReportsHeader.GetRANDR_Huawei();
        ////            //  "Total Repair Charges",  "STATUS(IQC)", 
        ////            worksheet1.Row(1).Height = 30.00d;
        ////            worksheet1.Cells["A1:AK1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            for (int i = 0; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[1, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 1, i + 1);
        ////                if (headerList[i] == "Reason for OOT" || headerList[i] == "REMARKS" || headerList[i] == "Labour Charges" || headerList[i] == "Material Charges" || headerList[i] == "Remarks")
        ////                {
        ////                    string HEXAHEADER = "#FFFF00";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else if (headerList[i] == "Labour Charges")
        ////                {
        ////                    string HEXAHEADER = "#DA9694";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else if (headerList[i] == "RMA Requested by")
        ////                {
        ////                    string HEXAHEADER = "#B1A0C7";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else if (headerList[i] == "Technology & BTS Model")
        ////                {
        ////                    string HEXAHEADER = "#c77a7a";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else
        ////                {
        ////                    string HEXAHEADER = "#8DB4E2";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 2;
        ////            int inc = 1;
        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.RO;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.unitDesc;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.modelName;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.location;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.ctdiRma;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Serial_Nbr;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.partNo;
        ////                col++;

        ////                worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet1.Cells[row, col].Value = order.UnitReceiveDate;
        ////                col++;

        ////                worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet1.Cells[row, col].Value = order.preAlertRaisedDate;
        ////                col++;

        ////                worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet1.Cells[row, col].Value = order.dispatchDate;
        ////                col++;

        ////                if (order.mnthYear.HasValue)
        ////                {
        ////                    worksheet1.Cells[row, col].Value = order.mnthYear.Value.ToString("MMM") + "'" + order.mnthYear.Value.ToString("yy");
        ////                }
        ////                else
        ////                {
        ////                    worksheet1.Cells[row, col].Value = "";
        ////                }
        ////                col++;


        ////                worksheet1.Cells[row, col].Value = order.status;
        ////                col++;

        ////                //worksheet1.Cells[row, col].Value = order.final_repair_status;
        ////                //col++;

        ////                worksheet1.Cells[row, col].Value = order.TAT;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TATSLA;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.viStatus;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.viInspComnt;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.softVers;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.ReasonForOOT;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.remarks;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.courierDtl;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.courierDocketNo;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.generalFaultDesc;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.correctiveAction;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.location;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WCCSignByTTSLAuthorityName;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.LabourCharges;
        ////                col++;


        ////                worksheet1.Cells[row, col].Value = order.MaterialCharges;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.LabourInvoice;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.MaterialInvoice;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.remarks;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TesterReadyDate;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.LearningPeriodClosedDate;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TechnologyAndBTSModel;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.rmaReqBy;
        ////                col++;


        ////                row++;
        ////                inc++;
        ////            }

        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////        }
        ////        public void ExportRANDRToXlsxForNEC(ExcelPackage xlPackage, IList<CTDI.WEB.Models.Report.RANDRReportModel.ReceivingData> data)
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet = xlPackage.Workbook.Worksheets.Add("NEC");

        ////            //Create Headers and format them
        ////            var properties = new string[]
        ////                    {
        ////                         "Sl. No.",
        ////                                            "RO NO.",
        ////                                            "Unit Description",
        ////                                            "Model",
        ////                                            "Circle",
        ////                                            "Serial Number",
        ////                                            "Control Card Serial Number",
        ////                                            "Modem Card 1 Serial Number",
        ////                                            "Modem Card 2 Serial Number",
        ////                                            "Interface Serial Number",
        ////                                            "RMA #",
        ////                                            "Date of Received",
        ////                                            "Date of Dispatch",
        ////                                            "Month-Year",                                            
        ////                                            "Status",
        ////                                            "TAT",
        ////                                            "TAT SLA defined",
        ////                                            "IN TAT/Out of TAT",
        ////                                            "Receiving Inspection Status",
        ////                                            "Pre-alert Raised date", 
        ////                                            "Reason for OOT", 
        ////                                            "Courier Details",
        ////                                            "Courier Docket no",
        ////                                            "General fault description reported ",
        ////                                            "Corrective Action",
        ////                                            "SAC Sign by TTSL authority Name",
        ////                                            "Labour Charges",
        ////                                            "Material Charges",
        ////                                            "Labour  TransactionId",
        ////                                            "Material TransactionId",
        ////                                            "Total TransactionId"
        ////                    };
        ////            //"STATUS(IQC)",  "Total Repair Charges",       
        ////            worksheet.Row(1).Height = 30.00d;
        ////            worksheet.Cells["A1:AF1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            for (int i = 0; i < properties.Length; i++)
        ////            {
        ////                worksheet.Cells[1, i + 1].Value = properties[i];
        ////                worksheet.Cells[1, i + 1].Style.Font.Bold = true;

        ////                ExcelBorderLine(worksheet, 1, i + 1);
        ////                if (properties[i] == "Reason for OOT" || properties[i] == "SAC Sign by TTSL authority Name" || properties[i] == "Labour Charges" || properties[i] == "Material Charges")
        ////                {
        ////                    string HEXAHEADER = "#FFFF00";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else
        ////                {
        ////                    string HEXAHEADER = "#8DB4E2";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 2;
        ////            int inc = 1;
        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet.Cells[row, col].Value = inc;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.RO;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.unitDesc;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.modelName;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.location;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.controlCard;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.modemCard1;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.modemCard2;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.interfaceFramerCard;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.ctdiRma;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.UnitReceiveDate;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.dispatchDate;
        ////                col++;

        ////                if (order.mnthYear.HasValue)
        ////                {
        ////                    worksheet.Cells[row, col].Value = order.mnthYear.Value.ToString("MMM") + "'" + order.mnthYear.Value.ToString("yy");
        ////                }
        ////                else
        ////                {
        ////                    worksheet.Cells[row, col].Value = "";
        ////                }
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.status;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TAT;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TATSLA;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.receiveInspectionStatus;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.preAlertRaisedDate;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.courierDtl;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.courierDocketNo;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.generalFaultDesc;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.correctiveAction;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.SACSignByTTSLAuthorityName;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.LabourCharges;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.MaterialCharges;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.LabourInvoice;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.MaterialInvoice;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TotalInvoice;
        ////                col++;

        ////                row++;
        ////                inc++;
        ////            }

        ////            worksheet.View.FreezePanes(2, 1);

        ////            worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////        }
        ////        public void ExportRANDRToXlsxForNSN(ExcelPackage xlPackage, IList<CTDI.WEB.Dto.ReportNSNDto> data)
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet = xlPackage.Workbook.Worksheets.Add("NSN");

        ////            //Create Headers and format them
        ////            var properties = new string[]
        ////                    {
        ////                         "Sl. No.",
        ////"RO NO.",
        ////"Category",
        ////"Model",
        ////"2G/3G",
        ////"OEM",
        ////"Circle",
        ////"Serial Number",
        ////"RMA",
        ////"Date of Received",
        ////"Date of Dispatch",
        ////"Customer Priority",
        ////"Repair date",
        ////"Repair TAT",
        ////"Avg TAT",
        ////"Status",
        ////"Receiving Inspection Status",
        ////"Courier Details",
        ////"Courier Docket no",
        ////"General fault description reported ",
        ////"Corrective Action",
        //// "SAC Sign by TTSL Authority Name", 
        //// "Labour Transaction Id.", 
        //// "Repaired Charges ",
        //// "Material Transaction Id.", 
        //// "Material Charges ",

        ////                    };
        ////            worksheet.Row(1).Height = 30.00d;
        ////            worksheet.Cells["A1:Z1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            for (int i = 0; i < properties.Length; i++)
        ////            {
        ////                worksheet.Cells[1, i + 1].Value = properties[i];
        ////                worksheet.Cells[1, i + 1].Style.Font.Bold = true;

        ////                ExcelBorderLine(worksheet, 1, i + 1);
        ////                string HexaHeader = "#8DB4E2";

        ////                if (properties[i] == "customer priority" || properties[i] == "Repair date" || properties[i] == "Repair TAT" || properties[i] == "Avg TAT")
        ////                {
        ////                    HexaHeader = "#FFFF00";
        ////                    //Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    //var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                    //fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    //fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                //else
        ////                //{
        ////                //    string HEXAHEADER = "#8DB4E2";
        ////                //    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                //    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                //    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                //}
        ////                Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HexaHeader);
        ////                var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 2;
        ////            int inc = 1;
        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet.Cells[row, col].Value = inc;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.RONo;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Category;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Model;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order._2G_3G;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.OEM;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Circle;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Serial_Number;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.RMA;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.DateOfReceived;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.DateOfDispatch;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.CustomerPriority;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.RepairDate;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.RepairTAT;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.AvgTAT;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Status;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.ReceivingInspectionStatus;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.CourierDetails;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.CourierDocketNo;
        ////                col++;


        ////                worksheet.Cells[row, col].Value = order.GeneralFaultDescriptionReported;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.SACSignByTTSLAuthorityName;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.LabourInvoiceNo;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.RepairedCharges;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.MaterialInvoiceNo;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.MaterialCharges;
        ////                col++;

        ////                row++;
        ////                inc++;
        ////            }

        ////            worksheet.View.FreezePanes(2, 1);

        ////            worksheet.Cells[string.Format("A1:Z{0}", row - 1)].AutoFitColumns();

        ////        }
        ////        public void ExportRANDRToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.RANDRReportModel.ReceivingData> data, string p_strPath, string OEM)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                if (OEM == "NEC")
        ////                {
        ////                    ExportRANDRToXlsxForNEC(xlPackage, data);
        ////                }
        ////                else if (OEM == "HUAWEI")
        ////                {
        ////                    ExportRANDRToXlsxForHuawei(xlPackage, data);
        ////                }

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "R&R Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        public void ExportRANDRToXlsx(Stream stream, CTDI.WEB.Models.Report.RANDRReportModel reportData, string p_strPath, string OEM)
        ////        {

        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                if (OEM == "NEC")
        ////                {
        ////                    ExportRANDRToXlsxForNEC(xlPackage, reportData.Result);
        ////                }
        ////                else if (OEM == "HUAWEI")
        ////                {
        ////                    ExportRANDRToXlsxForHuawei(xlPackage, reportData.Result1);
        ////                }
        ////                else if (OEM == "NSN")
        ////                {
        ////                    ExportRANDRToXlsxForNSN(xlPackage, reportData.ResultNSN);
        ////                }

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "R&R Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public void RandR_ForAllOEM(Stream stream, IList<CTDI.WEB.Models.Report.RANDRReportModel.ReceivingData> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {

        ////                List<string> oemsLst = data.Select(q => q.productName).Distinct().ToList();
        ////                if (oemsLst.Count() > 0)
        ////                {
        ////                    foreach (string item in oemsLst)
        ////                    {
        ////                        ExportRANDRToXlsxForHuawei(xlPackage, data.Where(q => q.productName == item).ToList(), item + "_HUAWEI");

        ////                    }

        ////                }

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "R&R Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }


        ////        //For DailyRepairR&R Report

        ////        public void DailyRepairExportRANDRToXlsxForHuawei(ExcelPackage xlPackage, IList<CTDI.WEB.Models.Report.DailyRepairRANDRReportModel.ReceivingData> data)
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add("HUAWEI");

        ////            //Create Headers and format them
        ////            var properties1 = new string[]
        ////                    {
        ////                                            "Sl. No.",
        ////                                            "RO NO.",
        ////                                            "Unit Description",
        ////                                            "Family",
        ////                                            "Source Circle",
        ////                                            "RMA #",
        ////                                            "Serial Number",
        ////                                            "Part Code",                                            
        ////                                            "Date of Received",                                            
        ////                                            "Pre-alert Raised date", 
        ////                                            "Dispatch Date",
        ////                                            "Month-Year",
        ////                                            "STATUS",
        ////                                            "STATUS(IQC)",
        ////                                            "TAT",
        ////                                            "TAT SLA defined",
        ////                                            "IN TAT/Out of TAT",
        ////                                            "VI STATUS",
        ////                                            "Visual Inspection Comments",
        ////                                            "Softwer Version",
        ////                                            "Reason for OOT", 
        ////                                            "REMARKS",
        ////                                            "Courier Details",
        ////                                            "Courier Docket no",
        ////                                            "General fault description reported",
        ////                                            //"General fault description reported ",
        ////                                            "CORRECTIVE ACTION",
        ////                                            "Dispatch Circle",
        ////                                            "WCC Sign by TTSL authority Name",
        ////                                            "Labour Charges",
        ////                                            "Material Charges",
        ////                                            "Total Repair Charges",                                          
        ////                                            "Labour  TransactionId",
        ////                                            "Material TransactionId",
        ////                                            "Remarks",
        ////                                            "Tester Ready Date",
        ////                                            "Learning Period Closed Date",
        ////                                            "Technology & BTS Model",
        ////                                            "RMA Requested by"
        ////                    };
        ////            worksheet1.Row(1).Height = 30.00d;
        ////            worksheet1.Cells["A1:AK1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            for (int i = 0; i < properties1.Length; i++)
        ////            {
        ////                worksheet1.Cells[1, i + 1].Value = properties1[i];
        ////                worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 1, i + 1);
        ////                if (properties1[i] == "Visual Inspection Comments"
        ////                    || properties1[i] == "Reason for OOT" || properties1[i] == "REMARKS" || properties1[i] == "WCC Sign by TTSL authority Name"
        ////                    || properties1[i] == "Labour Charges" || properties1[i] == "Material Charges" || properties1[i] == "Remarks")
        ////                {
        ////                    string HEXAHEADER = "#FFFF00";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else if (properties1[i] == "Labour Charges")
        ////                {
        ////                    string HEXAHEADER = "#DA9694";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else if (properties1[i] == "RMA Requested by")
        ////                {
        ////                    string HEXAHEADER = "#B1A0C7";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else
        ////                {
        ////                    string HEXAHEADER = "#8DB4E2";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 2;
        ////            int inc = 1;
        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.RO;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.unitDesc;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.modelName;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.location;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.ctdiRma;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Serial_Nbr;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.partNo;
        ////                col++;

        ////                worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet1.Cells[row, col].Value = order.UnitReceiveDate;
        ////                col++;

        ////                worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet1.Cells[row, col].Value = order.preAlertRaisedDate;
        ////                col++;

        ////                worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet1.Cells[row, col].Value = order.dispatchDate;
        ////                col++;

        ////                if (order.mnthYear.HasValue)
        ////                {
        ////                    worksheet1.Cells[row, col].Value = order.mnthYear.Value.ToString("MMM") + "'" + order.mnthYear.Value.ToString("yy");
        ////                }
        ////                else
        ////                {
        ////                    worksheet1.Cells[row, col].Value = "";
        ////                }
        ////                col++;


        ////                worksheet1.Cells[row, col].Value = order.status;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.final_repair_status;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TAT;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TATSLA;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.viStatus;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.viInspComnt;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.courierDtl;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.courierDocketNo;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.failureCode;
        ////                col++;

        ////                //worksheet1.Cells[row, col].Value = order.generalFaultDesc;
        ////                //col++;

        ////                worksheet1.Cells[row, col].Value = order.correctiveAction;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.location;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.rmaReqBy;
        ////                col++;


        ////                row++;
        ////                inc++;
        ////            }

        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        ////        }
        ////        public void DailyRepairExportRANDRToXlsxForNEC(ExcelPackage xlPackage, IList<CTDI.WEB.Models.Report.DailyRepairRANDRReportModel.ReceivingData> data)
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet = xlPackage.Workbook.Worksheets.Add("NEC");

        ////            //Create Headers and format them
        ////            var properties = new string[]
        ////                    {
        ////                         "Sl. No.",
        ////                                            "RO NO.",
        ////                                            "Unit Description",
        ////                                            "Model",
        ////                                            "Circle",
        ////                                            "Serial Number",
        ////                                            "Control Card Serial Number",
        ////                                            "Modem Card 1 Serial Number",
        ////                                            "Modem Card 2 Serial Number",
        ////                                            "Interface Serial Number",
        ////                                            "RMA #",
        ////                                            "Date of Received",
        ////                                            "Date of Dispatch",
        ////                                            "Month-Year",                                            
        ////                                            "STATUS",
        ////                                            "STATUS(IQC)",
        ////                                            "TAT",
        ////                                            "TAT SLA defined",
        ////                                            "IN TAT/Out of TAT",
        ////                                            "Receiving Inspection Status",
        ////                                            "Pre-alert Raised date", 
        ////                                            "Reason for OOT", 
        ////                                            "Courier Details",
        ////                                            "Courier Docket no",
        ////                                            "General fault description reported",
        ////                                            //"General fault description reported ",
        ////                                            "CORRECTIVE ACTION",
        ////                                            "SAC Sign by TTSL authority Name",
        ////                                            "Labour Charges",
        ////                                            "Material Charges",
        ////                                            "Total Repair Charges",                                          
        ////                                            "Labour  TransactionId",
        ////                                            "Material TransactionId",
        ////                                            "Total TransactionId"
        ////                    };
        ////            worksheet.Row(1).Height = 30.00d;
        ////            worksheet.Cells["A1:AF1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            for (int i = 0; i < properties.Length; i++)
        ////            {
        ////                worksheet.Cells[1, i + 1].Value = properties[i];
        ////                worksheet.Cells[1, i + 1].Style.Font.Bold = true;

        ////                ExcelBorderLine(worksheet, 1, i + 1);
        ////                if (properties[i] == "Date of Dispatch" || properties[i] == "Month-Year" || properties[i] == "Receiving Inspection Status" || properties[i] == "Pre-alert Raised date" || properties[i] == "Reason for OOT" || properties[i] == "SAC Sign by TTSL authority Name" || properties[i] == "Labour Charges" || properties[i] == "Material Charges")
        ////                {
        ////                    string HEXAHEADER = "#FFFF00";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////                else
        ////                {
        ////                    string HEXAHEADER = "#8DB4E2";
        ////                    Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 2;
        ////            int inc = 1;
        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet.Cells[row, col].Value = inc;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.RO;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.unitDesc;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.modelName;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.location;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.Serial_Nbr;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.controlCard;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.ctdiRma;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.UnitReceiveDate;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.dispatchDate;
        ////                col++;

        ////                if (order.mnthYear.HasValue)
        ////                {
        ////                    worksheet.Cells[row, col].Value = order.mnthYear.Value.ToString("MMM") + "'" + order.mnthYear.Value.ToString("yy");
        ////                }
        ////                else
        ////                {
        ////                    worksheet.Cells[row, col].Value = "";
        ////                }
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.status;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.final_repair_status;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TAT;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TATSLA;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.TAT > order.TATSLA ? "Out Of TAT" : "In TAT";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.receiveInspectionStatus;
        ////                col++;

        ////                worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                worksheet.Cells[row, col].Value = order.preAlertRaisedDate;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.courierDtl;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.courierDocketNo;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = order.failureCode;
        ////                col++;

        ////                //worksheet.Cells[row, col].Value = order.generalFaultDesc;
        ////                //col++;

        ////                worksheet.Cells[row, col].Value = order.correctiveAction;
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;

        ////                worksheet.Cells[row, col].Value = "";
        ////                col++;


        ////                row++;
        ////                inc++;
        ////            }

        ////            worksheet.View.FreezePanes(2, 1);

        ////            worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();


        ////        }

        ////        public void DailyRepairExportRANDRToXlsx(Stream stream, IList<CTDI.WEB.Models.Report.DailyRepairRANDRReportModel.ReceivingData> data, string p_strPath, IList<CTDI.WEB.Models.Report.DailyRepairRANDRReportModel.ReceivingData> data1)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                DailyRepairExportRANDRToXlsxForNEC(xlPackage, data);
        ////                DailyRepairExportRANDRToXlsxForHuawei(xlPackage, data1);

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Daily Repair R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Daily Repair R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Daily Repair R&R Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Daily Repair R&R", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        ////                //xlPackage.Save();
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }


        ////        public void CosmeticDoneToXlsx(Stream stream, List<CTDI.Shared.Dto.CosmeticDto> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            // string path = Path.Combine(HttpContext.Current.Server.MapPath("~//images/"), "ctdi-logo2.png");
        ////            //Image logo = Image.FromFile(path);
        ////            //logo.Size(
        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("CosmeticDone");

        ////                worksheet.Cells["A1:H1"].Merge = true;
        ////                worksheet.Cells["A1:H1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////                worksheet.Cells["A1:H1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////                worksheet.Cells["A1"].Value = "Cosmetic Done Report";
        ////                worksheet.Cells["A1"].Style.Font.Bold = true;
        ////                worksheet.Cells["A1"].Style.Font.Size = 20;

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                         "Sr.No.",
        ////                        "Unit Serial No",
        ////                        "Part No",
        ////                        "R.O. #",
        ////                        "Model",
        ////                        "Description",
        ////                        "Location",
        ////                        "Status"                
        ////                    };


        ////                worksheet.Row(2).Height = 30.00d;

        ////                string HEXAHEADER = "#8DB4E2";
        ////                Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[2, i + 1].Value = properties[i];
        ////                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;
        ////                    ExcelBorderLine(worksheet, 2, i + 1);

        ////                    var fillHEADER = worksheet.Cells[2, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 3;
        ////                int inc = 1;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = inc;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.UnitSerialNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.PartNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RepairOrderNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.ModelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Description;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Location;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Status;
        ////                    col++;


        ////                    row++;
        ////                    inc++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:G{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0}  Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0}  Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = " Cosmetic Done Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0}  Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }

        ////        public void PreAlertToXlsx(Stream stream, List<CTDI.Shared.Dto.PreAlertDto> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");
        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("Internal_Pre_Alert");

        ////                worksheet.Cells["A1:N1"].Merge = true;
        ////                worksheet.Cells["A1:N1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////                worksheet.Cells["A1:N1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////                worksheet.Cells["A1"].Value = "Internal Pre-Alert";
        ////                worksheet.Cells["A1"].Style.Font.Bold = true;
        ////                worksheet.Cells["A1"].Style.Font.Size = 20;

        ////                //Create Headers and format them
        ////                var properties = new string[]
        ////                    {
        ////                         "Sl.No.",
        ////                          "R.O. #",
        ////                           "Serial No",
        ////                         "RMA No",
        ////                           "Part No",
        ////                            "Model",
        ////                              "Description",
        ////                              "OEM",
        ////                              "Unit Rec. Date",
        ////                              "Warranty",
        ////                              "Status",
        ////                        "Location",
        ////                        "Value",
        ////                        "Pre-Alert Date"
        ////                    };


        ////                worksheet.Row(2).Height = 30.00d;

        ////                string HEXAHEADER = "#8DB4E2";
        ////                Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        ////                for (int i = 0; i < properties.Length; i++)
        ////                {
        ////                    worksheet.Cells[2, i + 1].Value = properties[i];
        ////                    worksheet.Cells[2, i + 1].Style.Font.Bold = true;
        ////                    ExcelBorderLine(worksheet, 2, i + 1);


        ////                    var fillHEADER = worksheet.Cells[2, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 3;
        ////                int inc = 1;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = inc;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.RepairOrderNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.UnitSerialNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RMANo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.PartNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.ModelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Description;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.OEM;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.UnitRecDate;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.Warranty;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.Status;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.Location;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.Value;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.PreAlertDate;
        ////                    col++;

        ////                    row++;
        ////                    inc++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:N{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0}  Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0}  Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = " Cosmetic Done Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0}  Cosmetic Done ", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }


        //public void MasterReport_ForAllOEM(Stream stream, IList<CTDI.Shared.Dto.MasterDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {

        //        List<string> oemsLst = data.Select(q => q.OEM).Distinct().ToList();
        //        if (oemsLst.Count() > 0)
        //        {
        //            foreach (string item in oemsLst)
        //            {
        //                //if (item.ToUpper() == ReportOEMType.HUAWEI.ToString())
        //                //{
        //                if (item != null)
        //                {
        //                    ExportMasterToXlsx(xlPackage, data.Where(q => q.OEM == item).ToList(), "Master Report : " + item);
        //                }
        //                //}
        //                //else if (item.ToUpper() == ReportOEMType.NEC.ToString() || item.ToUpper() == ReportOEMType.NSN.ToString())
        //                //{
        //                //    ExportMasterToXlsx(xlPackage, data.Where(q => q.OEM == item).ToList(), ReportOEMType.NEC, "Master Report : " + item);
        //                //}
        //            }

        //        }

        //        xlPackage.Workbook.Properties.Title = string.Format("{0} Master", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} Master", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} Master", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "Master Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} Master", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
        //        //xlPackage.Save();
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}
        //public void ExportMasterToXlsx(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.MasterDto> data, string sheetName = "Master Report")
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    string[] headerList = null;// CTDI.Shared.ReportsHeader.GetMaster_NSN();
        //    //if (reportOEMType == ReportOEMType.NSN || reportOEMType == ReportOEMType.NEC)
        //    //{
        //        headerList = CTDI.Shared.ReportsHeader.GetMasterNSN();
        //    //}
        //    //else if (reportOEMType == ReportOEMType.HUAWEI)
        //    //{
        //    //    headerList = CTDI.Shared.ReportsHeader.GetMasterHuawei();
        //    //}
        //    //if (headerList.Count() <= 0)
        //    //{
        //    //    return;
        //    //}
        //    worksheet1.Row(1).Height = 30.00d;
        //    worksheet1.Cells["A1:AL1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    Color _colorHEADER = AppUtility.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(AppUtility.HeaderBackColor);
        //    for (int i = 0; i < headerList.Length; i++)
        //    {
        //        worksheet1.Cells[1, i + 1].Value = headerList[i];
        //        worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 1, i + 1);

        //        var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;

        //    //if (reportOEMType == ReportOEMType.NSN || reportOEMType == ReportOEMType.NEC)
        //    //{
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet1.Cells[row, col].Value = inc;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RepairOrderNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RMANo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Location;
        //            col++;

        //            //worksheet1.Cells[row, col].Value = order.Warehouse;
        //            //col++;

        //            worksheet1.Cells[row, col].Value = order.ReceivingCourier;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReceiveDocket;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RecDC_InvoiceNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitSerial;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductType;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.OEM;
        //            col++;



        //            worksheet1.Cells[row, col].Value = order.ProductFamily;
        //            col++;

        //            //worksheet1.Cells[row, col].Value = order.ModemCard1SerialNumber;
        //            //col++;
        //            //worksheet1.Cells[row, col].Value = order.ModemCard2SerialNumber;
        //            //col++;

        //            //worksheet1.Cells[row, col].Value = order.ControlCardSerialNumber;
        //            //col++;

        //            //worksheet1.Cells[row, col].Value = order.InterfaceSerialNumber;
        //            //col++;

        //            worksheet1.Cells[row, col].Value = order.Category;
        //            col++;


        //            worksheet1.Cells[row, col].Value = order.UnitDescription;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.PartNo;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.ShipmentRecDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Status;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Warranty;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.VIDetails;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.FaultDetails;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SpareDetails;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.BurnInTest;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitStatus;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.PreAlertDate;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.ShipDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SendToLocation;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TATDays;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.InvoiceValue;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.DispatchChallan;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingPackNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingCourier;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingDocket;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReevingRemarks;
        //            col++;

        //            row++;
        //            inc++;
        //        }
        //    //}
        //    //else if (reportOEMType == ReportOEMType.HUAWEI)
        //    //{
        //    //    foreach (var order in data)
        //    //    {
        //    //        int col = 1;

        //    //        worksheet1.Cells[row, col].Value = inc;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.RepairOrderNo;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.RMANo;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.Location;
        //    //        col++;

        //    //        //worksheet1.Cells[row, col].Value = order.Warehouse;
        //    //        //col++;

        //    //        worksheet1.Cells[row, col].Value = order.ReceivingCourier;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ReceiveDocket;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.RecDC_InvoiceNo;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.UnitSerial;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.RMARequestedBy;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.OEM;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ProductFamily;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.Category;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.UnitDescription;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ModelName;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.PartNo;
        //    //        col++;
        //    //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //    //        worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //    //        col++;
        //    //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //    //        worksheet1.Cells[row, col].Value = order.ShipmentRecDate;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.Status;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.Warranty;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.UnitStatus;
        //    //        col++;
        //    //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //    //        worksheet1.Cells[row, col].Value = order.PreAlertDate;
        //    //        col++;
        //    //        worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //    //        worksheet1.Cells[row, col].Value = order.ShipDate;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.SendToLocation;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.TATDays;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.InvoiceValue;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.DispatchChallan;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ShipingPackNo;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ShipingCourier;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ShipingDocket;
        //    //        col++;

        //    //        worksheet1.Cells[row, col].Value = order.ReevingRemarks;
        //    //        col++;

        //    //        row++;
        //    //        inc++;
        //    //    }
        //    //}
        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:AL{0}", row - 1)].AutoFitColumns();

        //}

        //public void ExportMasterToXlsx(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.MasterDto> data, ReportOEMType reportOEMType, string sheetName = "Master Report")
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    string[] headerList = null;// CTDI.Shared.ReportsHeader.GetMaster_NSN();
        //    if (reportOEMType == ReportOEMType.NSN || reportOEMType == ReportOEMType.NEC)
        //    {
        //        headerList = CTDI.Shared.ReportsHeader.GetMasterNSN();
        //    }
        //    else if (reportOEMType == ReportOEMType.HUAWEI)
        //    {
        //        headerList = CTDI.Shared.ReportsHeader.GetMasterHuawei();
        //    }
        //    if (headerList.Count() <= 0)
        //    {
        //        return;
        //    }
        //    worksheet1.Row(1).Height = 30.00d;
        //    worksheet1.Cells["A1:AL1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    Color _colorHEADER = AppUtility.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(AppUtility.HeaderBackColor);
        //    for (int i = 0; i < headerList.Length; i++)
        //    {
        //        worksheet1.Cells[1, i + 1].Value = headerList[i];
        //        worksheet1.Cells[1, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 1, i + 1);

        //        var fillHEADER = worksheet1.Cells[1, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 2;
        //    int inc = 1;

        //    if (reportOEMType == ReportOEMType.NSN || reportOEMType == ReportOEMType.NEC)
        //    {
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet1.Cells[row, col].Value = inc;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RepairOrderNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RMANo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Location;
        //            col++;

        //            //worksheet1.Cells[row, col].Value = order.Warehouse;
        //            //col++;

        //            worksheet1.Cells[row, col].Value = order.ReceivingCourier;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReceiveDocket;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RecDC_InvoiceNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitSerial;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductType;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.OEM;
        //            col++;



        //            worksheet1.Cells[row, col].Value = order.ProductFamily;
        //            col++;

        //            //worksheet1.Cells[row, col].Value = order.ModemCard1SerialNumber;
        //            //col++;
        //            //worksheet1.Cells[row, col].Value = order.ModemCard2SerialNumber;
        //            //col++;

        //            //worksheet1.Cells[row, col].Value = order.ControlCardSerialNumber;
        //            //col++;

        //            //worksheet1.Cells[row, col].Value = order.InterfaceSerialNumber;
        //            //col++;

        //            worksheet1.Cells[row, col].Value = order.Category;
        //            col++;


        //            worksheet1.Cells[row, col].Value = order.UnitDescription;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.PartNo;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.ShipmentRecDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Status;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Warranty;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.VIDetails;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.FaultDetails;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SpareDetails;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.BurnInTest;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitStatus;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.PreAlertDate;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.ShipDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SendToLocation;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TATDays;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.InvoiceValue;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.DispatchChallan;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingPackNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingCourier;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingDocket;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReevingRemarks;
        //            col++;

        //            row++;
        //            inc++;
        //        }
        //    }
        //    else if (reportOEMType == ReportOEMType.HUAWEI)
        //    {
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet1.Cells[row, col].Value = inc;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RepairOrderNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RMANo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Location;
        //            col++;

        //            //worksheet1.Cells[row, col].Value = order.Warehouse;
        //            //col++;

        //            worksheet1.Cells[row, col].Value = order.ReceivingCourier;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReceiveDocket;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RecDC_InvoiceNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitSerial;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.RMARequestedBy;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.OEM;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ProductFamily;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Category;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitDescription;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.PartNo;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.UnitRecDate;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.ShipmentRecDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Status;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.Warranty;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.UnitStatus;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.PreAlertDate;
        //            col++;
        //            worksheet1.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        //            worksheet1.Cells[row, col].Value = order.ShipDate;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.SendToLocation;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.TATDays;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.InvoiceValue;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.DispatchChallan;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingPackNo;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingCourier;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ShipingDocket;
        //            col++;

        //            worksheet1.Cells[row, col].Value = order.ReevingRemarks;
        //            col++;

        //            row++;
        //            inc++;
        //        }
        //    }
        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:AL{0}", row - 1)].AutoFitColumns();

        //}

        //public void CosmeticDone(Stream stream, List<CosmeticItemDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");


        //    using (var xlPackage = new ExcelPackage(stream))
        //    {
        //        // get handle to the existing worksheet
        //        var worksheet = xlPackage.Workbook.Worksheets.Add("CosmeticDone");

        //        worksheet.Cells["A1:H1"].Merge = true;
        //        worksheet.Cells["A1:H1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //        worksheet.Cells["A1:H1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //        worksheet.Cells["A1"].Value = "Cosmetic Done Report";
        //        worksheet.Cells["A1"].Style.Font.Bold = true;
        //        worksheet.Cells["A1"].Style.Font.Size = 20;

        //        //Create Headers and format them
        //        var properties = CTDI.Shared.ReportsHeader.GetCosmeticDone();


        //        worksheet.Row(2).Height = 30.00d;

        //        string HEXAHEADER = "#8DB4E2";
        //        Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(HEXAHEADER);
        //        for (int i = 0; i < properties.Length; i++)
        //        {
        //            worksheet.Cells[2, i + 1].Value = properties[i];
        //            worksheet.Cells[2, i + 1].Style.Font.Bold = true;
        //            ExcelBorderLine(worksheet, 2, i + 1);

        //            var fillHEADER = worksheet.Cells[2, i + 1].Style.Fill;
        //            fillHEADER.PatternType = ExcelFillStyle.Solid;
        //            fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //        }

        //        string ordernumber = string.Empty;

        //        int row = 3;
        //        int inc = 1;
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet.Cells[row, col].Value = inc;
        //            col++;
        //            worksheet.Cells[row, col].Value = order.UnitSerialNo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ProductNo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.CTDI_RONo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ProductDesc;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.Location;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.RepairStatus;
        //            col++;


        //            row++;
        //            inc++;
        //        }

        //        worksheet.View.FreezePanes(2, 1);

        //        worksheet.Cells[string.Format("A1:G{0}", row - 1)].AutoFitColumns();

        //        xlPackage.Workbook.Properties.Title = string.Format("{0} Cosmetic Done ", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0}  Cosmetic Done ", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0}  Cosmetic Done ", "CTDI");
        //        xlPackage.Workbook.Properties.Category = " Cosmetic Done Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0}  Cosmetic Done ", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}

        //public void Summary(Stream stream, IList<SummaryCardWiseDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {

        //        SummaryCard(xlPackage, data, "Card Summary");



        //        xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "Summary Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}

        //public void Summary(Stream stream, IList<SummaryCardWiseDto> data, string p_strPath, List<string> locationNames)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {

        //        SummaryCard(xlPackage, data, locationNames, "Card Summary");



        //        xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "Summary Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}
        //private void SummaryCard(ExcelPackage xlPackage, IList<SummaryCardWiseDto> data, string sheetName = "Summary Huawei")
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    string[] headerList = null;

        //    headerList = CTDI.Shared.ReportsHeader.GetSummaryCard();

        //    if (headerList.Count() <= 0)
        //    {
        //        return;
        //    }

        //    worksheet1.Cells["A1:I1"].Merge = true;
        //    worksheet1.Cells["A1:I1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //    worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //    worksheet1.Cells["A1"].Value = "Product Type wise Reliance Summary";
        //    worksheet1.Cells["A1"].Style.Font.Bold = true;
        //    worksheet1.Cells["A1"].Style.Font.Size = 20;

        //    var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        //    fillColor2.PatternType = ExcelFillStyle.Solid;
        //    fillColor2.BackgroundColor.SetColor(AppUtility.HeadBackColor);

        //    int toLocation = 0 + 9;
        //    string lastColumunName = toLocation.ExcelColumnFromNumber();
        //    //worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Merge = true;
        //    //worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //    //worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //    //worksheet1.Cells["J1"].Value = "Cards Dispatched to Circle";
        //    //worksheet1.Cells["J1"].Style.Font.Bold = true;
        //    //worksheet1.Cells["J1"].Style.Font.Size = 20;


        //    var fillColor3 = worksheet1.Cells["J1"].Style.Fill;
        //    fillColor3.PatternType = ExcelFillStyle.Solid;
        //    fillColor3.BackgroundColor.SetColor(AppUtility.Head2BackColor);




        //    worksheet1.Row(2).Height = 30.00d;
        //    worksheet1.Cells[string.Format("A2:{0}2", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    Color _colorHEADER = AppUtility.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        //    int colHeaderCountr = 0;
        //    for (int i = colHeaderCountr; i < headerList.Length; i++)
        //    {
        //        worksheet1.Cells[2, i + 1].Value = headerList[i];
        //        worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 2, i + 1);

        //        var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //if (headerList[i].ToString() == "WIP ( Hold)")
        //        //{
        //        //    fillHEADER.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        //        //}
        //        //else
        //        //{
        //        fillHEADER.BackgroundColor.SetColor(AppUtility.HeaderBackColor);
        //        //}
        //        colHeaderCountr = i;
        //    }

        //    //foreach (var item in locations)
        //    //{
        //    //    worksheet1.Cells[2, colHeaderCountr + 1].Value = item;
        //    //    worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        //    //    ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        //    //    var fillHEADER = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        //    //    fillHEADER.PatternType = ExcelFillStyle.Solid;
        //    //    fillHEADER.BackgroundColor.SetColor(AppUtility.HeaderBackColor);

        //    //    colHeaderCountr++;
        //    //}

        //    worksheet1.Cells[2, colHeaderCountr + 1].Value = "Grand Total";
        //    worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        //    ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        //    var fillHEADERG = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        //    fillHEADERG.PatternType = ExcelFillStyle.Solid;
        //    fillHEADERG.BackgroundColor.SetColor(AppUtility.HeaderBackColor);


        //    string ordernumber = string.Empty;

        //    int row = 3;
        //    int inc = 1;

        //    int col = 1;
        //    foreach (var order in data)
        //    {
        //        col = 1;

        //        worksheet1.Cells[row, col].Value = inc;
        //        var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        //        fillSrNo.PatternType = ExcelFillStyle.Solid;
        //        fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SourceName;
        //        col++;
        //        //worksheet1.Cells[row, col].Value = order.POCounter;
        //        //col++;
        //        worksheet1.Cells[row, col].Value = order.INVCounter;
        //        col++;
        //        worksheet1.Cells[row, col].Value = order.MRCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.PKDCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.RDECounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.COSCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.OBACounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SHIPCounter;
        //        col++;


        //        foreach (var item in order.locatonCounter)
        //        {
        //            worksheet1.Cells[row, col].Value = Convert.ToInt32(item.Value);
        //            col++;
        //        }
        //        row++;
        //        inc++;

        //    }


        //    worksheet1.Cells[row, 1].Value = "";
        //    worksheet1.Cells[row, 2].Value = "Grand Total";
        //    worksheet1.Cells[row, 3].Formula = "=Sum(C3:C" + (row - 1) + ")";// "=Sum(" + worksheet1.Cells[3, 3].Address + ":" + worksheet1.Cells[59, 3].Address + ")";
        //    worksheet1.Cells[row, 4].Formula = "=Sum(D3:D" + (row - 1) + ")";
        //    worksheet1.Cells[row, 5].Formula = "=Sum(E3:E" + (row - 1) + ")";
        //    worksheet1.Cells[row, 6].Formula = "=Sum(F3:F" + (row - 1) + ")";
        //    worksheet1.Cells[row, 7].Formula = "=Sum(G3:G" + (row - 1) + ")";
        //    worksheet1.Cells[row, 8].Formula = "=Sum(H3:H" + (row - 1) + ")";
        //    worksheet1.Cells[row, 9].Formula = "=Sum(I3:I" + (row - 1) + ")";
        //    worksheet1.Cells[row, 10].Formula = "=Sum(K3:K" + (row - 1) + ")";

        //    int totalDataRows = data.Count();
        //    for (int ita = 10; ita <= col; ita++)
        //    {
        //        string colNam = ita.ExcelColumnFromNumber();
        //        worksheet1.Cells[row, ita].Formula = "=Sum(" + colNam + "3:" + colNam + (row - 1) + ")";
        //    }

        //    for (int ita = 3; ita < row; ita++)
        //    {
        //        string colNam = (col - 1).ExcelColumnFromNumber();
        //        worksheet1.Cells[ita, col].Formula = "=Sum(J" + ita + ":" + colNam + ita + ")";
        //    }

        //    var fillTotal = worksheet1.Cells[row, 1, row, col].Style.Fill;
        //    fillTotal.PatternType = ExcelFillStyle.Solid;
        //    fillTotal.BackgroundColor.SetColor(_colorHEADER);

        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:{0}{1}", lastColumunName, row - 1)].AutoFitColumns();

        //}
        //private void SummaryCard(ExcelPackage xlPackage, IList<SummaryCardWiseDto> data, List<string> locations, string sheetName = "Summary Huawei")
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    string[] headerList = null;

        //    headerList = CTDI.Shared.ReportsHeader.GetSummaryCard();

        //    if (headerList.Count() <= 0)
        //    {
        //        return;
        //    }

        //    worksheet1.Cells["A1:I1"].Merge = true;
        //    worksheet1.Cells["A1:I1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //    worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //    worksheet1.Cells["A1"].Value = "Product Type wise Reliance Summary";
        //    worksheet1.Cells["A1"].Style.Font.Bold = true;
        //    worksheet1.Cells["A1"].Style.Font.Size = 20;

        //    var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        //    fillColor2.PatternType = ExcelFillStyle.Solid;
        //    fillColor2.BackgroundColor.SetColor(AppUtility.HeadBackColor);

        //    int toLocation = locations.Count() + 9;
        //    string lastColumunName = toLocation.ExcelColumnFromNumber();
        //    worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Merge = true;
        //    worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //    worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //    worksheet1.Cells["J1"].Value = "Cards Dispatched to Circle";
        //    worksheet1.Cells["J1"].Style.Font.Bold = true;
        //    worksheet1.Cells["J1"].Style.Font.Size = 20;


        //    var fillColor3 = worksheet1.Cells["J1"].Style.Fill;
        //    fillColor3.PatternType = ExcelFillStyle.Solid;
        //    fillColor3.BackgroundColor.SetColor(AppUtility.Head2BackColor);




        //    worksheet1.Row(2).Height = 30.00d;
        //    worksheet1.Cells[string.Format("A2:{0}2", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    Color _colorHEADER = AppUtility.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        //    int colHeaderCountr = 0;
        //    for (int i = colHeaderCountr; i < headerList.Length; i++)
        //    {
        //        worksheet1.Cells[2, i + 1].Value = headerList[i];
        //        worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 2, i + 1);

        //        var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        //if (headerList[i].ToString() == "WIP ( Hold)")
        //        //{
        //        //    fillHEADER.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        //        //}
        //        //else
        //        //{
        //        fillHEADER.BackgroundColor.SetColor(AppUtility.HeaderBackColor);
        //        //}
        //        colHeaderCountr = i;
        //    }

        //    foreach (var item in locations)
        //    {
        //        worksheet1.Cells[2, colHeaderCountr + 1].Value = item;
        //        worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        //        var fillHEADER = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(AppUtility.HeaderBackColor);

        //        colHeaderCountr++;
        //    }

        //    worksheet1.Cells[2, colHeaderCountr + 1].Value = "Grand Total";
        //    worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        //    ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        //    var fillHEADERG = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        //    fillHEADERG.PatternType = ExcelFillStyle.Solid;
        //    fillHEADERG.BackgroundColor.SetColor(AppUtility.HeaderBackColor);


        //    string ordernumber = string.Empty;

        //    int row = 3;
        //    int inc = 1;

        //    int col = 1;
        //    foreach (var order in data)
        //    {
        //        col = 1;

        //        worksheet1.Cells[row, col].Value = inc;
        //        var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        //        fillSrNo.PatternType = ExcelFillStyle.Solid;
        //        fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SourceName;
        //        col++;
        //        //worksheet1.Cells[row, col].Value = order.POCounter;
        //        //col++;
        //        worksheet1.Cells[row, col].Value = order.INVCounter;
        //        col++;
        //        worksheet1.Cells[row, col].Value = order.MRCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.PKDCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.RDECounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.COSCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.OBACounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SHIPCounter;
        //        col++;


        //        foreach (var item in order.locatonCounter)
        //        {
        //            worksheet1.Cells[row, col].Value = Convert.ToInt32(item.Value);
        //            col++;
        //        }
        //        row++;
        //        inc++;

        //    }


        //    worksheet1.Cells[row, 1].Value = "";
        //    worksheet1.Cells[row, 2].Value = "Grand Total";
        //    worksheet1.Cells[row, 3].Formula = "=Sum(C3:C" + (row - 1) + ")";// "=Sum(" + worksheet1.Cells[3, 3].Address + ":" + worksheet1.Cells[59, 3].Address + ")";
        //    worksheet1.Cells[row, 4].Formula = "=Sum(D3:D" + (row - 1) + ")";
        //    worksheet1.Cells[row, 5].Formula = "=Sum(E3:E" + (row - 1) + ")";
        //    worksheet1.Cells[row, 6].Formula = "=Sum(F3:F" + (row - 1) + ")";
        //    worksheet1.Cells[row, 7].Formula = "=Sum(G3:G" + (row - 1) + ")";
        //    worksheet1.Cells[row, 8].Formula = "=Sum(H3:H" + (row - 1) + ")";
        //    worksheet1.Cells[row, 9].Formula = "=Sum(I3:I" + (row - 1) + ")";
        //    worksheet1.Cells[row, 10].Formula = "=Sum(K3:K" + (row - 1) + ")";

        //    int totalDataRows = data.Count();
        //    for (int ita = 10; ita <= col; ita++)
        //    {
        //        string colNam = ita.ExcelColumnFromNumber();
        //        worksheet1.Cells[row, ita].Formula = "=Sum(" + colNam + "3:" + colNam + (row - 1) + ")";
        //    }

        //    for (int ita = 3; ita < row; ita++)
        //    {
        //        string colNam = (col - 1).ExcelColumnFromNumber();
        //        worksheet1.Cells[ita, col].Formula = "=Sum(J" + ita + ":" + colNam + ita + ")";
        //    }

        //    var fillTotal = worksheet1.Cells[row, 1, row, col].Style.Fill;
        //    fillTotal.PatternType = ExcelFillStyle.Solid;
        //    fillTotal.BackgroundColor.SetColor(_colorHEADER);

        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:{0}{1}", lastColumunName, row - 1)].AutoFitColumns();

        //}

        //public void Summary(Stream stream, IList<CTDI.Shared.Dto.SummaryCircleWiseDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {
        //        SummaryCircle(xlPackage, data, "Circle Summary");
        //        xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "Summary Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}

        //private void SummaryCircle(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryCircleWiseDto> data, string sheetName = "Summary Circle")
        //{
        //    // get handle to the existing worksheet
        //    var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        //    //Create Headers and format them
        //    string[] headerList = null;

        //    headerList = CTDI.Shared.ReportsHeader.GetSummaryCircle();

        //    if (headerList.Count() <= 0)
        //    {
        //        return;
        //    }

        //    worksheet1.Cells["A1:J1"].Merge = true;
        //    worksheet1.Cells["A1:J1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //    worksheet1.Cells["A1:J1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        //    worksheet1.Cells["A1"].Value = "Circle wise Reliance CDMA/GSM Cards Summary";
        //    worksheet1.Cells["A1"].Style.Font.Bold = true;
        //    worksheet1.Cells["A1"].Style.Font.Size = 20;

        //    var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        //    fillColor2.PatternType = ExcelFillStyle.Solid;
        //    fillColor2.BackgroundColor.SetColor(AppUtility.HeadBackColor);

        //    worksheet1.Row(2).Height = 30.00d;
        //    worksheet1.Cells["A2:J2"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        //    Color _colorHEADER = AppUtility.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        //    for (int i = 0; i < headerList.Length; i++)
        //    {
        //        worksheet1.Cells[2, i + 1].Value = headerList[i];
        //        worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        //        ExcelBorderLine(worksheet1, 2, i + 1);

        //        var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        //        fillHEADER.PatternType = ExcelFillStyle.Solid;
        //        fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        //    }

        //    string ordernumber = string.Empty;

        //    int row = 3;
        //    int inc = 1;

        //    int tReceived = 0;
        //    int tRDE = 0;
        //    int tMR = 0;
        //    int tPicked = 0;
        //    int tCos = 0;
        //    int tOBA = 0;
        //    int tShipped = 0;
        //    int TGrandTotal = 0;

        //    foreach (var order in data)
        //    {
        //        int col = 1;

        //        worksheet1.Cells[row, col].Value = inc;
        //        var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        //        fillSrNo.PatternType = ExcelFillStyle.Solid;
        //        fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SourceName;
        //        col++;
        //        worksheet1.Cells[row, col].Value = order.INVCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.MRCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.PKDCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.RDECounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.COSCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.OBACounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.SHIPCounter;
        //        col++;

        //        worksheet1.Cells[row, col].Value = order.GrandTotal;


        //        var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        //        fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        //        fillGrandTotal.BackgroundColor.SetColor(_colorHEADER);
        //        col++;


        //        row++;
        //        inc++;

        //        tRDE = tRDE + order.RDECounter;
        //        tMR = tMR + order.MRCounter;
        //        tPicked = tPicked + order.PKDCounter;
        //        tCos = tCos + order.COSCounter;
        //        tOBA = tOBA + order.OBACounter;
        //        tShipped = tShipped + order.SHIPCounter;
        //        tReceived = tReceived + order.INVCounter;
        //        TGrandTotal = TGrandTotal + order.GrandTotal;

        //    }


        //    worksheet1.Cells[row, 1].Value = "";
        //    worksheet1.Cells[row, 2].Value = "Grand Total";
        //    worksheet1.Cells[row, 3].Value = tReceived;
        //    worksheet1.Cells[row, 4].Value = tMR;
        //    worksheet1.Cells[row, 5].Value = tPicked;
        //    worksheet1.Cells[row, 6].Value = tRDE;
        //    worksheet1.Cells[row, 7].Value = tCos;
        //    worksheet1.Cells[row, 8].Value = tOBA;
        //    worksheet1.Cells[row, 9].Value = tShipped;
        //    worksheet1.Cells[row, 10].Value = TGrandTotal;

        //    var fillTotal = worksheet1.Cells[row, 1, row, 11].Style.Fill;
        //    fillTotal.PatternType = ExcelFillStyle.Solid;
        //    fillTotal.BackgroundColor.SetColor(_colorHEADER);


        //    worksheet1.View.FreezePanes(2, 1);

        //    worksheet1.Cells[string.Format("A1:J{0}", row - 1)].AutoFitColumns();

        //}

        ////        public void RandR_RNP(Stream stream, List<CTDI.Shared.Dto.RAndRReportRNPDto> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");
        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                // get handle to the existing worksheet
        ////                var worksheet = xlPackage.Workbook.Worksheets.Add("R_and_R_Report_RNP");

        ////                //Create Headers and format them
        ////                string[] reportHeaderList = ReportsHeader.GetRandR_RNP();

        ////                worksheet.Row(1).Height = 30.00d;

        ////                Color _colorHEADER = AppSetting.HeaderBackColor;
        ////                for (int i = 0; i < reportHeaderList.Length; i++)
        ////                {
        ////                    worksheet.Cells[1, i + 1].Value = reportHeaderList[i];
        ////                    worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        ////                    ExcelBorderLine(worksheet, 1, i + 1);

        ////                    var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
        ////                    fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////                }

        ////                string ordernumber = string.Empty;

        ////                int row = 2;
        ////                int inc = 1;
        ////                foreach (var order in data)
        ////                {
        ////                    int col = 1;

        ////                    worksheet.Cells[row, col].Value = inc;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.RepairOrderNo;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Category;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.ModelName;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order._2G3G;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.OEM;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.Circle;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.SerialNumber;
        ////                    col++;

        ////                    //worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.RMANo;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.DateOfReceived;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.DateOfDispatch;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.CustomerPriority;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/MM/yyyy";
        ////                    worksheet.Cells[row, col].Value = order.RepairDate;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RepairTAT;
        ////                    col++;


        ////                    //worksheet.Cells[row, col].Value = order.AvgTAT;
        ////                    //col++;

        ////                    worksheet.Cells[row, col].Value = order.Status;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.ReceivingInspectionStatus;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.ReceivingCourier;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.CourierDocketNo;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.GeneralFaultDescriptionReported;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.CorrectiveAction;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.SACSignByTTSLAuthorityName;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.LabourInvoice;
        ////                    col++;

        ////                    worksheet.Cells[row, col].Value = order.RepairCharges;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.MaterialInvoice;
        ////                    col++;
        ////                    worksheet.Cells[row, col].Value = order.MaterialCharges;
        ////                    col++;

        ////                    row++;
        ////                    inc++;
        ////                }

        ////                worksheet.View.FreezePanes(2, 1);

        ////                worksheet.Cells[string.Format("A1:Z{0}", row - 1)].AutoFitColumns();

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} RandR Report RNP", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} RandR Report RNP ", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0}  RandR Report RNP ", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = " RandR Report RNP Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0}  RandR Report RNP ", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }




        ////        public void SummaryReport(Stream stream, SummaryFor summaryFor, IList<CTDI.Shared.Dto.SummaryHuaweiCircleWiseDto> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                SummaryHuaweiCircleInXlSX(xlPackage, data, "SummaryReport" + summaryFor.ToString());
        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Summary Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        public void SummaryReport(Stream stream, SummaryFor summaryFor, IList<CTDI.Shared.Dto.SummaryHuaweiCardWiseDto> data, string p_strPath, List<string> locationNames)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                SummaryHuaweiCardInXlSX(xlPackage, data, locationNames, "SummaryReport" + summaryFor.ToString());
        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Summary Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        public void SummaryReport(Stream stream, SummaryFor summaryFor, IList<CTDI.Shared.Dto.SummaryNECCircleWiseDto> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                SummaryNECCircleInXlSX(xlPackage, data, "SummaryReport" + summaryFor.ToString());
        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Summary Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        public void SummaryReport(Stream stream, SummaryFor summaryFor, IList<CTDI.Shared.Dto.SummaryNECCardWiseDto> data, string p_strPath, List<string> locationNames)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                SummaryNECCardInXlSX(xlPackage, data, locationNames, "SummaryReport" + summaryFor.ToString());
        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Summary Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);

        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        public void SummaryReport(Stream stream, SummaryFor summaryFor, IList<CTDI.Shared.Dto.SummaryRNPCircleWiseDto> data, string p_strPath)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                SummaryRNPCircleInXlSX(xlPackage, data, "SummaryReport" + summaryFor.ToString());

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Summary Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);
        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        public void SummaryReport(Stream stream, SummaryFor summaryFor, IList<CTDI.Shared.Dto.SummaryRNPCardWiseDto> data, string p_strPath, List<string> locationNames)
        ////        {
        ////            if (stream == null)
        ////                throw new ArgumentNullException("stream");

        ////            using (var xlPackage = new ExcelPackage(stream))
        ////            {
        ////                SummaryRNPCardInXlSX(xlPackage, data,locationNames, "SummaryReport" + summaryFor.ToString());

        ////                xlPackage.Workbook.Properties.Title = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Author = _companyName;
        ////                xlPackage.Workbook.Properties.Subject = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Keywords = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Category = "Summary Report";
        ////                xlPackage.Workbook.Properties.Comments = string.Format("{0} Summary Report", "CTDI");
        ////                xlPackage.Workbook.Properties.Company = "CTDI";
        ////                if (File.Exists(p_strPath))
        ////                    File.Delete(p_strPath);
        ////                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        ////                {
        ////                    xlPackage.SaveAs(fs);
        ////                }
        ////            }
        ////        }
        ////        private void SummaryHuaweiCircleInXlSX(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryHuaweiCircleWiseDto> data, string sheetName = "Summary Huawei")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            string[] headerList = null;

        ////            headerList = CTDI.Shared.ReportsHeader.GetSummary_Huawei();

        ////            if (headerList.Count() <= 0)
        ////            {
        ////                return;
        ////            }

        ////            worksheet1.Cells["A1:J1"].Merge = true;
        ////            worksheet1.Cells["A1:J1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells["A1:J1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["A1"].Value = "Circle wise TTL HUAWEI CDMA/GSM Cards Summary";
        ////            worksheet1.Cells["A1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["A1"].Style.Font.Size = 20;

        ////            //string HEXARECEIVE = "#f7f138";
        ////            //Color _color = System.Drawing.ColorTranslator.FromHtml(HEXARECEIVE);
        ////            var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        ////            fillColor2.PatternType = ExcelFillStyle.Solid;
        ////            fillColor2.BackgroundColor.SetColor(AppSetting.HeadBackColor);

        ////            worksheet1.Row(2).Height = 30.00d;
        ////            worksheet1.Cells["A2:J2"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            for (int i = 0; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[2, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, i + 1);

        ////                var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 3;
        ////            int inc = 1;

        ////            int TReceived = 0;
        ////            int TBER = 0;
        ////            int TFaultyReturn = 0;
        ////            int TNFF = 0;
        ////            int TRepaired = 0;
        ////            int TUseReferenceForRepairSupport = 0;
        ////            int TWIP = 0;
        ////            int TGrandTotal = 0;

        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        ////                fillSrNo.PatternType = ExcelFillStyle.Solid;
        ////                fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.SourceCircle;
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.Received;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.BER;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.FaultyReturn;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.NFF;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Repaired;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UseReferenceForRepairSupport;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WIP;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.GrandTotal;


        ////                var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        ////                fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        ////                fillGrandTotal.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;


        ////                row++;
        ////                inc++;

        ////                TReceived = TReceived + order.Received;
        ////                TBER = TBER + order.BER;
        ////                TFaultyReturn = TFaultyReturn + order.FaultyReturn;
        ////                TNFF = TNFF + order.NFF;
        ////                TRepaired = TRepaired + order.Repaired;
        ////                TUseReferenceForRepairSupport = TUseReferenceForRepairSupport + order.UseReferenceForRepairSupport;
        ////                TWIP = TWIP + order.WIP;
        ////                TGrandTotal = TGrandTotal + order.GrandTotal;

        ////            }


        ////            worksheet1.Cells[row, 1].Value = "";
        ////            worksheet1.Cells[row, 2].Value = "Grand Total";
        ////            worksheet1.Cells[row, 3].Value = TReceived;
        ////            worksheet1.Cells[row, 4].Value = TBER;
        ////            worksheet1.Cells[row, 5].Value = TFaultyReturn;
        ////            worksheet1.Cells[row, 6].Value = TNFF;
        ////            worksheet1.Cells[row, 7].Value = TRepaired;
        ////            worksheet1.Cells[row, 8].Value = TUseReferenceForRepairSupport;
        ////            worksheet1.Cells[row, 9].Value = TWIP;
        ////            worksheet1.Cells[row, 10].Value = TGrandTotal;

        ////            var fillTotal = worksheet1.Cells[row, 1, row, 10].Style.Fill;
        ////            fillTotal.PatternType = ExcelFillStyle.Solid;
        ////            fillTotal.BackgroundColor.SetColor(_colorHEADER);


        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:J{0}", row - 1)].AutoFitColumns();

        ////        }
        ////        private void SummaryHuaweiCardInXlSX(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryHuaweiCardWiseDto> data, List<string> locations, string sheetName = "Summary Huawei")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            string[] headerList = null;

        ////            headerList = CTDI.Shared.ReportsHeader.GetSummary_Huawei();

        ////            if (headerList.Count() <= 0)
        ////            {
        ////                return;
        ////            }

        ////            worksheet1.Cells["A1:I1"].Merge = true;
        ////            worksheet1.Cells["A1:I1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["A1"].Value = "Card wise TTL HUAWEI CDMA/GSM Cards Summary";
        ////            worksheet1.Cells["A1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["A1"].Style.Font.Size = 20;

        ////            var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        ////            fillColor2.PatternType = ExcelFillStyle.Solid;
        ////            fillColor2.BackgroundColor.SetColor(AppSetting.HeadBackColor);

        ////            int toLocation = locations.Count() + 9;
        ////            string lastColumunName = toLocation.ExcelColumnFromNumber();
        ////            worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Merge = true;
        ////            worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["J1"].Value = "Cards Dispatched to Circle";
        ////            worksheet1.Cells["J1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["J1"].Style.Font.Size = 20;


        ////            var fillColor3 = worksheet1.Cells["J1"].Style.Fill;
        ////            fillColor3.PatternType = ExcelFillStyle.Solid;
        ////            fillColor3.BackgroundColor.SetColor(AppSetting.Head2BackColor);




        ////            worksheet1.Row(2).Height = 30.00d;
        ////            worksheet1.Cells[string.Format("A2:{0}2", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            Color _colorHEADER = AppSetting.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            int colHeaderCountr = 0;
        ////            for (int i = colHeaderCountr; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[2, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, i + 1);

        ////                var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                if (headerList[i].ToString() == "WIP ( Hold)")
        ////                {
        ////                    fillHEADER.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        ////                }
        ////                else
        ////                {
        ////                    fillHEADER.BackgroundColor.SetColor(AppSetting.HeaderBackColor);
        ////                }
        ////                colHeaderCountr = i;
        ////            }

        ////            foreach (var item in locations)
        ////            {
        ////                worksheet1.Cells[2, colHeaderCountr + 1].Value = item;
        ////                worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        ////                var fillHEADER = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(AppSetting.HeaderBackColor);

        ////                colHeaderCountr++;
        ////            }

        ////            worksheet1.Cells[2, colHeaderCountr + 1].Value = "Grand Total";
        ////            worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        ////            ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        ////            var fillHEADERG = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        ////            fillHEADERG.PatternType = ExcelFillStyle.Solid;
        ////            fillHEADERG.BackgroundColor.SetColor(AppSetting.HeaderBackColor);


        ////            string ordernumber = string.Empty;

        ////            int row = 3;
        ////            int inc = 1;

        ////            int col = 1;
        ////            foreach (var order in data)
        ////            {
        ////                col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        ////                fillSrNo.PatternType = ExcelFillStyle.Solid;
        ////                fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UnitDescription;
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.Received;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.BER;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.FaultyReturn;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.NFF;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Repaired;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UseReferenceForRepairSupport;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WIP;

        ////                var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        ////                fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        ////                fillGrandTotal.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        ////                col++;

        ////                foreach (var item in order.locatonCounter)
        ////                {
        ////                    worksheet1.Cells[row, col].Value = Convert.ToInt32(item.Value);
        ////                    col++;
        ////                }
        ////                row++;
        ////                inc++;

        ////            }


        ////            worksheet1.Cells[row, 1].Value = "";
        ////            worksheet1.Cells[row, 2].Value = "Grand Total";
        ////            worksheet1.Cells[row, 3].Formula = "=Sum(C3:C" + (row - 1) + ")";// "=Sum(" + worksheet1.Cells[3, 3].Address + ":" + worksheet1.Cells[59, 3].Address + ")";
        ////            worksheet1.Cells[row, 4].Formula = "=Sum(D3:D" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 5].Formula = "=Sum(E3:E" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 6].Formula = "=Sum(F3:F" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 7].Formula = "=Sum(G3:G" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 8].Formula = "=Sum(H3:H" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 9].Formula = "=Sum(I3:I" + (row - 1) + ")";

        ////            int totalDataRows = data.Count();
        ////            for (int ita = 10; ita <= col; ita++)
        ////            {
        ////                string colNam = ita.ExcelColumnFromNumber();
        ////                worksheet1.Cells[row, ita].Formula = "=Sum(" + colNam + "3:" + colNam + (row - 1) + ")";
        ////            }


        ////            for (int ita = 3; ita < row; ita++)
        ////            {
        ////                string colNam = (col - 1).ExcelColumnFromNumber();
        ////                worksheet1.Cells[ita, col].Formula = "=Sum(J" + ita + ":" + colNam + ita + ")";
        ////            }

        ////            var fillTotal = worksheet1.Cells[row, 1, row, col].Style.Fill;
        ////            fillTotal.PatternType = ExcelFillStyle.Solid;
        ////            fillTotal.BackgroundColor.SetColor(_colorHEADER);

        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:{0}{1}", lastColumunName, row - 1)].AutoFitColumns();

        ////        }

        ////        private void SummaryRNPCircleInXlSX(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryRNPCircleWiseDto> data, string sheetName = "Summary Report")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            string[] headerList = null;
        ////            headerList = CTDI.Shared.ReportsHeader.GetSummary_RNP();

        ////            if (headerList.Count() <= 0)
        ////            {
        ////                return;
        ////            }

        ////            worksheet1.Cells["A1:I1"].Merge = true;
        ////            worksheet1.Cells["A1:I1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["A1"].Value = "Circle wise TTL RNP Cards Summary";
        ////            worksheet1.Cells["A1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["A1"].Style.Font.Size = 20;

        ////            var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        ////            fillColor2.PatternType = ExcelFillStyle.Solid;
        ////            fillColor2.BackgroundColor.SetColor(AppSetting.HeadBackColor);




        ////            worksheet1.Row(2).Height = 30.00d;
        ////            worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            for (int i = 0; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[2, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, i + 1);

        ////                var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 3;
        ////            int inc = 1;

        ////            int TGrandTotal = 0;
        ////            int TRepaired = 0;
        ////            int TReturnItIs = 0;
        ////            int TScrap = 0;
        ////            int TUseAsGolden = 0;
        ////            int TWIP = 0;
        ////            int TRecovery = 0;

        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        ////                fillSrNo.PatternType = ExcelFillStyle.Solid;
        ////                fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Circle;
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.GrandTotal;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Repaired;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.ReturnItIs;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Scrap;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UseAsGolden;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WIP;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Recovery + "%";
        ////                var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        ////                fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        ////                fillGrandTotal.BackgroundColor.SetColor(_colorHEADER);

        ////                col++;

        ////                row++;
        ////                inc++;

        ////                TGrandTotal = TGrandTotal + order.GrandTotal;
        ////                TRepaired = TRepaired + order.Repaired;
        ////                TReturnItIs = TReturnItIs + order.ReturnItIs;
        ////                TScrap = TScrap + order.Scrap;
        ////                TUseAsGolden = TUseAsGolden + order.UseAsGolden;
        ////                TWIP = TWIP + order.WIP;
        ////                TRecovery = TRecovery + order.Recovery;

        ////            }

        ////            worksheet1.Cells[row, 1].Value = "";
        ////            worksheet1.Cells[row, 2].Value = "Grand Total";
        ////            worksheet1.Cells[row, 3].Value = TGrandTotal;
        ////            worksheet1.Cells[row, 4].Value = TRepaired;
        ////            worksheet1.Cells[row, 5].Value = TReturnItIs;
        ////            worksheet1.Cells[row, 6].Value = TScrap;
        ////            worksheet1.Cells[row, 7].Value = TUseAsGolden;
        ////            worksheet1.Cells[row, 8].Value = TWIP;
        ////            worksheet1.Cells[row, 9].Value = TRecovery;

        ////            var fillTotal = worksheet1.Cells[row, 1, row, 9].Style.Fill;
        ////            fillTotal.PatternType = ExcelFillStyle.Solid;
        ////            fillTotal.BackgroundColor.SetColor(_colorHEADER);

        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:I{0}", row - 1)].AutoFitColumns();

        ////        }


        ////        private void SummaryRNPCardInXlSX(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryRNPCardWiseDto> data, List<string> locations, string sheetName = "Summary Report")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            string[] headerList = null;
        ////            headerList = CTDI.Shared.ReportsHeader.GetSummary_RNP();

        ////            if (headerList.Count() <= 0)
        ////            {
        ////                return;
        ////            }

        ////            worksheet1.Cells["A1:H1"].Merge = true;
        ////            worksheet1.Cells["A1:H1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells["A1:H1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["A1"].Value = "Card wise TTL RNP Cards Summary";
        ////            worksheet1.Cells["A1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["A1"].Style.Font.Size = 20;

        ////            var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        ////            fillColor2.PatternType = ExcelFillStyle.Solid;
        ////            fillColor2.BackgroundColor.SetColor(AppSetting.HeadBackColor);

        ////            int toLocation = locations.Count() + 8;
        ////            string lastColumunName = toLocation.ExcelColumnFromNumber();
        ////            worksheet1.Cells[string.Format("I1:{0}1", lastColumunName)].Merge = true;
        ////            worksheet1.Cells[string.Format("I1:{0}1", lastColumunName)].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells[string.Format("I1:{0}1", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["I1"].Value = "Cards Dispatched to Circle";
        ////            worksheet1.Cells["I1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["I1"].Style.Font.Size = 20;

        ////            var fillColor3 = worksheet1.Cells["J1"].Style.Fill;
        ////            fillColor3.PatternType = ExcelFillStyle.Solid;
        ////            fillColor3.BackgroundColor.SetColor(AppSetting.Head2BackColor);



        ////            worksheet1.Row(2).Height = 30.00d;
        ////            worksheet1.Cells[string.Format("A2:{0}2", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            Color _colorHEADER = AppSetting.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            int colHeaderCountr = 0;

        ////            //worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            //Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            for (int i = 0; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[2, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, i + 1);

        ////                var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                if (headerList[i].ToString() == "WIP")
        ////                {
        ////                    fillHEADER.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        ////                }
        ////                else
        ////                {
        ////                    fillHEADER.BackgroundColor.SetColor(AppSetting.HeaderBackColor);
        ////                }
        ////                colHeaderCountr = i;
        ////            }


        ////            foreach (var item in locations)
        ////            {
        ////                worksheet1.Cells[2, colHeaderCountr + 1].Value = item;
        ////                worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        ////                var fillHEADER = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(AppSetting.HeaderBackColor);

        ////                colHeaderCountr++;

        ////            }

        ////            worksheet1.Cells[2, colHeaderCountr + 1].Value = "Grand Total";
        ////            worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        ////            ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        ////            var fillHEADERG = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        ////            fillHEADERG.PatternType = ExcelFillStyle.Solid;
        ////            fillHEADERG.BackgroundColor.SetColor(AppSetting.HeaderBackColor);

        ////            string ordernumber = string.Empty;



        ////            //string ordernumber = string.Empty;

        ////            int row = 3;
        ////            int inc = 1;


        ////            int col = 1;
        ////            foreach (var order in data)
        ////            {
        ////                col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        ////                fillSrNo.PatternType = ExcelFillStyle.Solid;
        ////                fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UnitDescription;
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.GrandTotal;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Repaired;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.ReturnItIs;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Scrap;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UseAsGolden;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WIP;



        ////                var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        ////                fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        ////                fillGrandTotal.BackgroundColor.SetColor(_colorHEADER);

        ////                col++;

        ////                foreach (var item in order.locatonCounter)
        ////                {
        ////                    worksheet1.Cells[row, col].Value = Convert.ToInt32(item.Value);
        ////                    col++;
        ////                }


        ////                row++;
        ////                inc++;


        ////            }

        ////            worksheet1.Cells[row, 1].Value = "";
        ////            worksheet1.Cells[row, 2].Value = "Grand Total";
        ////            worksheet1.Cells[row, 3].Formula = "=Sum(C3:C" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 4].Formula = "=Sum(D3:D" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 5].Formula = "=Sum(E3:E" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 6].Formula = "=Sum(F3:F" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 7].Formula = "=Sum(G3:G" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 8].Formula = "=Sum(H3:H" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 9].Formula = "=Sum(I3:I" + (row - 1) + ")";

        ////            for (int ita = 10; ita <= col; ita++)
        ////            {
        ////                string colNam = ita.ExcelColumnFromNumber();
        ////                worksheet1.Cells[row, ita].Formula = "=Sum(" + colNam + "3:" + colNam + (row - 1) + ")";
        ////            }


        ////            for (int ita = 3; ita < row; ita++)
        ////            {
        ////                string colNam = (col - 1).ExcelColumnFromNumber();
        ////                worksheet1.Cells[ita, col].Formula = "=Sum(J" + ita + ":" + colNam + ita + ")";
        ////            }


        ////            var fillTotal = worksheet1.Cells[row, 1, row, col].Style.Fill;
        ////            fillTotal.PatternType = ExcelFillStyle.Solid;
        ////            fillTotal.BackgroundColor.SetColor(_colorHEADER);

        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:I{0}", row - 1)].AutoFitColumns();

        ////        }



        ////        private void SummaryNECCircleInXlSX(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryNECCircleWiseDto> data, string sheetName = "Summary NEC")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            string[] headerList = null;

        ////            headerList = CTDI.Shared.ReportsHeader.GetSummary_Huawei();

        ////            if (headerList.Count() <= 0)
        ////            {
        ////                return;
        ////            }


        ////            worksheet1.Cells["A1:J1"].Merge = true;
        ////            worksheet1.Cells["A1:J1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells["A1:J1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["A1"].Value = "Circle wise TTL NEC Cards Summary";
        ////            worksheet1.Cells["A1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["A1"].Style.Font.Size = 20;

        ////            var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        ////            fillColor2.PatternType = ExcelFillStyle.Solid;
        ////            fillColor2.BackgroundColor.SetColor(AppSetting.HeadBackColor);


        ////            worksheet1.Row(2).Height = 30.00d;
        ////            worksheet1.Cells["A1:J1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            for (int i = 0; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[2, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, i + 1);

        ////                var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(_colorHEADER);
        ////            }

        ////            string ordernumber = string.Empty;

        ////            int row = 3;
        ////            int inc = 1;

        ////            int TReceived = 0;
        ////            int TBER = 0;
        ////            int TFaultyReturn = 0;
        ////            int TNFF = 0;
        ////            int TRepaired = 0;
        ////            int TUseReferenceForRepairSupport = 0;
        ////            int TWIP = 0;
        ////            int TGrandTotal = 0;
        ////            foreach (var order in data)
        ////            {
        ////                int col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        ////                fillSrNo.PatternType = ExcelFillStyle.Solid;
        ////                fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.SourceCircle;
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.Received;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.BER;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.FaultyReturn;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.NFF;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Repaired;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UseReferenceForRepairSupport;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WIP;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.GrandTotal;
        ////                var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        ////                fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        ////                fillGrandTotal.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;

        ////                row++;
        ////                inc++;

        ////                TReceived = TReceived + order.Received;
        ////                TBER = TBER + order.BER;
        ////                TFaultyReturn = TFaultyReturn + order.FaultyReturn;
        ////                TNFF = TNFF + order.NFF;
        ////                TRepaired = TRepaired + order.Repaired;
        ////                TUseReferenceForRepairSupport = TUseReferenceForRepairSupport + order.UseReferenceForRepairSupport;
        ////                TWIP = TWIP + order.WIP;
        ////                TGrandTotal = TGrandTotal + order.GrandTotal;

        ////            }


        ////            worksheet1.Cells[row, 1].Value = "";
        ////            worksheet1.Cells[row, 2].Value = "Grand Total";
        ////            worksheet1.Cells[row, 3].Value = TReceived;
        ////            worksheet1.Cells[row, 4].Value = TBER;
        ////            worksheet1.Cells[row, 5].Value = TFaultyReturn;
        ////            worksheet1.Cells[row, 6].Value = TNFF;
        ////            worksheet1.Cells[row, 7].Value = TRepaired;
        ////            worksheet1.Cells[row, 8].Value = TUseReferenceForRepairSupport;
        ////            worksheet1.Cells[row, 9].Value = TWIP;
        ////            worksheet1.Cells[row, 10].Value = TGrandTotal;

        ////            var fillTotal = worksheet1.Cells[row, 1, row, 10].Style.Fill;
        ////            fillTotal.PatternType = ExcelFillStyle.Solid;
        ////            fillTotal.BackgroundColor.SetColor(_colorHEADER);

        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:AL{0}", row - 1)].AutoFitColumns();

        ////        }

        ////        private void SummaryNECCardInXlSX(ExcelPackage xlPackage, IList<CTDI.Shared.Dto.SummaryNECCardWiseDto> data, List<string> locations, string sheetName = "Summary NEC")
        ////        {
        ////            // get handle to the existing worksheet
        ////            var worksheet1 = xlPackage.Workbook.Worksheets.Add(sheetName);

        ////            //Create Headers and format them
        ////            string[] headerList = null;

        ////            headerList = CTDI.Shared.ReportsHeader.GetSummary_Huawei();

        ////            if (headerList.Count() <= 0)
        ////            {
        ////                return;
        ////            }


        ////            worksheet1.Cells["A1:I1"].Merge = true;
        ////            worksheet1.Cells["A1:I1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells["A1:I1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["A1"].Value = "Card wise TTL NEC CDMA/GSM Cards Summary";
        ////            worksheet1.Cells["A1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["A1"].Style.Font.Size = 20;

        ////            var fillColor2 = worksheet1.Cells["A1"].Style.Fill;
        ////            fillColor2.PatternType = ExcelFillStyle.Solid;
        ////            fillColor2.BackgroundColor.SetColor(AppSetting.HeadBackColor);

        ////            int toLocation = locations.Count() + 9;
        ////            string lastColumunName = toLocation.ExcelColumnFromNumber();
        ////            worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Merge = true;
        ////            worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        ////            worksheet1.Cells[string.Format("J1:{0}1", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

        ////            worksheet1.Cells["J1"].Value = "Cards Dispatched to Circle";
        ////            worksheet1.Cells["J1"].Style.Font.Bold = true;
        ////            worksheet1.Cells["J1"].Style.Font.Size = 20;

        ////            var fillColor3 = worksheet1.Cells["J1"].Style.Fill;
        ////            fillColor3.PatternType = ExcelFillStyle.Solid;
        ////            fillColor3.BackgroundColor.SetColor(AppSetting.Head2BackColor);

        ////            worksheet1.Row(2).Height = 30.00d;
        ////            worksheet1.Cells[string.Format("A2:{0}2", lastColumunName)].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
        ////            Color _colorHEADER = AppSetting.HeaderBackColor;// System.Drawing.ColorTranslator.FromHtml(ConfigSettings.HeaderBackColorHax);
        ////            int colHeaderCountr = 0;
        ////            for (int i = colHeaderCountr; i < headerList.Length; i++)
        ////            {
        ////                worksheet1.Cells[2, i + 1].Value = headerList[i];
        ////                worksheet1.Cells[2, i + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, i + 1);

        ////                var fillHEADER = worksheet1.Cells[2, i + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                if (headerList[i].ToString() == "WIP ( Hold)")
        ////                {
        ////                    fillHEADER.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        ////                }
        ////                else
        ////                {
        ////                    fillHEADER.BackgroundColor.SetColor(AppSetting.HeaderBackColor);
        ////                }
        ////                colHeaderCountr = i;
        ////            }
        ////            foreach (var item in locations)
        ////            {
        ////                worksheet1.Cells[2, colHeaderCountr + 1].Value = item;
        ////                worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        ////                ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        ////                var fillHEADER = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        ////                fillHEADER.PatternType = ExcelFillStyle.Solid;
        ////                fillHEADER.BackgroundColor.SetColor(AppSetting.HeaderBackColor);

        ////                colHeaderCountr++;

        ////            }

        ////            worksheet1.Cells[2, colHeaderCountr + 1].Value = "Grand Total";
        ////            worksheet1.Cells[2, colHeaderCountr + 1].Style.Font.Bold = true;
        ////            ExcelBorderLine(worksheet1, 2, colHeaderCountr + 1);

        ////            var fillHEADERG = worksheet1.Cells[2, colHeaderCountr + 1].Style.Fill;
        ////            fillHEADERG.PatternType = ExcelFillStyle.Solid;
        ////            fillHEADERG.BackgroundColor.SetColor(AppSetting.HeaderBackColor);

        ////            string ordernumber = string.Empty;

        ////            int row = 3;
        ////            int inc = 1;


        ////            int col = 1;
        ////            foreach (var order in data)
        ////            {
        ////                col = 1;

        ////                worksheet1.Cells[row, col].Value = inc;
        ////                var fillSrNo = worksheet1.Cells[row, col].Style.Fill;
        ////                fillSrNo.PatternType = ExcelFillStyle.Solid;
        ////                fillSrNo.BackgroundColor.SetColor(_colorHEADER);
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UnitDescription;
        ////                col++;
        ////                worksheet1.Cells[row, col].Value = order.Received;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.BER;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.FaultyReturn;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.NFF;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.Repaired;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.UseReferenceForRepairSupport;
        ////                col++;

        ////                worksheet1.Cells[row, col].Value = order.WIP;

        ////                var fillGrandTotal = worksheet1.Cells[row, col].Style.Fill;
        ////                fillGrandTotal.PatternType = ExcelFillStyle.Solid;
        ////                fillGrandTotal.BackgroundColor.SetColor(AppSetting.HeadBackColor);
        ////                col++;


        ////                foreach (var item in order.locatonCounter)
        ////                {
        ////                    worksheet1.Cells[row, col].Value = Convert.ToInt32(item.Value);
        ////                    col++;
        ////                }
        ////                row++;
        ////                inc++;


        ////            }

        ////            //"=Sum(" + worksheet1.Cells[3, 3].Address + ":" + worksheet1.Cells[59, 3].Address + ")";
        ////            worksheet1.Cells[row, 1].Value = "";
        ////            worksheet1.Cells[row, 2].Value = "Grand Total";
        ////            worksheet1.Cells[row, 3].Formula = "=Sum(C3:C" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 4].Formula = "=Sum(D3:D" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 5].Formula = "=Sum(E3:E" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 6].Formula = "=Sum(F3:F" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 7].Formula = "=Sum(G3:G" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 8].Formula = "=Sum(H3:H" + (row - 1) + ")";
        ////            worksheet1.Cells[row, 9].Formula = "=Sum(I3:I" + (row - 1) + ")";

        ////            //int totalDataRows = data.Count();
        ////            for (int ita = 10; ita <= col; ita++)
        ////            {
        ////                string colNam = ita.ExcelColumnFromNumber();
        ////                worksheet1.Cells[row, ita].Formula = "=Sum(" + colNam + "3:" + colNam + (row - 1) + ")";
        ////            }


        ////            for (int ita = 3; ita < row; ita++)
        ////            {
        ////                string colNam = (col - 1).ExcelColumnFromNumber();
        ////                worksheet1.Cells[ita, col].Formula = "=Sum(J" + ita + ":" + colNam + ita + ")";
        ////            }


        ////            var fillTotal = worksheet1.Cells[row, 1, row, col].Style.Fill;
        ////            fillTotal.PatternType = ExcelFillStyle.Solid;
        ////            fillTotal.BackgroundColor.SetColor(_colorHEADER);


        ////            worksheet1.View.FreezePanes(2, 1);

        ////            worksheet1.Cells[string.Format("A1:{0}{1}", lastColumunName, row - 1)].AutoFitColumns();
        ////        }


        //public void GetPicklistPending(Stream stream, IList<CTDI.Shared.Dto.PicklistItemDto> data, string p_strPath)
        //{
        //    if (stream == null)
        //        throw new ArgumentNullException("stream");

        //    using (var xlPackage = new ExcelPackage(stream))
        //    {
        //        // get handle to the existing worksheet
        //        var worksheet = xlPackage.Workbook.Worksheets.Add("Pick List Pending");

        //        //Create Headers and format them
        //        var properties = ReportsHeader.GetPickListPending();

        //        for (int i = 0; i < properties.Length; i++)
        //        {
        //            worksheet.Cells[1, i + 1].Value = properties[i];
        //            worksheet.Cells[1, i + 1].Style.Font.Bold = true;
        //        }

        //        string ordernumber = string.Empty;

        //        int row = 2;
        //        foreach (var order in data)
        //        {
        //            int col = 1;

        //            worksheet.Cells[row, col].Value = order.PickListNo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.MRNo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ProductType;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.OEMName;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ModelName;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.CategoryName;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ProductNo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.ProductDesc;
        //            col++;

        //            worksheet.Cells[row, col].Value = "1";
        //            col++;
        //            worksheet.Cells[row, col].Value = order.BinName;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.SerialNo;
        //            col++;

        //            worksheet.Cells[row, col].Value = order.CTDIRONo;
        //            col++;

        //            row++;
        //        }

        //        worksheet.View.FreezePanes(2, 1);

        //        worksheet.Cells[string.Format("A1:AF{0}", row - 1)].AutoFitColumns();

        //        xlPackage.Workbook.Properties.Title = string.Format("{0} Picklist", "CTDI");
        //        xlPackage.Workbook.Properties.Author = _companyName;
        //        xlPackage.Workbook.Properties.Subject = string.Format("{0} Picklist", "CTDI");
        //        xlPackage.Workbook.Properties.Keywords = string.Format("{0} Picklist", "CTDI");
        //        xlPackage.Workbook.Properties.Category = "Picklist Report";
        //        xlPackage.Workbook.Properties.Comments = string.Format("{0} Picklist", "CTDI");
        //        xlPackage.Workbook.Properties.Company = "CTDI";
        //        //xlPackage.Save();
        //        if (File.Exists(p_strPath))
        //            File.Delete(p_strPath);

        //        using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
        //        {
        //            xlPackage.SaveAs(fs);
        //        }
        //    }
        //}
        public void GetReceivingAllPaymentsReport(Stream stream, List<TransactionDTO> data, string p_strPath)
        {
            if (stream == null)
                throw new ArgumentNullException("stream");

            using (var xlPackage = new ExcelPackage(stream))
            {
                // get handle to the existing worksheet
                string time = DateTime.Now.ToString("yyyyMMddHHmmss");
                string sheetname = "PaymentReport" + time;

                var worksheet = xlPackage.Workbook.Worksheets.Add(sheetname);
                Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml("#E9F2FC");
                //bold summary


                worksheet.Cells["A1:B1"].Merge = true;
                worksheet.Cells[1, 1].Value = "Summary";
                worksheet.Cells[1, 1].Value = "Summary";
                worksheet.Cells[1, 1].Style.Font.Bold = true;
                ExcelBorderLine(worksheet, 1, 1);
                var fillHEADERone = worksheet.Cells[1, 1].Style.Fill;
                fillHEADERone.PatternType = ExcelFillStyle.Solid;
                fillHEADERone.BackgroundColor.SetColor(_colorHEADER);

                //Create Headers and format them
                var properties = ReportsHeader.GetReceiveAllPaymentseHeader();
                for (int i = 0; i < properties.Length; i++)
                {

                    //bold headers
                    worksheet.Cells[6, i + 1].Value = properties[i];
                    worksheet.Cells[6, i + 1].Value = properties[i];
                    worksheet.Cells[6, i + 1].Style.Font.Bold = true;
                    ExcelBorderLine(worksheet, 6, i + 1);

                    //Color _colorHEADER = System.Drawing.ColorTranslator.FromHtml("#E9F2FC");
                    var fillHEADER = worksheet.Cells[6, i + 1].Style.Fill;
                    //var fillHEADER = worksheet.Cells[1, i + 1].Style.Fill;
                    fillHEADER.PatternType = ExcelFillStyle.Solid;
                    fillHEADER.BackgroundColor.SetColor(_colorHEADER);
                }
                string ordernumber = string.Empty;
                int row = 7;
                //int row = 2;
                int inc = 1;
                decimal totalINR = 0m;
                decimal totalUSD = 0m;
                foreach (var order in data)
                {

                    int col = 1;

                    //if (order.IsInvoice == true)
                    //{
                    worksheet.Cells[row, col].Value = inc;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.InvoiceNo;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = "(" + order.TransactionId + ")-(" + order.PaymentId + ")";
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.CustomerName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = "" + order.Email + "" + order.CurrentLocation + "";
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.CourseName;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    string currency = "", installment = "";


                    if (order.Currency == "INR")
                    {
                        currency = "₹";
                        totalINR += Math.Round(order.Total);
                    }
                    else
                    {
                        currency = "$";
                        totalUSD += Math.Round(order.Total);
                    }

                    if (order.IsInstallment == true)
                    {
                        installment = "(I)";
                    }
                    else
                    {
                        installment = "(D)";
                    }
                    worksheet.Cells[row, col].Value = currency + order.Total.ToString("#,0.##") + installment;
                    ExcelBorderLine(worksheet, row, col);
                    col++;

                    worksheet.Cells[row, col].Value = order.CreatedDate + "/" + order.UpdatedDate;
                    ExcelBorderLine(worksheet, row, col);
                    col++;
                    //worksheet.Cells[row, col].Value = order.CurrentLocation;
                    //ExcelBorderLine(worksheet, row, col);
                    //col++;

                    row++;
                    inc++;
                    //}
                }
                decimal NetPrice = 0m;
                if (totalINR > 0)
                {
                    NetPrice = Math.Round(totalINR / (100 + TaxUtility.TaxValue) * 100, 2);
                }

                worksheet.Cells[2, 1].Value = "Total Amount(INR):- ";
                ExcelBorderLine(worksheet, 2, 1);

                worksheet.Cells[2, 2].Value = NetPrice + " INR";
                ExcelBorderLine(worksheet, 2, 2);

                worksheet.Cells[3, 1].Value = "Total Amount(USD):- ";
                ExcelBorderLine(worksheet, 3, 1);

                worksheet.Cells[3, 2].Value = totalUSD + " USD";
                ExcelBorderLine(worksheet, 3, 2);

                worksheet.Cells[4, 1].Value = "GST:- ";
                ExcelBorderLine(worksheet, 4, 1);

                worksheet.Cells[4, 2].Value = (totalINR - NetPrice) + " INR";
                ExcelBorderLine(worksheet, 4, 2);
                // worksheet.Cells[row, 6].Value = "₹ " + totalAmt;
                //ExcelBorderLine(worksheet, row, 6);

                //worksheet.View.FreezePanes(5, 2);

                //worksheet.Cells[string.Format("A1:AH{0}", row - 1)].AutoFitColumns();

                xlPackage.Workbook.Properties.Title = string.Format("{0} PaymentReport", "Dotnettricks");
                xlPackage.Workbook.Properties.Author = _companyName;
                xlPackage.Workbook.Properties.Subject = string.Format("{0} PaymentReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Keywords = string.Format("{0} PaymentExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Category = "Payment Report Excel";
                xlPackage.Workbook.Properties.Comments = string.Format("{0} PaymentReportExcel", "Dotnettricks");
                xlPackage.Workbook.Properties.Company = "Dotnettricks";
                //xlPackage.Workbook.Properties.HyperlinkBase = new Uri("http:www.ctdi.com");
                //xlPackage.Save();
                if (File.Exists(p_strPath))
                    File.Delete(p_strPath);

                using (FileStream fs = new FileStream(p_strPath, FileMode.Create))
                {
                    xlPackage.SaveAs(fs);
                }

            }
        }
    }
}
