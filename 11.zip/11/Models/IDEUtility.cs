﻿using System.Configuration;

namespace DNTWebUI.Models
{
    public static class IDEUtility
    {
        public static string CSharpApi
        {
            get { return ConfigurationManager.AppSettings.Get("csharpApi"); }
        }
        public static string PythonApi
        {
            get { return ConfigurationManager.AppSettings.Get("pythonApi"); }
        }
        public static string JavaScriptApi
        {
            get { return ConfigurationManager.AppSettings.Get("javascriptApi"); }
        }
    }
}