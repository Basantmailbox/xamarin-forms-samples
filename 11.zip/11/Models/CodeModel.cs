﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNTWebUI.Models
{
    public class CodeModel
    {
        public string file { get; set; }
        public string code { get; set; }
        public string language { get; set; }
    }
}