﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNTWebUI.Models.Security
{
    public static class DateTimeZoneExtension
    {
        public static string ToClientTime1(this DateTime dt, string timeOffSet, int addHours)
        {
            // read the value from session

            TimeZoneInfo zone = TimeZoneInfo.FindSystemTimeZoneById(timeOffSet);

            if (timeOffSet != null)
            {
                var k = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dt, TimeZoneInfo.Utc.Id, timeOffSet);

                //bool isDayLight = zone.IsDaylightSavingTime(k);

                //if (isDayLight)
                //    k = k.AddHours(1);

                if (timeOffSet == "Eastern Standard Time" || timeOffSet == "Central Standard Time")
                {
                    k = k.AddHours(addHours);
                }
                else //if (timeOffSet != "India Standard Time")
                {
                    k = k.AddHours(addHours);
                }

                return k.ToString();
            }

            // if there is no offset in session return the datetime in server timezone
            return dt.ToLocalTime().ToString();
        }

        public static DateTime ToClientTimeDate1(this DateTime dt, string timeOffSet, int addHours)
        {
            // read the value from session
            //     var timeOffSet = HttpContext.Current.Session["timezoneoffset"];
            try

            {
                TimeZoneInfo zone = TimeZoneInfo.FindSystemTimeZoneById(timeOffSet);

                if (timeOffSet != null)
                {
                    var k = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dt, TimeZoneInfo.Utc.Id, timeOffSet);
                    //bool isDayLight = zone.IsDaylightSavingTime(k);

                    //if (isDayLight)
                    //    k = k.AddHours(1);


                    if (timeOffSet == "Eastern Standard Time" || timeOffSet == "Central Standard Time")
                    {
                        k = k.AddHours(addHours);
                    }
                    else //if (timeOffSet != "India Standard Time")
                    {
                        k = k.AddHours(addHours);
                    }

                    return k;
                }
            }
            catch (Exception)
            {
                return dt.ToLocalTime();
            }
            // if there is no offset in session return the datetime in server timezone
            return dt.ToLocalTime();
        }


        public static string ToClientTime(this DateTime dt, string timeOffSet)
        {
            // read the value from session


            if (timeOffSet != null)
            {
                var offset = int.Parse(timeOffSet.ToString());
                dt = dt.AddMinutes(-1 * offset);

                return dt.ToString();
            }

            // if there is no offset in session return the datetime in server timezone
            return dt.ToLocalTime().ToString();
        }

        public static DateTime ToClientTimeDate1(this DateTime dt, string timeOffSet, string Id)
        {
            // read the value from session
            //     var timeOffSet = HttpContext.Current.Session["timezoneoffset"];
            try

            {
                var k = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dt, Id);

                //DaylightTime day = zone.GetDaylightChanges(2008);
                //Console.WriteLine(day.Start);
                //Console.WriteLine(day.End);
                //Console.WriteLine(day.Delta);
                if (timeOffSet != null)
                {
                    var offset = int.Parse(timeOffSet.ToString());
                    dt = dt.AddMinutes(-1 * offset);

                    return dt;
                }
            }
            catch (Exception)
            {
                return dt.ToLocalTime();
            }
            // if there is no offset in session return the datetime in server timezone
            return dt.ToLocalTime();
        }
        public static DateTime ToClientTimeDate(this DateTime dt, string timeOffSet)
        {
            // read the value from session
            //     var timeOffSet = HttpContext.Current.Session["timezoneoffset"];
            try

            {
                var zone = TimeZoneInfo.GetSystemTimeZones();

                //DaylightTime day = zone.GetDaylightChanges(2008);
                //Console.WriteLine(day.Start);
                //Console.WriteLine(day.End);
                //Console.WriteLine(day.Delta);
                if (timeOffSet != null)
                {
                    var offset = int.Parse(timeOffSet.ToString());
                    dt = dt.AddMinutes(-1 * offset);

                    return dt;
                }
            }
            catch (Exception)
            {
                return dt.ToLocalTime();
            }
            // if there is no offset in session return the datetime in server timezone
            return dt.ToLocalTime();
        }
    }
}