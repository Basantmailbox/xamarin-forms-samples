﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNTShared.DTO;
using DNTShared.Entities;

namespace DNTWebUI.Models.Security
{
    public class ResultFilterZone : ActionFilterAttribute, IActionFilter, IResultFilter
    {
        void IActionFilter.OnActionExecuted(ActionExecutedContext filterContext)
        {

            var model = (CoursePrice)filterContext.Controller.ViewData.Model;
            if (model != null)
            {
                model.PriceINR = model.PriceINR;
                model.PriceUSD = model.PriceUSD;
                model.DiscountPercentage = model.DiscountPercentage;
                filterContext.Controller.ViewData.Model = model;
            }
            filterContext.Controller.ViewBag.OnActionExecuted = "IActionFilter.OnActionExecuted filter called";
        }

        void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
        {
            filterContext.Controller.ViewBag.OnActionExecuting = "IActionFilter.OnActionExecuting filter called";
        }

        void IResultFilter.OnResultExecuted(ResultExecutedContext filterContext)
        {
            filterContext.Controller.ViewBag.OnResultExecuted = "IResultFilter.OnResultExecuted filter called";
        }

        void IResultFilter.OnResultExecuting(ResultExecutingContext filterContext)
        {
            filterContext.Controller.ViewBag.OnResultExecuting = "IResultFilter.OnResultExecuting filter called";
        }        
    }
}