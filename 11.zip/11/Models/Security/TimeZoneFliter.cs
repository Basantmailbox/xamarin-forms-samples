﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace DNTWebUI.Models.Security
{
    public class TimeZoneFliter : ActionFilterAttribute, IActionFilter
    {       
        void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
        {


            base.OnActionExecuting(filterContext);

            if(IsCrawlByBot())
            {
                HttpContext.Current.Session["timezoneoffset"] = "-330";
                HttpContext.Current.Session["currency"] = "INR";

            }
           if(filterContext.ActionDescriptor.ActionName== "Init" && filterContext.ActionDescriptor.ControllerDescriptor.ControllerName=="Home")
            {
                return;
            }
          //if (HttpContext.Current.Session["timezoneoffset"] == null || HttpContext.Current.Session["currency"]==null)
             if (HttpContext.Current.Request.Cookies.AllKeys.Contains("timezoneoffset"))
            {

                    HttpContext.Current.Session["timezoneoffset"] = HttpContext.Current.Request.Cookies["timezoneoffset"].Value;
                var defaultzone = HttpContext.Current.Session["timezoneoffset"].ToString() != null ? HttpContext.Current.Session["timezoneoffset"].ToString() : "-330";
                double minutes2 = Convert.ToDouble(defaultzone);

                IEnumerable<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                var zone = zones.Where(p => p.BaseUtcOffset.TotalMinutes == minutes2 * -1).FirstOrDefault();
                var timeOffSet = zone.Id;
                if (timeOffSet == "India Standard Time")
                {
                    RegionInfo ri = new RegionInfo("en-IN");
                    var currency = ri.ISOCurrencySymbol;
                    HttpContext.Current.Session["currency"] = currency;
                }
                else
                {
                    RegionInfo ri = new RegionInfo("en-US");
                    var currency = ri.ISOCurrencySymbol;
                    HttpContext.Current.Session["currency"] = currency;

                }
            }
            else
            {

                    HttpContext.Current.Session["timezoneoffset"] = "-330";
                    HttpContext.Current.Session["currency"] = "INR";
                    //var hostname = HttpContext.Current.Request.Url.Scheme+"://"+HttpContext.Current.Request.Url.Authority;

                    //var url = filterContext.HttpContext.Request.RawUrl;
                    //HttpContext.Current.Session["RequestUrl"] = url;
                    ////filterContext.Result = new RedirectResult(hostname + "/home/Init");
                    //filterContext.Result = new RedirectResult(hostname + url);
                }
      
         //   base.OnActionExecuting(filterContext);          
        }


        public  bool IsCrawlByBot()
        {
            List<string> Crawlers = new List<string>()
        {
            "googlebot","bingbot","yandexbot","ahrefsbot","msnbot","linkedinbot","exabot","compspybot",
            "yesupbot","paperlibot","tweetmemebot","semrushbot","gigabot","voilabot","adsbot-google",
            "botlink","alkalinebot","araybot","undrip bot","borg-bot","boxseabot","yodaobot","admedia bot",
            "ezooms.bot","confuzzledbot","coolbot","internet cruiser robot","yolinkbot","diibot","musobot",
            "dragonbot","elfinbot","wikiobot","twitterbot","contextad bot","hambot","iajabot","news bot",
            "irobot","socialradarbot","ko_yappo_robot","skimbot","psbot","rixbot","seznambot","careerbot",
            "simbot","solbot","mail.ru_bot","spiderbot","blekkobot","bitlybot","techbot","void-bot",
            "vwbot_k","diffbot","friendfeedbot","archive.org_bot","woriobot","crystalsemanticsbot","wepbot",
            "spbot","tweetedtimes bot","mj12bot","who.is bot","psbot","robot","jbot","bbot","bot","slurp","DuckDuckBot" ,
            "facebot","facebookexternalhit/1.0","facebookexternalhit/1.1","ia_archiver","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
        };
            if(HttpContext.Current.Request.Browser.IsMobileDevice)
            {
                return false;

            }

            if (HttpContext.Current.Request.UserAgent.Contains("Edge") )
            {
                return false;
                // Allow
            }

            if (HttpContext.Current.Request.UserAgent.Contains("Chrome"))
            {
                return false;
                // Allow
            }


            if (HttpContext.Current.Request.UserAgent.Contains("AppleWebKit"))
            {
                return false;
                // Allow
            }
            if (HttpContext.Current.Request.UserAgent.Contains("Mozilla"))
            {
                return false;
                // Allow
            }

            string WebBrowserName = string.Empty;
            WebBrowserName = HttpContext.Current.Request.Browser.Browser;
            if (WebBrowserName==string.Empty)
            {
                return false;

            }
            return true;
            //var br="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299";
            //if(br.ToLower() == HttpContext.Current.Request.UserAgent.ToLower())
            //{ return false; }
            //else { return true; }
            //string ua = HttpContext.Current.Request.UserAgent.ToLower();
            //bool iscrawler = Crawlers.Exists(x => ua.Contains(x));
            //return iscrawler;
        }

    }
}