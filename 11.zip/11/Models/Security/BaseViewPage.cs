﻿using DotNetTricks.COM.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DotNetTricks.COM.Models.Security
{
    public abstract class BaseViewPage : WebViewPage
    {
        public CustomPrincipal CurrentUser
        {
            get
            {
                return HttpContext.Current.User as CustomPrincipal;
            }
        }
    }
    public abstract class BaseViewPage<T> : WebViewPage<T>
    {
        public CustomPrincipal CurrentUser
        {
            get
            {
                return HttpContext.Current.User as CustomPrincipal;
            }
        }
        // public string UserImage
        //{
        //    get
        //    {
        //        var email = CurrentUser.Email;
        //        MemberViewModel model = commRepository.GetUserProfileDisplay(email);
        //        if (model != null)
        //        {
        //            return model.ProfilePic;
        //        }
        //        else
        //        {
        //            return null;
        //        }
        //    }
        //}
       
    }

}