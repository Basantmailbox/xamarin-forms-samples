﻿using System;

namespace WBP.Shared
{
    public class Class1
    {
    }
}
