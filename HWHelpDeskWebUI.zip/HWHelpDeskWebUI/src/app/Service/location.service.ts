import { Injectable } from '@angular/core';
import { AppSetting } from '../Security/AppSetting';
import { HttpClient } from '@angular/common/http';
import { DropDown } from '../Modals/dropdown';

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  AppURL: string = AppSetting.API_URL + "api";
  appHeader: any = AppSetting.HTTTP_OPTION;
  url:string;
  constructor(private http:HttpClient) { }

  GetLocation(){
    this.url=this.AppURL+'/Location/GetLocation';
    return this.http.get<DropDown[]>(this.url);
  }
}
