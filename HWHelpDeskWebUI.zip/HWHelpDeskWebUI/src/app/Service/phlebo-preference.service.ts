import { Injectable } from '@angular/core';
import { AppSetting } from '../Security/AppSetting';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DropDown } from '../Modals/dropdown';

@Injectable({
  providedIn: 'root'
})
export class PhleboPreferenceService {
  appURL: string = AppSetting.API_URL + "api";
  appHeader: any=AppSetting.HTTTP_OPTION;
  url:string;
  constructor(private http:HttpClient) { }

  GetPhleboPrefrence():Observable<DropDown[]>{
    this.url=this.appURL+'/District/getPhleboPreference';
    return this.http.get<DropDown[]>(this.url);
  }
}
