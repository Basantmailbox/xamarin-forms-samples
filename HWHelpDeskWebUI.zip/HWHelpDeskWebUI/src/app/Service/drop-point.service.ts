import { Injectable } from '@angular/core';
import { AppSetting } from '../Security/AppSetting';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DropDown } from '../Modals/dropdown';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class DropPointService {
  appURL: string = AppSetting.API_URL + "api";
  appHeader: any = AppSetting.HTTTP_OPTION;
  url:string;
  constructor(private http:HttpClient) { }

  GetDropPoint():Observable<DropDown[]>
  {
    this.url=this.appURL+'/DropPoint/getDropPoint';
    return this.http.get<DropDown[]>(this.url);
  }
}
