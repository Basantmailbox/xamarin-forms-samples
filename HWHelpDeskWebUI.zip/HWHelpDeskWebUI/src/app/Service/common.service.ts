import { Injectable } from '@angular/core';
import { AppSetting } from '../Security/AppSetting';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  appURL: string = AppSetting.API_URL + "api";
  appHeader: any = AppSetting.HTTTP_OPTION;
  url: string;
  constructor(private http: HttpClient) { }

  GetValidatePinCode(userID: number, pincode: string) {
    this.url = this.appURL + "/pincode/validate/?userID="+userID+"&pincode="+pincode;
    return this.http.get<any>(this.url);
  }

  GetGeoAddress(searchStr:string, pinCode:string, cityName:string, type:number)
  {
    this.url = this.appURL + "/pincode/validate";
    return this.http.get<any>(this.url);
  }
}
