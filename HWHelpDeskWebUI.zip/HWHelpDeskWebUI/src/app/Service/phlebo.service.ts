import { Injectable } from '@angular/core';
import { AppSetting } from '../Security/AppSetting';
import { Observable } from 'rxjs';
import { phlebo } from '../Modals/phlebo';
import { HttpClient } from '@angular/common/http';
import { DropDown } from '../Modals/dropdown';

@Injectable({
  providedIn: 'root'
})
export class PhleboService {

  AppURL: string = AppSetting.API_URL + "api";
  appHeader: any = AppSetting.HTTTP_OPTION;
  url: string;
  constructor(private http: HttpClient) { }

  GetPhleboList(phlebo: number, isActive: number, dropPointID: number, phleboType: number, helpDeskID: number, districtID: number): Observable<phlebo[]> {
    debugger;
    this.url = this.AppURL + '/phlebo/GetPhleboList/?phleboID=' + phlebo + '&isActive=' + isActive + '&dropPointID=' + dropPointID + '&phleboType=' + phleboType + '&helpDeskID=' + helpDeskID + '&districtID=' + districtID;
    return this.http.get<phlebo[]>(this.url);
  }

  GetPhleboTrainer(): Observable<DropDown[]> {
    debugger;
    this.url = this.AppURL + '/phlebo/GetPhleboTrainer';
    return this.http.get<DropDown[]>(this.url);
  }
  InsertPhlebo(phleboData: phlebo): Observable<any> {
    debugger;
    this.url = this.AppURL + '/phlebo/Insert';
    return this.http.post<any>(this.url, phleboData, this.appHeader);
  }

}
