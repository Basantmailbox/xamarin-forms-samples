import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { LoggedUserService } from 'src/app/Service/logged-user.service';
import { district } from 'src/app/Modals/district';
import { DistrictService } from 'src/app/Service/district.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { NgxSpinnerService } from 'ngx-spinner';
import { CircleService } from 'src/app/Service/circle.service';
import { DropDown } from 'src/app/Modals/dropdown';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-district',
  templateUrl: './view-district.component.html',
  styleUrls: ['./view-district.component.scss']
})
export class ViewDistrictComponent implements OnInit {
  displayedColumns: string[] = ['SNo.', 'city_name', 'defaultRoute', 'CircleName', 'IsActive'];
  dataSource = new MatTableDataSource<district>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  result: string = '';
  districtListObjs: district[];
  districtObj: DropDown[];
  circleObjs: DropDown[];
  loggedUser: any;
  constructor(
    private toastr: ToastrService,
    private _circle: CircleService,
    private _loggedUserService: LoggedUserService,
    private _district: DistrictService,
    private SpinnerService: NgxSpinnerService,
    private _router:Router
  ) { }

  ngOnInit() {
    this.validateUser();
    this.loggedUser = {
      userId: this._loggedUserService.getUserId()
    }
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    if (this.loggedUser.userId > 0) {
      this.SpinnerService.show();
      this.loadDistrictList(0, 0);
      this.loadCircle();
      this.loadDistrict();
      this.SpinnerService.hide();
    }
  }
  validateUser() {
    if (this._loggedUserService.getUserId() == null) {
      //redirection to login for error
      this._router.navigate(["/"]);
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  loadDistrictList(circleID: number, districtID: number) {
    this._district.GetAllDistrict(circleID,districtID)
      .subscribe(respons => {
        this.districtListObjs = respons;
        this.dataSource.data = this.districtListObjs;
      },
        error => {
          console.log("Error (GetData) :: " + error);
        }
      );
  }
  errorMessage(msg: string) {
    this.toastr.error(msg, "District");
  }

  loadCircle() {
    this._circle.GetCircle().subscribe(
      Response => {
        this.circleObjs = Response;
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }

  loadDistrict() {
    this._district.GetActiveDistrict().subscribe(
      response => {
        this.districtObj = response;
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }

  filterData() {
    this.loadDistrictList(0, 0);
  }
}
