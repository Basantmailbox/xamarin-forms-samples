import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { PhleboService } from 'src/app/Service/phlebo.service';
import { LocationService } from 'src/app/Service/location.service';
import { PhleboPreferenceService } from 'src/app/Service/phlebo-preference.service';
import { HelpDeskService } from 'src/app/Service/help-desk.service';
import { ToastrService } from 'ngx-toastr';
import { DropPointService } from 'src/app/Service/drop-point.service';
import { HttpClient } from '@angular/common/http';
import { DropDown } from 'src/app/Modals/dropdown';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/app/Service/common.service';
import { LoggedUserService } from 'src/app/Service/logged-user.service';
import { MatAutocompleteSelectedEvent } from '@angular/material';

@Component({
  selector: 'app-add-phlebo',
  templateUrl: './add-phlebo.component.html',
  styleUrls: ['./add-phlebo.component.scss']
})
export class AddPhleboRouteComponent implements OnInit {
  dropPointObjs: DropDown[];
  helpDeskObjs: DropDown[];
  phleboPrefrence1Objs: DropDown[];
  phleboPrefrence2Objs: DropDown[];
  phleboPrefrence3Objs: DropDown[];
  locationObjs: DropDown[];
  trainerObjs: DropDown[];
  AddPhleboForm: FormGroup;
  fileData: File = null;
  previewUrl: any = null;
  imageUrl: any = null;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;
  userID: number;
  constructor(private formBuilder: FormBuilder,
    private http: HttpClient,
    private _dropPoint: DropPointService,
    private _toaster: ToastrService,
    private _helpdesk: HelpDeskService,
    private _phleboPreference: PhleboPreferenceService,
    private _location: LocationService,
    private _phlebo: PhleboService,
    private SpinnerService: NgxSpinnerService,
    private _common: CommonService,
    private _loggeduser: LoggedUserService
  ) { }

  ngOnInit() {
    this.loadDropPoint();
    this.loadHelpDesk();
    this.loadPhleboPreference();
    this.loadLocation();
    this.loadTrainer();
    this.AddPhleboForm = this.formBuilder.group({
      empid: [0],
      employeetype: ['', [Validators.required]],
      employeeid: ['', [Validators.required]],
      phleboname: ['', [Validators.required]],
      doj: ['', [Validators.required]],
      dob: ['', [Validators.required]],
      droppointid: ['', [Validators.required]],
      helpdeskid: [''],
      prefrence1: ['', [Validators.required]],
      prefrence2: ['', [Validators.required]],
      prefrence3: ['', [Validators.required]],
      trainerID: ['', [Validators.required]],
      clino: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      mobile: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      pincode: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      address: ['', [Validators.required]],
      geoaddress: ['', [Validators.required]],
      locationID: ['', [Validators.required]],
      homeVerification: ['', [Validators.required]],
      designationid: ['']
    });
  }
  // Load Drop Point Function
  loadDropPoint() {
    debugger;
    this._dropPoint.GetDropPoint().subscribe(
      response => {
        debugger;
        this.dropPointObjs = response;
        console.log(this.dropPointObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //----END----//

  //Load Help Desk Function
  loadHelpDesk() {
    this._helpdesk.GetHelpDesk().subscribe(
      response => {
        this.helpDeskObjs = response;
        console.log(this.helpDeskObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //---END----

  //Load Phlebo Prefrence
  loadPhleboPreference() {
    this._phleboPreference.GetPhleboPrefrence().subscribe(
      response => {
        this.phleboPrefrence1Objs = response;
        this.phleboPrefrence2Objs = response;
        this.phleboPrefrence3Objs = response;
        console.log(this.phleboPrefrence1Objs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //----END----

  //Load Location
  loadLocation() {
    this._location.GetLocation().subscribe(
      response => {
        this.locationObjs = response;
      },
      error => {
        this.errorMessage(error.msg);
      }

    );
  }

  //----END----//
  //Load Trainer 
  loadTrainer() {
    this._phlebo.GetPhleboTrainer().subscribe(
      response => {
        this.trainerObjs = response;
        console.log(this.trainerObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }

    );
  }

  //----END----//

  //Error Message Function
  errorMessage(msg: string) {
    this._toaster.error(msg, 'Add Phlebo');
  }
  //----END----//

  onKeydownPincode(event: any) {
    var pinCode = event.target.value;
    if (pinCode.length == 6) {
      this.SpinnerService.show();
      if (parseInt(pinCode)) {
        this._common.GetValidatePinCode(Number(this._loggeduser.getUserId()), pinCode).subscribe(res => {
          res;
          // if (this.cityStateObjs != null) {
          //this.AddPhleboForm.controls['cityName'].setValue(this.cityStateObjs.cityName);
          //this.AddPhleboForm.controls['cityId'].setValue(this.cityStateObjs.cityId);
          //this.AddPhleboForm.controls['stateName'].setValue(this.cityStateObjs.stateName);
        });
        this.SpinnerService.hide();
      }
    }
  }

  onChangeGeoAddress(event: any) {
    var searchGeostr = event.target.value;
    if (searchGeostr.length > 2) {
      // if (this.cityStateObjs != null) {
      //   var cityName = this.AddPhleboForm.controls['cityName'].value;
      //   var pinCode = this.AddPhleboForm.controls['pincode'].value;
      //   if (cityName.length > 3 && pinCode.length == 6) {
      //     this._common.GetGeoAddress(searchGeostr, pinCode, cityName, 530)
      //       .subscribe(data => {
      //         //this.geoAddressFiltered = data;
      //       })
      //   }
      //   else {
      //     this._toaster.warning("something wrong. Please try again");
      //   }
      // }
      // else {
      //   this._toaster.warning("Please enter valid Pincode.");

      //   //this.geoAddressSelected.geoPlaceName = '';
      //   // this.geoAddressSelected.geoPlaceId = '';

      //   this.AddPhleboForm.controls['geoLatitude'].setValue('');
      //   //this.insertOrUpdateObj.geoLatitude = '';

      //   this.AddPhleboForm.controls['geoLongitude'].setValue('');
      //   //this.insertOrUpdateObj.geoLongitude = '';

      // }
    }
    else {

    }
  }

  onSelectionChanged(event: MatAutocompleteSelectedEvent) {
    // this.geoAddressSelected = this.geoAddressFiltered.find(prev => prev.geoPlaceId = event.option.value);
    // this.AddPhleboForm.controls['geoAddress'].setValue(this.geoAddressSelected.geoPlaceName);
    // if (this.loggedUser.userId > 0) {
    //   this._commonService.GetLatLongByPlaceId(this.loggedUser.userId, this.geoAddressSelected.geoPlaceId)
    //     .subscribe(respons => {
    //       if (respons != null) {
    //         this.AddPhleboForm.controls['geoLatitude'].setValue(respons.lat);
    //         //this.insertOrUpdateObj.geoLatitude = respons.lat;

    //         this.AddPhleboForm.controls['geoLongitude'].setValue(respons.lng);
    //         //this.insertOrUpdateObj.geoLongitude = respons.lng;
    //       }
    //     },
    //       error => {
    //         console.log("Error (GetData) :: " + error)
    //         this._toaster.error(error.statusText);
    //         this.AddPhleboForm.controls['geoLatitude'].setValue('');
    //         //this.insertOrUpdateObj.geoLatitude = '';

    //         this.AddPhleboForm.controls['geoLongitude'].setValue('');
    //         //this.insertOrUpdateObj.geoLongitude = '';

    //         this.AddPhleboForm.controls['geoAddress'].setValue('');
    //       }
    //     );


    //   console.log(event.option.value);
    // }
    // else {
    //   this.toastr.warning("somthing wrong, Try again.");
    // }
  }

  onAddPhlebo() {
    debugger;
    if (this.AddPhleboForm.invalid) {
      return;
    }
    else {
      //this.InsertOrUpdateEntity(this.AddPhleboForm.value);
      var data = this.AddPhleboForm.value;
      const phleboData = {
        phleboid: 0,
        phleboimage: '',
        employeetype: data.employeetype,
        employeetypename: '',
        employeeid: data.employeeid,
        phleboname: data.phleboname,
        doj: data.doj,
        dob: data.dob,
        droppointid: data.droppointid,
        droppointname: '',
        helpdeskid: data.defaultRoute,
        helpdeskname: '',
        prefrenceid1: data.prefrence1,
        prefrence1name: '',
        prefrenceid2: data.prefrence2,
        prefrence2name: '',
        prefrenceid3: data.prefrence2,
        prefrence3name: '',
        trainerid: data.trainerID,
        trainername: '',
        clino: data.clino,
        mobile: data.mobile,
        pincode: data.pincode,
        address: data.address,
        geoaddress: data.geoaddress,
        designationid: data.designationid,
        locationid: data.locationID,
        homeverification: data.homeVerification,
        homeverificationdate: '',
        document1: '',
        document2: '',
        document3: '',
        document4: '',
        document5: '',
        document6: ''

      }
      console.log(phleboData);
      this._phlebo.InsertPhlebo(phleboData).subscribe(
        respons => {
          this._toaster.success('Saved Successfully');
        },
        error => {
          console.log("Error (GetData) :: " + error)
          this._toaster.error(error.statusText);
        }
      );
    }
  }
}
