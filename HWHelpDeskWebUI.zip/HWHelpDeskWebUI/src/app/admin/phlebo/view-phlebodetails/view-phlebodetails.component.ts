import { Component, OnInit } from '@angular/core';
import { MatAutocompleteSelectedEvent } from '@angular/material';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { LoggedUserService } from 'src/app/Service/logged-user.service';
import { CommonService } from 'src/app/Service/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { LocationService } from 'src/app/Service/location.service';
import { PhleboService } from 'src/app/Service/phlebo.service';
import { PhleboPreferenceService } from 'src/app/Service/phlebo-preference.service';
import { HelpDeskService } from 'src/app/Service/help-desk.service';
import { ToastrService } from 'ngx-toastr';
import { DropPointService } from 'src/app/Service/drop-point.service';
import { HttpClient } from '@angular/common/http';
import { DropDown } from 'src/app/Modals/dropdown';
import { ActivatedRoute } from '@angular/router';
import { phlebo } from 'src/app/Modals/phlebo';

@Component({
  selector: 'app-view-phlebodetails',
  templateUrl: './view-phlebodetails.component.html',
  styleUrls: ['./view-phlebodetails.component.scss']
})
export class ViewPhlebodetailsComponent implements OnInit {
  dropPointObjs: DropDown[];
  helpDeskObjs: DropDown[];
  phleboPrefrence1Objs: DropDown[];
  phleboPrefrence2Objs: DropDown[];
  phleboPrefrence3Objs: DropDown[];
  locationObjs: DropDown[];
  trainerObjs: DropDown[];
  phleboListObj: phlebo;
  AddPhleboForm: FormGroup;
  fileData: File = null;
  previewUrl: any = null;
  imageUrl: any = null;
  phleboID: number;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;
  userID: number;
  constructor(private formBuilder: FormBuilder,
    private http: HttpClient,
    private _dropPoint: DropPointService,
    private _toaster: ToastrService,
    private _helpdesk: HelpDeskService,
    private _phleboPreference: PhleboPreferenceService,
    private _location: LocationService,
    private _phlebo: PhleboService,
    private SpinnerService: NgxSpinnerService,
    private _common: CommonService,
    private _loggeduser: LoggedUserService,
    private _activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.loadDropPoint();
    this.loadHelpDesk();
    this.loadPhleboPreference();
    this.loadLocation();
    this.loadTrainer();
    this.AddPhleboForm = this.formBuilder.group({
      empid: [0],
      employeetype: ['', [Validators.required]],
      employeeid: ['', [Validators.required]],
      phleboname: ['', [Validators.required]],
      doj: ['', [Validators.required]],
      dob: ['', [Validators.required]],
      droppointid: ['', [Validators.required]],
      helpdeskid: [''],
      prefrence1: ['', [Validators.required]],
      prefrence2: ['', [Validators.required]],
      prefrence3: ['', [Validators.required]],
      trainerID: ['', [Validators.required]],
      clino: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      mobile: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      pincode: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      address: ['', [Validators.required]],
      geoaddress: ['', [Validators.required]],
      locationID: ['', [Validators.required]],
      homeVerification: ['', [Validators.required]],
      designationid: ['']
    });
    this.phleboID = Number(this._activatedRoute.snapshot.queryParamMap.get('ID'));
    this.loadPhleboDetails(this.phleboID);
  }

  loadPhleboDetails(phleboID: number) {
    debugger;
    this._phlebo.GetPhleboList(phleboID, 0, 0, 0, 0, 0).subscribe(
      response => {
        var data = response;
        if(data.length>0)
        {
        this.phleboListObj=data[0];
        console.log(this.phleboListObj);

        this.AddPhleboForm.controls['empid'].setValue(this.phleboListObj.phleboid);
        this.AddPhleboForm.controls['employeetype'].setValue(this.phleboListObj.employeetype);
        this.AddPhleboForm.controls['employeeid'].setValue(this.phleboListObj.employeeid);
        this.AddPhleboForm.controls['phleboname'].setValue(this.phleboListObj.phleboname);
        this.AddPhleboForm.controls['doj'].setValue(this.phleboListObj.doj);
        this.AddPhleboForm.controls['dob'].setValue(this.phleboListObj.dob);
        this.AddPhleboForm.controls['droppointid'].setValue(this.phleboListObj.droppointid);
        this.AddPhleboForm.controls['helpdeskid'].setValue(this.phleboListObj.helpdeskid);
        this.AddPhleboForm.controls['prefrence1'].setValue(this.phleboListObj.prefrenceid1);
        this.AddPhleboForm.controls['prefrence2'].setValue(this.phleboListObj.prefrenceid2);
        this.AddPhleboForm.controls['prefrence3'].setValue(this.phleboListObj.prefrenceid3);
        this.AddPhleboForm.controls['trainerID'].setValue(this.phleboListObj.trainerid);
        this.AddPhleboForm.controls['clino'].setValue(this.phleboListObj.clino);
        this.AddPhleboForm.controls['mobile'].setValue(this.phleboListObj.mobile);
        this.AddPhleboForm.controls['pincode'].setValue(this.phleboListObj.pincode);
        this.AddPhleboForm.controls['address'].setValue(this.phleboListObj.address);
        this.AddPhleboForm.controls['geoaddress'].setValue(this.phleboListObj.geoaddress);
        this.AddPhleboForm.controls['designationid'].setValue(this.phleboListObj.designationid);
        this.AddPhleboForm.controls['locationID'].setValue(this.phleboListObj.locationid);
        this.AddPhleboForm.controls['homeVerification'].setValue(this.phleboListObj.homeverification);
        }
        this.SpinnerService.hide();
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }


  // Load Drop Point Function
  loadDropPoint() {
    debugger;
    this._dropPoint.GetDropPoint().subscribe(
      response => {
        debugger;
        this.dropPointObjs = response;
        console.log(this.dropPointObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //----END----//

  //Load Help Desk Function
  loadHelpDesk() {
    this._helpdesk.GetHelpDesk().subscribe(
      response => {
        this.helpDeskObjs = response;
        console.log(this.helpDeskObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //---END----

  //Load Phlebo Prefrence
  loadPhleboPreference() {
    this._phleboPreference.GetPhleboPrefrence().subscribe(
      response => {
        this.phleboPrefrence1Objs = response;
        this.phleboPrefrence2Objs = response;
        this.phleboPrefrence3Objs = response;
        console.log(this.phleboPrefrence1Objs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //----END----

  //Load Location
  loadLocation() {
    this._location.GetLocation().subscribe(
      response => {
        this.locationObjs = response;
      },
      error => {
        this.errorMessage(error.msg);
      }

    );
  }

  //----END----//
  //Load Trainer 
  loadTrainer() {
    this._phlebo.GetPhleboTrainer().subscribe(
      response => {
        this.trainerObjs = response;
        console.log(this.trainerObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }

    );
  }

  //----END----//

  //Error Message Function
  errorMessage(msg: string) {
    this._toaster.error(msg, 'Add Phlebo');
  }
  //----END----//

  onKeydownPincode(event: any) {
    var pinCode = event.target.value;
    if (pinCode.length == 6) {
      this.SpinnerService.show();
      if (parseInt(pinCode)) {
        this._common.GetValidatePinCode(Number(this._loggeduser.getUserId()), pinCode).subscribe(res => {
          res;
          // if (this.cityStateObjs != null) {
          //this.AddPhleboForm.controls['cityName'].setValue(this.cityStateObjs.cityName);
          //this.AddPhleboForm.controls['cityId'].setValue(this.cityStateObjs.cityId);
          //this.AddPhleboForm.controls['stateName'].setValue(this.cityStateObjs.stateName);
        });
        this.SpinnerService.hide();
      }
    }
  }

  onChangeGeoAddress(event: any) {
    var searchGeostr = event.target.value;
    if (searchGeostr.length > 2) {
     
    }
    else {

    }
  }

  

  onAddPhlebo() {
    debugger;
    if (this.AddPhleboForm.invalid) {
      return;
    }
    else {
      //this.InsertOrUpdateEntity(this.AddPhleboForm.value);
      var data = this.AddPhleboForm.value;
      const phleboData = {
        phleboid: 0,
        phleboimage: '',
        employeetype: data.employeetype,
        employeetypename: '',
        employeeid: data.employeeid,
        phleboname: data.phleboname,
        doj: data.doj,
        dob: data.dob,
        droppointid: data.droppointid,
        droppointname: '',
        helpdeskid: data.defaultRoute,
        helpdeskname: '',
        prefrenceid1: data.prefrence1,
        prefrence1name: '',
        prefrenceid2: data.prefrence2,
        prefrence2name: '',
        prefrenceid3: data.prefrence2,
        prefrence3name: '',
        trainerid: data.trainerID,
        trainername: '',
        clino: data.clino,
        mobile: data.mobile,
        pincode: data.pincode,
        address: data.address,
        geoaddress: data.geoaddress,
        designationid: data.designationid,
        locationid: data.locationID,
        homeverification: data.homeVerification,
        homeverificationdate: '',
        document1: '',
        document2: '',
        document3: '',
        document4: '',
        document5: '',
        document6: ''

      }
      console.log(phleboData);
      this._phlebo.InsertPhlebo(phleboData).subscribe(
        respons => {
          this._toaster.success('Saved Successfully');
        },
        error => {
          console.log("Error (GetData) :: " + error)
          this._toaster.error(error.statusText);
        }
      );
    }
  }
}
