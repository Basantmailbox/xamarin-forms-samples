import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { phlebo } from 'src/app/Modals/phlebo';

@Component({
  selector: 'app-route-report',
  templateUrl: './route-report.component.html',
  styleUrls: ['./route-report.component.scss']
})
export class RouteReportComponent implements OnInit {
  displayedColumns: string[] = ['SNo.', 'district', 'requestedRoute', 'approved', 'onField', 'currentPhlebo', 'ratioRoute'];
  dataSource = new MatTableDataSource<phlebo>();
 // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  //@ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor() { }

  ngOnInit() {
  }

  // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();

  //   if (this.dataSource.paginator) {
  //     this.dataSource.paginator.firstPage();
  //   }
  // }

}
