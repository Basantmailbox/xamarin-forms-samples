import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { RouteRequestDetail, Route } from 'src/app/Modals/routerequest';
import { RouteService } from 'src/app/Service/route.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { RequestDetailComponent } from '../request-detail/request-detail.component';
import { LoggedUserService } from 'src/app/Service/logged-user.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { phlebo } from 'src/app/Modals/phlebo';

@Component({
  selector: 'app-approve-detail',
  templateUrl: './approve-detail.component.html',
  styleUrls: ['./approve-detail.component.scss']
})
export class ApproveDetailComponent implements OnInit {
  requestDetailsObjs: RouteRequestDetail[];
  requestDetailsObj: Route;
  requestRouteObjs: Route[];
  private isButtonVisible = true;
  rrid: number;
  userID: number;
  displayedColumns: string[] = ['SNo.', 'districtName', 'currentRoute', 'requestedRoute', 'approvedRoute', 'viewPhlebo', 'addPhlebo'];
  dataSource = new MatTableDataSource<RouteRequestDetail>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(
    private _route: RouteService,
    private SpinnerService: NgxSpinnerService,
    private toastr: ToastrService,
    private _loggedUserService: LoggedUserService,
    private activatedRoute: ActivatedRoute,
    private _router: Router
  ) {

  }

  ngOnInit() {
    this.userID = Number(this._loggedUserService.getUserId());
    if (this.userID > 0) {
      debugger;
      this.rrid = Number(this.activatedRoute.snapshot.queryParamMap.get('ID'));
      if (this.rrid > 0) {
        this.loadRequestDetails(this.rrid);
        this.isButtonVisible = true;
      }
    }
  }

  loadRequestDetails(rrID: number) {
    //debugger;
    this.SpinnerService.show();
    this._route.GetRecentRouteRequestDetails(rrID).subscribe(
      data => {
        this.requestDetailsObjs = data;
        this.requestDetailsObjs.map((todo, i) => {
          this.requestDetailsObjs[i].isApproved = false;
        })
        this.dataSource.data = this.requestDetailsObjs;
        console.log(this.requestDetailsObjs);
        this.SpinnerService.hide();
      },
      error => {
        this.toastr.error("");
        this.SpinnerService.hide();
      }
    );

  }


  viewPhleboList(entityObjs: RouteRequestDetail) {
    debugger;
    this._router.navigateByUrl('admin/phlebo/viewPhlebo?ID='+entityObjs.DistrictID);
  }

  addPhleboList(entityObjs:phlebo)
  {
    this._router.navigateByUrl('admin/phlebo/addPhlebo');
  }

  ApprovedRequest(name: string) {
    //debugger;
    if (confirm("Are you sure to Approve " + name)) {
      this.userID = Number(this._loggedUserService.getUserId());
      let arr = [];
      for (let i = 0; i < this.requestDetailsObjs.length; i++) {
        if (Number(this.requestDetailsObjs[i].ApprovedRoute) > Number(0)) {
          arr.push(this.requestDetailsObjs[i])
        }
      }
      if (arr.length > 0) {
        this._route.ApproveRouteRequest(arr, this.rrid, this.userID, 1).subscribe(
          respons => {
            this.toastr.success(respons[0].responseMsg);
          },
          error => {
            this.toastr.error(error.msg, "");
          }
        );
      }
      else {
        this.toastr.error("No Data For Approved !!", "");
      }
    }
  }
}
