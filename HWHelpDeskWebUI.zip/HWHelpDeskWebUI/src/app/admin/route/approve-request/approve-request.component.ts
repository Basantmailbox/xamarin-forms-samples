import { Component, OnInit, ViewChild } from '@angular/core';

import { MatSort, MatPaginator, MatTableDataSource } from '@angular/material';

import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { RouteService } from 'src/app/Service/route.service';
import { Route } from 'src/app/Modals/routerequest';

@Component({
  selector: 'app-approve-request',
  templateUrl: './approve-request.component.html',
  styleUrls: ['./approve-request.component.scss']
})
export class ApproveRequestComponent implements OnInit {
  recentRequestObjs: Route[];
  displayedColumns: string[] = ['SNo.', 'requestNo', 'userName', 'requestDate', 'totalRouteRequested', 'requestStatus', 'Action'];
  dataSource = new MatTableDataSource<Route>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(private toastr: ToastrService,
    private SpinnerService: NgxSpinnerService,
    private _route: RouteService
  ) { }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.loadRecentRouteRequest(0);
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  onStatusChangeEvent(ev) {
    if (Number(ev.value) >= Number(0))
      this.loadRecentRouteRequest(ev.value);
  }

  viewRouteRequestDetails(entityObj: Route) {
    debugger;
    //localStorage.setItem('rrID', entityObj.rrID.toString());
    //console.log(localStorage.getItem('rrID'));
    //this._routeURL.navigateByUrl('/route/approvalView');
    window.open('/admin/route/approvalView/?ID=' + entityObj.rrID + '', '_blank');
  }
  loadRecentRouteRequest(status: number) {
    this.SpinnerService.show();
    //debugger;
    this._route.GetRecentRouteRequest(status).subscribe(
      data => {
        this.recentRequestObjs = data;
        this.dataSource.data = this.recentRequestObjs;
        this.SpinnerService.hide();
      },
      error => {
        this.toastr.error("");
        this.SpinnerService.hide();
      }
    );
  }

}
