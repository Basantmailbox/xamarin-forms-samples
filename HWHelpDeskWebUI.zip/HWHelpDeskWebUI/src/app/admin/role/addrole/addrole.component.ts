import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addrole',
  templateUrl: './addrole.component.html',
  styleUrls: ['./addrole.component.scss']
})
export class AddroleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
