import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewrole',
  templateUrl: './viewrole.component.html',
  styleUrls: ['./viewrole.component.scss']
})
export class ViewroleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
