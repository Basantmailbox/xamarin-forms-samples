import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Route } from 'src/app/Modals/routerequest';
import { phlebo } from 'src/app/Modals/phlebo';
import { DropPointService } from 'src/app/Service/drop-point.service';
import { ToastrService } from 'ngx-toastr';
import { DistrictService } from 'src/app/Service/district.service';
import { district } from 'src/app/Modals/district';
import { PhleboService } from 'src/app/Service/phlebo.service';
import { LoggedUserService } from 'src/app/Service/logged-user.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDown } from 'src/app/Modals/dropdown';

@Component({
  selector: 'app-view-phlebo',
  templateUrl: './view-phlebo.component.html',
  styleUrls: ['./view-phlebo.component.scss']
})
export class ViewPhleboComponent implements OnInit {
  dropPointObjs: DropDown[];
  phleboListObjs:phlebo[]
  districtObjs: DropDown[];
  loggedUser: any;
  displayedColumns: string[] = ['SNo.', 'phleboName', 'dropPoint', 'helpDesk', 'prefrence1', 'prefrence2', 'prefrence3', 'Edit', 'Action'];
  dataSource = new MatTableDataSource<phlebo>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(
    private _droppoint: DropPointService,
    private _toaster: ToastrService,
    private _district: DistrictService,
    private _phlebo:PhleboService,
    private _loggedUserService: LoggedUserService,
    private SpinnerService: NgxSpinnerService
  ) { }
  ngOnInit() {
    this.loggedUser = {
      userId: this._loggedUserService.getUserId()
    }

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.loadDistrict();
    this.loadDropPoint();
    this.loadDistrict();
    this.loadPhleboList(0,0,0,0,0,0);
  }
  loadDropPoint() {
    this._droppoint.GetDropPoint().subscribe(
      respons => {
        this.dropPointObjs = respons;
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }

  loadDistrict() {
    this._district.GetActiveDistrict().subscribe(
      response => {
        this.districtObjs = response;
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }

  loadPhleboList(phlebo:number,isActive:number,dropPointID :number,phleboType:number,helpDeskID:number,districtID:number)
  {
    debugger;
    this._phlebo.GetPhleboList(phlebo,isActive,dropPointID,phleboType,helpDeskID,districtID).subscribe(
      response=>{
        this.phleboListObjs=response;
        console.log(this.phleboListObjs);
        this.dataSource.data = this.phleboListObjs;
        this.SpinnerService.hide();
        
      },
      error=>{
        this.errorMessage(error.msg);
      }
    );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  errorMessage(msg) {
    this._toaster.error(msg, 'View Phlebo');
  }
}
