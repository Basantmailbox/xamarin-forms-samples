import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { DropPointService } from 'src/app/Service/drop-point.service';
import { ToastrService } from 'ngx-toastr';
import { HelpDeskService } from 'src/app/Service/help-desk.service';
import { PhleboPreferenceService } from 'src/app/Service/phlebo-preference.service';
import { LocationService } from 'src/app/Service/location.service';
import { PhleboService } from 'src/app/Service/phlebo.service';
import { DropDown } from 'src/app/Modals/dropdown';
import { invalid } from '@angular/compiler/src/render3/view/util';

@Component({
  selector: 'app-add-phlebo',
  templateUrl: './add-phlebo.component.html',
  styleUrls: ['./add-phlebo.component.scss']
})
export class AddPhleboComponent implements OnInit {
  dropPointObjs: DropDown[];
  helpDeskObjs: DropDown[];
  phleboPrefrence1Objs: DropDown[];
  phleboPrefrence2Objs: DropDown[];
  phleboPrefrence3Objs: DropDown[];
  locationObjs: DropDown[];
  trainerObjs: DropDown[];
  AddPhleboForm: FormGroup;
  fileData: File = null;
  previewUrl: any = null;
  imageUrl: any = null;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;
  constructor(private formBuilder: FormBuilder,
    private http: HttpClient,
    private _dropPoint: DropPointService,
    private _toaster: ToastrService,
    private _helpdesk: HelpDeskService,
    private _phleboPreference: PhleboPreferenceService,
    private _location: LocationService,
    private _phlebo: PhleboService
  ) { }

  ngOnInit() {
    this.loadDropPoint();
    this.loadHelpDesk();
    this.loadPhleboPreference();
    this.loadLocation();
    this.loadTrainer();
    this.AddPhleboForm = this.formBuilder.group({
      empid: [0],
      employeetype: ['', [Validators.required]],
      employeeid: ['', [Validators.required]],
      phleboname: ['', [Validators.required]],
      doj: ['', [Validators.required]],
      dob: ['', [Validators.required]],
      droppointid: ['', [Validators.required]],
      helpdeskid: [''],
      prefrence1: ['', [Validators.required]],
      prefrence2: ['', [Validators.required]],
      prefrence3: ['', [Validators.required]],
      trainerID: ['', [Validators.required]],
      clino: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      mobile: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      pincode: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
      address: ['', [Validators.required]],
      geoaddress: ['', [Validators.required]],
      locationID: ['', [Validators.required]],
      homeVerification: ['', [Validators.required]],
      designationid:['']
    });
  }
  // Load Drop Point Function
  loadDropPoint() {
    debugger;
    this._dropPoint.GetDropPoint().subscribe(
      response => {
        debugger;
        this.dropPointObjs = response;
        console.log(this.dropPointObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //----END----//

  //Load Help Desk Function
  loadHelpDesk() {
    this._helpdesk.GetHelpDesk().subscribe(
      response => {
        this.helpDeskObjs = response;
        console.log(this.helpDeskObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //---END----

  //Load Phlebo Prefrence
  loadPhleboPreference() {
    this._phleboPreference.GetPhleboPrefrence().subscribe(
      response => {
        this.phleboPrefrence1Objs = response;
        this.phleboPrefrence2Objs = response;
        this.phleboPrefrence3Objs = response;
        console.log(this.phleboPrefrence1Objs);
      },
      error => {
        this.errorMessage(error.msg);
      }
    );
  }
  //----END----

  //Load Location
  loadLocation() {
    this._location.GetLocation().subscribe(
      response => {
        this.locationObjs = response;
      },
      error => {
        this.errorMessage(error.msg);
      }

    );
  }

  //----END----//
  //Load Trainer 
  loadTrainer() {
    this._phlebo.GetPhleboTrainer().subscribe(
      response => {
        this.trainerObjs = response;
        console.log(this.trainerObjs);
      },
      error => {
        this.errorMessage(error.msg);
      }

    );
  }

  //----END----//

  //Error Message Function
  errorMessage(msg: string) {
    this._toaster.error(msg, 'Add Phlebo');
  }
  //----END----//

  onAddPhlebo() {
    debugger;
    if (this.AddPhleboForm.invalid) {
      return;
    }
    else {
      //this.InsertOrUpdateEntity(this.AddPhleboForm.value);
      var data = this.AddPhleboForm.value;
      const phleboData = {
        phleboid: 0,
        phleboimage:'',
        employeetype: data.employeetype,
        employeetypename:'',
        employeeid: data.employeeid,
        phleboname: data.phleboname,
        doj: data.doj,
        dob: data.dob,
        droppointid: data.droppointid,
        droppointname:'',
        helpdeskid: data.defaultRoute,
        helpdeskname:'',
        prefrenceid1: data.prefrence1,
        prefrence1name: '',
        prefrenceid2: data.prefrence2,
        prefrence2name:'',
        prefrenceid3:data.prefrence2,
        prefrence3name:'',
        trainerid: data.trainerID,
        trainername:'',
        clino: data.clino,
        mobile: data.mobile,
        pincode: data.pincode,
        address: data.address,
        geoaddress: data.geoaddress,
        designationid:data.designationid,
        locationid: data.locationID,
        homeverification:data.homeVerification,
        homeverificationdate:'',
        document1:'',
        document2:'',
        document3:'',
        document4:'',
        document5:'',
        document6:''    
    
      }
      console.log(phleboData);
      this._phlebo.InsertPhlebo(phleboData).subscribe(
          respons => {
            this._toaster.success('Saved Successfully');
          },
          error => {
            console.log("Error (GetData) :: " + error)
            this._toaster.error(error.statusText);
          }
        );
    }

     
  }

  

}
