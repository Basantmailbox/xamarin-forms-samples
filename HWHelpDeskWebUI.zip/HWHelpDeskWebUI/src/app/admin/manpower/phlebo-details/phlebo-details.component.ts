import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phlebo-details',
  templateUrl: './phlebo-details.component.html',
  styleUrls: ['./phlebo-details.component.scss']
})
export class PhleboDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
