import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { pincodeData } from 'src/app/Modals/pincodedata';
import { ToastrService } from 'ngx-toastr';
import { PincodeService } from 'src/app/Service/pincode.service';
import { NgxSpinnerService } from "ngx-spinner";
import { CircleService } from 'src/app/Service/circle.service';
import { DistrictService } from 'src/app/Service/district.service';
import { DropDown } from 'src/app/Modals/dropdown';
import { error } from 'protractor';
@Component({
  selector: 'app-view-pincode',
  templateUrl: './view-pincode.component.html',
  styleUrls: ['./view-pincode.component.scss']
})
export class ViewPincodeComponent implements OnInit {
  pincodeObjs: pincodeData[];
  circleObjs: DropDown[];
  districtObjs: DropDown[];
  displayedColumns: string[] = ['SNo.', 'pincode', 'district', 'state', 'circle', 'status'];
  dataSource = new MatTableDataSource<pincodeData>();
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(private _toastr: ToastrService,
    private _pincode: PincodeService,
    private _spinner: NgxSpinnerService,
    private _circle: CircleService,
    private _district: DistrictService
  ) { }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.loadPincodeList(0, 0);
    this.loadCircle();
    this.loadDistrict();
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  loadPincodeList(circleID: number, districtID: number) {
    this._spinner.show();
    this._pincode.GetPincodeList(circleID, districtID).subscribe(
      data => {
        this.pincodeObjs = data;
        this.dataSource.data = this.pincodeObjs;
        this._spinner.hide();
      },
      error => {
        this._toastr.error(error.msg, "Pincode");
        this._spinner.hide();
      }
    );
  }

  loadCircle() {
    this._spinner.show();
    this._circle.GetCircle().subscribe(
      response => {
        this.circleObjs = response;
        this._spinner.hide();
      },
      error => {
        this._toastr.error(error.msg, "Pincode");
        this._spinner.hide();
      }
    );
  }

  loadDistrict() {
    this._spinner.show();
    this._district.GetActiveDistrict().subscribe(
      response => {
        this.districtObjs = response;
      },
      error => {
        this._toastr.error(error.msg, "Pincode");
        this._spinner.hide();
      }
    );
  }

  filterData()
  {
    
  }
}
