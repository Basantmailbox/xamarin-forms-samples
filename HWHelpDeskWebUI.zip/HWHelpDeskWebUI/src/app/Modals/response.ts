export class ResponseFROMAPI{
    responseMsg:string;
    responseCode:number;
}