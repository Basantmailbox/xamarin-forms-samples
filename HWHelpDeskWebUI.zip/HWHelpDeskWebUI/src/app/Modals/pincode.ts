export class pincode{
pincode:string;
cityName:string;
city_id:number;
isActive:number;
}