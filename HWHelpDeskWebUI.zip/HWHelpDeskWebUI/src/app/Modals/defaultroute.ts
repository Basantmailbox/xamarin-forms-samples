export class DefaultRoute
{
    city_name:string;
    city_id:number;
    defaultRoute:number;
    lastCycleRequestedRoute:number;
    lastCycleApprovedRoute:number;
    requestedRoute:number;
}