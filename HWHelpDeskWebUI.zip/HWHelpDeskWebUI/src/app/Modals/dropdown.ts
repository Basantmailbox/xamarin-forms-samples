export class DropDown{
    id:number;
    value:string;
}