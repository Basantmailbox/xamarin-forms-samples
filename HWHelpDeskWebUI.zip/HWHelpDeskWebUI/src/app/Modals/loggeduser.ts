export  class LoggedUser{
    userId: number;
    fullName: string;
    userName: string;    
    token: string;
    roleId: number;
    roleName: string;
}