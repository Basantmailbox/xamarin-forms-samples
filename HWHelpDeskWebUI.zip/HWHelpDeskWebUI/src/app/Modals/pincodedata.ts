export class pincodeData{
    id:number;
    pincode:number;
    city:string;
    district:string;
    state:string;
    circleName:string
    Status_Info:number;
}

