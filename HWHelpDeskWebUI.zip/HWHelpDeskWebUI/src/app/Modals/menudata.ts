import { UserMenu } from './usermenu';

export class MenuData{
    RoleID:number;
    Menuobj:UserMenu[]
}