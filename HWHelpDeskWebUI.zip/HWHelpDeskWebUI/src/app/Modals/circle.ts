export class circle{
circleID:number;
circleName:string;
isActive:boolean;
}