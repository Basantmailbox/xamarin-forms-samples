export class district {
    city_id: number;
    city_name: string;
    city_s_name: string;
    state_s_id: number;
    IsActive: boolean;
    status_info1: number;
    CircleId: number;
    defaultRoute: number;
}