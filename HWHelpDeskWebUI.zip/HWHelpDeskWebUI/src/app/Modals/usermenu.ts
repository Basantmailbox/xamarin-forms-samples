export class UserMenu{
    MpID: number;
    ModuleID: number;
    PageID:number;
    PageUrl:string;
    ModuleName: string;
    PageName:string;
    IsView:boolean;
    IsEdit:boolean;
    IsenableDisable:boolean;
    isActive:boolean;
    RoleID:number;
}

// export class DisplayMenu{
   
//     ModuleID: number;
//     ModuleName: string;
//     Menuobj:UserMenu[]
// }