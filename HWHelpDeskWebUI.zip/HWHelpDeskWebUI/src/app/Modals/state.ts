export class state{
    s_id:number;
    s_name:string;
    s_country:string;
    circleID: number
}