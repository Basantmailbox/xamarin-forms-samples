export class UserRoles{
    roleID:number;
    roleName:string;
    rolePrefix:string;
    isActive:boolean;
    
}