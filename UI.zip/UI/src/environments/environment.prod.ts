export const environment = {
  production: true,
  apiUrl: 'http://localhost:44327/api'
};
