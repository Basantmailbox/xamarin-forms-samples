import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS,HttpClient } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { LoginComponent } from './login/login.component';
// import { JwtInterceptor } from '../app/_helpers/jwt.interceptor';
// import { ErrorInterceptor } from '../app/_helpers/error.interceptor';
import { SiteLayoutComponent } from './_layout/site-layout/site-layout.component';
import { AuthorisedLayoutComponent } from './_layout/authorised-layout/authorised-layout.component';
import { DashboardComponent } from './member/dashboard/dashboard.component';
import { ProfileComponent } from './member/profile/profile.component';
import { AppFooterComponent } from './_layout/app-footer/app-footer.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutusComponent,
    LoginComponent,
    SiteLayoutComponent,
    AuthorisedLayoutComponent,
    DashboardComponent,
    ProfileComponent,
    AppFooterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
        ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [
    // { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
],
  bootstrap: [AppComponent]
})
export class AppModule { }
