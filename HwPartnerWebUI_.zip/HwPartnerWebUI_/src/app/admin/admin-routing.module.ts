import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { ProfileAdminComponent } from './profile-admin/profile-admin.component';
import { AllPartnersComponent } from './partner/all-partners/all-partners.component';
import { ApprovalPendingComponent } from './partner/approval-pending/approval-pending.component';
import { PromocodesComponent } from './partner/promocodes/promocodes.component';
import { DiscountInventoryComponent } from './partner/discount-inventory/discount-inventory.component';


const routes: Routes = [
  { path: '',  component: DashboardAdminComponent },
  { path: 'dashboard',  component: DashboardAdminComponent },
  { path: 'profile', component: ProfileAdminComponent },
  { path: 'partnes', component: AllPartnersComponent },
  { path: 'partnes/approval-pending', component: ApprovalPendingComponent },
  { path: 'partnes/promos', component: PromocodesComponent },
  { path: 'partnes/discounts', component: DiscountInventoryComponent },
  { path: 'partnes/vOffice', component: DiscountInventoryComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
