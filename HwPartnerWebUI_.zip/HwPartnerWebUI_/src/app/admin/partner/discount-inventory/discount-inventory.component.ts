import { Component, OnInit,ViewChild } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {MatPaginator} from '@angular/material/paginator';
import { DiscountGlobal } from 'src/app/modals/globalDiscount';


@Component({
  selector: 'app-discount-inventory',
  templateUrl: './discount-inventory.component.html',
  styleUrls: ['./discount-inventory.component.scss']
})
export class DiscountInventoryComponent implements OnInit {

  displayedColumns: string[] = ['partnerName', 'partnerType','SetDiscount','ValidtoDate','ValidfromDate'];
  dataSource = new MatTableDataSource<DiscountGlobal>();

  discountGlobal: DiscountGlobal;
  
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  constructor() { }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }
  
}
