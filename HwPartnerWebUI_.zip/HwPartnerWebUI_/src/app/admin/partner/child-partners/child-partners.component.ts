import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PartnerService } from 'src/app/_services/partner.service';
import { Partner } from 'src/app/modals/partner';

@Component({
  selector: 'app-child-partners',
  templateUrl: './child-partners.component.html',
  styleUrls: ['./child-partners.component.scss']
})
export class ChildPartnersComponent implements OnInit {

  partnerObj:Partner;
  partnerObjs: Partner[];
  
  constructor(
    private _partnerService: PartnerService,
    private dialogRef: MatDialogRef<ChildPartnersComponent>,
    @Inject(MAT_DIALOG_DATA) data: Partner) {
      debugger;
    this.partnerObj = data;
    }

  ngOnInit() {
    if (this.partnerObj.partnerId > 0) {
     this.bindChildPartners();
    }
  }

  bindChildPartners() {
    debugger;
   
    this._partnerService.GetMyPartner(this.partnerObj.partnerId.toString())
    .subscribe(respons => {
      this.partnerObjs = respons;
    },
      error => console.log("Error (GetData) :: " + error)
    );
  
  }

  close() {
    this.dialogRef.close(false);
  }


}
