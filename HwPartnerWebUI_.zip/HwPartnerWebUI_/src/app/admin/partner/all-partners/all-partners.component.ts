import { Component, OnInit, ViewChild } from '@angular/core';
import { Partner } from 'src/app/modals/partner';
import { PartnerService } from 'src/app/_services/partner.service';
import { ToastrService } from 'ngx-toastr';
import { RoleType } from 'src/app/shared/enumApp';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ChildPartnersComponent } from '../child-partners/child-partners.component';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';

@Component({
  selector: 'app-all-partners',
  templateUrl: './all-partners.component.html',
  styleUrls: ['./all-partners.component.scss']
})
export class AllPartnersComponent implements OnInit {

  displayedColumns: string[] = ['fullName', 'mobileNo', 'emailId', 'partnerTypeName','status','Action'];
  dataSource = new MatTableDataSource<Partner>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  myPartners: Partner[];

  constructor(
    private dialog: MatDialog,
    private _partnerService: PartnerService,
    private toastr: ToastrService
  ) { }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

      this.loadMyPartner();
  }

  loadMyPartner() {
    debugger;
    this._partnerService.GetMyPartner("530")
      .subscribe(respons => {
        debugger;
        this.myPartners = respons;
        this.dataSource.data = this.myPartners;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  // showChilds(partner: Partner) {
  //   debugger;
  //   if (partner.partnerId > 0) {
  //     const dialogConfig = new MatDialogConfig();
  //     dialogConfig.disableClose = true;
  //     dialogConfig.autoFocus = true;
  //     dialogConfig.data = partner;
  //     dialogConfig.width = "850px";
  //     let dialogRef = this.dialog.open(ChildPartnersComponent, dialogConfig);
  //     dialogRef.afterClosed().subscribe(returnObj => {
  //       debugger;
  //       if (returnObj) {
  //         this.loadPartnerPending();
  //       }

  //     });
  //   }
  //   else {
  //     this.toastr.error("somthing wrong, try again.");
  //   }
  // }


}
