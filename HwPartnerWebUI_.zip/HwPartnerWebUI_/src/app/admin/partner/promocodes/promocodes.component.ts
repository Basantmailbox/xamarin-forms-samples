import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { PromoCode } from 'src/app/modals/Promocode';
import { MatSort } from '@angular/material';
import { PromocodeService } from 'src/app/_services/promocode.service';

export interface PeriodicElement {
  partnerName: string;
  partnerType: string;
  discount: number;
  validto: any;
  validfrom: any
}
@Component({
  selector: 'app-promocodes',
  templateUrl: './promocodes.component.html',
  styleUrls: ['./promocodes.component.scss']
})
export class PromocodesComponent implements OnInit {

  promoCodeObjs: PromoCode[];

  displayedColumns: string[] = ['promoCodeName', 'partnerType', 'discount', 'description', 'validto', 'validfrom', 'action'];
  dataSource = new MatTableDataSource<PromoCode>();

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private _promocodeService: PromocodeService
  ) {

  }


  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.loadPromoCode();
  }

  loadPromoCode() {
    this._promocodeService.GetMyPartner("530")
      .subscribe(respons => {
        this.promoCodeObjs = respons;
        this.dataSource.data = this.promoCodeObjs;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
