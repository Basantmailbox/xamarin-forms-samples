import { Component, OnInit, ViewChild } from '@angular/core';
import { PartnerService } from 'src/app/_services/partner.service';
import { ToastrService } from 'ngx-toastr';
import { Partner } from 'src/app/modals/partner';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-approval-pending',
  templateUrl: './approval-pending.component.html',
  styleUrls: ['./approval-pending.component.scss']
})
export class ApprovalPendingComponent implements OnInit {

  partnerObjs: Partner[];
  // displayedColumns: string[] = ['partnerName', 'mobileNo', 'emailId', 'partnerType', 'status'];
  // dataSource = new MatTableDataSource<Partner>();



  // @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  // @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private _partnerService: PartnerService,
    private toastr: ToastrService
  ) { }

  ngOnInit() {

    // this.loadPartnerPending();

    // this.dataSource.paginator = this.paginator;
    // this.dataSource.sort = this.sort;
  }

  // loadPartnerPending() {
  //   debugger;
  //   this._partnerService.GetPartnerApprovalPending(0, 0)
  //     .subscribe(respons => {
  //       this.partnerObjs = respons;
  //       this.dataSource.data = this.partnerObjs;
  //     },
  //       error => console.log("Error (GetData) :: " + error)
  //     );
  // }

  // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();

  //   if (this.dataSource.paginator) {
  //     this.dataSource.paginator.firstPage();
  //   }
  // }

  // UpdateEntity(entityObj) {

  // }
  // deleteEntity(entityObj) {

  // }
}
