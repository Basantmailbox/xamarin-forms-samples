import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from '../_core/appMaterialModule';
import { AdminRoutingModule } from './admin-routing.module';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { ProfileAdminComponent } from './profile-admin/profile-admin.component';
 import { ApprovalPendingComponent } from './partner/approval-pending/approval-pending.component';
 import { AllPartnersComponent } from './partner/all-partners/all-partners.component';
import { ChildPartnersComponent } from './partner/child-partners/child-partners.component';
import { ToastrModule } from 'ngx-toastr';
import { httpInterceptorProviders } from '../auth/auth-interceptor';

// import { MatFormFieldModule, MatButtonModule, MatInputModule, MatRippleModule, MatSelectModule, MatOptionModule, MatCheckboxModule } from "@angular/material";
// import { MatDialogModule, MatDialogTitle, MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { DiscountInventoryComponent } from './partner/discount-inventory/discount-inventory.component';
import { PromocodesComponent } from './partner/promocodes/promocodes.component';



@NgModule({
  declarations: [
    DashboardAdminComponent,
    ProfileAdminComponent, 
     ApprovalPendingComponent, 
     AllPartnersComponent, 
    ChildPartnersComponent,
    DiscountInventoryComponent,
    PromocodesComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    AppMaterialModule,
    ToastrModule.forRoot(
      {
        closeButton: true
      }
    ),
  ],
  exports: [
    AppMaterialModule
  ],
  providers: [httpInterceptorProviders],
  entryComponents: [ChildPartnersComponent]
})
export class AdminModule { }
