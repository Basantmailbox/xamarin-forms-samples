import { Injectable } from '@angular/core';
import { AppSetting } from '../security/appSetting';
import { Observable } from 'rxjs';
import { ReportSpent } from '../modals/reports';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  appURL: string = AppSetting.API_URL + "report";
  appHeader = AppSetting.HTTTP_OPTION;

  constructor(private http: HttpClient) { }
  GetSpent(partnerId: number, tenure: number, spentOn: number): Observable<ReportSpent[]> {
    return this.http.get<ReportSpent[]>(this.appURL + '/getspent/?partnerId=' + partnerId);
  }

  
}
