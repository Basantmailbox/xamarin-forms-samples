import { Injectable } from '@angular/core';
import { AppSetting } from '../security/appSetting';

import { Observable } from 'rxjs';
import { VirtualOffice } from '../modals/virtualOffice';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VirtualofficeService {

  appURL: string = AppSetting.API_URL + "virtualoffice";
  appHeader: any = AppSetting.HTTTP_OPTION;

  constructor(private http: HttpClient) { }

  GetByPartnerId(partnerId:string): Observable<VirtualOffice[]> {
    return this.http.get<VirtualOffice[]>(this.appURL + '/getbypartnerid/?partnerId='+partnerId);
  }

  SetNewEntity(entityObj: VirtualOffice) {
    return this.http.post<VirtualOffice>(this.appURL + '/setnewentity/', entityObj, this.appHeader);
  }

}
