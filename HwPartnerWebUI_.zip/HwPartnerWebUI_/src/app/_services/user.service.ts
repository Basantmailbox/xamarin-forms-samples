import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSetting } from '../security/appSetting';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  private adminUrl = 'https://localhost:44399/api/user/';

  constructor(private http: HttpClient) { }

  appURL: string = AppSetting.API_URL;
  appHeader = AppSetting.HTTTP_OPTION;

  getAdminBoard(): Observable<string> {
    return this.http.get(this.adminUrl, { responseType: 'text' });
  }

}
