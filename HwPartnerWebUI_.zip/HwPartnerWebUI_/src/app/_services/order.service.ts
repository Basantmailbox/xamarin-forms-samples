import { Injectable } from '@angular/core';
import { AppSetting } from '../security/appSetting';
import { HttpClient } from '@angular/common/http';
import { OrderHistoryDayWise } from '../modals/order';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  appURL: string = AppSetting.API_URL + "Order";
  appHeader: any = AppSetting.HTTTP_OPTION;
  
  constructor(private http: HttpClient) { }


  GetPartnerHistoryDayWise(partnerId: number): Observable<OrderHistoryDayWise[]> {
    return this.http.get<OrderHistoryDayWise[]>(this.appURL + '/getpartnerhistorydaywise/?partnerId=' + partnerId);
  }

  GetPartnerHistoryOneDay(partnerId: number,orderDate:string): Observable<OrderHistoryDayWise[]> {
    return this.http.get<OrderHistoryDayWise[]>(this.appURL + '/getpartnerhistoryoneday/?partnerId=' + partnerId+"&orderDate:"+orderDate);
  }
}

