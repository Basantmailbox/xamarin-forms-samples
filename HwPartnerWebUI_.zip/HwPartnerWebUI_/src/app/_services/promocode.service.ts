import { Injectable } from '@angular/core';
import { AppSetting } from '../security/appSetting';
import { Observable } from 'rxjs';
import { PromoCode } from '../modals/Promocode';
import { HttpClient, HttpHeaders } from '@angular/common/http';

// const httpOptions = {
//   headers: new HttpHeaders({ 'Content-Type': 'application/json' })
// };
@Injectable({
  providedIn: 'root'
})
export class PromocodeService {

  appURL: string = AppSetting.API_URL + "PromoCode";
  appHeader = AppSetting.HTTTP_OPTION;

  constructor(private http: HttpClient) { }

  GetMyPartner(partnerId: string): Observable<PromoCode[]> {
    return this.http.get<PromoCode[]>(this.appURL + '/getbypartnerid/?partnerId=' + partnerId);
  }

  InsertNew(entityObj: PromoCode) {
    
    return this.http.post<PromoCode>(this.appURL + '/insertnew/', entityObj, this.appHeader);
  }

  GetValidRechargePromo(): Observable<PromoCode[]> {
    return this.http.get<PromoCode[]>(this.appURL + '/getvalidrechargepromo');
  }

  GetValidBookingPromo(): Observable<PromoCode[]> {
    return this.http.get<PromoCode[]>(this.appURL + '/getvalidbookingpromo');
  }
  AppliedPromoValidate(entityObj: PromoCode): Observable<PromoCode>{
    return this.http.post<PromoCode>(this.appURL + '/appliedpromovalidate', entityObj, this.appHeader);
  }
  
}
