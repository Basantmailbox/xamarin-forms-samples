import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSetting } from '../security/appSetting';
import { Package } from '../modals/package';
import { Partner } from '../modals/partner';

@Injectable({
  providedIn: 'root'
})
export class PackageService {


  appURL: string = AppSetting.API_URL + "Package";
  appHeader: any = AppSetting.HTTTP_OPTION;
  
  constructor(private http: HttpClient) { }


  InserNew(entityObj: Package): Observable<Partner> {
    return this.http.post<Partner>(this.appURL + '/insertnew/', entityObj);
  }

  GetPackage4Booking(partnerId: number): Observable<Package[]> {
    return this.http.get<Package[]>(this.appURL + '/getpackage4booking/?partnerId=' + partnerId);
  }

  GetMyPackages(partnerId: number): Observable<Package[]> {
    return this.http.get<Package[]>(this.appURL + '/GetMyPackages/?partnerId=' + partnerId);
  }
  GetMyPackageDetails(partnerId: number,packageId: number): Observable<Package[]> {
    return this.http.get<Package[]>(this.appURL + '/getmypackagedetails/?partnerId=' + partnerId+"&packageId="+packageId);
  }
  GetHWPackages(): Observable<Package[]> {
    return this.http.get<Package[]>(this.appURL + '/GetHWPackages/');
  }

}
