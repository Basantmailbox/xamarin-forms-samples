import { Injectable } from '@angular/core';
import { AppSetting } from '../security/appSetting';
import { HttpClient } from '@angular/common/http';
import { DiscountGlobal } from '../modals/globalDiscount';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GlobaldiscountService {

  appURL: string = AppSetting.API_URL + "GlobalDiscount";
  appHeader: any = AppSetting.HTTTP_OPTION;
  
  constructor(private http: HttpClient) { }
  

  InsertOrUpdate(entityObj: DiscountGlobal) {
    return this.http.post<boolean>(this.appURL + '/insertorupdate/', entityObj, this.appHeader);
  }

  GetByPartnerId(partnerId: number): Observable<DiscountGlobal> {
    return this.http.get<DiscountGlobal>(this.appURL + '/getbypartnerid/?partnerId=' + partnerId);
  }

  GetAll(): Observable<DiscountGlobal[]> {
    return this.http.get<DiscountGlobal[]>(this.appURL + '/getall/');
  }
}
