import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSetting } from '../security/appSetting';
import { CityState } from '../modals/cityState';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  appURL: string = AppSetting.API_URL + "CommonAPI";
  appHeader: any = AppSetting.HTTTP_OPTION;

  constructor(private http: HttpClient) { }

  GetValidatePinCode(partnerId: number ,pincode: string) {
    return this.http.get<CityState>(this.appURL + '/getvalidatepincode/?userId=' + partnerId +'&pinCode=' + pincode);
  }

  GetGeoAddress(searchText: string, pinCode: string, cityName: string, partnerId: number): Observable<any[]> {
    return this.http.get<any[]>(this.appURL + '/getgeoaddress/?searchText=' + searchText + "&pinCode=" + pinCode + "&cityName=" + cityName + "&userId=" + partnerId);
  }

  GetLatLongByPlaceId(partnerId: number,placeId:string): Observable<any> {
    return this.http.get<any>(this.appURL + '/getlatlongbyplaceid/?userId=' + partnerId+"&placeId="+placeId);
  }


}
