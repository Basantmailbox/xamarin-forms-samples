import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSetting } from '../security/appSetting';
import { BuyCredit, CreditAllocated, CreditTransectionHistory } from '../modals/credit';


@Injectable({
  providedIn: 'root'
})
export class CreditService {
  appURL: string = AppSetting.API_URL + "Credit";
  appHeader: any = AppSetting.HTTTP_OPTION;
  
  constructor(private http: HttpClient) { }

  Buy(entityObj: BuyCredit) {
    return this.http.post<boolean>(this.appURL + '/buy/', entityObj, this.appHeader);
  }

  GetAllocated(partnerId: number): Observable<CreditAllocated[]> {
    return this.http.get<CreditAllocated[]>(this.appURL + '/getallocated/?partnerId=' + partnerId);
  }

  GetTransectionHistory(partnerId: number): Observable<CreditTransectionHistory[]> {
    return this.http.get<CreditTransectionHistory[]>(this.appURL + '/gettransectionhistory/?partnerId=' + partnerId);
  }


}
