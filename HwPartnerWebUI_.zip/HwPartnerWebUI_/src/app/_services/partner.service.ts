import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Partner } from '../modals/partner';
import { AppSetting } from '../security/appSetting';

@Injectable({
  providedIn: 'root'
})


export class PartnerService {

  appURL: string = AppSetting.API_URL + "partner";
  appHeader: any = AppSetting.HTTTP_OPTION;

  constructor(private http: HttpClient) { }

  GetMyPartner(partnerId: string): Observable<Partner[]> {

    return this.http.get<Partner[]>(this.appURL + '/getmypartner/?partnerId=' + partnerId);
  }

  UpdateEntity(entityObj: Partner) {
    return this.http.post<Partner>(this.appURL + '/updateentity/', entityObj, this.appHeader);
  }

  InsertNewEntity(entityObj: Partner) {
    return this.http.post<Partner>(this.appURL + '/insertnewentity/', entityObj, this.appHeader);
  }

  GetPartnerApprovalPending(partnerId: number, roleId: number): Observable<Partner[]> {
    return this.http.get<Partner[]>(this.appURL + '/getpartnerapprovalpending/?partnerId=' + partnerId + '&roleId=' + roleId);
  }

  GetPartnerByRole(roleId: number): Observable<Partner[]> {
    debugger;
    return this.http.get<Partner[]>(this.appURL + '/getpartnerbyrole/?roleId=' + roleId);
  }

  GetPartnerByRoleAndPartner(partnerId: number, roleId: number): Observable<Partner[]> {
    return this.http.get<Partner[]>(this.appURL + '/getpartnerbyroleandpartner/?roleId=' + roleId+'&partnerId=' + partnerId);
  }

  GetMinBalanceMyPartners(partnerId: number): Observable<Partner[]> {
    return this.http.get<Partner[]>(this.appURL + '/getminbalancemypartners/?partnerId=' + partnerId);
  }
  GetMyPartners4Chart(partnerId: number): Observable<Partner[]> {
    return this.http.get<Partner[]>(this.appURL + '/getmypartners4chart/?partnerId=' + partnerId);
  }

  GetPartner(partnerId: number): Observable<Partner> {
    return this.http.get<Partner>(this.appURL + '/getpartner/?partnerId=' + partnerId);
  }
  
 
  GetCurrentPoints(partnerId: number): Observable<Partner> {
    return this.http.get<Partner>(this.appURL + '/getcurrentpoints/?partnerId=' + partnerId);
  }
  
  
}
