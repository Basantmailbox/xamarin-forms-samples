//libs
import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router'; 
//auth
import { LoggedUserService } from 'src/app/auth/logged-user.service';


@Component({
  selector: 'app-partner-layout',
  templateUrl: './partner-layout.component.html',
  styleUrls: ['./partner-layout.component.scss']
})
export class PartnerLayoutComponent implements OnInit {

  loggedUser: any;
  constructor(private _loggedUserService: LoggedUserService, private router: Router) { }

  ngOnInit() {
    this.validateUser();
    this.loggedUser = {
      token: this._loggedUserService.getToken(),
      username: this._loggedUserService.getFullName(),
      roleName: this._loggedUserService.getRoleName()
    };
    
  }

   //logout app
   logout() {
    this._loggedUserService.signOut();
     //redirection to home
     this.router.navigate(["/"]);
  }
  //validate user token  in system
  validateUser(){
    if(this._loggedUserService.getToken() == null){
     //redirection to login for error
     this.router.navigate(["/"]);
    }
  }


}
