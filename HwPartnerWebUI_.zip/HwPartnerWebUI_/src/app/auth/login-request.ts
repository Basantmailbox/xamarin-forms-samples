export class LoginRequest {
    LoginId: string;
    Password: string;

    constructor(LoginId: string, Password: string) {
        this.LoginId = LoginId;
        this.Password = Password;
    }
}