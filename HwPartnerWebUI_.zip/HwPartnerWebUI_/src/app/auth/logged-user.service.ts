import { Injectable } from '@angular/core';

const TOKEN_KEY = 'AuthToken';
const USERID_KEY = 'AuthUserId';
// const USERNAME_KEY = 'AuthUserName';
const ROLEID_KEY = 'LoggedRoleId';
const ROLENAME_KEY = 'LoggedRoleName';
const BALANCE_KEY = 'LoggedUserBalance';
const FULLNAME_KEY = 'LoggedUserFullName';

@Injectable({
  providedIn: 'root'
})
export class LoggedUserService {
  private roles: string;
  constructor() { }

  signOut() {
    window.sessionStorage.clear();
  }

  public saveToken(token: string) {
    window.sessionStorage.removeItem(TOKEN_KEY);
    window.sessionStorage.setItem(TOKEN_KEY, token);
  }

  public getToken(): string {
    return sessionStorage.getItem(TOKEN_KEY);
  }

  // public saveUsername(username: string) {
  //   window.sessionStorage.removeItem(USERNAME_KEY);
  //   window.sessionStorage.setItem(USERNAME_KEY, username);
  // }

  // public getUserName(): string {
  //   return sessionStorage.getItem(USERNAME_KEY);
  // }

  public saveUserId(roleId: number) {
    window.sessionStorage.removeItem(USERID_KEY);
    window.sessionStorage.setItem(USERID_KEY, roleId.toString());
  }

  public getUserId(): number {
    return Number(sessionStorage.getItem(USERID_KEY));
  }


  public saveRoleName(roleName: string) {
    window.sessionStorage.removeItem(ROLENAME_KEY);
    window.sessionStorage.setItem(ROLENAME_KEY, roleName);
  }

  public getRoleName(): string {
    return sessionStorage.getItem(ROLENAME_KEY);
  }

  public saveRoleId(roleId: number) {
    window.sessionStorage.removeItem(ROLEID_KEY);
    window.sessionStorage.setItem(ROLEID_KEY, roleId.toString());
  }

  public getRoleId(): number {
    return Number(sessionStorage.getItem(ROLEID_KEY));
  }

  public saveBalance(balance: string) {
    window.sessionStorage.removeItem(BALANCE_KEY);
    window.sessionStorage.setItem(BALANCE_KEY, balance);
  }

  public getBalance(): string {
    return sessionStorage.getItem(BALANCE_KEY);
  }

  public saveFullName(fullName: string) {
    window.sessionStorage.removeItem(FULLNAME_KEY);
    window.sessionStorage.setItem(FULLNAME_KEY, fullName);
  }

  public getFullName(): string {
    return sessionStorage.getItem(FULLNAME_KEY);
  }

}