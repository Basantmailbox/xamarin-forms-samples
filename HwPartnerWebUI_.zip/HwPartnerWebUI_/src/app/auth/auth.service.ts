import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { LoggedUser } from '../modals/loggedUser';
import { LoginRequest } from './login-request';
import { AppSetting } from '../security/appSetting';
import { LoggedUserService } from './logged-user.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  appURL: string = AppSetting.API_URL;
  appHeader= AppSetting.HTTTP_OPTION;
  

  constructor(private http: HttpClient,
    private _loggedUserService: LoggedUserService) {
  }

  attemptAuth(credentials: LoginRequest): Observable<LoggedUser> {
    return this.http.post<LoggedUser>(this.appURL+"auth/authenticate", credentials, httpOptions);
  }
  getTest() {
    return this.http.get<string>(this.appURL+"Values");
  }

  
  logout() {
    // remove user from local storage and set current user to null
    this._loggedUserService.signOut();
}

  // signUp(info: SignUpInfo): Observable<string> {
  //   return this.http.post<string>(this.appURL+"/", info, httpOptions);
  // }
}