import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { PartnerLayoutComponent } from './layouts/partner-layout/partner-layout.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';

//const routes
const routes: Routes = [
  {
    //route to login
    path: '',
    component: LoginComponent,
    // data: {}
    // data: {
    // allowedRoles: ['admin', 'writer', 'author']
    // }
  },
  {
    path: 'admin', component: AdminLayoutComponent,
    loadChildren:()=>import('./admin/admin.module').then(m=>m.AdminModule)
  },
  {
    path: 'partner', component: PartnerLayoutComponent,
    loadChildren:()=>import('./partner/partner.module').then(m=>m.PartnerModule)
  },
{
  path: '**',
    redirectTo: ''
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
