//generic libs
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from '../app/shared/_modal';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

//auth interceptor
import { httpInterceptorProviders } from './auth/auth-interceptor';
import { AdminModule } from './admin/admin.module';
import { AdminRoutingModule } from './admin/admin-routing.module';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { PartnerLayoutComponent } from './layouts/partner-layout/partner-layout.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { PartnerModule } from './partner/partner.module';
import { PartnerRoutingModule } from './partner/partner-routing.module';
import { OnlyNumber} from './shared/directives/only-number.directive';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';    
import { LogoutComponent } from './logout/logout.component';
import { AppMaterialModule } from './_core/appMaterialModule';
import { ErrorInterceptorProviders } from './_helpers/error.interceptor';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminLayoutComponent,
    PartnerLayoutComponent,
    FooterComponent,
    OnlyNumber,
    LogoutComponent
  ],
  imports: [
    ModalModule,
    BrowserModule,
    BrowserAnimationsModule,  
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AdminRoutingModule,
    AdminModule,
    PartnerRoutingModule,
    PartnerModule,
    AppMaterialModule,
    NgxSpinnerModule
  ],  
  providers: [httpInterceptorProviders,ErrorInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
