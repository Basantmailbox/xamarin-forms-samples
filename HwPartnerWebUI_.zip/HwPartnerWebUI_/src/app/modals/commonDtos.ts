export class GoogleAPIGeoAddressResultDto {
    geoPlaceName: string;
    geoPlaceId:string;
}  

