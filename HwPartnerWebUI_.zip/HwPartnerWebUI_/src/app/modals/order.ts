export class OrderHistoryDayWise {
    orderDate: string;
    pickedOrder: number;
    pickedRevenue: string;
    partnerEarning: string;
    myEarning: string;
    partnerId: number;
}  
