import { Package } from './package';

export class CustomerBooking {
    firstName: string;
    lastName: string;
    relation:string;
    gender: string;
    age:string;
    dateOfBirth:any;
    bCORequire:string;
    payment:string;
    mobileNo:string;
    emailId:string;
    packages: Package[]=[];
}  

