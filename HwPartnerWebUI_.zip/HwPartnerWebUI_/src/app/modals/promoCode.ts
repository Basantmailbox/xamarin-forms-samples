export class PromoCode {
    promoCodeId: number;
    promoCodeName: string;
    promoType: string;
    discount: string;
    discountType: string;
    description: string;
    createdDate: string;
    userName: string;
    userId: number;
    isActive: boolean;
    isNew: boolean;
    validTo: Date;
    validFrom: Date;
    minAmount: number;
    isExpired: false;
    appliedCounter:number

}  