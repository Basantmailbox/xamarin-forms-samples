export class CityState {
    cityId: number;
    cityName:string;
    stateId: number;
    stateName:string;
    blockName:string;
    district:string;
    pincode:string;
    userId:number;
    googleKey:string;
}  

