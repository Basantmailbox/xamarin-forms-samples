export class ReportSpent {
    SpentAmount: number;
    Percentage: number;
    SpentDate:string;
    SpentOn:string;
}  

