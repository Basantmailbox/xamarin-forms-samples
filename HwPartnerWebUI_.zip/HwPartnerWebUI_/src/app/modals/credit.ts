export class BuyCredit {
    promoCodeId: number;
    partnerId: number;
    paymentMode:string;
    rechargeAmount:string;
}  


export class CreditAllocated {
    partnerName: string;
    partnerType: string;
    availableCredit:string;
    allocateCredits:string;
    creditLimitReminder:string;
    myEarning:string;
    partnerId:number;
}

export class CreditTransectionHistory {
    transectionId: string;
    transectionDate: string;
    assignedCredit:string;
}

