export class LoggedUser {
    partnerId: number;
    partnerName: string;
    //userName: string;
    balance: string;
    token: string;
    roleId: number;
    roleName: string;
}
//loginPayload 