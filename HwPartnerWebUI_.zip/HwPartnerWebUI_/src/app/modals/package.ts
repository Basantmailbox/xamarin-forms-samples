
export class Package {
    packageId: number;
    packageName: string;
    offAmount: string;
    offerPrice: number;
    actualPrice: number;
    testCount: number;
    testNames: string;
    createdDate:string;
    isHWPackage:boolean;  
    isSelected:boolean=false; 
    mappedPkgIds:string;
    partnerId:number;
    earning:number;
    isPackage:boolean;
    packageType:string;
    preInfo:string;
    availabilty:string;
}  