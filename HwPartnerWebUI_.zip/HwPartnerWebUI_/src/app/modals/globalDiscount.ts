export class DiscountGlobal {
    fromDate: any;
    toDate: any;
    globalDiscount: number;
    partnerId: number;
}  
