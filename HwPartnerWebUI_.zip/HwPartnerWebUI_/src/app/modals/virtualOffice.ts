
export class VirtualOffice {
    vOfficeId: number;
    vOfficeName: string;
    address1: string;
    geoAddress: string;
    landmark: string;
    geoLongitude: string;
    geoLatitude: string;
    pincode: string;
    cityId: number;
    contactName: string;
    contactNo: string;
    isActive: boolean;
    houseNo: string;
    blockNo: string;
    floorNo: string;
    area: string;
    partnerId: number;
    availableCredit:string;
    createdBy:string;
    cityName:string;
    stateName:string;
}  