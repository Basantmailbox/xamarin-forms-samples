
export class Partner {
    partnerId: number;
    partnerName: string;
    emailId: string;
    mobileNo: string;
    partnerTypeId: number;
    partnerType: string;
    displayRoleName:string;
    availableCredit:string;
    createdBy: number;
    isActive:boolean;
    isNew: boolean;
    earning:string;

}  