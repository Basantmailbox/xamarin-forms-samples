import { Component, OnInit, Inject } from '@angular/core';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CreditService } from 'src/app/_services/credit.service';
import { ToastrService } from 'ngx-toastr';
import { PromocodeService } from 'src/app/_services/promocode.service';
import { BuyCredit } from 'src/app/modals/credit';
import { PromoCode } from 'src/app/modals/Promocode';
import { RechargePromocodeComponent } from '../../promocode/recharge-promocode.component';
import { PromoType } from 'src/app/shared/enumApp';
import { Router } from '@angular/router';
import { PartnerService } from 'src/app/_services/partner.service';
import { Partner } from 'src/app/modals/partner';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-add-credit',
  templateUrl: './add-credit.component.html',
  styleUrls: ['./add-credit.component.scss']
})
export class AddCreditComponent implements OnInit {

  partnerId: number;
  loggedUser: any;
  angForm: FormGroup;
  buyCreditObj: BuyCredit;
  selectedPromoCodeObj: PromoCode;
  partnerObj: Partner;
  isPromoApplied: Boolean;

  constructor(
    private fb: FormBuilder,
    private _creditService: CreditService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private _loggedUserService: LoggedUserService,
    private _promocodeService: PromocodeService,
    private _partnerService: PartnerService,
    private dialogRef: MatDialogRef<AddCreditComponent>,
    @Inject(MAT_DIALOG_DATA) data: number) {
    this.partnerId = data;

    this.createForm();
  }

  ngOnInit() {

    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    };

    debugger;

    this.getPartnerDetails(this.partnerId);

    this.selectedPromoCodeObj = new PromoCode();
    this.buyCreditObj = new BuyCredit();
    this.partnerObj = new Partner();
  }

  getPartnerDetails(partnerId: number) {
    debugger;
    if (partnerId > 0) {
      this._partnerService.GetPartner(partnerId)
        .subscribe(respons => {
          debugger;
          if (respons == null) {
            this.toastr.warning("Partner Not valid.");
            this.dialogRef.close(false);
          }
          else {
            this.partnerObj = respons;
          }

        },
          error => {
            this.dialogRef.close(false);
            console.log("Error (GetData) :: " + error);
          }
        );
    }
    else {
      this.toastr.warning("Somthing wrong.");
      this.dialogRef.close(false);
    }
  }


  createForm() {
    this.angForm = this.fb.group({
      rechargeAmount: ['', Validators.required],
      paymentMode: ['', Validators.required],
      promoCode: ['']
    });
  }

  setDirectAmount(selectedAmount: string) {
    this.angForm.controls['rechargeAmount'].setValue(selectedAmount);
  }

  openDialog4SelectPromo() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = "";
    dialogConfig.width = "550px";
    let dialogRef = this.dialog.open(RechargePromocodeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      debugger;
      if (returnObj != null) {
        debugger;
        this.angForm.controls['paymentMode'].setValue(returnObj.promoCodeName);
      }
    });
  }

  onClickAddCredit() {
    debugger;

    var rechargeAmountField = this.angForm.controls['rechargeAmount'];
    if (rechargeAmountField.status == 'VALID') {

      this.buyCreditObj.rechargeAmount = rechargeAmountField.value;
    }
    else {
      this.toastr.warning("Please Enter Amount");
      return false;
    }

    var paymentModeField = this.angForm.controls['paymentMode'];

    if (paymentModeField.status == 'VALID') {
      this.buyCreditObj.paymentMode = paymentModeField.value;
    }
    else {
      this.toastr.warning("Please Select Payment Mode");
      return false;
    }

    // this._creditService.Buy(this.buyCreditObj).subscribe(respons => {
    //   if (respons != null) {
    this.toastr.success('Saved Successfully');
    this.dialogRef.close(true);
    //     // this.router.navigate(['edit-user']);
    //   }
    //   else {
    //     this.toastr.error('Error');
    //   }
    // },
    //   error => {
    //     console.log("Error (GetData) :: " + error)
    //     this.toastr.error(error.statusText);
    //   }
    // );
  }

  OnClickApply() {
    debugger;
    var rechargeAmountField = this.angForm.controls['rechargeAmount'];
    if (rechargeAmountField.status == 'VALID' && rechargeAmountField.value.length > 2) {
      this.selectedPromoCodeObj.minAmount = rechargeAmountField.value;
    }
    else {
      this.toastr.warning("Please Enter Amount");
      return false;
    }

    var promoCodeField = this.angForm.controls['promoCode'];
    if (promoCodeField.status == 'VALID' && promoCodeField.value.length > 4) {
      this.selectedPromoCodeObj.promoCodeName = promoCodeField.value;
      this.selectedPromoCodeObj.promoType = PromoType.RECHARGE;
    }
    else {
      this.toastr.warning("Please Enter Promo Code");
      return false;
    }

    this._promocodeService.AppliedPromoValidate(this.selectedPromoCodeObj)
      .subscribe(respons => {
        debugger;
        this.selectedPromoCodeObj.discount = respons.discount;
        if (respons != null) {
        
          if (respons.promoCodeId > 0) {
            this.isPromoApplied=true;
            this.selectedPromoCodeObj = respons;
              this.toastr.success('Promo Applied Successfully');
          }
          else{
            this.toastr.warning('Saved Successfully');
          }

        }
        else {
          this.toastr.error('Server Error.');
        }
      },
        error => {
          console.log("Error (GetData) :: " + error)
          this.toastr.error(error.statusText);
        }
      );
  }

  OnClickRemove() {
    this.selectedPromoCodeObj=new PromoCode();
    this.isPromoApplied=false;
  }
  close() {
    this.dialogRef.close(false);
  }

}
