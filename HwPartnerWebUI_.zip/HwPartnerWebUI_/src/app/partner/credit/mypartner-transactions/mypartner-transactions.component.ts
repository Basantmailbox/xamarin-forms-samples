import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { CreditService } from 'src/app/_services/credit.service';
import { CreditTransectionHistory } from 'src/app/modals/credit';

@Component({
  selector: 'app-mypartner-transactions',
  templateUrl: './mypartner-transactions.component.html',
  styleUrls: ['./mypartner-transactions.component.scss']
})
export class MypartnerTransactionsComponent implements OnInit {


  partnerId:string;
  loggedUser: any;
  historyObjs: CreditTransectionHistory[]
  
  constructor(
    private _creditService: CreditService,
    private _loggedUserService: LoggedUserService,
    private dialogRef: MatDialogRef<MypartnerTransactionsComponent>,
    @Inject(MAT_DIALOG_DATA) data: string) {
    
    this.partnerId = data;
  }

  ngOnInit() {
    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    };
    this.bindHistory();
  }

  bindHistory(){
    if(this.loggedUser.userId){
    this._creditService.GetTransectionHistory(this.loggedUser.userId)
            .subscribe(respons => {
              this.historyObjs = respons;
            },
              error => console.log("Error GetTransectionHistory :: " + error)
            );
      }
    }


  close() {
    this.dialogRef.close(false);
  }

}
