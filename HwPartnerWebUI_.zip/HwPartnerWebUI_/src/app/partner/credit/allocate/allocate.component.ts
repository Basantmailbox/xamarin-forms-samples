import { Component, OnInit,ViewChild } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { CreditAllocated } from 'src/app/modals/credit';
import { CreditService } from 'src/app/_services/credit.service';
import { MypartnerTransactionsComponent } from '../mypartner-transactions/mypartner-transactions.component';

import { AddCreditComponent } from '../add-credit/add-credit.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-allocate',
  templateUrl: './allocate.component.html',
  styleUrls: ['./allocate.component.scss']
})
export class AllocateComponent implements OnInit {

  displayedColumns: string[] = ['partnerName', 'partnerType', 'availableCredit', 'allocateCredits','creditLimitReminder','myEarning','viewDetails'];
  dataSource = new MatTableDataSource<CreditAllocated>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  creditAllocatedObjs: CreditAllocated[];
  modalPartnerHeader: string;
  isRequest4New: boolean;
  isShowModal: boolean;
  loggedUser: any;


  constructor(
    private router: Router,
    private _creditService: CreditService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private _loggedUserService: LoggedUserService
  ) { }

  ngOnInit() {

    
    this.loggedUser = {
      userId: this._loggedUserService.getUserId()
    }
    // this.resetModal();

    this.loadAllocatedCredits();
    this.modalPartnerHeader = "Create";

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openDialogMyPartnerAllocated(crdAllocated: CreditAllocated) {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = crdAllocated.partnerId;
    dialogConfig.width="550px";
    let dialogRef = this.dialog.open(MypartnerTransactionsComponent , dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      if(returnObj){
      
      }
    });
  }

  onClickViewDetails(partnerId: string) {
    debugger;
    partnerId="3";
   this.router.navigate(['../order/partnerhistorydaywise'],);
  
  }

  openDialogAddCredit(crdAllocated: CreditAllocated) {

    debugger;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = crdAllocated.partnerId;
    dialogConfig.width="800px";
    let dialogRef = this.dialog.open( AddCreditComponent  , dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      if(returnObj){
        this.loadAllocatedCredits();
      }
    });
  }


  // openDialog4InsertUpdate(entityObj: PromoCode) {

  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.disableClose = true;
  //   dialogConfig.autoFocus = true;
  //   dialogConfig.data = entityObj;
  //   dialogConfig.width = "520px";
  //   let dialogRef = this.dialog.open(CreatePromocodeComponent, dialogConfig);
  //   dialogRef.afterClosed().subscribe(returnObj => {
  //     debugger;
  //     if (returnObj) {
  //       this.loadPromoCode();
  //     }

  //   });

  // }
  

  loadAllocatedCredits() {
    debugger;
    this._creditService.GetAllocated(this.loggedUser.userId)
      .subscribe(respons => {
        debugger;
        
        this.creditAllocatedObjs= respons;
        this.dataSource.data = this.creditAllocatedObjs;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }


}
