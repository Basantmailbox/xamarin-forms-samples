import { Component, OnInit } from '@angular/core';
import { PromoCode } from 'src/app/modals/Promocode';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { RechargePromocodeComponent } from '../../promocode/recharge-promocode.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BuyCredit } from 'src/app/modals/credit';
import { CreditService } from 'src/app/_services/credit.service';
import { PromoType } from 'src/app/shared/enumApp';
import { PromocodeService } from 'src/app/_services/promocode.service';
import { PartnerService } from 'src/app/_services/partner.service';
import { Partner } from 'src/app/modals/partner';

@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.scss']
})
export class BuyComponent implements OnInit {

  selectedPromoCodeObj: PromoCode;
  buyCreditObj: BuyCredit;
  angForm: FormGroup;
  currentBalance: string;
  actualPoint: number = 0;
  bonusPoint: number = 0;
  isPromoApplied: boolean;

  constructor(
    private fb: FormBuilder,
    private _creditService: CreditService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private _loggedUserService: LoggedUserService,
    private _promocodeService: PromocodeService,
    private _partnerService: PartnerService
  ) {
    this.createForm();
  }

  ngOnInit() {
    this.selectedPromoCodeObj = new PromoCode();
    this.buyCreditObj = new BuyCredit();
    this.buyCreditObj.partnerId = this._loggedUserService.getUserId();
    this.currentBalance = this._loggedUserService.getBalance();
  }


  createForm() {
    this.angForm = this.fb.group({
      rechargeAmount: ['', Validators.required],
      paymentMode: ['', Validators.required],
      promoCode: ['']
    });
  }

  onKeydown(event: any) {
    debugger;
    var selectedAmount = event.target.value;
    if (parseInt(selectedAmount)) {
      this.actualPoint = (selectedAmount * 1) + ((selectedAmount * 1) / 10);
    }
  };

  openDialog4SelectPromo() {
    this.selectedPromoCodeObj = new PromoCode();
    this.angForm.controls['promoCode'].setValue('');
    this.bonusPoint = 0;
    this.isPromoApplied = false;

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = "";
    dialogConfig.width = "550px";
    let dialogRef = this.dialog.open(RechargePromocodeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      if (returnObj != null) {

        this.angForm.controls['promoCode'].setValue(returnObj.promoCodeName);
      }
    });
  }

  setDirectAmount(selectedAmount: number) {
    this.angForm.controls['rechargeAmount'].setValue(selectedAmount);
    this.actualPoint = (selectedAmount * 1) + ((selectedAmount * 1) / 10);
  }

  onClickRecharge() {
    debugger;

    var rechargeAmountField = this.angForm.controls['rechargeAmount'];
    if (rechargeAmountField.status == 'VALID') {

      this.buyCreditObj.rechargeAmount = rechargeAmountField.value;
    }
    else {
      this.toastr.warning("Please Enter Amount");
      return false;
    }

    var paymentModeField = this.angForm.controls['paymentMode'];

    if (paymentModeField.status == 'VALID') {
      this.buyCreditObj.paymentMode = paymentModeField.value;
    }
    else {
      this.toastr.warning("Please Select Payment Mode");
      return false;
    }

    if (this.selectedPromoCodeObj.promoCodeId > 0) {
      this.buyCreditObj.promoCodeId = this.selectedPromoCodeObj.promoCodeId;
    }

    this._creditService.Buy(this.buyCreditObj).subscribe(respons => {
      debugger;
      if (respons != null) {
        this.updateCurrentPoints();
        this.toastr.success('Saved Successfully');
      }
      else {
        this.toastr.error('Server Error');
      }
      this.selectedPromoCodeObj = new PromoCode();
      this.actualPoint = 0;
      this.bonusPoint = 0;
      this.isPromoApplied = false;
      this.angForm.reset();
    },
      error => {
        console.log("Error : " + error)
        this.selectedPromoCodeObj = new PromoCode();
        this.actualPoint = 0;
        this.bonusPoint = 0;
        this.isPromoApplied = false;
        this.angForm.reset();
        this.toastr.error(error);
      }
    );
  }

  OnClickRemove() {
    this.isPromoApplied = false;
  }

  OnClickApply() {
    this.isPromoApplied = false;
    var rechargeAmountField = this.angForm.controls['rechargeAmount'];
    if (rechargeAmountField.status == 'VALID') {
      this.selectedPromoCodeObj.minAmount = rechargeAmountField.value;
    }
    else {
      this.toastr.warning("Please Enter Amount");
      return false;
    }

    var promoCodeField = this.angForm.controls['promoCode'];
    if (promoCodeField.status == 'VALID' && promoCodeField.value.length > 4) {
      this.selectedPromoCodeObj.promoCodeName = promoCodeField.value;
      this.selectedPromoCodeObj.promoType = PromoType.RECHARGE;
    }
    else {
      this.toastr.warning("Please Enter Promo Code");
      return false;
    }

    this._promocodeService.AppliedPromoValidate(this.selectedPromoCodeObj)
      .subscribe(respons => {
        debugger;
        if (respons != null) {
          this.selectedPromoCodeObj.discount = respons.discount;
          if (respons.promoCodeId > 0) {
            this.selectedPromoCodeObj = respons;
            if (respons.promoCodeId > 0) {
              this.bonusPoint = parseInt(respons.discount);
              this.toastr.success('Successfully Applied');
              this.isPromoApplied = true;
            }
          }
          else {
            this.selectedPromoCodeObj = new PromoCode();
            this.angForm.controls['promoCode'].setValue('');
            this.toastr.warning('Promo Code Not Valid.');
          }

        }
        else {
          this.toastr.error('Error');
        }
      },
        error => {
          console.log("Error (GetData) :: " + error)
          this.toastr.error(error.statusText);
        }
      );
  }

  updateCurrentPoints() {

    if (this.buyCreditObj.partnerId > 0) {
      this._partnerService.GetCurrentPoints(this.buyCreditObj.partnerId)
        .subscribe(respons => {
          debugger;
          if (respons != null) {
            var partner = respons as Partner;
            if (partner.partnerId > 0) {
              this._loggedUserService.saveBalance(partner.availableCredit);
              this.currentBalance = this._loggedUserService.getBalance();
            }
          }
        })
    }
  }

}
