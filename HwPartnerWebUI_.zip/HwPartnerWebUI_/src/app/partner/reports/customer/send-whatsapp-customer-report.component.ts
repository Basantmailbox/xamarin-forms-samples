import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-whatsapp-customer-report',
  templateUrl: './send-whatsapp-customer-report.component.html',
  styleUrls: ['./send-whatsapp-customer-report.component.scss']
})
export class SendWhatsappCustomerReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
