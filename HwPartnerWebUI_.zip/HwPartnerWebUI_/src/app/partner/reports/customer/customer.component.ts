import { Component, OnInit,ViewChild } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { SendCustomerReportComponent } from './send-customer-report.component';
import { MatDialog, MatDialogConfig } from '@angular/material';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {


  displayedColumns: string[] = ['OrderId', 'CustomerName', 'OrderDate', 'OrderAmount','actions'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);


  constructor(public dialog: MatDialog) { }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
  }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  onClickViewReport(da:any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = "";
    dialogConfig.width = "650px";
    const dialogRef = this.dialog.open(SendCustomerReportComponent,dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}
export interface PeriodicElement {

}
const ELEMENT_DATA: PeriodicElement[] = [
  {OrderId: 1002, CustomerName: 'Pawan kumar', OrderDate:'12oct,19', OrderAmount:2500},
  {OrderId: 1003, CustomerName: 'Om prakash', OrderDate:'15oct,19', OrderAmount: 1500}
];
