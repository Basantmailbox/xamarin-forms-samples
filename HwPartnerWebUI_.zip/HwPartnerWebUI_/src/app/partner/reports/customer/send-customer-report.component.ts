import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { SendEmailCustomerReportComponent } from './send-email-customer-report.component';
import { SendWhatsappCustomerReportComponent } from './send-whatsapp-customer-report.component';

@Component({
  selector: 'app-send-customer-report',
  templateUrl: './send-customer-report.component.html',
  styleUrls: ['./send-customer-report.component.scss']
})
export class SendCustomerReportComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  onClickSendEmail() {
    const dialogRef = this.dialog.open(SendEmailCustomerReportComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  onClickSendWhatsApp() {
    const dialogRef = this.dialog.open(SendWhatsappCustomerReportComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


}
