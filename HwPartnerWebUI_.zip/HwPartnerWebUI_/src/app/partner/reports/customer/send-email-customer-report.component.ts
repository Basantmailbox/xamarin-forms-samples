import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-send-email-customer-report',
  templateUrl: './send-email-customer-report.component.html',
  styleUrls: ['./send-email-customer-report.component.scss']
})
export class SendEmailCustomerReportComponent implements OnInit {
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  constructor() { }

  ngOnInit() {
  }

}
