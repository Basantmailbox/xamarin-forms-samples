import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ReportSpent } from 'src/app/modals/reports';
import { ReportService } from 'src/app/_services/report.service';
import { LoggedUserService } from 'src/app/auth/logged-user.service';



@Component({
  selector: 'app-spent',
  templateUrl: './spent.component.html',
  styleUrls: ['./spent.component.scss']
})
export class SpentComponent implements OnInit {

  displayedColumns: string[] = ['spentAmount', 'percentage', 'spentDate', 'spentOn'];
  dataSource = new MatTableDataSource<ReportSpent>();

  constructor(
    private _reportService: ReportService,
    private _loggedUserService: LoggedUserService,
  ) { }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.getdata();
  }

  getdata() {
    var partnerId = this._loggedUserService.getUserId();
    if (partnerId > 0) {
      this._reportService.GetSpent(partnerId, 1, 1).subscribe(responcData => {
        this.dataSource.data = responcData;
      })
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
