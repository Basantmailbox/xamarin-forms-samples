import { Component, OnInit, ViewChild } from '@angular/core';
import { VirtualOffice } from 'src/app/modals/virtualOffice';
import { VirtualofficeService } from 'src/app/_services/virtualoffice.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig, MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { CreateOfficeComponent } from './create-office.component';

@Component({
  selector: 'app-inventory-office',
  templateUrl: './inventory-office.component.html',
  styleUrls: ['./inventory-office.component.scss']
})
export class InventoryOfficeComponent implements OnInit {

  displayedColumns: string[] = ['vOfficeName', 'geoAddress', 'contactName'];
  dataSource = new MatTableDataSource<VirtualOffice>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  modalHeader: string;
  virtualOffices: VirtualOffice[];

  isRequest4New: boolean;
  isShowModal: boolean;
  virtualOfficeObj: VirtualOffice;
  loggedUser: any;

  constructor(
    private _virtualOfficeService: VirtualofficeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private _loggedUserService: LoggedUserService
  ) { }


  ngOnInit() {

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    }
    this.SetModalDefaultValue();
    this.GetVirtualOffices();
    this.modalHeader = "Create";
  }


  SetModalDefaultValue() {
    this.virtualOfficeObj = {
        vOfficeId: 0,
        address1: '',
        area: '',
        availableCredit: "0",
        blockNo: '',
        cityId: 0,
        vOfficeName: '',
        contactName: '',
        contactNo: '',
        floorNo: '',
        geoAddress: '',
        houseNo: '',
        landmark: '',
        geoLatitude : '',
        geoLongitude : '',
        pincode: '',
        partnerId: this.loggedUser.userId,
        isActive: true,
        cityName: '',
        createdBy: '',
        stateName: ''
    }
  }

  GetVirtualOffices() {
    if (this.loggedUser.userId > 0) {
      this._virtualOfficeService.GetByPartnerId(this.loggedUser.userId)
        .subscribe(respons => {
          debugger;
          this.virtualOffices = respons;
        this.dataSource.data = this.virtualOffices;
        },
          error => console.log("Error :: " + error)
        );
    }
    else {
      this.toastr.warning("Somthing wrong, Please try again.");
    }
  }


  openDialog4InsertUpdate(vOffice: VirtualOffice) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = vOffice;
    dialogConfig.width = "650px";
    let dialogRef = this.dialog.open(CreateOfficeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      if (returnObj) {
        this.GetVirtualOffices();
      }
    });
  }


  InsertEntity() {
    this.SetModalDefaultValue();
    this.openDialog4InsertUpdate(this.virtualOfficeObj);
  }

  
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


}
