import { Component, OnInit, Inject } from '@angular/core';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { MatDialogRef, MAT_DIALOG_DATA, MatAutocompleteSelectedEvent } from '@angular/material';
import { VirtualofficeService } from 'src/app/_services/virtualoffice.service';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { VirtualOffice } from 'src/app/modals/virtualOffice';
import { CommonService } from 'src/app/_services/common.service';
import { CityState } from 'src/app/modals/cityState';
import { NgxSpinnerService } from "ngx-spinner";
import { GoogleAPIGeoAddressResultDto } from 'src/app/modals/commonDtos';

@Component({
  selector: 'app-create-office',
  templateUrl: './create-office.component.html',
  styleUrls: ['./create-office.component.scss']
})
export class CreateOfficeComponent implements OnInit {

  insertOrUpdateObj: VirtualOffice;
  loggedUser: any;
  btnSubmitText: string;
  frmVirtualOffice: FormGroup;
  cityStateObjs: CityState;
  geoAddressFiltered: GoogleAPIGeoAddressResultDto[];
  geoAddressSelected: GoogleAPIGeoAddressResultDto;

  constructor(
    private _loggedUserService: LoggedUserService,
    private _virtualOfficeService: VirtualofficeService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private _commonService: CommonService,
    private _ngxSpinnerService: NgxSpinnerService,
    private dialogRef: MatDialogRef<CreateOfficeComponent>,
    @Inject(MAT_DIALOG_DATA) data: VirtualOffice) {
    this.insertOrUpdateObj = data;
  }


  ngOnInit() {
    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    };
    this.cityStateObjs = new CityState();
    this.btnSubmitText = "Save";

    this.frmVirtualOffice = this.formBuilder.group({
      vOfficeId: ['0'],
      // packageAmount: ['', Validators.required],
      // address1: ['', Validators.required],
      area: ['', Validators.required],
      blockNo: ['', Validators.required],
      cityId: ['0', Validators.required],
      vOfficeName: ['', Validators.required],
      contactName: ['', Validators.required],
      contactNo: ['', Validators.required],
      floorNo: ['', Validators.required],
      geoAddress: ['', Validators.required],
      houseNo: ['', Validators.required],
      isActive: [true, Validators.required],
      landmark: ['', Validators.required],
      geoLatitude: ['', Validators.required],
      geoLongitude: ['', Validators.required],
      pincode: ['', Validators.required],
      cityName: ['', Validators.required],
      stateName: ['', Validators.required]
    });


    if (this.insertOrUpdateObj.vOfficeId > 0) {
      this.btnSubmitText = "Update";
      //this.partnerUpdateId = this.partnerObj.partnerId;
      this.frmVirtualOffice.controls['vOfficeId'].setValue(this.insertOrUpdateObj.vOfficeId);
      // this.frmVirtualOffice.controls['address1'].setValue(this.insertOrUpdateObj.address1);
      this.frmVirtualOffice.controls['area'].setValue(this.insertOrUpdateObj.area);
      this.frmVirtualOffice.controls['blockNo'].setValue(this.insertOrUpdateObj.blockNo);
      this.frmVirtualOffice.controls['cityId'].setValue(this.insertOrUpdateObj.cityId);
      this.frmVirtualOffice.controls['vOfficeName'].setValue(this.insertOrUpdateObj.vOfficeName);
      this.frmVirtualOffice.controls['contactName'].setValue(this.insertOrUpdateObj.contactName);
      this.frmVirtualOffice.controls['contactNo'].setValue(this.insertOrUpdateObj.contactNo);
      this.frmVirtualOffice.controls['floorNo'].setValue(this.insertOrUpdateObj.floorNo);
      this.frmVirtualOffice.controls['geoAddress'].setValue(this.insertOrUpdateObj.geoAddress);
      this.frmVirtualOffice.controls['houseNo'].setValue(this.insertOrUpdateObj.houseNo);
      this.frmVirtualOffice.controls['isActive'].setValue(this.insertOrUpdateObj.isActive);
      this.frmVirtualOffice.controls['landmark'].setValue(this.insertOrUpdateObj.landmark);
      this.frmVirtualOffice.controls['geoLatitude'].setValue(this.insertOrUpdateObj.geoLatitude);
      this.frmVirtualOffice.controls['geoLongitude'].setValue(this.insertOrUpdateObj.geoLongitude);
      this.frmVirtualOffice.controls['pincode'].setValue(this.insertOrUpdateObj.pincode);
      this.frmVirtualOffice.controls['cityName'].setValue(this.insertOrUpdateObj.cityName);
      this.frmVirtualOffice.controls['stateName'].setValue(this.insertOrUpdateObj.stateName);
      this.frmVirtualOffice.controls['geoLatitude'].setValue(this.insertOrUpdateObj.cityName);
      this.frmVirtualOffice.controls['stateName'].setValue(this.insertOrUpdateObj.stateName);
    }
  }

  onKeydownPincode(event: any) {
    var pinCode = event.target.value;
    if (pinCode.length == 6) {
      this._ngxSpinnerService.show();
      if (parseInt(pinCode)) {
        this._commonService.GetValidatePinCode(this.loggedUser.userId,pinCode).subscribe(res => {
          this.cityStateObjs = res;
          if (this.cityStateObjs != null) {
            this.frmVirtualOffice.controls['cityName'].setValue(this.cityStateObjs.cityName);
            this.frmVirtualOffice.controls['cityId'].setValue(this.cityStateObjs.cityId);
            this.frmVirtualOffice.controls['stateName'].setValue(this.cityStateObjs.stateName);
          }
          this._ngxSpinnerService.hide();
        })
      }
    }
    else {
      this.frmVirtualOffice.controls['cityName'].setValue('');
      this.cityStateObjs.cityName = '';
      this.frmVirtualOffice.controls['stateName'].setValue('');
      this.cityStateObjs.stateName = '';
      this.frmVirtualOffice.controls['geoAddress'].setValue('');
      this.cityStateObjs.cityId = 0;
      this.frmVirtualOffice.controls['cityId'].setValue('');
      this.geoAddressSelected.geoPlaceName = '';
      this.geoAddressSelected.geoPlaceId = '';

      this.frmVirtualOffice.controls['geoLatitude'].setValue('');
      this.insertOrUpdateObj.geoLatitude = '';

      this.frmVirtualOffice.controls['GeoLongitude'].setValue('');
      this.insertOrUpdateObj.geoLongitude = '';
    }
  }

  onClickInsertOrUpdate() {
    var vOfficeObj = this.frmVirtualOffice.value as VirtualOffice;
    if (vOfficeObj.vOfficeId == 0) {
      this.InsertEntity(this.frmVirtualOffice.value);
    }
    else {
      this.UpdateEntity(this.frmVirtualOffice.value);
    }
  }


  close() {
    this.dialogRef.close(false);
  }

  onChangeGeoAddress(event: any) {
    var searchGeostr = event.target.value;
    if (searchGeostr.length > 2) {
      if (this.cityStateObjs != null) {
        var cityName = this.frmVirtualOffice.controls['cityName'].value;
        var pinCode = this.frmVirtualOffice.controls['pincode'].value;
        if (cityName.length > 3 && pinCode.length == 6) {
          this._commonService.GetGeoAddress(searchGeostr, pinCode, cityName, 530)
            .subscribe(data => {
              this.geoAddressFiltered = data;
            })
        }
        else {
          this.toastr.warning("something wrong. Please try again");
        }
      }
      else {
        this.toastr.warning("Please enter valid Pincode.");

        this.geoAddressSelected.geoPlaceName = '';
        this.geoAddressSelected.geoPlaceId = '';

        this.frmVirtualOffice.controls['geoLatitude'].setValue('');
        this.insertOrUpdateObj.geoLatitude = '';

        this.frmVirtualOffice.controls['geoLongitude'].setValue('');
        this.insertOrUpdateObj.geoLongitude = '';

      }
    }
    else {

    }
  }

  onSelectionChanged(event: MatAutocompleteSelectedEvent) {
    this.geoAddressSelected = this.geoAddressFiltered.find(prev => prev.geoPlaceId = event.option.value);
    this.frmVirtualOffice.controls['geoAddress'].setValue(this.geoAddressSelected.geoPlaceName);
    if (this.loggedUser.userId > 0) {
      this._commonService.GetLatLongByPlaceId(this.loggedUser.userId, this.geoAddressSelected.geoPlaceId)
        .subscribe(respons => {
          if (respons != null) {
            this.frmVirtualOffice.controls['geoLatitude'].setValue(respons.lat);
            this.insertOrUpdateObj.geoLatitude = respons.lat;

            this.frmVirtualOffice.controls['geoLongitude'].setValue(respons.lng);
            this.insertOrUpdateObj.geoLongitude = respons.lng;
          }
        },
          error => {
            console.log("Error (GetData) :: " + error)
            this.toastr.error(error.statusText);
            this.frmVirtualOffice.controls['geoLatitude'].setValue('');
            this.insertOrUpdateObj.geoLatitude = '';

            this.frmVirtualOffice.controls['geoLongitude'].setValue('');
            this.insertOrUpdateObj.geoLongitude = '';

            this.frmVirtualOffice.controls['geoAddress'].setValue('');
          }
        );


      console.log(event.option.value);
    }
    else {
      this.toastr.warning("somthing wrong, Try again.");
    }
  }

  // convenience getter for easy access to form fields
  get f() { return this.frmVirtualOffice.controls; }

  InsertEntity(VofficeObj: VirtualOffice) {

    VofficeObj.partnerId = this.loggedUser.userId;
    this._virtualOfficeService.SetNewEntity(VofficeObj)
      .subscribe(respons => {
        if(respons!=null) {
        this.toastr.success('Saved Successfully');
        this.dialogRef.close(true);
        }
        else{
          this.toastr.error('Something wrong, Try again.');
          this.dialogRef.close(false);
        }
      },
        error => {
          console.log("Error (GetData) :: " + error)
          this.toastr.error(error.statusText);
          this.dialogRef.close(false);
        }
      );
  }

  UpdateEntity(VofficeObj: VirtualOffice) {
    this.toastr.success('Update Successfully');
    // VofficeObj.createdBy = this.loggedUser.userId;
    // this._virtualOfficeService.SetNewOffice(VofficeObj)
    //   .subscribe(respons => {
    //     this.toastr.success('Update Successfully');
    //   },
    //     error => {
    //       console.log("Error (GetData) :: " + error)
    //       this.toastr.error(error.statusText);
    //     }
    //   );
  }


  getAllErrors(form: FormGroup | FormArray): { [key: string]: any; } | null {
    let hasError = false;
    const result = Object.keys(form.controls).reduce((acc, key) => {
      const control = form.get(key);
      const errors = (control instanceof FormGroup || control instanceof FormArray)
        ? this.getAllErrors(control)
        : control.errors;
      if (errors) {
        acc[key] = errors;
        hasError = true;
      }
      return acc;
    }, {} as { [key: string]: any; });
    return hasError ? result : null;
  }

}
