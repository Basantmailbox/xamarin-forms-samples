import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource, } from '@angular/material';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { OrderService } from 'src/app/_services/order.service';
import { OrderHistoryDayWise } from 'src/app/modals/order';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { MatDialogConfig } from '@angular/material/dialog';
import { MypartnerHistoryOnedayComponent } from '../mypartner-history-oneday/mypartner-history-oneday.component';

@Component({
  selector: 'app-mypartner-history-daywise',
  templateUrl: './mypartner-history-daywise.component.html',
  styleUrls: ['./mypartner-history-daywise.component.scss']
})
export class MypartnerHistoryDaywiseComponent implements OnInit {

  displayedColumns: string[] = ['orderDate', 'pickedOrder', 'pickedRevenue', 'partnerEarning','myEarning','viewDetails'];
  dataSource = new MatTableDataSource<OrderHistoryDayWise>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  creditAllocatedObjs: OrderHistoryDayWise[];
  urlPartnerId:string;
  loggedUser:any;

  constructor(
    private _orderService: OrderService,
    private toastr: ToastrService,
    private _loggedUserService: LoggedUserService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    ) {
    //   this.urlPartnerId= this.route.paramMap.pipe(map(params => params.get('pId'))); 
    //  const id: Observable<string> = route.params.pipe(map(p => p.pId));
    //  console.log( this.urlPartnerId + " " + id);
      this.route.paramMap.subscribe(params => {
        console.log()
       this.urlPartnerId=params.get('pid').toString();

      });

     }

  ngOnInit() {
    this.loggedUser={
      userId: this._loggedUserService.getUserId()
    }

    this.loadOrderHistory();
  }

  loadOrderHistory() {

    if(this.urlPartnerId!=null && this.urlPartnerId!=undefined && this.urlPartnerId!=""){
      this._orderService.GetPartnerHistoryDayWise(Number(this.urlPartnerId))
      .subscribe(respons => {
        this.creditAllocatedObjs= respons;
        this.dataSource.data = this.creditAllocatedObjs;
          },
            error => console.log("Error (GetData) :: " + error)
          );
    }
    else{
      this._orderService.GetPartnerHistoryDayWise(this.loggedUser.userId)
      .subscribe(respons => {
        this.creditAllocatedObjs= respons;
        this.dataSource.data = this.creditAllocatedObjs;
        },
          error => console.log("Error (GetData) :: " + error)
        );
    }
    
  }

  openOneDayHistory(entityObj: OrderHistoryDayWise) {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = entityObj;
    dialogConfig.width = "850px";
    let dialogRef = this.dialog.open(MypartnerHistoryOnedayComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      debugger;
      if (returnObj) {
       
      }

    });

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
 

}
