import { Component, OnInit, ElementRef } from '@angular/core';
import { PackageService } from 'src/app/_services/package.service';
import { ToastrService } from 'ngx-toastr';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { Package } from 'src/app/modals/package';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDatepickerInputEvent } from '@angular/material';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/shared/mat-datepicker';
import { CustomerBooking } from 'src/app/modals/customer';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})
export class BookingComponent implements OnInit {

  loggedUser: any;
  allPackageObjs: Package[];
  selectedPackageObjs: Package[] = [];
  public filterPackageStr: any = '';
  totalBookingAmount: number = 0;
  formCustomerDetails: FormGroup;
  addedCustomerObjs: CustomerBooking[] = [];
  addCustomerBtnLbl: string = "Add";
  minDate = new Date();
  maxDate = new Date(2100, 0, 1);

  bookingSteps: BookingSteps;

  constructor(
    private elementRef: ElementRef,
    private _packageService: PackageService,
    private toastr: ToastrService,
    private _loggedUserService: LoggedUserService,
    private _ngxSpinnerService: NgxSpinnerService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {

    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "assets/js/script.js";
    this.elementRef.nativeElement.appendChild(s);

    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    }

    this.loadHWPackages();
    this.bookingSteps = new BookingSteps;

    this.reSetTabs();
    this.bookingSteps.IsActiveTestDetails = true;
    this.reSetTabsProcessDone();

    this.createCustomerDetailsForm();

    //Onload Testing Active
    this.reSetTabs();
    this.bookingSteps.IsActivePickLocation = true;
    this.bookingSteps.IsProcessDoneCustomerDetails = true;
  }

  createCustomerDetailsForm() {
    this.formCustomerDetails = this.formBuilder.group({
      mobileNo: ['', [Validators.required]],
      emailId: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      relation: ['SELF', [Validators.required]],
      gender: ['MALE', [Validators.required]],
      age: ['', [Validators.required]],
      dateOfBirth: [Date, [Validators.required]],
      bCORequire: ['NO', [Validators.required]],
      payment: ['AlreadyPaid', [Validators.required]]
    });
  }

  loadHWPackages() {
    this._ngxSpinnerService.show();
    this.allPackageObjs = [];
    if (this.loggedUser.userId > 0) {
      this._packageService.GetPackage4Booking(this.loggedUser.userId)
        .subscribe(respons => {
          this.allPackageObjs = respons;
          this._ngxSpinnerService.hide();
        },
          error => {
            this._ngxSpinnerService.hide();
            this.toastr.warning("Ohh ! Test or Packags not found.");
            console.log("Error (GetData) :: " + error)
          }
        );
    }
    else {
      this._ngxSpinnerService.hide();
    }
  }


  setMinMaxPickupDate() {

    this.minDate = new Date();
  this.maxDate = new Date(2100, 0, 1);

       // this.formCustomerDetails.controls['age'].setValue('');
       // this.formCustomerDetails.controls['firstName'].setValue('');

      var today = new Date();
      var dd = today.getDate() + parseInt('10');
      var mm = today.getMonth() + 1; //January is 0!
      var yyyy: any;
      
        yyyy = today.getFullYear();
   

      var dayNo: string;
      var monthNo: string;
      if (dd < 10) {
        dayNo = '0' + dd.toString();
      }
      else {
        dayNo = dd.toString();
      }

      if (mm < 10) {
        monthNo = '0' + mm;
      }
      else {
        monthNo = mm.toString();
      }

      var newYeardate = new Date(yyyy, mm, dd);
      this.formCustomerDetails.controls['dateOfBirth'].setValue(newYeardate);
    //}
    // else {

    //   this.formCustomerDetails.controls['dateOfBirth'].setValue('');
    // }
  }


  onClickAddPackage4Test(selectedPackage: Package) {
    selectedPackage.isSelected = true;
    this.totalBookingAmount = this.totalBookingAmount + (selectedPackage.actualPrice * 1);
  }

  onClickRemovePackage4Test(selectedPackage: Package) {
    selectedPackage.isSelected = false;
    this.totalBookingAmount = this.totalBookingAmount - selectedPackage.actualPrice;
  }

  onClickTabTestDetail() {
    this.reSetTabs();
    this.bookingSteps.IsActiveTestDetails = true;
  }

  onClickTabCustomerDetails() {
    // this.reSetTabs();
    // this.bookingSteps.IsActiveCustomerDetails = true;
    this.onClickContinueTestDetail();
  }

  onClickTabPickLocation() {
    this.reSetTabs();
    this.bookingSteps.IsActivePickLocation = true;
  }

  onClickTabOrderSummary() {
    this.reSetTabs();
    this.bookingSteps.IsActiveOrderSummary = true;
  }

  onClickTabPaymentMode() {
    this.reSetTabs();
    this.bookingSteps.IsActivePaymentMode = true;
  }

  reSetTabs() {
    this.bookingSteps.IsActiveTestDetails = false;
    this.bookingSteps.IsActiveCustomerDetails = false;
    this.bookingSteps.IsActiveOrderSummary = false;
    this.bookingSteps.IsActivePickLocation = false;
    this.bookingSteps.IsActivePaymentMode = false;
  }
  reSetTabsProcessDone() {
    this.bookingSteps.IsProcessDoneTestDetails = false;
    this.bookingSteps.IsProcessDoneCustomerDetails = false;
    this.bookingSteps.IsProcessDoneOrderSummary = false;
    this.bookingSteps.IsProcessDonePickLocation = false;
    this.bookingSteps.IsProcessDonePaymentMode = false;
  }

  onClickContinueTestDetail() {
    this.selectedPackageObjs = [];
    if (this.totalBookingAmount > 100) {
      this.reSetTabs();
      this.allPackageObjs.forEach(x => {
        if (x.isSelected) { this.selectedPackageObjs.push(x); }
      });


      this.bookingSteps.IsActiveCustomerDetails = true;
      this.bookingSteps.IsProcessDoneTestDetails = true;
    }
    else {
      this.toastr.warning("Please select Package and Test");
      this.reSetTabs();
      this.bookingSteps.IsActiveTestDetails = true;
    }
  }

  onClickContinueCustomerDetails() {
    debugger;
    if (this.totalBookingAmount > 100) {
      if (this.addedCustomerObjs.length > 0) {
        this.reSetTabs();
        this.bookingSteps.IsActivePickLocation = true;
        this.bookingSteps.IsProcessDoneCustomerDetails = true;
      }
      else {
        this.toastr.warning("Please Add Customer Details.");
        this.reSetTabs();
        this.bookingSteps.IsActiveCustomerDetails = true;
      }
    }
    else {
      this.toastr.warning("Please select Package and Test");
      this.reSetTabs();
      this.bookingSteps.IsActiveCustomerDetails = true;
    }

  }

  onClickContinuePickLocation() {

    if (this.totalBookingAmount > 100) {
      this.reSetTabs();
      this.bookingSteps.IsActiveOrderSummary = true;
      this.bookingSteps.IsProcessDonePickLocation = true;
    }
    else {
      this.toastr.warning("Please select Package and Test");
      this.reSetTabs();
      this.bookingSteps.IsActivePickLocation = true;
    }

  }

  onClickContinueOrderSummary() {

    if (this.totalBookingAmount > 100) {
      this.reSetTabs();
      this.bookingSteps.IsActivePaymentMode = true;
      this.bookingSteps.IsProcessDoneOrderSummary = true;
    }
    else {
      this.toastr.warning("Please select Package and Test");
      this.reSetTabs();
      this.bookingSteps.IsActiveOrderSummary = true;
    }


  }

  onClickContinuePaymentMode() {
    this.reSetTabs();
    this.bookingSteps.IsActivePaymentMode = true;
  }

  onClickAddCustomer() {
    var customerObj = this.formCustomerDetails.value as CustomerBooking;

    var newCustomer = new CustomerBooking();

    if (customerObj.mobileNo.length == 0) {
      this.toastr.warning("Please Enter Mobile No !");
      return false;
    }
    else {
      newCustomer.mobileNo = customerObj.mobileNo;
    }

    if (customerObj.emailId.length == 0) {
      this.toastr.warning("Please Enter Email Id !");
      return false;
    }
    else {
      newCustomer.emailId = customerObj.emailId;
    }
    if (customerObj.firstName.length == 0) {
      this.toastr.warning("Please Enter First Name !");
      return false;
    }
    else {
      newCustomer.firstName = customerObj.firstName;
    }

    if (customerObj.lastName.length == 0) {
      this.toastr.warning("Please Enter Last Name !");
      return false;
    }
    else {
      newCustomer.lastName = customerObj.lastName;
    }

    if (customerObj.relation.length == 0) {
      this.toastr.warning("Please select Package and Test");
      return false;
    }
    else {
      newCustomer.relation = customerObj.relation;
    }


    if (customerObj.gender.length == 0) {
      this.toastr.warning("Please Select Gender !");
      return false;
    }
    else {
      newCustomer.gender = customerObj.gender;
    }


    if (customerObj.age.length == 0) {
      this.toastr.warning("Please Enter Age !");
      return false;
    }
    else {
      newCustomer.age = customerObj.age;
    }

    if (customerObj.dateOfBirth == null) {
      this.toastr.warning("Please Select Date Of Borth");
      return false;
    }
    else {
      newCustomer.dateOfBirth = customerObj.dateOfBirth;
    }

    if (customerObj.bCORequire.length == null) {
      this.toastr.warning("Please Select BCO Require !");
      return false;
    }
    else {
      newCustomer.bCORequire = customerObj.bCORequire;
    }

    if (customerObj.payment.length == null) {
      this.toastr.warning("Please Selecct Payment");
      return false;
    }
    else {
      newCustomer.payment = customerObj.payment;
    }

    if (this.selectedPackageObjs.length > 0) {
      this.selectedPackageObjs.forEach(d => { newCustomer.packages.push(d); });
    }
    else {
      this.toastr.warning("Please Package and Test");
      return false;
    }

    this.addedCustomerObjs.push(newCustomer);

    this.createCustomerDetailsForm();
    this.addCustomerBtnLbl = "Add Another Person for Same Package";
  }
  onClickAddAnotherPackageCustomer() {

    if (this.addedCustomerObjs.length > 0) {
      this.reSetTabs();
      this.allPackageObjs.forEach(x => { x.isSelected = false; });

      this.bookingSteps.IsActiveTestDetails = true;
      this.addCustomerBtnLbl = "Add";
      // this.bookingSteps.IsProcessDoneTestDetails = true;
    }
    else {
      this.toastr.warning("Please Add customer Details");
      this.reSetTabs();
      this.bookingSteps.IsActiveCustomerDetails = true;
    }



  }

  onChangeAge() {
    var ageField = this.formCustomerDetails.controls['age'];
    if (ageField.status == 'VALID' && ageField.value != '') {
      if (parseInt(ageField.value) > 150) {
        this.toastr.warning("age can not be more than 150 !");
        this.formCustomerDetails.controls['age'].setValue('');
        this.formCustomerDetails.controls['firstName'].setValue('');
        return false;
      }


      debugger;
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth() + 1; //January is 0!
      var yyyy: any;
      if (ageField.value != "") {
        yyyy = today.getFullYear() - parseInt(ageField.value);
      }
      else {
        yyyy = today.getFullYear();
      }
      var dayNo: string;
      var monthNo: string;
      if (dd < 10) {
        dayNo = '0' + dd.toString();
      }
      else {
        dayNo = dd.toString();
      }

      if (mm < 10) {
        monthNo = '0' + mm;
      }
      else {
        monthNo = mm.toString();
      }

      var newYeardate = new Date(yyyy, mm, dd);
      this.formCustomerDetails.controls['dateOfBirth'].setValue(newYeardate);
    }
    else {

      this.formCustomerDetails.controls['dateOfBirth'].setValue('');
    }
  }

  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {

    var dobField = event.value;
    var ageField = this.formCustomerDetails.controls['age'];
    if (dobField != null) {
      var today = new Date();
      var dd = today.getDate();
      var mm = today.getMonth() + 1; //January is 0!
      var yyyy = today.getFullYear();
      var dayNo: string;
      var monthNo: string;

      if (dd < 10) {
        dayNo = '0' + dd.toString();
      }

      if (mm < 10) {
        monthNo = '0' + mm.toString();
      }

      if (new Date(yyyy + "-" + mm + "-" + dd) >= new Date(dobField)) {
        var bob_date = new Date(dobField);
        var bob_date_dd = bob_date.getDate();
        var bob_date_mm = bob_date.getMonth();
        var bob_date_yyyy = bob_date.getFullYear();
        var age = Number(yyyy) - Number(bob_date_yyyy);
        if (age >= 0) {
          this.formCustomerDetails.controls['age'].setValue(age);
        }
        else {
          this.toastr.warning('Date of birth should be lower than current date.');
          this.formCustomerDetails.controls['dateOfBirth'].setValue('');
        }
      }
      else {
        this.toastr.warning('Date of birth should be lower than current date.');
        this.formCustomerDetails.controls['dateOfBirth'].setValue('');
      }
    }
    else{
      this.formCustomerDetails.controls['age'].setValue('');
    }
  }


}

export class BookingSteps {
  public IsActiveTestDetails: boolean = true;
  public IsActiveCustomerDetails: boolean;
  public IsActivePickLocation: boolean;
  public IsActiveOrderSummary: boolean;
  public IsActivePaymentMode: boolean;

  public IsProcessDoneTestDetails: boolean;
  public IsProcessDoneCustomerDetails: boolean;
  public IsProcessDonePickLocation: boolean;
  public IsProcessDoneOrderSummary: boolean;
  public IsProcessDonePaymentMode: boolean;
}
