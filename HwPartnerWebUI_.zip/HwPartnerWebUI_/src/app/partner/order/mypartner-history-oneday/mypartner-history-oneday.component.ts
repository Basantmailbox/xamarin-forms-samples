import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OrderService } from 'src/app/_services/order.service';
import { OrderHistoryDayWise } from 'src/app/modals/order';

@Component({
  selector: 'app-mypartner-history-oneday',
  templateUrl: './mypartner-history-oneday.component.html',
  styleUrls: ['./mypartner-history-oneday.component.scss']
})
export class MypartnerHistoryOnedayComponent implements OnInit {

 
  historyObjs:OrderHistoryDayWise[];
  selectedHistoryObj:OrderHistoryDayWise;
  constructor(
    private _orderService: OrderService, 
    private dialogRef: MatDialogRef<MypartnerHistoryOnedayComponent>,
    @Inject(MAT_DIALOG_DATA) data: OrderHistoryDayWise) {
      this.selectedHistoryObj=data;
  }

  ngOnInit() {
    this.bindHistory();
  }

  
  bindHistory(){
    debugger;
    if(this.selectedHistoryObj!=null && this.selectedHistoryObj!=undefined){
      this._orderService.GetPartnerHistoryOneDay(this.selectedHistoryObj.partnerId, this.selectedHistoryObj.orderDate)
      .subscribe(respons => {
        this.historyObjs = respons;
      },
        error => console.log("Error (GetData) :: " + error)
      );
    }
}


  close() {
    this.dialogRef.close(null);
  }

}
