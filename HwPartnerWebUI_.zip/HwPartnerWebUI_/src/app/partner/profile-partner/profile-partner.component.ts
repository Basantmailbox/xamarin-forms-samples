import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-partner',
  templateUrl: './profile-partner.component.html',
  styleUrls: ['./profile-partner.component.scss']
})
export class ProfilePartnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
