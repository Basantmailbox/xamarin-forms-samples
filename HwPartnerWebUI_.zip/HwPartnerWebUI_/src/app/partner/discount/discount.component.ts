import { Component, OnInit } from '@angular/core';
import { DiscountGlobal } from 'src/app/modals/globalDiscount';
import { GlobaldiscountService } from 'src/app/_services/globaldiscount.service';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material';

@Component({
  selector: 'app-discount',
  templateUrl: './discount.component.html',
  styleUrls: ['./discount.component.scss']
})
export class DiscountComponent implements OnInit {

  discountGlobal: DiscountGlobal;
  discountValue: number = 0;
  formGlobalDiscount: FormGroup;

  constructor(
    private fb: FormBuilder,
    private _globalDiscount: GlobaldiscountService,
    private _loggedUserService: LoggedUserService,
    private toastr: ToastrService
  ) { }

  ngOnInit() {
    this.createForm();
    this.discountGlobal = new DiscountGlobal();
    this.discountGlobal.partnerId = this._loggedUserService.getUserId();
    this.onLoadBindDiscount();
  }

  createForm() {
    this.formGlobalDiscount = this.fb.group({
      globalDiscount: ['', Validators.required],
      fromDate: ['', Validators.required],
      toDate: ['', Validators.required]
    });
  }


  onLoadBindDiscount() {
    if (this.discountGlobal.partnerId > 0) {
      this._globalDiscount.GetByPartnerId(this.discountGlobal.partnerId).subscribe(respons => {
        debugger;
        if (respons != null) {

          this.discountGlobal = respons as DiscountGlobal;
          if (this.discountGlobal.partnerId == 0) {
            this.formGlobalDiscount.controls['globalDiscount'].setValue("0");
            this.formGlobalDiscount.controls['toDate'].setValue(new Date());
            this.formGlobalDiscount.controls['fromDate'].setValue(new Date());
       
          }
          else {
            this.formGlobalDiscount.controls['globalDiscount'].setValue(this.discountGlobal.globalDiscount);
            this.formGlobalDiscount.controls['toDate'].setValue(this.discountGlobal.toDate);
            this.formGlobalDiscount.controls['fromDate'].setValue(this.discountGlobal.fromDate);
          }
          // this.toastr.error('Server Error');
        }
        else {
          this.toastr.error('Server Error');
        }
      },
        error => {
          console.log("Error : " + error)
          this.toastr.error(error);
        }
      );
    }
  }

  onChangeUpdateDiscount(event) {
    this.discountValue = event.value;
    this.discountGlobal.globalDiscount = event.value;
  }

  onChangeToDate(type: string, event: MatDatepickerInputEvent<Date>) {
    this.formGlobalDiscount.controls['toDate'].setValue(event.value);
    this.discountGlobal.toDate = event.value;
  }

  onChangeFromDate(type: string, event: MatDatepickerInputEvent<Date>) {
    this.formGlobalDiscount.controls['fromDate'].setValue(event.value);
    this.discountGlobal.fromDate = event.value;

  }
  onClickSetDiscount() {
    debugger;

    var globalDiscount = this.formGlobalDiscount.controls['globalDiscount'];
    if (globalDiscount.status == 'VALID') {
      this.discountGlobal.globalDiscount = globalDiscount.value;
    }
    else {
      this.toastr.warning("Please select Discount.");
      return false;
    }

    var toDate = this.formGlobalDiscount.controls['toDate'];
    if (toDate.status == 'VALID') {
      this.discountGlobal.toDate = toDate.value;
    }
    else {
      this.toastr.warning("Please Select Valid To Date.");
      return false;
    }

    var fromDate = this.formGlobalDiscount.controls['fromDate'];
    if (fromDate.status == 'VALID') {
      this.discountGlobal.fromDate= fromDate.value;
    }
    else {
      this.toastr.warning("Please Select Valid From Date.");
      return false;
    }

    this.discountGlobal.partnerId = this._loggedUserService.getUserId();

    if (this.discountGlobal.partnerId > 0) {
      this._globalDiscount.InsertOrUpdate(this.discountGlobal).subscribe(respons => {
        debugger;
        if (respons != null) {
          this.toastr.success("Ok Set");
        }
        else {
          this.toastr.error('Server Error');
        }
      },
        error => {
          console.log("Error : " + error)
          this.toastr.error(error);
        }
      );
    }

  }

}

