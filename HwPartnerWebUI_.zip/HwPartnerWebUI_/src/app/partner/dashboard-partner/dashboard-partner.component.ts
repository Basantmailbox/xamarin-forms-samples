import { Component, OnInit, DebugElement } from '@angular/core';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { Router } from '@angular/router';
import { RoleType } from 'src/app/shared/enumApp';

@Component({
  selector: 'app-dashboard-partner',
  templateUrl: './dashboard-partner.component.html',
  styleUrls: ['./dashboard-partner.component.scss']
})
export class DashboardPartnerComponent implements OnInit {
  info: any;
  roleId: Number;
  isPLATINUM:boolean;
  isGOLD:boolean;
  isSILVER:boolean;

  constructor(private token: LoggedUserService, private router: Router) { }

  ngOnInit() {
debugger;

    this.roleId= this.token.getRoleId();
    if(RoleType.PLATINUM==this.roleId){
      // this.isPLATINUM=true;
      this.router.navigate(["/partner/dashboard-platinum"]);
    }
    else if(RoleType.GOLD==this.roleId){
      // this.isGOLD=true;
      this.router.navigate(["/partner/dashboard-gold"]);
    }
    else if(RoleType.SILVER==this.roleId){
      // this.isSILVER=true;
      this.router.navigate(["/partner/dashboard-silver"]);
    }
    else if(RoleType.VOFFOCE==this.roleId){
      // this.isSILVER=true;
      this.router.navigate(["/partner/dashboard-silver"]);
    }

  }
  
}
