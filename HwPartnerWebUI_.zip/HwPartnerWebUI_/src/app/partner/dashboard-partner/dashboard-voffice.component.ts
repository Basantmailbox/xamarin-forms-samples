import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-voffice',
  templateUrl: './dashboard-voffice.component.html',
  styleUrls: ['./dashboard-voffice.component.scss']
})
export class DashboardVofficeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
