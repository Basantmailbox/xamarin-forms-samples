import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-silver',
  templateUrl: './dashboard-silver.component.html',
  styleUrls: ['./dashboard-silver.component.scss']
})
export class DashboardSilverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
