import { Component, OnInit } from '@angular/core';
import { PartnerService } from 'src/app/_services/partner.service';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { Partner } from 'src/app/modals/partner';

@Component({
  selector: 'app-dashboard-platinum',
  templateUrl: './dashboard-platinum.component.html',
  styleUrls: ['./dashboard-platinum.component.scss']
})
export class DashboardPlatinumComponent implements OnInit {

  minBalanceMyPartners: Partner[];
  partnerObj: Partner;
  loggedUser:any;
  
  constructor(
    private _partnerService: PartnerService,
    private _loggedUserService: LoggedUserService

  ) { }

  ngOnInit() {
    this.loggedUser={
      userId: this._loggedUserService.getUserId()
    }
this.loadMinBalanceMyPartners();
  }

  

  loadMinBalanceMyPartners() {
    debugger;
    this._partnerService.GetMinBalanceMyPartners(this.loggedUser.userId)
      .subscribe(respons => {
        debugger;
        this.minBalanceMyPartners = respons;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }

}
