import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-gold',
  templateUrl: './dashboard-gold.component.html',
  styleUrls: ['./dashboard-gold.component.scss']
})
export class DashboardGoldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
