import { Component, Input, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Partner } from 'src/app/modals/partner';
import { ToastrService } from 'ngx-toastr';
import { PartnerService } from 'src/app/_services/partner.service';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


// export interface Food {
//   value: string;
//   viewValue: string;
// }

@Component({
  selector: 'app-create-partner',
  templateUrl: './create-partner.component.html',
  styleUrls: ['./create-partner.component.scss']
})

export class CreatePartnerComponent implements OnInit {

  partnerObj: Partner;
  partnerForm: FormGroup;
  submitted = false;
  partnerUpdateId: number;
  loggedUser: any;
  btnSubmitText: string;

  constructor(
    private _loggedUserService: LoggedUserService,
    private _partnerService: PartnerService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<CreatePartnerComponent>,
    @Inject(MAT_DIALOG_DATA) data: Partner) 
    {
    this.partnerObj = data;
    }


  onClickInsertOrUpdate() {
    this.InsertOrUpdateEntity(this.partnerForm.value);
  }

  close() {
    this.dialogRef.close(false);
  }

  ngOnInit() {
    debugger;
    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    };
    this.btnSubmitText = "Save";
   // this.partnerUpdateId = 0;
    this.partnerForm = this.formBuilder.group({
      partnerId: ['0'],
      partnerName: ['', [Validators.required]],
      emailId: ['', [Validators.required, Validators.email]],
      mobileNo: ['', [Validators.required]],
      partnerTypeId: ['81', Validators.required],
      isAcceptTerm: [false, Validators.requiredTrue]
    });


    // alert(this.partnerObj.partnerId);
    if (this.partnerObj.partnerId > 0) {
      this.btnSubmitText = "Update";
      //this.partnerUpdateId = this.partnerObj.partnerId;
      this.partnerForm.controls['partnerId'].setValue(this.partnerObj.partnerId);
      this.partnerForm.controls['partnerName'].setValue(this.partnerObj.partnerName);
      this.partnerForm.controls['emailId'].setValue(this.partnerObj.emailId);
      this.partnerForm.controls['mobileNo'].setValue(this.partnerObj.mobileNo);
      this.partnerForm.controls['partnerTypeId'].setValue(this.partnerObj.partnerTypeId);
    }

  }

  // convenience getter for easy access to form fields
  get f() { return this.partnerForm.controls; }

  InsertOrUpdateEntity(partner: Partner) {
    debugger;

    var fullNameField = this.partnerForm.controls['partnerName'];
    if (fullNameField.status == 'VALID' && fullNameField.value != '') {

      this.partnerObj.partnerName = fullNameField.value;
    }
    else {
      this.toastr.warning("Please Full Name");
      return false;
    }

    partner.createdBy = this.loggedUser.userId;

    if (partner.partnerId == 0) {
      partner.availableCredit='0';
      partner.isActive=true;
      this.insertNewEntity(partner);
      }
      else {
      this.updateEntity(partner);
      }
    }


  insertNewEntity(partner: Partner) {
    this._partnerService.InsertNewEntity(partner).subscribe(
      respons => {
        this.toastr.success('Saved Successfully');
        this.dialogRef.close(true);
      },
      error => {
        console.log("Error (GetData) :: " + error)
        this.toastr.error(error.statusText);
      }
    );

  }

  updateEntity(partner: Partner) {
    this._partnerService.UpdateEntity(partner).subscribe(
      respons => {
        this.toastr.success('Update Successfully');
        this.dialogRef.close(true);
      },
      error => {
        console.log("Error (GetData) :: " + error)
        this.toastr.error(error.statusText);
      }
    );
  }


}
