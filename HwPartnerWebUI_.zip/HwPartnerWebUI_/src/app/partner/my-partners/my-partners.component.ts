import { Component, OnInit, ViewChild } from '@angular/core';
import { PartnerService } from 'src/app/_services/partner.service';
import { Partner } from 'src/app/modals/partner';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { CreatePartnerComponent } from './create-partner.component';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { LoggedUser } from 'src/app/modals/loggedUser';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';

@Component({
  selector: 'app-my-partners',
  templateUrl: './my-partners.component.html',
  styleUrls: ['./my-partners.component.scss']
})


export class MyPartnersComponent implements OnInit {


  displayedColumns: string[] = ['fullName', 'mobileNo', 'emailId', 'partnerTypeName','status','Action'];
  dataSource = new MatTableDataSource<Partner>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  
  myPartners: Partner[];
  modalPartnerHeader: string;
  isRequest4New: boolean;
  isShowModal: boolean;
  partnerObj: Partner;
  loggedUser:any;
  
  constructor(
    private _partnerService: PartnerService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private _loggedUserService: LoggedUserService
  ) { }

  ngOnInit() {


    this.loggedUser={
      userId: this._loggedUserService.getUserId()
    }

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.loadMyPartner();
    this.modalPartnerHeader = "Create";

    this.partnerObj = {
      partnerId: 0,
      emailId: '',
      partnerName: '',
      mobileNo: '',
      partnerTypeId: 45,
      partnerType: '',
      createdBy: this.loggedUser.userId,
      availableCredit:'0',
      isActive:false,
      isNew: true,
      earning:"0",
      displayRoleName:''
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

      openDialog4InsertUpdate(partnerEntity: Partner) {

        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.data = partnerEntity;
        dialogConfig.width="550px";
        let dialogRef = this.dialog.open(CreatePartnerComponent, dialogConfig);
        dialogRef.afterClosed().subscribe(returnObj => {
          debugger;
          if(returnObj){
            this.loadMyPartner();
          }
         
        });

      }



  InsertEntity() {
    this.partnerObj = {
      partnerId: 0,
      emailId: '',
      partnerName: '',
      mobileNo: '',
      partnerTypeId: 45,
      partnerType: '',
      createdBy: this.loggedUser.userId,
      availableCredit:'0',
      isActive : false,
      isNew: true,
      earning:"0",
      displayRoleName:''
    }
    this.openDialog4InsertUpdate(this.partnerObj);
    
    // this.isRequest4New=true;
    //this.modalPartnerHeader = "Create";
    //this.modalService.open(id);
  }



  loadMyPartner() {
    debugger;
    this._partnerService.GetMyPartner(this.loggedUser.userId)
      .subscribe(respons => {
        debugger;
        this.myPartners = respons;
        this.dataSource.data = this.myPartners;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }

  UpdateEntity(entityObj: Partner) {
   // this.modalPartnerHeader = "Update";
    this.partnerObj.partnerId = entityObj.partnerId;
    this.partnerObj.emailId = entityObj.emailId;
    this.partnerObj.partnerName = entityObj.partnerName;
    this.partnerObj.mobileNo = entityObj.mobileNo;
    this.partnerObj.partnerTypeId = entityObj.partnerTypeId;
    this.partnerObj.createdBy= this.loggedUser.userId,
    this.partnerObj.isActive= entityObj.isActive,
    this.partnerObj.isNew=false;
    this.openDialog4InsertUpdate(this.partnerObj);
    // this.modalService.open("modalPartner");
    // debugger;
  }

  deleteEntity(entityObj) {

  }

}
