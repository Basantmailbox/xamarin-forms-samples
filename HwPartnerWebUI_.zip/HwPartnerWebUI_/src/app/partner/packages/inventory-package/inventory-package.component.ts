import { Component, OnInit, ViewChild } from '@angular/core';
import { Package } from 'src/app/modals/package';
// import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { PackageService } from 'src/app/_services/package.service';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { PackageDetailsComponent } from '../package-details/package-details.component';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-inventory-package',
  templateUrl: './inventory-package.component.html',
  styleUrls: ['./inventory-package.component.scss']
})

export class InventoryPackageComponent implements OnInit {

  displayedColumns: string[] = ['packageName', 'ActualPrice', 'OfferPrice', 'createdDate', 'viewDetails'];
  dataSource = new MatTableDataSource<Package>();
  packageObjs: Package[];
  loggedUser: any;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;



  constructor(
    private _packageService: PackageService,
    private _loggedUserService: LoggedUserService,
    private dialog: MatDialog,
    private toastr: ToastrService
  ) { }

  ngOnInit() {
    this.loggedUser = {
      userId: this._loggedUserService.getUserId()
    }
    this.loadMyPackages();
  }

  
  loadMyPackages() {
    if (this.loggedUser.userId > 0) {
      this._packageService.GetMyPackages(this.loggedUser.userId)
        .subscribe(respons => {
          this.packageObjs = respons;
          this.dataSource.data = this.packageObjs;
        },
          error => console.log("Error (GetData) :: " + error)
        );
    }
  }

  onClickViewDetails(packageobj: Package) {
    if (packageobj.packageId > 0) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.data = packageobj;
      dialogConfig.width = "650px";
      let dialogRef = this.dialog.open(PackageDetailsComponent, dialogConfig);
      dialogRef.afterClosed().subscribe(returnObj => {

      });
    }
    else {
      this.toastr.warning("Please try again.");
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
