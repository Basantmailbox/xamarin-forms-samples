import { Component, OnInit, Inject } from '@angular/core';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Package } from 'src/app/modals/package';
import { PackageService } from 'src/app/_services/package.service';


@Component({
  selector: 'app-package-details',
  templateUrl: './package-details.component.html',
  styleUrls: ['./package-details.component.scss']
})
export class PackageDetailsComponent implements OnInit {

  partnerObj: Package;
  packageObjs: Package[];

  constructor(
    private _packageService: PackageService,
    private dialogRef: MatDialogRef<PackageDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) data: Package) {
    this.partnerObj = data;
  }


  ngOnInit() {
    if (this.partnerObj.partnerId > 0) {
      this.loadPackageDetails();
    }
  }

  
  loadPackageDetails() {
    if (this.partnerObj.partnerId > 0) {
      this._packageService.GetMyPackageDetails(this.partnerObj.partnerId, this.partnerObj.packageId)
        .subscribe(respons => {
          this.packageObjs = respons;
        },
          error => console.log("Error (GetData) :: " + error)
        );
    }
  }

  close() {
    this.dialogRef.close(false);
  }
}
