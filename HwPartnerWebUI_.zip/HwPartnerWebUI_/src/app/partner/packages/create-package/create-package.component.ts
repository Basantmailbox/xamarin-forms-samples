import { Component, OnInit, ViewChild } from '@angular/core';
import { Package } from 'src/app/modals/package';
import { PackageService } from 'src/app/_services/package.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { Partner } from 'src/app/modals/partner';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-create-package',
  templateUrl: './create-package.component.html',
  styleUrls: ['./create-package.component.scss']
})
export class CreatePackageComponent implements OnInit {

  hwPackageObjs: Package[];
  selectedPackageObjs: Package[];
  newPackageObj: Package;
  frmPackage: FormGroup;
  actualPrice: number;
  loggedUser: any;
  displayedColumns: string[] = ['packageName', 'actualPrice', 'packageType', 'action'];
  dataSource = new MatTableDataSource<Package>();

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private _packageService: PackageService,
    private _loggedUserService: LoggedUserService,
    private toastr: ToastrService

  ) {
    this.createForm();
  }

  ngOnInit() {
    this.actualPrice = 0;
    this.selectedPackageObjs = [];
    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    };
    this.loadHWPackages();
  }

  createForm() {
    this.frmPackage = this.fb.group({
      packageName: ['', Validators.required],
      packageAmount: ['', Validators.required]
    });
  }


  loadHWPackages() {
    this._packageService.GetHWPackages()
      .subscribe(respons => {
        this.hwPackageObjs = respons;
        this.dataSource.data = this.hwPackageObjs;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  onClickAdd(hwPackageObj: Package) {
    debugger;
    this.selectedPackageObjs.push(hwPackageObj);

    const index: number = this.hwPackageObjs.indexOf(hwPackageObj);
    if (index !== -1) {
      this.hwPackageObjs.splice(index, 1);
    }
    this.dataSource.data = this.hwPackageObjs;
    this.calculateActualAmount();
  }

  calculateActualAmount() {

    this.actualPrice = 0;
    if (this.selectedPackageObjs != null && this.selectedPackageObjs.length > 0) {
      this.selectedPackageObjs.forEach(x => this.actualPrice += Number(x.actualPrice));
    }
  }

  onClickDelete(packageObj: Package) {
    debugger;
    this.hwPackageObjs.push(packageObj);

    const index: number = this.selectedPackageObjs.indexOf(packageObj);
    if (index !== -1) {
      this.selectedPackageObjs.splice(index, 1);
    }
    this.dataSource.data = this.hwPackageObjs;
    this.calculateActualAmount();
  }

  onClickAddPackage() {
    this.newPackageObj = new Package();

    if (this.selectedPackageObjs.length < 2) {
      this.toastr.warning("Please select Package.");
      return false;
    }
    else {
      debugger;
      this.newPackageObj.mappedPkgIds = Array.prototype.map.call(this.selectedPackageObjs, function (item) { return item.packageId; }).join(",");
    }


    var packageName = this.frmPackage.controls['packageName'];
    if (packageName.status == 'VALID') {
      this.newPackageObj.packageName = packageName.value;
    }
    else {
      this.toastr.warning("Please select Discount.");
      return false;
    }

    var packageAmount = this.frmPackage.controls['packageAmount'];
    if (packageAmount.status == 'VALID') {
      this.newPackageObj.offerPrice = packageAmount.value;
    }
    else {
      this.toastr.warning("Please select Discount.");
      return false;
    }
    this.newPackageObj.actualPrice = this.actualPrice;

    

    if (this.loggedUser.userId > 0) {
      this.newPackageObj.partnerId=this.loggedUser.userId;
      this._packageService.InserNew(this.newPackageObj).subscribe(res => {
          if (res != null) {
            debugger;
            var ddd=res as Partner;
            this.toastr.success("Package Successfully Inserted.</br> You Earning : &#8377;"+  this.actualPrice +" /-");
            this.router.navigate(['/partner/packages']);
          }
      });
    }
    else {
      this.toastr.warning("Sorry Action not valid.");
    }


  }
}
