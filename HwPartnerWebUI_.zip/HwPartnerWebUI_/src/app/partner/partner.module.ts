import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PartnerRoutingModule } from './partner-routing.module';
import { ProfilePartnerComponent } from './profile-partner/profile-partner.component';
import { DashboardPartnerComponent } from './dashboard-partner/dashboard-partner.component';
import { DashboardGoldComponent } from './dashboard-partner/dashboard-gold.component';
import { DashboardSilverComponent } from './dashboard-partner/dashboard-silver.component';
import { DashboardPlatinumComponent } from './dashboard-partner/dashboard-platinum.component';
import { MyPartnersComponent } from './my-partners/my-partners.component';
import { BuyComponent } from './credit/buy/buy.component';
import { AllocateComponent } from './credit/allocate/allocate.component';
import { CustomerComponent } from './reports/customer/customer.component';
import { HistoryComponent } from './transaction/history/history.component';
import { InboxComponent } from './inbox/inbox.component';
import { TrainingListComponent } from './training/training-list/training-list.component';
import { FaqComponent } from './faq/faq.component';
import { CreatePackageComponent } from './packages/create-package/create-package.component';
import { InventoryPackageComponent } from './packages/inventory-package/inventory-package.component';
import { CreateOfficeComponent } from './virtualOffice/create-office.component';
import { InventoryOfficeComponent } from './virtualOffice/inventory-office.component';
import { DiscountComponent } from './discount/discount.component';
import { CreatePartnerComponent } from './my-partners/create-partner.component';
import { ModalModule } from '../shared/_modal';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr'; 
import { DashboardVofficeComponent } from './dashboard-partner/dashboard-voffice.component';
import { InventoryPromocodeComponent } from './promocode/inventory-promocode.component';
import { CreatePromocodeComponent } from './promocode/create-promocode.component';
import { RechargePromocodeComponent } from './promocode/recharge-promocode.component';
import { AppMaterialModule } from '../_core/appMaterialModule';
import { httpInterceptorProviders } from '../auth/auth-interceptor';
import { NumericDirective } from "../shared/directives/numeric.directive";
import { MypartnerTransactionsComponent } from './credit/mypartner-transactions/mypartner-transactions.component';
import { AddCreditComponent } from './credit/add-credit/add-credit.component';
import { MypartnerHistoryDaywiseComponent } from './order/mypartner-history-daywise/mypartner-history-daywise.component';
import { MypartnerHistoryOnedayComponent } from './order/mypartner-history-oneday/mypartner-history-oneday.component';
import { BookingComponent } from './order/booking/booking.component';
import { SpentComponent } from './reports/spent/spent.component';
import { PackageDetailsComponent } from './packages/package-details/package-details.component';
import { SendCustomerReportComponent } from './reports/customer/send-customer-report.component';
import { SendEmailCustomerReportComponent } from './reports/customer/send-email-customer-report.component';
import { SendWhatsappCustomerReportComponent } from './reports/customer/send-whatsapp-customer-report.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import {  AppFilterPipe } from '../shared/filter.pipe';
import { SearchPipe } from '../shared/pipes/appfilter.pipe';


@NgModule({
  declarations: [
    NumericDirective,
    ProfilePartnerComponent,
    DashboardPartnerComponent,
    DashboardGoldComponent,
    DashboardSilverComponent,
    DashboardPlatinumComponent,
    MyPartnersComponent,
    BuyComponent,
    AllocateComponent,
    CustomerComponent,
    HistoryComponent,
    InboxComponent,
    TrainingListComponent,
    FaqComponent,
    CreatePackageComponent,
    InventoryPackageComponent,
    CreateOfficeComponent,
    InventoryOfficeComponent,
    BookingComponent,
    DiscountComponent,
    CreatePartnerComponent,
    DashboardVofficeComponent,
    InventoryPromocodeComponent,
    CreatePromocodeComponent,
    RechargePromocodeComponent,
    MypartnerTransactionsComponent,
    AddCreditComponent,
    MypartnerHistoryDaywiseComponent,
    MypartnerHistoryOnedayComponent,
    SpentComponent,
    PackageDetailsComponent,
    SendCustomerReportComponent,
    SendEmailCustomerReportComponent,
    SendWhatsappCustomerReportComponent,
    AppFilterPipe,
    SearchPipe
  ],
  imports: [
    CommonModule,
    PartnerRoutingModule,
    ModalModule,
    FormsModule,
    ReactiveFormsModule,
    AppMaterialModule,
    NgxSpinnerModule,
    ToastrModule.forRoot(
      {  
        closeButton: true,
        timeOut: 6000, 
        progressBar: true,
        enableHtml: true
      }  
    ),
  ],
  exports: [
    AppMaterialModule
  ],
  providers: [httpInterceptorProviders],
  entryComponents: [
    CreatePartnerComponent, 
    CreateOfficeComponent, 
    CreatePromocodeComponent,
    RechargePromocodeComponent,
    MypartnerTransactionsComponent,
    AddCreditComponent,
    MypartnerHistoryOnedayComponent,
    PackageDetailsComponent,
    SendCustomerReportComponent,
    SendEmailCustomerReportComponent,
    SendWhatsappCustomerReportComponent
]

})

export class PartnerModule { }
