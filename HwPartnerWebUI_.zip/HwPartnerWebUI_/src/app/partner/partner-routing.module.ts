import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardPartnerComponent } from './dashboard-partner/dashboard-partner.component';
import { ProfilePartnerComponent } from './profile-partner/profile-partner.component';
import { DashboardGoldComponent } from './dashboard-partner/dashboard-gold.component';
import { DashboardSilverComponent } from './dashboard-partner/dashboard-silver.component';
import { DashboardPlatinumComponent } from './dashboard-partner/dashboard-platinum.component';
import { BuyComponent } from './credit/buy/buy.component';
import { MyPartnersComponent } from './my-partners/my-partners.component';
import { AllocateComponent } from './credit/allocate/allocate.component';
import { HistoryComponent } from './transaction/history/history.component';
import { CustomerComponent } from './reports/customer/customer.component';
import { InventoryPackageComponent } from './packages/inventory-package/inventory-package.component';
import { CreatePackageComponent } from './packages/create-package/create-package.component';
import { DiscountComponent } from './discount/discount.component';
import { InventoryOfficeComponent } from './virtualOffice/inventory-office.component';
import { InboxComponent } from './inbox/inbox.component';
import { TrainingListComponent } from './training/training-list/training-list.component';
import { FaqComponent } from './faq/faq.component';
import { CreatePartnerComponent } from './my-partners/create-partner.component';
import { InventoryPromocodeComponent } from './promocode/inventory-promocode.component';
import { MypartnerHistoryDaywiseComponent } from './order/mypartner-history-daywise/mypartner-history-daywise.component';
import { BookingComponent } from './order/booking/booking.component';
import { SpentComponent } from './reports/spent/spent.component';

const routes: Routes = [
  { path: '',  component: DashboardPartnerComponent },
  { path: 'dashboard',  component: DashboardPartnerComponent },
  { path: 'dashboard-gold',  component: DashboardGoldComponent },
  { path: 'dashboard-silver',  component: DashboardSilverComponent },
  { path: 'dashboard-platinum',  component: DashboardPlatinumComponent },
  { path: 'credits/buy',  component: BuyComponent },
  { path: 'my-partners',  component: MyPartnersComponent },
  { path: 'my-partners/create',  component: CreatePartnerComponent },
  { path: 'credits/allocate',  component: AllocateComponent },
  { path: 'order/booking',  component: BookingComponent },
  { path: 'transaction/history',  component: HistoryComponent },
  { path: 'reports/spent',  component: SpentComponent },
  { path: 'reports/customer',  component: CustomerComponent },
  { path: 'packages',  component: InventoryPackageComponent },
  { path: 'package/create',  component: CreatePackageComponent },
  { path: 'set-discounts',  component: DiscountComponent },
  { path: 'virtual-offices',  component: InventoryOfficeComponent },
  { path: 'inbox',  component: InboxComponent },
  { path: 'training',  component: TrainingListComponent },
  { path: 'faq',  component: FaqComponent },
  { path: 'profile', component: ProfilePartnerComponent },
  { path: 'promocodes', component: InventoryPromocodeComponent },
  { path: 'order/partnerhistorydaywise/:pid',  component:  MypartnerHistoryDaywiseComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PartnerRoutingModule { }
