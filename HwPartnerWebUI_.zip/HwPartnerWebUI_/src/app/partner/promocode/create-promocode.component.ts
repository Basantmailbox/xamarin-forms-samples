import { Component, OnInit, Inject } from '@angular/core';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { PromoCode } from 'src/app/modals/Promocode';
import { PromocodeService } from 'src/app/_services/promocode.service';
import { DateAdapter, MAT_DATE_FORMATS} from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/shared/mat-datepicker';

@Component({
  selector: 'app-create-promocode',
  templateUrl: './create-promocode.component.html',
  styleUrls: ['./create-promocode.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: AppDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS}
  ]
})

export class CreatePromocodeComponent implements OnInit {

  insertOrUpdateObj: PromoCode;
  loggedUser: any;
  btnSubmitText: string;
  insertOrUpdateFormObj: FormGroup;

  constructor(
    private _loggedUserService: LoggedUserService,
    private _promocodeService: PromocodeService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private dialogRef: MatDialogRef<CreatePromocodeComponent>,
    @Inject(MAT_DIALOG_DATA) data: PromoCode) {

    this.insertOrUpdateObj = data;
  }

  ngOnInit() {
    debugger;
    this.loggedUser = {
      userId: this._loggedUserService.getUserId(),
      roleId: this._loggedUserService.getRoleId()
    };
    this.btnSubmitText = "Save";

    this.insertOrUpdateFormObj = this.formBuilder.group({
      promoCodeId: ['0'],
      promoCodeName: ['', [Validators.required]],
      minAmount: ['', [Validators.required]],
      promoType: ['B', [Validators.required]],
      discount: ['', [Validators.required]],
      discountType: ['A', [Validators.required]],
      validTo: [Date, [Validators.required]],
      validFrom: [Date, [Validators.required]],
      description: ['', [Validators.required]]
    });


    if (this.insertOrUpdateObj.promoCodeId > 0) {
      this.btnSubmitText = "Update";
      this.insertOrUpdateFormObj.controls['promoCodeId'].setValue(this.insertOrUpdateObj.promoCodeId);
      this.insertOrUpdateFormObj.controls['promoCodeName'].setValue(this.insertOrUpdateObj.promoCodeName);
      this.insertOrUpdateFormObj.controls['minAmount'].setValue(this.insertOrUpdateObj.minAmount);
      this.insertOrUpdateFormObj.controls['promoType'].setValue(this.insertOrUpdateObj.promoType);
      this.insertOrUpdateFormObj.controls['discount'].setValue(this.insertOrUpdateObj.discount);
      this.insertOrUpdateFormObj.controls['validTo'].setValue(this.insertOrUpdateObj.validTo);
      this.insertOrUpdateFormObj.controls['validFrom'].setValue(this.insertOrUpdateObj.validFrom);
      this.insertOrUpdateFormObj.controls['discountType'].setValue(this.insertOrUpdateObj.discountType);
      this.insertOrUpdateFormObj.controls['description'].setValue(this.insertOrUpdateObj.description);
    }
  }

  onClickInsertOrUpdate() {
    this.InsertOrUpdateEntity(this.insertOrUpdateFormObj.value);
  }

  close() {
    this.dialogRef.close(false);
  }

  // convenience getter for easy access to form fields
  get f() { return this.insertOrUpdateFormObj.controls; }

  InsertOrUpdateEntity(entityObj: PromoCode) {
    entityObj.userId = this.loggedUser.userId;
    if (entityObj.promoCodeId == 0) {
      this._promocodeService.InsertNew(entityObj)
        .subscribe(respons => {
          if (entityObj.promoCodeId == 0) {
            this.toastr.success('Saved Successfully');
            this.dialogRef.close(true);
          }
          else {
            this.toastr.success('Update Successfully');
            this.dialogRef.close(true);
          }
        },
          error => {
            console.log("Error (GetData) :: " + error)
            this.toastr.error(error.statusText);
          }
        );
    }
    else {

    }
  }
}
