import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {MatSort} from '@angular/material/sort';

import { PromoCode } from 'src/app/modals/Promocode';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { LoggedUserService } from 'src/app/auth/logged-user.service';
import { CreatePromocodeComponent } from '../promocode/create-promocode.component';
import { PromocodeService } from 'src/app/_services/promocode.service';


@Component({
  selector: 'app-inventory-promocode',
  templateUrl: './inventory-promocode.component.html',
  styleUrls: ['./inventory-promocode.component.scss']
})
export class InventoryPromocodeComponent implements OnInit {

  displayedColumns: string[] = ['promoCodeName', 'discount', 'description', 'isActive','Action'];
  dataSource = new MatTableDataSource<PromoCode>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  promoCodeObjs: PromoCode[];
  modalPartnerHeader: string;
  isRequest4New: boolean;
  isShowModal: boolean;
  promoCodeObj: PromoCode;
  loggedUser: any;
  constructor(
    private _promocodeService: PromocodeService,
    private toastr: ToastrService,
    private dialog: MatDialog,
    private _loggedUserService: LoggedUserService
  ) { }

  ngOnInit() {
     
    this.loggedUser = {
      userId: this._loggedUserService.getUserId()
    }
    this.resetModal();

    this.loadPromoCode();
    this.modalPartnerHeader = "Create";

    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  resetModal() {
    this.promoCodeObj = {
      promoCodeId: 0,
      promoCodeName: '',
      promoType: 'B',
      discount: '',
      description: '',
      createdDate: '',
      userName: '',
      userId: this.loggedUser.userId,
      isActive: false,
      isNew: true,
      discountType: 'A',
      validFrom: new Date(),
      validTo: new Date(),
      minAmount: 0,
      isExpired: false,
      appliedCounter:0
    }
  }

  openDialog4InsertUpdate(entityObj: PromoCode) {

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = entityObj;
    dialogConfig.width = "520px";
    let dialogRef = this.dialog.open(CreatePromocodeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(returnObj => {
      debugger;
      if (returnObj) {
        this.loadPromoCode();
      }

    });

  }


  InsertEntity() {
    this.resetModal();
    this.openDialog4InsertUpdate(this.promoCodeObj);

  }


  loadPromoCode() {
    debugger;
    this._promocodeService.GetMyPartner(this.loggedUser.userId)
      .subscribe(respons => {
        debugger;
        
        this.promoCodeObjs= respons;
        this.dataSource.data = this.promoCodeObjs;
      },
        error => console.log("Error (GetData) :: " + error)
      );
  }

  UpdateEntity(entityObj: PromoCode) {
    this.promoCodeObj.promoCodeId = entityObj.promoCodeId;
    this.promoCodeObj.description = entityObj.description;
    this.promoCodeObj.discount = entityObj.discount;
    this.promoCodeObj.discountType = entityObj.discountType;
    this.promoCodeObj.promoCodeName = entityObj.promoCodeName;
    this.promoCodeObj.promoType = entityObj.promoType;
    this.promoCodeObj.userId = this.loggedUser.userId,
      this.promoCodeObj.isActive = entityObj.isActive,
      this.promoCodeObj.isNew = false;
    this.openDialog4InsertUpdate(this.promoCodeObj);
  }

  deleteEntity(entityObj) {

  }


}
