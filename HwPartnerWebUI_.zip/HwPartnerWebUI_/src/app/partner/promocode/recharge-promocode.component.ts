import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PromoCode } from 'src/app/modals/Promocode';
import { PromocodeService } from 'src/app/_services/promocode.service';

@Component({
  selector: 'app-recharge-promocode',
  templateUrl: './recharge-promocode.component.html',
  styleUrls: ['./recharge-promocode.component.scss']
})

export class RechargePromocodeComponent implements OnInit {

  selectedPromoObj: PromoCode;
  promoCodeObjs:PromoCode[];
  constructor(
    private _promocodeService: PromocodeService, 
    private dialogRef: MatDialogRef<RechargePromocodeComponent>,
    @Inject(MAT_DIALOG_DATA) data: string) {
  }

  ngOnInit() {
    this.bindPromoCode();
  }


bindPromoCode(){
  this._promocodeService.GetValidRechargePromo()
  .subscribe(respons => {
    debugger;
    this.promoCodeObjs = respons;
  },
    error => console.log("Error (GetData) :: " + error)
  );
}

  close() {
    this.dialogRef.close(null);
  }
  onSelectPromo(selectedPromoObj:PromoCode){
    // this.selectedPromoObj=new PromoCode();
    // this.selectedPromoObj.promoCodeName="TestPromo20";
    this.dialogRef.close(selectedPromoObj);
  }

  
}
