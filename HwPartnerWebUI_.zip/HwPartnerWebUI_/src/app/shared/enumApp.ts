export enum RoleType {
    ADMIN = 44,
    PLATINUM = 45,
    VOFFOCE = 46,
    SILVER = 81,
    GOLD = 82
}


export enum PromoType {
    BOOKING = 'B',
    RECHARGE = 'R'
}

export enum EnumPaymentMode {
    BANK_TRANSFER = 1,
    CASH = 2,
    //CHECK=3,
    CARD = 4,
    PAYTM = 5
}
