
//generic libs
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//auth libs
import { AuthService } from '../auth/auth.service';
import { LoggedUserService } from '../auth/logged-user.service';
import { LoginRequest } from '../auth/login-request';
import { RoleType } from '../shared/enumApp';
import { ToastrService } from 'ngx-toastr';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roleName: string;
  roleId: number;
  private loginInfo: LoginRequest;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private tokenStorage: LoggedUserService,
    private router: Router,
    private toastr: ToastrService) { }

  ngOnInit() {
   
    if (this.tokenStorage.getToken()) {
      this.isLoggedIn = true;
      this.roleName = this.tokenStorage.getRoleName();
    }

    this.loginForm = this.formBuilder.group({
      loginId: ['', Validators.required],
      password: ['', Validators.required]
    });


    // get return url from route parameters or default to '/'
    // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  onSubmit() {

    //this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    else {

      console.log(this.loginForm);
      debugger;
      var data = this.loginForm.value;
      this.loginInfo = new LoginRequest(data.loginId, data.password);

      if (this.loginInfo.LoginId != undefined && this.loginInfo.Password != undefined) {
        this.authService.attemptAuth(this.loginInfo).subscribe(
          data => {
            if (data.partnerId > 0 && data.roleId > 0) {
              //data local

              this.tokenStorage.saveToken(data.token);
              this.tokenStorage.saveUserId(data.partnerId);
              //this.tokenStorage.saveUsername(data.userName);
              this.tokenStorage.saveRoleName(data.roleName);
              this.tokenStorage.saveBalance(data.balance);
              this.tokenStorage.saveFullName(data.partnerName);
              this.tokenStorage.saveRoleId(data.roleId);


              this.isLoginFailed = false;
              this.isLoggedIn = true;
              this.roleName = this.tokenStorage.getRoleName();
              this.roleId = this.tokenStorage.getRoleId();

              if (RoleType.ADMIN == this.roleId) {
                //redirection to home
                this.router.navigate(["/admin"]);
              }
              else if (RoleType.PLATINUM == this.roleId || RoleType.GOLD == this.roleId || RoleType.SILVER == this.roleId) {
                this.router.navigate(["/partner"]);
              }
              // else if(RoleType.GOLD==this.roleId)
              // {
              //   this.router.navigate(["/partner/gold"]);
              // }
              // else if(RoleType.SILVER==this.roleId)
              // {
              //   this.router.navigate(["/partner/silver"]);
              // }
              else {
                this.toastr.error("Please enter valid UserName and Password", "Login");
                this.router.navigate(["/"]);
              }

            }
            else {
              this.toastr.error("Please enter valid UserName and Password", "Login");
            }

          },
          error => {
            debugger;
            if (error.status == 0) {
              this.toastr.error("Oh ! Server Not Responding.");
              //this.errorMessage = error.error.message;
              this.isLoginFailed = true;
            }
            else {
              console.log('Login Error ' + error.name);
              this.toastr.warning("Oh ! Server Not Responding.");
            }
          });

      }
      else {
        this.toastr.warning("Please Enter Login details.");
      }
    }
  }

  }