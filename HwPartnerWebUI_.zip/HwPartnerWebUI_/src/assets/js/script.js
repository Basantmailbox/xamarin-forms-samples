
$(document).ready(function(){
    // Sidebar toggle behavior
 
    $('#sidebarCollapse').on('click', function() {
      $('#mySidenav, #main').toggleClass('active');
    });
    $('.owl-carousel').owlCarousel({
      loop: false,
      margin: 10,
      nav: true,
      navText: [
        "<i class='fa fa-caret-left'></i>",
        "<i class='fa fa-caret-right'></i>"
      ],
      autoplay: false,
      autoplayHoverPause: true,
      responsive: {
        0: {
          items: 1
        },
        577:{
          items: 2
        },
        1000: {
          items: 3
        },
        1110:{
          items:3
        }
      }
    });
 
});

