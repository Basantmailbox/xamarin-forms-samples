﻿//define the Angular module 
var config = angular.module('app');


config.controller('config', function ($scope, $http,toaster,$modal) {

    $scope.configs = [];
    $scope.isEdit = false;
    $scope.Value = 0;
    var configObj = {
        Id: 0,
        ConfigCode: "",
        Description: "",
        TypeIndicator: 0,
        Value: 0,
        show:true
    }
    $scope.config = {
        Id: 0,
        ConfigCode: "",
        Description: "",
        TypeIndicator: 0,
        Value: 0,
        show: true
    }

    $scope.getAllConfig = function () {
        $http.get('/api/GeneralConfigs').success(function (data) {
            $scope.configs = data;
        }).error(function () {
            $scope.error = "An Error has occurred while loading Configurations!";
            toaster.pop('error', 'Error', $scope.error);
                })
    }
    $scope.getAllConfig();

   

    $scope.updateConfig = function (index, id, isEdit) {
        $scope.configObject = {};
        $scope.valueFetched = false;
        $http.get('/api/GeneralConfigs/' + id).success(function (data) {
            if (data.TypeIndicator == 2 || data.TypeIndicator == 3) {
                $scope.configObject = {
                    ConfigCode: data.COnfigCode,
                    Description: data.Description,
                    Id: data.Id,
                    TypeIndicator: data.TypeIndicator,
                    Value: parseInt(data.Value),
                    show: true
                }
            }
            if (data.TypeIndicator == 10) {
                $scope.configObject = {
                    ConfigCode: data.COnfigCode,
                    Description: data.Description,
                    Id: data.Id,
                    TypeIndicator: data.TypeIndicator,
                    Value: data.Value,
                    show: true
                }
            }
            openModal($scope.configObject);
        }).error(function (data) {
           
        });
    }
    function openModal(obj) {
        var modalInstance = $modal.open({
            templateUrl: 'ConfigModal.html',
            controller: 'ConfigModalPopUpCtrl',
            backdrop: 'static',
            size: 'lg',
            scope: $scope,
            resolve: {
                obj: function () {
                    return obj;
                }
            }
        });
        modalInstance.result.then(function (obj) {
            if (obj != "")
            {
                //update the list
                var indx = 0;
                angular.forEach($scope.configs, function (value, index) {
                    if (value.Id == obj.Id) {
                        indx = index;
                    }
                })
                $scope.configs[indx].Value = obj.Value;
                toaster.pop('success', 'Success', "Updated Successfully");
            }
            
        });
    }
})

config.controller('ConfigModalPopUpCtrl', ['$scope', '$http', '$modalInstance', 'obj', 'toaster', '$location',
    function ($scope, $http, $modalInstance,  obj, toaster, location) {
        $scope.config = obj;
        $scope.toggleConfigModal = function () {
            $modalInstance.close("");
        }
        var configObj = {
            Id: 0,
            ConfigCode: "",
            Description: "",
            TypeIndicator: 0,
            Value: 0,
            show: true
        }
        $scope.saveConfig = function () {
            configObj.COnfigCode = $scope.config.ConfigCode;
            configObj.Description = $scope.config.Description
            configObj.Id = $scope.config.Id
            configObj.TypeIndicator = $scope.config.TypeIndicator
            configObj.Value = $scope.config.Value;
            configObj.show = true;
            $http.put('/api/generalconfigs/' + $scope.config.Id, configObj).success(function (data) {
                $modalInstance.close($scope.config);
            }).error(function (data) {
                $scope.error = "an error has occurred while updating configuration! " + data;
                toaster.pop('error', 'Error', $scope.error);
                $modalInstance.close("");
            });
        }
    }]);

