﻿//used by "App\master\Resume\Scripts\app\contract-controller.js"
//used by "App\master\Resume\Scripts\app\departmentConfiguration\js\controllers\departmentCtrl.js"
//used by " App\master\Resume\Scripts\app\proposal-controller.js"
//used by "App\master\Resume\Scripts\app\releasenotes-controller.js"
//used by "App\master\Resume\Scripts\app\rolepermission-controller.js"
//used by "App\master\Resume\Scripts\app\bidtracking-controller.js"
app.filter('myLimitTo', function () {
    return function (input, limit, begin) {
        if (input != null) {
            return input.slice(begin, begin + limit);
        }

    };
})
//used in "App\master\Resume\Scripts\app\customer\partials\customerAddEdit.html"
//used in "App\master\Resume\tpl\app\Partials\Resume\Employment_Tab_Section.html"
app.filter("GetValueName", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Key == Id) {
                name = array[i].Value;
                break;
            }
        }
        return name;
    }
});
//used in the Bid Page..   "tpl/app/BidTracking.html"
app.filter("GetBiddingConstantName", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].Constant;
                break;
            }
        }
        return name;
    }
})
//used in "App\master\Resume\tpl\app\Partials\Resume\ResumeView.html"
app.filter("GetTypeName", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].Name;
                break;
            }
        }
        return name;
    }
})
app.filter("GetRelation", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].Name;
                break;
            }
        }
        return name;
    }
});
//used in "App\master\Resume\tpl\app\BidTracking.html"
//used in "App\master\Resume\tpl\app\report.html"
app.filter("DaysToGo", function () {
    return function (data) {

        var daystogo;
        var submitdate;
        var currentdate;
        var timeDiff;

        submitdate = new Date(data);
        currentdate = new Date();
        timeDiff = Math.abs(submitdate.getTime() - currentdate.getTime());
        daystogo = Math.ceil(timeDiff / (1000 * 3600 * 24));

        if (currentdate > submitdate) { daystogo = daystogo * -1; }

        return daystogo;
    }
});
app.filter('phonefilter', function () {
    return function (tel) {
        if (!tel) { return ''; }

        var value = tel.toString().trim().replace(/^\+/, '');

        if (value.match(/[^0-9]/)) {
            return tel;
        }

        var country, city, number;

        switch (value.length) {
            case 10: // +1PPP####### -> C (PPP) ###-####
                country = 1;
                city = value.slice(0, 3);
                number = value.slice(3);
                break;

            case 11: // +CPPP####### -> CCC (PP) ###-####
                country = value[0];
                city = value.slice(1, 4);
                number = value.slice(4);
                break;

            case 12: // +CCCPP####### -> CCC (PP) ###-####
                country = value.slice(0, 3);
                city = value.slice(3, 5);
                number = value.slice(5);
                break;

            default:
                return tel;
        }

        if (country == 1) {
            country = "";
        }

        number = number.slice(0, 3) + '-' + number.slice(3);

        return (country + " (" + city + ") " + number).trim();
    };
});

// A filter for getting uniqe value from array Object
app.filter('unique', function () {
    return function (arr, field) {
        return _.uniq(arr, function (a) { return a[field]; });
    };
});

