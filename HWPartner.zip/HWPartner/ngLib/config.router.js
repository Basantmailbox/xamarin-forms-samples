
'use strict';

/**
 * Config for the router
 */
angular.module('app')
  .run(
    ['$rootScope', '$state', '$stateParams', '$window', '$location',
      function ($rootScope, $state, $stateParams, $window, $location) {
          $rootScope.$state = $state;
          $rootScope.CURRENTROLE = 'Admin';
          $rootScope.$stateParams = $stateParams;
          $window.ga('create', 'UA-38345077-2', 'auto');                  //google analytics code for production
          $window.ga('create', 'UA-104544048-2', 'auto');                  //google analytics code for dev
          $window.ga('create', 'UA-104544048 - 1', 'auto');                  //google analytics code for test

          $rootScope.$on('$stateChangeSuccess', function (event) {
              $window.ga('send', 'pageview', $location.path());            //google analytics code for production
          });
      }
    ]
  )
  .config(
    ['$stateProvider', '$urlRouterProvider',
      function ($stateProvider, $urlRouterProvider) {
          $urlRouterProvider
             .otherwise('/app/dashboard');

          $stateProvider
              .state('app', {
                  abstract: true,
                  url: '/app',
                  templateUrl: '/tpl/app.html'
              })

                .state('apps.release', {
                    url: '/ReleaseNotes',
                    templateUrl: '/tpl/app/Releasenotes.html',
                    resolve: {
                        deps: ['$ocLazyLoad',
                          function ($ocLazyLoad) {
                              return $ocLazyLoad.load(['Scripts/app/releasenotes-controller.js']);
                          }
                        ]
                    }
                })

              .state('app.dashboard', {
                  url: '/dashboard',
                  templateUrl: '/tpl/app/Dashboard.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Services/DashboardGraph-service.js'])
                            .then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/dashboard-controller.js']);
                                })
                        }
                      ]
                  }
              })

              .state('apps.bidTrack', {
                  url: '/BidTracking',
                  templateUrl: 'tpl/app/BidTracking.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Services/Bid-service.js'])
                            .then(
                                 function () {
                                     return $ocLazyLoad.load('textAngular')
                                     .then(
                                         function () {
                                             return $ocLazyLoad.load(['Scripts/app/bidtracking-controller.js'])
                                         });
                                 })
                        }]
                  }
              })

              .state('apps.Contract', {
                  url: '/Contract',
                  templateUrl: '/tpl/app/Contract.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Services/Contract-service.js'])
                            .then(
                                 function () {
                                     return $ocLazyLoad.load('textAngular')
                                     .then(
                                         function () {
                                             return $ocLazyLoad.load(['Scripts/app/contract-controller.js'])
                                         });
                                 })
                        }]
                  }
              })


              .state('apps.ProposalsRpt', {
                  url: '/ProposalsReport',
                  templateUrl: '/tpl/app/report.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/report-controller.js']);
                        }
                      ]
                  }
              })


               .state('apps.Customer', {
                   url: '/Customer',
                   templateUrl: 'Scripts/app/customer/partials/customer.html',
                   controller: 'customerCtrl',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load('textAngular')
                         }]
                   }
               })
               .state('apps.Notes', {
                   url: '/Notes',
                   templateUrl: 'Scripts/app/notes/partials/notes.html',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load(['Scripts/app/notes/js/service/notesService.js'])
                             .then(
                                  function () {
                                      return $ocLazyLoad.load('textAngular')
                                      .then(
                                          function () {
                                              return $ocLazyLoad.load(['Scripts/app/notes/js/controllers/notesCtrl.js'])
                                          });
                                  })
                         }]
                   }
               })
               .state('apps.Department', {
                   url: '/Department',
                   templateUrl: 'Scripts/app/departmentConfiguration/partials/department.html',
                   controller: 'departmentCtrl'
               })

               .state('apps.UserProfile', {
                   url: '/UserProfile',
                   templateUrl: 'Scripts/app/profileConfiguartion/partials/profileTemplate.html',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load(['Scripts/app/profileConfiguartion/js/controllers/profileTemplateCtrl.js']).then(
                                 function () {
                                     return $ocLazyLoad.load(['Scripts/app/profileConfiguartion/js/services/profileServices.js']);
                                 }
                             );
                         }]
                   }
               })

              .state('apps.layout', {
                  url: '/View_Layout',
                  templateUrl: 'Scripts/app/appConfiguration/viewConfig/partials/genericView.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('textAngular').then(
                                function () {
                                    return $ocLazyLoad.load('Scripts/app/appConfiguration/viewConfig/js/controllers/genericViewCtrl.js')
                                    .then(
                                    function () {
                                        return $ocLazyLoad.load(['Scripts/app/appConfiguration/viewConfig/js/services/genericViewService.js']);
                                    });
                                });
                        }]
                  }
              })
              .state('apps.Development', {
                  url: '/Development',
                  templateUrl: 'tpl/app/Development.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('textAngular').then(
                                function () {
                                    return $ocLazyLoad.load('Scripts/app/development-controller.js')
                                    .then(
                                    function () {
                                        return $ocLazyLoad.load(['Scripts/app/Services/BidDevService.js']);
                                    });
                                });
                        }]
                  }
              })
              .state('apps.Partners', {
                  url: '/Partners',
                  templateUrl: 'Scripts/app/Partner/partials/Partner.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Partner/js/services/partnerService.js'])
                                .then({
                                    PartnersData: function () {
                                        return PartnerService.getAllPartners();
                                    }
                                })
                                .then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/Partner/js/controllers/PartnersCtrl.js'])
                                });
                        }
                      ]
                  }
              })
              .state('apps.PriorityRpt', {
                  url: '/PriorityReport',
                  templateUrl: 'Scripts/app/PriorityFollowReport/partials/mainReport.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/PriorityFollowReport/js/service/priorityFollowService.js'])
                                .then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/PriorityFollowReport/js/controllers/mainPFRCtrl.js'])
                                });
                        }
                      ]
                  }
              })
          //------------- RR-535 Start -----------------
            .state('apps.FollowUpRpt', {
                url: '/FollowUpReport',
                templateUrl: 'Scripts/app/FollowUpReport/partials/followUpReport.html',
                resolve: {
                    deps: ['$ocLazyLoad',
                      function ($ocLazyLoad) {
                          return $ocLazyLoad.load(['Scripts/app/FollowUpReport/js/service/followUpService.js'])
                              .then(
                              function () {
                                  return $ocLazyLoad.load(['Scripts/app/FollowUpReport/js/controllers/followUpReportCtrl.js'])
                              });
                      }
                    ]
                }
            })
          
            //------------- RR-535 End -----------------
              //------------- RR-531 Start -----------------
                .state('apps.SpringAhead', {
                    url: '/SpringAhead',
                    templateUrl: 'Scripts/app/SpringAhead/partials/dataReport.html',
                    resolve: {
                        deps: ['$ocLazyLoad',
                          function ($ocLazyLoad) {
                              return $ocLazyLoad.load(['Scripts/app/SpringAhead/js/service/springAheadService.js'])
                                .then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/SpringAhead/js/controllers/springAheadCtrl.js']);
                                });
                          }
                        ]
                    }
                })
              //------------- RR-531 End -----------------

               //------------- RR-552 Start -----------------
                .state('apps.BidTrackingReport', {
                    url: '/OpportunityTracker',
                    templateUrl: 'Scripts/app/BidTrackingReport/partials/dataReport.html',
                    resolve: {
                        deps: ['$ocLazyLoad',
                          function ($ocLazyLoad) {
                              return $ocLazyLoad.load(['Scripts/app/BidTrackingReport/js/service/bidTrackingReportService.js'])
                                .then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/BidTrackingReport/js/controllers/bidTrackingReportCtrl.js']);
                                });
                          }
                        ]
                    }
                })
              //------------- RR-552 End -----------------

              .state('apps.SkillsRpt', {
                  url: '/SkillsReport',
                  templateUrl: '/tpl/app/Reports/SkillsRpt.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Reports/SkillsRpt-controller.js']);
                        }
                      ]
                  }

              })

              .state('apps.TechnologiesRpt', {
                  url: '/TechnologiesReport',
                  templateUrl: '/tpl/app/Reports/TechnologiesRpt.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Reports/TechnologiesRpt-controller.js']);
                        }
                      ]
                  }

              })

              .state('apps.MethodologiesRpt', {
                  url: '/Technologies_Methodologies_Report',
                  templateUrl: '/tpl/app/Reports/MethodologiesRpt.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/Reports/MethodologiesRpt-controller.js']);
                        }
                      ]
                  }

              })

               



              //.state('apps.ProposalsRpt', {
              //    url: '/ProposalsReport',
              //    templateUrl: '/tpl/app/Reports/ProposalsRpt.html',
              //    resolve: {
              //        deps: ['$ocLazyLoad',
              //          function ($ocLazyLoad) {
              //              return $ocLazyLoad.load(['Scripts/app/Reports/ProposalsRpt-controller.js'])
              //               .then(
              //                  function () {
              //                      return $ocLazyLoad.load(['Scripts/app/Services/Proposal-service.js'])
              //                  });
              //          }
              //        ]
              //    }

              //})

              .state('app.config', {
                  url: '/config',
                  templateUrl: '/tpl/config.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/config-controller.js']);
                        }
                      ]
                  }

              })

              .state('app.formconfig', {
                  url: '/FormConfig',
                  templateUrl: 'Scripts/app/appConfiguration/formConfig/partials/formConfig.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/appConfiguration/formConfig/js/controllers/formConfigCtrl.js']).then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/appConfiguration/formConfig/js/services/formConfigService.js']);
                                }
                            );
                        }]
                  }
              })

              .state('app.techsupport', {
                  url: '/Tech-Support',
                  templateUrl: 'tpl/app/Tech-Support.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/techsupport-controller.js']);
                        }]
                  }
              })

               .state('apps.test', {
                   url: '/Test',
                   templateUrl: 'tpl/app/Test.html',

                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load(['Scripts/app/test-controller.js']);
                         }]
                   }
               })

              .state('apps.Profile', {
                  url: '/Profile',
                  templateUrl: 'Home/Profile',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/profile-controller.js'])
                            .then(
                            function () {

                            })
                        }]
                  }
              })

           //.state('apps.Resume', {
           //    url: '/Resume',
           //    templateUrl: 'Home/Resume',
           //    resolve: {
           //        deps: ['$ocLazyLoad',
           //          function ($ocLazyLoad) {
           //              return $ocLazyLoad.load(['Scripts/app/resume-controller.js'])
           //              .then(
           //              function () {
           //                  return $ocLazyLoad.load(['Scripts/app/Services/Activity-service.js']);
           //              });
           //          }]
           //    }
           //})

               .state('apps.Resume', {
                   url: '/Resume',
                   templateUrl: 'Home/Resume',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load('textAngular').then(
                                 function () {
                                     return $ocLazyLoad.load('/js/controllers/editor.js')
                                     .then(
                                         function () {
                                             return $ocLazyLoad.load(['Scripts/app/resume-controller.js'])
                                       .then(
                                           function () {
                                               return $ocLazyLoad.load(['/Scripts/app/Services/Activity-service.js']);
                                           });
                                         });
                                 })
                         }]
                   }

               })


              .state('apps.Requisition', {
                  url: '/Requisition',
                  templateUrl: 'tpl/app/Requisition.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/requisition-controller.js']);
                        }]
                  }
              })

              .state('apps.Topics', {
                  url: '/Past.Performances',
                  templateUrl: 'home/Proposal',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('textAngular').then(
                                function () {
                                    return $ocLazyLoad.load('/js/controllers/editor.js')
                                    .then(
                                        function () {
                                            return $ocLazyLoad.load(['/Scripts/app/Services/Proposal-service.js'])
                                      .then(
                                          function () {
                                              return $ocLazyLoad.load(['/Scripts/app/Services/Activity-service.js']);
                                          });
                                        });
                                })
                        }]
                  }

              })

              .state('apps.Proposal', {
                  url: '/Proposal',
                  templateUrl: 'Home/About',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/profile-controller.js']);
                        }]
                  }
              })

              .state('apps.RolePermissions', {
                  url: '/Role_Permissions',
                  templateUrl: '/tpl/app/Permissions.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['/Scripts/app/rolepermission-controller.js']);
                        }]
                  }
              })

              .state('apps.Permission', {
                  url: '/Permissions',
                  templateUrl: 'Home/Permissions',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/permission-controller.js']);
                        }]
                  }
              })

              .state('apps.RecordState', {
                  url: '/State',
                  templateUrl: '/tpl/app/RecordState.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/recordstate-controller.js']);
                        }]
                  }
              })

               .state('apps.RecordStateRoleMap', {
                   url: '/RoleMap',
                   templateUrl: '/tpl/app/RecordStateRoleMap.html',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load(['Scripts/app/recordStateRoleMap-controller.js']);
                         }]
                   }
               })

              .state('apps.configure1', {
                  url: '/Dropdowns_Configuration',
                  templateUrl: '/tpl/app/DropdownConfiguration.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/dropdownconfiguration-controller.js']);
                        }]
                  }
              })
              .state('apps.customconfigure', {
                  url: '/CustomDropdownConfiguration',
                  templateUrl: 'Scripts/app/appConfiguration/customDropDownConfig/partials/customDDConfig.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/appConfiguration/customDropDownConfig/js/controllers/customDDConfigCtrl.js']).then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/appConfiguration/customDropDownConfig/js/services/customDDConfigService.js']);
                                }
                            );
                        }]
                  }
              })
              .state('apps.customuserdefinedValueconfigure', {
                  url: '/CustomUserDefinedValueConfiguration',
                  templateUrl: 'Scripts/app/appConfiguration/customUserDefinedConfig/partials/customUDVConfig.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/appConfiguration/customUserDefinedConfig/js/controllers/customUDVConfigCtrl.js']).then(
                                function () {
                                    return $ocLazyLoad.load(['Scripts/app/appConfiguration/customUserDefinedConfig/js/services/customUDVConfigService.js']);
                                }
                            );
                        }]
                  }
              })
               .state('apps.customuserdefinedquestionnaireValueconfigure', {
                   url: '/CustomUserDefinedQuestionnaireValueConfiguration',
                   templateUrl: 'Scripts/app/appConfiguration/customUserDefinedQuestionnaireConfig/partials/customUDVQuestionnaireConfig.html',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load(['Scripts/app/appConfiguration/customUserDefinedQuestionnaireConfig/js/controllers/customUDVQuestionnaireConfigCtrl.js']).then(
                                 function () {
                                     return $ocLazyLoad.load(['Scripts/app/appConfiguration/customUserDefinedQuestionnaireConfig/js/services/customUDVQuestionnaireConfigService.js']);
                                 }
                             );
                         }]
                   }
               })
               .state('apps.Log', {
                   url: '/Log',
                   templateUrl: '/tpl/app/Log.html',
                   resolve: {
                       deps: ['$ocLazyLoad',
                         function ($ocLazyLoad) {
                             return $ocLazyLoad.load(['Scripts/app/Log-controller.js']);
                         }]
                   }
               })

              .state('apps.DefaultSettings', {
                  url: '/Default_Settings',
                  templateUrl: 'Home/DefaultSettings',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(['Scripts/app/defaultsettings-controller.js']);
                        }]
                  }
              })

              .state('app.ui', {
                  url: '/ui',
                  template: '<div ui-view class="fade-in-up"></div>'
              })
              .state('app.ui.buttons', {
                  url: '/buttons',
                  templateUrl: 'tpl/ui_buttons.html'
              })
              .state('app.ui.icons', {
                  url: '/icons',
                  templateUrl: 'tpl/ui_icons.html'
              })
              .state('app.ui.grid', {
                  url: '/grid',
                  templateUrl: 'tpl/ui_grid.html'
              })
              .state('app.ui.widgets', {
                  url: '/widgets',
                  templateUrl: 'tpl/ui_widgets.html'
              })
              .state('app.ui.bootstrap', {
                  url: '/bootstrap',
                  templateUrl: 'tpl/ui_bootstrap.html'
              })
              .state('app.ui.sortable', {
                  url: '/sortable',
                  templateUrl: 'tpl/ui_sortable.html'
              })
              .state('app.ui.portlet', {
                  url: '/portlet',
                  templateUrl: 'tpl/ui_portlet.html'
              })
              .state('app.ui.timeline', {
                  url: '/timeline',
                  templateUrl: 'tpl/ui_timeline.html'
              })
              .state('app.ui.tree', {
                  url: '/tree',
                  templateUrl: 'tpl/ui_tree.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('angularBootstrapNavTree').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/tree.js');
                                }
                            );
                        }
                      ]
                  }
              })
              .state('app.ui.toaster', {
                  url: '/toaster',
                  templateUrl: 'tpl/ui_toaster.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('toaster').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/toaster.js');
                                }
                            );
                        }]
                  }
              })
              .state('app.ui.jvectormap', {
                  url: '/jvectormap',
                  templateUrl: 'tpl/ui_jvectormap.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('js/controllers/vectormap.js');
                        }]
                  }
              })
              .state('app.ui.googlemap', {
                  url: '/googlemap',
                  templateUrl: 'tpl/ui_googlemap.html',
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load([
                              'js/app/map/load-google-maps.js',
                              'js/app/map/ui-map.js',
                              'js/app/map/map.js']).then(
                                function () {
                                    return loadGoogleMaps();
                                }
                              );
                        }]
                  }
              })
              .state('app.chart', {
                  url: '/chart',
                  templateUrl: 'tpl/ui_chart.html',
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load('/js/controllers/chart.js');
                        }]
                  }
              })
              // table
              .state('app.table', {
                  url: '/table',
                  template: '<div ui-view></div>'
              })
              .state('app.table.static', {
                  url: '/static',
                  templateUrl: 'tpl/table_static.html'
              })
              .state('app.table.datatable', {
                  url: '/datatable',
                  templateUrl: 'tpl/table_datatable.html'
              })
              .state('app.table.footable', {
                  url: '/footable',
                  templateUrl: 'tpl/table_footable.html'
              })
              .state('app.table.grid', {
                  url: '/grid',
                  templateUrl: 'tpl/table_grid.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('ngGrid').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/grid.js');
                                }
                            );
                        }]
                  }
              })
              // form
              .state('app.form', {
                  url: '/form',
                  template: '<div ui-view class="fade-in"></div>',
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load('js/controllers/form.js');
                        }]
                  }
              })
              .state('app.form.elements', {
                  url: '/elements',
                  templateUrl: 'tpl/form_elements.html'
              })
              .state('app.form.validation', {
                  url: '/validation',
                  templateUrl: 'tpl/form_validation.html'
              })
              .state('app.form.wizard', {
                  url: '/wizard',
                  templateUrl: 'tpl/form_wizard.html'
              })
              .state('app.form.fileupload', {
                  url: '/fileupload',
                  templateUrl: 'tpl/form_fileupload.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('angularFileUpload').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/file-upload.js');
                                }
                            );
                        }]
                  }
              })
              .state('app.form.imagecrop', {
                  url: '/imagecrop',
                  templateUrl: 'tpl/form_imagecrop.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('ngImgCrop').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/imgcrop.js');
                                }
                            );
                        }]
                  }
              })
              .state('app.form.select', {
                  url: '/select',
                  templateUrl: 'tpl/form_select.html',
                  controller: 'SelectCtrl',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('ui.select').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/select.js');
                                }
                            );
                        }]
                  }
              })
              .state('app.form.slider', {
                  url: '/slider',
                  templateUrl: 'tpl/form_slider.html',
                  controller: 'SliderCtrl',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('vr.directives.slider').then(
                                function () {
                                    return $ocLazyLoad.load('js/controllers/slider.js');
                                }
                            );
                        }]
                  }
              })
              .state('app.form.editor', {
                  url: '/editor',
                  templateUrl: 'tpl/form_editor.html',
                  controller: 'EditorCtrl',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load('textAngular').then(
                                function () {
                                    return $ocLazyLoad.load('/js/controllers/editor.js');
                                }
                            );
                        }]
                  }
              })
              // pages
              .state('app.page', {
                  url: '/page',
                  template: '<div ui-view class="fade-in-down"></div>'
              })
              .state('app.page.profile', {
                  url: '/profile',
                  templateUrl: 'tpl/page_profile.html'
              })
              .state('app.page.post', {
                  url: '/post',
                  templateUrl: 'tpl/page_post.html'
              })
              .state('app.page.search', {
                  url: '/search',
                  templateUrl: 'tpl/page_search.html'
              })
              .state('app.page.invoice', {
                  url: '/invoice',
                  templateUrl: 'tpl/page_invoice.html'
              })
              .state('app.page.price', {
                  url: '/price',
                  templateUrl: 'tpl/page_price.html'
              })
              .state('app.docs', {
                  url: '/docs',
                  templateUrl: 'tpl/docs.html'
              })
              // others
              .state('lockme', {
                  url: '/lockme',
                  templateUrl: 'tpl/page_lockme.html'
              })
              .state('access', {
                  url: '/access',
                  template: '<div ui-view class="fade-in-right-big smooth"></div>'
              })
              .state('access.signin', {
                  url: '/signin',
                  templateUrl: 'tpl/page_signin.html',
                  //resolve: {
                  //    deps: ['uiLoad',
                  //      function( uiLoad ){
                  //        return uiLoad.load( ['js/controllers/signin.js'] );
                  //    }]
                  //}
              })
              .state('access.signup', {
                  url: '/signup',
                  templateUrl: 'tpl/page_signup.html',
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['js/controllers/signup.js']);
                        }]
                  }
              })
              .state('access.forgotpwd', {
                  url: '/forgotpwd',
                  templateUrl: 'tpl/page_forgotpwd.html'
              })
              .state('access.404', {
                  url: '/404',
                  templateUrl: 'tpl/page_404.html'
              })

              // fullCalendar
              .state('app.calendar', {
                  url: '/calendar',
                  templateUrl: 'tpl/app_calendar.html',
                  // use resolve to load other dependences
                  resolve: {
                      deps: ['$ocLazyLoad', 'uiLoad',
                        function ($ocLazyLoad, uiLoad) {
                            return uiLoad.load(
                              ['vendor/jquery/fullcalendar/fullcalendar.css',
                                'vendor/jquery/fullcalendar/theme.css',
                                'vendor/jquery/jquery-ui-1.10.3.custom.min.js',
                                'vendor/libs/moment.min.js',
                                'vendor/jquery/fullcalendar/fullcalendar.min.js',
                                'js/app/calendar/calendar.js']
                            ).then(
                              function () {
                                  return $ocLazyLoad.load('ui.calendar');
                              }
                            )
                        }]
                  }
              })

              // mail
              .state('app.mail', {
                  abstract: true,
                  url: '/mail',
                  templateUrl: 'tpl/mail.html',
                  // use resolve to load other dependences
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['js/app/mail/mail.js',
                                                 'js/app/mail/mail-service.js',
                                                 'vendor/libs/moment.min.js']);
                        }]
                  }
              })
              .state('app.mail.list', {
                  url: '/inbox/{fold}',
                  templateUrl: 'tpl/mail.list.html'
              })
              .state('app.mail.detail', {
                  url: '/{mailId:[0-9]{1,4}}',
                  templateUrl: 'tpl/mail.detail.html'
              })
              .state('app.mail.compose', {
                  url: '/compose',
                  templateUrl: 'tpl/mail.new.html'
              })

              .state('layout', {
                  abstract: true,
                  url: '/layout',
                  templateUrl: 'tpl/layout.html'
              })
              .state('layout.fullwidth', {
                  url: '/fullwidth',
                  views: {
                      '': {
                          templateUrl: 'tpl/layout_fullwidth.html'
                      },
                      'footer': {
                          templateUrl: 'tpl/layout_footer_fullwidth.html'
                      }
                  },
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['js/controllers/vectormap.js']);
                        }]
                  }
              })


              .state('layout.mobile', {
                  url: '/mobile',
                  views: {
                      '': {
                          templateUrl: 'tpl/layout_mobile.html'
                      },
                      'footer': {
                          templateUrl: 'tpl/layout_footer_mobile.html'
                      }
                  }
              })
              .state('layout.skill', {
                  url: '/skill',
                  views: {
                      '': {
                          templateUrl: '/Home/Skill'
                      },
                      'footer': {
                          templateUrl: 'tpl/layout_footer_fullwidth.html'
                      }
                  },
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['Scripts/app/Skill-controller.js']);
                        }]
                  }
              })
               .state('layout.positions', {
                   url: '/positions',
                   views: {
                       '': {
                           templateUrl: '/Home/Positions'
                       },
                       'footer': {
                           templateUrl: 'tpl/layout_footer_fullwidth.html'
                       }
                   },
                   resolve: {
                       deps: ['uiLoad',
                         function (uiLoad) {
                             return uiLoad.load(['Scripts/app/Positions-controller.js']);
                         }]
                   }
               })
              .state('layout.app', {
                  url: '/app',
                  views: {
                      '': {
                          templateUrl: 'tpl/layout_app.html'
                      },
                      'footer': {
                          templateUrl: 'tpl/layout_footer_fullwidth.html'
                      }
                  },
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['js/controllers/tab.js']);
                        }]
                  }
              })
              .state('apps', {
                  abstract: true,
                  url: '/apps',
                  templateUrl: 'tpl/layout.html'
              })
              .state('apps.note', {
                  url: '/note',
                  templateUrl: 'tpl/apps_note.html',
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['js/app/note/note.js',
                                                 'vendor/libs/moment.min.js']);
                        }]
                  }
              })
              .state('apps.contact', {
                  url: '/contact',
                  templateUrl: 'tpl/apps_contact.html',
                  resolve: {
                      deps: ['uiLoad',
                        function (uiLoad) {
                            return uiLoad.load(['js/app/contact/contact.js']);
                        }]
                  }
              })
              .state('app.weather', {
                  url: '/weather',
                  templateUrl: 'tpl/apps_weather.html',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load(
                                {
                                    name: 'angular-skycons',
                                    files: ['js/app/weather/skycons.js',
                                            'vendor/libs/moment.min.js',
                                            'js/app/weather/angular-skycons.js',
                                            'js/app/weather/ctrl.js']
                                }
                            );
                        }]
                  }
              })
              .state('music', {
                  url: '/music',
                  templateUrl: 'tpl/music.html',
                  controller: 'MusicCtrl',
                  resolve: {
                      deps: ['$ocLazyLoad',
                        function ($ocLazyLoad) {
                            return $ocLazyLoad.load([
                              'com.2fdevs.videogular',
                              'com.2fdevs.videogular.plugins.controls',
                              'com.2fdevs.videogular.plugins.overlayplay',
                              'com.2fdevs.videogular.plugins.poster',
                              'com.2fdevs.videogular.plugins.buffering',
                              'js/app/music/ctrl.js',
                              'js/app/music/theme.css'
                            ]);
                        }]
                  }
              })
                .state('music.home', {
                    url: '/home',
                    templateUrl: 'tpl/music.home.html'
                })
                .state('music.genres', {
                    url: '/genres',
                    templateUrl: 'tpl/music.genres.html'
                })
                .state('music.detail', {
                    url: '/detail',
                    templateUrl: 'tpl/music.detail.html'
                })
                .state('music.mtv', {
                    url: '/mtv',
                    templateUrl: 'tpl/music.mtv.html'
                })
                .state('music.mtvdetail', {
                    url: '/mtvdetail',
                    templateUrl: 'tpl/music.mtv.detail.html'
                })
                .state('music.playlist', {
                    url: '/playlist/{fold}',
                    templateUrl: 'tpl/music.playlist.html'
                })
      }
    ]
  );