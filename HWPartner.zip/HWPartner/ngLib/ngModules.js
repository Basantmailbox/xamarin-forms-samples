'use strict';

angular.module('app', [
    'ngAnimate',
    'ngSanitize',
    'ui.router',
    'ui.bootstrap',
    'toaster',
    'ui.calendar',
    'angular.filter',
    'ui.bootstrap.modal',
    'ui.select'
]);


    //.run(['$anchorScroll', function ($anchorScroll) {
    //    $anchorScroll.yOffset = 200;   // always scroll by 150 extra pixels

    //}]);

