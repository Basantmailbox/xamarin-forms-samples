﻿'use strict';

/* Controllers */

angular.module('app')
  .controller('AppCtrl', ['$scope', '$http', '$translate', '$localStorage', '$window', '$rootScope', '$timeout', '$interval', '$sce', '$location',
    function ($scope, $http, $translate, $localStorage, $window, $rootScope, $timeout, $interval, $sce) {
        // add 'ie' classes to html
        //var isIE = !!navigator.userAgent.match(/MSIE/i);
        //isIE && angular.element($window.document.body).addClass('ie');
        //isSmartDevice($window) && angular.element($window.document.body).addClass('smart');

        var workflowButtonsArray = {
            ButtonPosition: "",
            ButtonText: "",
            ButtonValue: 0,
            showicon: false,
            showbutton: false
        };



        //api service call of all data together
        //UserPermissionService.assortedCalls().loadAllCalls()
        //    .then(function (response) {
        //        $scope.allDataSet = response;
        //        $scope.app.rights = $scope.allDataSet[0].data;
        //        $scope.app.recordstatePermissions = $scope.allDataSet[1].data;
        //    })

        $scope.categories = true;
        $scope.bidStatus = [];
        // config
        $scope.app = {
            name: 'Rigil.Rocks',
            userName: 'Rigil',
            version: '1.0.0',
            globalStatusFilter: 0,
            globalDevFilter: 0,
            bidmodule: "",
            // for chart colors
            color: {
                primary: '#7266ba',
                info: '#23b7e5',
                success: '#27c24c',
                warning: '#fad733',
                danger: '#f05050',
                light: '#e8eff0',
                dark: '#3a3f51',
                black: '#1c2b36'
            },
            settings: {
                themeID: 1,
                navbarHeaderColor: 'bg-black',
                navbarCollapseColor: 'bg-white-only',
                asideColor: 'bg-black',
                headerFixed: true,
                asideFixed: false,
                asideFolded: false,
                asideDock: false,
                container: false
            },
            permissions: {
                USERNAME: "",
                PROFILEPIC: "",
                ROLES: []
            },
            notifications: [
                {
                    CreatedBy: "",
                    EmailTo: "",
                    CreatedDate: new Date,
                    Module: "",
                    SubModule: "",
                    Message: "",
                    DateRecord: "",
                    Attribute: "",
                    OldValue: "",
                    NewValue: ""
                }],
            allnotifications: [
                {
                    CreatedBy: "",
                    EmailTo: "",
                    CreatedDate: new Date,
                    Module: "",
                    SubModule: "",
                    Message: "",
                    DateRecord: "",
                    Attribute: "",
                    OldValue: "",
                    NewValue: ""
                }],
            workflow: {
                buttonArray: []
            }
        };

        //$http.get('/Home/GetBidStatus').success(function (data) {
        //    $scope.bidStatus = data.types;
        //    //default case for session storage
        //    sessionStorage.setItem("app.bidmodule", "Tracker");
        //    sessionStorage.setItem("app.globalStatusFilter", 0);
        //    sessionStorage.setItem("app.globalDevFilter", 0);
        //})
   
       
       // $scope.GetRolenPermissions();
       
        //which role to activate
        //$scope.activateRole = function (RoleId, Rolename) {
        //    $scope.app.roleid = RoleId;
        //    $scope.app.rolename = Rolename;
        //    $localStorage.defaultroleid = $scope.app.roleid;
        //    $localStorage.defaultrolename = $scope.app.rolename;
        //    $window.location.href = '#/apps/dashboard';
        //    $scope.GetRolenPermissions();
        //};
       
        //KYC
        //$http.get("/Home/GetLoggedIn_UserName").success(function (data) {
        //    $scope.app.permissions.USERNAME = data.username;
        //    $scope.app.permissions.PROFILEPIC = data.userprofilepic;
        //    $scope.getAllNotifications($scope.app.permissions.USERNAME);
        //});

        ////////////////////////////////   Notification Start /////////////////////////////////////////////////////////////////////////////
        //$interval(function () { $scope.getAllNotificationsRefersh($scope.app.permissions.USERNAME); }, 21000);
        //$scope.clear = function () {
        //    $http.get("/Home/clearNotifications?useremail=" + $scope.app.permissions.USERNAME).success(function (data) {
        //        if (data.data == "success") {
        //            $scope.app.notifications = [];
        //        }
        //        else
        //        {
        //            $scope.error = "An error Occured" + data;
        //        }
        //    });
        //}

        //$scope.getAllNotificationsRefersh = function (user) {
        //    $http.get("/Home/getNotifications?useremail=" + user).success(function (data) {
        //        if ($scope.app.notifications.length != data.data.length) {
        //            $scope.app.notifications = data.data;
        //        }
        //    });
        //}
     

 
        ///////////////////////////////   Notification End ///////////////////////////////////////////////////////////////////////////

       

        //return permission of navigational and form level links (i.e. show enabled / hidden)
        //$scope.showLink = function (key) {
        //    var found = false;
        //    var tmptxt = "";
        //    if (!$scope.app.rights) {
        //        tmptxt = "not found";
        //        //console.log("2a..." + key + " " + tmptxt);
        //    } else {
        //        tmptxt = "found";
        //        //console.log("2a..." + key + " " + tmptxt);
        //        angular.forEach($scope.app.rights.rightsList, function (value, index) {
        //            if (value.Key == key && value.State == 'Enabled') {
        //                found = true;
        //                return false;
        //            }
        //        })
        //    }

        //    return found;
        //};

        


        // save settings to local storage
        if (angular.isDefined($localStorage.settings)) {
            $scope.app.settings = $localStorage.settings;
        } else {
            $localStorage.settings = $scope.app.settings;
        }

        $scope.$watch('app.settings', function () {
            if ($scope.app.settings.asideDock && $scope.app.settings.asideFixed) {
                // aside dock and fixed must set the header fixed.
                $scope.app.settings.headerFixed = true;
            }
            // save to local storage
            $localStorage.settings = $scope.app.settings;
        }, true);

        //// angular translate
        //$scope.lang = { isopen: false };
        //$scope.langs = { en: 'English', de_DE: 'German', it_IT: 'Italian' };
        //$scope.selectLang = $scope.langs[$translate.proposedLanguage()] || "English";

        //$scope.setLang = function (langKey, $event) {
        //    // set the current lang
        //    $scope.selectLang = $scope.langs[langKey];
        //    // You can change the language during runtime
        //    $translate.use(langKey);
        //    $scope.lang.isopen = !$scope.lang.isopen;

        //};


        //function isSmartDevice($window) {
        //    // Adapted from http://www.detectmobilebrowsers.com
        //    var ua = $window['navigator']['userAgent'] || $window['navigator']['vendor'] || $window['opera'];
        //    // Checks for iOs, Android, Blackberry, Opera Mini, and Windows mobile devices
        //    return (/iPhone|iPod|iPad|Silk|Android|BlackBerry|Opera Mini|IEMobile/).test(ua);
        //}

      

        

    }]);