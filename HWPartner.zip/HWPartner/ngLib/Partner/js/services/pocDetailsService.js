﻿app.factory('pocDetailsService', [
    '$http',
    function ($http) {
        return {
            getPOCDetailList: function () {
                return $http.get('/api/PartnerContact').success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            postData: function (id, data) {
                return $http.post('/api/PartnerContact/' + id, data).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      //console.log("error");
                  });
            },
            putData: function (id, data) {
                return $http.put('/api/PartnerContact/' + id, data).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      //console.log("error");
                  });
            },
            deleleData: function (id) {
                return $http.delete('api/Partner?id=' + id).
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
        }
    }
]);