﻿
app.controller('partnerPocManageCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'partnerId', 'obj', 'mode', 'toaster', '$location', 'pocDetailsService',
    function ($scope, $http, $modalInstance, $controller, partnerId, obj, mode, toaster, location, pocDetailsService) {
        //$controller('partnersCtrl', { $scope: $scope })
        $scope.partnerId = partnerId;
        $scope.pocDetails = {
            Id: obj.Id,
            POC: obj.POC,
            Email: obj.Email,
            Phone: obj.Phone,
            Comments: obj.Comments,
            POCTitle: obj.POCTitle,
            MobileNo: obj.MobileNo,
            Bid_Id: obj.Bid_Id
        }
        $scope.currentMode = mode;

        $scope.toggleAddPOCModal = function () {
            $modalInstance.close();
        }

        $scope.addNewPocDetail = function () {
            if ($scope.currentMode == "Create") {
                pocDetailsService.postData($scope.partnerId, $scope.pocDetails).then(function (response) {
                    if (response.data) {
                        $modalInstance.close(response.data, $scope.currentMode);
                    }
                    else {
                        toaster.pop('error', 'Error', "An Error has occurred while adding POC Details!");
                    }
                });
            }
            else if ($scope.currentMode == "Edit") {
                pocDetailsService.putData($scope.partnerId, $scope.pocDetails).then(function (response) {
                    if (response.data) {
                        $modalInstance.close(response.data, $scope.currentMode);
                    }
                    else {
                        toaster.pop('error', 'Error', "An Error has occurred while updating POC Details!");
                    }
                });
            }
        }

    }]);