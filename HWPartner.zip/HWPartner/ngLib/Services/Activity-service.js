﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('ActivityService', function ($http, $q, $timeout) {

    //multiple API call service
    this.assortedCalls = function () {
        return {
            saveAllCalls: function (masterid) {
                var deferred = $q.defer();
                var firstCall = $http.post('/api/ActivityRecord/SaveActivity/' + masterid);
                $q.all([firstCall]);
                return deferred.promise;
            }
        }
    };
})