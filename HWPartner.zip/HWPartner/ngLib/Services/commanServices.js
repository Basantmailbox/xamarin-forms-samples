﻿app.factory('commanServices', [
    '$http',
    function ($http) {
        return {
            getBiddingConstantData: function (value) {
                return $http.get('api/Bidding_constant?type=' + value).
                success(function (data, status, headers) {
                }).
                error(function (data, status, headers) {
                });
            },
            getAllUsersDropDown: function (value) {
                return $http.get('/Home/GetAllUsersDropDown').
                success(function (data, status, headers) {
                }).
                error(function (data, status, headers) {
                });
            },
            
        }
    }
]);