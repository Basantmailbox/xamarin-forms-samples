﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('testServiceS', function () {
    this.sayHello = function (text) {
        return "Service says \"Hello " + text + "\"";
    };
});