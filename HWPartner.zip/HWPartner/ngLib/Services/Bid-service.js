﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('BidService', function ($http, $q, $timeout) {

    //multiple API call service (on load)
    this.assortedCalls = function () {
        return {
            loadAllCalls: function () {
                var deferred = $q.defer();
                var call00 = $http.get('/api/GeneralConfigs');//d
                var call01 = $http.get('/api/Permissions');//d
                var call02 = $http.get('/Home/getIdIQContract');//d
                var call03 = $http.get('/api/Bidding_constant');//d
                var call04 = $http.get('/api/Bids?isArchived=false');//d RR-520
                var call05 = $http.get('/api/GeneralConfigs/6');//d
                var call06 = $http.get('/api/Questionnaires/1');
                var call07 = $http.get('/api/NAICScodes');
                var call08 = $http.get('/Home/GetDepartments');//d
                var call09 = $http.get('/Home/GetFullAgencies');//d
                //var call10 = $http.get('/api/GeneralConfigs/9');//d
                var call11 = $http.get('/Home/GetModifiedBidStatus');//d
                var call12 = $http.get('/Home/GetResearchFormId');
                var call13 = $http.get('/Home/GetProposalPlanningFormId');
                var call14 = $http.get('/Home/GetPartnerType');
                var call15 = $http.get('/Home/GetAllForms?moduleId=1');
                var call16 = $http.get('/Home/GetAllRoles');
                var call17 = $http.get('/Home/GetAllContracts');

                $q.all([call00, call01, call02, call03, call04, call05, call06, call07, call08,call09,call11,call12,call13,call14,call15,call16,call17])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };

})