﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('DashboardGraphService', function ($http,$q,$timeout) {

    //multiple API call service
    this.assortedCalls = function () {
        return {
            loadAllCalls: function (currentYear) {
                var deferred = $q.defer();
                var firstCall = $http.get('/api/DashBoard/GetBidStageStackedDataSet?constype=PROPOSALSTAGE&fldname=Rigil_Stage&Years=');
                var secondCall = $http.get('/api/DashBoard/GetBidValuesDataSet?months=12');
                var thirdcall = $http.get('/api/DashBoard/GetFunnelDataSet?year=' + currentYear);
                var fourthcall = $http.get('/api/GeneralConfigs/8');
                var fifthcall = $http.get('/api/DashBoard/GetBidTilesData');
                var sixthcall = $http.get('/api/DashBoard/GetBidDataYearsList');
                $q.all([firstCall, secondCall, thirdcall,fourthcall, fifthcall,sixthcall])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };
})