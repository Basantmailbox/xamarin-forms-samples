﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('testServiceT', function () {
    this.sayHello = function (text) {
        return "Service says \"Hello " + text + "\"";
    };
});