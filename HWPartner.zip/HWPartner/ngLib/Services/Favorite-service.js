﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('FavoriteService', function ($http, $q, $timeout) {

    //multiple API call service
    this.assortedCalls = function () {
        return {
            saveAllCalls: function (param) {
                var deferred = $q.defer();
                var firstCall = $http.post('/api/Follow/SaveFollow', param);
                $q.all([firstCall])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };

    this.assortedCall2 = function () {
        return {
            saveAllCalls2: function (paramlist) {
                var deferred = $q.defer();
                var firstCall = $http.post('/api/Follow/SaveFollowList',paramlist);
                $q.all([firstCall])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };
})