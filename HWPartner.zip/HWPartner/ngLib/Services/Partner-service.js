﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('PartnerService', function ($http,$q,$timeout) {

    //single API call service
    this.getPartners = function () {
        return $http.get('/api/Partner').then(function (response) { return response; })
    };

    //multiple API call service
    this.assortedCalls = function () {
        return {
            loadAllCalls: function () {
                var deferred = $q.defer();
                var firstCall = $http.get('/api/Partner');
                var secondCall = $http.get('/api/Bids');

                $q.all([firstCall, secondCall])
                .then(
                function(results) {
                    //deferred.resolve(
                    // JSON.stringify(results)) 
                    deferred.resolve(results);
                },
                function(errors) {
                    deferred.reject(errors);
                },
                function(updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
    }
};

    this.test = function () {
        return "How are you?";
    };
});