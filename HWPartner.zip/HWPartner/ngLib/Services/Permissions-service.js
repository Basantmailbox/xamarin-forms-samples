﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('UserPermissionService', function ($http, $q, $timeout) {
    //multiple API call service (on load)
    this.assortedCalls = function () {
        return {
            loadAllCalls: function () {
                var deferred = $q.defer();
                var call00 = $http.get('/Home/GetUser_n_Roles_n_Permissions');
                var call01 = $http.get('/Home/GetMy_RecordStates');

                $q.all([call00, call01])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };
})
