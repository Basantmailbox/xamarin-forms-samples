﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('ContractService', function ($http, $q, $timeout) {

    //update workflow status
    this.workflowUpdateCall = function () {
        return {
            updateRecordState: function (contractId, newRecordStateId) {
                $http.put('/api/Contracts?ContractId=' + contractId + "&RecordStateId=" + newRecordStateId).success(function (data) {
                })
            }
        }
    }

    //multiple API call service (on load)
    this.assortedCalls = function () {
        return {
            loadAllCalls: function () {
                var deferred = $q.defer();
                var call00 = $http.get('/api/topics?showallrecords=' + true);
                var call01 = $http.get('/api/Contracts?status=Active');
                var call02 = $http.get('/api/technologies');
                var call03 = $http.get('/api/methodologies');
                var call04 = $http.get('/api/Resume');
                var call05 = $http.get('/api/Contracts?status=Archived');
                var call06 = $http.get('/api/RecordStates?filter=Contract');   //needed for workflow implementation
                var call07 = $http.get('/Home/Get_RecordlistPermissions?Modulename=Contract');  //needed for workflow implementation

                $q.all([call00, call01, call02, call03, call04, call05, call06, call07])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };
})