﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('testServiceM', function () {
    this.sayHello = function (text) {
        return "Service says \"Hello " + text + "\"";
    };
});