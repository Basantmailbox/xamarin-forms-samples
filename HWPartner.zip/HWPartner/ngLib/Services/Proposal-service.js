﻿//define the Angular module 
var model = angular.module('app');

// Service definition
model.service('TopicService', function ($http, $q, $timeout) {

    //update workflow status
    this.workflowUpdateCall = function () {
        return {
            updateRecordState: function (topicId, newRecordStateId) {
                $http.put('/api/Topics?TopicId=' + topicId + "&RecordStateId=" + newRecordStateId).success(function (data) {
                })
            }
        }
    }

    //multiple API call service (on load)
    this.assortedCalls = function () {
        return {
            loadAllCalls: function () {
                var deferred = $q.defer();
                var call06 = $http.get('/api/RecordStates?filter=Capability');   //needed for workflow implementation
                var call07 = $http.get('/Home/Get_RecordlistPermissions?Modulename=Capability');  //needed for workflow implementation

                $q.all([call06, call07])
                .then(
                function (results) {
                    deferred.resolve(results);
                },
                function (errors) {
                    deferred.reject(errors);
                },
                function (updates) {
                    deferred.update(updates);
                });
                return deferred.promise;
            }
        }
    };
})