﻿var modelBid = angular.module('app');
modelBid.directive('ngBlur', function () {
    return function (scope, elem, attrs) {
        elem.bind('blur', function () {
            scope.$apply(attrs.ngBlur);
        });
    };
});

//used in bid partner
modelBid.directive('dateTimePicker', function () {

    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            var parent = $(element).parent();
            var dtp = parent.datetimepicker({
                format: "MM/DD/YYYY",
                showTodayButton: true,
                minDate: "25/10/2016" ? "01/01/2012" : false

            });

            dtp.on("dp.change", function (e) {
                ngModelCtrl.$setViewValue(moment(e.date).format("MM/DD/YYYY"));
                scope.$apply();
            });
        }
    };
})
//used in the bid main ui grid
modelBid.directive('datePicker', function () {
    return {
        restrict: "A",
        require: 'ngModel',
        scope: {
            releaseFirstDate: '@',
            releaseLastDate: '@',
            proposedFirstDate: '@',
            proposedLastDate: '@',
            submittedFisrtDate: '@',
            submittedLastDate: '@',
            solFirstDate: '@',
            solLastDate: '@',
            rfiDueFirstDate: '@',
            rfiDueLastDate: '@',
            rfiSubmittedFirstDate: '@',
            rfiSubmittedLastDate: '@',
            // ********   RR-540   START **************************************//
            createdFirstDate: '@',
            createdLastDate: '@',
            updatedFirstDate: '@',
            updatedLastDate: '@',
            // ********   RR-540   END **************************************//
            // ********   RR-541   START **************************************//
            followFirstDate: '@',
            followLastDate: '@',
            // ********   RR-541   END **************************************//
        },
        link: function (scope, element, attrs, ngModel) {
            $(function () {
                $(element).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    closeText: 'Clear',
                    showButtonPanel: true,
                    maxDate: new Date(),
                    onClose: function () {
                        var event = arguments.callee.caller.caller.arguments[0];
                        // If "Clear" gets clicked, then really clear it
                        if ($(event.delegateTarget).hasClass('ui-datepicker-close')) {
                            $(this).val('');
                            scope.$apply(function () {
                                ngModel.$setViewValue(null);
                                var obj = {};
                                obj.releaseFirstDate = scope.releaseFirstDate;
                                obj.releaseLastDate = scope.releaseLastDate;
                                obj.proposedFirstDate = scope.proposedFirstDate;
                                obj.proposedLastDate = scope.proposedLastDate;
                                obj.submittedFisrtDate = scope.submittedFisrtDate;
                                obj.submittedLastDate = scope.submittedLastDate;
                                obj.solFirstDate = scope.solFirstDate;
                                obj.solLastDate = scope.solLastDate;
                                obj.rfiDueFirstDate = scope.rfiDueFirstDate;
                                obj.rfiDueLastDate = scope.rfiDueLastDate;
                                obj.rfiSubmittedFirstDate = scope.rfiSubmittedFirstDate;
                                obj.rfiSubmittedLastDate = scope.rfiSubmittedLastDate;
                                // ********   RR-540   START **************************************//
                                obj.createdFirstDate = scope.createdFirstDate;
                                obj.createdLastDate = scope.createdLastDate;
                                obj.updatedFirstDate = scope.updatedFirstDate;
                                obj.updatedLastDate = scope.updatedLastDate;
                                // ********   RR-540   END **************************************//
                                // ********   RR-541  START **************************************//
                                obj.followFirstDate = scope.followFirstDate;
                                obj.followLastDate = scope.followLastDate;
                                // ********   RR-541   END **************************************//
                                scope.$emit('clearDate', obj);
                            });
                        }
                    },
                    onSelect: function (date) {
                        scope.$apply(function () {
                            ngModel.$setViewValue(date);
                        });
                    }
                });
            })
        }
    }
});
//used in the "App\master\Resume\tpl\app\Partials\BidTracking\InfoSection.html"
modelBid.directive('codeCheck', function ($http) {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            elem.on('keyup', function () {
                scope.$apply(function () {
                    ctrl.$setValidity('zero', true);
                    if (elem.val().length > 0) {
                        $http.get('/Home/CheckBidCode?code=' + elem.val()).success(function (data) {
                            if (data.result == "duplicate") {
                                ctrl.$setValidity('zero', false);
                            }
                            else {
                                ctrl.$setValidity('zero', true);
                            }
                        })
                    }
                });
            });
        }
    };
});
//used in  "App\master\Resume\tpl\app\Partials\BidTracking\InfoSection.html"
modelBid.directive('acronymCheck', function ($http) {
    return {
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            elem.on('keyup', function () {
                scope.$apply(function () {
                    ctrl.$setValidity('one', true);
                    if (elem.val().length > 0) {
                        $http.get('/Home/CheckBidAcronym?acronym=' + elem.val()).success(function (data) {
                            if (data.result == "duplicate") {
                                ctrl.$setValidity('one', false);
                            }
                            else {
                                ctrl.$setValidity('one', true);
                            }
                        })
                    }
                });
            });
        }
    };
});
//used in "App\master\Resume\tpl\app\BidTracking.html"
modelBid.filter("IDIQFilter", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].Contractname;
                break;
            }
        }
        return name;
    }
})
//used in " App\master\Resume\tpl\app\BidTracking.html"
modelBid.filter("BidNoBid", function () {
    return function (boolstat) {
        var fullname;

        if (boolstat) { fullname = "Bid"; } else { fullname = "No Bid"; }
        return fullname;
    }
});
//used in "App\master\Resume\tpl\app\BidTracking.html"
modelBid.filter("ShortText", function () {
    return function (fulltext) {
        var shorttext;
        var regex = /\s+/gi;
        var wordCount = fulltext.trim().replace(regex, ' ').split(' ').length;
        var totalChars = fulltext.length;
        var charCount = fulltext.trim().length;
        if (charCount > 30) { shorttext = fulltext.substring(0, 30); } else { shorttext = fulltext; }
        return shorttext;
    }
})
//used in "App\master\Resume\tpl\modal\ImportOpportunityModal.html"
modelBid.filter("ShortText1", function () {
    return function (fulltext) {
        var shorttext;
        var regex = /\s+/gi;
        var wordCount = fulltext.trim().replace(regex, ' ').split(' ').length;
        var totalChars = fulltext.length;
        var charCount = fulltext.trim().length;
        if (charCount > 14) { shorttext = fulltext.substring(0, 14) + "..."; } else { shorttext = fulltext; }
        return shorttext;
    }
})
//used in "App\master\Resume\tpl\app\BidTracking.html"
//used in "App\master\Resume\tpl\app\Partials\BidTracking\InfoSection.html"
modelBid.filter("GetDepartmentNames", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].Agencyname;
                break;
            }
        }
        return name;
    }
})
//used in "App\master\Resume\tpl\app\Partials\BidTracking\InfoSection.html"
modelBid.filter("NaicsCode", function () {
    return function (strvar, array) {
        var htmlstr = '';
        if (strvar) {
            if (strvar.length > 0) {
                var naicscodeArray = strvar.split(",");
                for (var i = 0; i < naicscodeArray.length; i++) {
                    angular.forEach(array, function (value, index) {
                        if (value.NaicsCode == naicscodeArray[i]) {
                            htmlstr = htmlstr + value.NaicsCode + ' - ' + value.IndustryName + '\n';
                        }
                    })
                }
            }
        }
        return htmlstr;
    }
})

//used in "App\master\Resume\tpl\app\Partials\BidTracking\PartnerSection.html"
modelBid.filter('phonenumber', function () {
    /* 
    Format phonenumber as: c (xxx) xxx-xxxx
        or as close as possible if phonenumber length is not 10
        if c is not '1' (country code not USA), does not use country code
    */

    return function (number) {
        /* 
        @param {Number | String} number - Number that will be formatted as telephone number
        Returns formatted number: (###) ###-####
            if number.length < 4: ###
            else if number.length < 7: (###) ###

        Does not handle country codes that are not '1' (USA)
        */
        if (!number) { return ''; }

        number = String(number);
        // Will return formattedNumber. 
        // If phonenumber isn't longer than an area code, just show number
        var formattedNumber = number;

        // if the first character is '1', strip it out and add it back
        //var c = (number[0] == '1') ? '1 ' : '';
        //number = number[0] == '1' ? number.slice(1) : number;

        // # (###) ###-#### as c (area) front-end
        var area = number.substring(0, 3);
        var front = number.substring(3, 6);
        var end = number.substring(6, 10);

        if (front) {
            formattedNumber = ("(" + area + ") " + front);
        }
        if (end) {
            formattedNumber += ("-" + end);
        }
        return formattedNumber;
    };
});

modelBid.controller('bidTrackingCommentModal', function ($scope, $modal) {
    $scope.addNewComment = function (comment) {
        $scope.newCommentAdd();
        $scope.commentsIndex[$scope.comments.currentIndex].Comment = comment;
        $scope.comments.isadding = true;
        $scope.saveInstance(0, 'Comment');
        $scope.comments.isadding = false;
    }

    $scope.closeComment = function (flag) {
        $scope.$commentModalInstance.close();

    };
})

modelBid.controller('bidTrackingWinModal', function ($scope, $modal, $http) {

    $scope.addContract = function () {
        var newRecord = $scope.objContract;
        $http.post('/api/Contracts/', newRecord).success(function (data) {

            $scope.currentcontractRecordId = data.Id;
            $scope.myContracts.push(data);
            $scope.currentIndex = $scope.myContracts.length - 1;
            $scope.isAdding = false;
            $scope.closeWin();
        }).error(function (data) {
            $scope.error = "An Error has occurred while adding Contract! " + data;
        });
    }
})

modelBid.controller('bidTrackingLoseModal', function ($scope, $modal) {
    $scope.addLoseContract = function () {
        $scope.Steps[1].step1[0].AwardedTo = $scope.AwardedTo
        $scope.Steps[1].step1[0].ContractValue = $scope.ContractValue
        $scope.Steps[1].step1[0].Duration = $scope.Duration
        $scope.closeLose();
    }
})

//<!-- ----------------RR-524 START  ------------------>
modelBid.directive('infiniteScroll', ['$rootScope', '$window', '$timeout', function ($rootScope, $window, $timeout) {
    return {
        link: function (scope, elem, attrs) {
            var checkWhenEnabled, handler, scrollDistance, scrollEnabled;
            $window = angular.element($window);
            elem.css('overflow-y', 'auto');
            elem.css('overflow-x', 'hidden');
            elem.css('height', 'inherit');
            scrollDistance = 0;
            if (attrs.infiniteScrollDistance != null) {
                scope.$watch(attrs.infiniteScrollDistance, function (value) {
                    return (scrollDistance = parseInt(value, 10));
                });
            }
            scrollEnabled = true;
            checkWhenEnabled = false;
            if (attrs.infiniteScrollDisabled != null) {
                scope.$watch(attrs.infiniteScrollDisabled, function (value) {
                    scrollEnabled = !value;
                    if (scrollEnabled && checkWhenEnabled) {
                        checkWhenEnabled = false;
                        return handler();
                    }
                });
            }
            $rootScope.$on('refreshStart', function () {
                elem.animate({ scrollTop: "0" });
            });
            handler = function () {
                var container, elementBottom, remaining, shouldScroll, containerBottom;
                container = $(elem.children()[0]);
                elementBottom = elem.offset().top + elem.height();
                containerBottom = container.offset().top + container.height();
                remaining = containerBottom - elementBottom;
                shouldScroll = remaining <= elem.height() * scrollDistance;
                if (shouldScroll && scrollEnabled) {
                    if ($rootScope.$$phase) {
                        return scope.$eval(attrs.infiniteScroll);
                    } else {
                        return scope.$apply(attrs.infiniteScroll);
                    }
                } else if (shouldScroll) {
                    return (checkWhenEnabled = true);
                }
            };
            elem.on('scroll', handler);
            scope.$on('$destroy', function () {
                return $window.off('scroll', handler);
            });
            return $timeout((function () {
                if (attrs.infiniteScrollImmediateCheck) {
                    if (scope.$eval(attrs.infiniteScrollImmediateCheck)) {
                        return handler();
                    }
                } else {
                    return handler();
                }
            }), 0);
        }
    };
}
]);
//<!-- ----------------RR-524 END  ------------------>



modelBid.controller('bidTracking',
            ['$scope', '$http', '$modal', '$rootScope', '$window', '$timeout', '$compile', 'uiGridConstants', 'uiCalendarConfig', 'BidService', '$sce', 'ActivityService', 'toaster', '$interval', 'departmentService', 'partnerService',
    function ($scope, $http, $modal, $rootScope, $window, $timeout, $compile, uiGridConstants, uiCalendarConfig, BidService, $sce, ActivityService, toaster, $interval, departmentService, partnerService) {

        //// VARIABLES DECLARATION
        $scope.loadingImage = true;
        $scope.isloading = true;           //for showing loader
        $scope.isEditing = false;          //editmode or not
        $scope.showList = false;            //for switching between add/edit page
        $scope.showView = false;           //for displaying report type snapshot page
        $scope.showEntry = false;          //for displaying add/edit page
        $scope.uploadImage = false;        //for displaying image upload popup in library tab
        $scope.showPopup = false;          //for displaying Bid / No bid page
        $scope.showPopupNAICS = false;     //for displaying NAICS selection popup
        $scope.submissionPending = false;  //for ensuring that during new entry, unless the first tab is saved, others tabs are disabled
        $scope.ImagePathU = "";            //for saving the uploaded image name
        $scope.ScoreCalculation = false;   //for controlling the scope of score calculation
        $scope.spLoad = false;             //for showing loader for service provider load in partner tab
        $scope.bidinfo = {};
        $scope.bidinfo.awardtoLoad = false;
        $scope.bidinfo.showmessage1 = false;
        $scope.companyinfo = {};
        $scope.Steps = [];                 //for holding initialized model array from StepsSource
        $scope.bidsIndex = [];             //for holding list of bids from Get api call
        $scope.currentRecordId = 0;        //for maintaining id of currently selected bid
        $scope.currentIndex = 0;           //for current array index of bidsIndex array
        $scope.currentBidRecord = {};      //for storing current selected bid details
        $scope.agencies = [];              //for storing list of agencies from database
        $scope.departments = [];           //for storing list of Departments from the database
        $scope.offices = [];
        $scope.users = [];                 //for storing list of users (needed in actions tab)
        $scope.selectedDept = {};          //for Storing selected department object from department List
        $scope.selectedAgency = {};        //for Storing selected Agency object from department List
        $scope.selectedOffice = {};        //for Storing selected Office object from Office List
        $scope.bidConstants = [];          //for fetching dropdown values from table
        $scope.rigilstatusDrpdwn = [];     //for storing rigilstatus values from bidConstants array
        $scope.bidstatusDrpDwn = [];       //for storing bidstatus values from bidConstants array
        $scope.serviceProviders = [];      //for storing the service providers 
        $scope.competetypeDrpDwn = [];     //for storing competetype values from bidConstants array
        $scope.primesubDrpDwn = [];        //for storing primesub values from bidConstants array
        $scope.bidtypeDrpDwn = [];         //for storing bidtype values from bidConstants array
        $scope.awardtypeDrpDwn = [];       //for storing awardtype values from bidConstants array

        //RR-536
        $scope.kegDrpDwn = [];             //for storing KEG values from bidConstants array
        $scope.kegConstraint = {
            showValue: false,
        };
        $scope.allContractsDrpDwn = [];        //for storing contracts values 

        $scope.bidCalculatedScore = 0.00;  //for storing bidscore when bid/no-bid decision questionnaire is filled
        $scope.filterValue = "";           //for general search text on grid 
        $scope.counter = 0;                //for storing count of hits to selectedBid function 
        $scope.commentsIndex = [];         //for holding list of comments from Get api call
        $scope.actionsIndex = [];          //for holding list of actions from Get api call
        $scope.actionitemsIndex = [];      //for holding list of actionitems from Get api call
        $scope.showTimeline = false;       //for triggering timeline display
        $scope.events = [];                  //for holding the bid tracking related changes and displaying them in a timeline
        $scope.allIDIQContracts = [];
        $scope.IDIQValue = "";
        $scope.newsIndex = [];             //for holding list of news from Get api call
        $scope.documentIndex = [];
        $scope.resourcesIndex = [];
        $scope.partnerIndex = [];
        $scope.isExpandedPOCSection = true;
        $scope.isExpandedPOCListSection = true;
        $scope.isIframe = false;
        $scope.fullFilePath = "";
        $scope.viewerFullFilePath = "";
        $scope.TrustedviewerFullFilePath = "";
        $scope.comment = {};               //for single comment new entry / old modification
        $scope.action = {};                //for single action new entry / old modification
        $scope.actionitem = {};            //for single actionitem new entry / old modification
        $scope.document = {};
        $scope.partners = {};
        $scope.News = {};                  //for single News new entry / old modification
        $scope.questionnaires = [];        //for list of questionnaires
        $scope.total_yesno_questions = 0;  //for calculating bid score
        $scope.questionnaires_scores = []; //for list of questionnaires scores of a particular bid
        $scope.NAICScodes = [];            //for list of NAICScode
        $scope.selectedNAICScodes = "";    //for selected NAICS codes
        $scope.score_notes = [];           //for holding list of user notes related to bid scores 
        $scope.backup_document = [];       //for holding backup of list of bid_document for undo purpose during news entry / edit
        $scope.backup_comments = [];       //for holding backup of list of bid_comments for undo purpose during new comment entry / edit
        $scope.backup_actions = [];        //for holding backup of list of bid_actions for undo purpose during new action entry / edit
        $scope.backup_actionitems = [];    //for holding backup of list of bid_actionitems for undo purpose during new actionitem entry / edit
        $scope.backup_news = [];           //for holding backup of list of bid_news for undo purpose during news entry / edit
        $scope.oldNAICSval = "";           //for holding old values
        $scope.passingBidscore = 0;        //for holding master value of passing Bid score
        $scope.isBidscorePass = false;     //for keeping status of pass/fail bid score
        $scope.isBidDetExpanded = false;   //for show/hide additional header info in Bid/No Bid questionnaire
        $scope.bidNote = "";               //for bid note during Bid/No Bid questionnaire interaction
        $scope.bidResearchid = 0;          //for storing selected Bid Research Record Id 
        $scope.mouse_over = false;
        $scope.mouse_over_cv = false;
        $scope.showTaskTable = true;       //for show / hide of task table in Actions tab
        $scope.isActionSelected = false;   //for keeping track whether action selected or not
        $scope.isActionItemSelected = false; //for keeping track whether actionitem selected or not
        $scope.BidRating = [];

        $scope.lostbidsState = 0;
        $scope.lostbidsStateTF = false;
        $scope.lostbidsarr = {};
        $scope.orgBidsArray = [];
        $scope.generalBidsArray = [];

        $scope.emoji = "NONE";
        $scope.isNewOpp = false;

        $scope.predicate = "ChangeDate";
        $scope.reverse = true;

        $scope.trustedHtmlSummary = "";

        //Validations between " Bid Type", " Bid status" and "Proposal Stage"
        $scope.restrict_proposalstageIds_when_RFI = [2, 10, 26, 27];
        $scope.restrict_bidstatusIds_when_RFI = [14, 15, 29, 42];
        $scope.restrict_proposalstageIds_when_RFP = [3, 4, 11];
        $scope.restrict_bidstatusIds_when_RFP = [];
        $scope.restrict_proposalstageIds_when_QUOTE = [3, 4, 11];
        $scope.restrict_bidstatusIds_when_QUOTE = [];
        $scope.restrict_bidstatusIds_when_NOTIMPORTED = [62];
        $scope.proposalstageIds = [];
        $scope.bidstatusIds = [];

        $scope.showBidFilter = false;
        $scope.modifiedBidStatusList = [];
        $scope.writingflag = false;
        $scope.fullCalendarFlag = false;
        $scope.complianceflag = false;
        $scope.isShowWaitingIcon = false;
        //RR-446
        $scope.typeObj = {
            PartnerTypeObj: {
                Id: 0,
                Name: ""
            },
        }
        $scope.partnerTypeDrpDwn = [];       //for storing partnertype values from bidConstants array

        // RR - 520
        $scope.ctrlVar = {
            isArchived: false
        }

        $scope.isdeletedA = false;
        $scope.isdeletedD = false;
        $scope.isdeletedL = false;
        $scope.debrieffiles = [];
        $scope.ACTION = {
            actionTitle: '',
            actionText: '',
            actionDueDate: '',
            assignees: [],
            actionStatus: '',
            //RR-537
            assignedBy: ''
        }

        $scope.ACTIONITEM = {
            actionTitle: '',
            actionText: '',
            actionStartDate: '',
            actionDueDate: '',
            actionDueTime: '',
            assignees: [],
            reminderDate: '',
            snoozeTimes: 0,
            isMilestone: false,
            pcComplete: 0,
            //RR-537
            assignedBy: ''
        }
        $scope.bellLength = 0;
        $scope.printAdvData = [];
        $scope.rfiDate = new Date("01/01/1900");
        $scope.rfpDate = new Date("01/01/1900");
        $scope.isRfiSubmitted = false;

        $scope.researchCformId = 0;
        $scope.proposalPlanningformId = 0;
        $scope.formInfoListData = [];
        $scope.allRoles = [];


        $scope.exceptedTurnAround = 0;
        $scope.clientContracts = "";

        //RR-528
        $scope.coreCompetenciesDropDwn = [];

        //////////////////////////////////////////////////////////////
        //Rating code

        $scope.rating_max = 5;

        //api service call of all data together
        BidService.assortedCalls().loadAllCalls()
            .then(function (response) {

                var redirect = sessionStorage.getItem("DashboardRedirectBid");
                var idvalue = parseInt(sessionStorage.getItem("BidId"));
                if (redirect == "true") {
                    $scope.selectedBid(idvalue, 'E', idvalue);
                    $scope.showEntry = true;
                    $scope.showList = false;
                    sessionStorage.removeItem("DashboardRedirectBid");
                    sessionStorage.removeItem("BidId");
                }
                else {
                    $scope.showEntry = false;
                    $scope.showList = true;
                }
                $scope.allDataSet = response;

                $scope.passingBidscore = $scope.allDataSet[0].data[0].Value;

                $scope.users = $scope.allDataSet[1].data;
                $scope.allIDIQContracts = $scope.allDataSet[2].data.data;
                $scope.bidConstants = $scope.allDataSet[3].data;
                $scope.bidCount = 0;
                if ($scope.bidConstants.length > 0) {
                    angular.forEach($scope.bidConstants, function (value, index) {
                        if ($scope.bidConstants[index].Constant_Type == 'PROPOSALSTAGE') { $scope.proposalstageIds.push($scope.bidConstants[index]); }
                        if ($scope.bidConstants[index].Constant_Type == 'BIDSTATUS') { $scope.bidstatusIds.push($scope.bidConstants[index]); }
                        if ($scope.bidConstants[index].Constant_Type == 'COMPETITIONTYPE') { $scope.competetypeDrpDwn.push($scope.bidConstants[index]); }
                        if ($scope.bidConstants[index].Constant_Type == 'PRIMESUB') { $scope.primesubDrpDwn.push($scope.bidConstants[index]); }
                        if ($scope.bidConstants[index].Constant_Type == 'BIDTYPE') { $scope.bidtypeDrpDwn.push($scope.bidConstants[index]); }
                        if ($scope.bidConstants[index].Constant_Type == 'AWARDTYPE') { $scope.awardtypeDrpDwn.push($scope.bidConstants[index]); }
                        //RR-536
                        if ($scope.bidConstants[index].Constant_Type == 'KEG') { $scope.kegDrpDwn.push($scope.bidConstants[index]); }
                    })
                    $scope.bidCount = $scope.bidConstants.length;
                }
                angular.copy($scope.bidstatusIds, $scope.bidstatusDrpDwn);
                angular.copy($scope.proposalstageIds, $scope.rigilstatusDrpdwn);

                $scope.orgBidsArray = $scope.allDataSet[4].data;

                angular.forEach($scope.orgBidsArray, function (value, index) {

                    value['RelDays'] = $scope.daysToGo(value.Projected_releaseDate);
                    value['BiddingStage'] = $scope.bidStageText(value.Rigil_Stage);
                    value['BiddingStatus'] = $scope.bidStatusText(value.Bid_statusId);
                    value['CompetitionType'] = $scope.bidCompetitionTypeText(value.Bid_competitionTypeId);
                    value['BiddingType'] = $scope.bidTypeToText(value.Bid_typeId);
                    value['PrimeSubType'] = $scope.PrimeSubTypeToText(value.Prime_Sub);
                    value['RigilStageType'] = $scope.RigilStageToText(value.Rigil_Stage);
                    value['BiddingAwardType'] = $scope.bidAwardTypeToText(value.Award_typeId);
                    value['allIDIQlist'] = $scope.allIDIQContracts;
                    value['TotalValue_short'] = value.Total_dollarValue / 1000000;
                    if (value.AgencyKey) {
                        value['AgencyName'] = value.AgencyKey.Agencyname;
                    } else {
                        value['AgencyName'] = "";
                    }
                    if (value.AgencyKey) {
                        value['AgencyAcronym'] = value.AgencyKey.Acronym;
                    } else {
                        value['AgencyAcronym'] = "";
                    }
                    value.Ratings = JSON.parse(value.Ratings);


                })

                $scope.bidsIndex = [];
                angular.copy($scope.orgBidsArray, $scope.bidsIndex);
                $scope.bidCount = $scope.bidsIndex.length;
                $scope.isloading = false;

                $scope.modifiedBidStatusList = $scope.allDataSet[10].data.types;
                //for nav tab bid status filter
                updateGridDataGlobally();
                $scope.gridOptions.data = $scope.bidsIndex;

                $scope.savedState = $scope.allDataSet[5].data;
                if ($scope.savedState.Value != null) {
                    //if previous saved state exists
                    $scope.state = JSON.parse($scope.savedState.Value);
                    //$scope.restoreState();
                }

                $scope.questionnaires = $scope.allDataSet[6].data;
                $scope.total_yesno_questions = 0;
                var questionsCount = 0;
                angular.forEach($scope.questionnaires, function (value1, index1) {
                    if (value1.ResponseType == 'yesno') { questionsCount = questionsCount + 1; }
                })
                $scope.total_yesno_questions = questionsCount;

                $scope.NAICScodes = $scope.allDataSet[7].data;
                $scope.naicsCount = $scope.NAICScodes.length;
                angular.forEach($scope.NAICScodes, function (value, index) {
                    value.index = index;
                })
                $scope.departments = $scope.allDataSet[8].data.agencyList;

                $scope.deptAgencies = $scope.allDataSet[9].data.fullAgencyList;
                $scope.researchCformId = $scope.allDataSet[11].data.result;
                $scope.proposalPlanningformId = $scope.allDataSet[12].data.result;
                $scope.partnerTypeDrpDwn = $scope.allDataSet[13].data.types;
                $scope.formInfoListData = $scope.allDataSet[14].data.result;
                $scope.allRoles = $scope.allDataSet[15].data.result;
                //RR-536
                $scope.allContractsDrpDwn = $scope.allDataSet[16].data.data;

                arrangedBidType();
                awardBidType();
                primeSubType();
                aproposalstageType();
                bidingStatusType();
                compotiontionType();
                $scope.loadingImage = false;
            });

        $scope.getForm = function (moduleId) {
            $http.get('/Home/GetAllForms?moduleId=' + moduleId).success(function (data) {
                if (data.data == "success")
                    $scope.formInfoListData = data.result;
            })
        }
        //  RR-520 Start
        $scope.archivedSwitch = function () {
            var isArchived = $scope.ctrlVar.isArchived;
            $scope.isShowWaitingIcon = true;
            $http.get('/api/Bids?isArchived=' + isArchived).success(function (response) {
                $scope.orgBidsArray = response;
                angular.forEach($scope.orgBidsArray, function (value, index) {

                    value['RelDays'] = $scope.daysToGo(value.Projected_releaseDate);
                    value['BiddingStage'] = $scope.bidStageText(value.Rigil_Stage);
                    value['BiddingStatus'] = $scope.bidStatusText(value.Bid_statusId);
                    value['CompetitionType'] = $scope.bidCompetitionTypeText(value.Bid_competitionTypeId);
                    value['BiddingType'] = $scope.bidTypeToText(value.Bid_typeId);
                    value['PrimeSubType'] = $scope.PrimeSubTypeToText(value.Prime_Sub);
                    value['RigilStageType'] = $scope.RigilStageToText(value.Rigil_Stage);
                    value['BiddingAwardType'] = $scope.bidAwardTypeToText(value.Award_typeId);
                    value['allIDIQlist'] = $scope.allIDIQContracts;
                    value['TotalValue_short'] = value.Total_dollarValue / 1000000;
                    if (value.AgencyKey) {
                        value['AgencyName'] = value.AgencyKey.Agencyname;
                    } else {
                        value['AgencyName'] = "";
                    }
                    if (value.AgencyKey) {
                        value['AgencyAcronym'] = value.AgencyKey.Acronym;
                    } else {
                        value['AgencyAcronym'] = "";
                    }
                    value.Ratings = JSON.parse(value.Ratings);
                })

                $scope.bidsIndex = [];
                angular.copy($scope.orgBidsArray, $scope.bidsIndex);
                $scope.bidCount = $scope.bidsIndex.length;
                $scope.isloading = false;

                $scope.modifiedBidStatusList = $scope.allDataSet[10].data.types;
                //for nav tab bid status filter
                updateGridDataGlobally();
                $scope.gridOptions.data = $scope.bidsIndex;
                $scope.isShowWaitingIcon = false;

            }).error(function (response) {
                $scope.error = "An Error has occurred !! " + response;
                $scope.isShowWaitingIcon = false;

            });
            if (isArchived) {
                archivedStatus = "Archived"
                $scope.gridOptions.columnDefs[0].visible = false;
            }
            else {
                archivedStatus = "Active";
                $scope.gridOptions.columnDefs[0].visible = true;
            }
        }
        //  RR-520 End

        // $scope.getForm(1);//1 for module Bid
        //method called from grid
        $scope.setRatingGrid = function (rating, BidId, ratingsArr, oldrating, ratingID) {

            $scope.ratings_temp = {};
            $scope.ratings_temp = ratingsArr;
            $scope.rating_temp = rating + 1;
            for (i = 0; i < $scope.rating_max; i++) {
                if (i < $scope.rating_temp) {
                    $scope.ratings_temp[i] = "True";
                } else {
                    $scope.ratings_temp[i] = "False";
                }
            }
            $scope.ratingArr_temp = {
                bidId: BidId,
                rate: $scope.rating_temp,
                rating: JSON.stringify($scope.ratings_temp)
            }

            if (ratingID == 0) {
                $http.post("/api/Bid_Ratings", $scope.ratingArr_temp).success(function (data) {
                    //update grid record columns...RatingId,Rating,Ratings
                    angular.forEach($scope.bidsIndex, function (value, index) {
                        if (value.Id == BidId) {
                            value.Rating = $scope.rating_temp;
                            value.Ratings = $scope.ratings_temp;
                            value.RatingId = data.id;
                        }
                    })
                })
            } else {
                $http.put("/api/Bid_Ratings?id=" + ratingID, $scope.ratingArr_temp).success(function () {
                    //update grid record columns...RatingId,Rating,Ratings
                    angular.forEach($scope.bidsIndex, function (value, index) {
                        if (value.Id == BidId) {
                            value.Rating = $scope.rating_temp;
                            value.Ratings = $scope.ratings_temp;
                        }
                    })
                })
            }
        }

        //method called from Bid detail
        $scope.getSelectedRating = function (rating) {
            $scope.rating = rating + 1;
            for (i = 0; i < $scope.rating_max; i++) {
                if (i < $scope.rating) {
                    $scope.ratings[i] = "True";
                } else {
                    $scope.ratings[i] = "False";
                }
            }
            $scope.ratingArr = {
                bidId: $scope.currentRecordId,
                rate: $scope.rating,
                rating: JSON.stringify($scope.ratings)
            }

            if ($scope.BidRating == null) {
                $http.post("/api/Bid_Ratings", $scope.ratingArr).success(function (data) {
                    //loadrating
                    $scope.loadRating($scope.currentRecordId);
                    //update grid
                    angular.forEach($scope.bidsIndex, function (value, index) {
                        if (value.Id == $scope.currentRecordId) {
                            value.Rating = $scope.ratingArr.rate;
                            value.Ratings = $scope.ratings;
                            value.RatingId = data.id;
                        }
                    })
                })
            } else {
                $http.put("/api/Bid_Ratings?id=" + $scope.ratingId, $scope.ratingArr).success(function () {
                    //loadrating
                    $scope.loadRating($scope.currentRecordId);
                    //update grid
                    angular.forEach($scope.bidsIndex, function (value, index) {
                        if (value.Id == $scope.currentRecordId) {
                            value.Rating = $scope.ratingArr.rate;
                            value.Ratings = $scope.ratings;
                        }
                    })
                })
            }
        }
        // RR-528 Bind CoreCompetency
        $scope.getCoreCompetencies = function () {
            $scope.coreCompetenciesDropDwn = [];
            $http.get('/Home/GetCoreCompetencyDropdown').success(function (data) {
                if (data.IsSuccess) {
                    $scope.coreCompetenciesDropDwn = data.responseData;
                }
                else {
                    $scope.coreCompetenciesDropDwn = [];
                }
            })
        }

        $scope.getCoreCompetencies();
        //////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////
        //partner data initial collection onchange of %

        $scope.onChange_Workshare = function () {
            $scope.requiredValues = {

            };

            var modalInstance = $modal.open({
                templateUrl: '../tpl/modal/PartnerInfo.html',
                controller: 'ModalInstanceCtrl',
                backdrop: 'static',
                scope: $scope,

            });

            app.controller('ModalInstanceCtrl', ['$scope', '$controller', '$modalInstance', '$http', 'toaster', '$q', function ($scope, $controller, $modalInstance, $http, toaster, $q) {

                //cancel button click
                $scope.cancel = function () {
                    $modalInstance.close();
                }

                //close button click
                $scope.close = function () {
                    $modalInstance.close();
                }

            }]);
        }






        $scope.$on("bidEvent", function (evt, data) {
        });
        $scope.codeErrorMessage = "";

        $scope.task_Actions = [];
        $scope.task_ActionItems = [];
        $scope.task_inprogressItems = [];
        $scope.task_doneItems = [];
        $scope.task_users = [];
        $scope.moveFromColumn = 0;       //set in action board drag start event
        $scope.moveToColumn = 0;         //set in action board drag end event
        $scope.isdeletionConfirmed = false; //used in deleteInstance for keeping track whether user selected 'OK' to go ahead with deletion (only then action board will be updated) 
        $scope.currentdate = new Date();
        $scope.maxdate = "";
        $scope.showKanbanBoard = false;
        $scope.showGnattChart = true;
        $scope.showCalendar = true;
        var srcActionItemId = 0;
        $scope.GANTTdata = [];

        // Pagination control related
        $scope.HcurrentPage = 0;
        $scope.LcurrentPage = 0;
        $scope.Hstartindex = 0;
        $scope.HpageChanged = function (pageno) {
            $scope.Hstartindex = (pageno * $scope.maxSize) - $scope.maxSize;
        };

        $scope.getHistory = function (id) {
            //bidHistory
            $http.get('/api/Bid_History/' + id).success(function (data) {
                $scope.bidHistory = data;
                $scope.HbidsCount = data.length;
            })
        }

        $scope.showimage = function (uniquename, filename, filetype, filepath) {
            $scope.documentID = uniquename;
            $scope.documentNAME = filename;
            $scope.documentFILETYPE = filetype;
            $scope.fullFilePath = filepath + $scope.documentID;
            $scope.viewerFullFilePath = "<iframe src='https://docs.google.com/viewer?url=" + filepath + $scope.documentID + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
            $scope.TrustedviewerFullFilePath = $sce.trustAsHtml($scope.viewerFullFilePath);
            $scope.isIframe = true;
        }



        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //prepare data for GANTT chart
        $scope.cookGANTTdata = function () {
            $scope.GANTTdata = [];

            //add root node first
            var rootObj = {
                name: 'Bid'
            };
            $scope.GANTTdata.push(rootObj);

            //add milestones first
            var milestone = {
                name: 'Milestones',
                parent: 'Bid',
                height: '3em',
                sortable: false,
                classes: 'gantt-row-milestone',
                color: 'lightblue',
                tasks: []
            }
            angular.forEach($scope.actionitemsIndex, function (value, index) {
                var task = {};
                if (value.IsMilestone) {
                    task = {
                        name: value.ActionItem,
                        color: 'rgba(66, 139, 202, 1)',
                        from: (value.Start_From),
                        to: (value.ActionDue_dateTime),
                        content: value.ActionItem_Title,
                        movable: false
                    }
                    milestone.tasks.push(task);
                }
            })
            $scope.GANTTdata.push(milestone);


            //add lowest level nodes second
            angular.forEach($scope.actionitemsIndex, function (value, index) {
                var subitem = {
                    name: '',
                    tasks: []
                };

                var task = {};
                //to do
                if (value.ActionItem_Status == 0) {
                    task = {
                        name: value.ActionItem,
                        color: 'rgba(240, 80, 80, 0.25)',
                        from: (value.Start_From),
                        to: (value.ActionDue_dateTime),
                        content: value.ActionItem_Title,
                        movable: false,
                    }
                }
                    //inprogress
                else if (value.ActionItem_Status == 1) {
                    task = {
                        name: value.ActionItem,
                        color: 'rgba(255, 255, 0, 0.40)',
                        from: (value.Start_From),
                        to: (value.ActionDue_dateTime),
                        content: value.ActionItem_Title,
                        movable: false,
                    }
                }
                    //done
                else if (value.ActionItem_Status == 2) {
                    task = {
                        name: value.ActionItem,
                        color: 'rgba(0, 128, 0, 0.25)',
                        from: (value.Start_From),
                        to: (value.ActionDue_dateTime),
                        movable: false,
                        content: value.ActionItem_Title
                    }
                }

                subitem.name = value.ActionItem_Title;
                subitem.tasks.push(task);
                $scope.GANTTdata.push(subitem);
            })

            //add parent nodes third and attach with child nodes
            angular.forEach($scope.task_Actions, function (valueA, indexA) {
                var group = {
                    name: '',
                    parent: '',
                    children: []
                };

                group.name = valueA.action_title;
                group.parent = 'Bid';
                angular.forEach(valueA.actionItems, function (valueA0, indexA0) {
                    group.children.push(valueA0.actionitem_title);
                })

                angular.forEach(valueA.inprogressItems, function (valueA1, indexA1) {
                    group.children.push(valueA1.actionitem_title);
                })

                angular.forEach(valueA.doneItems, function (valueA2, indexA2) {
                    group.children.push(valueA2.actionitem_title);
                })
                $scope.GANTTdata.push(group);
            })
        }

        //gantt chart API events handling
        //ref:https://www.angular-gantt.com/configuration/api/
        $scope.registerApi = function (api) {
            api.tasks.on.change($scope, function (task) {
                console.log("Name:" + task.model.content);
                console.log("Org from:" + task.model.from._i + "   " + "Org to:" + task.model.to._i);
                console.log("New from:" + task.model.from._d + "   " + "New to:" + task.model.to._d);
            });
            //api.data.on.change($scope, function (newData, oldData) {
            //     //
            //    var i = 0;
            //});
        }

        //defaults for timepicker in actionitems

        $scope.mytime = new Date();

        $scope.hstep = 1;
        $scope.mstep = 5;

        $scope.options = {
            hstep: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
            mstep: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55]
        };

        $scope.ismeridian = true;
        $scope.toggleMode = function () {
            $scope.ismeridian = !$scope.ismeridian;
        };

        $scope.update = function () {
            var d = new Date();
            d.setHours(14);
            d.setMinutes(0);
            $scope.mytime = d;
        };

        $scope.changed = function () {
            //console.log('Time changed to: ' + $scope.mytime);
        };

        $scope.clear = function () {
            $scope.mytime = null;
        };
        ////////////////////////////////////////////////////////////////////////////////////

        $scope.containsId = function contains(arr, value) {
            var i = arr.length;
            while (i--) {
                if (arr[i].id === value) return true;
            }
            return false;
        }


        //Validations between " Bid Type", " Bid status" and "Proposal Stage"
        $scope.bidTypeOnchange = function (id, bidId) {
            $scope.Steps[1].step1[0].rigilStage = "";
            //
            //RFI
            if (id == 13) {
                var pos = 0;
                angular.copy($scope.bidstatusIds, $scope.bidstatusDrpDwn)
                for (var i = $scope.bidstatusDrpDwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_bidstatusIds_when_RFI.indexOf($scope.bidstatusDrpDwn[i].Id);
                    if (pos != -1) {
                        $scope.bidstatusDrpDwn.splice(i, 1);
                    }
                }
                angular.copy($scope.proposalstageIds, $scope.rigilstatusDrpdwn);
                for (var i = $scope.rigilstatusDrpdwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_proposalstageIds_when_RFI.indexOf($scope.rigilstatusDrpdwn[i].Id);
                    if (pos != -1) {
                        $scope.rigilstatusDrpdwn.splice(i, 1);
                    }
                }
            }
            //RFP
            if (id == 16) {
                $scope.Steps[1].step1[0].status = "";
                var pos = 0;
                angular.copy($scope.bidstatusIds, $scope.bidstatusDrpDwn)
                for (var i = $scope.bidstatusDrpDwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_bidstatusIds_when_RFP.indexOf($scope.bidstatusDrpDwn[i].Id);
                    if (pos != -1) {
                        $scope.bidstatusDrpDwn.splice(i, 1);
                    }
                }
                angular.copy($scope.proposalstageIds, $scope.rigilstatusDrpdwn);
                for (var i = $scope.rigilstatusDrpdwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_proposalstageIds_when_RFP.indexOf($scope.rigilstatusDrpdwn[i].Id);
                    if (pos != -1) {
                        $scope.rigilstatusDrpdwn.splice(i, 1);
                    }
                }
            }
            //QUOTE
            if (id == 20) {
                $scope.Steps[1].step1[0].status = "";
                var pos = 0;
                angular.copy($scope.bidstatusIds, $scope.bidstatusDrpDwn)
                for (var i = $scope.bidstatusDrpDwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_bidstatusIds_when_QUOTE.indexOf($scope.bidstatusDrpDwn[i].Id);
                    if (pos != -1) {
                        $scope.bidstatusDrpDwn.splice(i, 1);
                    }
                }
                angular.copy($scope.proposalstageIds, $scope.rigilstatusDrpdwn);
                for (var i = $scope.rigilstatusDrpdwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_proposalstageIds_when_QUOTE.indexOf($scope.rigilstatusDrpdwn[i].Id);
                    if (pos != -1) {
                        $scope.rigilstatusDrpdwn.splice(i, 1);
                    }
                }
            }
            if (bidId == 0)//new bid so remove the option for auto imported bid type
            {
                for (var i = $scope.bidstatusDrpDwn.length - 1; i >= 0; i--) {
                    pos = $scope.restrict_bidstatusIds_when_NOTIMPORTED.indexOf($scope.bidstatusDrpDwn[i].Id);
                    if (pos != -1) {
                        $scope.bidstatusDrpDwn.splice(i, 1);
                    }
                }
            }
            if (bidId > 0)//old bid so checjk whether the bid was imported or created if created remove the option for auto imported bid type
            {
                var bidobj = _.find($scope.bidsIndex, function (obj) { return obj.Id == bidId });
                if (!bidobj.isImported) {
                    for (var i = $scope.bidstatusDrpDwn.length - 1; i >= 0; i--) {
                        pos = $scope.restrict_bidstatusIds_when_NOTIMPORTED.indexOf($scope.bidstatusDrpDwn[i].Id);
                        if (pos != -1) {
                            $scope.bidstatusDrpDwn.splice(i, 1);
                        }
                    }
                }
            }
        }

        $scope.opendp = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened = true;
        };

        $scope.opendp1 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened1 = true;
        };

        $scope.opendp2 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened2 = true;
        };

        $scope.dateOptions = {
            class: 'datepicker'
        };

        $scope.dateTimeOptions = { useCurrent: false, showClear: true, showClose: true, maxDate: moment().add(1, 'days') };

        $scope.dateTimeOptionsRFP = { useCurrent: false, showClear: true, showClose: true, maxDate: moment().add(1, 'days') };

        $scope.opendp3 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened3 = true;
        };

        $scope.opendp4 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened4 = true;
        };

        $scope.opendp5 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened5 = true;
        };

        $scope.opendp6 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened6 = true;
        };

        $scope.opendp7 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened7 = true;
        };

        $scope.opendp8 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened8 = true;
        };

        $scope.opendp9 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened9 = true;
        };

        $scope.opendp10 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened10 = true;
        };

        $scope.opendp11 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened11 = true;
        };
        $scope.opendp12 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened12 = true;
        };
        $scope.opendp13 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened13 = true;
        };
        $scope.opendp14 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened14 = true;
        };

        $scope.opendp15 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened15 = true;
        };


        $scope.setMaxdate = function (date) {
            //$scope.maxdate = new Date()+4;
            $scope.maxdate = date;
        }

        $scope.kanbanSortOptions = {


            //restrict move across columns. move only within column.
            /*accept: function (sourceItemHandleScope, destSortableScope) {
             return sourceItemHandleScope.itemScope.sortableScope.$id === destSortableScope.$id;
             },*/
            itemMoved: function (event) {
                $scope.isShowWaitingIcon = true;
                var srcTaskActionId = $scope.task_Actions[event.source.sortableScope.$parent.$index].id;       //got 'From' Action ID
                var destTaskActionId = $scope.task_Actions[event.dest.sortableScope.$parent.$index].id;        //got 'To' Action ID

                //now getting moved to which column
                if ($scope.containsId($scope.task_Actions[event.dest.sortableScope.$parent.$index].actionItems, srcActionItemId)) { $scope.moveToColumn = 0; }
                else if ($scope.containsId($scope.task_Actions[event.dest.sortableScope.$parent.$index].inprogressItems, srcActionItemId)) { $scope.moveToColumn = 1; }
                else if ($scope.containsId($scope.task_Actions[event.dest.sortableScope.$parent.$index].doneItems, srcActionItemId)) { $scope.moveToColumn = 2; }

                //update action item table
                $scope.actionitems.isediting = true;
                $scope.editoldInstance(srcActionItemId, 'Actionitem');
                $scope.actionitem.ActionId = destTaskActionId;
                $scope.actionitem.ActionItem_Status = $scope.moveToColumn;
                //
                $scope.saveInstance($scope.actionitem.Id, 'Actionitem');

            },
            orderChanged: function (event) {
            },
            dragStart: function (event) {
                $scope.isShowWaitingIcon = true;
                srcActionItemId = event.source.sortableScope.modelValue[event.source.index].id;

                //now getting moving from which column
                if ($scope.containsId($scope.task_Actions[event.source.sortableScope.$parent.$index].actionItems, srcActionItemId)) { $scope.moveFromColumn = 0; }
                else if ($scope.containsId($scope.task_Actions[event.source.sortableScope.$parent.$index].inprogressItems, srcActionItemId)) { $scope.moveFromColumn = 1; }
                else if ($scope.containsId($scope.task_Actions[event.source.sortableScope.$parent.$index].doneItems, srcActionItemId)) { $scope.moveFromColumn = 2; }
            },
            dragEnd: function (event) {
            },
            containment: '#board'
        };

        // Pagination control related

        $scope.bidCount = 0;
        $scope.naicsCount = 0;

        $scope.currentPage = 0;
        $scope.currentPageNAICS = 0;

        $scope.startindex = 0;
        $scope.startindexNAICS = 0;

        $scope.pageChanged = function () {
            $scope.startindex = ($scope.currentPage * 10) - 10;
        };

        $scope.pageChangedNAICS = function () {
            $scope.startindexNAICS = ($scope.currentPageNAICS * 10) - 10;
        };

        $scope.maxSize = 10;
        $scope.bigTotalItems = 1000;
        $scope.bigCurrentPage = 1;
        $scope.isAttachmentUploading = false;
        $scope.isAttachmentDebriefUploading = false;
        $scope.attachments = [];
        $scope.myContracts = [];

        //format date in date-time-picker control
        $scope.formatdate = function (sdate) {
            var d = new Date(sdate);
            var currDay = "";
            if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
            var currMonth = "";
            if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
            var currYear = d.getFullYear();
            var startDate = currMonth + "/" + currDay + "/" + currYear;
            return startDate;
        }
        $scope.formatdatetime = function (sdate) {
            var dateObj = new Date(sdate);
            var currDay = "";
            if (dateObj.getDate() < 10) { currDay = "0" + dateObj.getDate(); } else { currDay = dateObj.getDate(); }
            var currMonth = "";
            if ((dateObj.getMonth() + 1) < 10) { currMonth = "0" + (dateObj.getMonth() + 1); } else { currMonth = dateObj.getMonth() + 1; }
            var currYear = dateObj.getFullYear();
            var hours = dateObj.getHours();
            var minutes = dateObj.getMinutes();
            var typo = "AM"
            if (hours > 12) {
                hours = hours - 12;
                typo = "PM";
            }
            var newdate = currMonth + "/" + currDay + "/" + currYear + " " + hours + ":" + minutes + ":" + typo;
            return newdate;
        }

        //reset status dropdown value depending on isProjected is true/false
        $scope.resetStatus = function (boolval) {
            if (boolval) {
                //$scope.Steps[1].step1[0].status = 5;
            }
        }


        //days to go
        $scope.daysToGo = function (data) {
            var daystogo;
            var submitdate;
            var currentdate;
            var timeDiff;

            submitdate = new Date(data);
            currentdate = new Date();
            timeDiff = Math.abs(submitdate.getTime() - currentdate.getTime());
            daystogo = Math.ceil(timeDiff / (1000 * 3600 * 24));

            if (currentdate > submitdate) { daystogo = daystogo * -1; }

            return daystogo;
        }

        $scope.daysDifference = function (datefrom, dateto) {
            var daystogo;
            var fromdate;
            var todate;
            var timeDiff;

            fromdate = new Date(datefrom);
            todate = new Date(dateto);
            timeDiff = Math.abs(todate.getTime() - fromdate.getTime());
            daystogo = Math.ceil(timeDiff / (1000 * 3600 * 24));

            if (fromdate > todate) { daystogo = daystogo * -1; }

            $scope.exceptedTurnAround = daystogo;
        }

        //calculates datediff with today
        $scope.daysToRelease = function (id, rDate, sDate, isProjected) {
            var daystogo;
            var submitdate;
            var currentdate;
            var timeDiff;
            if ((rDate != "" && id == "releasedate") || isProjected) {
                submitdate = new Date(rDate);
                currentdate = new Date();
                var timeDiff = submitdate.getTime() - currentdate.getTime();
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                daystogo = diffDays;
                return daystogo;
            }
            else if ((sDate != "" && id == "submittaldate") || !isProjected) {
                submitdate = new Date(sDate);
                currentdate = new Date();
                var timeDiff = submitdate.getTime() - currentdate.getTime();
                var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
                daystogo = diffDays;
                return daystogo;
            }
        }

        ////JAVASCRIPT MODEL CLASSES 

        //javascript model class for bid Object
        var bidInfoModel = {
            Id: 0,
            Award_typeId: 0,
            Bid_typeId: 0,
            Rigil_Stage: 0,
            Projected_releaseDate: "01/01/1900",
            isProjected: false,
            Proposal_submittalDate: "01/01/1900",
            Proposal_submittedDate: "01/01/1900",
            Proposal_submittedTime: "",
            Proposal_submittedTimeOnly: "",
            Code_Name: "",
            Prime_Sub: "",
            Bid_Score: 0,
            Bid_Decision: false,
            Days_toRelease: 0,
            Status: "",
            DepartmentName: "",
            AgencyName: "",
            Title: "",
            Acronym: "",
            Solicitation_Num: "",
            Solicitation_Date: "01/01/1900",
            Bid_competitionTypeId: 0,
            Work_Share: 0,
            Total_dollarValue: 0.00,
            Rigil_dollarValue: 0.00,
            Bid_statusId: 0,
            OpportunityId: "",
            Projected_awardDate: "01/01/1900",
            Summary: "",
            AwardedTo: "",
            ContractValue: 0,
            Duration: '',
            link: "",
            IDIQID: 0,
            BusinessArea: "",
            Debrief_Request: "01/01/1900",
            Debrief_Received: "01/01/1900",
            Pop_Start: "01/01/1900",
            Pop_End: "01/01/1900",
            Debrief_Description: "",
            OfficeKey: {
                Agency_Id: "",
                Id: 0,
                OfficeName: ""
            },
            DepartmentKey: {
                Id: 0,
                Agencyname: "",
                Acronym: "",
                TypeIndicator: ""
            },
            AgencyKey: {
                Id: 0,
                Agencyname: "",
                Acronym: "",
                TypeIndicator: ""
            },
            CLocationZip: "",
            CLocationCity: "",
            CLocationState: "",
            CManager: "",
            PManager: "",
            AwardNumber: 0,
            RFISubmittedDate: "01/01/1900",
            RFIDueDate: "01/01/1900",
            WorkLocation: "",
            //RR-541
            FollowDate: "01/01/1900",
            AssignedFollowRole: "",
            //RR-536
            KEGId: 0,
            ContractId: 0,
            ContractPMName: "",
            ContractPMEmail: "",
            ContractPMPhone: "",
            //RR-545
            DocSource: "",

        };

        //javascript model for class BidstatusTrackModel
        var bidStatusTrackModelObj = {
            id: 0,
            BidId: 0,
            ChangeDate: "01/01/1900",
            UserId: "",
            BidType: 0,
            BidType_Changed: false,
            OurStage: 0,
            OurStage_Changed: false,
            BidStage: 0,
            BidStage_Changed: false
        }

        //javascript model for class Comment_Bid_NoBid Object
        var sideBidScoreModel = {
            Id: 0,
            ModuleId: 0,
            RecordId: 0,
            UserId: "",
            Comment_dateTime: "01/01/1900",
            Prevailing_Score: 0,
            Bid_Decision: false,
            Comment: "",
        }

        //javascript model class for bid_comment object
        var commentObj = {
            Id: 0,
            BidId: 0,
            Comment: "",
            UserId: "",
            Comment_dateTime: null,
            Add: false,
            Edit: false,
            Delete: false
        }

        //javascript model class for bid_action object
        var actionObj = {
            Id: 0,
            BidId: 0,
            Action_Title: "",
            Action_takenLastWeek: "",
            UserId: "",
            Action_dateTime: null,
            Status: false,
            DueDate: null,
            Comments: "",
            Add: false,
            Edit: false,
            Delete: false
        }

        //javascript model for bid_action task board
        var actionObjUI = {
            bidId: 0,
            id: 0,
            action_title: '',
            action: '',
            comment: '',
            dueDate: new Date(),
            users: {},
            actionItems: [],
            inprogressItems: [],
            doneItems: [],
            snoozeTimes: 0
        }

        //javascript model class for bid_actionitems object
        var actionitemObj = {
            Id: 0,
            BidId: 0,
            ActionId: 0,
            ActionItem_Title: "",
            ActionItem: "",
            Actionable_Actioned: false,
            By_userId: "",
            Action_dateTime: null,
            Start_From: null,
            ActionDue_dateTime: null,
            ActionDue_TimeOnlyDT: null,
            ReminderDate_dateTime: null,
            Snooze_times: 0,
            Snooze_history: '',
            ActionItem_Status: 0,
            IsMilestone: false,
            pc_complete: 0,
            Add: false,
            Edit: false,
            Delete: false
        }

        //javascript model for bid_actionitems task board
        var actionitemObjUI = {
            bidId: 0,
            actionId: 0,
            id: 0,
            actionitem_title: '',
            Item: '',
            startDate: new Date(),
            dueDate: new Date(),
            dueTime: new Date(),
            reminderDate: new Date(),
            users: {},
            isMilestone: false,
            pccomplete: 0
        }
        //javascript model class for bid_news object
        var newsObj = {
            Id: 0,
            BidId: 0,
            News: "",
            UserId: "",
            News_dateTime: null,
            Add: false,
            Edit: false,
            Delete: false
        }
        //javascript model class for bid_Document object
        var documentObj = {
            Id: 0,
            BidId: 0,
            Document: "",
            UserId: "",
            Document_dateTime: null,
            Link: "",
            Add: false,
            Edit: false,
            Delete: false
        }


        //// PERMISSION SETTINGS

        //for holding permissions
        $scope.permissions = {
            addnew: true,
            editold: true,
            delete: true
        }

        //for bid permissions
        $scope.bids = {
            addnew: $scope.showLink('BidTracker.ButtonNew'),      //NIU now            //for switching to CREATE page
            editold: $scope.showLink('BidTracker.EditRight'),
            delete: $scope.showLink('BidTracker.DeleteRight'),
            showmyrecordsonly: true,
            adding: false,
            addcomment: false,
            addaction: false,
            addnews: false,
            addactionitem: false
        };

        //for bid_comment permissions
        $scope.comments = {
            addnew: $scope.showLink('BidTracker.Comments.ButtonNew'),
            editold: $scope.showLink('BidTracker.Comments.EditRight'),
            deleteold: $scope.showLink('BidTracker.Comments.DeleteRight'),
            isadding: false,
            isediting: false,
            currentIndex: 0
        }

        //for bid_action permissions
        $scope.actions = {
            addnew: $scope.showLink('BidTracker.Actions.ButtonNew'),
            editold: $scope.showLink('BidTracker.Actions.EditRight'),
            deleteold: $scope.showLink('BidTracker.Actions.DeleteRight'),
            isadding: false,
            isediting: false,
            currentIndex: 0,
            currentId: 0
        }

        //for bid_actionitems permissions
        $scope.actionitems = {
            addnew: true,
            editold: true,
            deleteold: true,
            isadding: false,
            isediting: false,
            currentIndex: 0,
            currentId: 0
        }

        //for bid research permissions
        $scope.neWs = {
            addnew: true, //$scope.showLink('BidTracker.News.ButtonNew'),
            editold: true, // $scope.showLink('BidTracker.News.EditRight'),
            deleteold: true, //$scope.showLink('BidTracker.News.DeleteRight'),
            isadding: false,
            isediting: false,
            currentIndex: 0
        }
        // for Library
        //for bid_news permissions
        $scope.library = {
            addnew: true, //$scope.showLink('BidTracker.News.ButtonNew'),
            editold: true, //$scope.showLink('BidTracker.News.EditRight'),
            deleteold: true, //$scope.showLink('BidTracker.News.DeleteRight'),
            isadding: false,
            isediting: false,
            currentIndex: 0
        }
        //for partner permissions
        $scope.Partner = {
            //addnew: $scope.showLink('BidTracker.Library.ButtonNew'),
            //editold: $scope.showLink('BidTracker.Library.EditRight'),
            //deleteold: $scope.showLink('BidTracker.Library.DeleteRight'),
            addnew: true,
            editold: true,
            deleteold: true,
            isadding: false,
            isediting: false,
            currentIndex: 0,
            isUpdateAndLink: false
        }

        //for Library permissions
        var partner = {
            Id: 0,
            Bid_Id: 0,
            PartnerName: "",
            PartnerType: "Vendor",
            ExpirationDate: "",
            Cage: "",
            isPartnerActive: false,
            Duns: "",
            DunsPlus4: "",
            Street: "",
            City: "",
            State: "",
            Country: "",
            Zip: "",
            Phone: "",
            ServiceProviderContact: "",
            ContactPhone: "",
            ContactEmail: "",
            WebSite: "",
            POC: "",
            Email: "",
            HasDelinquentFederalDebt: false,
            HasKnownExclusion: false,
            WorkShare: "",
            PocDetails: [],
            addnew: true,
            editold: true,
            deleteold: true,
            isadding: false,
            isediting: false,
            currentIndex: 0,
            Comments: "",
            CoreCompetencies: ""
        }

        var partnerpoc = {
            Id: 0,
            POC: "",
            Email: "",
            Phone: "",
            Comments: "",
            POCTitle: "",
            MobileNo: ""
        }
        $scope.partnerDetails = partnerpoc;

        // for Core-Competency Selected Object
        $scope.tempObjs = {
            CoreCompetencyObj: []
        };

        // for bid_library permissions
        $scope.objlibrary = {
            addnew: $scope.showLink('BidTracker.library.ButtonNew'),
            editold: $scope.showLink('BidTracker.library.EditRight'),
            deleteold: $scope.showLink('BidTracker.library.DeleteRight'),
            isadding: false,
            isediting: false,
            currentIndex: 0
        }
        //dto instantiation
        var bidModel = {};
        var company = {
            Id: 0,
            ServiceProviderName: "",
            ExpirationDate: "",
            Cage: "",
            IsProviderActive: false,
            Duns: "",
            DunsPlus4: "",
            Street: "",
            City: "",
            State: "",
            Country: "",
            Zip: "",
            HasDelinquentFederalDebt: false,
            HasKnownExclusion: false,
        }
        $scope.companyinfo = company;

        //model array
        $scope.StepsSource = [
            { "percent1": 0 },
            {
                //for info tab
                "step1": [{
                    "active": true, "addMode": true, "percent1": "0", "link": "", "bidType": 13, "awardType": 18, "codeName": "", "rigilStage": "",
                    "releaseDate": "", "isProjected": true, "submittalDate": "", "rigilPrimeSub": "", "bidScore": 0, "Bid_Decision": false,
                    "daysToRelease": "", "bidStatus": "", "bidAwardDate": "", "Id": 0, "departmentName": "", "departmentAgency": "", "agencyOffice": "",
                    "bidTitle": "", "solicitationNumber": "", "solicitationDate": "", "bidAcronym": "", "totalDollarValue": "", "rigilDollarValue": "",
                    "workShare": 0.00, "oppId": "", "status": 64, "competitionType": 0, "summary": "", "idiqId": 0, "businessArea": "", "debriefrequest": "",
                    "debriefreceived": "", "popstart": "", "popend": "", "debriefdescription": "", "submittedDate": "", "submittedTime": "", "workLocation": "",
                    "customerZipCode": "", "customerCity": "", "customerState": "", "cManager": "", "pManager": "", "awardNumber": 0, "rfiSubmittedDate": "",
                    "cManagerName": "", "pManagerName": "", "rfiDueDate": "", "isImported": false,
                    //RR-541
                    "followDate": "", "followAssignedRolesObj": [],
                    //RR-536
                    "KEGId": 0, "ContractId": 0, "ContractPMPhone": "", "ContractPMEmail": "", "ContractPMPhone": "",
                    //RR-545
                    "DocSource": "",
                    //RR-505
                    "isBell": false
                }]
            },
            //not in use
            {
                "step2": [{
                    "active": false, "addMode": true, "percent1": "20", "percent2": "20", "rigilComments": [], "rigilComment": "", "bidID": 0,
                    "showCommentlist": true, "isCommentAdding": false, "isCommentEditing": false, "userID": "", "commentDT": ""
                }]
            },
            //action tab
            {
                "step3": [{
                    "active": false, "addMode": true, "percent1": "20", "percent2": "20", "actionTaken": [], "rigilAction": "",
                    "showActionlist": true, "isActionAdding": false, "isActionEditing": false
                }]
            },
            //Capture tab and action item
            {
                "step4": [{
                    "active": false, "addMode": true, "percent1": "40", "percent2": "40", "actionableItems": [], "actionedItems": [], "actionItem": "",
                    "showActionItemslist": true, "isActionItemAdding": false, "isActionItemEditing": false
                }]
            },
            //Library Tab
            {
                "step5": [{
                    "active": false, "addMode": true, "percent1": "80", "percent2": "60", "latestNews": [], "currentNews": "",
                    "showLatestNewslist": true, "isLatestNewsAdding": false, "isLatestNewsEditing": false
                }]
            },
            //Partners tab
            {
                "step6": [{
                    "active": false, "addMode": true, "percent1": "100", "percent2": "70", "finished": false, "Id": 0, "serviceProviderName": "", "serviceProviderType": "", "serviceProviderTypeId": 0, "expirationDate": "", "cage": "", "isProviderActive": false, "DUNS": "", "DUNSPlus4": "", "street": "", "city": "", "state": "", "country": "", "zip": "", "phone": "", "serviceProviderContact": "", "contactPhone": "", "contactEmail": "", "webSite": "", "poc": "", "POCEmail": "", "isDelinquentFederalDebt": false, "isKnownExclusion": false, "WorkShare": "", "PocDetails": []
                }]
            },
            //Partners tab
            {
                "step7": [{
                    "Id": 0, "serviceProviderName": "", "expirationDate": "", "cage": "", "isProviderActive": false, "DUNS": "", "DUNSPlus4": "", "street": "", "city": "", "state": "", "country": "", "zip": "", "isDelinquentFederalDebt": false, "isKnownExclusion": false
                }]
            },
            //Witing Tab
            {
                "step8": [{
                    "active": false, "percent1": "100", "percent2": "80"
                }]
            },
            //Scheduling Tab
            {
                "step9": [{
                    "active": false, "percent1": "100", "percent2": "90"
                }]
            },
            //Compliance Tab
            {
                "step10": [{
                    "active": false, "percent1": "100", "percent2": "100"
                }]
            },
            //Proposal Planning Tab
             {
                 "step11": [{
                     "active": false, "percent1": "60", "percent2": "50"
                 }]
             },
        ]


        //Bid Info Tab functions
        //---------------------------------------------------------------

        //initializes Model
        $scope.newBid = function () {
            $scope.currentRecordId = 0;
            angular.copy($scope.StepsSource, $scope.Steps);
            $scope.bidinfo.showmessage1 = false;
            $scope.bidinfo.awardtoLoad = false;
            $scope.submissionPending = true;
            $scope.isBidscorePass = false;
            $scope.bidNote = "";
            $scope.score_notes = [];
            $scope.codeErrorMessage = "";
            $scope.commentsIndex = [];
            $scope.actionsIndex = [];
            $scope.actionitemsIndex = [];
            $scope.newsIndex = [];
            $scope.documentIndex = [];
            $scope.partnerIndex = [];
            $scope.bidTypeOnchange($scope.Steps[1].step1[0].bidType, $scope.Steps[1].step1[0].Id);
        };

        $scope.toggleShowView = function () {
            $scope.showView = !$scope.showView;
        }

        $scope.toggleBackToList = function () {
            $scope.showList = true;
            $scope.showEntry = false;
            $scope.showView = false;
        };

        $scope.toggleShowList = function () {
            $scope.showList = !$scope.showList;
            if (!$scope.showList) { $scope.newBid(); $scope.showEntry = true; $scope.bids.adding = true; }
        };

        $scope.toggleShowEntry = function () {
            //callGridData();
            $scope.showEntry = !$scope.showEntry;
            if (!$scope.showEntry) { $scope.showList = true; $scope.showView = false; } else { $scope.showList = false; $scope.showView = false; }
        };
        $scope.rebindGridEntry = function () {
            callGridData();
            $scope.toggleShowEntry();
        };
        $scope.toggleBack = function () {
            $scope.showList = false;
            $scope.showEntry = true;
        };

        $scope.cancelEntry = function () {
            $scope.showEntry = false; $scope.bids.adding = false; $scope.showList = true;
        }



        function updateGridDataGlobally() {
            var result = emptyCheckedArray();
            if (result) {
                if ($scope.app.bidmodule == "")//in case we refresh the page or we are redirecting
                {
                    $scope.app.globalStatusFilter = sessionStorage.getItem("app.globalStatusFilter");
                    $scope.app.bidmodule = sessionStorage.getItem("app.bidmodule");
                    $scope.app.globalDevFilter = sessionStorage.getItem("app.globalDevFilter");
                }
                $scope.bidsIndex = [];
                if ($scope.app.bidmodule == "Tracker") {
                    if ($scope.app.globalStatusFilter != 0) {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if (value.Bid_statusId == $scope.app.globalStatusFilter) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                    else {
                        $scope.bidsIndex = $scope.orgBidsArray;
                    }
                }
                else if ($scope.app.bidmodule == "Development") {
                    //$scope.app.globalDevFilter == 0 all development bids 
                    //$scope.app.globalDevFilter == 1 all RFP/Quote Development bids
                    //$scope.app.globalDevFilter == 2 all rfi development bids
                    //Bid_statusId  interest---12   pursuit----29  bid---42
                    //proposal_stage  development---2 rfi development----11  planning--26
                    if ($scope.app.globalDevFilter == 0) {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if ((value.Rigil_Stage == 2 || value.Rigil_Stage == 26) && (value.Bid_statusId == 12 || value.Bid_statusId == 29 || value.Bid_statusId == 42)) {
                                $scope.bidsIndex.push(value);
                            }
                            else if (value.Rigil_Stage == 11 && value.Bid_statusId == 12) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                    else if ($scope.app.globalDevFilter == 1)//RFP/Quote Development
                    {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if ((value.Rigil_Stage == 2 || value.Rigil_Stage == 26) && (value.Bid_statusId == 12 || value.Bid_statusId == 29 || value.Bid_statusId == 42)) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                    else if ($scope.app.globalDevFilter == 2)//RFI Development
                    {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if (value.Rigil_Stage == 11 && value.Bid_statusId == 12) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                    else if ($scope.app.globalDevFilter == 3)//RFP/Quote Development----Development
                    {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if (value.Rigil_Stage == 2 && (value.Bid_statusId == 12 || value.Bid_statusId == 29 || value.Bid_statusId == 42)) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                    else if ($scope.app.globalDevFilter == 4) //RFP/Quote Development----Planning
                    {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if (value.Rigil_Stage == 26 && (value.Bid_statusId == 12 || value.Bid_statusId == 29 || value.Bid_statusId == 42)) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                }
                else {
                    if ($scope.app.globalStatusFilter != 0) {
                        angular.forEach($scope.orgBidsArray, function (value, index) {
                            if (value.Bid_statusId == $scope.app.globalStatusFilter) {
                                $scope.bidsIndex.push(value);
                            }
                        })
                    }
                    else {
                        $scope.bidsIndex = $scope.orgBidsArray;
                    }
                }

            }



        }
        // watch on globalStatusFilter for grid data rebind
        $scope.$watch('app.globalStatusFilter', function () {
            updateGridDataGlobally();
            $scope.gridOptions.data = $scope.bidsIndex;
        }, true);

        // watch on globalStatusFilter for grid data rebind
        $scope.$watch('app.globalDevFilter', function () {
            updateGridDataGlobally();
            $scope.gridOptions.data = $scope.bidsIndex;
        }, true);

        // watch on globalStatusFilter for grid data rebind
        $scope.$watch('app.bidmodule', function () {
            updateGridDataGlobally();
            $scope.gridOptions.data = $scope.bidsIndex;
        }, true);

        $scope.isDevelopment = function (stageId, statusId) {
            if ((stageId == 2 || stageId == 26) && (statusId == 12 || statusId == 29 || statusId == 42)) {
                return true;
            }
            else if (stageId == 11 && statusId == 12) {
                return true;
            }
            else {
                return false;
            }
        }
        function callGridData() {
            $http.get('/api/Bids/').success(function (data) {
                if (data) {
                    $scope.orgBidsArray = data;
                    angular.forEach($scope.orgBidsArray, function (value, index) {
                        value['RelDays'] = $scope.daysToGo(value.Projected_releaseDate);
                        value['BiddingStage'] = $scope.bidStageText(value.Rigil_Stage);
                        value['BiddingStatus'] = $scope.bidStatusText(value.Bid_statusId);
                        value['CompetitionType'] = $scope.bidCompetitionTypeText(value.Bid_competitionTypeId);
                        value['BiddingType'] = $scope.bidTypeToText(value.Bid_typeId);
                        value['PrimeSubType'] = $scope.PrimeSubTypeToText(value.Prime_Sub);
                        value['RigilStageType'] = $scope.RigilStageToText(value.Rigil_Stage);
                        value['BiddingAwardType'] = $scope.bidAwardTypeToText(value.Award_typeId);
                        value['allIDIQlist'] = $scope.allIDIQContracts;
                        value['TotalValue_short'] = value.Total_dollarValue / 1000000;
                        if (value.AgencyKey) {
                            value['AgencyName'] = value.AgencyKey.Agencyname;
                        } else {
                            value['AgencyName'] = "";
                        }
                        if (value.AgencyKey) {
                            value['AgencyAcronym'] = value.AgencyKey.Acronym;
                        } else {
                            value['AgencyAcronym'] = "";
                        }
                        value.Ratings = JSON.parse(value.Ratings);


                    });
                    $scope.bidsIndex = [];
                    angular.copy($scope.orgBidsArray, $scope.bidsIndex);
                    //set new opportunities scope
                    $scope.toggleNewOpportunities();

                    $scope.bidCount = $scope.bidsIndex.length;

                    // for nav tab bid status filter
                    updateGridDataGlobally();
                    $scope.gridOptions.data = $scope.bidsIndex;
                    $scope.loadingImage = false;
                }
            });
        }




        function timeConverter(UNIX_timestamp) {
            var a = new Date(UNIX_timestamp * 1000);
            // var a = new Date(UNIX_timestamp);
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var year = a.getFullYear();
            var month = months[a.getMonth()];
            var date = a.getDate();
            var hour = a.getHours().toString().length == 1 ? +'0' + a.getHours().toString() : a.getHours().toString();
            var min = a.getMinutes().toString().length == 1 ? +'0' + a.getMinutes().toString() : a.getMinutes().toString();
            var sec = a.getSeconds().toString().length == 1 ? '0' + a.getSeconds().toString() : a.getSeconds().toString();
            //var time = moment(UNIX_timestamp).format('YYYY-MM-DD') + 'T' + hour + ':' + min + ':' + sec + '+' + '05:30';
            var time = moment(UNIX_timestamp).format('YYYY-MM-DD') + 'T' + hour + ':' + min + ':' + sec + '-' + '05:00';
            return time;
        }

        $scope.bidTypeDropDownData = [];
        $scope.awardTypeDrpDwnData = [];
        $scope.proposalstageDropDownData = [];
        $scope.primeSubDropDownData = [];
        $scope.bidDropDownData = [];
        $scope.competitionDropDownData = [];

        function arrangedBidType() {
            if ($scope.bidtypeDrpDwn && $scope.bidtypeDrpDwn.length > 0) {
                _.each($scope.bidtypeDrpDwn, function (data) {
                    var obj = {};
                    obj.value = data.Constant.trim();
                    obj.label = data.Constant.trim();
                    $scope.bidTypeDropDownData.push(obj);
                });
            }
        }

        function awardBidType() {
            if ($scope.awardtypeDrpDwn && $scope.awardtypeDrpDwn.length > 0) {
                _.each($scope.awardtypeDrpDwn, function (data) {
                    var obj = {};
                    obj.value = data.Constant.trim();
                    obj.label = data.Constant.trim();
                    $scope.awardTypeDrpDwnData.push(obj);
                });
            }
        }

        function aproposalstageType() {
            if ($scope.proposalstageIds && $scope.proposalstageIds.length > 0) {
                _.each($scope.proposalstageIds, function (data) {
                    var obj = {};
                    obj.value = data.Constant.trim();
                    obj.label = data.Constant.trim();
                    $scope.proposalstageDropDownData.push(obj);
                });
            }
        }

        function primeSubType() {
            if ($scope.primesubDrpDwn && $scope.primesubDrpDwn.length > 0) {
                _.each($scope.primesubDrpDwn, function (data) {
                    var obj = {};
                    obj.value = data.Constant.trim();
                    obj.label = data.Constant.trim();
                    $scope.primeSubDropDownData.push(obj);
                });
            }
        }

        function bidingStatusType() {
            if ($scope.bidstatusIds && $scope.bidstatusIds.length > 0) {
                _.each($scope.bidstatusIds, function (data) {
                    var obj = {};
                    obj.value = data.Constant.trim();
                    obj.label = data.Constant.trim();
                    $scope.bidDropDownData.push(obj);
                });
            }
        }

        function compotiontionType() {
            if ($scope.competetypeDrpDwn && $scope.competetypeDrpDwn.length > 0) {
                _.each($scope.competetypeDrpDwn, function (data) {
                    var obj = {};
                    if (data.Constant != null) {
                        obj.value = data.Constant.trim();
                        obj.label = data.Constant.trim();
                        $scope.competitionDropDownData.push(obj);
                    }

                });
            }
        }

        $scope.redirectlogic = function (id) {

        }

        //Return BidStage
        $scope.bidStageText = function (id) {
            var obj = _.find($scope.rigilstatusDrpdwn, function (obj) { return obj.Id == id });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.rigilstatusDrpdwn, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }


        //Return BidStatus
        $scope.bidStatusText = function (id) {
            var obj = _.find($scope.bidstatusDrpDwn, function (obj) { return obj.Id == id });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.bidstatusDrpDwn, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }

        //Return Competition Type
        $scope.bidCompetitionTypeText = function (id) {
            var obj = _.find($scope.competetypeDrpDwn, function (obj) {
                return obj.Id == id
            });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.competetypeDrpDwn, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }

        //Return Bidding Type
        $scope.bidTypeToText = function (id) {
            var obj = _.find($scope.bidtypeDrpDwn, function (obj) { return obj.Id == id });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.bidtypeDrpDwn, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }
        $scope.PrimeSubTypeToText = function (id) {
            var obj = _.find($scope.primesubDrpDwn, function (obj) { return obj.Id == id });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.primesubDrpDwn, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }
        $scope.RigilStageToText = function (id) {
            var obj = _.find($scope.proposalstageIds, function (obj) { return obj.Id == id });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.proposalstageIds, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }
        //Return Bid Award Type
        $scope.bidAwardTypeToText = function (id) {
            var obj = _.find($scope.awardtypeDrpDwn, function (obj) { return obj.Id == id });
            if (obj == null || obj == undefined)
                return 'None';
            else
                return obj.Constant;
            //var fullname = "";
            //angular.forEach($scope.awardtypeDrpDwn, function (value, index) {
            //    if (value.Id == id) { fullname = value.Constant; }
            //})
            //if (fullname == "") { fullname = 'None'; }
            //return fullname;
        }

        $scope.validateDepartment = function () {
            for (var i = 0; i < $scope.departments.length; i++) {
                if ($scope.departments[i].Agencyname == $scope.Steps[1].step1[0].departmentName)
                    return true;
            }
        }

        $scope.validateAgency = function () {
            for (var i = 0; i < $scope.deptAgencies.length; i++) {
                if ($scope.deptAgencies[i].Agencyname == $scope.Steps[1].step1[0].departmentAgency)
                    return true;
            }
        }

        $http.get("/api/GeneralConfigs/6").success(function (data) {
            if (data) {
                $scope.savedState = data;
                $scope.state = JSON.parse(data.Value);
                $timeout(function () {
                    $scope.gridApi.saveState.restore($scope, $scope.state);
                    $scope.gridOptions.columnDefs[0].visible = true;
                }, 1000);

            }
        });

        //ui-grid filter conditions

        //1.  STARTS_WITH
        //2.  ENDS_WITH
        //3.  CONTAINS 
        //4.  EXACT
        //5.  NOT_EQUAL
        //6.  GREATER_THAN
        //7.  GREATER_THAN_OR_EQUAL
        //8.  LESS_THAN
        //9.  LESS_THAN_OR_EQUAL
        var bellIcon = '<span style="color:green" ng-if="!grid.appScope.ctrlVar.isArchived">' +
                       '<i ng-if="row.entity.isBell" id="{{row.entity.Id}}" ng-click="grid.appScope.openBellFunction(row,col,false)" class="fa fa-bell" aria-hidden="true" style="padding-left:5px;"></i>' +
                       '<i ng-if="!row.entity.isBell" id="{{row.entity.Id}}" ng-click="grid.appScope.openBellFunction(row,col,true)" class="fa fa-bell-o" aria-hidden="true" style="padding-left:5px;"></i>' +
                   '</span>';
        //var headerBellIcon = '<span style="color:green"><i id="headerBellId" ng-if="grid.appScope.headerBellFlag" ng-click="grid.appScope.headerBellFunction(row,col,false)" class="fa fa-bell" aria-hidden="true" style="padding-left:5px;padding-top:12px;"></i><i id="headerBellId" ng-if="!grid.appScope.headerBellFlag" ng-click="grid.appScope.headerBellFunction(row,col,true)" class="fa fa-bell-o" aria-hidden="true" style="padding-left:5px;padding-top:12px;"></i></span>';
        var headerBellIcon = '<span style="color:green"  ng-if="!grid.appScope.ctrlVar.isArchived">' +
                       '<i ng-if="grid.appScope.headerBellFlag" id="headerBellId" ng-click="grid.appScope.openBatchBellFunction(false)" class="fa fa-bell" aria-hidden="true" style="padding-left:5px;padding-top:12px;"></i>' +
                       '<i ng-if="!grid.appScope.headerBellFlag" id="headerBellId" ng-click="grid.appScope.openBatchBellFunction(true)" class="fa fa-bell-o" aria-hidden="true" style="padding-left:5px;padding-top:12px;"></i>' +
                   '</span>';;
        //RR-520
        var actionCellTemplate = '<div><span style="padding-left:10px" ng-if="grid.appScope.showLink(\'BidTracker.EditRight\') && !grid.appScope.ctrlVar.isArchived">' +
                            '<a ng-click="grid.appScope.counter=0;grid.appScope.isEditing=true;grid.appScope.selectedBid($index,\'E\',row.entity.Id);grid.appScope.toggleShowEntry();grid.appScope.printSearchData();">' +
                            '<i ng-if="!grid.appScope.isDevelopment(row.entity.Rigil_Stage,row.entity.Bid_statusId)" class="fa fa-pencil-square-o" style="color:green;cursor:pointer" title="Edit"></i>' +
                             '<i ng-if="grid.appScope.isDevelopment(row.entity.Rigil_Stage,row.entity.Bid_statusId)" class="fa fa-pencil-square-o" style="color:coral;cursor:pointer;font-weight: bolder;font-size: 16px;" title="Edit"></i></a></span>' +
                            '<span >' +
                            '<span style="padding-left:15px;cursor:pointer;color:green;" ng-if="grid.appScope.showLink(\'BidTracker.DeleteRight\') && !grid.appScope.ctrlVar.isArchived""  class="fa fa-trash"   ng-click ="grid.appScope.selectedBid($index,\'D\',row.entity.Id)" title="Delete Bid"></span>' +
                            '<span style="padding-left:20px;color:green;cursor:pointer" ng-if="grid.appScope.showLink(\'BidTracker.RestoreRight\') && grid.appScope.ctrlVar.isArchived" class="fa fa-undo"  ng-click="grid.appScope.selectedBid($index,\'R\',row.entity.Id)" title="Restore"></span></div>';
        // add new column after Restore column as we are using column index to set the visibility ********
        $scope.myDefs = [
                       { name: 'isBell', minWidth: 30, cellTemplate: bellIcon, headerCellTemplate: headerBellIcon, enableFiltering: false, enableGrouping: false, enableSorting: false, enablePinning: true, enableHiding: false },

                        { field: 'OpportunityId', displayName: 'Opp.Id', enableGrouping: false, minWidth: 100 },

                        { field: 'Code_Name', displayName: 'Code Name', enableGrouping: false, visible: false, minWidth: 100 },

                        { field: 'Solicitation_Num', displayName: 'Solicitation Number', enableGrouping: false, minWidth: 100, },

                        {
                            field: 'BiddingType', displayName: 'Bid Type', groupingShowAggregationMenu: false, minWidth: 100,
                            filter: { noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.bidTypeDropDownData },
                        },

                        {
                            field: 'BiddingAwardType', displayName: 'Award Type', groupingShowAggregationMenu: false, visible: false, minWidth: 100,
                            filter: { noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.awardTypeDrpDwnData },
                        },

                        {
                            field: 'Status', displayName: 'Naics Codes', enableGrouping: false, visible: false, minWidth: 100,
                        },

                        { field: 'Title', displayName: 'Title', enableGrouping: false, minWidth: 300 },
                        {
                            field: 'PrimeSubType', displayName: 'Prime/ Sub', groupingShowAggregationMenu: false, minWidth: 100,
                            filter: { noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.primeSubDropDownData },
                        },

                        { field: 'AgencyAcronym', displayName: 'Agency', cellTemplate: 'agencyTemplate.html', groupingShowAggregationMenu: false, minWidth: 100, },

                        {
                            field: 'Projected_releaseDate', displayName: 'Release Date', cellTemplate: 'orgreleasedateTemplate.html', cellFilter: 'date:"mediumDate"', enableGrouping: false, minWidth: 100,
                            filters: [{ condition: checkStartRelease }, { condition: checkEndRelease }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" release-first-date="active" release-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" release-first-date="deactive" release-last-date="active" ng-model="col.filters[1].term" placeholder="To" ng-class="{textColor:grid.appScope.endDateTextReleaseFlag}"/></div>'
                        },

                        {
                            field: 'RelDays', displayName: 'Days to Release', minWidth: 100, enableGrouping: false,
                            filters: [{ condition: uiGridConstants.filter.GREATER_THAN, placeholder: 'From' },
                                { condition: uiGridConstants.filter.LESS_THAN, placeholder: 'To' }
                            ],
                            sort: { direction: uiGridConstants.ASC, priority: 0 },
                            sortingAlgorithm: function (a, b, rowA, rowB, direction) {
                                //Note: Think of b as 0 position. Now how 'a' will be placed in array. If a>b, then return '1' means below b. 
                                //      If a<b, return '-1' means place a before b. Return '0' means, take no action, leave the positions of a nad b as is.
                                if (a > b) {
                                    return 1;
                                }
                                if (a < b) {
                                    return -1;
                                }
                                if (a == b) {
                                    return 0;
                                }
                            }
                        },
                        //RR-515 added new field 
                        {
                            field: 'Solicitation_Date', displayName: 'Solicitation Date', cellTemplate: 'solicitationdateTemplate.html', cellFilter: 'date:"mediumDate', enableGrouping: false, minWidth: 150,
                            filters: [{ condition: checkStartSoldate }, { condition: checkEndSoldate }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" sol-first-date="active" sol-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" sol-first-date="deactive" sol-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextSolFlag}"/></div>'
                        },
                        {
                            field: 'RFIDueDate', displayName: 'RFI Due Date', cellTemplate: 'RFIDueDateTemplate.html', cellFilter: 'date:"mediumDate', enableGrouping: false, minWidth: 150,
                            filters: [{ condition: checkStartRFIDueDate }, { condition: checkEndRFIDueDate }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" rfidue-first-date="active" rfidue-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" rfidue-first-date="deactive" rfidue-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextRFIDueFlag}"/></div>'
                        },
                        {
                            field: 'RFISubmittedDate', displayName: 'RFI Submitted Date', cellTemplate: 'RFISubmittedDateTemplate.html', cellFilter: 'date:"mediumDate', enableGrouping: false, minWidth: 170,
                            filters: [{ condition: checkStartRFISubmittedDate }, { condition: checkEndRFISubmittedDate }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" rfisubmitted-first-date="active" rfisubmitted-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" rfisubmitted-first-date="deactive" rfisubmitted-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextRFISubmittedFlag}"/></div>'
                        },

                        {
                            field: 'Proposal_submittalDate', displayName: 'Proposal Due Date', cellTemplate: 'submittaldateTemplate.html', cellFilter: 'date:"M/d/yyyy', enableGrouping: false, minWidth: 200,
                            filters: [{ condition: checkStartProposal }, { condition: checkEndProposal }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" proposed-first-date="active" proposed-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" proposed-first-date="deactive" proposed-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextProposalFlag}"/></div>'
                        },

                         {
                             field: 'Proposal_submittedDate', displayName: 'Proposal submitted Date', cellTemplate: 'submitteddateTemplate.html', cellFilter: 'date:"MM/dd/yyyy h:mm:ss a"', enableGrouping: false, minWidth: 200,
                             filters: [{ condition: checkStartSubmitted }, { condition: checkEndSubmitted }],
                             filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" submitted-first-date="active" submitted-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" submitted-first-date="deactive" submitted-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextProposedFlag}"/></div>'
                         },

                        {
                            field: 'Bid_Score', displayName: 'Bid/ NoBid Score', cellTemplate: 'bidscoreTemplate.html', enableGrouping: false, minWidth: 150,
                            filters: [{ condition: uiGridConstants.filter.GREATER_THAN_OR_EQUAL, placeholder: 'From' },
                                { condition: uiGridConstants.filter.LESS_THAN_OR_EQUAL, placeholder: 'To' }
                            ],
                            sort: { direction: uiGridConstants.ASC, priority: 0 },
                            sortingAlgorithm: function (a, b, rowA, rowB, direction) {
                                //Note: Think of b as 0 position. Now how 'a' will be placed in array. If a>b, then return '1' means below b. 
                                //      If a<b, return '-1' means place a before b. Return '0' means, take no action, leave the positions of a nad b as is.
                                if (a > b) {
                                    return 1;
                                }
                                if (a < b) {
                                    return -1;
                                }
                                if (a == b) {
                                    return 0;
                                }
                            }
                        },

                        {
                            field: 'RigilStageType', displayName: 'Proposal Stage', groupingShowAggregationMenu: false, visible: false, width: 200,
                            filter: {
                                condition: function (searchTerm, cellValue) {
                                    return cellValue === searchTerm;
                                }, type: uiGridConstants.filter.SELECT, selectOptions: $scope.proposalstageDropDownData
                            },
                        },

                        {
                            field: 'BiddingStatus', displayName: 'Bid Status', groupingShowAggregationMenu: false, visible: true, width: 200,
                            filter: {
                                condition: function (searchTerm, cellValue) {
                                    return cellValue === searchTerm;
                                }, type: uiGridConstants.filter.SELECT, selectOptions: $scope.bidDropDownData
                            },
                        },

                        {
                            field: 'CompetitionType', displayName: 'Comp. Type', groupingShowAggregationMenu: true, visible: false, minWidth: 200,
                            filter: { noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.competitionDropDownData },
                        },

                        {
                            field: 'TotalValue_short', displayName: 'Total Value ($) in millions', cellFilter: 'currency', visible: true, minWidth: 130, cellClass: 'salary-align-right',
                            filters: [{ condition: uiGridConstants.filter.GREATER_THAN, placeholder: 'From' },
                                { condition: uiGridConstants.filter.LESS_THAN, placeholder: 'To' }]
                        },
                        {
                            field: 'BusinessArea', displayName: 'Business Area', visible: true, minWidth: 100,
                            filter: {
                                noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: [{ value: "Strategy", label: "Strategy" }, { value: "Technology", label: "Technology" }, { value: "Products", label: "Products" }, { value: "Products12", label: "Products12" }],
                            }
                        },
                        {
                            field: 'IDIQID', displayName: 'IDIQ', cellTemplate: 'idiqTemplate.html', visible: false, minWidth: 100,

                        },
                        {
                            field: 'allIDIQlist', displayName: 'IDIQLIst', cellTemplate: 'idiqTemplate.html', visible: false, enableHiding: false, minWidth: 100,
                        },
                        {
                            field: 'Rating', displayName: 'Priority', cellTemplate: 'RatingTemplate.html', enableGrouping: false, minWidth: 175,
                        },
                        // ********   RR-540   START **************************************//
                        {
                            field: 'AddedBy', displayName: 'Created By', enableGrouping: false, minWidth: 175,
                        },
                        {
                            field: 'UpdatedBy', displayName: 'Updated By', enableGrouping: false, minWidth: 175,
                        },
                        {
                            field: 'CreatedDate', displayName: 'Created Date', cellTemplate: 'createdDateTemplate.html', cellFilter: 'date:"M/d/yyyy', enableGrouping: false, minWidth: 175,
                            filters: [{ condition: checkStartCreated }, { condition: checkEndCreated }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" created-first-date="active" created-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" created-first-date="deactive" created-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextCreatedFlag}"/></div>'
                        },
                        {
                            field: 'UpdateDate', displayName: 'Updated Date', cellTemplate: 'updatedDateTemplate.html', cellFilter: 'date:"M/d/yyyy', enableGrouping: false, minWidth: 175,
                            filters: [{ condition: checkStartUpdated }, { condition: checkEndUpdated }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" updated-first-date="active" updated-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" updated-first-date="deactive" updated-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextUpdatedFlag}"/></div>'
                        },
                        // ********   RR-540   START **************************************//

                        // ********   RR-541   START **************************************//
                        {
                            field: 'FollowDate', displayName: 'Follow Date', cellTemplate: 'followDateTemplate.html', cellFilter: 'date:"M/d/yyyy', enableGrouping: false, minWidth: 175,
                            filters: [{
                                condition: checkStartFollow
                            }, {
                                condition: checkEndFollow
                            }],
                            filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" date-picker type="text" follow-first-date="active" follow-last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" date-picker type="text" follow-first-date="deactive" follow-last-date="active" ng-model="col.filters[1].term" placeholder="To"  ng-class="{textColor:grid.appScope.endDateTextFollowFlag}"/></div>'
                        },
                        // ********   RR-541  END **************************************//
                        // ********   RR-545   START **************************************//
                        {
                            field: 'DocSource', displayName: 'Source', enableGrouping: false, minWidth: 175,
                        },
                        // ********   RR-545   END **************************************//

                        { field: 'Action', displayName: 'Action', cellTemplate: actionCellTemplate, enableFiltering: false, enableGrouping: false, enableSorting: false, enablePinning: true, enableHiding: false, minWidth: 30, }
        ];

        $scope.gridOptions = {};

        $scope.gridOptions.columnDefs = $scope.myDefs;
        $scope.gridOptions.enableSelectAll = false;
        $scope.gridOptions.enableSelectionBatchEvent = false;
        $scope.gridOptions.multiSelect = false;
        $scope.gridOptions.noUnselect = false;
        $scope.gridOptions.enableRowHeaderSelection = false;
        $scope.gridOptions.enableSorting = true;
        $scope.gridOptions.enableFiltering = false;
        $scope.gridOptions.enableHorizontalScrollbar = 1;
        $scope.gridOptions.enableVerticalScrollbar = 1;
        $scope.gridOptions.enablePaginationControls = true;
        $scope.gridOptions.paginationPageSizes = [5, 10, 25];
        $scope.gridOptions.paginationPageSize = 10;
        $scope.gridOptions.showGridFooter = false;
        $scope.gridOptions.showColumnFooter = false;
        $scope.gridOptions.enableGridMenu = true;
        $scope.gridOptions.exporterMenuPdf = false;
        $scope.gridOptions.exporterMenuAllData = $scope.showLink('Bid.GridExport');
        $scope.gridOptions.exporterMenuVisibleData = $scope.showLink('Bid.GridExport');


        $scope.gridOptions.rowTemplate = rowTemplate()
        $scope.gridOptions.onRegisterApi = function (gridApi) {
            //set gridApi on scope
            $scope.gridApi = gridApi;
            $scope.gridApi.core.handleWindowResize();
            $scope.gridApi.grid.registerRowsProcessor($scope.singleFilter, 200);
        };

        function setPrintData() {
            var columnArray = [];
            $scope.rowData = [];
            _.each($scope.myDefs, function (obj) {
                if (obj.visible) {
                    columnArray.push(obj.name);
                }
            });
            _.each($scope.renderedRows, function (objRow) {
                if (objRow.entity) {
                    var rowObject = {};
                    var pair = [];
                    var objectPairs = [];
                    objectPairs = _.pairs(objRow.entity);
                    _.each(objectPairs, function (objPair) {
                        var colContian = _.contains(columnArray, objPair[0]);
                        if (colContian) {
                            var createObj = {};
                            if ((objPair[0] == 'Projected_releaseDate') || (objPair[0] == 'Proposal_submittalDate') || (objPair[0] == 'Proposal_submittedDate')) {
                                createObj.colName = objPair[0];
                                createObj.colValue = new Date(objPair[1]).getFullYear() <= 1900 ? objPair[1] : '';
                            } else {
                                createObj.colName = objPair[0];
                                createObj.colValue = objPair[1];
                            }
                            pair.push(createObj);
                        }
                    });
                    rowObject.title = objRow.entity.Title;
                    rowObject.rowCollection = pair;
                    $scope.rowData.push(rowObject);
                }
            });
        }

        function rowTemplate() {
            return '<div ng-class="{font_bold:row.entity.isRead==true,font_colorBlue:row.entity.isUpdated==true }"><div ng-dblclick="grid.appScope.rowDblClick(row)" >' +
                         '  <div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div>' +
                         '</div></div>';
        }

        $scope.rowDblClick = function (row) {
            setPrintableAdvData();
            $scope.selectedBid(row.entity.Id, 'V', row.entity.Id);
        };

        $interval(function () {
            $scope.gridApi.core.handleWindowResize();
        }, 1000);

        $scope.resize = function () {
            $scope.gridApi.core.handleWindowResize();
        }

        $scope.filter = function () {
            $scope.gridApi.grid.refresh();
        };

        $scope.singleFilter = function (renderableRows) {
            var findval = $scope.filterValue.toLowerCase();
            var searchedval = "";
            var matcher = new RegExp(findval);
            renderableRows.forEach(function (row) {
                var match = false;
                ['OpportunityId', 'Code_Name', 'Solicitation_Num', 'Status', 'Title', 'AgencyAcronym', 'Summary', 'BiddingType', 'BiddingAwardType', 'CompetitionType', 'BiddingStatus', 'BiddingStage'].forEach(function (field) {
                    if (row.entity[field] != null) {
                        searchedval = row.entity[field].toLowerCase();
                        if (searchedval.match(matcher)) {
                            match = true;
                        }
                    }

                });
                if (!match) {
                    row.visible = false;
                }
            });
            return renderableRows;
        };

        $scope.saveState = function () {
            $scope.state = $scope.gridApi.saveState.save();
            angular.forEach($scope.state.columns, function (value, index) {
                if (value.filters.length > 0 && value.filters[0].selectOptions != undefined) {
                    value.filters[0].selectOptions = [];
                }
            })
            $scope.savedState.Value = JSON.stringify($scope.state);
            $http.put('/api/GeneralConfigs/6', $scope.savedState).success(function (data) {
                toaster.pop('success', 'Success', "Grid Setting Saved");
            }).error(function (data) {
                $scope.error = "an error has occurred while updating state! ";
            });
        };



        $scope.toggleNewOpportunities = function () {
            if ($scope.isNewOpp) {
                //keep a backup of existing array
                $scope.totalarrabckup = [];
                angular.copy($scope.bidsIndex, $scope.totalarrabckup);
                //create a list of only new opportunity
                $scope.newopp = [];
                angular.forEach($scope.bidsIndex, function (value, index) {
                    if (value.isImported && value.isRead) {
                        $scope.newopp.push(value);
                    }
                })
                //make the filtered list Active now
                angular.copy($scope.newopp, $scope.bidsIndex);
            }
            if (!$scope.isNewOpp) {
                //restore old state
                angular.copy($scope.totalarrabckup, $scope.bidsIndex);
            }
        }

        $scope.restoreState = function () {
            $scope.gridApi.saveState.restore($scope, $scope.state);
        };

        $scope.defaultState = function () {
            $http.get('/api/GeneralConfigs/7').success(function (data) {
                $scope.savedState = data;
                if (data.Value != null) {
                    //if previous saved state exists
                    $scope.state = JSON.parse(data.Value);
                    $scope.gridApi.saveState.restore($scope, $scope.state);
                }
            })
        };

        $scope.toggleFiltering = function () {
            $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
            $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        };



        function checkStartRelease(term, value, row, column) {
            $scope.endDateTextReleaseFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateRelease = moment(term);
            if ($scope.endDateRelease) {
                var duration = $scope.endDateRelease.diff($scope.startDateRelease, 'days');
                if (duration < 0)
                    $scope.endDateTextReleaseFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        function checkEndRelease(term, value, row, column) {
            $scope.endDateTextReleaseFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateRelease = moment(term);
            var duration = $scope.endDateRelease.diff($scope.startDateRelease, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextReleaseFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }
        //RR-515 checking start date validation
        function checkStartSoldate(term, value, row, column) {
            $scope.endDateTextSolFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateSolicitation = moment(term);
            if ($scope.endDateSolicitation) {
                var duration = $scope.endDateSolicitation.diff($scope.startDateSolicitation, 'days');
                if (duration < 0)
                    $scope.endDateTextSolFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        //RR-515 checking end date validation
        function checkEndSoldate(term, value, row, column) {
            $scope.endDateTextSolFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateSolicitation = moment(term);
            if ($scope.startDateSolicitation)
                var duration = $scope.endDateSolicitation.diff($scope.startDateSolicitation, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextSolFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }

        //RR-515 checking start date validation
        function checkStartRFIDueDate(term, value, row, column) {
            $scope.endDateTextRFIDueFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateRFIDue = moment(term);
            if ($scope.endDateRFIDue) {
                var duration = $scope.endDateRFIDue.diff($scope.startDateRFIDue, 'days');
                if (duration < 0)
                    $scope.endDateTextRFIDueFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        //RR-515 checking end date validation
        function checkEndRFIDueDate(term, value, row, column) {
            $scope.endDateTextRFIDueFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateRFIDue = moment(term);
            if ($scope.startDateRFIDue)
                var duration = $scope.endDateRFIDue.diff($scope.startDateRFIDue, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextRFIDueFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }

        //RR-515 checking start date validation
        function checkStartRFISubmittedDate(term, value, row, column) {
            $scope.endDateTextRFISubmittedFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateRFISubmitted = moment(term);
            if ($scope.endDateRFISubmitted) {
                var duration = $scope.endDateRFISubmitted.diff($scope.startDateRFISubmitted, 'days');
                if (duration < 0)
                    $scope.endDateTextRFISubmittedFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        //RR-515 checking end date validation
        function checkEndRFISubmittedDate(term, value, row, column) {
            $scope.endDateTextRFISubmittedFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateRFISubmitted = moment(term);
            if ($scope.endDateRFISubmitted)
                var duration = $scope.endDateRFISubmitted.diff($scope.startDateRFISubmitted, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextRFISubmittedFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }

        function checkStartProposal(term, value, row, column) {
            $scope.endDateTextProposalFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateProposal = moment(term);
            if ($scope.endDateProposal) {
                var duration = $scope.endDateProposal.diff($scope.startDateProposal, 'days');
                if (duration < 0)
                    $scope.endDateTextProposalFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        function checkEndProposal(term, value, row, column) {
            $scope.endDateTextProposalFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateProposal = moment(term);
            var duration = $scope.endDateProposal.diff($scope.startDateProposal, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextProposalFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }

        function checkStartSubmitted(term, value, row, column) {
            $scope.endDateTextProposedFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "");
            $scope.startDateProposed = moment(term);
            if ($scope.endDateProposed) {
                var duration = $scope.endDateProposed.diff($scope.startDateProposed, 'days');
                if (duration < 0)
                    $scope.endDateTextProposedFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        function checkEndSubmitted(term, value, row, column) {
            $scope.endDateTextProposedFlag = false;
            term = term.replace(/\\/g, "");
            $scope.endDateProposed = moment(term);
            var duration = $scope.endDateProposed.diff($scope.startDateProposed, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextProposedFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }

        // ********   RR-540   START **************************************//
        function checkStartCreated(term, value, row, column) {
            $scope.endDateTextCreatedFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateCreated = moment(term);
            if ($scope.endDateCreated) {
                var duration = $scope.endDateCreated.diff($scope.startDateCreated, 'days');
                if (duration < 0)
                    $scope.endDateTextCreatedFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        function checkEndCreated(term, value, row, column) {
            $scope.endDateTextCreatedFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateCreated = moment(term);
            var duration = $scope.endDateCreated.diff($scope.startDateCreated, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextCreatedFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }

        function checkStartUpdated(term, value, row, column) {
            $scope.endDateTextUpdatedFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateUpdated = moment(term);
            if ($scope.endDateUpdated) {
                var duration = $scope.endDateUpdated.diff($scope.startDateUpdated, 'days');
                if (duration < 0)
                    $scope.endDateTextUpdatedFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        function checkEndUpdated(term, value, row, column) {
            $scope.endDateTextUpdatedFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateUpdated = moment(term);
            var duration = $scope.endDateUpdated.diff($scope.startDateUpdated, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextUpdatedFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }
        // ********   RR-540   END **************************************//

        // ********   RR-541   Start **************************************//
        function checkStartFollow(term, value, row, column) {
            $scope.endDateTextFollowFlag = false;
            var duration = '';
            term = term.replace(/\\/g, "")
            $scope.startDateFollow = moment(term);
            if ($scope.endDateFollow) {
                var duration = $scope.endDateFollow.diff($scope.startDateFollow, 'days');
                if (duration < 0)
                    $scope.endDateTextFollowFlag = true;
            }
            var now = moment(value);
            if (term) {
                if (moment(term).isAfter(now, 'day')) return false;;
            }
            return true;
        }

        function checkEndFollow(term, value, row, column) {
            $scope.endDateTextFollowFlag = false;
            term = term.replace(/\\/g, "")
            $scope.endDateFollow = moment(term);
            var duration = $scope.endDateFollow.diff($scope.startDateFollow, 'days');
            var now = moment(value);
            if (duration < 0)
                $scope.endDateTextFollowFlag = true;
            if (term) {
                if (moment(term).isBefore(now, 'day')) return false;;
            }
            return true;
        }
        // ********   RR-541   END **************************************//


        $scope.$on('clearDate', function (event, args) {
            if (args) {
                if (args.releaseLastDate && args.releaseLastDate == 'active') {
                    $scope.endDateRelease = '';
                } else if (args.releaseFirstDate && args.releaseFirstDate == 'active') {
                    $scope.startDateRelease = '';
                }
                if (args.proposedLastDate && args.proposedLastDate == 'active') {
                    $scope.endDateProposal = '';
                } else if (args.proposedFirstDate && args.proposedFirstDate == 'active') {
                    $scope.startDateProposal = '';
                }
                if (args.submittedLastDate && args.submittedLastDate == 'active') {
                    $scope.endDateProposed = '';
                } else if (args.submittedFirstDate && args.submittedFirstDate == 'active') {
                    $scope.startDateProposed = '';
                }
                //RR-515
                if (args.solFirstDate && args.solFirstDate == 'active') {
                    $scope.startDateSolicitation = '';
                }
                else if (args.solLastDate && args.solLastDate == 'active') {
                    $scope.endDateSolicitation = '';
                }
                if (args.rfiDueFirstDate && args.rfiDueFirstDate == 'active') {
                    $scope.startDateRFIDue = '';
                }
                else if (args.rfiDueLastDate && args.rfiDueLastDate == 'active') {
                    $scope.endDateRFIDue = '';
                }
                if (args.rfiSubmittedFirstDate && args.rfiSubmittedFirstDate == 'active') {
                    $scope.startDateRFISubmitted = '';
                }
                else if (args.rfiSubmittedLastDate && args.rfiSubmittedLastDate == 'active') {
                    $scope.endDateRFISubmitted = '';
                }
                // ********   RR-540   Start **************************************//
                if (args.createdFirstDate && args.createdFirstDate == 'active') {
                    $scope.startDateCreated = '';
                }
                else if (args.createdLastDate && args.createdLastDate == 'active') {
                    $scope.endDateCreated = '';
                }

                if (args.updatedFirstDate && args.updatedFirstDate == 'active') {
                    $scope.startDateUpdated = '';
                }
                else if (args.updatedLastDate && args.updatedLastDate == 'active') {
                    $scope.endDateUpdated = '';
                }
                // ********   RR-540   END **************************************//
                // ********   RR-541   Start **************************************//
                if (args.followFirstDate && args.followFirstDate == 'active') {
                    $scope.startDateFollow = '';
                }
                else if (args.followLastDate && args.followLastDate == 'active') {
                    $scope.endDateFollow = '';
                }


                // ********   RR-541   END **************************************//
                if ($scope.endDateTextProposalFlag) {
                    $scope.endDateTextProposalFlag = false;
                }

                if ($scope.endDateTextReleaseFlag) {
                    $scope.endDateTextReleaseFlag = false;
                }

                if ($scope.endDateTextProposedFlag) {
                    $scope.endDateTextProposedFlag = false;
                }
                if ($scope.endDateTextSolFlag) {
                    $scope.endDateTextSolFlag = false;
                }
                if ($scope.endDateTextRFIDueFlag) {
                    $scope.endDateTextRFIDueFlag = false;
                }
                if ($scope.endDateTextRFISubmittedFlag) {
                    $scope.endDateTextRFISubmittedFlag = false;
                }
                // ********   RR-540   Start **************************************//

                if ($scope.endDateTextCreatedFlag) {
                    $scope.endDateTextCreatedFlag = false;
                }
                if ($scope.endDateTextUpdatedFlag) {
                    $scope.endDateTextUpdatedFlag = false;
                }
                // ********   RR-540   END **************************************//
                // ********   RR-541   Start **************************************//

                if ($scope.endDateTextFollowFlag) {
                    $scope.endDateTextFollowFlag = false;
                }
                // ********   RR-541   END **************************************//
            }
        });

        function setPrintableAdvData() {
            $scope.printAdvData = [];
            $scope.iconBackFlag = false;
            $scope.iconForwardFlag = false;
            var renderedData = $scope.gridApi.grid.renderContainers.body.renderedRows;
            _.each(renderedData, function (obj) {
                $scope.printAdvData.push(obj.entity);
            });
        }

        $scope.printSearchData = function () {
            setPrintableAdvData();
        }

        $scope.bidBackForward = function (index, type, id, backForword) {
            $scope.iconBackFlag = false;
            $scope.iconForwardFlag = false;
            var bidId = 0;
            var bidIndex = 0;
            var bidLength = $scope.printAdvData.length
            //_.each($scope.bidsIndex, function (obj, key) {
            _.each($scope.printAdvData, function (obj, key) {
                if (backForword == 'back') {
                    if (obj.Id == id && bidIndex != -1) {
                        if (key == 0) {
                            bidId = $scope.printAdvData[key].Id;
                            bidIndex = key;
                            $scope.iconBackFlag = true;
                        } else {
                            bidId = $scope.printAdvData[key - 1].Id;
                            bidIndex = key - 1;
                        }
                    }
                }
                else if (backForword == 'forward') {
                    if (obj.Id == id && bidIndex != bidLength) {
                        if ((key) != (bidLength - 1)) {
                            bidId = $scope.printAdvData[key + 1].Id;
                        }
                        if (key == (bidLength - 1))
                            $scope.iconForwardFlag = true;
                    }
                }
            });
            if (bidId != 0)
                $scope.selectedBid(bidIndex, type, bidId);
        }
        //--------------------------------------------------

        $scope.openBidSelector = function () {

            $scope.showBidFilter = !$scope.showBidFilter;
        }
        $scope.getAPICallInfo = function () {
            $scope.isloading = true;
            var url = 'https://api.data.gov/sam/v1/registrations?qterms=legalBusinessName:' +
                        $('#awardedtoname').val().replace(/[^a-z*0-9\s]/gi, '').replace(/[_\s]/g, '-') +
                        '&api_key=sTb3Twqloh67fVfGyv0T9TUX8bjnTTtI3p6fPFlh';
            $http.get(url).success(function (data) {
                if (data.results.length < 1) {
                    $scope.bidinfo.awardtoLoad = false;
                    toaster.pop('error', 'Error', "No Company Records found for the name entered!");
                    $scope.isloading = false;
                    $scope.Steps[7].step7[0].Id = 0;
                    $scope.Steps[7].step7[0].serviceProviderName = "";
                    $scope.Steps[1].step1[0].AwardedTo = "";
                    $scope.Steps[7].step7[0].DUNS = "";
                    $scope.Steps[7].step7[0].street = "";
                    $scope.Steps[7].step7[0].city = "";
                    $scope.Steps[7].step7[0].state = "";
                    $scope.Steps[7].step7[0].country = "";
                    $scope.Steps[7].step7[0].zip = "";
                    $scope.Steps[7].step7[0].cage = "";
                    $scope.Steps[7].step7[0].DUNSPlus4 = "";
                    $scope.Steps[7].step7[0].expirationDate = "";
                    $scope.Steps[7].step7[0].isDelinquentFederalDebt = false;
                    $scope.Steps[7].step7[0].isKnownExclusion = false;
                    $scope.Steps[7].step7[0].isProviderActive = false;
                    $scope.Steps[7].step7[0].comment = "";
                    $scope.Steps[7].step7[0].coreCompetencies = "";
                    return false;
                }
                else if (data.results.length == 1) {
                    $scope.bidinfo.awardtoLoad = false;
                    $scope.isloading = false;
                    if (data.results[0].status == "Active") {
                        $scope.Steps[7].step7[0].Id = 0;
                        $scope.Steps[7].step7[0].serviceProviderName = data.results[0].legalBusinessName;
                        $scope.Steps[1].step1[0].AwardedTo = data.results[0].legalBusinessName;
                        $scope.Steps[7].step7[0].DUNS = data.results[0].duns;
                        $scope.Steps[7].step7[0].street = data.results[0].samAddress.line1;
                        $scope.Steps[7].step7[0].city = data.results[0].samAddress.city;
                        $scope.Steps[7].step7[0].state = data.results[0].samAddress.stateOrProvince;
                        $scope.Steps[7].step7[0].country = data.results[0].samAddress.country;
                        $scope.Steps[7].step7[0].zip = data.results[0].samAddress.zip;
                        if (data.results[0].samAddress.zip4 != null && data.results[0].samAddress.zip4 != "")
                            $scope.Steps[7].step7[0].zip = data.results[0].samAddress.zip + "-" + data.results[0].samAddress.zip4;
                        else
                            $scope.Steps[7].step7[0].zip = data.results[0].samAddress.zip;

                        $scope.Steps[7].step7[0].cage = data.results[0].cage;
                        $scope.Steps[7].step7[0].DUNSPlus4 = data.results[0].dunsPlus4;
                        if (data.results[0].expirationDate == '' || data.results[0].expirationDate == null) {
                            $scope.Steps[7].step7[0].expirationDate = "01/01/1900";
                        }
                        else {
                            $scope.Steps[7].step7[0].expirationDate = $scope.formatdate(data.results[0].expirationDate);
                        }
                        var delinquent = data.results[0].hasDelinquentFederalDebt;
                        if (delinquent) {
                            $scope.Steps[7].step7[0].isDelinquentFederalDebt = true;
                        }
                        var Exclusion = data.results[0].hasKnownExclusion;
                        if (Exclusion) {
                            $scope.Steps[7].step7[0].isKnownExclusion = true;
                        }
                        if (data.results[0].status == "Active") {
                            $scope.Steps[7].step7[0].isProviderActive = true;
                        }
                        $scope.Steps[7].step7[0].comment = "";
                        $scope.Steps[7].step7[0].coreCompetencies = "";
                    }
                    else {
                        $scope.Steps[1].step1[0].AwardedTo = "";
                        $scope.error = data.results[0].legalBusinessName + "Company is currently inactive";
                        toaster.pop('error', 'Error', $scope.error);
                    }

                }
                else {
                    $scope.bidinfo.awardtoLoad = true;
                    $scope.serviceProviders = data.results;
                    $scope.isloading = false;

                }

            }).error(function (data) {
                $scope.isloading = false;
                $scope.Steps[7].step7[0].Id = 0;
                $scope.Steps[7].step7[0].serviceProviderName = "";
                $scope.Steps[1].step1[0].AwardedTo = "";
                $scope.Steps[7].step7[0].DUNS = "";
                $scope.Steps[7].step7[0].street = "";
                $scope.Steps[7].step7[0].city = "";
                $scope.Steps[7].step7[0].state = "";
                $scope.Steps[7].step7[0].country = "";
                $scope.Steps[7].step7[0].zip = "";
                $scope.Steps[7].step7[0].cage = "";
                $scope.Steps[7].step7[0].DUNSPlus4 = "";
                $scope.Steps[7].step7[0].expirationDate = "";
                $scope.Steps[7].step7[0].isDelinquentFederalDebt = false;
                $scope.Steps[7].step7[0].isKnownExclusion = false;
                $scope.Steps[7].step7[0].isProviderActive = false;
                $scope.Steps[7].step7[0].comment = "";
                $scope.Steps[7].step7[0].coreCompetencies = "";
                toaster.pop('error', 'Error', "Failed to get company data");
            })


        }

        // gets the Data of Service Providers From the Service
        $scope.getAPIDataInfo = function (data) {
            $scope.isloading = true;
            $http.get('https://api.data.gov/sam/v1/registrations?qterms=duns:' +
                      $scope.Steps[1].step1[0].AwardedTo +
                        '&api_key=sTb3Twqloh67fVfGyv0T9TUX8bjnTTtI3p6fPFlh').success(function (data) {
                            if (data.results[0].status == "Active") {
                                $scope.Steps[7].step7[0].serviceProviderName = data.results[0].legalBusinessName;
                                $scope.Steps[1].step1[0].AwardedTo = data.results[0].legalBusinessName;
                                $scope.Steps[7].step7[0].DUNS = data.results[0].duns;

                                $scope.Steps[7].step7[0].street = data.results[0].samAddress.line1;
                                $scope.Steps[7].step7[0].city = data.results[0].samAddress.city;
                                $scope.Steps[7].step7[0].state = data.results[0].samAddress.stateOrProvince;
                                $scope.Steps[7].step7[0].country = data.results[0].samAddress.country;
                                $scope.Steps[7].step7[0].zip = data.results[0].samAddress.zip;
                                if (data.results[0].samAddress.zip4 != null && data.results[0].samAddress.zip4 != "")
                                    $scope.Steps[7].step7[0].zip = data.results[0].samAddress.zip + "-" + data.results[0].samAddress.zip4;
                                else
                                    $scope.Steps[7].step7[0].zip = data.results[0].samAddress.zip;

                                $scope.Steps[7].step7[0].cage = data.results[0].cage;
                                $scope.Steps[7].step7[0].DUNSPlus4 = data.results[0].dunsPlus4;
                                if (data.results[0].expirationDate == '' || data.results[0].expirationDate == null) {
                                    $scope.Steps[7].step7[0].expirationDate = "01/01/1900";
                                }
                                else {
                                    $scope.Steps[7].step7[0].expirationDate = $scope.formatdate(data.results[0].expirationDate);
                                }

                                var delinquent = data.results[0].hasDelinquentFederalDebt;
                                if (delinquent) {
                                    $scope.Steps[7].step7[0].isDelinquentFederalDebt = true;
                                }
                                var Exclusion = data.results[0].hasKnownExclusion;
                                if (Exclusion) {
                                    $scope.Steps[7].step7[0].isKnownExclusion = true;
                                }
                                if (data.results[0].status == "Active") {
                                    $scope.Steps[7].step7[0].isProviderActive = true;
                                }
                            }
                            else {
                                $scope.Steps[1].step1[0].AwardedTo = "";
                                $scope.error = data.results[0].legalBusinessName + "Company is currently inactive";
                                toaster.pop('error', 'Error', $scope.error);
                            }
                            $scope.isloading = false;
                            $scope.bidinfo.awardtoLoad = false;
                        }).error(function (data) {
                            $scope.bidinfo.awardtoLoad = false;
                            $scope.error = data;
                        });
        }

        $scope.bidStatusChanged = function () {
            if ($scope.Steps[1].step1[0].status == 15) {
                $scope.Steps[1].step1[0].AwardedTo = "";
                $scope.Steps[1].step1[0].ContractValue = 0;
                $scope.bidinfo.showmessage1 = true;
            }
            else {
                $scope.bidinfo.showmessage1 = false;
            }
        }
        $scope.totalDollarvalueChanged = function () {
            $scope.bidinfo.showmessage1 = false;
        }
        $scope.proposalsubmittedChanged = function () {
            var currentdate = new Date();
            var submitteddate = new Date($scope.Steps[1].step1[0].submittedDate);
            var proposalDueDate = new Date($scope.Steps[1].step1[0].submittalDate);
            submitteddate.setHours(0, 0, 0, 0);
            proposalDueDate.setHours(0, 0, 0, 0);
            if (submitteddate != "NaN/NaN/NaN" && submitteddate != "") {
                if (submitteddate > currentdate) {
                    toaster.pop("error", "Error", "Proposal Submitted Date cannot be greater than current date")
                    $scope.Steps[1].step1[0].submittedDate = "";
                    $("#rfpSubmittedDateTime").val("");
                }
                else if ($scope.Steps[1].step1[0].submittalDate == '' || !$scope.Steps[1].step1[0].submittalDate) {
                    toaster.pop("error", "Error", "Proposal Submitted date cannot be entered unless you have a Proposal Due Date")
                    $scope.Steps[1].step1[0].submittedDate = "";
                    $("#rfpSubmittedDateTime").val("");
                }
                else if (submitteddate > proposalDueDate) {
                    toaster.pop("error", "Error", "Proposal Submitted Date cannot be greater than Proposal Due date")
                    $scope.Steps[1].step1[0].submittedDate = "";
                    $("#rfpSubmittedDateTime").val("");
                }
            }


        }

        $scope.checkRFIDate = function () {
            var yr = $scope.rfiDate.getFullYear();
            if (yr == "1900")
                return false;
            else
                return true;
        }
        $scope.checkRFPDate = function () {
            var yr = $scope.rfpDate.getFullYear();
            if (yr == "1900")
                return false;
            else
                return true;
        }
        $scope.checkRFIRFPDate = function () {
            var rfiyr = $scope.rfiDate.getFullYear();
            var rfpyr = $scope.rfpDate.getFullYear();
            if (rfpyr != "1900" || rfiyr != "1900")
                return true;
            else
                return false;
        }
        function recheckDates() {
            $scope.checkRFIDate();
            $scope.checkRFPDate();
            $scope.checkRFIRFPDate();
        }
        $scope.checkIfRfiSubmitted = function (bidId) {
            $scope.isRfiSubmitted = false;
            $http.get('/Home/GetRFIStatus?bidID=' + bidId).success(function (data) {
                if (data.data == "success")
                    $scope.isRfiSubmitted = data.result;
            })
        }
        $scope.getClientContracts = function (clientId) {
            $scope.clientContracts = "";
            $http.get('/Home/GetClientContracts?clientId=' + clientId).success(function (data) {
                if (data.data == "success")
                    $scope.clientContracts = data.result;
            })
        }
        //save bid info and move to comments
        $scope.enableStep2 = function () {
            var objForm = this.step1;
            // RR-353 checkShareValidationFlag will hold boolean value if validation share will be valid then its value will be True.
            var checkShareValidationFlag;
            //RR-353  checkShareValidation Method is called to get the addition of partner and rigilshare, if share will be equal to 100 or less than 100 the output will be true.
            checkShareValidation("Bid", 0, $scope.Steps[1].step1[0].workShare, function callback(bool) {
                checkShareValidationFlag = bool
                var isValid = true;
                //isValid = $scope.validateDepartment();
                //isValid = $scope.validateAgency();
                if (!checkShareValidationFlag) {
                    toaster.pop('error', 'Error', "summation of workShare and Partner percentage is not valid!");
                }
                else {
                    if (isValid) {

                        bidInfoModel = {};
                        //populate dto with current input values
                        bidModel = bidInfoModel;
                        if ($scope.Steps[1].step1[0].addMode) { bidModel.Id = 0; } else { bidModel.Id = $scope.currentRecordId; }

                        bidModel.Bid_typeId = $scope.Steps[1].step1[0].bidType;
                        bidModel.Award_typeId = $scope.Steps[1].step1[0].awardType;
                        bidModel.Rigil_Stage = $scope.Steps[1].step1[0].rigilStage;

                        if ($scope.Steps[1].step1[0].releaseDate == null || $scope.Steps[1].step1[0].releaseDate == '') {
                            bidModel.Projected_releaseDate = "01/01/1900";
                        } else {
                            bidModel.Projected_releaseDate = $scope.Steps[1].step1[0].releaseDate;
                        }

                        if ($scope.Steps[1].step1[0].submittalDate == null || $scope.Steps[1].step1[0].submittalDate == '') {
                            bidModel.Proposal_submittalDate = "01/01/1900";
                        } else {
                            bidModel.Proposal_submittalDate = $scope.Steps[1].step1[0].submittalDate;
                        }
                        if (bidModel.Bid_typeId == 13)//if bid type is rfi(13) then remove the proposalsubmitted date
                        {
                            bidModel.Proposal_submittedDate = "01/01/1900";
                            $scope.Steps[1].step1[0].submittedDate = '';
                        }
                        else {
                            if ($scope.Steps[1].step1[0].submittedDate == null || $scope.Steps[1].step1[0].submittedDate == '') {
                                bidModel.Proposal_submittedDate = "01/01/1900";
                            } else {
                                bidModel.Proposal_submittedDate = $scope.Steps[1].step1[0].submittedDate;
                            }
                        }

                        if ($scope.Steps[1].step1[0].submittedTime == null || $scope.Steps[1].step1[0].submittedTime == '') {
                            bidModel.Proposal_submittedTimeOnly = "01/01/1900";
                        } else {
                            bidModel.Proposal_submittedTimeOnly = $scope.Steps[1].step1[0].submittedTime;
                        }
                        //bidModel.Proposal_submittedTimeOnly = $scope.Steps[1].step1[0].submittedTime;
                        bidModel.Code_Name = $scope.Steps[1].step1[0].codeName;
                        bidModel.Prime_Sub = $scope.Steps[1].step1[0].rigilPrimeSub;
                        bidModel.Bid_Score = $scope.Steps[1].step1[0].bidScore;
                        bidModel.Bid_Decision = $scope.Steps[1].step1[0].Bid_Decision;
                        bidModel.isImported = $scope.Steps[1].step1[0].isImported;
                        bidModel.link = $scope.Steps[1].step1[0].link;
                        if ($scope.Steps[1].step1[0].daysToRelease == null || $scope.Steps[1].step1[0].daysToRelease == '') {
                            bidModel.Days_toRelease = 0;
                        } else {
                            bidModel.Days_toRelease = $scope.Steps[1].step1[0].daysToRelease;
                        }
                        bidModel.Status = $scope.Steps[1].step1[0].bidStatus;
                        bidModel.Department = $scope.selectedDept.Agencyname;
                        bidModel.Agency = $scope.selectedAgency.Agencyname;

                        bidModel.DepartmentKey = $scope.selectedDept;
                        bidModel.AgencyKey = $scope.selectedAgency;

                        if ($scope.selectedOffice == null) {
                            bidModel.OfficeKey = {};
                            bidModel.OfficeKey.OfficeName = $scope.Steps[1].step1[0].agencyOffice;
                            bidModel.OfficeKey.Agency_Id = $scope.selectedAgency.Id;
                        }
                        else {
                            bidModel.OfficeKey = $scope.selectedOffice;
                            bidModel.OfficeKey.Agency_Id = bidModel.AgencyKey.Id;
                            bidModel.OfficeKey.OfficeName = $scope.Steps[1].step1[0].agencyOffice;
                        }

                        bidModel.Title = $scope.Steps[1].step1[0].bidTitle;
                        bidModel.Acronym = $scope.Steps[1].step1[0].bidAcronym;
                        bidModel.Solicitation_Num = $scope.Steps[1].step1[0].solicitationNumber;
                        if ($scope.Steps[1].step1[0].solicitationDate == null || $scope.Steps[1].step1[0].solicitationDate == '') {
                            bidModel.Solicitation_Date = "01/01/1900";
                        } else {
                            bidModel.Solicitation_Date = $scope.Steps[1].step1[0].solicitationDate;
                        }
                        bidModel.Work_Share = $scope.Steps[1].step1[0].workShare;
                        bidModel.Bid_competitionTypeId = $scope.Steps[1].step1[0].competitionType;
                        if ($scope.Steps[1].step1[0].totalDollarValue == null || $scope.Steps[1].step1[0].totalDollarValue == '') {
                            bidModel.Total_dollarValue = 0;
                        } else {
                            bidModel.Total_dollarValue = $scope.Steps[1].step1[0].totalDollarValue;
                        }
                        if ($scope.Steps[1].step1[0].rigilDollarValue == null || $scope.Steps[1].step1[0].rigilDollarValue == '') {
                            bidModel.Rigil_dollarValue = 0;
                        } else {
                            bidModel.Rigil_dollarValue = $scope.Steps[1].step1[0].rigilDollarValue;
                        }
                        bidModel.Bid_statusId = $scope.Steps[1].step1[0].status;
                        bidModel.OpportunityId = $scope.Steps[1].step1[0].oppId;
                        if ($scope.Steps[1].step1[0].bidAwardDate == null || $scope.Steps[1].step1[0].bidAwardDate == '') {
                            bidModel.Projected_awardDate = "01/01/1900";
                        } else {
                            bidModel.Projected_awardDate = $scope.Steps[1].step1[0].bidAwardDate;
                        }
                        bidModel.Summary = $scope.Steps[1].step1[0].summary;

                        bidModel.AwardedTo = $scope.Steps[1].step1[0].AwardedTo;
                        bidModel.ContractValue = $scope.Steps[1].step1[0].ContractValue;
                        bidModel.Duration = $scope.Steps[1].step1[0].Duration;
                        bidModel.isProjected = $scope.Steps[1].step1[0].isProjected;
                        if ($scope.Steps[1].step1[0].idiqId == null) {
                            bidModel.IDIQID = 0;
                        }
                        else {
                            bidModel.IDIQID = $scope.Steps[1].step1[0].idiqId;
                        }

                        bidModel.BusinessArea = $scope.Steps[1].step1[0].businessArea;

                        if ($scope.Steps[1].step1[0].debriefrequest == "" || $scope.Steps[1].step1[0].debriefrequest == null) {
                            bidModel.Debrief_Request = "01/01/1900";
                        }
                        else {
                            bidModel.Debrief_Request = $scope.Steps[1].step1[0].debriefrequest;
                        }

                        if ($scope.Steps[1].step1[0].debriefreceived == "" || $scope.Steps[1].step1[0].debriefreceived == null) {
                            bidModel.Debrief_Received = "01/01/1900";
                        }
                        else {
                            bidModel.Debrief_Received = $scope.Steps[1].step1[0].debriefreceived;
                        }

                        if ($scope.Steps[1].step1[0].popstart == "" || $scope.Steps[1].step1[0].popstart == null) {
                            bidModel.Pop_Start = "01/01/1900";
                        }
                        else {
                            bidModel.Pop_Start = $scope.Steps[1].step1[0].popstart;
                        }

                        if ($scope.Steps[1].step1[0].popend == "" || $scope.Steps[1].step1[0].popend == null) {
                            bidModel.Pop_End = "01/01/1900";
                        }
                        else {
                            bidModel.Pop_End = $scope.Steps[1].step1[0].popend;
                        }
                        if ($scope.Steps[1].step1[0].rfiDueDate == "" || $scope.Steps[1].step1[0].rfiDueDate == null) {
                            bidModel.RFIDueDate = "01/01/1900";
                        }
                        else {
                            bidModel.RFIDueDate = $scope.Steps[1].step1[0].rfiDueDate;
                        }
                        bidModel.Debrief_Description = $scope.Steps[1].step1[0].debriefdescription;
                        bidModel.CLocationZip = $scope.Steps[1].step1[0].customerZipCode;
                        bidModel.CLocationCity = $scope.Steps[1].step1[0].customerCity;
                        bidModel.CLocationState = $scope.Steps[1].step1[0].customerState;
                        if ($scope.Steps[1].step1[0].cManager == "" || $scope.Steps[1].step1[0].cManager == null) {
                            bidModel.CManager = "";
                        }
                        else {
                            bidModel.CManager = $scope.Steps[1].step1[0].cManager.Email;
                        }
                        if ($scope.Steps[1].step1[0].pManager == "" || $scope.Steps[1].step1[0].pManager == null) {
                            bidModel.PManager = "";
                        }
                        else {
                            bidModel.PManager = $scope.Steps[1].step1[0].pManager.Email;
                        }
                        bidModel.AwardNumber = $scope.Steps[1].step1[0].awardNumber;
                        if ($scope.Steps[1].step1[0].rfiSubmittedDate == "" || $scope.Steps[1].step1[0].rfiSubmittedDate == null) {
                            bidModel.RFISubmittedDate = "01/01/1900";
                            $scope.rfiDate = new Date(bidModel.RFISubmittedDate);
                        }
                        else {
                            bidModel.RFISubmittedDate = new Date($scope.Steps[1].step1[0].rfiSubmittedDate);//$scope.Steps[1].step1[0].rfiSubmittedDate;
                            $scope.rfiDate = new Date(bidModel.RFISubmittedDate);
                        }
                        if ($scope.Steps[1].step1[0].submittedDate == null || $scope.Steps[1].step1[0].submittedDate == '') {
                            bidModel.Proposal_submittedDate = "01/01/1900";
                            $scope.rfpDate = new Date(bidModel.Proposal_submittedDate);
                        } else {
                            bidModel.Proposal_submittedDate = new Date($scope.Steps[1].step1[0].submittedDate);
                            $scope.rfpDate = new Date(bidModel.Proposal_submittedDate);
                        }

                        bidModel.WorkLocation = $scope.Steps[1].step1[0].workLocation;
                        // ******* RR-541  START    ***********************************//
                        if ($scope.Steps[1].step1[0].followDate == "" || $scope.Steps[1].step1[0].followDate == null) {
                            bidModel.FollowDate = "01/01/1900";
                        }
                        else {
                            bidModel.FollowDate = $scope.Steps[1].step1[0].followDate;
                        }
                        if ($scope.Steps[1].step1[0].followAssignedRolesObj == undefined || $scope.Steps[1].step1[0].followAssignedRolesObj.Count <= 0 || bidModel.FollowDate == "01/01/1900") {
                            bidModel.AssignedFollowRole = "";
                        }
                        else {
                            var list = [];
                            angular.forEach($scope.Steps[1].step1[0].followAssignedRolesObj, function (value, index) {
                                list.push(value.Id);
                            })

                            bidModel.AssignedFollowRole = list.join(',');
                        }
                        // ******* RR-541  END    ***********************************//

                        // ******* RR-536  START    ***********************************//
                        if ($scope.Steps[1].step1[0].KEGId == null || $scope.Steps[1].step1[0].KEGId == undefined || $scope.Steps[1].step1[0].KEGId == "") {
                            bidModel.KEGId = 0;
                        }
                        else {
                            bidModel.KEGId = $scope.Steps[1].step1[0].KEGId;
                        }
                        if ($scope.Steps[1].step1[0].ContractId == null || $scope.Steps[1].step1[0].ContractId == undefined || $scope.Steps[1].step1[0].ContractId == "") {
                            bidModel.ContractId = 0;
                        }
                        else {
                            bidModel.ContractId = $scope.Steps[1].step1[0].ContractId;
                        }
                        bidModel.ContractPMName = $scope.Steps[1].step1[0].ContractPMName;
                        bidModel.ContractPMEmail = $scope.Steps[1].step1[0].ContractPMEmail;
                        bidModel.ContractPMPhone = $scope.Steps[1].step1[0].ContractPMPhone;
                        // ******* RR-536  END    ***********************************//

                        if ($scope.Steps[7].step7[0].serviceProviderName != "" && $scope.Steps[7].step7[0].serviceProviderName != null) {
                            if ($scope.Steps[7].step7[0].isProviderActive == true) {
                                $scope.companyinfo.Id = 0;
                                $scope.companyinfo.ServiceProviderName = $scope.Steps[7].step7[0].serviceProviderName;
                                $scope.companyinfo.Duns = $scope.Steps[7].step7[0].DUNS;
                                $scope.companyinfo.Street = $scope.Steps[7].step7[0].street;
                                $scope.companyinfo.City = $scope.Steps[7].step7[0].city;
                                $scope.companyinfo.State = $scope.Steps[7].step7[0].state;
                                $scope.companyinfo.Country = $scope.Steps[7].step7[0].country;
                                $scope.companyinfo.Zip = $scope.Steps[7].step7[0].zip;
                                $scope.companyinfo.Cage = $scope.Steps[7].step7[0].cage;
                                $scope.companyinfo.DunsPlus4 = $scope.Steps[7].step7[0].DUNSPlus4;
                                $scope.companyinfo.ExpirationDate = $scope.Steps[7].step7[0].expirationDate;
                                $scope.companyinfo.HasDelinquentFederalDebt = $scope.Steps[7].step7[0].isDelinquentFederalDebt;
                                $scope.companyinfo.HasKnownExclusion = $scope.Steps[7].step7[0].isKnownExclusion;
                                $scope.companyinfo.IsProviderActive = $scope.Steps[7].step7[0].isProviderActive;

                                $http.post('/Home/SaveCompany', $scope.companyinfo).success(function (data) {
                                    if (data.data == "success") {
                                    }
                                }).error(function (data) {
                                });
                            }

                        }

                        $scope.bidinfo.showmessage1 = false;
                        $scope.bidinfo.awardtoLoad = false;

                        //for insert
                        if ($scope.Steps[1].step1[0].addMode) {
                            if (bidModel.Title != null && bidModel.Projected_releaseDate != null && bidModel.Department != "") {
                                $http.post('/api/Bids/', bidModel).success(function (data) {
                                    if (data.id == 0) {
                                        toaster.pop('error', 'Error', "Server validation reported save error. So, data could not be saved !");
                                    } else {
                                        if (bidModel.Bid_statusId == 14 || bidModel.Bid_statusId == 15) {
                                            $scope.AddDebriefModal(data.Id);
                                        }
                                        toaster.pop('success', 'Success', "Bid Information Added successfully!");

                                        recheckDates();
                                        ActivityService.assortedCalls().saveAllCalls(46);
                                        $scope.currentRecordId = data.Id;

                                        $scope.bidId = data.Id;

                                        $scope.checkIfRfiSubmitted($scope.currentRecordId);
                                        $scope.getClientContracts($scope.selectedAgency.Id);
                                        $scope.daysDifference($scope.Steps[1].step1[0].releaseDate, $scope.Steps[1].step1[0].submittalDate);

                                        $scope.bidsIndex.push(data);
                                        $scope.Steps[1].step1[0].oppId = data.OpportunityId;
                                        $scope.currentIndex = $scope.bidsIndex.length - 1;
                                        $scope.Steps[1].step1[0].addMode = false;
                                        $scope.Steps[2].step2[0].addMode = true;
                                        objForm.$setPristine(true);
                                        $scope.submissionPending = false;
                                        //re create and update the temporary columns in the array
                                        $scope.bidsIndex[$scope.currentIndex]['RelDays'] = $scope.daysToGo($scope.bidsIndex[$scope.currentIndex].Projected_releaseDate);
                                        $scope.bidsIndex[$scope.currentIndex]['BiddingStage'] = $scope.bidStageText($scope.bidsIndex[$scope.currentIndex].Rigil_Stage);
                                        $scope.bidsIndex[$scope.currentIndex]['BiddingStatus'] = $scope.bidStatusText($scope.bidsIndex[$scope.currentIndex].Bid_statusId);
                                        $scope.bidsIndex[$scope.currentIndex]['CompetitionType'] = $scope.bidCompetitionTypeText($scope.bidsIndex[$scope.currentIndex].Bid_competitionTypeId);
                                        $scope.bidsIndex[$scope.currentIndex]['BiddingType'] = $scope.bidTypeToText($scope.bidsIndex[$scope.currentIndex].Bid_typeId);
                                        $scope.bidsIndex[$scope.currentIndex]['PrimeSubType'] = $scope.PrimeSubTypeToText($scope.bidsIndex[$scope.currentIndex].Prime_Sub);
                                        $scope.bidsIndex[$scope.currentIndex]['RigilStageType'] = $scope.RigilStageToText($scope.bidsIndex[$scope.currentIndex].Rigil_Stage);
                                        $scope.bidsIndex[$scope.currentIndex]['BiddingAwardType'] = $scope.bidAwardTypeToText($scope.bidsIndex[$scope.currentIndex].Award_typeId);
                                        $scope.bidsIndex[$scope.currentIndex]['AgencyName'] = $scope.bidsIndex[$scope.currentIndex].AgencyKey.Agencyname;
                                        $scope.bidsIndex[$scope.currentIndex]['AgencyAcronym'] = $scope.bidsIndex[$scope.currentIndex].AgencyKey.Acronym;
                                        $scope.bidsIndex[$scope.currentIndex]['TotalValue_short'] = $scope.bidsIndex[$scope.Total_dollarValue] / 1000000;
                                        $scope.bidsIndex[$scope.currentIndex].Rating = 0;
                                        $scope.bidsIndex[$scope.currentIndex].RatingId = 0;
                                        $scope.bidsIndex[$scope.currentIndex].Ratings = ['False', 'False', 'False', 'False', 'False'];

                                        $scope.loadBidTrackingItems($scope.currentRecordId);
                                        $scope.Steps[3].step3[0].active = true;
                                    }
                                }).error(function (data) {
                                    $scope.error = "An Error has occurred while adding Bid! ";
                                    toaster.pop('error', 'Error', $scope.error);
                                });
                            } else {
                                toaster.pop('error', 'Error', "Bid Information was not added!");
                            }

                            //for update
                        } else {
                            $http.put('/api/Bids/' + $scope.currentRecordId, bidModel).success(function (data) {
                                $scope.loading = false;
                                ActivityService.assortedCalls().saveAllCalls(47);
                                angular.forEach($scope.bidsIndex, function (value, index) {
                                    if (value.Id == $scope.currentRecordId) {
                                        $scope.currentIndex = index;
                                    }
                                })
                                toaster.pop('success', 'Success', "Bid Information updated successfully!");
                                $scope.bidsIndex[$scope.currentIndex] = bidModel;
                                recheckDates();
                                $scope.checkIfRfiSubmitted($scope.currentRecordId);
                                $scope.getClientContracts($scope.selectedAgency.Id);
                                $scope.daysDifference($scope.Steps[1].step1[0].releaseDate, $scope.Steps[1].step1[0].submittalDate);
                                //re create and update the temporary columns in the array
                                $scope.bidsIndex[$scope.currentIndex]['RelDays'] = $scope.daysToGo($scope.bidsIndex[$scope.currentIndex].Projected_releaseDate);
                                $scope.bidsIndex[$scope.currentIndex]['BiddingStage'] = $scope.bidStageText($scope.bidsIndex[$scope.currentIndex].Rigil_Stage);
                                $scope.bidsIndex[$scope.currentIndex]['BiddingStatus'] = $scope.bidStatusText($scope.bidsIndex[$scope.currentIndex].Bid_statusId);
                                $scope.bidsIndex[$scope.currentIndex]['CompetitionType'] = $scope.bidCompetitionTypeText($scope.bidsIndex[$scope.currentIndex].Bid_competitionTypeId);
                                $scope.bidsIndex[$scope.currentIndex]['BiddingType'] = $scope.bidTypeToText($scope.bidsIndex[$scope.currentIndex].Bid_typeId);
                                $scope.bidsIndex[$scope.currentIndex]['PrimeSubType'] = $scope.PrimeSubTypeToText($scope.bidsIndex[$scope.currentIndex].Prime_Sub);
                                $scope.bidsIndex[$scope.currentIndex]['RigilStageType'] = $scope.RigilStageToText($scope.bidsIndex[$scope.currentIndex].Rigil_Stage);
                                $scope.bidsIndex[$scope.currentIndex]['BiddingAwardType'] = $scope.bidAwardTypeToText($scope.bidsIndex[$scope.currentIndex].Award_typeId);
                                $scope.bidsIndex[$scope.currentIndex]['AgencyName'] = $scope.bidsIndex[$scope.currentIndex].AgencyKey.Agencyname;
                                $scope.bidsIndex[$scope.currentIndex]['AgencyAcronym'] = $scope.bidsIndex[$scope.currentIndex].AgencyKey.Acronym;
                                $scope.bidsIndex[$scope.currentIndex]['TotalValue_short'] = $scope.bidsIndex[$scope.Total_dollarValue] / 1000000;

                                objForm.$setPristine();

                                //load Bid Tracking changes
                                $scope.loadBidTrackingItems($scope.currentRecordId);

                                //Fetch history
                                $scope.getHistory($scope.currentRecordId);
                                $scope.Steps[3].step3[0].active = true;

                            }).error(function (data) {
                                $scope.error = "An Error has occurred while updating Bid! " + data;
                                $scope.loading = false;
                                toaster.pop('error', 'Error', $scope.error);
                            });
                        }


                    }
                    else
                        toaster.pop('error', 'Error', " Either Department Name or Agency Name is not valid!");
                }
            });
        };

        //from bid info move to Actions
        $scope.enableStep2step = function () {
            $scope.Steps[3].step3[0].active = true;
        }

        //toggle task board from task action column
        $scope.showTaskTableToggleA = function (id) {
            //

            //action delete case
            if (!$scope.actions.isadding && !$scope.actions.isediting) {

                if (id != null) {
                    for (i = 0; i < $scope.task_Actions.length; i++) {
                        if ($scope.task_Actions[i].id == id) {
                            if ($scope.task_Actions[i].actionItems.length > 0) {
                                toaster.pop('error', 'Error', "Delete Action Items first !");
                                return false;
                            }
                            else {
                                //delete action
                                $scope.deleteInstance(id, 'Action');
                                //update the board
                                if ($scope.isdeletionConfirmed) {
                                    for (i = 0; i < $scope.task_Actions.length; i++) {
                                        if ($scope.task_Actions[i].id == id) {
                                            $scope.task_Actions.splice(i, 1);
                                            return false;
                                        }
                                    }
                                }
                                $scope.isdeletionConfirmed = false;
                            }

                        }
                    }
                }
                return false;
            }

            $scope.showTaskTable = !$scope.showTaskTable;
            $scope.isActionSelected = !$scope.showTaskTable;

            //action edit case
            if ($scope.actions.isediting && !$scope.actions.isadding) {
                if (id != null) {
                    for (i = 0; i < $scope.task_Actions.length; i++) {
                        if ($scope.task_Actions[i].id == id) {
                            $scope.actions.currentId = id;  //store selected if to a global variable
                            $scope.ACTION.actionTitle = $scope.task_Actions[i].action_title;
                            $scope.ACTION.actionText = $scope.task_Actions[i].action;
                            $scope.ACTION.actionDueDate = $scope.formatdate($scope.task_Actions[i].dueDate);
                            $scope.ACTION.assignees = $scope.task_Actions[i].users;
                            $scope.ACTION.actionStatus = $scope.task_Actions[i].comment;
                            //RR-537 TODO
                            $scope.ACTION.assignedBy = $scope.task_Actions[i].assignedBy;
                            return true;
                        }
                    }
                }
            }
        }

        //initialize form variable before new Action entry
        $scope.initializeActionForm = function () {
            //
            $scope.ACTION.actionTitle = '';
            $scope.ACTION.actionText = '';
            $scope.ACTION.actionDueDate = '';
            $scope.ACTION.assignees = '';
            $scope.ACTION.actionStatus = '';
            //RR-537
            $scope.ACTION.assignedBy = $scope.app.permissions.USERNAME;

        }

        //initialize form variable before new ActionItem entry
        $scope.initializeActionItemForm = function () {
            //
            $scope.ACTIONITEM.actionTitle = '';
            $scope.ACTIONITEM.actionText = '';
            $scope.ACTIONITEM.actionStartDate = '';
            $scope.ACTIONITEM.actionDueDate = '';
            $scope.ACTIONITEM.actionDueTime = '';
            $scope.ACTIONITEM.reminderDate = '';
            $scope.ACTIONITEM.assignees = '';
            $scope.ACTIONITEM.isMilestone = false;
            $scope.ACTIONITEM.pcComplete = 0;
            //RR-537
            $scope.ACTIONITEM.assignedBy = $scope.app.permissions.USERNAME;
        }

        //update task action on board
        $scope.updateActionOnBoard = function () {
            //
            $scope.editoldInstance($scope.actions.currentId, 'Action');

            //prepare update to send to server
            $scope.action.Action_Title = $scope.ACTION.actionTitle;
            $scope.action.Action_takenLastWeek = $scope.ACTION.actionText;
            $scope.action.DueDate = $scope.formatdate($scope.ACTION.actionDueDate);
            $scope.action.UserId = $scope.ACTION.assignees.toString();
            $scope.action.Comments = $scope.ACTION.actionStatus;
            //RR-537
            $scope.action.AssignedBy = $scope.ACTION.assignedBy;
            $scope.setMaxdate($scope.action.DueDate);

            //push to server
            $scope.saveInstance($scope.actions.currentId, 'Action');


        }

        //toggle task board from task action items column
        $scope.showTaskTableToggleAI = function (taskid, taskactionid) {
            //
            if (!$scope.actionitems.isadding && !$scope.actionitems.isediting) {

                //delete from server
                if (taskactionid != null) {
                    $scope.deleteInstance(taskactionid, 'Actionitem');
                    //update the board
                    if ($scope.isdeletionConfirmed) {
                        for (i = 0; i < $scope.task_Actions.length; i++) {
                            if ($scope.task_Actions[i].id == taskid) {
                                for (j = 0; j < $scope.task_Actions[i].actionItems.length; j++) {
                                    if ($scope.task_Actions[i].actionItems[j].id == taskactionid) {
                                        $scope.task_Actions[i].actionItems.splice(j, 1);
                                        return false;
                                    }
                                }
                            }
                        }

                    }
                    $scope.isdeletionConfirmed = false;
                }

                return false;
            }

            $scope.showTaskTable = !$scope.showTaskTable;
            $scope.isActionItemSelected = !$scope.showTaskTable;

            if ($scope.actionitems.isediting && !$scope.actionitems.isadding) {
                if (taskactionid != null) {
                    for (i = 0; i < $scope.task_Actions.length; i++) {
                        if ($scope.task_Actions[i].id == taskid) {
                            for (j = 0; j < $scope.task_Actions[i].actionItems.length; j++) {
                                if ($scope.task_Actions[i].actionItems[j].id == taskactionid) {
                                    $scope.actionitems.currentId = taskactionid;
                                    $scope.ACTIONITEM.actionTitle = $scope.task_Actions[i].actionItems[j].actionitem_title;
                                    $scope.ACTIONITEM.actionText = $scope.task_Actions[i].actionItems[j].Item;
                                    $scope.ACTIONITEM.actionStartDate = $scope.formatdate($scope.task_Actions[i].actionItems[j].startDate); //559
                                    $scope.ACTIONITEM.actionDueDate = $scope.formatdate($scope.task_Actions[i].actionItems[j].dueDate);
                                    $scope.ACTIONITEM.actionDueTime = $scope.task_Actions[i].actionItems[j].dueTime;
                                    $scope.ACTIONITEM.reminderDate = $scope.formatdate($scope.task_Actions[i].actionItems[j].reminderDate);
                                    $scope.ACTIONITEM.assignees = $scope.task_Actions[i].actionItems[j].users;
                                    $scope.ACTIONITEM.isMilestone = $scope.task_Actions[i].actionItems[j].isMilestone;
                                    $scope.ACTIONITEM.pcComplete = $scope.task_Actions[i].actionItems[j].pccomplete;
                                    //RR-537
                                    $scope.ACTIONITEM.assignedBy = $scope.task_Actions[i].actionItems[j].assignedBy;
                                    $scope.setMaxdate($scope.task_Actions[i].dueDate);
                                    return false;
                                }
                            }
                        }
                    }
                }
            }

        }

        //update task action on board
        $scope.updateActionItemOnBoard = function () {
            //
            $scope.editoldInstance($scope.actionitems.currentId, 'Actionitem');

            //prepare update to send to server
            $scope.actionitem.ActionItem_Title = $scope.ACTIONITEM.actionTitle;
            $scope.actionitem.ActionItem = $scope.ACTIONITEM.actionText;
            $scope.actionitem.Start_From = $scope.ACTIONITEM.actionStartDate;
            $scope.actionitem.ActionDue_dateTime = $scope.formatdate($scope.ACTIONITEM.actionDueDate);
            $scope.actionitem.ActionDue_TimeOnlyDT = $scope.ACTIONITEM.actionDueTime;
            $scope.actionitem.ReminderDate_dateTime = $scope.ACTIONITEM.reminderDate;
            $scope.actionitem.By_userId = $scope.ACTIONITEM.assignees.toString();
            $scope.actionitem.IsMilestone = $scope.ACTIONITEM.isMilestone;
            $scope.actionitem.pc_complete = $scope.ACTIONITEM.pcComplete;


            //RR-537
            $scope.actionitem.assignedBy = $scope.ACTIONITEM.assignedBy;
            //push to server
            $scope.saveInstance($scope.actionitems.currentId, 'Actionitem');
            ////update the board
            //for (i = 0; i < $scope.task_Actions.length; i++) {
            //    if ($scope.task_Actions[i].id == $scope.actionitem.ActionId) {
            //        for (j = 0; j < $scope.task_Actions[i].actionItems.length; j++) {
            //            if ($scope.task_Actions[i].actionItems[j].id == $scope.actionitem.currentId) {
            //                $scope.task_Actions[i].actionItems[j].Item = $scope.ACTIONITEM.actionText;
            //                $scope.task_Actions[i].actionItems[j].dueDate = $scope.ACTIONITEM.actionDueDate;
            //                $scope.task_Actions[i].actionItems[j].reminderDate = $scope.ACTIONITEM.reminderDate;
            //                $scope.task_Actions[i].actionItems[j].users = $scope.ACTIONITEM.assignees;
            //                return false;
            //            }
            //        }
            //    }
            //}
        }

        //comma separated string of users
        $scope.usersListToString = function (userArray) {
            var userString = '';
            if (userArray != null) {
                userString = userArray[0];
                for (i = 1; i < userArray.length; i++) {
                    userString = userString + ", " + userArray[i];
                };
            }
            return userString;
        }

        $scope.addNewBid = function () {
            $scope.bidId = 0;
            $scope.task_Actions = [];
            $scope.task_ActionItems = [];
            $scope.task_inprogressItems = [];
            $scope.bidHistory = [];
            $scope.HbidsCount = 0;
        }

        $scope.$on('bidUpdatedNotification', function (event, bidId) {
            $scope.bidId = bidId;
            $scope.selectedBid(bidId, 'E', bidId);
            $scope.formInfoListData = [];
            $scope.getForm(1);//1 for module Bid
            $scope.showEntry = true;
            $scope.showList = false;
        });
        //RR-541
        //returns the role name text from a rolelist
        function getRoleText(id) {
            var retString = "";
            angular.forEach($scope.allRoles, function (value, index) {
                if (value.Id == id) { retString = value.Value; }
            })
            return retString;
        }

        //RR-538
        $scope.showHideTimeline = function () {
            $scope.showTimeline = !$scope.showTimeline;
        }

        //edit/view bid method
        $scope.selectedBid = function (index, type, id) {
            $scope.loadingImage = false;
            angular.copy($scope.StepsSource, $scope.Steps);
            var bellObjectValue = false;
            //if ($scope.counter == 1 && type != 'D') { return true; } //to prevent double triggering of same event with E and V type
            //update the isRead status and isUpdated status
            angular.forEach($scope.bidsIndex, function (value, index) {
                if (value.Id == id) {
                    bellObjectValue = value.isBell;
                    if ($scope.app.permissions.USERNAME == value.AddedBy) {
                        value.isRead = false;
                        $http.post("/ExternalBid/ChangeReadStatus?status=" + value.isRead + "&bidId=" + id);
                    }
                    //update the isUpdated status
                    if (value.isUpdated == true) {
                        value.isUpdated = false;
                        $http.post("/BidUpdate/ChangeBidUpdateStatus?bidId=" + id);
                    }
                }
            })
            $scope.bidIndex = index;
            $scope.bidType = type;
            $scope.bidId = id;
            $scope.task_Actions = [];
            $scope.task_ActionItems = [];
            $scope.task_inprogressItems = [];
            $scope.task_doneItems = [];
            $scope.task_users = [];
            $scope.codeErrorMessage = "";
            $scope.neWs = {
                addnew: true, //$scope.showLink('BidTracker.News.ButtonNew'),
                editold: true, //$scope.showLink('BidTracker.News.EditRight'),
                deleteold: true, //$scope.showLink('BidTracker.News.DeleteRight'),
                isadding: false,
                isediting: false,
            }
            // for Library
            //for bid_news permissions
            $scope.library = {
                addnew: true, //$scope.showLink('BidTracker.News.ButtonNew'),
                editold: true, //$scope.showLink('BidTracker.News.EditRight'),
                deleteold: true, //$scope.showLink('BidTracker.News.DeleteRight'),
                isadding: false,
                isediting: false,
            }

            var ID = id;
            $http.get('/api/Bids/' + ID).success(function (data) {
                if (data.id == 0) {
                    toaster.pop('error', 'Error', "No data was fetched!");
                } else {
                    bidModel = data;
                    angular.copy($scope.StepsSource, $scope.Steps);

                    $scope.Steps[1].step1[0].addMode = false;
                    //$scope.showView = false;
                    if (bidModel != null) {
                        $scope.Steps[1].step1[0].bidType = bidModel.Bid_typeId;
                        $scope.bidTypeOnchange($scope.Steps[1].step1[0].bidType, ID);
                        $scope.Steps[1].step1[0].awardType = bidModel.Award_typeId;
                        $scope.Steps[1].step1[0].rigilStage = bidModel.Rigil_Stage;
                        $scope.Steps[1].step1[0].link = bidModel.link;
                        $scope.Steps[1].step1[0].isBell = bellObjectValue;//RR-505
                        var rd = new Date(bidModel.Projected_releaseDate);
                        if (rd.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].releaseDate = "";
                        }
                        else {
                            $scope.Steps[1].step1[0].releaseDate = $scope.formatdate(bidModel.Projected_releaseDate);
                        }

                        var sb = new Date(bidModel.Proposal_submittalDate);
                        if (sb.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].submittalDate = "";
                        }
                        else {
                            $scope.Steps[1].step1[0].submittalDate = $scope.formatdate(bidModel.Proposal_submittalDate);
                        }
                        var psd = new Date(bidModel.Proposal_submittedDate);
                        if (psd.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].submittedDate = "";
                        } else {
                            $scope.Steps[1].step1[0].submittedDate = $scope.formatdate(bidModel.Proposal_submittedDate);
                        }
                        $scope.Steps[1].step1[0].submittedTime = bidModel.Proposal_submittedTimeOnly;
                        $scope.Steps[1].step1[0].codeName = bidModel.Code_Name;
                        $scope.Steps[1].step1[0].rigilPrimeSub = parseInt(bidModel.Prime_Sub);
                        $scope.Steps[1].step1[0].bidScore = bidModel.Bid_Score;
                        $scope.Steps[1].step1[0].Bid_Decision = bidModel.Bid_Decision;
                        $scope.Steps[1].step1[0].isImported = bidModel.isImported;

                        $scope.Steps[1].step1[0].isProjected = bidModel.isProjected;
                        if (bidModel.isProjected) {
                            $scope.Steps[1].step1[0].daysToRelease = $scope.daysToGo(bidModel.Projected_releaseDate);
                        } else {
                            $scope.Steps[1].step1[0].daysToRelease = $scope.daysToGo(bidModel.Proposal_submittalDate);
                        }
                        $scope.Steps[1].step1[0].bidStatus = bidModel.Status;
                        $scope.oldNAICSval = bidModel.Status;
                        $scope.Steps[1].step1[0].departmentName = bidModel.DepartmentKey.Id;
                        $http.get('/Home/GetAgencies?departmentId=' + bidModel.DepartmentKey.Id).success(function (data) {
                            $scope.agencies = data.agencyList;
                            $scope.Steps[1].step1[0].departmentAgency = bidModel.AgencyKey.Id;
                        })

                        $scope.selectedDept = bidModel.DepartmentKey;
                        $scope.selectedAgency = bidModel.AgencyKey;
                        $scope.selectedOffice = bidModel.OfficeKey;
                        if (bidModel.OfficeKey != null) {
                            $scope.Steps[1].step1[0].agencyOffice = bidModel.OfficeKey.OfficeName;
                        } else {
                            $scope.Steps[1].step1[0].agencyOffice = "";
                        }

                        $scope.Steps[1].step1[0].bidTitle = bidModel.Title;
                        $scope.Steps[1].step1[0].bidAcronym = bidModel.Acronym;
                        $scope.Steps[1].step1[0].solicitationNumber = bidModel.Solicitation_Num;
                        var sd = new Date(bidModel.Solicitation_Date);
                        if (sd.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].solicitationDate = "";
                        }
                        else {
                            $scope.Steps[1].step1[0].solicitationDate = $scope.formatdate(bidModel.Solicitation_Date);
                        }

                        $scope.Steps[1].step1[0].workShare = bidModel.Work_Share;
                        $scope.Steps[1].step1[0].competitionType = bidModel.Bid_competitionTypeId;
                        $scope.Steps[1].step1[0].totalDollarValue = bidModel.Total_dollarValue;
                        $scope.Steps[1].step1[0].rigilDollarValue = bidModel.Rigil_dollarValue;

                        $scope.Steps[1].step1[0].status = bidModel.Bid_statusId;
                        $scope.Steps[1].step1[0].oppId = bidModel.OpportunityId;
                        var da = new Date(bidModel.Projected_awardDate);
                        if (da.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].bidAwardDate = "";
                        } else {
                            $scope.Steps[1].step1[0].bidAwardDate = $scope.formatdate(bidModel.Projected_awardDate);
                        }
                        $scope.Steps[1].step1[0].summary = bidModel.Summary;
                        $scope.trustedHtmlSummary = $sce.trustAsHtml($scope.Steps[1].step1[0].summary);

                        $scope.Steps[1].step1[0].AwardedTo = bidModel.AwardedTo;
                        $scope.Steps[1].step1[0].ContractValue = bidModel.ContractValue;
                        $scope.Steps[1].step1[0].Duration = bidModel.Duration;
                        $scope.Steps[1].step1[0].businessArea = bidModel.BusinessArea;
                        $scope.Steps[1].step1[0].idiqId = bidModel.IDIQID;
                        var dreq = new Date(bidModel.Debrief_Request);
                        if (dreq.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].debriefrequest = "";
                        } else {
                            $scope.Steps[1].step1[0].debriefrequest = $scope.formatdate(bidModel.Debrief_Request);
                        }

                        var drec = new Date(bidModel.Debrief_Received);
                        if (drec.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].debriefreceived = "";
                        } else {
                            $scope.Steps[1].step1[0].debriefreceived = $scope.formatdate(bidModel.Debrief_Received);
                        }

                        var pops = new Date(bidModel.Pop_Start);
                        if (pops.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].popstart = "";
                        } else {
                            $scope.Steps[1].step1[0].popstart = $scope.formatdate(bidModel.Pop_Start);
                        }

                        var pope = new Date(bidModel.Pop_End);
                        if (pope.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].popend = "";
                        } else {
                            $scope.Steps[1].step1[0].popend = $scope.formatdate(bidModel.Pop_End);
                        }
                        var rfidue = new Date(bidModel.RFIDueDate);
                        if (rfidue.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].rfiDueDate = "";
                        } else {
                            $scope.Steps[1].step1[0].rfiDueDate = $scope.formatdate(bidModel.RFIDueDate);
                        }
                        $scope.Steps[1].step1[0].debriefdescription = bidModel.Debrief_Description;
                        $scope.Steps[1].step1[0].customerZipCode = bidModel.CLocationZip;
                        $scope.Steps[1].step1[0].customerCity = bidModel.CLocationCity;
                        $scope.Steps[1].step1[0].customerState = bidModel.CLocationState;
                        if (bidModel.CManager == "" || bidModel.CManager == null) {
                            $scope.Steps[1].step1[0].cManager = "";
                        }
                        else {
                            $scope.Steps[1].step1[0].cManager = {};
                            $scope.Steps[1].step1[0].cManager.Email = bidModel.CManager;
                        }
                        if (bidModel.PManager == "" || bidModel.PManager == null) {
                            $scope.Steps[1].step1[0].pManager.Email = "";
                        }
                        else {
                            $scope.Steps[1].step1[0].pManager = {};
                            $scope.Steps[1].step1[0].pManager.Email = bidModel.PManager;
                        }
                        $scope.Steps[1].step1[0].awardNumber = bidModel.AwardNumber;
                        var rfisubmit = new Date(bidModel.RFISubmittedDate);
                        if (rfisubmit.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].rfiSubmittedDate = "";
                        } else {
                            $scope.Steps[1].step1[0].rfiSubmittedDate = $scope.formatdatetime(bidModel.RFISubmittedDate);//new Date(bidModel.RFISubmittedDate).toLocaleString()
                            $scope.rfiDate = new Date($scope.Steps[1].step1[0].rfiSubmittedDate);
                        }
                        var psd = new Date(bidModel.Proposal_submittedDate);
                        if (psd.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].submittedDate = "";
                        } else {
                            $scope.Steps[1].step1[0].submittedDate = $scope.formatdatetime(bidModel.Proposal_submittedDate);
                            $scope.rfpDate = new Date($scope.Steps[1].step1[0].submittedDate);
                        }
                        $scope.Steps[1].step1[0].workLocation = bidModel.WorkLocation;
                        // ***************    RR-541    START   ******************************//
                        var followD = new Date(bidModel.FollowDate);
                        if (followD.getFullYear() <= 1900) {
                            $scope.Steps[1].step1[0].followDate = "";
                        } else {
                            $scope.Steps[1].step1[0].followDate = $scope.formatdate(bidModel.FollowDate);
                        }
                        var selectedfollowDropDownObj = {
                            Id: 0,
                            Value: ""
                        };
                        var selectedfollowDropDownObjs = [];
                        if (bidModel.AssignedFollowRole != null && bidModel.AssignedFollowRole != "" && bidModel.AssignedFollowRole != undefined) {
                            var followRoleIds = bidModel.AssignedFollowRole.split(",");
                            for (j = 0; j < followRoleIds.length; j++) {
                                var newObj = angular.copy(selectedfollowDropDownObj);
                                newObj.Id = parseInt(followRoleIds[j]);
                                newObj.Value = getRoleText(newObj.Id);
                                selectedfollowDropDownObjs.push(newObj);
                            }
                        }
                        $scope.Steps[1].step1[0].followAssignedRolesObj = selectedfollowDropDownObjs;

                        // ***************    RR-541    END   ******************************//

                        // ***************    RR-536    START   ******************************//
                        $scope.Steps[1].step1[0].KEGId = bidModel.KEGId;
                        $scope.Steps[1].step1[0].ContractId = bidModel.ContractId;
                        $scope.Steps[1].step1[0].ContractPMName = bidModel.ContractPMName;
                        $scope.Steps[1].step1[0].ContractPMEmail = bidModel.ContractPMEmail;
                        $scope.Steps[1].step1[0].ContractPMPhone = bidModel.ContractPMPhone;
                        if (bidModel.KEGId > 0) {
                            $scope.KEGOnchange(bidModel.KEGId);
                        }
                        // ***************    RR-536    END   ******************************//
                        //RR-545
                        $scope.Steps[1].step1[0].DocSource = bidModel.DocSource;
                        $scope.checkIfRfiSubmitted(ID);
                        $scope.getClientContracts($scope.selectedAgency.Id);

                        $scope.daysDifference($scope.Steps[1].step1[0].releaseDate, $scope.Steps[1].step1[0].submittalDate);
                        $scope.bidinfo.showmessage1 = false;
                        $scope.bidinfo.awardtoLoad = false;
                        $scope.currentRecordId = bidModel.Id;

                        //$scope.$broadcast("refershEvent", $scope.currentRecordId);
                        if (type == 'E') {
                            $scope.isEditing = true;
                            $scope.showView = false;
                            $scope.submissionPending = false;
                        }
                        else if (type == 'V') {
                            if ($scope.bnb == true) {
                                $scope.showView = false;
                            }
                            else {
                                if (!$scope.isEditing) {
                                    $scope.showView = true;
                                }
                            }
                        }
                        else if (type == 'D') {
                            var ans = confirm("Are you sure you want to remove this Bid ?");
                            if (ans) {
                                $scope.showView = false;
                                var indx = 0;
                                angular.forEach($scope.bidsIndex, function (value, indeX) {
                                    if (value.Id == id) { indx = indeX; }
                                })
                                $scope.bidsIndex.splice(indx, 1);
                                $http.delete('/Home/DeleteBid/' + ID).success(function (data) {
                                    ActivityService.assortedCalls().saveAllCalls(48);
                                    toaster.pop('success', 'Success', "Bid has been removed successfully!");
                                }).error(function (data) {
                                    toaster.pop('error', 'Error', " An Error has occurred while deleting Bid!");
                                    $scope.error = "An Error has occurred while deleting Bid! " + data;
                                });
                            }
                        }//RR-520
                        else if (type == 'R') {
                            $scope.showView = false;
                            var indx = 0;
                            angular.forEach($scope.bidsIndex, function (value, indeX) {
                                if (value.Id == id) { indx = indeX; }
                            })
                            $scope.bidsIndex.splice(indx, 1);
                            $http.delete('/Home/RestoreBid/' + ID).success(function (data) {
                                ActivityService.assortedCalls().saveAllCalls(48);
                                toaster.pop('success', 'Success', "Bid has been restored successfully!");
                            }).error(function (data) {
                                toaster.pop('error', 'Error', " An Error has occurred while restoring Bid!");
                                $scope.error = "An Error has occurred while restoring Bid! " + data;
                            });
                        }
                    }
                }
            }).error(function (data) {
                $scope.error = "An Error has occurred while loading Bid! " + data;
            });


            $http.get('/Home/getIdIQContract').success(function (data) {
                $scope.allIDIQContracts = data.data;
            });

            //Fetch history
            $scope.getHistory(ID);

            $scope.counter = $scope.counter + 1;

            //load bid comments
            $scope.loadcomments(ID);

            //load bid actions
            $scope.loadactions(ID);

            //load bid actionitems
            //$scope.loadactionitems(ID);  //moved to within loadactions

            //load bid news
            $scope.loadnews(ID);

            //load Bid Document
            //$scope.loaddocument(ID);

            //load bid resources
            //$scope.loadresources(ID);

            // load Partners
            $scope.loadPartners(ID);

            $scope.Partner.isadding = false;
            $scope.Partner.isediting = false;

            //load Bid Tracking changes
            $scope.loadBidTrackingItems(ID);

            //loadrating
            $scope.loadRating(ID);

            //IsBidTop5
            $scope.getTop5BidStatus(ID);
        };
        $scope.changeTab = function (name) {
            if (name == 'Writing') {
                $scope.writingflag = true;
                $rootScope.$broadcast("writingSectionEvent", $scope.currentRecordId);
                $scope.complianceflag = false;
            }
            else if (name == 'Scheduler') {
                $scope.fullCalendarFlag = true;
            }
            else if (name == 'Compliance') {
                $scope.complianceflag = true;
                $rootScope.$broadcast("complianceSectionEvent", $scope.currentRecordId);
            }
        }
        $scope.getTop5BidStatus = function (ID) {
            $http.get("/Home/isBidTop5?id=" + ID).success(function (data) {
                $scope.emoji = data.Icon;
            })
        }

        $scope.loadRating = function (ID) {
            $http.get("/Home/GetBidRating?id=" + ID).success(function (data) {
                $scope.BidRating = data.RatingLine;
                $scope.otherRatings = data.OtherLine;
                angular.forEach($scope.otherRatings, function (value, index) {
                    value.rating = JSON.parse(value.rating);
                })

                if ($scope.BidRating != null) {
                    $scope.ratings = JSON.parse($scope.BidRating.rating);
                    $scope.rating = $scope.BidRating.rate;
                    $scope.ratingId = $scope.BidRating.id;
                } else {
                    $scope.ratings = ["False", "False", "False", "False", "False"];
                    $scope.rating = 0;
                    $scope.ratingId = 0;
                }
            })
        }


        //RR-528 : POC mapped/UnMapped with Bid  
        $scope.pocCheckedUnchecked = function () {
            $scope.IsAllChecked = true;
            for (var i = 0; i < $scope.Steps[6].step6[0].PocDetails.length; i++) {
                if (!$scope.Steps[6].step6[0].PocDetails[i].IsBidMapped) {
                    $scope.IsAllChecked = false;
                    break;
                }
            };
        };

        $scope.pocMappedWithBid = function (pocData) {
            $scope.pocCheckedUnchecked();
            if (pocData.Id > 0) {
                var pocBidIdsArray = null;
                if (pocData.Bid_Id != null && pocData.Bid_Id != "") {
                    pocBidIdsArray = pocData.Bid_Id.split(',');
                }

                var pocBidIdsTemp = [];
                if (pocBidIdsArray.length > 1) {
                    if ((pocBidIdsArray != undefined || pocBidIdsArray != null) && pocBidIdsArray.length > 0) {
                        var isExist = false;
                        _.each(pocBidIdsArray, function (data) {
                            if (data != $scope.currentRecordId) {
                                pocBidIdsTemp.push(data);
                            }
                            else { isExist = true; }
                        });
                        if (!isExist) { pocBidIdsTemp.push($scope.currentRecordId); }
                    }
                    else {
                        pocBidIdsTemp.push($scope.currentRecordId);
                    }
                    pocData.Bid_Id = pocBidIdsTemp.join(',');
                    partnerService.updateBidIds(pocData).then(function (response) {
                        toaster.pop('success', 'Success', "Updated Link POC with Bid");
                        $scope.loadPartners($scope.currentRecordId);

                    }).catch(function (data) {
                        // Handle error here
                        toaster.pop('error', 'Error', "No data was update!");
                    });;
                }
            }
        };


        $scope.CheckUncheckAll = function () {
            for (var i = 0; i < $scope.Steps[6].step6[0].PocDetails.length; i++) {
                $scope.Steps[6].step6[0].PocDetails[i].IsBidMapped = $scope.IsAllChecked;
            }
        };


        $scope.selectedPartner = function (index) {
            //  var ID = id;
            $scope.Steps[6].step6[0].Id = $scope.partnerIndex[index].Id;
            $scope.Steps[6].step6[0].serviceProviderName = $scope.partnerIndex[index].PartnerName;
            $scope.Steps[6].step6[0].serviceProviderType = $scope.partnerIndex[index].PartnerType;
            $scope.Steps[6].step6[0].serviceProviderTypeId = $scope.partnerIndex[index].PartnerTypeId;
            //RR-446
            $scope.typeObj.PartnerTypeObj.Id = $scope.partnerIndex[index].PartnerTypeId;
            $scope.typeObj.PartnerTypeObj.Name = $scope.partnerIndex[index].PartnerType;

            $scope.Steps[6].step6[0].expirationDate = $scope.formatdate($scope.partnerIndex[index].ExpirationDate);
            $scope.Steps[6].step6[0].cage = $scope.partnerIndex[index].Cage;
            $scope.Steps[6].step6[0].isProviderActive = $scope.partnerIndex[index].isPartnerActive;
            $scope.Steps[6].step6[0].DUNS = $scope.partnerIndex[index].Duns;
            $scope.Steps[6].step6[0].DUNSPlus4 = $scope.partnerIndex[index].DunsPlus4;
            $scope.Steps[6].step6[0].street = $scope.partnerIndex[index].Street;
            $scope.Steps[6].step6[0].city = $scope.partnerIndex[index].City;
            $scope.Steps[6].step6[0].state = $scope.partnerIndex[index].State;
            $scope.Steps[6].step6[0].country = $scope.partnerIndex[index].Country;
            $scope.Steps[6].step6[0].zip = $scope.partnerIndex[index].Zip;
            $scope.Steps[6].step6[0].phone = $scope.partnerIndex[index].Phone;
            $scope.Steps[6].step6[0].serviceProviderContact = $scope.partnerIndex[index].ServiceProviderContact;
            $scope.Steps[6].step6[0].contactPhone = $scope.partnerIndex[index].ContactPhone;
            $scope.Steps[6].step6[0].contactEmail = $scope.partnerIndex[index].ContactEmail;
            $scope.Steps[6].step6[0].webSite = $scope.partnerIndex[index].WebSite;
            $scope.Steps[6].step6[0].poc = $scope.partnerIndex[index].POC;
            $scope.Steps[6].step6[0].POCEmail = $scope.partnerIndex[index].Email;
            $scope.Steps[6].step6[0].isDelinquentFederalDebt = $scope.partnerIndex[index].HasDelinquentFederalDebt;
            $scope.Steps[6].step6[0].isKnownExclusion = $scope.partnerIndex[index].isKnownExclusion;
            $scope.Steps[6].step6[0].WorkShare = $scope.partnerIndex[index].WorkShare;
            $scope.Steps[6].step6[0].PocDetails = $scope.partnerIndex[index].PocDetails;

            //RR-528
            debugger;
            $scope.Steps[6].step6[0].comments = $scope.partnerIndex[index].Comments;
            $scope.Steps[6].step6[0].coreCompetencies = $scope.partnerIndex[index].CoreCompetencies;

            $scope.tempObjs.CoreCompetencyObj = [];
            if ($scope.Steps[6].step6[0].coreCompetencies != null && $scope.Steps[6].step6[0].coreCompetencies != "") {
                var coreCompetenciesArray = $scope.Steps[6].step6[0].coreCompetencies.split(',');
                if (coreCompetenciesArray.length > 0) {
                    angular.forEach(coreCompetenciesArray, function (value, key) {
                        var coreCompetencySelectedObj = _.find($scope.coreCompetenciesDropDwn, function (obj) { return obj.Id == value });
                        if (coreCompetencySelectedObj != null) {
                            $scope.tempObjs.CoreCompetencyObj.push({ 'Id': coreCompetencySelectedObj.Id, 'Name': coreCompetencySelectedObj.Name });
                        }
                    });
                }
            }

            $scope.pocCheckedUnchecked();

        }

        //Bid score related functions
        //----------------------------------------------------------------

        // Sets the value of Our Stage
        //$scope.setBid = function (flag) {
        //     //
        //    if (!flag) {

        //    }

        //}

        //open modal for Bid/No-Bid Decision Questionnaire
        $scope.bnb = false
        $scope.open = function (index, id, flag) {
            $scope.bnb = true
            $scope.ScoreCalculation = false;
            if (!flag) {
                var objFormQ = this.Questionnaire;
                var objFormS = this.Sidebar;
                objFormQ.$setPristine();
                objFormS.$setPristine();
                $scope.showView = false;
                $scope.showPopup = true;
                $scope.currentBidRecord = angular.copy(bidInfoModel);

                var ID = id;

                //fetch the bid record from database
                $http.get('/api/Bids/' + ID).success(function (data) {
                    if (data.id == 0) {
                        toaster.pop('error', 'Error', "No data was fetched!");
                    } else {
                        bidModel = data;
                        $scope.currentBidRecord.Id = bidModel.Id;
                        $scope.currentBidRecord.Title = bidModel.Title;
                        $scope.currentBidRecord.OpportunityId = bidModel.OpportunityId;
                        $scope.currentBidRecord.Agency = bidModel.Agency;
                        $scope.currentBidRecord.Proposal_submittalDate = bidModel.Proposal_submittalDate;
                        $scope.currentBidRecord.Summary = bidModel.Summary;
                    }
                    $scope.bidNote = "";
                    if (bidModel.Bid_Decision) { $scope.isBidscorePass = true; } else { $scope.isBidscorePass = false; }
                })

                //fetch the saved bid score values from database
                $http.get('/api/Questionnaire_Response?moduleid=1&recordid=' + ID).success(function (data) {

                    if (data.length == 0) {
                        $scope.questionnaires_scores = [];
                        angular.forEach($scope.questionnaires, function (value1, index1) {
                            if (value1.ResponseType == 'yesno') {
                                value1.boolresp = false;
                            }
                            if (value1.ResponseType == 'text') {
                                value1.strresp = "";
                            }
                        })
                    } else {
                        $scope.questionnaires_scores = data;
                    }
                    angular.forEach($scope.questionnaires_scores, function (value, index) {
                        angular.forEach($scope.questionnaires, function (value1, index1) {
                            if (value1.Id == value.ModuleRecordId) {
                                if (value1.ResponseType == 'yesno') {
                                    if (value.Response == 'True') { value1.boolresp = true; } else { value1.boolresp = false; }

                                }
                                if (value1.ResponseType == 'text') {
                                    value1.strresp = value.Response;
                                }
                            }
                        })
                    })

                    $scope.calculateScore();
                })

                //fetch the saved bid score notes from database
                $http.get('/api/Comment_Bid_NoBid?moduleid=1&recordid=' + ID).success(function (data) {
                    $scope.score_notes = data;
                })
            }
            else {
                return false;
            }

        };

        //close modal of Bid/No-Bid Decision Questionnaire
        $scope.close = function () {
            $scope.showPopup = false;
            $scope.bnb = false;
        }

        //re calculate score from user selection
        $scope.calculateScore = function () {
            var total = 0.00;
            angular.forEach($scope.questionnaires, function (value, index) {
                if (value.ResponseType == "yesno") {
                    if (value.boolresp) { total = total + 1; }
                }
            })
            $scope.bidCalculatedScore = parseInt((total / $scope.total_yesno_questions) * 100);

            if ($scope.ScoreCalculation) {
                if ($scope.bidCalculatedScore >= $scope.passingBidscore) {
                    $scope.isBidscorePass = true;
                }
            }
            $scope.ScoreCalculation = true;
        }

        //save bid score and bid decision
        $scope.save = function () {
            $http.post('/api/Questionnaire_Response?moduleid=1&recordid=' + $scope.currentBidRecord.Id, $scope.questionnaires).success(function (data) {

                //update array with new Bid score
                var indx = -1;
                angular.forEach($scope.bidsIndex, function (value, indeX) {
                    if (value.Id == $scope.currentBidRecord.Id) { indx = indeX; }
                })

                //if matching row found in array
                if (indx != -1) {
                    $scope.bidsIndex[indx].Bid_Score = $scope.bidCalculatedScore;
                    $scope.bidsIndex[indx].Bid_Decision = $scope.isBidscorePass;
                }

                //if ($scope.Steps[1].step1[0].bidScore) { $scope.Steps[1].step1[0].bidScore = $scope.bidCalculatedScore; $scope.Steps[1].step1[0].Bid_Decision = $scope.isBidscorePass; }
                $scope.Steps[1].step1[0].bidScore = $scope.bidCalculatedScore;
                $scope.Steps[1].step1[0].Bid_Decision = $scope.isBidscorePass;

                //now update database
                //$scope.currentBidRecord.Bid_Score = $scope.bidCalculatedScore;
                //$scope.currentBidRecord.Bid_Decision = $scope.isBidscorePass;
                //$scope.bidsIndex[indx].Rigil_Stage = 11;
                //$scope.bidsIndex[indx].Bid_statusId = 42;
                $scope.currentBidRecord = $scope.bidsIndex[indx];

                $http.put('/api/Bids/' + $scope.currentBidRecord.Id, $scope.currentBidRecord).success(function (data) {
                    if (!$scope.isBidscorePass) {
                        //$scope.Steps[1].step1[0].rigilStage = 10;
                    }
                    else {
                        //$scope.Steps[1].step1[0].rigilStage = 11;
                        //$scope.Steps[1].step1[0].status = 42;

                        //if ($scope.Steps[1].step1[0].rigilStage == 10 || $scope.Steps[1].step1[0].rigilStage == 0) {
                        //    $scope.Steps[1].step1[0].rigilStage = 11;
                        //}
                    }
                }).error(function (data) {
                    $scope.error = "An Error has occurred while updating Bid! " + data;
                    $scope.loading = false;
                });

                if ($scope.bidNote.trim().length > 0) {
                    //update side details
                    var sideDetailObj = angular.copy(sideBidScoreModel);
                    sideDetailObj.Id = 0;
                    sideDetailObj.ModuleId = 1;
                    sideDetailObj.RecordId = $scope.currentBidRecord.Id;
                    sideDetailObj.UserId = "";
                    sideDetailObj.Comment_dateTime = "01/01/1900";
                    sideDetailObj.Prevailing_Score = $scope.bidCalculatedScore;
                    sideDetailObj.bid_Decision = $scope.isBidscorePass;
                    sideDetailObj.Comment = $scope.bidNote;
                    $http.post('/api/Comment_Bid_NoBid', sideDetailObj).success(function (data) {
                        //update side object comments array
                        $scope.score_notes.push(data);
                    })
                }
            })
        }

        //----------------------------------------------------------------

        //NAICS popup related functions
        //----------------------------------------------------------------

        //Open modal for NAICS codes multi selection
        $scope.openNAICS = function (index, id) {
            var objFormN = this.NAICSform;
            objFormN.$setPristine();
            $scope.currentPageNAICS = 0;
            $scope.startindexNAICS = 0;
            $scope.showView = false;
            $scope.showPopupNAICS = true;
            $scope.selectedNAICScodes = $scope.Steps[1].step1[0].bidStatus;
            if ($scope.Steps[1].step1[0].bidStatus.trim().length > 0) {
                angular.forEach($scope.NAICScodes, function (value, index) {
                    if ($scope.Steps[1].step1[0].bidStatus.search(value.NaicsCode) != -1) { value.isSelected = true; } else { value.isSelected = false; }
                })
            } else {
                angular.forEach($scope.NAICScodes, function (value, index) {
                    value.isSelected = false;                                    //initialize with unselected All
                })
            }
        }

        //Onclick of selection/de-selection of NAICS Code
        $scope.clickNAICS = function (index, code) {
            if ($scope.NAICScodes[index].isSelected) {
                var isSeparator = "";
                if ($scope.selectedNAICScodes.trim().length > 5) { isSeparator = ","; } else { isSeparator = ''; }

                $scope.selectedNAICScodes = $scope.selectedNAICScodes + isSeparator + code;
            } else {
                var toReplace = code + ",";
                var newCodes = $scope.selectedNAICScodes;

                if (newCodes.search(code + ",") != -1) {
                    newCodes = newCodes.replace(code + ",", '');     //if not last item then will have  comma after it
                } else if (newCodes.search("," + code) != -1) {
                    newCodes = newCodes.replace("," + code, '');      //if last item then won't have comma after it
                } else {
                    newCodes = newCodes.replace(code, '');          //if only item
                }

                $scope.selectedNAICScodes = newCodes;
            }
        }

        //close modal of NAICS selection
        $scope.closeNAICS = function () {
            $scope.Steps[1].step1[0].bidStatus = $scope.selectedNAICScodes;
            $scope.showPopupNAICS = false;
            var objForm = this.step1;
            objForm.Steps[1].step1[0].bidStatus.$setViewValue(objForm.Steps[1].step1[0].bidStatus.$viewValue);
        }

        //---------------------------------------------------------------


        //Comments Tab functions
        //---------------------------------------------------------------

        // Method to load comments related to selected Bid
        $scope.loadcomments = function (bidID) {
            $scope.commentsIndex = [];
            $http.get('/api/Bid_Comment/?bidID=' + bidID + "&dummy=1").success(function (data) {
                $scope.commentsIndex = data;
                $scope.commentCount = data.length;
            })
        }

        // New comment add button click
        $scope.newCommentAdd = function () {
            $scope.backup_comments = angular.copy($scope.commentsIndex);  //will be used in case of undo

            $scope.comment = angular.copy(commentObj);

            $scope.commentsIndex.push($scope.comment);
            $scope.comments.currentIndex = $scope.commentsIndex.length - 1;

            $scope.commentsIndex[$scope.comments.currentIndex].BidId = $scope.currentRecordId;
            $scope.commentsIndex[$scope.comments.currentIndex].Add = true;
            $scope.commentsIndex[$scope.comments.currentIndex].Id = 3000;
            $scope.commentsIndex[$scope.comments.currentIndex].Comment_dateTime = new Date();
        }

        //Actions Tab functions
        //---------------------------------------------------------------

        // Method to load actions related to selected Bid
        $scope.loadactions = function (bidID) {

            $scope.actionsIndex = [];
            $http.get('/api/Bid_Action/?bidID=' + bidID + "&dummy=1").success(function (data) {
                $scope.actionsIndex = data;
                $scope.actionCount = data.length;
                angular.forEach($scope.actionsIndex, function (value, index) {
                    //set the current pointer and render action on board
                    $scope.actions.currentIndex = index;
                    $scope.ActionUpdateInBoard();
                })

                //load bid actionitems
                $scope.loadactionitems(bidID);
            })
        }

        // New action add button click
        $scope.newActionAdd = function () {
            //
            $scope.backup_actions = angular.copy($scope.actionsIndex);  //will be used in case of undo

            $scope.action = angular.copy(actionObj);

            $scope.actionsIndex.push($scope.action);
            $scope.actions.currentIndex = $scope.actionsIndex.length - 1;

            $scope.actionsIndex[$scope.actions.currentIndex].BidId = $scope.currentRecordId;
            $scope.actionsIndex[$scope.actions.currentIndex].Add = true;
            $scope.actionsIndex[$scope.actions.currentIndex].Id = 3000;
            $scope.actionsIndex[$scope.actions.currentIndex].Action_Title = $scope.ACTION.actionTitle;
            $scope.actionsIndex[$scope.actions.currentIndex].Action_takenLastWeek = $scope.ACTION.actionText;
            $scope.actionsIndex[$scope.actions.currentIndex].UserId = $scope.ACTION.assignees.toString();
            $scope.actionsIndex[$scope.actions.currentIndex].Action_dateTime = new Date();
            $scope.actionsIndex[$scope.actions.currentIndex].DueDate = $scope.formatdate($scope.ACTION.actionDueDate);//559
            $scope.actionsIndex[$scope.actions.currentIndex].Comments = $scope.ACTION.actionStatus;


            //RR-537
            $scope.actionsIndex[$scope.actions.currentIndex].AssignedBy = $scope.ACTION.assignedBy;
        }

        // Update Action in Task Board
        $scope.ActionUpdateInBoard = function () {

            $scope.newactionObjJUI = angular.copy(actionObjUI);


            $scope.newactionObjJUI = {
                bidId: $scope.actionsIndex[$scope.actions.currentIndex].BidId,
                id: $scope.actionsIndex[$scope.actions.currentIndex].Id,
                action_title: $scope.actionsIndex[$scope.actions.currentIndex].Action_Title,
                action: $scope.actionsIndex[$scope.actions.currentIndex].Action_takenLastWeek,
                comment: $scope.actionsIndex[$scope.actions.currentIndex].Comments,
                dueDate: $scope.formatdate($scope.actionsIndex[$scope.actions.currentIndex].DueDate),  //RR-559
                users: $scope.actionsIndex[$scope.actions.currentIndex].UserId.split(','),
                assignedBy: $scope.actionsIndex[$scope.actions.currentIndex].AssignedBy, //RR-537
                actionItems: [],
                inprogressItems: [],
                doneItems: []
            }
            $scope.task_Actions.push($scope.newactionObjJUI);
        }

        $scope.getMeActionIndex = function (actionId) {
            var indx = 0;
            angular.forEach($scope.actionsIndex, function (value, index) {
                if (value.Id == actionId) { indx = index; }
            })
            return indx;
        }

        //Actions Items Tab functions
        //---------------------------------------------------------------

        // Method to load actionitems related to selected Bid
        $scope.loadactionitems = function (bidID) {
            $scope.actionitemsIndex = [];
            $http.get('/api/Bid_ActionItem/?bidID=' + bidID + "&dummy=1").success(function (data) {
                $scope.actionitemsIndex = data;
                $scope.actionitemsCount = data.length;
                //
                //attach action items to actions in task board
                angular.forEach($scope.actionitemsIndex, function (value, index) {
                    if (value.ActionId > 0) {
                        $scope.actionitems.currentIndex = index;
                        //$scope.actions.currentIndex = $scope.getMeActionIndex(value.ActionId);
                        $scope.ActionItemUpdateInBoard();
                    }
                })

            })
        }


        // New action items add button click
        $scope.newActionItemAdd = function () {
            $scope.backup_actionitems = angular.copy($scope.actionitemsIndex);  //will be used in case of undo

            $scope.actionitem = angular.copy(actionitemObj);

            $scope.actionitemsIndex.push($scope.actionitem);
            $scope.actionitems.currentIndex = $scope.actionitemsIndex.length - 1;

            $scope.actionitemsIndex[$scope.actionitems.currentIndex].BidId = $scope.currentRecordId;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionId = $scope.actions.currentId;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem_Title = $scope.ACTIONITEM.actionTitle;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem = $scope.ACTIONITEM.actionText;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].By_userId = $scope.ACTIONITEM.assignees.toString();
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Actionable_Actioned = false;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Add = true;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Id = 3000;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Action_dateTime = new Date();
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Start_From = $scope.ACTIONITEM.StartDate;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionDue_dateTime = $scope.formatdate($scope.ACTIONITEM.actionDueDate);  //RR-559
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionDue_TimeOnlyDT = $scope.ACTIONITEM.actionDueTime;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ReminderDate_dateTime = $scope.ACTIONITEM.reminderDate;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Snooze_times = 0;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Snooze_history = '';
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem_Status = 0;    //ToDo=0, In-Progresss=1, Done=2
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].IsMilestone = $scope.ACTIONITEM.isMilestone;
            $scope.actionitemsIndex[$scope.actionitems.currentIndex].pc_complete = $scope.ACTIONITEM.pcComplete;
        }

        // Update ActionItem in Task Board
        $scope.ActionItemUpdateInBoard = function () {
            $scope.newactionitemObjJUI = angular.copy(actionitemObjUI);
            $scope.newactionitemObjJUI = {
                bidId: $scope.actionitemsIndex[$scope.actionitems.currentIndex].BidId,
                actionId: $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionId,
                id: $scope.actionitemsIndex[$scope.actionitems.currentIndex].Id,
                actionitem_title: $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem_Title,
                Item: $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem,
                startDate: $scope.actionitemsIndex[$scope.actionitems.currentIndex].Start_From,
                dueDate: $scope.formatdate($scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionDue_dateTime), //TOTO
                dueTime: $scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionDue_TimeOnlyDT,
                reminderDate: $scope.actionitemsIndex[$scope.actionitems.currentIndex].ReminderDate_dateTime,
                users: $scope.actionitemsIndex[$scope.actionitems.currentIndex].By_userId.split(','),
                snoozeTimes: $scope.actionitemsIndex[$scope.actionitems.currentIndex].Snooze_times,
                isMilestone: $scope.actionitemsIndex[$scope.actionitems.currentIndex].IsMilestone,
                pccomplete: $scope.actionitemsIndex[$scope.actionitems.currentIndex].pc_complete,
                assignedBy: $scope.actionitemsIndex[$scope.actionitems.currentIndex].AssignedBy,
            }
            $scope.actions.currentIndex = $scope.getMeActionIndex($scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionId);



            if ($scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem_Status == 0) { $scope.task_Actions[$scope.actions.currentIndex].actionItems.push($scope.newactionitemObjJUI); }
            else if ($scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem_Status == 1) { $scope.task_Actions[$scope.actions.currentIndex].inprogressItems.push($scope.newactionitemObjJUI); }
            else if ($scope.actionitemsIndex[$scope.actionitems.currentIndex].ActionItem_Status == 2) { $scope.task_Actions[$scope.actions.currentIndex].doneItems.push($scope.newactionitemObjJUI); }
            else { }
        }

        //Latest News Tab functions
        //---------------------------------------------------------------

        // Method to load news related to selected Bid
        $scope.loadnews = function (bidID) {
            $scope.newsIndex = [];
            $http.get('/api/Bid_News/?bidID=' + bidID + "&dummy=1").success(function (data) {
                $scope.newsIndex = data;
                $scope.newsCount = data.length;
                $scope.loaddocument(bidID);
            })
        }

        // New news item add button click
        $scope.newNewsAdd = function () {

            $scope.backup_news = angular.copy($scope.newsIndex);  //will be used in case of undo

            $scope.News = angular.copy(newsObj);

            $scope.newsIndex.push($scope.News);
            $scope.neWs.currentIndex = $scope.newsIndex.length - 1;

            $scope.newsIndex[$scope.neWs.currentIndex].BidId = $scope.currentRecordId;
            $scope.newsIndex[$scope.neWs.currentIndex].Add = true;
            $scope.newsIndex[$scope.neWs.currentIndex].Id = 3000;
            $scope.newsIndex[$scope.neWs.currentIndex].News_dateTime = new Date();
        }

        //----------------------------------------------------------------

        //General method to edit an existing record (for Comment / Action / Action Items / News)
        $scope.editoldInstance = function (Id, RecordType) {
            switch (RecordType) {
                case 'Comment':
                    $scope.backup_comments = angular.copy($scope.commentsIndex);  //will be used in case of undo

                    angular.forEach($scope.commentsIndex, function (value, index) {
                        if (value.Id == Id) { value.Edit = true; $scope.comment = value; }
                    })
                    break;

                case 'Action':
                    $scope.backup_actions = angular.copy($scope.actionsIndex);  //will be used in case of undo
                    angular.forEach($scope.actionsIndex, function (value, index) {
                        if (value.Id == Id) {
                            value.Edit = true;
                            $scope.action = value;
                        }
                    })
                    break;
                case 'Actionitem':
                    $scope.backup_actionitems = angular.copy($scope.actionitemsIndex);  //will be used in case of undo

                    angular.forEach($scope.actionitemsIndex, function (value, index) {
                        if (value.Id == Id) { value.Edit = true; $scope.actionitem = value; }
                    })
                    break;
                case 'News':
                    $scope.backup_news = angular.copy($scope.newsIndex);  //will be used in case of undo
                    angular.forEach($scope.newsIndex, function (value, index) {
                        if (value.Id == Id) { value.Edit = true; $scope.News = value; $scope.neWs.currentIndex = value.Id; }
                    })
                    break;

                case 'Document':
                    $scope.backup_document = angular.copy($scope.documentIndex);  //will be used in case of undo
                    angular.forEach($scope.documentIndex, function (value, index) {
                        if (value.Id == Id) { value.Edit = true; $scope.document = value; $scope.library.currentIndex = value.Id; }
                    })
                    break;

                case 'Partner':
                    angular.forEach($scope.partnerIndex, function (value, index) {
                        if (value.Id == Id) { value.Edit = true; $scope.partners = value; }
                    })
                    break;
                default:
            }
        }

        //upload attachment
        $scope.uploadAttachment1 = function () {
            if ($("#pUpload").val() == "") { toaster.pop('error', 'Error', "Select an image to upload..."); return false; }
            $scope.isAttachmentUploading = true;
            var fileUpload = $("#pUpload").get(0);
            var files = fileUpload.files;
            var test = new FormData();
            for (var i = 0; i < files.length; i++) {
                test.append(files[i].name, files[i]);
            }
            $.ajax({
                async: true,
                url: "fileUploader.ashx",
                type: "POST",
                contentType: false,
                processData: false,
                data: test,
                // dataType: "json",
                success: function (result) {
                    if (result.substring(0, 7) == "Success") {

                        var newImgModel = {
                            Id: 0,
                            ticketId: 0,
                            ImagePath: result.substring(8)
                        }
                        $("#ContrUpload").val("");
                        $scope.attachments.push(newImgModel);
                        $scope.isAttachmentUploading = false;
                        $scope.$apply();

                        $window.localStorage.setItem('attachmentName', result.substring(8));

                        angular.forEach($scope.newsIndex, function (value, index) {
                            if (value.Id == $scope.bidResearchid) { value.UploadFile = result.substring(8); }
                        })
                    } else {
                        toaster.pop('error', 'Error', "Upload failed. Another image with same name exists!");
                    }
                },
                error: function (err) {
                    toaster.pop('error', 'Error', "Error occured!");
                }
            });

        };

        //upload any document
        $scope.uploadLibraryDocument = function (files, subModule) {
            if (files[0].size > 12000000) {
                toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                if (subModule == 'Research') { $("#document" + subModuleId).val(""); }
                if (subModule == 'Library') { $("#documentL" + subModuleId).val(""); }
                return false;
            }
            var filename = files[0].name;
            filename = filename.toLowerCase();
            if (filename.includes(".jpg") || filename.includes(".jpeg") || filename.includes(".bmp") || filename.includes(".png") ||
                 filename.includes(".pdf") || filename.includes(".txt") || filename.includes(".doc") || filename.includes(".docx") || filename.includes(".xls") ||
                 filename.includes(".xlsx") || filename.includes(".ppt") || filename.includes(".pptx") || filename.includes(".html")) {
                $scope.isAttachmentUploading = true;
                var subModuleId = "";
                if (subModule == 'Research') { subModuleId = $scope.neWs.currentIndex; }
                if (subModule == 'Library') { subModuleId = $scope.library.currentIndex; }
                var fd = new FormData();
                //Take the first selected file
                fd.append("file", files[0]);

                $http.post("/api/Library/Resource?module=Bid&moduleId=" + $scope.currentRecordId + "&subModule=" + subModule + "&subModuleId=" + subModuleId, fd, {
                    withCredentials: true,
                    headers: { 'Content-Type': undefined },
                    transformRequest: angular.identity
                }).success(function (data) {
                    if (subModule == 'Research') { $("#document" + subModuleId).val(""); }
                    if (subModule == 'Library') { $("#documentL" + subModuleId).val(""); }
                    $scope.isAttachmentUploading = false;

                    if (subModule == 'Research') {
                        angular.forEach($scope.newsIndex, function (valueN, indexN) {
                            if (valueN.docs == null) { valueN.docs = []; }
                            if (valueN.Id == $scope.neWs.currentIndex) { valueN.docs.push(data[0]); }
                        })
                    }
                    if (subModule == 'Library') {
                        angular.forEach($scope.documentIndex, function (valueD, indexD) {
                            if (valueD.docs == null) { valueD.docs = []; }
                            if (valueD.Id == $scope.library.currentIndex) { valueD.docs.push(data[0]); }
                        })
                    }
                }
                ).error(function (data) {
                    toaster.pop('error', 'Error', "Error Occured!");
                }
                );
            }
            else {
                if (subModule == 'Research') { $("#document" + subModuleId).val(""); }
                if (subModule == 'Library') { $("#documentL" + subModuleId).val(""); }
                toaster.pop('error', 'Error', "Valid file types are: jpg/jpeg/bmp/png/pdf/txt/doc/docx/xls/xlsx/ppt/pptx/html!");
            };


        };


        $scope.deleteAttachmentA = function (id, researchid) {

            var ans = confirm("Are you sure you want to delete?");
            if (ans) {
                $http.delete("/api/Library/Resource/" + id).success(function (data) {
                    var indx = 0;

                    angular.forEach($scope.newsIndex, function (value, index) {

                        if (value.Id == researchid) {

                            angular.forEach(value.docs, function (valueN, indexN) {

                                if (valueN.fileId == id) {

                                    indx = indexN;
                                    value.docs.splice(indx, 1);
                                }

                            })
                        }

                    })
                });
            }
        }

        $scope.deleteAttachmentL = function (id, libraryid) {

            var ans = confirm("Are you sure you want to delete?");
            if (ans) {
                $http.delete("/api/Library/Resource/" + id).success(function (data) {
                    var indx = 0;

                    angular.forEach($scope.documentIndex, function (value, index) {

                        if (value.Id == libraryid) {

                            angular.forEach(value.docs, function (valueN, indexN) {

                                if (valueN.fileId == id) {

                                    indx = indexN;
                                    value.docs.splice(indx, 1);
                                }

                            })
                        }

                    })
                });
            }
        }


        // $scope.modalInstance1 = ''
        $scope.openUpload = function (id) {
            $scope.bidResearchid = id;
            $scope.$modalInstance1 = $modal.open({
                scope: $scope,
                templateUrl: 'tpl/uploadModal.html',
                controller: 'bidTracking'
            })
        };

        $scope.ok = function () {
            $scope.$modalInstance1.close();
        };

        // Comment Modal
        $scope.openCommentModal = function (boolval) {
            if (boolval && !$scope.bids.adding) {
                $scope.$commentModalInstance = $modal.open({
                    scope: $scope,
                    templateUrl: 'tpl/commentModal.html',
                    controller: 'bidTrackingCommentModal'
                })
            }
        };

        //Win or Lose Status Check

        $scope.chkStatus = function (stage, status) {
            if (stage == 3) {
                if (status == 14)
                    $scope.openWinModal()
                if (status == 15)
                    $scope.openLoseModal()
            }
        };

        //win modal

        $scope.openWinModal = function () {
            $scope.$winModalInstance = $modal.open({
                scope: $scope,
                templateUrl: 'tpl/winModal.html',
                controller: 'bidTrackingWinModal'
            })
        };

        $scope.closeWin = function () {
            $scope.$winModalInstance.close();
        };

        //Lose Modal

        $scope.openLoseModal = function () {
            $scope.$loseModalInstance = $modal.open({
                scope: $scope,
                templateUrl: 'tpl/loseModal.html',
                controller: 'bidTrackingLoseModal'
            })
        };

        $scope.closeLose = function () {
            $scope.$loseModalInstance.close();
        };



        //General method to save an existing record (for Comment / Action / Action Items / Research / Document)

        $scope.saveInstance = function (Id, RecordType) {

            switch (RecordType) {
                case 'Comment':
                    if ($scope.comments.isadding)    //i.e. new addition
                    {
                        $http.post('/api/Bid_Comment', $scope.comment).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(49);
                            $scope.commentsIndex[$scope.comments.currentIndex] = data;
                            $scope.commentsIndex[$scope.comments.currentIndex].Add = false;
                            $scope.commentsIndex[$scope.comments.currentIndex].Edit = false;
                            $scope.comments.isadding = false;
                            toaster.pop('success', 'Success', "Comment added Successfully");

                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while adding comment");
                        })
                    }
                    if ($scope.comments.isediting)    //i.e. existing modification
                    {
                        $http.put('/api/Bid_Comment?id=' + Id, $scope.comment).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(50);

                            angular.forEach($scope.commentsIndex, function (value, index) {
                                if (value.Id == Id) {
                                    value.Add = false;
                                    value.Edit = false;
                                }
                            })
                            $scope.comments.isediting = false;
                            toaster.pop('success', 'Success', "Comment updated Successfully");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while updating comment");
                        });
                    }
                    break;

                case 'Action':
                    if ($scope.actions.isadding)    //i.e. new addition
                    {

                        $scope.action.DueDate = $scope.formatdate($scope.action.DueDate);// 559

                        $http.post('/api/Bid_Action', $scope.action).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(52);

                            $scope.actionsIndex[$scope.actions.currentIndex] = data;
                            $scope.actionsIndex[$scope.actions.currentIndex].Add = false;
                            $scope.actionsIndex[$scope.actions.currentIndex].Edit = false;
                            $scope.actions.isadding = false;

                            $scope.actions.currentId = data.Id;
                            var emailHeader = "New Task";
                            //update action board
                            $scope.ActionUpdateInBoard();
                            toaster.pop('success', 'Success', "Action added Successfully");
                            //send email
                            $http.post('/Home/SendTaskEmail?TaskType=A&Id=' + $scope.actions.currentId + '&NewOld=' + emailHeader).success(function (data) {
                            });
                            $scope.isShowWaitingIcon = false;
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while adding Action!");
                        });
                    }
                    if ($scope.actions.isediting)    //i.e. existing modification
                    {
                        //RR-537
                        $scope.action.assignedBy = $scope.app.permissions.USERNAME;
                        $scope.ACTION.assignedBy = $scope.app.permissions.USERNAME;

                        $scope.action.DueDate = $scope.formatdate($scope.action.DueDate);//559

                        $http.put('/api/Bid_Action?id=' + Id, $scope.action).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(53);
                            angular.forEach($scope.actionsIndex, function (value, index) {
                                if (value.Id == Id) { value = data; value.Add = false; value.Edit = false; }
                            })
                            $scope.actions.isediting = false;
                            $scope.actions.currentId = Id;
                            var emailHeader = "Task Update";

                            //update the board
                            for (i = 0; i < $scope.task_Actions.length; i++) {
                                if ($scope.task_Actions[i].id == $scope.actions.currentId) {
                                    $scope.task_Actions[i].action_title = $scope.ACTION.actionTitle;
                                    $scope.task_Actions[i].action = $scope.ACTION.actionText;
                                    $scope.task_Actions[i].comment = $scope.ACTION.actionStatus;
                                    $scope.task_Actions[i].dueDate = $scope.ACTION.actionDueDate; //RR-559
                                    $scope.task_Actions[i].users = $scope.ACTION.assignees;
                                    //RR-537  
                                    $scope.task_Actions[i].assignedBy = $scope.ACTION.assignedBy;


                                }
                            }
                            $scope.isShowWaitingIcon = false;
                            toaster.pop('success', 'Success', "Action updated Successfully");

                            //send email
                            $http.post('/Home/SendTaskEmail?TaskType=A&Id=' + $scope.actions.currentId + '&NewOld=' + emailHeader).success(function (data) {
                            });
                        })
                        .error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while updating Action!");
                        });
                    }

                    break;
                case 'Actionitem':
                    if ($scope.actionitems.isadding)    //i.e. new addition
                    {
                        $http.post('/api/Bid_ActionItem', $scope.actionitem).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(55);

                            data.startDate = $scope.formatdate(data.actionStartDate);
                            data.dueDate = $scope.formatdate(data.actionDueDate);
                            data.reminderDate = $scope.formatdate(data.reminderDate);

                            $scope.actionitemsIndex[$scope.actionitems.currentIndex] = data;
                            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Add = false;
                            $scope.actionitemsIndex[$scope.actionitems.currentIndex].Edit = false;

                            $scope.actionitems.isadding = false;
                            var emailHeader = "New Task Assignment";

                            // update action item in board
                            $scope.ActionItemUpdateInBoard();
                            toaster.pop('success', 'Success', "Action Item added Successfully");
                            //send email
                            $http.post('/Home/SendTaskEmail?TaskType=AI&Id=' + data.Id + '&NewOld=' + emailHeader).success(function (data) {
                            });
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while adding Action Item!");
                        });
                    }
                    if ($scope.actionitems.isediting)    //i.e. existing modification
                    {
                        //RR-537
                        $scope.actionitem.assignedBy = $scope.app.permissions.USERNAME;
                        $scope.ACTIONITEM.assignedBy = $scope.app.permissions.USERNAME;

                        $http.put('/api/Bid_ActionItem?id=' + Id, $scope.actionitem).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(56);
                            angular.forEach($scope.actionitemsIndex, function (value, index) {
                                if (value.Id == Id) { value.Add = false; value.Edit = false; }
                            })

                            $scope.actionitems.isediting = false;
                            var emailHeader = "Task Assignment Update";

                            //update the board

                            if ($scope.ACTIONITEM.actionText) {
                                for (i = 0; i < $scope.task_Actions.length; i++) {
                                    if ($scope.task_Actions[i].id == $scope.actionitem.ActionId) {
                                        for (j = 0; j < $scope.task_Actions[i].actionItems.length; j++) {
                                            if ($scope.task_Actions[i].actionItems[j].id == Id) {
                                                $scope.task_Actions[i].actionItems[j].actionitem_title = $scope.ACTIONITEM.actionTitle;
                                                $scope.task_Actions[i].actionItems[j].Item = $scope.ACTIONITEM.actionText;
                                                $scope.task_Actions[i].actionItems[j].startDate = $scope.formatdate($scope.ACTIONITEM.actionStartDate);
                                                $scope.task_Actions[i].actionItems[j].dueDate = $scope.formatdate($scope.ACTIONITEM.actionDueDate);
                                                $scope.task_Actions[i].actionItems[j].dueTime = $scope.ACTIONITEM.actionDueTime;
                                                $scope.task_Actions[i].actionItems[j].reminderDate = $scope.formatdate($scope.ACTIONITEM.reminderDate);
                                                $scope.task_Actions[i].actionItems[j].users = $scope.ACTIONITEM.assignees;
                                                $scope.task_Actions[i].actionItems[j].isMilestone = $scope.ACTIONITEM.isMilestone;
                                                $scope.task_Actions[i].actionItems[j].pccomplete = $scope.ACTIONITEM.pcComplete;
                                                //RR-537 TODO 
                                                $scope.task_Actions[i].actionItems[j].assignedBy = $scope.ACTIONITEM.assignedBy;
                                            }
                                        }
                                    }
                                }
                            }
                            toaster.pop('success', 'Success', "Action Item updated Successfully");
                            //send email
                            $http.post('/Home/SendTaskEmail?TaskType=AI&Id=' + Id + '&NewOld=' + emailHeader).success(function (data) {
                            });

                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while updating Action Item!");
                        });
                    }
                    break;
                case 'News':
                    if ($scope.neWs.isadding)    //i.e. new addition
                    {
                        $http.post('/api/Bid_News', $scope.News).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(58);
                            $scope.newsIndex[$scope.neWs.currentIndex] = data;
                            $scope.AddNewsModal(data.Id, $scope.neWs.currentIndex);
                            toaster.pop('success', 'Success', "Research added Successfully");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while adding Research!");
                        });
                    }
                    if ($scope.neWs.isediting)    //i.e. existing modification
                    {
                        $scope.News.UploadFile = $window.localStorage.getItem('attachmentName');

                        $http.put('/api/Bid_News?id=' + Id, $scope.News).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(59);
                            angular.forEach($scope.newsIndex, function (value, index) {
                                if (value.Id == Id) { value.Add = false; value.Edit = false; value.UploadFile = $scope.ImagePathU; }
                            })
                            $scope.neWs.isediting = false;
                            toaster.pop('success', 'Success', "Research updated Successfully");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while updating Research!");
                        });
                    }
                    break;
                case 'Document':
                    if ($scope.library.isadding)    //i.e. new addition
                    {
                        $http.post('/api/Bid_Library', $scope.document).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(61);
                            $scope.documentIndex[$scope.library.currentIndex] = data;
                            $scope.AddLibraryModal(data.Id, $scope.library.currentIndex);
                            toaster.pop('success', 'Success', "Library added Successfully");

                        })
                        .error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while adding Library!");
                        });
                    }
                    if ($scope.library.isediting)    //i.e. existing modification
                    {
                        $scope.document.UploadFile = $window.localStorage.getItem('attachmentName');

                        $http.put('/api/Bid_Library?id=' + Id, $scope.document).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(62);
                            angular.forEach($scope.documentIndex, function (value, index) {
                                if (value.Id == Id) { value.Add = false; value.Edit = false; value.UploadFile = $scope.ImagePathU; }
                            })
                            $scope.library.isediting = false;
                            toaster.pop('success', 'Success', "Library updated Successfully");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while updating Library!");
                        });
                    }
                    break;
                default:
            }
        }

        //General method to delete an existing record (for Comment / Action / Action Items / Research / Document)

        $scope.deleteInstance = function (Id, RecordType) {
            //
            switch (RecordType) {
                case 'Comment':
                    var ans = confirm("Are you sure you want to delete this comment?");
                    if (ans) {
                        var indx = 0;
                        angular.forEach($scope.commentsIndex, function (value, index) {
                            if (value.Id == Id) { indx = index; }
                        })
                        $scope.commentsIndex.splice(indx, 1);

                        $http.delete('/api/Bid_Comment?id=' + Id).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(51);
                            toaster.pop('success', 'Success', " Comment deleted successfully!");
                        })
                        .error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while deleting Comment!");
                        });
                    }
                    break;

                case 'Action':
                    var ans = confirm("Are you sure you want to delete this Action?");
                    if (ans) {
                        var indx = 0;
                        $scope.isdeletionConfirmed = true;
                        angular.forEach($scope.actionsIndex, function (value, index) {
                            if (value.Id == Id) { indx = index; }
                        })
                        $scope.actionsIndex.splice(indx, 1);

                        $http.delete('/api/Bid_Action?id=' + Id).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(54);
                            toaster.pop('success', 'Success', "Bid Action deleted successfully!");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while deleting Bid Action!");
                        });
                    }
                    else {
                        $scope.isdeletionConfirmed = false;
                    }
                    break;
                case 'Actionitem':
                    var ans = confirm("Are you sure you want to delete this Action Item?");
                    if (ans) {
                        var indx = 0;
                        $scope.isdeletionConfirmed = true;
                        angular.forEach($scope.actionitemsIndex, function (value, index) {
                            if (value.Id == Id) { indx = index; }
                        })
                        $scope.actionitemsIndex.splice(indx, 1);

                        $http.delete('/api/Bid_ActionItem?id=' + Id).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(57);
                            toaster.pop('success', 'Success', "Bid Action Item deleted successfully!");
                        })
                        .error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while deleting Bid Action Item!");
                        });
                    } else {
                        $scope.isdeletionConfirmed = false;
                    }
                    break;
                case 'News':
                    var ans = confirm("Are you sure you want to delete this Research?");
                    if (ans) {
                        var indx = 0;
                        angular.forEach($scope.newsIndex, function (value, index) {
                            if (value.Id == Id) { indx = index; }
                        })
                        $scope.newsIndex.splice(indx, 1);

                        $http.delete('/api/Bid_News?id=' + Id).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(60);
                            toaster.pop('success', 'Success', " Bid Research deleted successfully!");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while deleting Research!");
                        });
                    }
                    break;
                case 'Document':
                    var ans = confirm("Are you sure you want to delete this Document?");
                    if (ans) {
                        var indx = 0;
                        angular.forEach($scope.documentIndex, function (value, index) {
                            if (value.Id == Id) { indx = index; }
                        })
                        $scope.documentIndex.splice(indx, 1);

                        $http.delete('/api/Bid_Library?id=' + Id).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(63);
                            toaster.pop('success', 'Success', "Bid Library deleted successfully!");
                        }).error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while deleting Library!");
                        });
                    }
                    break;
                default:
            }
        }

        //General method to undo a record (for Comment / Action / Action Items / News)

        $scope.cancelInstance = function (Id, RecordType) {
            switch (RecordType) {
                case 'Comment':
                    $scope.comments.isadding = false;
                    $scope.comments.isediting = false;
                    $scope.commentsIndex = angular.copy($scope.backup_comments);  //restore from backup

                    angular.forEach($scope.commentsIndex, function (value, index) {
                        if (value.Id == Id) { value.Add = false; value.Edit = false; }
                    })
                    break;
                case 'Action':
                    $scope.actions.isadding = false;
                    $scope.actions.isediting = false;
                    $scope.actionsIndex = angular.copy($scope.backup_actions);  //restore from backup

                    angular.forEach($scope.actionsIndex, function (value, index) {
                        if (value.Id == Id) { value.Add = false; value.Edit = false; }
                    })
                    break;
                case 'Actionitem':
                    $scope.actionitems.isadding = false;
                    $scope.actionitems.isediting = false;
                    $scope.actionitemsIndex = angular.copy($scope.backup_actionitems);  //restore from backup

                    angular.forEach($scope.actionitemsIndex, function (value, index) {
                        if (value.Id == Id) { value.Add = false; value.Edit = false; }
                    })
                    break;
                case 'News':
                    $scope.neWs.isadding = false;
                    $scope.neWs.isediting = false;
                    var docs = [];
                    angular.forEach($scope.newsIndex, function (value, index) {
                        if (value.Id == Id) {
                            value.Add = false; value.Edit = false;
                            docs = value.docs;
                        }
                    })
                    $scope.newsIndex = angular.copy($scope.backup_news);  //restore from backup

                    angular.forEach($scope.newsIndex, function (value, index) {
                        if (value.Id == Id) {
                            value.Add = false; value.Edit = false;
                            value.docs = docs;
                        }
                    })
                    break;
                case 'Document':
                    $scope.library.isadding = false;
                    $scope.library.isediting = false;
                    var docs1 = [];
                    angular.forEach($scope.documentIndex, function (value, index) {
                        if (value.Id == Id) {
                            value.Add = false; value.Edit = false;
                            docs1 = value.docs;
                        }
                    })
                    $scope.documentIndex = angular.copy($scope.backup_document);  //restore from backup

                    angular.forEach($scope.documentIndex, function (value, index) {
                        if (value.Id == Id) {
                            value.Add = false; value.Edit = false;
                            value.docs = docs1;
                        }
                    })
                    break;
                default:

            }
        }



        $scope.clickForMore = function (comments) {
            $scope.comments = comments;
        };

        //derive from Office selection
        $scope.setcodeO = function (selection) {
            $scope.Steps[1].step1[0].agencyOffice = selection.OfficeName;
            $scope.selectedOffice = selection;
        };
        //derive from Agency selection
        $scope.setcodeA = function (selection) {
            $scope.Steps[1].step1[0].departmentAgency = selection.Agencyname;
            $scope.selectedAgency = selection;
            $http.get('/api/Offices?agencyId=' + selection.Id).success(function (data) {
                if (data != null && data != "") {
                    $scope.offices = data;
                }
            })
             .error(function () {
                 $scope.error = "An Error has occurred while loading Offices!";
             })

        };
        //derive from Department selection
        $scope.setcodeD = function (selection) {
            $scope.Steps[1].step1[0].departmentName = selection.Agencyname;
            $scope.selectedDept = selection;
            //get the Agency/agencies according to the department Dropdown selection
            $http.get('/Home/GetAgencies?departmentId=' + selection.Id).success(function (data) {
                $scope.agencies = data.agencyList;
            })
        };

        $scope.getAgency = function () {
            var id = $scope.Steps[1].step1[0].departmentName;
            $http.get('/Home/GetInfoAgency?id=' + id).success(function (data) {
                $scope.selectedDept = data.agency;
            });
            //get the Agency/agencies according to the department Dropdown selection
            $http.get('/Home/GetAgencies?departmentId=' + id).success(function (data) {
                if (data.length == 0) {
                    $scope.agencies = [];
                }
                else {
                    $scope.agencies = data.agencyList;
                }
                $scope.Steps[1].step1[0].departmentAgency = "";
            })
        };

        $scope.getOffice = function () {
            var id = $scope.Steps[1].step1[0].departmentAgency;
            $http.get('/Home/GetInfoAgency?id=' + id).success(function (data) {
                $scope.selectedAgency = data.agency;
            });
            $http.get('/api/Offices?agencyId=' + id).success(function (data) {
                if (data != null && data != "") {
                    $scope.offices = data;
                }
                else {
                    $scope.offices = [];
                }
            })
             .error(function () {
                 $scope.error = "An Error has occurred while loading Offices!";
             })

        };
        $scope.linkModelFunc = function (url) {
            $window.open(url);
        }
        //download the div of View Topic as PDF with filename being the Topic name
        $scope.downloadTopicPDF = function () {
            var filename = $scope.Steps[1].step1[0].bidTitle + ".pdf";
            html2canvas(document.getElementById('ExportThis'), {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500,
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download(filename);
                }
            });
        }
        //download the div of View Topic as DOCX with filename being the Topic name
        $scope.downloadTopicDOC = function () {
            var filename = $scope.Steps[1].step1[0].bidTitle + ".doc";
            var elHtml = document.getElementById('ExportThis').innerHTML;
            var link = document.createElement('a');
            link.setAttribute('download', filename);
            link.setAttribute('href', 'data:' + 'text/doc' + ';charset=utf-8,' + encodeURIComponent(elHtml));
            link.click();
        }
        //print the div for View Topic
        $scope.printTopic = function () {
            var printContents = document.getElementById('ExportThis').innerHTML;
            var popupWin = window.open('', '_blank', 'width=300,height=300');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + printContents + '</body></html>');
            popupWin.document.close();
        }

        $scope.printGridData = function () {
            $scope.renderedRows = $scope.gridApi.grid.renderContainers.body.renderedRows;
            setPrintData();
            $timeout(function () {
                if ($scope.renderedRows.length > 0) {
                    var printContents = document.getElementById('gridDatOptions').innerHTML;
                    var popupWin = window.open('', '_blank', 'width=300,height=300');
                    popupWin.document.open();
                    popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + printContents + '</body></html>');
                    popupWin.document.close();
                }
            }, 500)
        }

        $scope.printEditBid = function () {
            var printContents = document.getElementById('printEditDataId').innerHTML;
            var popupWin = window.open('', '_blank', 'width=300,height=300');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="../css/print_info.css" /></head><body onload="window.print()">' + printContents + '</body></html>');
            popupWin.document.close();
        }
        $scope.printBlueSheet = function () {
            var printContents = document.getElementById('blueSheetDiv').innerHTML;
            var popupWin = window.open('', '_blank', 'width=300,height=300');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="../css/bluesheet-print.css" /></head><body onload="window.print()">' + printContents + '</body></html>');
            popupWin.document.close();
        }

        // add new Document Library
        $scope.newLibraryAdd = function () {
            $scope.backup_document = angular.copy($scope.documentIndex); //will be used in case of undo
            $scope.document = angular.copy(documentObj);
            $scope.documentIndex.push($scope.document);
            $scope.library.currentIndex = $scope.documentIndex.length - 1;
            $scope.documentIndex[$scope.library.currentIndex].BidId = $scope.currentRecordId;
            $scope.documentIndex[$scope.library.currentIndex].Add = true;
            $scope.documentIndex[$scope.library.currentIndex].Id = 3000;
            $scope.documentIndex[$scope.library.currentIndex].Document_dateTime = new Date();
        };


        //////////////////////////////   Partner Module Start ////////////////////////////////////////////////////////////////////////////
        $scope.newPartnerAdd = function () {
            $scope.typeObj = {
                PartnerTypeObj: {
                    Id: 0,
                    Name: ""
                },
            }
            $scope.Steps[6].step6[0].serviceProviderName = "";
            $scope.Steps[6].step6[0].DUNS = "";
            $scope.Steps[6].step6[0].street = "";
            $scope.Steps[6].step6[0].city = "";
            $scope.Steps[6].step6[0].state = "";
            $scope.Steps[6].step6[0].country = "";
            $scope.Steps[6].step6[0].zip = "";
            $scope.Steps[6].step6[0].cage = "";
            $scope.Steps[6].step6[0].DUNSPlus4 = "";
            $scope.Steps[6].step6[0].expirationDate = "";
            $scope.Steps[6].step6[0].isDelinquentFederalDebt = false;
            $scope.Steps[6].step6[0].isKnownExclusion = false;
            $scope.Steps[6].step6[0].isProviderActive = false;
            $scope.Steps[6].step6[0].phone = "";
            $scope.Steps[6].step6[0].serviceProviderContact = "";
            $scope.Steps[6].step6[0].contactPhone = "";
            $scope.Steps[6].step6[0].contactEmail = "";
            $scope.Steps[6].step6[0].webSite = "";
            $scope.Steps[6].step6[0].poc = "";
            $scope.Steps[6].step6[0].POCEmail = "";
            $scope.Steps[6].step6[0].WorkShare = "";
            $scope.Steps[6].step6[0].PocDetails = [];
            $scope.Steps[6].step6[0].comments = "";
            $scope.Steps[6].step6[0].coreCompetencies = "";

            $scope.tempObjs.CoreCompetencyObj = [];
        }
        // gets the Data of Service Providers From the Service
        $scope.getAPIData = function (data) {
            $scope.isloading = true;
            $scope.PartnerisUpdateAndLink = false;
            var selectedServiceProviderDuns = $scope.Steps[6].step6[0].serviceProviderName;
            partnerService.getPartnerByDuns(selectedServiceProviderDuns, $scope.currentRecordId).then(function (response) {
                if (response.status == "200" && response.data != "" && response.data.Id > 0) {
                    $scope.PartnerisUpdateAndLink = true;
                    toaster.pop("warning", "Success", "Partner already exist.")
                    $scope.Steps[6].step6[0].Id = response.data.Id;
                    $scope.Steps[6].step6[0].serviceProviderName = response.data.PartnerName;
                    $scope.Steps[6].step6[0].DUNS = response.data.Duns;
                    $scope.Steps[6].step6[0].street = response.data.Street;
                    $scope.Steps[6].step6[0].city = response.data.City;
                    $scope.Steps[6].step6[0].state = response.data.State;
                    $scope.Steps[6].step6[0].country = response.data.Country;
                    $scope.Steps[6].step6[0].zip = response.data.Zip;
                    $scope.Steps[6].step6[0].DUNSPlus4 = response.data.DunsPlus4;
                    $scope.Steps[6].step6[0].cage = response.data.Cage;
                    $scope.Steps[6].step6[0].phone = response.data.Phone;
                    $scope.Steps[6].step6[0].serviceProviderContact = response.data.ServiceProviderContact;
                    $scope.Steps[6].step6[0].contactPhone = response.data.ContactPhone;
                    $scope.Steps[6].step6[0].contactEmail = response.data.ContactEmail;
                    $scope.Steps[6].step6[0].webSite = response.data.WebSite;
                    $scope.Steps[6].step6[0].poc = response.data.POC;
                    $scope.Steps[6].step6[0].email = response.data.Email;
                    $scope.Steps[6].step6[0].comments = response.data.Comments;
                    $scope.Steps[6].step6[0].WorkShare = response.data.WorkShare;

                    $scope.typeObj.PartnerTypeObj.Id = response.data.PartnerTypeId;
                    $scope.typeObj.PartnerTypeObj.Name = response.data.PartnerType;

                    $scope.Steps[6].step6[0].expirationDate = $scope.formatdate(response.data.ExpirationDate);
                    var delinquent = response.data.HasDelinquentFederalDebt;
                    if (delinquent) {
                        $scope.Steps[6].step6[0].isDelinquentFederalDebt = true;
                    }
                    var Exclusion = response.data.HasKnownExclusion;
                    if (Exclusion) {
                        $scope.Steps[6].step6[0].isKnownExclusion = true;
                    }
                    $scope.Steps[6].step6[0].isProviderActive = response.data.isPartnerActive;

                    $scope.Steps[6].step6[0].coreCompetencies = response.data.CoreCompetencies;

                    if ($scope.Steps[6].step6[0].coreCompetencies != null && $scope.Steps[6].step6[0].coreCompetencies != "") {
                        var coreCompetenciesArray = $scope.Steps[6].step6[0].coreCompetencies.split(',');
                        if (coreCompetenciesArray.length > 0) {
                            angular.forEach(coreCompetenciesArray, function (value, key) {
                                var coreCompetencySelectedObj = _.find($scope.coreCompetenciesDropDwn, function (obj) { return obj.Id == value });
                                if (coreCompetencySelectedObj != null) {
                                    $scope.tempObjs.CoreCompetencyObj.push({ 'Id': coreCompetencySelectedObj.Id, 'Name': coreCompetencySelectedObj.Name });
                                }
                            });
                        }
                    }

                    $scope.GetPocDetailsByPartner($scope.Steps[6].step6[0].Id);
                    $scope.isloading = false;
                    $scope.spLoad = false;
                    $scope.Partner.isadding = false;
                    $scope.Partner.isediting = true;
                    $scope.isShowPOCList = true;
                }
                else {
                    $scope.Steps[6].step6[0].Id = 0;
                    $http.get('https://api.data.gov/sam/v1/registrations?qterms=duns:' +
                                      selectedServiceProviderDuns +
                                '&api_key=sTb3Twqloh67fVfGyv0T9TUX8bjnTTtI3p6fPFlh').success(function (data) {
                                    $scope.Steps[6].step6[0].serviceProviderName = data.results[0].legalBusinessName;
                                    $scope.Steps[6].step6[0].DUNS = data.results[0].duns;

                                    $scope.Steps[6].step6[0].street = data.results[0].samAddress.line1;
                                    $scope.Steps[6].step6[0].city = data.results[0].samAddress.city;
                                    $scope.Steps[6].step6[0].state = data.results[0].samAddress.stateOrProvince;
                                    $scope.Steps[6].step6[0].country = data.results[0].samAddress.country;
                                    $scope.Steps[6].step6[0].zip = data.results[0].samAddress.zip;
                                    if (data.results[0].samAddress.zip4 != null && data.results[0].samAddress.zip4 != "")
                                        $scope.Steps[6].step6[0].zip = data.results[0].samAddress.zip + "-" + data.results[0].samAddress.zip4;
                                    else
                                        $scope.Steps[6].step6[0].zip = data.results[0].samAddress.zip;

                                    $scope.Steps[6].step6[0].cage = data.results[0].cage;
                                    $scope.Steps[6].step6[0].DUNSPlus4 = data.results[0].dunsPlus4;
                                    $scope.Steps[6].step6[0].expirationDate = $scope.formatdate(data.results[0].expirationDate);
                                    var delinquent = data.results[0].hasDelinquentFederalDebt;
                                    if (delinquent) {
                                        $scope.Steps[6].step6[0].isDelinquentFederalDebt = true;
                                    }
                                    var Exclusion = data.results[0].hasKnownExclusion;
                                    if (Exclusion) {
                                        $scope.Steps[6].step6[0].isKnownExclusion = true;
                                    }
                                    if (data.results[0].status == "Active") {
                                        $scope.Steps[6].step6[0].isProviderActive = true;
                                    }
                                    $scope.isloading = false;
                                    $scope.spLoad = false;
                                }).error(function (data) {
                                    $scope.spLoad = false;
                                    $scope.error = data;
                                });
                }

            });

        }
        // get the data related to service provider from the service
        $scope.getAPICall = function () {
            $scope.isloading = true;
            var url = 'https://api.data.gov/sam/v1/registrations?qterms=legalBusinessName:' +
                        $('#spName').val().replace(/[^a-z*0-9\s]/gi, '').replace(/[_\s]/g, '-') +
                        '&api_key=sTb3Twqloh67fVfGyv0T9TUX8bjnTTtI3p6fPFlh';
            $http.get(url).success(function (data) {
                if (data.results.length < 1) {
                    $scope.spLoad = false;
                    toaster.pop('error', 'Error', "No Company Records found for the name entered!");
                    $scope.isloading = false;
                    $scope.Steps[6].step6[0].serviceProviderName = "";
                    $scope.Steps[6].step6[0].DUNS = "";
                    $scope.Steps[6].step6[0].street = "";
                    $scope.Steps[6].step6[0].city = "";
                    $scope.Steps[6].step6[0].state = "";
                    $scope.Steps[6].step6[0].country = "";
                    $scope.Steps[6].step6[0].zip = "";
                    $scope.Steps[6].step6[0].cage = "";
                    $scope.Steps[6].step6[0].DUNSPlus4 = "";
                    $scope.Steps[6].step6[0].expirationDate = "";
                    $scope.Steps[6].step6[0].isDelinquentFederalDebt = false;
                    $scope.Steps[6].step6[0].isKnownExclusion = false;
                    $scope.Steps[6].step6[0].isProviderActive = false;
                    return false;
                }
                else if (data.results.length == 1) {
                    $scope.spLoad = false;
                    $scope.isloading = false;
                    $scope.Steps[6].step6[0].serviceProviderName = data.results[0].legalBusinessName;
                    $scope.Steps[6].step6[0].DUNS = data.results[0].duns;
                    $scope.Steps[6].step6[0].street = data.results[0].samAddress.line1;
                    $scope.Steps[6].step6[0].city = data.results[0].samAddress.city;
                    $scope.Steps[6].step6[0].state = data.results[0].samAddress.stateOrProvince;
                    $scope.Steps[6].step6[0].country = data.results[0].samAddress.country;
                    $scope.Steps[6].step6[0].zip = data.results[0].samAddress.zip;
                    if (data.results[0].samAddress.zip4 != null && data.results[0].samAddress.zip4 != "")
                        $scope.Steps[6].step6[0].zip = data.results[0].samAddress.zip + "-" + data.results[0].samAddress.zip4;
                    else
                        $scope.Steps[6].step6[0].zip = data.results[0].samAddress.zip;

                    $scope.Steps[6].step6[0].cage = data.results[0].cage;
                    $scope.Steps[6].step6[0].DUNSPlus4 = data.results[0].dunsPlus4;
                    $scope.Steps[6].step6[0].expirationDate = $scope.formatdate(data.results[0].expirationDate);
                    var delinquent = data.results[0].hasDelinquentFederalDebt;
                    if (delinquent) {
                        $scope.Steps[6].step6[0].isDelinquentFederalDebt = true;
                    }
                    var Exclusion = data.results[0].hasKnownExclusion;
                    if (Exclusion) {
                        $scope.Steps[6].step6[0].isKnownExclusion = true;
                    }
                    if (data.results[0].status == "Active") {
                        $scope.Steps[6].step6[0].isProviderActive = true;
                    }
                }
                else {
                    $scope.spLoad = true;
                    $scope.serviceProviders = data.results;
                    $scope.isloading = false;

                }

            }).error(function (data) {
                $scope.isloading = false;
                $scope.Steps[6].step6[0].serviceProviderName = "";
                $scope.Steps[6].step6[0].DUNS = "";
                $scope.Steps[6].step6[0].street = "";
                $scope.Steps[6].step6[0].city = "";
                $scope.Steps[6].step6[0].state = "";
                $scope.Steps[6].step6[0].country = "";
                $scope.Steps[6].step6[0].zip = "";
                $scope.Steps[6].step6[0].cage = "";
                $scope.Steps[6].step6[0].DUNSPlus4 = "";
                $scope.Steps[6].step6[0].expirationDate = "";
                $scope.Steps[6].step6[0].isDelinquentFederalDebt = false;
                $scope.Steps[6].step6[0].isKnownExclusion = false;
                $scope.Steps[6].step6[0].isProviderActive = false;
                toaster.pop('error', 'Error', "Failed to get company data");
            })


        }

        $scope.updatePartnerType = function () {

        }

        $scope.saveStep6 = function (type) {
            // update the partner Records 
            objPartner = partner;
            if ($scope.Partner.isediting) {

                if ($scope.PartnerisUpdateAndLink) {
                    objPartner.Id = $scope.Steps[6].step6[0].Id;
                    objPartner.PocDetails = $scope.Steps[6].step6[0].PocDetails;
                }
                else {
                    objPartner.Id = $scope.partnerIndex[$scope.Partner.currentIndex].Id;
                    objPartner.PocDetails = $scope.partnerIndex[$scope.Partner.currentIndex].PocDetails;
                }
            }
            else {
                objPartner.Id = 0;
                objPartner.PocDetails = [];
            }
            var bidId = $scope.currentRecordId;
            var workShare = $scope.Steps[6].step6[0].WorkShare;
            // RR-353 checkShareValidationFlag will hold boolean value if validation share will be valid then its value will be True.
            var checkShareValidationFlag;
            //RR-353 checkShareValidation Method is called to get the addition of partner and rigilshare, if share will be equal to 100 or less than 100 the output will be true.
            checkShareValidation("Partner", objPartner.Id, workShare, function callback(bool) {
                checkShareValidationFlag = bool;
                if (!checkShareValidationFlag) {
                    toaster.pop('error', 'Error', "Summation of workShare and Partner percentage is not valid!");
                }
                else {
                    objPartner.Bid_Id = $scope.currentRecordId;
                    objPartner.PartnerName = $scope.Steps[6].step6[0].serviceProviderName;
                    //objPartner.PartnerType = $scope.Steps[6].step6[0].serviceProviderType;
                    //objPartner.PartnerTypeId = $scope.Steps[6].step6[0].serviceProviderTypeId;
                    objPartner.PartnerType = $scope.typeObj.PartnerTypeObj.Name;
                    objPartner.PartnerTypeId = $scope.typeObj.PartnerTypeObj.Id;


                    objPartner.ExpirationDate = $scope.formatdate($scope.Steps[6].step6[0].expirationDate);
                    objPartner.Cage = $scope.Steps[6].step6[0].cage;
                    objPartner.isPartnerActive = $scope.Steps[6].step6[0].isProviderActive
                    objPartner.Duns = $scope.Steps[6].step6[0].DUNS;
                    objPartner.DunsPlus4 = $scope.Steps[6].step6[0].DUNSPlus4;
                    objPartner.Street = $scope.Steps[6].step6[0].street;
                    objPartner.City = $scope.Steps[6].step6[0].city;
                    objPartner.State = $scope.Steps[6].step6[0].state;
                    objPartner.Country = $scope.Steps[6].step6[0].country;
                    objPartner.Zip = $scope.Steps[6].step6[0].zip;
                    objPartner.Phone = $scope.Steps[6].step6[0].phone;
                    objPartner.ServiceProviderContact = $scope.Steps[6].step6[0].serviceProviderContact;
                    objPartner.ContactPhone = $scope.Steps[6].step6[0].contactPhone;
                    objPartner.ContactEmail = $scope.Steps[6].step6[0].contactEmail;
                    objPartner.WebSite = $scope.Steps[6].step6[0].webSite;
                    objPartner.POC = $scope.Steps[6].step6[0].poc;
                    objPartner.Email = $scope.Steps[6].step6[0].POCEmail;
                    objPartner.HasDelinquentFederalDebt = $scope.Steps[6].step6[0].isDelinquentFederalDebt;
                    objPartner.HasKnownExclusion = $scope.Steps[6].step6[0].isKnownExclusion;
                    objPartner.WorkShare = $scope.Steps[6].step6[0].WorkShare;

                    objPartner.Comments = $scope.Steps[6].step6[0].comments;

                    // Process to get Core-competency comma spared from selected list
                    if ($scope.tempObjs.CoreCompetencyObj != undefined && $scope.tempObjs.CoreCompetencyObj.length > 0) {
                        var coreCompList = [];
                        _.each($scope.tempObjs.CoreCompetencyObj, function (data) {
                            coreCompList.push(data.Id);
                        });

                        objPartner.CoreCompetencies = coreCompList.join(',');
                    }
                    else {
                        objPartner.CoreCompetencies = "";
                    }


                    if ($scope.Partner.isadding) {
                        //$http.post('/api/Partner/', objPartner).success(function (data) {
                        partnerService.postData(objPartner).then(function (response) {
                            if (data.id == 0) {
                                toaster.pop('error', 'Error', "Server validation reported save error. So, data could not be saved !");
                            } else {
                                ActivityService.assortedCalls().saveAllCalls(64);
                                $scope.Partner.currentRecordId = data.Id;
                                $scope.partnerIndex.push(data);
                                $scope.AddPOCModal('lg', data.Id);
                                $scope.typeObj = {
                                    PartnerTypeObj: {
                                        Id: 0,
                                        Name: ""
                                    },
                                }
                                $scope.Steps[6].step6[0].serviceProviderName = "";
                                $scope.Steps[6].step6[0].serviceProviderType = "";
                                $scope.Steps[6].step6[0].serviceProviderTypeId = 0;
                                $scope.Steps[6].step6[0].expirationDate = "";
                                $scope.Steps[6].step6[0].cage = "";
                                $scope.Steps[6].step6[0].isProviderActive = false;
                                $scope.Steps[6].step6[0].DUNS = "";
                                $scope.Steps[6].step6[0].DUNSPlus4 = "";
                                $scope.Steps[6].step6[0].street = "";
                                $scope.Steps[6].step6[0].city = "";
                                $scope.Steps[6].step6[0].state = "";
                                $scope.Steps[6].step6[0].country = "";
                                $scope.Steps[6].step6[0].zip = "";
                                $scope.Steps[6].step6[0].phone = "";
                                $scope.Steps[6].step6[0].serviceProviderContact = "";
                                $scope.Steps[6].step6[0].contactPhone = "";
                                $scope.Steps[6].step6[0].contactEmail = "";
                                $scope.Steps[6].step6[0].webSite = "";
                                $scope.Steps[6].step6[0].poc = "";
                                $scope.Steps[6].step6[0].POCEmail = "";
                                $scope.Steps[6].step6[0].isDelinquentFederalDebt = false;
                                $scope.Steps[6].step6[0].isKnownExclusion = false;
                                $scope.Steps[6].step6[0].WorkShare = "";
                                $scope.Steps[6].step6[0].PocDetails = [];
                                $scope.Partner.isadding = false;
                                $scope.Partner.isediting = false;
                            }
                        });
                        //    .error(function (data) {
                        //    $scope.error = "An Error has occurred while adding Partner! " + data;
                        //});
                    }
                    else if ($scope.Partner.isediting) {

                        var pId = $scope.partnerIndex[$scope.Partner.currentIndex].Id;

                        if ($scope.PartnerisUpdateAndLink) {
                            objPartner.Id = $scope.Steps[6].step6[0].Id;
                            pId = $scope.Steps[6].step6[0].Id;
                            objPartner.PocDetails = $scope.Steps[6].step6[0].PocDetails;
                        }
                        //else {
                        //    objPartner.Id = $scope.partnerIndex[$scope.Partner.currentIndex].Id;
                        //    objPartner.PocDetails = $scope.partnerIndex[$scope.Partner.currentIndex].PocDetails;
                        //}

                       
                        partnerService.putData(pId, objPartner).then(function (response) {
                            ActivityService.assortedCalls().saveAllCalls(65);
                            $scope.loadPartners($scope.currentRecordId);
                            $scope.PartnerisUpdateAndLink = false;
                            if (objPartner.PocDetails.length == 0) {
                                $scope.AddPOCModal('lg', pId);
                            } else {
                                var isAnyPOCLinkedWithBid = false;
                                _.each(objPartner.PocDetails, function (data) {
                                    if (data.IsBidMapped) {
                                        isAnyPOCLinkedWithBid = true;
                                    }
                                });

                                if (!isAnyPOCLinkedWithBid) {
                                    $scope.AddPOCModal('lg', pId);
                                }
                            }
                            // $scope.Partner.isadding = false;
                            //$scope.Partner.isediting = false;
                        });
                    }

                }
            });
        }




        //RR-528 : Bind POC Details
        $scope.GetPocDetailsByPartner = function (partnerId) {
            $scope.Steps[6].step6[0].PocDetails = [];
            if (partnerId > 0) {
                partnerService.getPOCDetailByPartner(partnerId).then(function (response) {
                    $scope.Steps[6].step6[0].PocDetails = response.data;
                });
            }
        }

        //loading the Bid Partners
        $scope.loadPartners = function (bidId) {
            $scope.partnerIndex = [];
            partnerService.getByBid(bidId).then(function (response) {
                $scope.partnerIndex = response.data;
                $scope.partnerCount = response.data.length;
            });
        }

        $scope.updateLinkingPartnerWithBid = function (id) {
            var isNeedToDelete = confirm("Are you sure you want to delete this Partner?");
            if (isNeedToDelete) {
                partnerService.updateLinkingPartnerWithBid(id, $scope.currentRecordId).then(function (response) {
                    toaster.pop('success', 'Success', "Partner deleted successfully!");
                    ActivityService.assortedCalls().saveAllCalls(66);
                    angular.forEach($scope.partnerIndex, function (value, index) {
                        if (value.Id == id) {
                            $scope.partnerIndex.splice(index, 1);
                        }
                    }).catch(function (data) {
                        toaster.pop('error', 'Error', "An Error has occurred while deleting Partner!");
                    });
                });
            }
        }

        $scope.newPOCRequest = function (id) {
            $scope.AddNewPOCModal(id);
        }

        $scope.deletePoc = function (pid, pcid) {
            if ($scope.Steps[6].step6[0].PocDetails.length == 1) {
                toaster.pop('info', 'Message', "POC cannot be deleted.Atleast one POC is required!");
            }
            else {
                var ans = confirm("Are you sure you want to delete this POC?");
                if (ans) {
                    $http.delete("api/PartnerContact?pid=" + pid + "&pcid=" + pcid).success(function (data) {
                        toaster.pop('success', 'Success', "POC Details deleted successfully!");
                        angular.forEach($scope.Steps[6].step6[0].PocDetails, function (value, index) {
                            if (value.Id == pcid) {
                                $scope.Steps[6].step6[0].PocDetails.splice(index, 1);
                            }
                        });
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An Error has occurred while deleting POC Details!");
                    })
                }
            }


        }

        $scope.editPocOld = function (data, id) {
            $scope.showEntry = false;
            $scope.mode = "Edit";

            $scope.partnerDetails.Id = data.Id;
            $scope.partnerDetails.POC = data.POC;
            $scope.partnerDetails.Email = data.Email;
            $scope.partnerDetails.Phone = data.Phone;
            $scope.partnerDetails.Comments = data.Comments;

            var modalInstance = $modal.open({
                templateUrl: 'AddPOC.html',
                controller: 'ModalInstanceAddPOCCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    partnerId: function () {
                        return id;
                    },
                    obj: function () {
                        return $scope.partnerDetails;
                    },
                    mode: function () {
                        return $scope.mode;
                    }
                }
            });
            modalInstance.result.then(function (value) {
                if (value == "success") {
                    $http.post('Home/getPartnerInfo?partnerid=' + id).success(function (data) {
                        $scope.Steps[6].step6[0].PocDetails = data.data.PocDetails;
                    }).error(function (data) {
                    })
                    toaster.pop('success', 'Success', "POC Details edited successfully!");
                }
                $scope.showEntry = true;
            });
        }

        $scope.editPoc = function (data, id) { //New
            $scope.showEntry = false;
            $scope.mode = "Edit";

            $scope.partnerDetails = {
                Id: data.Id,
                POC: data.POC,
                Email: data.Email,
                Phone: data.Phone,
                Comments: data.Comments,
                POCTitle: data.POCTitle,
                MobileNo: data.MobileNo,
                Bid_Id: data.Bid_Id
            }

            var modalInstance = $modal.open({
                templateUrl: '../Scripts/app/Partner/partials/pocAddEdit.html',
                controller: 'modalInstanceAddPOCCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    partnerId: function () {
                        return id;
                    },
                    obj: function () {
                        return $scope.partnerDetails;
                    },
                    mode: function () {
                        return $scope.mode;
                    }
                }
            });
            modalInstance.result.then(function (data) {
                toaster.pop('success', 'Success', "POC Details edited successfully!");

                if (data != "" && data != undefined) {
                    $scope.Steps[6].step6[0].PocDetails = data;
                    $scope.pocCheckedUnchecked();
                }
                $scope.showEntry = true;
            });
        }

        $scope.AddNewPOCModal = function (id) {
            $scope.showEntry = false;
            $scope.mode = "Create";
            $scope.partnerDetails = {
                Id: 0,
                POC: "",
                Email: "",
                Phone: "",
                Comments: "",
                POCTitle: "",
                MobileNo: "",
                Bid_Id: $scope.currentRecordId
            }


            var modalInstance = $modal.open({
                templateUrl: '../Scripts/app/Partner/partials/pocAddEdit.html',
                controller: 'modalInstanceAddPOCCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    partnerId: function () {
                        return id;
                    },
                    obj: function () {
                        return $scope.partnerDetails;
                    },
                    mode: function () {
                        return $scope.mode;
                    }
                }
            });
            modalInstance.result.then(function (data) {
                if (data != "" && data != undefined) {
                    $scope.Steps[6].step6[0].PocDetails.push(data);
                    toaster.pop('success', 'Success', "POC Details added successfully!");
                    $scope.pocCheckedUnchecked();
                }
                $scope.showEntry = true;
            });
        }

        $scope.AddPOCModal = function (size, id) {
            $scope.showEntry = false;

            var modalInstance = $modal.open({
                templateUrl: '../Scripts/app/Partner/partials/pocLinkedwithBidAndCreate.html',
                controller: 'ModalInstancePOCCtrl',
                backdrop: 'static',
                scope: $scope,
                size: size,
                resolve: {
                    partnerId: function () {
                        return id;
                    }
                }
            });
            modalInstance.result.then(function (data) {
                if (data == "" || data == undefined) {
                    $scope.loadPartners($scope.currentRecordId);
                    $scope.Partner.isadding = false;
                    $scope.Partner.isediting = false;
                }
                $scope.showEntry = true;
            });
        }

        $scope.togglePOCExpandedSection = function () {
            $scope.isExpandedPOCSection = !$scope.isExpandedPOCSection;
        }
        $scope.togglePOCListExpandedSection = function () {
            $scope.isExpandedPOCListSection = !$scope.isExpandedPOCListSection;
        }






        ///////////////////////////////////   Partner Module End ////////////////////////////////////////////////////////////


        //loading the Bid Diocuments
        $scope.loaddocument = function (bidID) {
            $scope.documentIndex = [];
            $http.get('/api/Bid_Library/?bidID=' + bidID + "&dummy=1").success(function (data) {
                $scope.documentIndex = data;
                $scope.documentCount = data.length;
                $scope.loadresources(bidID);
            })
        };

        //loading the Bid resources
        $scope.loadresources = function (bidID) {

            $scope.resourcesIndex = [];
            //Fetch the library documents on Main page
            $http.get('/api/Library/Index?module=Bid&moduleId=' + bidID).success(function (data3) {
                if (data3 != "") {
                    $scope.debrieffiles = [];
                    $scope.resourcesIndex = data3;
                    angular.forEach($scope.resourcesIndex.uploadresults, function (value, index) {
                        if (value.filesubModule == "Research") {
                            angular.forEach($scope.newsIndex, function (valueN, indexN) {
                                if (valueN.docs == null) { valueN.docs = []; }
                                if (value.filesubModuleId == valueN.Id) { valueN.docs.push(value); }
                            })
                        }
                        if (value.filesubModule == "Library") {
                            angular.forEach($scope.documentIndex, function (valueD, indexD) {
                                if (valueD.docs == null) { valueD.docs = []; }
                                if (value.filesubModuleId == valueD.Id) { valueD.docs.push(value); }
                            })
                        }
                        if (value.filesubModule == "Debrief") {
                            $scope.debrieffiles.push(value);
                        }
                    })
                } else {
                    $scope.resourcesIndex = [];
                }
            })
        };



        $scope.loadBidTrackingItems = function (bidID) {
            $scope.events = [];
            $http.get('/api/BidstatusTrackModel?bidID=' + bidID).success(function (data) {
                $scope.events = data;
            })
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //prepare data for calendar

        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();

        $scope.events11 = [];

        /* Change View */
        $scope.changeView = function (view, calendar) {
            uiCalendarConfig.calendars[calendar].fullCalendar('changeView', view);
        };
        /* Change View */
        $scope.renderCalendar = function (calendar) {
            $timeout(function () {
                if (uiCalendarConfig.calendars[calendar]) {
                    uiCalendarConfig.calendars[calendar].fullCalendar('render');
                }
            });
        };
        $scope.nextstep = function () {
            $('#calendar').fullCalendar('next');
        }
        $scope.prevstep = function () {
            $('#calendar').fullCalendar('prev');
        }

        /* Render Tooltip */
        $scope.eventRender = function (event, element, view) {
            element.attr({
                'tooltip': event.desc,
                'tooltip-append-to-body': true
            });
            $compile(element)($scope);
        };
        $scope.uiConfig = {
            calendar: {
                eventRender: $scope.eventRender
            }
        };


        /*event sources array*/
        $scope.eventSources = [];
        $scope.eventSources = [$scope.events11];

        // Method to load actionitems related to selected Bid
        $scope.loadactionitemscalendar = function () {
            $scope.events11.splice(0, $scope.events11.length);


            $http.get('/api/Bid_ActionItemDashBoard/GetBid_ActionItemAll').success(function (data) {
                $scope.actionitemsIndex = data;
                $scope.actionitemsCount = data.length;
                var count = 0;
                for (var i = 0; i < $scope.actionitemsCount; i++) {
                    var currentdate = new Date().getDate();
                    var actiondate = new Date($scope.actionitemsIndex[i].ActionDue_dateTime).getDate();
                    if (currentdate == actiondate) {
                        count = 1;
                    }
                }
                $scope.actionitemsfilterCount = count;
                angular.forEach($scope.actionitemsIndex, function (value, index) {
                    if (value.ActionItem_Status == 0) {
                        $scope.events11.push({
                            title: value.ActionItem_Title,
                            desc: value.ActionItem,
                            start: (value.Start_From),
                            end: (value.ActionDue_dateTime),
                            color: "red",
                            className: "highPriority",
                            allDay: true,
                            stick: true
                        });
                    }
                    else if (value.ActionItem_Status == 1) {

                        $scope.events11.push({
                            title: value.ActionItem_Title,
                            desc: value.ActionItem,
                            start: (value.Start_From),
                            end: (value.ActionDue_dateTime),
                            color: "yellow",
                            className: "medPriority",
                            allDay: true,
                            stick: true
                        });
                    }
                    else if (value.ActionItem_Status == 2) {

                        $scope.events11.push({
                            title: value.ActionItem_Title,
                            desc: value.ActionItem,
                            start: (value.Start_From),
                            end: (value.ActionDue_dateTime),
                            className: "noPriority",
                            color: "green",
                            allDay: true,
                            stick: true
                        });
                    }
                    else {

                        $scope.events11.push({
                            title: value.ActionItem_Title,
                            desc: value.ActionItem,
                            start: (value.Start_From),
                            end: (value.ActionDue_dateTime),
                            color: "red",
                            backgroundColor: '#23b7e5',
                            className: "highPriority",
                            allDay: true,
                            stick: true
                        });
                    }
                })
            })
        }

        $scope.loadactionitemscalendar();


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //very important code from complex validation point of view
        $scope.checkDueDate = function () {

            if ($scope.Steps[1].step1[0].submittalDate != null && $scope.Steps[1].step1[0].releaseDate != null) {
                if ($scope.Steps[1].step1[0].submittalDate < new Date($scope.Steps[1].step1[0].releaseDate)) {
                    this.step1.proposalDueDate.$error.warningMessage = true;
                    if ($scope.Steps[1].step1[0].isProjected) {
                        this.step1.proposalDueDate.$setValidity('validation-err', true);
                    } else {
                        this.step1.proposalDueDate.$setValidity('validation-err', false);
                    }
                } else {
                    delete this.step1.proposalDueDate.$error.warningMessage;
                    this.step1.proposalDueDate.$setValidity('validation-err', true);
                }
            } else {
                delete this.step1.proposalDueDate.$error.warningMessage;
                this.step1.proposalDueDate.$setValidity('validation-err', true);
            }
        };

        $scope.checkSolicitationDate = function () {

            if ($scope.Steps[1].step1[0].solicitationDate != null && $scope.Steps[1].step1[0].submittalDate != null) {
                if (new Date($scope.Steps[1].step1[0].solicitationDate) > new Date($scope.Steps[1].step1[0].submittalDate)) {
                    this.step1.solicitationDate.$error.warningMessage = true;
                    this.step1.solicitationDate.$setValidity('validation-err1', true);
                }
                else {
                    delete this.step1.solicitationDate.$error.warningMessage;
                    this.step1.solicitationDate.$setValidity('validation-err1', true);
                }
            } else {
                delete this.step1.solicitationDate.$error.warningMessage;
                this.step1.solicitationDate.$setValidity('validation-err1', true);
            }
        };


        $scope.checkBidTitle = function () {

            $http.get('/Home/CheckBidTitle?title=' + $scope.Steps[1].step1[0].bidTitle).success(function (data) {
                if (data.result == "duplicate") {
                    $scope.codeErrorMessage = "Bid Title <b> " + $scope.Steps[1].step1[0].bidTitle + " </b> already exists";
                }
                else {
                    $scope.codeErrorMessage = "";
                }
            })
        }

        $scope.AddNewsModal = function (id, indexValue) {
            var modalInstance = $modal.open({
                templateUrl: 'Attachment.html',
                controller: 'ModalInstanceCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    item1: function () {
                        return id;
                    },
                    bidID: function () {
                        return $scope.currentRecordId;
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.newsIndex[indexValue].Add = false;
                $scope.newsIndex[indexValue].Edit = false;
                $scope.neWs.isadding = false;
                $scope.loadnews($scope.currentRecordId);
            });
        }

        $scope.AddLibraryModal = function (id, indexValue) {
            var modalInstance = $modal.open({
                templateUrl: 'AttachmentLibrary.html',
                controller: 'ModalInstance1Ctrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    item1: function () {
                        return id;
                    },
                    bidID: function () {
                        return $scope.currentRecordId;
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.documentIndex[indexValue].Add = false;
                $scope.documentIndex[indexValue].Edit = false;
                $scope.library.isadding = false;
                $scope.loaddocument($scope.currentRecordId);
            });
        }

        $scope.AddDebriefModal = function (id) {
            var modalInstance = $modal.open({
                templateUrl: 'AttachmentDebrief.html',
                controller: 'ModalInstanceDebriefCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    bidID: function () {
                        return id;
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.loadresources(id);
            });
        }

        $scope.uploadDebriefDocument = function (files, subModule) {
            if (files[0].size > 12000000) {
                toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                $("#documentDebrief").val("");
                return false;
            }
            var filename = files[0].name;
            filename = filename.toLowerCase();
            if (filename.includes(".jpg") || filename.includes(".jpeg") || filename.includes(".bmp") || filename.includes(".png") ||
                 filename.includes(".pdf") || filename.includes(".txt") || filename.includes(".doc") || filename.includes(".docx") || filename.includes(".xls") ||
                 filename.includes(".xlsx") || filename.includes(".ppt") || filename.includes(".pptx") || filename.includes(".html")) {
                $scope.isAttachmentDebriefUploading = true;
                var fd = new FormData();
                //Take the first selected file
                fd.append("file", files[0]);

                $http.post("/api/Library/Resource?module=Bid&moduleId=" + $scope.currentRecordId + "&subModule=" + subModule + "&subModuleId=0", fd, {
                    withCredentials: true,
                    headers: { 'Content-Type': undefined },
                    transformRequest: angular.identity
                }).success(function (data) {
                    $scope.isAttachmentDebriefUploading = false;
                    $("#documentDebrief").val("");
                    if (subModule == 'Debrief') {
                        $scope.debrieffiles.push(data[0]);
                        $("#documentDebrief").val("");
                    }
                }
                ).error(function (data) {
                    toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                    $("#documentDebrief").val("");
                }
                );
            }
            else {
                toaster.pop('error', 'Error', "Valid file types are: jpg/jpeg/bmp/png/pdf/txt/doc/docx/xls/xlsx/ppt/pptx/html");
                $("#documentDebrief").val("");
            };

        };

        $scope.deleteAttachmentD = function (id) {

            var ans = confirm("Are you sure you want to delete?");
            if (ans) {
                $http.delete("/api/Library/Resource/" + id).success(function (data) {
                    var indx = 0;
                    angular.forEach($scope.debrieffiles, function (value, index) {
                        if (value.fileId == id) {
                            indx = index;
                            $scope.debrieffiles.splice(indx, 1);
                        }
                    })
                }).error(function () {
                });
            }
        }



        $scope.openBluesheet = function () {
            var modalInstance = $modal.open({
                templateUrl: 'BlueSheet.html',
                controller: 'modalInstanceBlueSheetCtrl',
                backdrop: 'static',
                size: 'lg',
                scope: $scope,
                resolve: {
                    bidID: function () {
                        return $scope.currentRecordId;
                    }
                }
            });
            modalInstance.result.then(function () {

            });
        }
        $scope.changeZipCodeLocation = function () {
            if ($("#ziploc").val().length == 5) {
                $http.get("/Home/GetCitynState?zipcode=" + $scope.Steps[1].step1[0].customerZipCode).success(function (data) {
                    if (data.zipInfo != null) {
                        $scope.Steps[1].step1[0].customerCity = data.zipInfo.City;
                        $scope.Steps[1].step1[0].customerState = data.zipInfo.Statename;
                    } else {
                        $scope.Steps[1].step1[0].customerCity = "";
                        $scope.Steps[1].step1[0].customerState = "";
                        toaster.pop('error', 'Error', "Enter a valid zipcode");
                        $scope.Steps[1].step1[0].customerZipCode = "";

                    }
                }).error(function (data) {
                    $scope.Steps[1].step1[0].customerCity = "";
                    $scope.Steps[1].step1[0].customerState = "";
                })
            }
            else {
                $scope.Steps[1].step1[0].customerCity = "";
                $scope.Steps[1].step1[0].customerState = "";
            }
        }


        // Method to add a new Department
        $scope.addnewDepartment = function () {
            $scope.newRecord = {
                Id: 0,
                Agencyname: "",
                Acronym: "",
                TypeIndicator: 0,
            }
            $scope.addEditDepartment($scope.newRecord, "add", "department", $scope.departments);
        }

        // Method to add a new Agency
        $scope.addNewAgency = function () {
            $scope.newRecord = {
                Id: 0,
                Agencyname: "",
                Acronym: "",
                TypeIndicator: $scope.Steps[1].step1[0].departmentName,
            }
            $scope.addEditDepartment($scope.newRecord, "add", "agency", $scope.agencies);
        }
        //to add/edit department and agency
        $scope.addEditDepartment = function (obj, mode, type, completelist) {
            $scope.department = {};
            $scope.department = obj;
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/app/departmentConfiguration/partials/departmentPopUp.html',
                controller: 'modalInstanceDepartmentCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    item: function () {
                        return $scope.department;
                    },
                    mode: function () {
                        return mode;
                    },
                    wholelist: function () {
                        return completelist;
                    },
                    type: function () {
                        return type;
                    }
                }
            });
            modalInstance.result.then(function (value) {
                if (value != "") {
                    if (type == "agency") {
                        getAgency(value);
                    }
                    else if (type == "department") {
                        getDepartments(value);
                    }
                }
            });
        }
        function getDepartments(obj) {
            departmentService.getDepartments().then(function (response) {
                $scope.departments = response.data.agencyList;           //populating list of departments 
                $scope.Steps[1].step1[0].departmentName = obj.Id;
                $scope.getAgency();
            });
        }

        function getAgency(obj) {
            var id = $scope.Steps[1].step1[0].departmentName;
            $http.get('/Home/GetInfoAgency?id=' + id).success(function (data) {
                $scope.selectedDept = data.agency;
            });
            //get the Agency/agencies according to the department Dropdown selection
            $http.get('/Home/GetAgencies?departmentId=' + id).success(function (data) {
                if (data.length == 0) {
                    $scope.agencies = [];
                }
                else {
                    $scope.agencies = data.agencyList;
                }
                $scope.Steps[1].step1[0].departmentAgency = obj.Id;
                $http.get('/Home/GetInfoAgency?id=' + obj.Id).success(function (data) {
                    $scope.selectedAgency = data.agency;
                });
            })
        };

        //*****  import fbo.gov opportunities window  START   **********************************

        $scope.openImportWindow = function () {
            $scope.parameterValues = {

            };

            var modalInstance = $modal.open({
                templateUrl: '../tpl/modal/ImportOpportunityModal.html',
                controller: 'OpportunitiesModalInstanceCtrl',
                backdrop: 'static',
                size: 'lg',
                scope: $scope
            });

            app.controller('OpportunitiesModalInstanceCtrl', ['$scope', '$controller', '$modalInstance', '$http', 'toaster', '$q', '$sce', '$window', function ($scope, $controller, $modalInstance, $http, toaster, $q, $sce, $window) {
                // Pagination control related
                $scope.recordCount = 0;
                $scope.currentPage = 1;
                $scope.startindex = 0;
                $scope.pageBoundary = 1;
                var pgboundary = 0;
                $scope.allImportSources = [
                { Id: 1, Name: "FBO.GOV BIZ" },
                { Id: 2, Name: "EBuy" },
                ];
                $scope.importObj = {
                    typeObj: { Id: 1, Name: "FBO.GOV BIZ" }
                }

                //variables
                $scope.textdate = "";
                $scope.isImporting = false;
                $scope.orgOpportunities = [];
                $scope.opportunities = [];
                $scope.currentOpportunityIndex = 0;
                $scope.message = "";
                $scope.datePicker = {};
                $scope.datePicker.date = { startDate: null, endDate: null };
                $scope.searchtextstring = "";
                $scope.totalRecordCount = 0;
                $scope.totalPageBlock = 0;
                $scope.currentPageBlock = 0;
                $scope.blockPerPage = 0;
                $scope.buttonlocation = "";
                $scope.userRowsPerPage = 0;

                // FBO FILTER filter model
                $scope.oldsearchText = {
                    title: [],
                    noticetype: ["PRESOL", "SRCSGT", "COMBINE", "SNOTE", "SSALE", "AWARD", "JA", "AMDCSS", "MOD", "FSTD", "FAIROPP"],
                    solicitationNo: [],
                    naicscode: ["334511", "425110", "454111", "518210", "514162", "519190", "541219", "541330", "541430", "541510", "541511", "541512", "541513", "541519", "541611", "541612", "541614", "541618", "541690", "541712", "541720", "541990", "561110", "561210", "561410", "561499", "562910", "611420", "611430", "611512", "811219"],
                    setaside: ["N/A", "Competitive 8(a)", "Emerging Small Business", "Woman Owned Small Business", "Economically Disadvantaged Woman Owned Small Business", "HUBZone", "Very Small Business", "Partial HBCU / MI", "Partial Small Business", "Service-Disabled Veteran-Owned Small Business", "Total HBCU / MI", "Total Small Business", "Veteran-Owned Small Business", "Indian Economic Enterprises", "Indian Small Business Economic Enterprises", "Service Disabled Veteran Owned Small Business (SDVOSB)"],
                    agency: [],
                    location: [],
                    office: [],
                }
                $scope.searchText = {
                    title: [],
                    noticetype: [],
                    solicitationNo: [],
                    naicscode: [],
                    setaside: [],
                    agency: [],
                    location: [],
                    office: [],
                }

                // EBUY FILTER filter model
                $scope.oldsearchEBUYText = {
                    title: [],
                    solicitationNo: [],
                    agency: [],
                    office: [],
                    sourceCarriers: [],
                }
                $scope.searchEBUYText = {
                    title: [],
                    solicitationNo: [],
                    agency: [],
                    office: [],
                    sourceCarriers: [],
                }
                $scope.filter = function (count) {
                    return count
                }


                // ********************Paging Configuration **************************************

                $scope.maxSize = 100;
                $scope.bigTotalItems = 10000;
                $scope.bigCurrentPage = 1;

                $scope.$watch('maxSize', function () {
                    $scope.currentPage = 1;
                    var pagecount = ($scope.recordCount / $scope.maxSize);
                    var decimalpart = pagecount % 1;
                    $scope.pageBoundary = Math.floor(pagecount);  //integer part from pagecount
                    if (decimalpart > 0) {
                        $scope.pageBoundary = $scope.pageBoundary + 1;
                    }
                    if ($scope.pageBoundary == 0) { $scope.pageBoundary = $scope.pageBoundary + 1; }
                    $scope.startindex = ($scope.currentPage * $scope.maxSize) - $scope.maxSize;
                })

                $scope.pageChanged = function (pageno) {
                    $scope.startindex = (pageno * $scope.maxSize) - $scope.maxSize;
                    if ($scope.startindex >= $scope.blockPerPage) {
                        if (($scope.currentPageBlock + 1) < $scope.totalPageBlock) {
                            $scope.currentPageBlock = $scope.currentPageBlock + 1;
                            $scope.isImporting = true;
                            $scope.changePageBlock($scope.currentPageBlock, '');
                        }
                    }
                    if (pageno == 1) //i.e. clicked first page
                    {
                        if ($scope.buttonlocation == 'first') {
                            $scope.currentPage = 1;
                            $scope.isImporting = true;
                            $scope.currentPageBlock = 0;
                            $scope.changePageBlock($scope.currentPageBlock, 'first');
                        }

                    }
                    if (pageno == $scope.pageBoundary) //i.e. clicked last page
                    {
                        if ($scope.buttonlocation == 'last') {
                            $scope.isImporting = true;
                            $scope.currentPageBlock = ($scope.totalPageBlock - 1);
                            $scope.changePageBlock($scope.currentPageBlock, 'last');
                        }

                    }
                    if (pageno == 0) //i.e. trying to goto previous page block
                    {
                        if ($scope.buttonlocation == '') {
                            $scope.isImporting = true;
                            $scope.currentPageBlock = ($scope.currentPageBlock - 1);
                            $scope.changePageBlock($scope.currentPageBlock, 'last');
                        }
                    }
                };

                $scope.changeBoundary = function () {

                    $scope.currentPage = 1;
                    var pagecount = ($scope.recordCount / $scope.maxSize);
                    var decimalpart = pagecount % 1;
                    $scope.pageBoundary = Math.floor(pagecount);  //integer part from pagecount
                    if (decimalpart > 0) {
                        $scope.pageBoundary = $scope.pageBoundary + 1;
                    }
                    if ($scope.pageBoundary == 0) { $scope.pageBoundary = $scope.pageBoundary + 1; }
                    if ($scope.buttonlocation == 'last') { $scope.currentPage = $scope.pageBoundary; }

                    $scope.startindex = ($scope.currentPage * $scope.maxSize) - $scope.maxSize;
                    return $scope.pageBoundary;
                }

                $scope.changePageBlock = function (blockno, pagelocation) {
                    $scope.searchFilterModel = {};
                    if ($scope.importObj.typeObj.Id == 1)//FBO
                    {
                        angular.copy($scope.searchText, $scope.searchFilterModel)
                    }
                    if ($scope.importObj.typeObj.Id == 2)//EBUY
                    {
                        angular.copy($scope.searchEBUYText, $scope.searchFilterModel)
                    }
                    $http.post("/ExternalBid/GetfromDatalake?date1=" + $scope.startDate + "&date2=" + $scope.endDate + "&datablocknum=" + blockno + "&source=" + $scope.importObj.typeObj.Id, $scope.searchFilterModel).success(function (response) {

                        $scope.orgOpportunities = response.OpportunityData;
                        $scope.opportunities = response.OpportunityData;

                        $scope.isImporting = false;
                        if (response == "") {
                            $scope.recordCount = 0;
                        } else {
                            $scope.recordCount = $scope.opportunities.length;
                            $scope.changeBoundary();

                            if (pagelocation == 'first') { $scope.currentPage = 1; }
                            if (pagelocation == 'last') { $scope.currentPage = $scope.changeBoundary(); }
                        }

                        angular.forEach($scope.opportunities, function (value, index) {
                            value.SearchString = value.Comments + value.NoticeType + value.Subject + value.SolicitationDate + value.SolicitationNumber + value.ResponseDate + value.NaicsCodes + value.SetAsides + value.DeptAgency + value.AgencyOffice + value.OfficeLocation + value.Url;
                        })
                    })
                }

                $scope.saveUserPreference = function (value) {
                    if (value == undefined)
                        value = "100";
                    $http.post("/Home/UserConfigurationUpdate?eventId=BizOppPagesize&typeIndicator=2&value=" + value).success(function () {
                        toaster.pop("success", "Rows per page", "Your preference for rows per page updated successfully.");
                    })
                }

                $http.get("/Home/UserConfiguration?eventId=BizOppPagesize").success(function (response) {
                    if (response.ReturnValue != "") {
                        $scope.maxSize = parseInt(response.ReturnValue);
                    } else {
                        $scope.maxSize = $scope.userRowsPerPage;
                    }
                })
                // ********************Paging Configuration **************************************

                // <!-- ----------------RR-524 START  ------------------>

                //Infinite Scroll 
                $scope.infiniteScroll = {};
                $scope.infiniteScroll.numToAdd = 20;
                $scope.infiniteScroll.currentItems = 20;

                $scope.resetInfScroll = function () {
                    $scope.infiniteScroll.currentItems = $scope.infiniteScroll.numToAdd;
                };
                $scope.addMoreItems = function () {
                    $scope.infiniteScroll.currentItems += $scope.infiniteScroll.numToAdd;
                };
                //for FBO
                function getFBOFilterParameters() {
                    $http.get("/GlobalCacheMethods/GetFBOAgencies").success(function (response) {
                        $scope.oldsearchText.agency = response.data;
                    })
                    $http.get("/GlobalCacheMethods/GetFBOLocations").success(function (response) {
                        $scope.oldsearchText.location = response.data;
                    })
                    $http.get("/GlobalCacheMethods/GetFBOOffices").success(function (response) {
                        $scope.oldsearchText.office = response.data;
                    })

                }
                //For EBUY
                function getEBUYFilterParameters() {
                    $http.get("/GlobalCacheMethods/GetEBUYAgencies").success(function (response) {
                        $scope.oldsearchEBUYText.agency = response.data;
                    })
                    $http.get("/GlobalCacheMethods/GetEBUYOffices").success(function (response) {
                        $scope.oldsearchEBUYText.office = response.data;
                    })
                    $http.get("/GlobalCacheMethods/GetEBUYSourcesCarriers").success(function (response) {
                        $scope.oldsearchEBUYText.sourceCarriers = response.data;
                    })

                }

                getFBOFilterParameters();

                getEBUYFilterParameters();
                // <!-- ----------------RR-524 END  ------------------>
                $scope.updateImportSource = function () {
                    $scope.orgOpportunities = [];
                    $scope.opportunities = [];
                    $scope.currentOpportunityIndex = 0;
                    $scope.totalRecordCount = 0;
                    $scope.totalPageBlock = 0;
                    $scope.currentPageBlock = 0;
                    $scope.blockPerPage = 0;
                }


                //cancel button click
                $scope.cancel = function () {
                    $modalInstance.close();
                }

                //close button click
                $scope.close = function () {
                    $modalInstance.close();
                    callGridData();
                }

                //substitute function of angularJs search textbox filter as that hangs often when the array size increases
                $scope.searchFilter = function () {
                    if ($scope.searchtextstring.length > 0) {
                        $scope.opportunities = [];
                        angular.forEach($scope.orgOpportunities, function (value, index) {
                            if (value.SearchString.toUpperCase().indexOf($scope.searchtextstring.toUpperCase()) != -1) {
                                value.Show = true;
                                $scope.opportunities.push(value);
                            } else {
                                value.Show = false;
                            }
                        })
                        $scope.recordCount = $scope.opportunities.length;
                        $scope.changeBoundary();
                    } else {
                        $scope.opportunities = $scope.orgOpportunities;
                        $scope.recordCount = $scope.opportunities.length;
                        $scope.changeBoundary();
                    }

                }

                $scope.getData = function () {
                    $scope.isImporting = true;
                    $scope.startDate = $scope.formatdate($scope.datePicker.date.startDate._d);
                    $scope.endDate = $scope.formatdate($scope.datePicker.date.endDate._d);


                    $scope.searchFilterModel = {};
                    if ($scope.importObj.typeObj.Id == 1)//FBO
                    {
                        angular.copy($scope.searchText, $scope.searchFilterModel)
                    }
                    if ($scope.importObj.typeObj.Id == 2)//EBUY
                    {
                        angular.copy($scope.searchEBUYText, $scope.searchFilterModel)
                    }
                    $http.post("/ExternalBid/GetfromDatalakeCount?date1=" + $scope.startDate + "&date2=" + $scope.endDate + "&source=" + $scope.importObj.typeObj.Id, $scope.searchFilterModel).success(function (response) {
                        $scope.totalRecordCount = response.dataCount;
                        $scope.totalPageBlock = response.blockCount;
                        $scope.currentPageBlock = 0;
                        $scope.blockPerPage = response.recordsVolume;
                        $scope.userRowsPerPage = response.recordsVolume;
                        $scope.changeBoundary();
                    });

                    $http.post("/ExternalBid/GetfromDatalake?date1=" + $scope.startDate + "&date2=" + $scope.endDate + "&datablocknum=0" + "&source=" + $scope.importObj.typeObj.Id, $scope.searchFilterModel).success(function (response) {

                        $scope.orgOpportunities = response.OpportunityData;
                        $scope.opportunities = response.OpportunityData;

                        $scope.isImporting = false;
                        if (response == "") {
                            $scope.recordCount = 0;
                        } else {
                            $scope.recordCount = $scope.opportunities.length;
                            $scope.changeBoundary();
                        }

                        angular.forEach($scope.opportunities, function (value, index) {
                            value.SearchString = value.Comments + value.NoticeType + value.Subject + value.SolicitationDate + value.SolicitationNumber + value.ResponseDate + value.NaicsCodes + value.SetAsides + value.DeptAgency + value.AgencyOffice + value.OfficeLocation + value.Url + value.Source;
                        })

                    })
                }

                $scope.dateOptionsRange = {
                    locale: {
                        applyLabel: "Apply",
                        cancelLabel: 'Clear',
                        fromLabel: "From",
                        format: "MM/DD/YYYY",
                        toLabel: "To",
                        customRangeLabel: 'Custom range'
                    },
                    showDropdowns: true,
                    minDate: moment().subtract(1, 'year').startOf('year'),
                    maxDate: moment().subtract(1, 'days'),
                    opens: "down",
                    drops: "down",
                    ranges: {
                        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                        'Last 2 Days': [moment().subtract(2, 'days'), moment().subtract(1, 'days')],
                        'Last 3 Days': [moment().subtract(3, 'days'), moment().subtract(1, 'days')]
                    }
                }

                $scope.formatdate = function (sdate) {
                    var d = new Date(sdate);
                    var currDay = "";
                    if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
                    var currMonth = "";
                    if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
                    var currYear = d.getFullYear();
                    var startDate = currMonth + "/" + currDay + "/" + currYear;
                    return startDate;
                }


                //comment window for FBO
                $scope.openCommentWindow = function (id, noticetype, status) {
                    var Passobj = {
                        id: id,
                        noticetype: noticetype,
                        status: status
                    }

                    var commentmodalInstance = $modal.open({
                        templateUrl: '../tpl/modal/CommentModal.html',
                        controller: 'CommentModalInstanceCtrl',
                        backdrop: 'static',
                        size: 'md',
                        scope: $scope,
                        resolve: {
                            parametersObj: function () {
                                return Passobj;
                            }
                        }
                    });

                    app.controller('CommentModalInstanceCtrl', ['$scope', '$controller', '$modalInstance', '$http', 'toaster', '$q', '$sce', 'parametersObj', function ($scope, $controller, $modalInstance, $http, toaster, $q, $sce, parametersObj) {
                        $scope.id = parametersObj.id;
                        $scope.status = parametersObj.status;
                        $scope.noticetype = parametersObj.noticetype;
                        $scope.comment = "";

                        $scope.closeComment = function () {
                            $modalInstance.close();
                        }

                        $scope.saveComment = function () {
                            $http.post("/ExternalBid/SaveCommentMongoDB?id=" + $scope.id + "&noticeType=" + $scope.noticetype + "&status=" + $scope.status + "&comment=" + $scope.comment).success(function (response) {
                                angular.forEach($scope.opportunities, function (value, index) {
                                    if (value.sid == $scope.id) {
                                        value.Comments = $scope.comment;
                                        if ($scope.status == "Accept") {
                                            value.Accept = "Y";
                                            value.Reject = "N";
                                        }
                                        if ($scope.status == "Reject") {
                                            value.Accept = "N";
                                            value.Reject = "Y";
                                        }
                                        if (value.Accept == "Y") {
                                            //push the accepted data to bid table
                                            $http.post("/ExternalBid/SaveFBOBid?objId=" + $scope.id, $scope.opportunities[index]).success(function (response) {

                                                value.Comments = $scope.comment;
                                                if (response.result == "Success") {
                                                    toaster.pop("success", "Bid Tracker Update", "Opportunity successfully imported into Bid Tracker.");
                                                    callGridData();

                                                }
                                                if (response.result == "Error") {
                                                    $scope.opportunities[index].Accept = null;
                                                    $scope.opportunities[index].Reject = null;
                                                    toaster.pop("error", "Bid Tracker Update Failed", "Opportunity Updation failed.");
                                                }


                                            })
                                        }
                                    }
                                })
                                $scope.closeComment();
                            })
                        }
                    }]);
                }

                //comment window for Ebuy
                $scope.openEbuyCommentWindow = function (id, status) {
                    var Passobj = {
                        id: id,
                        status: status
                    }
                    var commentmodalInstance = $modal.open({
                        templateUrl: '../tpl/modal/CommentModal.html',
                        controller: 'eBuyCommentModalInstanceCtrl',
                        backdrop: 'static',
                        size: 'md',
                        scope: $scope,
                        resolve: {
                            parametersObj: function () {
                                return Passobj;
                            }
                        }
                    });

                    app.controller('eBuyCommentModalInstanceCtrl', ['$scope', '$controller', '$modalInstance', '$http', 'toaster', '$q', '$sce', 'parametersObj', function ($scope, $controller, $modalInstance, $http, toaster, $q, $sce, parametersObj) {
                        $scope.id = parametersObj.id;
                        $scope.status = parametersObj.status;
                        $scope.comment = "";

                        $scope.closeComment = function () {
                            $modalInstance.close();
                        }

                        $scope.saveComment = function () {
                            $http.post("/ExternalBid/SaveEBuyCommentMongoDB?id=" + $scope.id + "&status=" + $scope.status + "&comment=" + $scope.comment).success(function (response) {
                                angular.forEach($scope.opportunities, function (value, index) {
                                    if (value.sid == $scope.id) {
                                        value.Comments = $scope.comment;
                                        if ($scope.status == "Accept") {
                                            value.Accept = "Y";
                                            value.Reject = "N";
                                        }
                                        if ($scope.status == "Reject") {
                                            value.Accept = "N";
                                            value.Reject = "Y";
                                        }
                                        if (value.Accept == "Y") {
                                            //push the accepted data to bid table
                                            $http.post("/ExternalBid/SaveEBUYBid?objId=" + $scope.id, $scope.opportunities[index]).success(function (response) {

                                                value.Comments = $scope.comment;
                                                if (response.result == "Success") {
                                                    toaster.pop("success", "Bid Tracker Update", "Opportunity successfully imported into Bid Tracker.");
                                                    callGridData();

                                                }
                                                if (response.result == "Error") {
                                                    $scope.opportunities[index].Accept = null;
                                                    $scope.opportunities[index].Reject = null;
                                                    toaster.pop("error", "Bid Tracker Update Failed", "Opportunity Updation failed.");
                                                }


                                            })
                                        }
                                    }
                                })
                                $scope.closeComment();
                            })
                        }
                    }]);
                }


                //filter window
                $scope.openFilterWindow = function (id, status) {
                    if ($scope.importObj.typeObj.Id == 1)//FBO Filter Window
                    {
                        var Passobj = {
                            id: id,
                            status: status
                        }
                        var filtermodalInstance = $modal.open({
                            templateUrl: '../tpl/modal/FilterModal.html',
                            controller: 'FilterModalInstanceCtrl',
                            backdrop: 'static',
                            size: 'md',
                            scope: $scope,
                            resolve: {
                                parametersObj: function () {
                                    return Passobj;
                                }
                            }
                        });
                        filtermodalInstance.result.then(function (obj) {
                            $scope.searchText = obj;
                        });
                    }
                    if ($scope.importObj.typeObj.Id == 2)//Ebuy Filter Window
                    {
                        var Passobj = {
                            id: id,
                            status: status
                        }
                        var filtermodalInstance = $modal.open({
                            templateUrl: '../tpl/modal/EBuyFilterModal.html',
                            controller: 'EbuyFilterModalInstanceCtrl',
                            backdrop: 'static',
                            size: 'md',
                            scope: $scope,
                            resolve: {
                                parametersObj: function () {
                                    return Passobj;
                                }
                            }
                        });
                        filtermodalInstance.result.then(function (obj) {
                            $scope.searchEBUYText = obj;
                        });
                    }

                    //FBO Filter window controller
                    app.controller('FilterModalInstanceCtrl', ['$scope', '$controller', '$modalInstance', '$http', 'toaster', '$q', '$sce', 'parametersObj',
                                    function ($scope, $controller, $modalInstance, $http, toaster, $q, $sce, parametersObj) {
                                        $scope.id = parametersObj.id;
                                        $scope.status = parametersObj.status;
                                        $scope.comment = "";

                                        $scope.setFilter = function () {
                                            $modalInstance.close($scope.searchText);
                                        }

                                        //RR-556 Get FBO default filter setting
                                        $http.get('/Home/GetUserGeneralConfigs?code=FBOFILTER').success(function (response) {
                                            if (response.data != null && response.data != undefined) {
                                                var value = response.data.Value;
                                                var filterValue = JSON.parse(value);
                                                $scope.searchText = angular.copy(filterValue);
                                            }
                                        }).error(function (response) {
                                            $scope.error = "an error has occurred " + response.msg;
                                        });
                                        $scope.closeFilter = function () {
                                            $scope.searchText = {
                                                title: [],
                                                noticetype: [],
                                                naicscode: [],
                                                setaside: [],
                                                agency: [],
                                                location: [],
                                                office: [],
                                            }
                                            $modalInstance.close($scope.searchText);
                                        }

                                        $scope.clearFilter = function () {
                                            $scope.searchText = {
                                                title: [],
                                                noticetype: [],
                                                naicscode: [],
                                                setaside: [],
                                                agency: [],
                                                location: [],
                                                office: [],
                                            }
                                        }
                                        //  <!-- ----------------RR-533 START  ------------------>
                                        $scope.isExpandedNoticeInfoPanelSection = false;

                                        $scope.toggleNoticeInfoPanelSection = function () {
                                            $scope.isExpandedNoticeInfoPanelSection = !$scope.isExpandedNoticeInfoPanelSection;
                                        }
                                        //  <!-- ----------------RR-533 END  ------------------>

                                        //  <!-- ----------------RR-556 START  ------------------>
                                        $scope.saveDefaultFilters = function () {
                                            $scope.userGeneralConfig = {};
                                            $scope.newserchText = [];
                                            $scope.newserchText = angular.copy($scope.searchText);
                                            angular.forEach($scope.newserchText, function (value, index) {
                                                if (index != "noticetype" && index != "naicscode" && index != "setaside") {
                                                    $scope.newserchText[index] = [];
                                                }
                                            })
                                            $scope.userGeneralConfig.ConfigCode = "FBOFILTER";
                                            $scope.userGeneralConfig.Description = "FBO Filter for Import Window";
                                            $scope.userGeneralConfig.TypeIndicator = "1";
                                            $scope.userGeneralConfig.Value = JSON.stringify($scope.newserchText);
                                            $http.post('/Home/SaveUserGeneralConfigs', $scope.userGeneralConfig).success(function (data) {
                                                toaster.pop('success', 'Success', "");
                                            }).error(function (data) {
                                                $scope.error = "an error has occurred while updating state! ";
                                            });
                                        }
                                        //  <!-- ----------------RR-556 END  ------------------>
                                    }]);
                    //EBuy Filter Window controller
                    app.controller('EbuyFilterModalInstanceCtrl', ['$scope', '$controller', '$modalInstance', '$http', 'toaster', '$q', '$sce', 'parametersObj', function ($scope, $controller, $modalInstance, $http, toaster, $q, $sce, parametersObj) {
                        $scope.id = parametersObj.id;
                        $scope.status = parametersObj.status;
                        $scope.comment = "";

                        $scope.setFilter = function () {
                            $modalInstance.close($scope.searchEBUYText);
                        }

                        $scope.closeFilter = function () {
                            $scope.searchEBUYText = {
                                title: [],
                                solicitationNo: [],
                                agency: [],
                                office: [],
                                sourceCarriers: [],
                            }
                            $modalInstance.close($scope.searchEBUYText);
                        }
                    }]);
                }
            }]);
        }

        //*****  import fbo.gov opportunities window  END   **********************************

        //------------RR-480 Custom Notification Start--------------------------

        $scope.checkedArray = [];
        $scope.headerBellFlag = false;

        $scope.openBellFunction = function (row, col, flag) {
            if (flag == true) {
                row.entity.isBell = true;
                $scope.checkedArray.push(row.entity.Id);
                updateHeaderIcon();
            }
            else if (flag == false) {
                //check if bid is avaiable in checkedArray
                var isArrayElement = CheckArray(row.entity.Id);
                if (isArrayElement) {
                    $scope.bckupcheckedArray = [];
                    $scope.bckupcheckedArray = angular.copy($scope.checkedArray);
                    $scope.checkedArray = [];
                    angular.forEach($scope.bckupcheckedArray, function (value, index) {
                        if (value != row.entity.Id) {
                            $scope.checkedArray.push(value);
                        }
                        if (value == row.entity.Id) {
                            row.entity.isBell = false;
                        }
                    })
                    updateHeaderIcon();
                }
                else {
                    $scope.openNotificationSettingModal(row, flag);
                }
            }

        }

        function CheckArray(curId) {
            var result = false;
            angular.forEach($scope.checkedArray, function (value, index) {
                if (value == curId) {
                    result = true;
                }
            })
            return result;
        }

        function updateHeaderIcon() {
            if ($scope.bidsIndex.length == $scope.checkedArray.length) {
                $scope.headerBellFlag = true;
            }
            else {
                $scope.headerBellFlag = false;
            }
        }

        function emptyCheckedArray() {
            $scope.headerBellFlag = false;
            $scope.dataArray = angular.copy($scope.checkedArray);
            $scope.checkedArray = [];
            angular.forEach($scope.bidsIndex, function (value, index) {
                angular.forEach($scope.dataArray, function (val, ind) {
                    if (value.Id == val) {
                        value.isBell = false;
                    }
                })
            })
            return true;
        }
        $scope.openBatchBellFunction = function (flag) {

            if (flag) {
                $scope.headerBellFlag = flag;
                $scope.checkedArray = [];
                angular.forEach($scope.bidsIndex, function (value, index) {
                    if (value.isBell == false) {
                        value.isBell = flag;
                        $scope.checkedArray.push(value.Id);
                    }

                })
            }
            else {
                $scope.headerBellFlag = flag;
                $scope.dataArray = angular.copy($scope.checkedArray);
                $scope.checkedArray = [];
                angular.forEach($scope.bidsIndex, function (value, index) {
                    angular.forEach($scope.dataArray, function (val, ind) {
                        if (value.Id == val) {
                            value.isBell = flag;
                        }
                    })
                })
            }

        }

        $scope.openNotificationSettingModal = function (row, flag) {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/app/customNotification/partials/NotifySettingDiv.html',
                controller: 'ModalInstanceNotifySettingCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    moduleId: function () {
                        return row.entity.Id;
                    },
                    module: function () {
                        return "Bid";
                    },
                    flag: function () {
                        return flag;
                    }
                }
            });
            modalInstance.result.then(function (data) {
                row.entity.isBell = data;
                $scope.headerBellFlag = false;
            })
        }


        $scope.openSchedulerWindow = function () {
            var modalSchedulerInstance = $modal.open({
                templateUrl: 'Scripts/app/customNotification/partials/SchedulerSettingDiv.html',
                controller: 'ModalSchedulerSettingCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    dataIds: function () {
                        return $scope.checkedArray;
                    },
                    module: function () {
                        return "Bid";
                    },
                }
            });
            modalSchedulerInstance.result.then(function (data) {
                $scope.headerBellFlag = false;
                $scope.dataArray = angular.copy($scope.checkedArray);
                $scope.checkedArray = [];
                angular.forEach($scope.bidsIndex, function (value, index) {
                    angular.forEach($scope.dataArray, function (val, ind) {
                        if (value.Id == val) {
                            value.isBell = data;
                        }
                    })
                })

            })
        }
        //------------RR-480 Custom Notification End--------------------------

        //-- RR-353 Bid Tracker- Partner page validation Snippet Start--
        function checkShareValidation(loc, pId, workShare, callback) {
            var returnval = false;
            if ($scope.Steps[1].step1[0].addMode) {
                returnval = true;
                callback(returnval);
            } else {
                $http.get('/Home/checkShareValidation?bidId=' + $scope.currentRecordId + '&ws=' + workShare + '&Location=' + loc + '&pId=' + pId).then(function (response) {
                    return callback(response.data);
                }).catch(function (error) {
                    returnval = false;
                    return callback(returnval);
                });
            }
        }
        //-- RR-353 Bid Tracker- Partner page validation Snippet END--

        //******************************************************
        //Library Attachment Name returned
        $scope.putDocumentName = function (value) {
            if (value.length < 10) {
                var spaces = 13 - (value.length);
                var finaldata = value;
                finaldata = value + new Array(spaces).join(' ');
                return finaldata;
            }
            else {
                var finaldata = value.substring(0, 9) + "...";
                return finaldata;
            }


        }
        //*************** RR-536 Start ***************************************
        $scope.KEGOnchange = function (kegId) {
            if (kegId == null || kegId == undefined) {
                $scope.kegConstraint.showValue = false;
                $scope.Steps[1].step1[0].ContractId = 0;
                $scope.Steps[1].step1[0].ContractPMName = "";
                $scope.Steps[1].step1[0].ContractPMEmail = "";
                $scope.Steps[1].step1[0].ContractPMPhone = "";

            }
            else {
                var obj = _.find($scope.kegDrpDwn, function (data) { return data.Id == kegId });
                var kegValue = obj.Constant;
                if (kegValue.toLowerCase().trim() == "expand" || kegValue.toLowerCase().trim() == "keep") {
                    $scope.kegConstraint.showValue = true;
                }
                else {
                    $scope.kegConstraint.showValue = false;
                    $scope.Steps[1].step1[0].ContractId = 0;
                    $scope.Steps[1].step1[0].ContractPMName = "";
                    $scope.Steps[1].step1[0].ContractPMEmail = "";
                    $scope.Steps[1].step1[0].ContractPMPhone = "";
                }
            }
        }

        $scope.contractOnChange = function (contractId) {
            $http.get('/Home/GetContractInfo?contractId=' + contractId).success(function (response) {
                $scope.Steps[1].step1[0].ContractPMName = response.PM;
                $scope.Steps[1].step1[0].ContractPMEmail = response.PMEmail;
                $scope.Steps[1].step1[0].ContractPMPhone = response.PMPhone;
            })
        }

        //*************** RR-536 End ***************************************

        //*************** RR-505 Start ***************************************
        $scope.openNotificationSetting = function (id, flag) {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/app/customNotification/partials/NotifySettingDiv.html',
                controller: 'ModalInstanceNotifySettingCtrl',
                backdrop: 'static',
                scope: $scope,
                resolve: {
                    moduleId: function () {
                        return id;
                    },
                    module: function () {
                        return "Bid";
                    },
                    flag: function () {
                        return flag;
                    }
                }
            });
            modalInstance.result.then(function (data) {
                $scope.Steps[1].step1[0].isBell = data;
                angular.forEach($scope.bidsIndex, function (value, index) {
                    if (value.Id == id) {
                        value.isBell = data;
                    }
                })
                //$scope.headerBellFlag = false;
            })
        }
        //*************** RR-505 End ***************************************

        //*************** RR-561 Excel POp Up Call Start ***************************************
        $scope.downloadExcelData = function (mode) {
            var columns = [];
            angular.forEach($scope.gridOptions.columnDefs, function (value, index) {
                if (value.visible && value.name != 'isBell' && value.field != 'Action') {
                    columns.push(value.field);
                }
            })
            var data = [];
            var copiedData = [];
            //the Data from Grid is pushed into "copiedData" list  first and then copied to "data" list as 
            //if we directly copy data from the ui grid to "data" list then the placement of the special characters
            //are also reflected in the ui grid
            if (mode == "All") {
                angular.copy($scope.bidsIndex, data);

            }
            else if (mode == "Filtered") {
                angular.forEach($scope.gridApi.grid.rows, function (value, index) {
                    if (value.visible) {
                        copiedData.push(value.entity);
                    }
                })
                if (copiedData.length > 0) {
                    angular.copy(copiedData, data);
                }
            }

            var col = ["OpportunityId", "Code_Name", "Solicitation_Num", "BiddingType", "BiddingAwardType", "Status", "Title", "PrimeSubType", "AgencyAcronym",
                "Projected_releaseDate", "RelDays", "Solicitation_Date", "RFIDueDate", "RFISubmittedDate", "Proposal_submittalDate", "Proposal_submittedDate",
                "Bid_Score", "RigilStageType", "BiddingStatus", "CompetitionType", "TotalValue_short", "BusinessArea", "IDIQID", "Rating", "AddedBy", "UpdatedBy",
                "CreatedDate", "UpdateDate", "FollowDate", "DocSource"];
            angular.forEach(data, function (value, index) {
                //For ♫ use Alt+14 (14 from number pad) and then release Alt (for ,)
                //For ♦ use Alt+4 (4 from number pad) and then release Alt(for:)
                //Used this special character to replace all occurences of , from a given data string
                //as the serialization of this rows data causes the data to be converted in string
                if (value.Title != "" && value.Title != null && value.Title != undefined) {
                    value.Title = value.Title.replace(/,/g, "♫");
                }
                else if (value.Code_Name != "" && value.Code_Name != null && value.Code_Name != undefined) {
                    value.Code_Name = value.Code_Name.replace(/,/g, "♫");
                }
                else if (value.Solicitation_Num != "" && value.Solicitation_Num != null && value.Solicitation_Num != undefined) {
                    value.Solicitation_Num = value.Solicitation_Num.replace(/,/g, "♫");
                }
                else if (value.BiddingType != "" && value.BiddingType != null && value.BiddingType != undefined) {
                    value.BiddingType = value.BiddingType.replace(/,/g, "♫");
                }
                else if (value.BiddingAwardType != "" && value.BiddingAwardType != null && value.BiddingAwardType != undefined) {
                    value.BiddingAwardType = value.BiddingAwardType.replace(/,/g, "♫");
                }
                else if (value.Status != "" && value.Status != null && value.Status != undefined) {
                    value.Status = value.Status.replace(/,/g, "♫");
                }
                else if (value.PrimeSubType != "" && value.PrimeSubType != null && value.PrimeSubType != undefined) {
                    value.PrimeSubType = value.PrimeSubType.replace(/,/g, "♫");
                }
                else if (value.AgencyAcronym != "" && value.AgencyAcronym != null && value.AgencyAcronym != undefined) {
                    value.AgencyAcronym = value.AgencyAcronym.replace(/,/g, "♫");
                }
                else if (value.RigilStageType != "" && value.RigilStageType != null && value.RigilStageType != undefined) {
                    value.RigilStageType = value.RigilStageType.replace(/,/g, "♫");
                }
                else if (value.BiddingStatus != "" && value.BiddingStatus != null && value.BiddingStatus != undefined) {
                    value.BiddingStatus = value.BiddingStatus.replace(/,/g, "♫");
                }
                else if (value.CompetitionType != "" && value.CompetitionType != null && value.CompetitionType != undefined) {
                    value.CompetitionType = value.CompetitionType.replace(/,/g, "♫");
                }
                else if (value.BusinessArea != "" && value.BusinessArea != null && value.BusinessArea != undefined) {
                    value.BusinessArea = value.BusinessArea.replace(/,/g, "♫");
                }
            })

            if (columns.length > 0) {
                var modalInstance = $modal.open({
                    templateUrl: 'Scripts/app/excelReporting/partials/ReportExcelModal.html',
                    controller: 'modalInstanceReportExcelCtrl',
                    backdrop: 'static',
                    size: 'md',
                    scope: $scope,
                    resolve: {
                        columnsData: function () {
                            return columns;
                        },
                        rowsData: function () {
                            return data;
                        },
                        nameInfo: function () {
                            return "";
                        },
                        moduleName: function () {
                            return "Bid";
                        }
                    }
                });
                modalInstance.result.then(function () {

                });
            }
        }

        //*************** RR-561 Excel POp Up Call  End ***************************************

    }]);

modelBid.controller('ModalInstanceCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'item1', 'bidID', 'toaster', '$location', function ($scope, $http, $modalInstance, $controller, item1, bidID, toaster, location) {
    $controller('bidTracking', { $scope: $scope })
    $scope.docfiles = [];
    $scope.subModuleId = item1;
    $scope.currentRecordId = bidID;
    $scope.isdeletedA = false;
    $scope.toggleAttachModal = function () {
        $modalInstance.close();
    }
    $scope.uploadLibraryDocument = function (files, subModule) {
        if (files[0].size > 12000000) {
            toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
            $("#document").val("");
            return false;
        }
        var filename = files[0].name;
        filename = filename.toLowerCase();
        if (filename.includes(".jpg") || filename.includes(".jpeg") || filename.includes(".bmp") || filename.includes(".png") ||
             filename.includes(".pdf") || filename.includes(".txt") || filename.includes(".doc") || filename.includes(".docx") || filename.includes(".xls") ||
             filename.includes(".xlsx") || filename.includes(".ppt") || filename.includes(".pptx") || filename.includes(".html")) {
            $scope.isAttachmentUploading = true;
            var fd = new FormData();
            //Take the first selected file
            fd.append("file", files[0]);

            $http.post("/api/Library/Resource?module=Bid&moduleId=" + $scope.currentRecordId + "&subModule=" + subModule + "&subModuleId=" + $scope.subModuleId, fd, {
                withCredentials: true,
                headers: { 'Content-Type': undefined },
                transformRequest: angular.identity
            }).success(function (data) {
                $scope.isAttachmentUploading = false;
                $("#document").val("");
                if (subModule == 'Research') {
                    $scope.docfiles.push(data[0]);
                }
            }
            ).error(function (data) {
                toaster.pop('error', 'Error', "Valid file types are: jpg/jpeg/bmp/png/pdf/txt/doc/docx/xls/xlsx/ppt/pptx/html");
            }
            );
        }
        else {
            toaster.pop('error', 'Error', "Valid file types are: jpg/jpeg/bmp/png/pdf/txt/doc/docx/xls/xlsx/ppt/pptx/html");
            $("#document").val("");
        };

    };

    $scope.deleteAttachmentA = function (id) {

        var ans = confirm("Are you sure you want to delete?");
        if (ans) {
            $http.delete("/api/Library/Resource/" + id).success(function (data) {
                var indx = 0;
                angular.forEach($scope.docfiles, function (value, index) {
                    if (value.fileId == id) {
                        indx = index;
                        $scope.docfiles.splice(indx, 1);
                    }
                })
            }).error(function () {
            });
        }
    }
}]);

modelBid.controller('ModalInstance1Ctrl', ['$scope', '$http', '$modalInstance', '$controller', 'item1', 'bidID', 'toaster', '$location', function ($scope, $http, $modalInstance, $controller, item1, bidID, toaster, location) {
    $controller('bidTracking', { $scope: $scope })
    $scope.docfiles = [];
    $scope.subModuleId = item1;
    $scope.currentRecordId = bidID;
    $scope.isdeletedA = false;
    $scope.toggleAttachModal = function () {
        $modalInstance.close();
    }
    $scope.uploadLibraryDocument = function (files, subModule) {
        if (files[0].size > 12000000) {
            toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
            $("#document").val("");
            return false;
        }
        var filename = files[0].name;
        filename = filename.toLowerCase();
        if (filename.includes(".jpg") || filename.includes(".jpeg") || filename.includes(".bmp") || filename.includes(".png") ||
             filename.includes(".pdf") || filename.includes(".txt") || filename.includes(".doc") || filename.includes(".docx") || filename.includes(".xls") ||
             filename.includes(".xlsx") || filename.includes(".ppt") || filename.includes(".pptx") || filename.includes(".html")) {
            $scope.isAttachmentUploading = true;
            var fd = new FormData();
            //Take the first selected file
            fd.append("file", files[0]);

            $http.post("/api/Library/Resource?module=Bid&moduleId=" + $scope.currentRecordId + "&subModule=" + subModule + "&subModuleId=" + $scope.subModuleId, fd, {
                withCredentials: true,
                headers: { 'Content-Type': undefined },
                transformRequest: angular.identity
            }).success(function (data) {
                $scope.isAttachmentUploading = false;
                $("#document").val("");
                if (subModule == 'Library') {
                    $scope.docfiles.push(data[0]);
                    $("#document").val("");
                }
            }
            ).error(function (data) {
                toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");

            }
            );
        }
        else {
            toaster.pop('error', 'Error', "Valid file types are: jpg/jpeg/bmp/png/pdf/txt/doc/docx/xls/xlsx/ppt/pptx/html");
            $("#document").val("");
        };

    };

    $scope.deleteAttachmentA = function (id) {

        var ans = confirm("Are you sure you want to delete?");
        if (ans) {
            $http.delete("/api/Library/Resource/" + id).success(function (data) {
                var indx = 0;
                angular.forEach($scope.docfiles, function (value, index) {
                    if (value.fileId == id) {
                        indx = index;
                        $scope.docfiles.splice(indx, 1);
                    }
                })
            }).error(function () {
            });
        }
    }
}]);

modelBid.controller('ModalInstanceAddPOCCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'partnerId', 'obj', 'mode', 'toaster', '$location', function ($scope, $http, $modalInstance, $controller, partnerId, obj, mode, toaster, location) {
    $controller('bidTracking', { $scope: $scope })
    $scope.partnerId = partnerId;
    $scope.partnerDetails.Id = obj.Id;
    $scope.partnerDetails.POC = obj.POC;
    $scope.partnerDetails.Email = obj.Email;
    $scope.partnerDetails.Phone = obj.Phone;
    $scope.partnerDetails.Comments = obj.Comments;
    $scope.currentMode = mode;


    $scope.toggleAddPOCModal = function () {
        $modalInstance.close();
    }
    $scope.addNewPocDetail = function () {
        if ($scope.currentMode == "Create") {
            $http.post("api/PartnerContact?id=" + $scope.partnerId, $scope.partnerDetails).success(function (data) {
                $modalInstance.close(data);
            }).error(function (data) {
                toaster.pop('error', 'Error', "An Error has occurred while adding POC Details!");
            })
        }
        else if ($scope.currentMode == "Edit") {
            $http.put("api/PartnerContact?id=" + $scope.partnerId, $scope.partnerDetails).success(function (data) {
                $modalInstance.close("success");
            }).error(function (data) {
                toaster.pop('error', 'Error', "An Error has occurred while updating POC Details!");
            })
        }

    }
}]);

modelBid.controller('ModalInstancePOCCtrl', ['$scope', '$http', '$modalInstance', '$modal', '$controller', 'partnerId', 'toaster', '$location', function ($scope, $http, $modalInstance, $modal, $controller, partnerId, toaster, location) {
    $controller('bidTracking', { $scope: $scope })
    $scope.partnerId = partnerId;
    $scope.PocDetails = [];

    $scope.togglePOCModal = function () {
        $modalInstance.close();
    }
    $scope.addPocDetail = function () {
        $('#mainview').css('opacity', '0');
        $scope.AddNewPOCModal($scope.partnerId);
    }

    $scope.deletePoc = function (id) {
        if ($scope.PocDetails.length == 1) {
            toaster.pop('info', 'Message', "POC cannot be deleted.Atleast one POC is required!");
        }
        else {
            var ans = confirm("Are you sure you want to delete this POC?");
            if (ans) {
                $http.delete("api/PartnerContact?pid=" + $scope.partnerId + "&pcid=" + id).success(function (data) {
                    toaster.pop('success', 'Success', "POC Details deleted successfully!");
                    angular.forEach($scope.PocDetails, function (value, index) {
                        if (value.Id == id) {
                            $scope.PocDetails.splice(index, 1);
                        }
                    });
                }).error(function (data) {
                    toaster.pop('error', 'Error', "An Error has occurred while deleting POC Details!");
                })
            }
        }


    }
    $scope.editPoc = function (data) {
        $('#mainview').css('opacity', '0');
        $scope.mode = "Edit";
        $scope.partnerDetails.Id = data.Id;
        $scope.partnerDetails.POC = data.POC;
        $scope.partnerDetails.Email = data.Email;
        $scope.partnerDetails.Phone = data.Phone;
        $scope.partnerDetails.Comments = data.Comments;

        var modalInstance = $modal.open({
            templateUrl: 'AddPOC.html',
            controller: 'ModalInstanceAddPOCCtrl',
            backdrop: 'static',
            scope: $scope,
            resolve: {
                partnerId: function () {
                    return $scope.partnerId;
                },
                obj: function () {
                    return $scope.partnerDetails;
                },
                mode: function () {
                    return $scope.mode;
                }
            }
        });
        modalInstance.result.then(function (value) {
            if (value == "success") {
                $http.post('Home/getPartnerInfo?partnerid=' + $scope.partnerId).success(function (data) {
                    $scope.PocDetails = data.data.PocDetails;
                }).error(function (data) {
                })
                toaster.pop('success', 'Success', "POC Details edited successfully!");
            }
            $('#mainview').css('opacity', '1');
        });
    }

    $scope.AddNewPOCModal = function (id) {
        $scope.mode = "Create";
        $scope.partnerDetails.Id = 0;
        $scope.partnerDetails.POC = "";
        $scope.partnerDetails.Email = "";
        $scope.partnerDetails.Phone = "";
        $scope.partnerDetails.Comments = "";
        var modalInstance = $modal.open({
            templateUrl: 'AddPOC.html',
            controller: 'ModalInstanceAddPOCCtrl',
            backdrop: 'static',
            scope: $scope,
            resolve: {
                partnerId: function () {
                    return id;
                },
                obj: function () {
                    return $scope.partnerDetails;
                },
                mode: function () {
                    return $scope.mode;
                }
            }
        });
        modalInstance.result.then(function (data) {
            if (data != "" && data != undefined) {
                $scope.PocDetails.push(data);
                toaster.pop('success', 'Success', "POC Details added successfully!");
            }
            $('#mainview').css('opacity', '1');
        });
    }
}]);

modelBid.controller('ModalInstanceDebriefCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'bidID', 'toaster', '$location', function ($scope, $http, $modalInstance, $controller, bidID, toaster, location) {
    $scope.debrieffiles = [];
    $scope.currentRecordId = bidID;
    $scope.isdeletedD = false;
    $scope.isAttachmentDebriefUploading = false;
    $scope.toggleAttachModal = function () {
        $modalInstance.close();
    }
    $scope.uploadDebriefDocument = function (files, subModule) {
        if (files[0].size > 12000000) {
            toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
            $("#documentDebrief1").val("");
            return false;
        }
        var filename = files[0].name;
        filename = filename.toLowerCase();
        if (filename.includes(".jpg") || filename.includes(".jpeg") || filename.includes(".bmp") || filename.includes(".png") ||
             filename.includes(".pdf") || filename.includes(".txt") || filename.includes(".doc") || filename.includes(".docx") || filename.includes(".xls") ||
             filename.includes(".xlsx") || filename.includes(".ppt") || filename.includes(".pptx") || filename.includes(".html")) {
            $scope.isAttachmentDebriefUploading = true;
            var fd = new FormData();
            //Take the first selected file
            fd.append("file", files[0]);

            $http.post("/api/Library/Resource?module=Bid&moduleId=" + $scope.currentRecordId + "&subModule=" + subModule + "&subModuleId=0", fd, {
                withCredentials: true,
                headers: { 'Content-Type': undefined },
                transformRequest: angular.identity
            }).success(function (data) {
                $scope.isAttachmentDebriefUploading = false;
                $("#documentDebrief1").val("");
                if (subModule == 'Debrief') {
                    $scope.debrieffiles.push(data[0]);
                    $("#documentDebrief1").val("");
                }
            }
            ).error(function (data) {
                toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                $("#documentDebrief1").val("");
            }
            );
        }
        else {
            toaster.pop('error', 'Error', "Valid file types are: jpg/jpeg/bmp/png/pdf/txt/doc/docx/xls/xlsx/ppt/pptx/html");
            $("#documentDebrief1").val("");
        };

    };

    $scope.deleteAttachmentD = function (id) {

        var ans = confirm("Are you sure you want to delete?");
        if (ans) {
            $http.delete("/api/Library/Resource/" + id).success(function (data) {
                var indx = 0;
                angular.forEach($scope.debrieffiles, function (value, index) {
                    if (value.fileId == id) {
                        indx = index;
                        $scope.debrieffiles.splice(indx, 1);
                    }
                })
            }).error(function () {
            });
        }
    }
}]);

modelBid.controller('modalInstanceBlueSheetCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'bidID', 'toaster', '$location', function ($scope, $http, $modalInstance, $controller, bidID, toaster, location) {
    //$controller('bidTracking', { $scope: $scope })
    $scope.currentRecordId = bidID;

    $scope.toggleAttachModal = function () {
        $modalInstance.close();
    }

}]);












