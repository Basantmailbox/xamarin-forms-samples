﻿'use strict';

app.directive('bsDropdown', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            items: '=dropdownData',
            doSelect: '&selectVal',
            selectedItem: '=preselectedItem'
        },
        link: function (scope, element, attrs) {
            var html = '';
            switch (attrs.menuType) {
                case "button":
                    html += '<div class="btn-group"><button class="btn button-label btn-info">Action</button><button class="btn btn-info dropdown-toggle" data-toggle="dropdown"><span class="caret"></span></button>';
                    break;
                default:
                    html += '<div class="dropdown"><a class="dropdown-toggle" role="button" data-toggle="dropdown"  href="javascript:;">Dropdown<b class="caret"></b></a>';
                    break;
            }
            html += '<ul class="dropdown-menu"><li ng-repeat="item in items"><a tabindex="-1" data-ng-click="selectVal(item)">{{item.name}}</a></li></ul></div>';
            element.append($compile(html)(scope));
            for (var i = 0; i < scope.items.length; i++) {
                if (scope.items[i].id === scope.selectedItem) {
                    scope.bSelectedItem = scope.items[i];
                    break;
                }
            }
            scope.selectVal = function (item) {
                switch (attrs.menuType) {
                    case "button":
                        $('button.button-label', element).html(item.name);
                        break;
                    default:
                        $('a.dropdown-toggle', element).html('<b class="caret"></b> ' + item.name);
                        break;
                }
                scope.doSelect({
                    selectedVal: item.id
                });
            };
            scope.selectVal(scope.bSelectedItem);
        }
    };
});

app.filter('getActionItems', function () {
    return function (actionitemsIndex) {
        var filtered_list = [];
        if (actionitemsIndex) {
            for (var i = 0; i < actionitemsIndex.length; i++) {
                var currentdate = new Date().getDate();
                var actiondate = new Date(actionitemsIndex[i].ActionDue_dateTime).getDate();
                if (currentdate == actiondate) {
                    filtered_list.push(actionitemsIndex[i]);
                }
            }
        }
        return filtered_list;
    }
});
app.filter('shortNumber', function () {
    return function (number) {
        if (number) {
            var abs = Math.abs(number);
            if (abs >= Math.pow(10, 12)) {
                // trillion
                number = (number / Math.pow(10, 12)).toFixed(1) + "T";
            } else if (abs < Math.pow(10, 12) && abs >= Math.pow(10, 9)) {
                // billion
                number = (number / Math.pow(10, 9)).toFixed(1) + "B";
            } else if (abs < Math.pow(10, 9) && abs >= Math.pow(10, 6)) {
                // million
                number = (number / Math.pow(10, 6)).toFixed(1) + "M";
            } else if (abs < Math.pow(10, 6) && abs >= Math.pow(10, 3)) {
                // thousand
                number = (number / Math.pow(10, 3)).toFixed(1) + "K";
            }
            return number;
        }
    };
});

app.filter('convertTomillion', function () {
    return function (number) {
        number = (number / Math.pow(10, 6)).toFixed(1) + "M";
        return number;
    }
})


app.controller('dashboardCtrl', ['$scope', '$http', '$window', '$timeout', '$compile', 'uiCalendarConfig', 'DashboardGraphService', '$interval', '$modal', '$filter', 'commanServices',
    function ($scope, $http, $window, $timeout, $compile, uiCalendarConfig, DashboardGraphService, $interval, $modal, $filter, commanServices) {
        $scope.skillCount = 0;
        $scope.candidateCount = 0;
        $scope.topicCount = 0;
        $scope.kudosCount = 0;
        $scope.contractCount = 0;
        $scope.bidCount = 0;
        $scope.data2 = [];
        $scope.noOfUser = "";
        $scope.typeName = [];
        $scope.topicGroupBy = [];
        $scope.createdDate = [];
        $scope.updatedDate = [];
        $scope.activities = [{ "recentactivities": [] }];
        $scope.activities1 = [{ "allactivities": [] }];
        $scope.AllBidsInformation = [];
        $scope.PipelineBidsInformation = [];
        $scope.datePicker = {};
        $scope.datePicker.date = { startDate: null, endDate: null };
        $scope.gauge1 = {};
        $scope.gauge2 = {};


        $scope.allDataSet = [];
        $scope.bidStageStackedDataSet = [];
        $scope.bidsStatus = {};
        $scope.myChartObject = [];

        $scope.myChartObject2 = [];
        $scope.myChartObject3 = [];
        $scope.funneldata = [];
        $scope.guagedata = [];
        $scope.guageDataDefault = [];
        $scope.selectedVal1 = "ColumnChart";
        $scope.selectedVal2 = "LineChart";
        $scope.selectedVal3 = "PROPOSALSTAGE";
        $scope.selectedVal4 = [];
        $scope.actionitemsfilterCount = 0;
        $scope.showPopover = {};
        $scope.showPopover.div1 = false;
        $scope.showPopover.div2 = false;

        $scope.threshhold = 0;
        $scope.todaysDate = new Date();
        $scope.yearList = [];//list for year dropdown in funnel chart
        $scope.Year = "";// scope for binding year dropdown and funnel chart
        $scope.Years = "";

        $scope.currentIndex = 0;//graph swipe index
        $scope.length = 3;//graph swipe length
        $scope.checkPrev = true;
        $scope.checkNext = false;

        $scope.goback = true;
        $scope.gonext = false;

        $scope.gobackAll = true;
        $scope.gonextAll = false;

        $scope.allActCount = 0;
        $scope.myActCount = 0;
        $scope.servicecalled = false;
        $scope.allActCountTo = 0;
        $scope.allActCountFrom = 0;
        $scope.myActCountTo = 0;
        $scope.myActCountFrom = 0;

        // for reload calander 
        $scope.calenderEvent = {
            isShow: false
        };
        //$scope.items1 = [1, 2, 3, 4, 5];
        //$scope.items2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

        $scope.scrollerData = [];

        $scope.isExpandedUserSection = false;
        $scope.toggleExpandedUserSection = function () {
            $scope.isExpandedUserSection = !$scope.isExpandedUserSection;
        }


        $scope.isExpandedGraphSection = false;
        $scope.toggleExpandedGraphSection = function () {
            $scope.isExpandedGraphSection = !$scope.isExpandedGraphSection;
        }

        $scope.isExpandedCalendarSection = false;
        $scope.toggleExpandedCalendarSection = function () {
            $scope.isExpandedCalendarSection = !$scope.isExpandedCalendarSection;
        }
        // *********** RR-535  Follow Report Start  ***************************
        $scope.isExpandedFollowReportSection = false;
        $scope.toggleExpandedFollowReportSection = function () {
            $scope.isExpandedFollowReportSection = !$scope.isExpandedFollowReportSection;
        }

        $scope.allBidTypesList = [];
        $scope.allfollowList = [
              { Id: '0-6', Value: '0-6 Months' },
              { Id: '6-12', Value: '6-12 Months' },
              { Id: '12-24', Value: '12-24 Months' },
              { Id: '24-48', Value: '24-48 Months' },
              { Id: 'customrange', Value: 'Custom Range' },
              { Id: 'norange', Value: 'No Range' },
        ];
        $scope.dateCrietriaList = [
            { Id: 'releasedate', Value: 'Release Date' },
            { Id: 'projectedreleasedate', Value: 'Projected Release Date' },
            { Id: 'solicitationdate', Value: 'Solicitation Date' },
            { Id: 'rfiduedate', Value: 'RFI due Date' },
            { Id: 'rfisubmissiondate', Value: 'RFI Submission Date' },
            { Id: 'Proposalduedate', Value: 'Proposal Due Date' },
            { Id: 'proposalsubmitteddate', Value: 'proposal Submitted Date' },
            { Id: 'followupdate', Value: 'Follow Up Date' },
            { Id: 'createddate', Value: 'Created Date' },
        ];
        //get All Bid types
        commanServices.getBiddingConstantData("BIDTYPE").then(function (response) {
            $scope.allBidTypesList = response.data;
        });

        $scope.$on("ReloadFollowGrid", function (event, data) {
            $scope.isExpandedFollowReportSection = false;
            $timeout(function () {
                $scope.isExpandedFollowReportSection = true;
            }, 1000);
        });

        // *********** RR-535   Follow Report End  ***************************
        $scope.isExpandedTaskInfoSection = false;
        $scope.toggleExpandedTaskInfoSection = function () {
            $scope.isExpandedTaskInfoSection = !$scope.isExpandedTaskInfoSection;
        }

        function onload() {
            $http.get("Home/ApplicationStartCaches").success(function (response) {
                $timeout(function () {
                    delayedSessionCacheCall();
                }, 1000);
            }).error(function () {
            });
        }
        onload();
        function delayedSessionCacheCall() {
            $http.get("Home/ApplicationStartSessionCaches").success(function (response2) {

            }).error(function () {
            });
        }

        //---------------------------------------Top 5 bids related javascript functions------------------------------------------------------

        $scope.columnHeader = "Total dollar value";
        $scope.topbids = [];
        $scope.bidCountFrom = 0;
        $scope.bidCountTo = 0;
        $scope.bidPageNo = 1;
        $scope.totalbids = 0;
        $scope.sub = false;
        $scope.idiq = false;
        $scope.option = 1;

        $scope.getTopBids = function () {
            $scope.option = 0;
            if ($scope.sub == false && $scope.idiq == false) { $scope.option = 1; $scope.columnHeader = "Total dollar value"; }
            if ($scope.sub == true && $scope.idiq == false) { $scope.option = 2; $scope.columnHeader = "Rigil work share"; }
            if ($scope.sub == false && $scope.idiq == true) { $scope.option = 3; $scope.columnHeader = "Total dollar value"; }
            if ($scope.sub == true && $scope.idiq == true) { $scope.option = 4; $scope.columnHeader = "Rigil work share"; }
            $http.get('/api/Dashboard/GetTop5Bids/' + $scope.option + '/1').success(function (data) {
                $scope.topbids = data;
                $scope.bidPageNo = 1;
                if ($scope.topbids.length > 0) { $scope.bidCountFrom = 1; } else { $scope.bidCountFrom = 0; }
                $scope.bidCountTo = $scope.topbids.length;
                $http.get('/api/Dashboard/GetTop5BidsCount/' + $scope.option).success(function (count) {
                    $scope.totalbids = count;
                })
            })
        }

        $scope.prevBids = function () {
            if (($scope.bidPageNo * 5) > 0) {
                $scope.bidPageNo = $scope.bidPageNo - 1;
                $http.get('/api/Dashboard/GetTop5Bids/' + $scope.option + '/' + $scope.bidPageNo).success(function (data) {
                    $scope.topbids = data;
                    $scope.bidCountFrom = (($scope.bidPageNo - 1) * 5) + 1;
                    $scope.bidCountTo = $scope.bidCountFrom + $scope.topbids.length - 1;
                })
            }
        }

        $scope.nextBids = function () {
            if (($scope.bidPageNo * 5) < $scope.totalbids) {
                $scope.bidPageNo = $scope.bidPageNo + 1;
                $http.get('/api/Dashboard/GetTop5Bids/' + $scope.option + '/' + $scope.bidPageNo).success(function (data) {
                    $scope.topbids = data;
                    $scope.bidCountFrom = (($scope.bidPageNo - 1) * 5) + 1;
                    $scope.bidCountTo = $scope.bidCountFrom + $scope.topbids.length - 1;
                })
            }
        }

        //--------------------------------------------------------------------------------------------------------------------------------


        $scope.chartTypes = [
      { typeName: 'ColumnChart', typeValue: 'ColumnChart' },
      { typeName: 'BarChart', typeValue: 'BarChart' },
      { typeName: 'AreaChart', typeValue: 'AreaChart' },
      { typeName: 'LineChart', typeValue: 'LineChart' },
       { typeName: 'PieChart', typeValue: 'PieChart' },
       { typeName: 'Table', typeValue: 'Table' }
        ];
        $scope.bidTypes = [
     { typeName: 'Rigil_Stage', typeValue: 'PROPOSALSTAGE' },
     { typeName: 'Bid_statusId', typeValue: 'BIDSTATUS' },
     { typeName: 'Bid_typeId', typeValue: 'BIDTYPE' },
     { typeName: 'Award_typeId', typeValue: 'AWARDTYPE' },
      { typeName: 'Bid_competitionTypeId', typeValue: 'COMPETITIONTYPE' },
      { typeName: 'Prime_Sub', typeValue: 'PRIMESUB' }
        ];

        $scope.getMonthYear = function (mY) {
            var MY = mY.toString();
            var month_year = "";
            var year = MY.substr(MY.length - 4, 4);
            var mn = MY.substr(0, MY.length - 4);
            var month = "";

            switch (mn) {
                case "1":
                    month = "Jan";
                    break;
                case "2":
                    month = "Feb";
                    break;
                case "3":
                    month = "Mar";
                    break;
                case "4":
                    month = "Apr";
                    break;
                case "5":
                    month = "May";
                    break;
                case "6":
                    month = "Jun";
                    break;
                case "7":
                    month = "Jul";
                    break;
                case "8":
                    month = "Aug";
                    break;
                case "9":
                    month = "Sep";
                    break;
                case "10":
                    month = "Oct";
                    break;
                case "11":
                    month = "Nov";
                    break;
                case "12":
                    month = "Dec";
                    break;
            }

            month_year = month + ' ' + year;
            return month_year;
        }

        $scope.swipeL = function ($event) {
            alert("Swiped left");
        }
        $scope.swipeR = function ($event) {
            alert("Swiped right");
        }
        var currentYear = new Date().getFullYear().toString();//current year scope for first time loading

        //api service call of all data together
        DashboardGraphService.assortedCalls().loadAllCalls(currentYear)
          .then(function (response) {
              $scope.allDataSet = response;
              $scope.myChartObject = $scope.allDataSet[0].data;
              $scope.myChartObject2 = $scope.allDataSet[1].data;
              $scope.funneldata = $scope.allDataSet[2].data;
              var thresh = $scope.allDataSet[3].data.Value;
              $scope.threshhold = parseInt(thresh);
              $scope.AllBidsInformation = $scope.allDataSet[4].data.AllBids;
              $scope.PipelineBidsInformation = $scope.allDataSet[4].data.PipelineBids;
              $scope.bidYearsData = $scope.allDataSet[5].data;
              $scope.sub == false;
              $scope.idiq == false;
              $scope.getTopBids();

              drawfunnel();

              for (i = 0; i < $scope.myChartObject2.data.rows.length; i++) {
                  $scope.myChartObject2.data.rows[i].c[0].v = $scope.getMonthYear($scope.myChartObject2.data.rows[i].c[0].v);
              }
          });


        ////////////////////////////////////////////////////////////////////////////////////////////////
        $scope.$watch(function (scope) { return scope.selectedVal1 },
                 function (newValue, oldValue) {
                     if ($scope.myChartObject.type) {
                         $scope.myChartObject.type = $scope.selectedVal1;
                     }
                 }
                );
        $scope.$watch(function (scope) { return scope.selectedVal2 },
                   function (newValue, oldValue) {
                       if ($scope.myChartObject2.type) {
                           $scope.myChartObject2.type = $scope.selectedVal2;
                       }
                   }
                  );
        $scope.ChangeStatusType = function (value) {
            $scope.myChartObject.type = value;
            $scope.selectedVal1 = value;
        }
        $scope.ChangeStatusType2 = function (value) {
            $scope.$apply();
            $scope.myChartObject2.type = value;
        }
        $scope.ChangeBidType = function (val) {
            var compareField = "";
            angular.forEach($scope.bidTypes, function (value, index) {
                if (value.typeValue == val) { compareField = value.typeName; }
            })
            $http.get('/api/DashBoard/GetBidStageStackedDataSet?constype=' + val + '&fldname=' + compareField + "&Years=" + $scope.Years).success(function (data) {
                $scope.myChartObject = data;
                $scope.myChartObject.type = $scope.selectedVal1;
            });
            $scope.selectedVal3 = val;
        }
        $scope.ChangeBidYears = function (arr) {
            $scope.Years = arr.join();
            var compareField = "";
            angular.forEach($scope.bidTypes, function (value, index) {
                if (value.typeValue == $scope.selectedVal3) { compareField = value.typeName; }
            })
            $http.get('/api/DashBoard/GetBidStageStackedDataSet?constype=' + $scope.selectedVal3 + '&fldname=' + compareField + "&Years=" + $scope.Years).success(function (data) {
                $scope.myChartObject = data;
                $scope.myChartObject.type = $scope.selectedVal1;
            });
            $scope.selectedVal4 = arr;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////         Graph Swipe   Start  //////////////////////////////////////////////////////////////////////////

        $scope.prevView = function () {
            $scope.currentIndex = ($scope.currentIndex > 0) ? --$scope.currentIndex : $scope.length - 1;
            setscope();
        }
        $scope.nextView = function () {
            $scope.currentIndex = ($scope.currentIndex < $scope.length - 1) ? ++$scope.currentIndex : 0;
            setscope();
        }
        function setscope() {
            if ($scope.currentIndex == 0) {
                $scope.checkPrev = true;
                $scope.checkNext = false;
            }
            else if ($scope.currentIndex == $scope.length - 1) {
                $scope.checkPrev = false;
                $scope.checkNext = true;
            }
            else {
                $scope.checkPrev = false;
                $scope.checkNext = false;
            }

        }
        $scope.isCurrentGraphIndex = function (index) {
            return $scope.currentIndex === index;
        };

        /////////////////////////////////////        DynaView Code   ////////////////////////////////////////////////////////



        $scope.AlldataViews = [];

        $scope.isCurrentSlide = function (index) {
            if ($scope.DynaViews[index].showSlide) { return true; } else { return false; }
        }

        $scope.nextSlide = function () {
            var nextindex = $scope.currentSlideIndex + 1;
            if (nextindex > $scope.DynaViews.length - 1) { $scope.currentSlideIndex = 0; }
            if (nextindex <= $scope.DynaViews.length - 1) { $scope.currentSlideIndex = $scope.currentSlideIndex + 1; }
        }
        $scope.prevSlide = function () {
            var previndex = $scope.currentSlideIndex - 1;
            if (previndex < 0) { $scope.DynaViews[$scope.currentSlideIndex].showSlide = false; $scope.currentSlideIndex = $scope.DynaViews.length - 1; $scope.DynaViews[$scope.currentSlideIndex].showSlide = true; }
            if (previndex >= 0) { $scope.DynaViews[$scope.currentSlideIndex].showSlide = false; $scope.currentSlideIndex = $scope.currentSlideIndex - 1; $scope.DynaViews[$scope.currentSlideIndex].showSlide = true; }
        }

        $scope.addChart = function () {
            var ans = confirm("Proceed to add a chart?");
            if (ans) {
                $scope.dashboardChartView = {
                    id: 0,
                    userid: "",
                    bidflag: "",
                    bidField: "",
                    bidYears: "",
                    bidCharttype: ""
                }

                $scope.Years = $scope.selectedVal4.join();
                var compareField = "";
                angular.forEach($scope.bidTypes, function (value, index) {
                    if (value.typeValue == $scope.selectedVal3) { compareField = value.typeName; }
                })

                $scope.dashboardChartView = {
                    id: 0,
                    userid: "",
                    bidflag: $scope.selectedVal3,
                    bidField: compareField,
                    bidYears: $scope.Years,
                    bidCharttype: $scope.selectedVal1
                }
                $http.post("/api/DashboardChartViews", $scope.dashboardChartView).success(function () {
                    //set master chart to default
                    $http.get('/api/DashBoard/GetBidStageStackedDataSet?constype=PROPOSALSTAGE&fldname=Rigil_Stage&Years=').success(function (data) {
                        $scope.myChartObject = data;
                        $scope.selectedVal1 = "ColumnChart";
                        $scope.myChartObject.type = $scope.selectedVal1;
                        $scope.selectedVal3 = "PROPOSALSTAGE";
                        $scope.selectedVal4 = [];
                    });
                    //
                    $scope.getCustomCharts();
                })
            }
        }

        $scope.getCustomCharts = function () {
            $http.get("/api/DashboardChartViews").success(function (data) {
                $scope.DynaViews = [];
                $scope.DynaViews = data;
                $scope.AlldataViews = [];
                angular.forEach($scope.DynaViews, function (value, index) {
                    $http.get('/api/DashBoard/GetBidStageStackedDataSet?constype=' + value.bidflag + '&fldname=' + value.bidField + "&Years=" + value.bidYears).success(function (data) {
                        $scope.myChartObjectDyna = [];
                        $scope.myChartObjectDyna = data;
                        $scope.myChartObjectDyna.type = value.bidCharttype;
                        $scope.myChartObjectDyna["Heading"] = "Bid Tracker by " + value.bidflag;
                        $scope.myChartObjectDyna["Id"] = value.id;
                        $scope.AlldataViews.push($scope.myChartObjectDyna);
                    });
                })
                $scope.currentSlideIndex = 0;
            })
        }

        $scope.deleteChart = function (ID) {
            var ans = confirm("Are you sure you want to delete it?");
            if (ans) {
                $http.delete("/api/DashboardChartViews/" + ID).success(function () {
                    $scope.getCustomCharts();
                    alert("Deleted successfully");
                })
            }
        }

        $scope.getCustomCharts();

        //-----------------------------------------------------------------------------------------------------------------//

        /////////////////////////////////////       Graph Swipe   End   ////////////////////////////////////////////////////////


        /////////////////////////////////////       Funnel  Start   ////////////////////////////////////////////////////////
        function drawfunnel() {
            var chart = new D3Funnel("#funnel");
            var options = {
                chart: {
                    width: 350,
                    height: 350,
                    curve:
                       {
                           enabled: true
                       },
                    curveHeight: 20,
                    bottomPinch: 1,
                },
                block: {
                    dynamicHeight: true,
                    minHeight: 25,
                    fill: {
                        type: 'gradient',
                    },
                    highlight: true,
                },
                label: {
                    fontSize: "15px",
                    format: '{l} : {f} (bids)',
                }
            };



            chart.draw($scope.funneldata, options);
        }

        /////////////////////////////////////      Funnel  End   ////////////////////////////////////////////////////////

        /////////////////////////////////////       Funnel dropdown   start   ////////////////////////////////////////////////////////
        $.get("/api/DashBoard/GetFunnelYears", function (data) {
            $scope.yearList = data;
            $scope.Year = new Date().getFullYear().toString();
        })
        $scope.GetFunneldata = function () {
            $.get("/api/DashBoard//GetFunnelDataSet/" + $scope.Year, function (data) {
                $scope.funneldata = data;
                drawfunnel();
            })
        }

        /////////////////////////////////////      Funnel dropdown   End   ////////////////////////////////////////////////////////


        /////////////////////////////////////       Liquid Guage  Start   ////////////////////////////////////////////////////////

        $http.get('/api/DashBoard/GetGuageData?year=' + currentYear).success(function (data) {
            $scope.guagedata = data;
            angular.copy($scope.guagedata, $scope.guageDataDefault);
            drawGuage();
        }).error(function (data) {

        })
        function drawGuage() {
            var config1 = liquidFillGaugeDefaultSettings();
            config1.circleThickness = 0.15;
            config1.circleColor = "#808015";
            config1.textColor = "#555500";
            config1.waveTextColor = "#FFFFAA";
            config1.waveColor = "#AAAA39";
            config1.textVertPosition = 0.8;
            config1.waveAnimateTime = 1000;
            config1.waveHeight = 0.05;
            config1.waveAnimate = true;
            config1.waveRise = false;
            config1.waveHeightScaling = false;
            config1.waveOffset = 0.25;
            config1.textSize = 0.75;
            config1.waveCount = 3;

            var config2 = liquidFillGaugeDefaultSettings();
            config2.circleThickness = 0.15;
            config2.circleColor = "#246D5F";
            config2.textColor = "#246D5F";
            config2.waveTextColor = "#FFFFAA";
            config2.waveColor = "#6DA398";
            config2.textVertPosition = 0.8;
            config2.waveAnimateTime = 1000;
            config2.waveHeight = 0.05;
            config2.waveAnimate = true;
            config2.waveRise = false;
            config2.waveHeightScaling = false;
            config2.waveOffset = 0.25;
            config2.textSize = 0.75;
            config2.waveCount = 3;

            $scope.gauge1 = loadLiquidFillGauge("fillgauge1", $scope.guagedata[0], config1);
            $scope.gauge2 = loadLiquidFillGauge("fillgauge2", $scope.guagedata[1], config2);
        }

        $scope.dateOptions = {
            locale: {
                applyLabel: "Apply",
                cancelLabel: 'Clear',
                fromLabel: "From",
                format: "MM/DD/YYYY",
                toLabel: "To",
                customRangeLabel: 'Custom range'
            },
            showDropdowns: true,
            minDate: moment().subtract(20, 'year').startOf('year'),
            maxDate: moment(),
            opens: "left",
            drops: "up",
            ranges: {
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                'Last 3 Month': [moment().subtract(3, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                'Last 6 Month': [moment().subtract(6, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }
        $scope.formatdate = function (sdate) {
            var d = new Date(sdate);
            var currDay = "";
            if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
            var currMonth = "";
            if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
            var currYear = d.getFullYear();
            var startDate = currMonth + "/" + currDay + "/" + currYear;
            return startDate;
        }

        $scope.getlatestLiquidFill = function (obj) {
            $scope.startdate = $scope.formatdate(obj.startDate._d);
            $scope.enddate = $scope.formatdate(obj.endDate._d);
            $http.get('/Home/GetSpecificGuageData?start=' + $scope.startdate + '&end=' + $scope.enddate).success(function (data) {
                $scope.guagedata = data.data;
                $scope.gauge1.update($scope.guagedata[0]);
                $scope.gauge2.update($scope.guagedata[1]);
            }).error(function (data) {
                $scope.error = "An Error has occurred while updating Bid! " + data;
                $scope.loading = false;
            });
        }

        $scope.getDefaultLiquidData = function () {
            angular.copy($scope.guageDataDefault, $scope.guagedata);
            $scope.gauge1.update($scope.guagedata[0]);
            $scope.gauge2.update($scope.guagedata[1]);
            $scope.datePicker.date = "";
        }

        $scope.autoCloseDiv = function (obj) {
            $timeout(function () {
                if (obj == "div1") {
                    $scope.showPopover.div1 = false;
                }
                else if (obj == "div2") {
                    $scope.showPopover.div2 = false;
                }
            }, 1000);
        }
        $scope.autoOpenDiv = function (obj) {
            if (obj == "div1") {
                $scope.showPopover.div1 = true;
                $scope.showPopover.div2 = false;
            }
            else if (obj == "div2") {
                $scope.showPopover.div1 = false;
                $scope.showPopover.div2 = true;
            }
        }




        /////////////////////////////////////      Liquid Guage  End   ////////////////////////////////////////////////////////


        ///////////////////////////////       Activity Start         /////////////////////////////////////////////////


        $.get("/api/DashBoard", function (data) {
            $scope.topicCount = data.topicCount;
            $scope.kudosCount = data.kudosCount;
            $scope.skillCount = data.skillCount;
            $scope.contractCount = data.contractCount;
            $scope.bidCount = data.bidCount;
            $scope.candidateCount = data.candidateCount;
            $scope.allActCount = data.allActCount;
            $scope.myActCount = data.myActCount;
            $scope.allActCountTo = data.allActCountTo;
            $scope.allActCountFrom = data.allActCountFrom;
            $scope.myActCountTo = data.myActCountTo;
            $scope.myActCountFrom = data.myActCountFrom;
            $scope.topicGroupBy = data.topicGroupBy;
            angular.forEach(data.topicGroupBy, function (value, index) {
                $scope.data2.push(value.typeCount);
                $scope.typeName.push(value.typeName);
            });

            $scope.createdDate = data.createdDateNCount;
            $scope.updatedDate = data.updatedDateNCount;
            $scope.teamMates = data.teammates;
            $scope.teamMatesCount = data.teamMatesCount;
            $scope.teamMateAndTopic = data.teamMateAndTopics;
            $scope.activities[0].recentactivities = data.recentactivities;
            $scope.activities1[0].allactivities = data.allactivities;
            setMyActivityScope();
            setAllActivityScope();
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        });

        ///////////////////////////////       Activity End          /////////////////////////////////////////////////
        ///////////////////////////////      Activity scroll start          //////////////////////////
        $scope.prevmyact = function () {
            $.get("/api/DashBoard/GetPrevActivity/myAct/" + $scope.myActCountFrom, function (data) {
                $scope.myActCountTo = data.myActCountTo;
                $scope.myActCountFrom = data.myActCountFrom;
                $scope.activities[0].recentactivities = data.recentactivities;
                setMyActivityScope();
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            });
        }

        $scope.nextmyact = function () {
            $.get("/api/DashBoard/GetNextActivity/myAct/" + $scope.myActCountTo, function (data) {
                $scope.myActCountTo = data.myActCountTo;
                $scope.myActCountFrom = data.myActCountFrom;
                $scope.activities[0].recentactivities = data.recentactivities;
                setMyActivityScope();
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            });
        }

        $scope.prevallact = function () {
            $.get("/api/DashBoard/GetPrevActivity/allAct/" + $scope.allActCountFrom, function (data) {
                $scope.allActCountTo = data.allActCountTo;
                $scope.allActCountFrom = data.allActCountFrom;
                $scope.activities1[0].allactivities = data.allactivities;
                setAllActivityScope();
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            });
        }

        $scope.nextallact = function () {
            $.get("/api/DashBoard/GetNextActivity/allAct/" + $scope.allActCountTo, function (data) {
                $scope.allActCountTo = data.allActCountTo;
                $scope.allActCountFrom = data.allActCountFrom;
                $scope.activities1[0].allactivities = data.allactivities;
                setAllActivityScope();
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            });

        }

        function setAllActivityScope() {
            if ($scope.allActCountFrom == 1 || $scope.allActCountFrom == 0)
                $scope.gobackAll = true;
            else
                $scope.gobackAll = false;
            if ($scope.allActCountTo == $scope.allActCount)
                $scope.gonextAll = true;
            else
                $scope.gonextAll = false;
        }

        function setMyActivityScope() {
            if ($scope.myActCountFrom == 1 || $scope.myActCountFrom == 0)
                $scope.goback = true;
            else
                $scope.goback = false;
            if ($scope.myActCountTo == $scope.myActCount)
                $scope.gonext = true;
        }

        //////////////////////////////       Activity scroll end  /////////////////////////////////////////////




        $scope.d = [[1, 6.5], [2, 6.5], [3, 7], [4, 8], [5, 7.5], [6, 7], [7, 6.8], [8, 7], [9, 7.2], [10, 7], [11, 6.8], [12, 7]];

        $scope.d0_1 = [[0, 7], [1, 6.5], [2, 12.5], [3, 7], [4, 9], [5, 6], [6, 11], [7, 6.5], [8, 8], [9, 7]];

        $scope.d0_2 = [[0, 4], [1, 4.5], [2, 7], [3, 4.5], [4, 3], [5, 3.5], [6, 6], [7, 3], [8, 4], [9, 3]];

        $scope.d1_1 = [[10, 120], [20, 70], [30, 70], [40, 60]];

        $scope.d1_2 = [[10, 50], [20, 60], [30, 90], [40, 35]];

        $scope.d1_3 = [[10, 80], [20, 40], [30, 30], [40, 20]];

        $scope.d2 = [];

        for (var i = 0; i < 20; ++i) {
            $scope.d2.push([i, Math.sin(i)]);
        }

        $scope.d3 = [
          { label: "iPhone5S", data: 40 },
          { label: "iPad Mini", data: 10 },
          { label: "iPad Mini Retina", data: 20 },
          { label: "iPhone4S", data: 12 },
          { label: "iPad Air", data: 18 }
        ];

        $scope.refreshData = function () {
            $scope.d0_1 = $scope.d0_2;
        };

        $scope.getRandomData = function () {
            var data = [],
            totalPoints = 150;
            if (data.length > 0)
                data = data.slice(1);
            while (data.length < totalPoints) {
                var prev = data.length > 0 ? data[data.length - 1] : 50,
                  y = prev + Math.random() * 10 - 5;
                if (y < 0) {
                    y = 0;
                } else if (y > 100) {
                    y = 100;
                }
                data.push(y);
            }
            // Zip the generated y values with the x values
            var res = [];
            for (var i = 0; i < data.length; ++i) {
                res.push([i, data[i]])
            }
            return res;
        }

        $scope.toggleAddUser = function () {
            $('#myModalAddUser').modal('toggle');
            return false;
        }
        $scope.d4 = $scope.getRandomData();



        /////////////////////////////////  Calendar Start      ////////////////////////////////////////////////////


        //Bind calander with Events 
        function GetCalenderData() {
            $http.get('/api/Bid_ActionItemDashBoard/GetBidActionItemAsEvents').success(function (data) {

                $scope.actionitemsIndex = data;
                $scope.actionitemsCount = data.length;
                var count = 0;
                for (var i = 0; i < $scope.actionitemsCount; i++) {
                    var currentdate = new Date().getDate();
                    var actiondate = new Date($scope.actionitemsIndex[i].End).getDate();
                    if (currentdate == actiondate) {
                        count = 1;
                    }
                }
                $scope.actionitemsfilterCount = count;
                angular.forEach($scope.actionitemsIndex, function (value, index) {
                    $scope.events.push({
                        title: value.Title,
                        desc: value.Desc,
                        start: (value.End),
                        end: (value.End),
                        className: value.ClassName,
                        allDay: value.AllDay,
                        stick: value.Stick,
                        moduleId: value.ModuleId,
                        subModuleId: value.SubModuleId,
                        module: value.Module,
                        subModule: value.SubModule
                    });
                })

                $scope.calenderEvent.isShow = true;
            });

        };


        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();
        var currentView = "month";

        $scope.events = [];


        //event source that pulls from google.com
        //$scope.eventSource = {
        //    url: "http://www.google.com/calendar/feeds/usa__en%40holiday.calendar.google.com/public/basic",
        //    className: 'gcal-event',           // an option!
        //    currentTimezone: 'America/Chicago' // an option!
        //};


        //This will call onLoad and you can assign the values the way you want to the calendar
        //here DataRetriever.jsp will give me array of JSON data generated from the database data
        //$http.get('DataRetriever.jsp').success(function (data) {
        //    console.log(data);
        //    for (var i = 0; i < data.length; i++) {
        //        $scope.events[i] = { id: data[i].id, title: data[i].task, start: new Date(data[i].start), end: new Date(data[i].end), allDay: false };
        //    }
        //});
        GetCalenderData();

        //$scope.events = [
        //     { title: 'All Day Event', start: new Date('Thu Oct 17 2013 09:00:00 GMT+0530 (IST)') },
        //     { title: 'Long Event', start: new Date('Thu Oct 17 2013 10:00:00 GMT+0530 (IST)'), end: new Date('Thu Oct 17 2013 17:00:00 GMT+0530 (IST)') },
        //     { id: 999, title: 'Repeating Event', start: new Date('Thu Oct 17 2013 09:00:00 GMT+0530 (IST)'), allDay: false },
        //     { id: 999, title: 'Repeating Event', start: new Date(y, m, d + 4, 16, 0), allDay: false },
        //     { title: 'Birthday Party', start: new Date(y, m, d + 1, 19, 0), end: new Date(y, m, d + 1, 22, 30), allDay: false },
        //     { title: 'Click for Google', start: new Date(y, m, 28), end: new Date(y, m, 29), url: 'http://google.com/' }
        //];

        /*
        //to explicitly add events to the calendar
        //you can add the events in following ways
        $scope.events = [
          {title: 'All Day Event',start: new Date('Thu Oct 17 2013 09:00:00 GMT+0530 (IST)')},
          {title: 'Long Event',start: new Date('Thu Oct 17 2013 10:00:00 GMT+0530 (IST)'),end: new Date('Thu Oct 17 2013 17:00:00 GMT+0530 (IST)')},
          {id: 999,title: 'Repeating Event',start: new Date('Thu Oct 17 2013 09:00:00 GMT+0530 (IST)'),allDay: false},
          {id: 999,title: 'Repeating Event',start: new Date(y, m, d + 4, 16, 0),allDay: false},
          {title: 'Birthday Party',start: new Date(y, m, d + 1, 19, 0),end: new Date(y, m, d + 1, 22, 30),allDay: false},
          {title: 'Click for Google',start: new Date(y, m, 28),end: new Date(y, m, 29),url: 'http://google.com/'}
        ];
        //we don't need it right now*/

        /* event source that calls a function on every view switch */
        //$scope.eventsF = function (start, end, timezone, callback) {
        //    var s = new Date(start).getTime() / 1000;
        //    var e = new Date(end).getTime() / 1000;
        //    var m = new Date(start).getMonth();
        //    var events = [{ title: 'Feed Me ' + m, start: s + (50000), end: s + (100000), allDay: false, className: ['customFeed'] }];
        //    callback(events);
        //};


        ////with this you can handle the events that generated by clicking the day(empty spot) in the calendar
        //$scope.dayClick = function (date, allDay, jsEvent, view) {
        //    $scope.alertMessage = ('Day Clicked ' + date);
        //};



        ////with this you can handle the events that generated by droping any event to different position in the calendar
        //$scope.alertOnDrop = function (event, dayDelta, minuteDelta, allDay, revertFunc, jsEvent, ui, view) {
        //    $scope.alertMessage = ('Event Droped to make dayDelta ' + dayDelta);
        //};


        ////with this you can handle the events that generated by resizing any event to different position in the calendar
        //$scope.alertOnResize = function (event, dayDelta, minuteDelta, revertFunc, jsEvent, ui, view) {
        //    // $scope.$apply(function () {
        //    $scope.alertMessage = ('Event Resized to make dayDelta ' + minuteDelta);
        //    // });
        //};

        /*
        //this code will add new event and remove the event present on index
        //you can call it explicitly in any method
          $scope.events.push({
            title: 'New Task',
            start: new Date(y, m, 28),
            end: new Date(y, m, 29),
            className: ['newtask']
          });
         



        $scope.events.splice(index,1);*/

        /* Render Tooltip */
        $scope.eventRender = function (event, element, view) {
            element.attr({
                'tooltip': (event.subModule == 'Action' ? 'Task ' : 'Action ') + ':- ' + event.title,
                'tooltip-append-to-body': true
            });
            $compile(element)($scope);
        };

        //with this you can handle the click on the events
        $scope.eventClick = function (event) {

            var itemType = event.subModule == 'Action' ? 'A' : 'AI';
            var modealSize = event.subModule == "Action" ? "lg" : "sl";
            var modalInstance = $modal.open({
                templateUrl: 'TaskActionModal.html',
                controller: 'modalInstanceTaskActionCtrl',
                backdrop: 'static',
                size: modealSize,
                scope: $scope,
                resolve: {
                    item: function () {
                        return itemType;
                    },
                    value: function () {
                        return event.subModuleId;
                    }
                }
            });




            modalInstance.result.then(function (isAnyEventDone) {

                //If any Action done by Modal then rebind all Task and ActionItem
                if (isAnyEventDone) {
                    $scope.events = [];
                    $scope.calenderEvent.isShow = false;

                    GetCalenderData();
                    $scope.eventSources = [$scope.events];
                    // $scope.GetTaskActionBids($scope.isTaskRequest, $scope.isAssignedByMeRequest);
                }
            });



        };



        ////with this you can handle the events that generated by each page render process
        //$scope.renderView = function (view) {
        //    var date = new Date(view.calendar.getDate());
        //    $scope.currentDate = date.toDateString();
        //    $scope.alertMessage = ('Page render with date ' + $scope.currentDate);
        //};


        ////with this you can handle the events that generated when we change the view i.e. Month, Week and Day
        //$scope.changeView = function (view, calendar) {
        //    currentView = view;
        //    calendar.fullCalendar('changeView', view);
        //    $scope.alertMessage = ('You are looking at ' + currentView);
        //};


        //  $scope.me.eventSources = [$scope.eventsF];


        //   calanderConfig();
        /* config object */

        $scope.uiConfig = {
            calendar: {
                height: 500,
                editable: false,
                header: {
                    left: 'month agendaWeek agendaDay title',
                    center: '',
                    right: 'today prev,next'
                },
                eventClick: $scope.eventClick,
                eventRender: $scope.eventRender
            }
        };


        /* event sources array  eventDrop: $scope.alertOnDrop,*/
        //dayClick: $scope.dayClick,
        //eventResize: $scope.alertOnResize,
        // viewRender: $scope.renderView
        // $scope.eventSources = [$scope.events, $scope.events, $scope.eventsF];

        $scope.eventSources = [$scope.events];


        /////////////////////////////////  Calendar End      ////////////////////////////////////////////////////

        $scope.redirectlogic = function (obj) {
            $window.location.href = '#/apps/BidTracking';
            sessionStorage.setItem("BidId", obj.Id);
            sessionStorage.setItem("DashboardRedirectBid", 'true');
        }
        if (!$scope.$$phase) {
            $scope.$apply();
        }

        ////////////////////////////////  Bid Status Count  Start  ///////////////////////////////////////////////////
        //RR-546
        $scope.showObj = { showTicker: false, }
        $scope.carouselFlag = false;
        function getTickerData(configValue) {
            $http.get("Home/GetBidStatusCount").success(function (response) {
                $scope.showObj.showTicker = true;
                setProperty(configValue);
                $scope.scrollerData = response.data;

            }).error(function () {
            });
        }

        $scope.colorInspirationClasses = [
        'grapefruit', 'grass', 'bittersweet',
        'mint', 'aqua', 'bluejeans', 'lavender',
        'pinkrose', 'darkgray', 'sunflower', 'lightgray', 'mediumgray'
        ];
        $scope.getOvalClass = function (index) {
            var len = $scope.colorInspirationClasses.length;
            if (index > len - 1)
                index = index - len;
            return $scope.colorInspirationClasses[index];
        }

        // saving state for pause / play button user wise
        //  <!-- ----------------Pause Play Dashboard  ------------------>
        $scope.saveDefaultFilters = function (state) {
            $scope.userGeneralConfig = {};
            $scope.userGeneralConfig.ConfigCode = "PausePlayStateDashboard";
            $scope.userGeneralConfig.Description = "Saving state of Pause Play for Users";
            $scope.userGeneralConfig.TypeIndicator = "1";
            $scope.userGeneralConfig.Value = state;
            $http.post('/Home/SaveUserGeneralConfigs', $scope.userGeneralConfig).success(function (data) {
            }).error(function (data) {
                $scope.error = "an error has occurred while updating state! ";
            });
        }
        getTickerConfiguration();
        function getTickerConfiguration() {
            $http.get('/Home/GetUserGeneralConfigs?code=PausePlayStateDashboard').success(function (response) {
                if (response.data != null && response.data != undefined) {
                    var value = response.data.Value;
                    getTickerData(value);
                }
                else {
                 getTickerData('Running');
                }
            }).error(function (response) {
                $scope.error = "an error has occurred " + response.msg;
            });
        }

        //  <!-- ----------------Pause Play Dashboard  ------------------>

        ////////////////////////////////  Bid Status Count  End  ///////////////////////////////////////////////////


        //---------------------------------------Top Task and Action  related Declaration ------------------------------------------------------

        $scope.allTaskActionbids = [];
        $scope.topTaskActionbids = [];
        $scope.backupTaskActionBids = [];
        $scope.isTaskRequest = true;
        $scope.isAssignedByMeRequest = true;
        $scope.AssignedByandMeValueSelected = '1';
        $scope.TaskOrActionRadioSelected = 'A';
        $scope.BidsUpcoming = 0;
        $scope.BidsDelayed = 0;
        $scope.BidsScheduled = 0;

        $scope.bidTaskActionCountFrom = 0;
        $scope.bidTaskActionCountTo = 0;
        $scope.bidTaskActionPageNo = 1;
        $scope.totalTaskActionbids = 0;
        $scope.gridTaskActionTitle = "Task Assigned by Me";
        $scope.isAdvanceSearch = false;

        $scope.ddlFiltersStatus = [];
        $scope.ddlFiltersProgress = [];

        $scope.txtFiltersTaskAction = "";
        $scope.ddlFiltersStatusSelected = "";
        $scope.ddlFiltersProgressSelected = "";




        // Pagination control  Variables
        $scope.dataCount = 0;
        $scope.currentPage = 0;
        $scope.startindex = 0;
        $scope.maxSize = 5;
        $scope.pageBoundary = 1;
        $scope.bigTotalItems = 5000;
        $scope.bigCurrentPage = 1;

        $scope.txtFilterStartDate = undefined;
        $scope.txtFilterEndDate = undefined;

        $scope.opendp1 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened1 = true;
        };
        $scope.opendp2 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened2 = true;
        };
        $scope.dateOptions = {
            class: 'datepicker'
        };
        //--------------------------------------------------------------------------------------------------------------------------------

        ////////////////////////////////  Task and Action Grid - Start  ///////////////////////////////////////////////////
        //RR-537

        // Pagination control  functionality
        $scope.pageChanged = function (pagenum, size) {
            $scope.startindex = (pagenum * size) - size;
        };

        $scope.pageSizeChanged = function (size) {
            updatePaging(size);
        }
        function updatePaging(size) {
            $scope.currentPage = 1;
            var pagecount = ($scope.dataCount / size);
            var decimalpart = pagecount % 1;
            $scope.pageBoundary = Math.floor(pagecount);  //integer part from pagecount
            if (decimalpart > 0) {
                $scope.pageBoundary = $scope.pageBoundary + 1;
            }
            if ($scope.pageBoundary == 0) { $scope.pageBoundary = $scope.pageBoundary + 1; }
            $scope.startindex = ($scope.currentPage * size) - size;
        }


        //Show Grid first column text base on selected Task/Action Check box and Assiged by me/ to By dropdown
        function SetGridTaskActionTitle() {
            var strAssignedByMeRequest = $scope.AssignedByandMeValueSelected == 1 ? "Assigned by Me" : "Assigned to Me";
            var strTaskRequest = $scope.TaskOrActionRadioSelected == "A" ? "Task" : "Action";
            $scope.gridTaskActionTitle = strTaskRequest + " " + strAssignedByMeRequest;
        }

        //To file dropdown
        $scope.ddlAssignedByandMe = [{ id: '1', name: 'Assigned By Me' }, { id: '2', name: 'Assigned To Me' }];

        //Getting top 5 task/Action base on selected task/Action Checkbox and assigne dropdown
        $scope.GetTaskActionBids = function (isTaskRequest, isAssignedByMeRequest) {
            SetGridTaskActionTitle();

            $scope.txtFilterStartDate = undefined;
            $scope.txtFilterEndDate = undefined;

            var url = "Home/GetTop5TaskAndActions?isTaskRequest=" + isTaskRequest + "&isAssignedByMeRequest=" + isAssignedByMeRequest + "&pageNo=" + $scope.bidPageNo;
            $http.get(url).success(function (data) {
                $scope.topTaskActionbids = [];
                //$scope.allTaskActionbids = [];
                // $scope.topTaskActionbids = data.responseData;
                // $scope.allTaskActionbids = data.allTaskActions;
                $scope.dataCount = 0;
                $scope.topTaskActionbids = data.allTaskActions;
                $scope.backupTaskActionBids = angular.copy($scope.topTaskActionbids);

                $scope.bidTaskActionPageNo = 1;
                if ($scope.topTaskActionbids.length > 0) { $scope.bidTaskActionCountFrom = 1; } else { $scope.bidTaskActionCountFrom = 0; }
                $scope.bidTaskActionCountTo = $scope.topTaskActionbids.length;
                $scope.dataCount = $scope.topTaskActionbids.length;
                updatePaging($scope.maxSize);

                $scope.BidsUpcoming = data.bidsUpcoming;
                $scope.BidsDelayed = data.bidsDelayed;
                $scope.BidsScheduled = data.bidsScheduled;

                $scope.totalTaskActionbids = data.totalCount;

                BindFilters($scope.topTaskActionbids);
            })
        }

        //RR-537 : Method to Bind Task/ActionItem grid on Load
        $scope.GetTaskActionBids($scope.isTaskRequest, $scope.isAssignedByMeRequest);

        //RR-537 : Method to open modal on click Task/ActionItem from grid
        $scope.OnClickBidTaskAction = function (selectedTaskActionId, seletedIndex) {

            var strTaskRequest = $scope.TaskOrActionRadioSelected == "A" ? "Task" : "Action";
            var modealSize = $scope.TaskOrActionRadioSelected == "A" ? "lg" : "sl";
            var modalInstance = $modal.open({
                templateUrl: 'TaskActionModal.html',
                controller: 'modalInstanceTaskActionCtrl',
                backdrop: 'static',
                size: modealSize,
                scope: $scope,
                resolve: {
                    item: function () {
                        return $scope.TaskOrActionRadioSelected;
                    },
                    value: function () {
                        return selectedTaskActionId;
                    }
                }
            });

            modalInstance.result.then(function (isAnyEventDone) {

                //If any Action done by Modal then rebind all Task and ActionItem
                if (isAnyEventDone) {
                    $scope.GetTaskActionBids($scope.isTaskRequest, $scope.isAssignedByMeRequest);
                }
            });
        }

        //RR-537 : Method Call from Check box Task and ActionItem 
        $scope.OnChangeGetTaskAction = function () {
            SetGridTaskActionTitle();
            $scope.isAssignedByMeRequest = $scope.AssignedByandMeValueSelected == 1 ? true : false;
            $scope.isTaskRequest = $scope.TaskOrActionRadioSelected == "A" ? true : false;
            $scope.GetTaskActionBids($scope.isTaskRequest, $scope.isAssignedByMeRequest);
        }

        //RR-537 : Method called by Advance Filters 
        $scope.onChangeFilters = function () {
            $scope.backupTaskActionBidsTemp = angular.copy($scope.backupTaskActionBids);
            //Filters for Date From/To
            if ($scope.txtFilterStartDate != undefined && $scope.txtFilterEndDate != undefined) {
                //$filter('date')(new Date($scope.txtFilterEndDate), "MM/dd/yyyy");
                var fromTime = new Date($scope.txtFilterStartDate);
                var toTime = new Date($scope.txtFilterEndDate);
                fromTime.setHours(0, 0, 0, 0);
                toTime.setHours(0, 0, 0, 0);

                var filteredDataByDates = [];
                var row, date;

                for (i in $scope.backupTaskActionBidsTemp) {

                    row = $scope.backupTaskActionBidsTemp[i];
                    date = new Date(row.DueDate);
                    date.setHours(0, 0, 0, 0);
                    if (date >= fromTime && date <= toTime) {
                        filteredDataByDates.push(row);
                    }
                }
                $scope.backupTaskActionBidsTemp = filteredDataByDates;
            }
            else if ($scope.txtFilterStartDate != undefined) {
                var fromTime = new Date($scope.txtFilterStartDate);// $filter('date')(new Date($scope.txtFilterStartDate), "MM/dd/yyyy");
                fromTime.setHours(0, 0, 0, 0);
                var filteredDataByDates = [];
                var row, date;

                for (i in $scope.backupTaskActionBidsTemp) {
                    row = $scope.backupTaskActionBidsTemp[i];
                    date = new Date(row.DueDate);//$filter('date')(new Date(row.DueDate), "MM/dd/yyyy");
                    date.setHours(0, 0, 0, 0);
                    if (date > fromTime) {
                        filteredDataByDates.push(row);
                    }
                }
                $scope.backupTaskActionBidsTemp = filteredDataByDates;

            }
            else if ($scope.txtFilterEndDate != undefined) {
                var toTime = new Date($scope.txtFilterEndDate);
                toTime.setHours(0, 0, 0, 0);
                var filteredDataByDates = [];
                var row, date;

                for (i in $scope.backupTaskActionBidsTemp) {
                    row = $scope.backupTaskActionBidsTemp[i];
                    date = new Date(row.DueDate);
                    date.setHours(0, 0, 0, 0);
                    if (date < toTime) {
                        filteredDataByDates.push(row);
                    }
                }
                $scope.backupTaskActionBidsTemp = filteredDataByDates;
            }

            //Filters for Task and Action Textbox
            if ($scope.txtFiltersTaskAction != "") {
                $scope.backupTaskActionBidsTemp = $filter('filter')($scope.backupTaskActionBidsTemp, { TaksActionName: $scope.txtFiltersTaskAction });
            }
            //Filters for Status DropDown
            if ($scope.ddlFiltersStatusSelected != "Select" && $scope.ddlFiltersStatusSelected != "" && $scope.ddlFiltersStatusSelected != undefined) {
                $scope.backupTaskActionBidsTemp = $filter('filter')($scope.backupTaskActionBidsTemp, { Status: $scope.ddlFiltersStatusSelected });
            }
            //Filters for Progress DropDown
            if ($scope.ddlFiltersProgressSelected != "Select" && $scope.ddlFiltersProgressSelected != "" && $scope.ddlFiltersProgressSelected != undefined) {
                $scope.backupTaskActionBidsTemp = $filter('filter')($scope.backupTaskActionBidsTemp, { Progress: $scope.ddlFiltersProgressSelected });
            }
            $scope.topTaskActionbids = $scope.backupTaskActionBidsTemp;

            $scope.dataCount = $scope.topTaskActionbids.length;
            updatePaging($scope.maxSize);

        }

        // Call by Advance filter Checkbox
        $scope.OnChangeAdvanceSearch = function () {

            $scope.txtFilterStartDate = undefined;
            $scope.txtFilterEndDate = undefined;

            if ($scope.topTaskActionbids.length > 0) {
                if ($scope.isAdvanceSearch) {
                    BindFilters($scope.topTaskActionbids);
                }
                else {
                    $scope.topTaskActionbids = angular.copy($scope.backupTaskActionBids);
                }
            }
            else {
                $scope.isAdvanceSearch = false;
            }

        }


        function BindFilters(taskActionList) {

            BindFiltersStatus(taskActionList);
            BindFiltersProgress(taskActionList);
        }

        //function BindFiltersTaskAction(taskActionList) {
        //    $scope.txtFiltersTaskAction = "";
        //    $scope.ddlFiltersTaskActions = [];
        //    $scope.ddlFiltersTaskActions = uniqueBy(taskActionList, function (x) { return x.TaksActionName });


        function BindFiltersStatus(taskActionList) {
            $scope.ddlFiltersStatus = [];
            $scope.ddlFiltersStatus = uniqueBy(taskActionList, function (x) { return x.Status });
            $scope.ddlFiltersStatus.unshift("");
            $scope.ddlFiltersStatusSelected = "";
        }

        function BindFiltersProgress(taskActionList) {
            $scope.ddlFiltersProgress = [];
            $scope.ddlFiltersProgress = uniqueBy(taskActionList, function (x) { return x.Progress });
            $scope.ddlFiltersProgress.unshift("");
            $scope.ddlFiltersProgressSelected = "";
        }

        // method retrive unique objects from List of Objects
        function uniqueBy(arr, fn) {
            var unique = {};
            var distinct = [];
            arr.forEach(function (x) {
                var key = fn(x);
                if (!unique[key]) {
                    distinct.push(key);
                    unique[key] = true;
                }
            });
            return distinct;
        }
        ////////////////////////////////  Task and Action Grid - End  ///////////////////////////////////////////////////





    }]);

app.controller('ModalCtrl', ['$scope', '$modal', '$log', function ($scope, $modal, $log) {
    if (!$scope.$$phase) {
        $scope.$apply();
    }
    $scope.items = ['item1', 'item2', 'item3'];
    $scope.modalInstanc = "";
    $scope.role = "";
    $scope.selectedRole = "Viewer";

    var addUser = {
        userName: "",
        role: "",
    }
    $scope.userName = "";
    $scope.role = "";
    $.get('/api/Roles').success(function (data) {
        $scope.roles = data;
        $scope.roleCount = data.length;

    })
    $.get("/Account/GetUserRole").success(function (data) {
        $scope.role = data;
    });

    $.get("/Account/GetNoOfUser").success(function (data) {
        $scope.noOfUser = data;
    });


    $scope.open = function (formName) {
        var modalInstance;
        //get all roles
        $scope.sendEmail = function () {
            addUser.userName = this.userName;
            addUser.role = this.role.Id;
            $.post('/api/DashBoard/', addUser).success(function (data) {
                modalInstance.dismiss('cancel');
            });
        };

        $scope.cancel = function () {
            modalInstance.dismiss('cancel');
        };

        modalInstance = $modal.open({
            templateUrl: formName,
            controller: 'ModalInstanceCtrl',
            scope: $scope,
            resolve: {
                items: function () {
                    return $scope.items;
                }
            }
        });
        if (!$scope.$$phase) {
            $scope.$apply();
        }
        return false;
    };

}]);



//RR-537 Process to Open Modal on click Task/ActionItem from Dashboard Grid 
app.controller('modalInstanceTaskActionCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'toaster', '$location', 'item', 'value', 'ActivityService',
    function ($scope, $http, $modalInstance, $controller, toaster, location, item, value, ActivityService) {

        $scope.itemId = value;
        $scope.objPram = item;
        $scope.taskAction = {};
        $scope.isDeleteAction = false;
        $scope.isAnyEventDone = false; // for keeping track whether any event ( status or Delete ) done from modal 

        $scope.bidName = "";
        $scope.ACTION = {
            Action_Title: '',
            Action_takenLastWeek: '',
            DueDate: '',
            UserId: [],
            Comments: '',
            AssignedBy: ''
        }

        $scope.bidName = '';
        $scope.isActionRequest = false;   //for keeping track whether action selected or not

        $scope.ACTIONITEMS = []; //for keepting all ActionItems  

        onLoad();

        // Bind Task/ActionItem grid on pageLoad
        function onLoad() {
            if ($scope.objPram == 'A') {
                $scope.isActionRequest = true;
                bindActions($scope.itemId, true);

            }
            else {
                $scope.isActionRequest = false;
                var urlActionItems = "Home/GetBidActionItem?id=" + $scope.itemId;
                bindActionItems(urlActionItems, false);
            }
        }

        $scope.toggleAttachModal = function () {
            $modalInstance.close($scope.isAnyEventDone);
        }


        //RR-537 Update ActionItem Status on Dropdown change Event
        $scope.UpdateActionStatus = function (actionItem) {
            var url = "Home/BidActionItemUpdateStatus?id=" + actionItem.Id + "&actionItemStatus=" + actionItem.ActionItem_Status;
            $http.get(url).success(function (data) {
                if (data.IsSuccess) {
                    toaster.pop('success', 'Success', "Action Item updated Successfully");
                    ActivityService.assortedCalls().saveAllCalls(56);
                    $scope.isAnyEventDone = true;

                    var emailHeader = "Action Item Update";
                    $http.post('/Home/SendTaskEmail?TaskType=AI&Id=' + actionItem.Id + '&NewOld=' + emailHeader).success(function (data) {
                    });

                }
                else {
                    toaster.pop('error', 'Error', "An error occured while updating Bid Action Item!");
                }
            });

        }


        //RR-537 Process to delete Task or ActionItem by click Delete link from Modal
        $scope.onClickTaskActionDelete = function (id, isAction) {
            if (isAction) {
                var confirmResult = confirm("Are you sure you want to delete this Task?");
                if (confirmResult == true) {
                    $http.delete('/api/Bid_Action?id=' + id).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(54);
                        $scope.isAnyEventDone = true;
                        toaster.pop('success', 'Success', "Bid Action deleted successfully!");
                        bindActions($scope.itemId, true);
                        $scope.toggleAttachModal();
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while deleting Bid Action!");
                    });

                    //var emailHeader = "Task Deletion";
                    //$http.post('/Home/SendTaskEmail?TaskType=A&Id=' + id + '&NewOld=' + emailHeader).success(function (data) {
                    //});

                }
                else {
                    $scope.isAnyEventDone = false;
                    $scope.toggleAttachModal();
                }
            }
            else {
                var confirmResult = confirm("Are you sure you want to delete this Action?");
                if (confirmResult == true) {
                    $http.delete('/api/Bid_ActionItem?id=' + id).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(57);
                        $scope.isAnyEventDone = true;
                        toaster.pop('success', 'Success', "Bid Action Item deleted successfully!");
                        var urlActionItes = "Home/GetBidActionItem?id=" + $scope.itemId;
                        bindActionItems(urlActionItes, false);

                        if ($scope.ACTIONITEMS.length == 0) {
                            $scope.toggleAttachModal();
                        }

                        //var emailHeader = "Action Item Deletion";
                        //$http.post('/Home/SendTaskEmail?TaskType=AI&Id=' + id + '&NewOld=' + emailHeader).success(function (data) {
                        //});

                    })
                        .error(function (data) {
                            toaster.pop('error', 'Error', "An error occured while deleting Bid Action Item!");
                        });
                }
                else {
                    $scope.isAnyEventDone = false;
                    $scope.toggleAttachModal();
                }
            }

        }

        //days to go
        $scope.daysToGo = function (data) {
            var daystogo;
            var submitdate;
            var currentdate;
            var timeDiff;

            submitdate = new Date(data);
            currentdate = new Date();
            timeDiff = Math.abs(submitdate.getTime() - currentdate.getTime());
            daystogo = Math.ceil(timeDiff / (1000 * 3600 * 24));

            if (currentdate > submitdate) { daystogo = daystogo * -1; }

            return daystogo;
        }



        // Method to load actionitems related to selected Bid
        function bindActions(actionId, isActionRequest) {
            $scope.ACTION = {};
            $http.get('/api/Bid_Action/?id=' + actionId).success(function (data) {
                $scope.ACTION = data;


                var urlActionItes = "Home/GetBidActionItemByTaskId?id=" + actionId;
                bindActionItems(urlActionItes, isActionRequest);
                if (isActionRequest) {
                    $scope.bidName = $scope.ACTION.BidName;
                }

            })
        }
        //Method to Bind actionitems
        function bindActionItems(urlActionItes, isActionRequest) {
            $scope.ACTIONITEMS = [];
            $http.get(urlActionItes).success(function (data) {
                $scope.ACTIONITEMS = data.responseData;
                if ($scope.ACTIONITEMS.length == 0) {
                    $scope.isDeleteAction = true;
                }
                else {
                    $scope.isDeleteAction = false;
                }

                angular.forEach($scope.ACTIONITEMS, function (value, index) {

                    var ActionDateTime = value.Action_dateTime;
                    value.Action_dateTime = new Date(parseInt(ActionDateTime.substr(6)));

                    var ActionDueDateTime = value.ActionDue_dateTime;
                    value.ActionDue_dateTime = new Date(parseInt(ActionDueDateTime.substr(6)));

                    var ReminderDateDateTime = value.ReminderDate_dateTime;
                    value.ReminderDate_dateTime = new Date(parseInt(ReminderDateDateTime.substr(6)));

                })

                if (!isActionRequest) {
                    if ($scope.ACTIONITEMS.length > 0) {
                        $scope.bidName = $scope.ACTIONITEMS[0].BidName;
                    }
                }
            })
        }

    }]);

