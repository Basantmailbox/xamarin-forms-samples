﻿//define the Angular module 
var model = angular.module('app');

model.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

model.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function (file, uploadUrl) {
        var fd = new FormData();
        fd.append('file', file);

        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        })

        .success(function () {
        })

        .error(function () {
        });
    }
}]);



model.filter("Technology_MethodologyName", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].Name;
                break;
            }
        }
        return name;
    }
})

model.filter("PersonnelName", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].ResumeId == Id) {
                name = array[i].Candidate_Name;
                break;
            }
        }
        return name;
    }
})

model.filter("GetName", function () {
    return function (strvar, Id, array) {
        var name;
        for (var i = 0; i < array.length; i++) {
            if (array[i].Id == Id) {
                name = array[i].TopicName;
                break;
            }
        }
        return name;
    }
})

model.controller("contract", ['$scope', '$http', '$modal', '$rootScope', '$log', 'fileUpload', 'ContractService', '$sce', 'ActivityService', 'toaster','departmentService',
    function ($scope, $http, $modal, $log, fileUpload, $rootScope, ContractService, $sce, ActivityService, toaster,departmentService) {

    $scope.filterChanged = function (arr) {
        angular.forEach(arr, function (value, index) {
            $scope.totalContractValue = $scope.totalContractValue + value.ContractValue;
        })
    }
    $scope.addNew = $scope.showLink('ContractForm.ButtonNew');
    $scope.editold = $scope.showLink('ContractForm.EditRight');
    $scope.delete = $scope.showLink('ContractForm.DeleteRight');
    $scope.isdeleted = false;
    $scope.myContracts = [];
    $scope.myContracts_Archived = [];
    $scope.RecordStates = [];
    $scope.currentRecordId = 0;
    $scope.defaultRecordstateId = 0;
    $scope.currentIndex = 0;
    $scope.showList = true;
    $scope.showForm = false;
    $scope.showView = false;
    $scope.TaskDropdown = []; // Dropown for storing task values
    $scope.amActionable = true;   //required for Workflow implementation
    $scope.listRecordPermissions = []; //required for Workflow implementation
    $scope.isAdding = false;
    $scope.isEditing = false;
    $scope.isloading = true;
    $scope.contractsCount = 0;
    $scope.contractsCount_Archived = 0;
    $scope.HcontractsCount = 0;
    $scope.isAdmin = true;
    $scope.isEmailSending = false;
    $scope.fileName = {};
    $scope.imageNames = [];
    $scope.isIframe = false;
    $scope.fullFilePath = "";
    $scope.viewerFullFilePath = "";
    $scope.TrustedviewerFullFilePath = "";
    $scope.documents_mainPage = [];
    $scope.isAttachmentUploading = false;
    $scope.attachments = [];
    $scope.workflowButtons = {};
    $scope.selectedButton = '';
    $scope.imageAttachments = [];
    $scope.iframeHeight = window.innerHeight;
    $scope.submissionPending = true;
    $scope.generalContractInfo_currentRecordId = 0;
    $scope.generalContractInfo_isFetched = false;
    $scope.specificContractInfo = [];
    $scope.showSpecificPPList = true;
    $scope.selectedSpecificPPIndex = 0;
    $scope.selectedSpecificPP_currentRecordId = 0;
    $scope.newSpecificPP = false;
    $scope.SpecificPP = {};
    $scope.newrecord = {};
    $scope.oldrecord = {};
    $scope.radioModel = 'Active';
    $scope.documentID = 0;
    $scope.documentNAME = "";
    $scope.documentFILETYPE = "";
    //$scope.isTaskOrder = false;
    //$scope.isTaskOrderReadonly = false;
    $scope.mouseover_spdamt = false;
    $scope.mouseover_fndamt = false;
    $scope.mouseover_celval = false;
    $scope.mouseover_ylyamt = false;

    $scope.technologiesList = [];
    $scope.methodologiesList = [];
    $scope.personnelList = [];
    $scope.contractHistory = [];

    $scope.selectedTechnology = 0;
    $scope.selectedMethodology = 0;
    $scope.selectedPersonnel = 0;

    $scope.backup_technologies = [];
    $scope.backup_methodologies = [];
    $scope.backup_personnel = [];

    $scope.technologiesIndex = [];
    $scope.technologiesCount = 0;

    $scope.methodologiesIndex = [];
    $scope.methodologiesCount = 0;

    $scope.personnelIndex = [];
    $scope.personnelCount = 0;
    $scope.departments = [];
    $scope.allDepartments = [];
    $scope.validation1 = "";
    $scope.validation2 = "";
    $scope.showerror = false;
    //+++++++++++++++++++++++++++WORKFLOW RELATED EVENTS START++++++++++++++++++++++++++++//

    //Fetch the eligible previous,current and next workflow buttons for a RecordState
    //called from SelectedContract
    $scope.getWorkFlowButtons = function (recordstateId) {

        //In case of old records, current recordstate may not exist.
        //In such a case, fetch the default button details 
        if (recordstateId == 0) {
            $scope.states = $scope.RecordStates;
            if ($scope.states.length == 0) {
                $scope.workflowButtons = [];
                $scope.currentRecordStateId = recordstateId;
            } else {
                $scope.workflowButtons = [];
                $scope.currentRecordStateId = 0;  //nothing selected
                var workflowDefaultbutton = {
                    Description: $scope.states[0].Description,
                    Modulename: "Contract",
                    Name: "",
                    NotifyUsers: "",
                    Order: 1,
                    Permission: 1,
                    RecordPermission: 1,
                    RecordState: $scope.states[0].Id,
                    RecordStateId: $scope.states[0].Id,
                    Recordstatename: $scope.states[0].Recordstatename,
                    RoleId: 0,
                    RolenRecordStateId: 0
                }
                $scope.workflowButtons.push(workflowDefaultbutton)
            }

        } else {
            $http.get("/Home/GetRole_n_RecordStates?RoleId=" + $scope.app.roleid + "&Modulename=Contract&recordStateId=" + recordstateId).success(function (data) {
                $scope.workflowButtons = data.recStatesList;
                $scope.currentRecordStateId = recordstateId;
            })
        }

    }

    //Workflow button click event
    //called from Contract Form HTML
    $scope.updateSelectedButton = function (button) {
        var obj = JSON.parse(button);

        //i.e. if pressed button is NOT ReadOnly
        if (obj.Permission != 2) {
            var selectedId = obj.RecordStateId;

            //update Contract record in database
            ContractService.workflowUpdateCall().updateRecordState($scope.currentRecordId, selectedId);

            //update Contract record list
            angular.forEach($scope.myContracts, function (value, index) {
                if (value.Id == $scope.currentRecordId) { $scope.currentIndex = index; return true; }
            })


            var oldrecordstateId = $scope.myContracts[$scope.currentIndex].RecordStateId;

            var oldRecordstate = $scope.myContracts[$scope.currentIndex].RecordState;
            if (oldRecordstate == "") { oldRecordstate = "NONE"; }

            $scope.myContracts[$scope.currentIndex].RecordStateId = selectedId;
            $scope.myContracts[$scope.currentIndex].RecordState = $scope.retRecordStateName(selectedId);

            var newRecordstate = $scope.myContracts[$scope.currentIndex].RecordState;
            var newrecordstateId = $scope.myContracts[$scope.currentIndex].RecordStateId;

            $scope.myContracts[$scope.currentIndex].RecordPermission = $scope.retRecordStatePermission(selectedId);

            var emailBody = "Contract No." + $scope.myContracts[$scope.currentIndex].ContnTask + " " + $scope.myContracts[$scope.currentIndex].Contractname;

            var receipients = "";
            $http.get("/Home/GetRole_n_RecordStates_NotifyUsers?RoleId=" + $scope.app.roleid + "&Modulename=Contract&oldrecordStateId=" + oldrecordstateId + "&newrecordStateId=" + newrecordstateId).success(function (data) {
                var receipients = data.users;
                //send notifications
                $http.post("/Home/SendNotifications?users=" + receipients + "&module=Contract&recordTitle=" + emailBody + "&changedFrom=" + oldRecordstate + "&changedTo=" + newRecordstate);
            });

            //$scope.getWorkFlowButtons(selectedId);
          
        }

    }
    //$http.get('/Home/GetFullAgencies').success(function (data) {
    //    $scope.departments = data.fullAgencyList;
    //}).error(function (data) {
       
    //})
    $http.get('/Home/GetDepartments').success(function (data) {
        $scope.allDepartments = data.agencyList;
    }).error(function (data) {

    })
    $scope.getAgency = function (deptId) {
        $scope.objContract.AgencyName = "";
        $scope.objContract.AgencyId = "";
        angular.forEach($scope.allDepartments, function (value, indeX) {
            if (value.Id == deptId) {
                $scope.objContract.DepartmentName = value.Agencyname;
            }
        })
        $http.get('/Home/GetAgencies?departmentId=' + deptId).success(function (data) {
            $scope.departments = data.agencyList;
        })
    }
   
    //called from contract load
    $scope.retRecordStateName = function (selectedId) {
        var name = "";
        angular.forEach($scope.RecordStates, function (value, index) {
            if (value.Id == selectedId) { name = value.Recordstatename; }
        })
        return name;
    }

    //called from contract load
    $scope.retRecordStatePermission = function (selectedId) {
        var permissionValue = 0;
        angular.forEach($scope.listRecordPermissions, function (value, index) {
            if (value.RecordState == selectedId) { permissionValue = value.RecordPermission; }
        })
        return permissionValue;
    }

    //++++++++++++++++++++++++++++WORKFLOW RELATED EVENTS END++++++++++++++++++++++++++++//

    $scope.showimage = function (uniquename, filename, filetype, filepath) {
        $scope.documentID = uniquename;
        $scope.documentNAME = filename;
        $scope.documentFILETYPE = filetype;
        $scope.fullFilePath = filepath + $scope.documentID;
        $scope.viewerFullFilePath = "<iframe src='https://docs.google.com/viewer?url=" + filepath + $scope.documentID + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
        $scope.TrustedviewerFullFilePath = $sce.trustAsHtml($scope.viewerFullFilePath);
        $scope.isIframe = true;
    }

    $scope.contractTypeClick = function (val) {
      
        if (val == "IQ") {
            $scope.objContract.isTaskOrderReadonly = true;
        }
        else {
            $scope.objContract.isTaskOrderReadonly = false;
        }
    }

    $scope.taskOrderCheckClick = function (val) {
        if(val==false)
        {
            $scope.objContract.TaskOrderNumber = "";
        }
    }

    //var objForm = this.contractForm;
    $scope.specificPP = {
        addnew: $scope.showLink('ContractForm.SpecificPastPerformance.ButtonNew'),
        editold: $scope.showLink('ContractForm.SpecificPastPerformance.EditRight'),
        deleteold: $scope.showLink('ContractForm.SpecificPastPerformance.DeleteRight')
    }



    //for contract_technologies permissions
    $scope.technologies = {
        addnew: $scope.showLink('ContractForm.Technologies.ButtonNew'),
        editold: $scope.showLink('ContractForm.Technologies.EditRight'),
        deleteold: $scope.showLink('ContractForm.Technologies.DeleteRight'),
        isadding: false,
        isediting: false,
        currentIndex: 0
    }

    //for contract_methodologies permissions
    $scope.methodologies = {
        addnew: $scope.showLink('ContractForm.Methodologies.ButtonNew'),
        editold: $scope.showLink('ContractForm.Methodologies.EditRight'),
        deleteold: $scope.showLink('ContractForm.Methodologies.DeleteRight'),
        isadding: false,
        isediting: false,
        currentIndex: 0
    }

    //for contract_personnel permissions
    $scope.personnel = {
        addnew: $scope.showLink('ContractForm.Personnel.ButtonNew'),
        editold: $scope.showLink('ContractForm.Personnel.EditRight'),
        deleteold: $scope.showLink('ContractForm.Personnel.DeleteRight'),
        isadding: false,
        isediting: false,
        currentIndex: 0
    }

    $scope.Tab = {
        tab1: true,
        tab2: false,
        tab3: false,
        tab4: false,
        tab5: false,
        tab6: false,
        tab7: false
    }

    // Pagination control related (Active list)
    $scope.currentPage = 0;
    $scope.startindex = 0;
    $scope.maxSize = 99;
    $scope.pageBoundary = 1;
    $scope.bigTotalItems = 1000;
    $scope.bigCurrentPage = 1;
    $scope.pageChanged = function (pagenum,sizevalue) {
        $scope.startindex = (pagenum * sizevalue) - sizevalue;
    };

    $scope.$watch('maxSize', function () {
        updatepaging();
    })
    function updatepaging(){
        $scope.currentPage = 1;
        var pagecount = ($scope.contractsCount / $scope.maxSize);
        var decimalpart = pagecount % 1;
        $scope.pageBoundary = Math.floor(pagecount);  //integer part from pagecount
        if (decimalpart > 0) {
            $scope.pageBoundary = $scope.pageBoundary + 1;
        }
        if ($scope.pageBoundary == 0) { $scope.pageBoundary = $scope.pageBoundary + 1; }
        $scope.startindex = ($scope.currentPage * $scope.maxSize) - $scope.maxSize;
    }
    $scope.updateContractGridSize = function (sizeValue) {
        $scope.currentPage = 1;
        var pagecount = ($scope.contractsCount / sizeValue);
        var decimalpart = pagecount % 1;
        $scope.pageBoundary = Math.floor(pagecount);  //integer part from pagecount
        if (decimalpart > 0) {
            $scope.pageBoundary = $scope.pageBoundary + 1;
        }
        if ($scope.pageBoundary == 0) { $scope.pageBoundary = $scope.pageBoundary + 1; }
        $scope.startindex = ($scope.currentPage * sizeValue) - sizeValue;
    }
    // Pagination control related (Archived list)
    $scope.currentPage_Archived = 0;
    $scope.startindex_Archived = 0;
    $scope.maxSize_Archived = 99;
    $scope.pageBoundary_Archived = 1;
    $scope.bigTotalItems_Archived = 1000;
    $scope.bigCurrentPage_Archived = 1;
    $scope.pageChanged_Archived = function (pagenum,sizevalue) {
        $scope.startindex_Archived = (pagenum * sizevalue) - sizevalue;
    };

    $scope.$watch('maxSize_Archived', function () {
        updateArchivedpaging();
    })
    function updateArchivedpaging() {
        $scope.currentPage_Archived = 1;
        var pagecount = ($scope.contractsCount_Archived / $scope.maxSize_Archived);
        var decimalpart = pagecount % 1;
        $scope.pageBoundary_Archived = Math.floor(pagecount);  //integer part from pagecount
        if (decimalpart > 0) {
            $scope.pageBoundary_Archived = $scope.pageBoundary_Archived + 1;
        }
        if ($scope.pageBoundary_Archived == 0) { $scope.pageBoundary_Archived = $scope.pageBoundary_Archived + 1; }
        $scope.startindex_Archived = ($scope.currentPage_Archived * $scope.maxSize_Archived) - $scope.maxSize_Archived;
    }
    $scope.updateContractArchivedGridSize = function (sizeValue) {
        $scope.currentPage_Archived = 1;
        var pagecount = ($scope.contractsCount_Archived / sizeValue);
        var decimalpart = pagecount % 1;
        $scope.pageBoundary_Archived = Math.floor(pagecount);  //integer part from pagecount
        if (decimalpart > 0) {
            $scope.pageBoundary_Archived = $scope.pageBoundary_Archived + 1;
        }
        if ($scope.pageBoundary_Archived == 0) { $scope.pageBoundary_Archived = $scope.pageBoundary_Archived + 1; }
        $scope.startindex_Archived = ($scope.currentPage_Archived * sizeValue) - sizeValue;
    }
    
    // Pagination control related
    $scope.HcurrentPage = 0;
    $scope.LcurrentPage = 0;
    $scope.Hstartindex = 0;
    $scope.HpageChanged = function (pageno) {
        $scope.Hstartindex = (pageno * $scope.maxSize) - $scope.maxSize;
    };

    //DTO model
    var objContract = {
        Id: 0,
        Contractnum: "",
        Contractname: "",
        TaskOrderNumber: "",
        AgencyName: "",
        AgencyId: "",
        DepartmentName: "",
        DepartmentId: "",
        ContractAwardDate: null,
        ContractStartDate: null,
        ContractEndDate: null,
        ContractType: "",
        PrimeSub: "",
        CORname: "",
        CORaddress: "",
        CORphoneno: "",
        CORemail: "",
        COname: "",
        COaddress: "",
        COphoneno: "",
        COemail: "",
        POname: "",
        POaddress: "",
        POphoneno: "",
        POemail: "",
        PMname: "",
        PMaddress: "",
        PMphoneno: "",
        PMemail: "",
        RecordStateId: 0,
        ContractValue: 0,
        CeleingAmount: 0,
        FundingAmount: 0,
        SpendingAmount: 0,
        YearlyAmount: 0,
        ContractDescription: "",
        Attachments: [],
        ContractActualEndDate: null,
        RecordState: "",
        RecordPermission: 0,
        isTaskOrder: false,
        isTaskOrderReadonly:false
    }

    var library_mainPage = {
        fileName: "",
        fileId: 0,
        fileInternalName: "",
        fileType: "",
        filePath: ""
    }

    var attachmentModel = {
        Id: 0,
        ticketId: 0,
        ImagePath: ""
    }

    var objContractGeneralPP = {
        Id: 0,
        ContractId: 0,
        Description: ""
    }

    var objContractSpecificPP = {
        Id: 0,
        ContractId: 0,
        TaskName: "",
        Description: "",
        TopicId: null
    }

    var objContractTechnology = {
        Id: 0,
        ContractId: 0,
        TechnologyId: 0,
        Description: '',
        Add: false,
        Edit: false,
        Delete: false,
        Name: ''
    }

    var objContractMethodology = {
        Id: 0,
        ContractId: 0,
        MethodologyId: 0,
        Description: '',
        Add: false,
        Edit: false,
        Delete: false,
        Name: ''
    }

    var objContractPersonnel = {
        Id: 0,
        ContractId: 0,
        ProfileId: 0,
        Remarks: '',
        Add: false,
        Edit: false,
        Delete: false,
        Name: ''
    }

    var objgeneralContractInfo = {
        generalContractInfo1: ""
    }

    $scope.generalContractInfo = objgeneralContractInfo;

    //upload file
    $scope.uploadFile = function () {
        var file = $scope.myFile;

        var uploadUrl = "/docsUpload";
        fileUpload.uploadFileToUrl(file, uploadUrl);
    };

    $scope.resetCheckBox = function () {
        $scope.objContract.isTaskOrder = false;
        $scope.objContract.isTaskOrderReadonly = false;
        $scope.isAdding = true; 
        $scope.isEditing = false;
        
    }
    $scope.toggleShowList = function () {
        $scope.attachments = [];

        $scope.showList = !$scope.showList;
        $scope.showForm = !$scope.showForm;
        $scope.objContract = angular.copy(objContract);
    }

    $scope.toggleBackToList = function () {
        $scope.showList = true;
        $scope.showForm = false;
        $scope.showView = false;
    };

    //format date in date-time-picker control
    $scope.formatdate = function (sdate) {
        var d = new Date(sdate);
        var currDay = "";
        if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
        var currMonth = "";
        if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
        var currYear = d.getFullYear();
        var startDate = currMonth + "/" + currDay + "/" + currYear;
        return startDate;
    }


    //api service call of all data together
    ContractService.assortedCalls().loadAllCalls()
        .then(function (response) {
            $scope.allDataSet = response;

            $scope.TaskDropdown = $scope.allDataSet[0].data;
            $scope.myContracts = $scope.allDataSet[1].data;
            $scope.totalContractValue = 0;
            angular.forEach($scope.myContracts, function (value, index) {
                $scope.totalContractValue = $scope.totalContractValue + value.ContractValue;
            })
            $scope.contractsCount = $scope.myContracts.length;
            updatepaging();
            updateArchivedpaging();
            //------------------------------------
            //needed for workflow implementation
            $scope.listRecordPermissions = $scope.allDataSet[7].data.data;
            $scope.RecordStates = $scope.allDataSet[6].data;
            if ($scope.RecordStates.length > 0) {
                $scope.defaultRecordstateId = $scope.RecordStates[0].Id;
            }
            //-------------------------------------

            angular.forEach($scope.myContracts, function (value, index) {
                //------------------------------------
                //needed for workflow implementation
                value['RecordState'] = $scope.retRecordStateName(value.RecordStateId);
                value['RecordPermission'] = $scope.retRecordStatePermission(value.RecordStateId);
                //-------------------------------------

                if (value.TaskOrderNumber != '')
                    value['ContnTask'] = value.Contractnum + '-' + value.TaskOrderNumber;
                else
                    value['ContnTask'] = value.Contractnum;
            })
            $scope.isloading = false;
            if ($scope.myContracts.length > 0) {
                angular.forEach($scope.myContracts, function (value, index) {
                    if ($scope.myContracts[index].Constant_Type == 'TaskName') { $scope.bidtypeDrpDwn.push($scope.myContracts[index]); }
                })
                $scope.bidCount = $scope.myContracts.length;
            }

            $scope.technologiesList = $scope.allDataSet[2].data;

            $scope.methodologiesList = $scope.allDataSet[3].data;

            $scope.personnelList = $scope.allDataSet[4].data;

            $scope.myContracts_Archived = $scope.allDataSet[5].data;
            $scope.contractsCount_Archived = $scope.myContracts_Archived.length;


        })

    //---------------------------contract methods--------------------------------------

    $scope.getTechnologyName = function (id) {
        var toreturn = "";
        angular.forEach($scope.technologiesList, function (valueX, indexX) {
            if (valueX.Id == id) {
                toreturn = valueX.Name;
            }
        })
        return toreturn;
    };

    $scope.getMethodologyName = function (id) {
        var toreturn = "";
        angular.forEach($scope.methodologiesList, function (valueY, indexY) {
            if (valueY.Id == id) {
                toreturn = valueY.Name;
            }
        })
        return toreturn;
    };

    $scope.getPersonnelName = function (id) {
        var toreturn = "";
        angular.forEach($scope.personnelList, function (valueZ, indexZ) {
            if (valueZ.Id == id) {
                toreturn = valueZ.Candidate_Name;
            }
        })
        return toreturn;
    };

    //derive from Technology selection
    $scope.setcodeA = function (selection) {
        $scope.selectedTechnology = selection.Id;
    };

    //derive from Methodology selection
    $scope.setcodeB = function (selection) {
        $scope.selectedMethodology = selection.Id;
    };

    //derive from Resources selection
    $scope.setcodeC = function (selection) {
        $scope.selectedPersonnel = selection.ResumeId;
    };

    $scope.getHistory = function (id) {
        //contractHistory
        $http.get('/api/Contract_History/' + id).success(function (data) {
            $scope.contractHistory = data;
            $scope.HcontractsCount = data.length;
        })
    }


    //----------------------------------------------------------------
    // New technology add button click
    $scope.newTechnologyAdd = function () {
        $scope.backup_technologies = angular.copy($scope.objContract.ContractTechnologies);  //will be used in case of undo

        $scope.itmContractTechnology = {
            Id: 0,
            ContractId: 0,
            TechnologyId: 0,
            Description: '',
            Add: false,
            Edit: false,
            Delete: false,
            Name: ''
        }

        $scope.objContract.ContractTechnologies.push($scope.itmContractTechnology);
        $scope.technologies.currentIndex = $scope.objContract.ContractTechnologies.length - 1;

        $scope.objContract.ContractTechnologies[$scope.technologies.currentIndex].Add = true;
        $scope.objContract.ContractTechnologies[$scope.technologies.currentIndex].Id = 3000;
    }

    // New methodology add button click
    $scope.newMethodologyAdd = function () {
        $scope.backup_methodologies = angular.copy($scope.objContract.ContractMethodologies);  //will be used in case of undo

        $scope.itmContractMethodology = {
            Id: 0,
            ContractId: 0,
            MethodologyId: 0,
            Description: '',
            Add: false,
            Edit: false,
            Delete: false,
            Name: ''
        }

        $scope.objContract.ContractMethodologies.push($scope.itmContractMethodology);
        $scope.methodologies.currentIndex = $scope.objContract.ContractMethodologies.length - 1;

        $scope.objContract.ContractMethodologies[$scope.methodologies.currentIndex].Add = true;
        $scope.objContract.ContractMethodologies[$scope.methodologies.currentIndex].Id = 3000;
    }

    // New personnel add button click
    $scope.newPersonnelAdd = function () {
        $scope.backup_personnel = angular.copy($scope.objContract.ContractResources);  //will be used in case of undo

        $scope.itmContractPersonnel = {
            Id: 0,
            ContractId: 0,
            ProfileId: 0,
            Remarks: '',
            Add: false,
            Edit: false,
            Delete: false,
            Name: ''
        }

        $scope.objContract.ContractResources.push($scope.itmContractPersonnel);
        $scope.personnel.currentIndex = $scope.objContract.ContractResources.length - 1;

        $scope.objContract.ContractResources[$scope.personnel.currentIndex].Add = true;
        $scope.objContract.ContractResources[$scope.personnel.currentIndex].Id = 3000;
    }

    //General method to edit a record (for Technologies / Methodologies / Personnel)
    $scope.editoldInstance = function (Id, RecordType) {
        switch (RecordType) {
            case 'Technology':
                $scope.backup_technologies = angular.copy($scope.objContract.ContractTechnologies);  //will be used in case of undo

                angular.forEach($scope.objContract.ContractTechnologies, function (value, index) {
                    if (value.Id == Id) { value.Edit = true; objContractTechnology = value; }
                })
                break;

            case 'Methodology':
                $scope.backup_methodologies = angular.copy($scope.objContract.ContractMethodologies);  //will be used in case of undo

                angular.forEach($scope.objContract.ContractMethodologies, function (value, index) {
                    if (value.Id == Id) { value.Edit = true; objContractMethodology = value; }
                })
                break;
            case 'Personnel':
                $scope.backup_personnel = angular.copy($scope.objContract.ContractResources);  //will be used in case of undo

                angular.forEach($scope.objContract.ContractResources, function (value, index) {
                    if (value.Id == Id) { value.Edit = true; objContractPersonnel = value; }
                })
                break;
            default:
        }
    }

    //General method to save (during insert / edit) a record (for Technologies / Methodologies / Personnel)
    $scope.saveInstance = function (Id, RecordType) {
        switch (RecordType) {
            case 'Technology':
                if ($scope.technologies.isadding)    //i.e. new addition
                {
                    objContractTechnology = $scope.objContract.ContractTechnologies[$scope.technologies.currentIndex];
                    objContractTechnology.ContractId = $scope.objContract.Id;           //set the contract Id
                    objContractTechnology.TechnologyId = $scope.selectedTechnology;   //set the selected technology
                    $http.post('/api/ContractTechnologies', objContractTechnology).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(31);
                        $scope.objContract.ContractTechnologies[$scope.technologies.currentIndex] = data;
                        $scope.objContract.ContractTechnologies[$scope.technologies.currentIndex].Add = false;
                        $scope.objContract.ContractTechnologies[$scope.technologies.currentIndex].Edit = false;
                        toaster.pop('success', 'Success', "Technology added successfully");
                        $scope.technologies.isadding = false;
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while adding Technology");
                    })
                }
                if ($scope.technologies.isediting)    //i.e. existing modification
                {
                    objContractTechnology.TechnologyId = $scope.selectedTechnology;   //set the selected technology
                    $http.put('/api/ContractTechnologies?id=' + Id, objContractTechnology).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(32);
                        angular.forEach($scope.objContract.ContractTechnologies, function (value, index) {
                            if (value.Id == Id) {
                                value.Add = false; value.Edit = false;
                            }
                        })
                        toaster.pop('success', 'Success', "Technology updated successfully");
                        $scope.technologies.isediting = false;
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while updating Technology");
                    })
                }
                break;

            case 'Methodology':
                if ($scope.methodologies.isadding)    //i.e. new addition
                {
                    objContractMethodology = $scope.objContract.ContractMethodologies[$scope.methodologies.currentIndex];
                    objContractMethodology.ContractId = $scope.objContract.Id;           //set the contract Id
                    objContractMethodology.MethodologyId = $scope.selectedMethodology;   //set the selected technology
                    $http.post('/api/ContractMethodologies', objContractMethodology).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(34);
                        $scope.objContract.ContractMethodologies[$scope.methodologies.currentIndex] = data;
                        $scope.objContract.ContractMethodologies[$scope.methodologies.currentIndex].Add = false;
                        $scope.objContract.ContractMethodologies[$scope.methodologies.currentIndex].Edit = false;
                        toaster.pop('success', 'Success', "Methodology added successfully");
                        $scope.methodologies.isadding = false;
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while adding Methodology");
                    })
                }
                if ($scope.methodologies.isediting)    //i.e. existing modification
                {
                    objContractMethodology.MethodologyId = $scope.selectedMethodology;   //set the selected methodology
                    $http.put('/api/ContractMethodologies?id=' + Id, objContractMethodology).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(35);
                        angular.forEach($scope.objContract.ContractMethodologies, function (value, index) {
                            if (value.Id == Id) {
                                value.Add = false; value.Edit = false;
                            }
                        })
                        toaster.pop('success', 'Success', "Methodology updated successfully");
                        $scope.methodologies.isediting = false;
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while updating Methodology");
                    })
                }
                break;
            case 'Personnel':
                if ($scope.personnel.isadding)    //i.e. new addition
                {
                    objContractPersonnel = $scope.objContract.ContractResources[$scope.personnel.currentIndex];
                    objContractPersonnel.ContractId = $scope.objContract.Id;           //set the contract Id
                    objContractPersonnel.ProfileId = $scope.selectedPersonnel;         //set the selected profile
                    $http.post('/api/ContractPersonnels', objContractPersonnel).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(43);
                        $scope.objContract.ContractResources[$scope.personnel.currentIndex] = data;
                        $scope.objContract.ContractResources[$scope.personnel.currentIndex].Add = false;
                        $scope.objContract.ContractResources[$scope.personnel.currentIndex].Edit = false;
                        toaster.pop('success', 'Success', "Personnel added successfully");
                        $scope.personnel.isadding = false;
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while adding Personnel");
                    })
                }
                if ($scope.personnel.isediting)    //i.e. existing modification
                {
                    objContractPersonnel.ProfileId = $scope.selectedPersonnel;         //set the selected profile
                    $http.put('/api/ContractPersonnels?id=' + Id, objContractPersonnel).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(44);
                        angular.forEach($scope.objContract.ContractResources, function (value, index) {
                            if (value.Id == Id) {
                                value.Add = false; value.Edit = false;
                            }
                        })
                        toaster.pop('success', 'Success', "Personnel updated successfully");
                        $scope.personnel.isediting = false;
                    })
                    .error(function(data)
                    {
                        toaster.pop('error', 'Error', "An error occured while updating Personnel");
                    })
                }
                break;
            default:
        }
    }

    //General method to delete a record (for Technologies / Methodologies / Personnel)
    $scope.deleteInstance = function (Id, RecordType) {
        switch (RecordType) {
            case 'Technology':
                var ans = confirm("Are you sure you want to delete this technology?");
                if (ans) {
                    var indx = 0;
                    angular.forEach($scope.objContract.ContractTechnologies, function (value, index) {
                        if (value.Id == Id) { indx = index; }
                    })
                    $scope.objContract.ContractTechnologies.splice(indx, 1);

                    $http.delete('/api/ContractTechnologies?id=' + Id).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(33);
                        toaster.pop('success', 'Success', "Technology deleted successfully");
                    })
                    .error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while deleting Technology");
                    })
                }
                break;

            case 'Methodology':
                var ans = confirm("Are you sure you want to delete this methodology?");
                if (ans) {
                    var indx = 0;
                    angular.forEach($scope.objContract.ContractMethodologies, function (value, index) {
                        if (value.Id == Id) { indx = index; }
                    })
                    $scope.objContract.ContractMethodologies.splice(indx, 1);

                    $http.delete('/api/ContractMethodologies?id=' + Id).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(36);
                        toaster.pop('success', 'Success', "Methodology deleted successfully");
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while deleting Methodology");
                    })
                }
                break;

            case 'Personnel':
                var ans = confirm("Are you sure you want to delete this person?");
                if (ans) {
                    var indx = 0;
                    angular.forEach($scope.objContract.ContractResources, function (value, index) {
                        if (value.Id == Id) { indx = index; }
                    })
                    $scope.objContract.ContractResources.splice(indx, 1);

                    $http.delete('/api/ContractPersonnels?id=' + Id).success(function (data) {
                        ActivityService.assortedCalls().saveAllCalls(45);
                        toaster.pop('success', 'Success', "Personnel deleted successfully");
                    }).error(function (data) {
                        toaster.pop('error', 'Error', "An error occured while deleting Personnel");
                    })
                }
                break;
            default:
        }
    }

    //General method to undo a record (for Technologies / Methodologies / Personnel)
    $scope.cancelInstance = function (Id, RecordType) {
        switch (RecordType) {
            case 'Technology':
                $scope.technologies.isadding = false;
                $scope.technologies.isediting = false;
                $scope.objContract.ContractTechnologies = angular.copy($scope.backup_technologies);  //restore from backup

                angular.forEach($scope.objContract.ContractTechnologies, function (value, index) {
                    if (value.Id == Id) { value.Add = false; value.Edit = false; }
                })
                break;
            case 'Methodology':
                $scope.methodologies.isadding = false;
                $scope.methodologies.isediting = false;
                $scope.objContract.ContractMethodologies = angular.copy($scope.backup_methodologies);  //restore from backup

                angular.forEach($scope.objContract.ContractMethodologies, function (value, index) {
                    if (value.Id == Id) { value.Add = false; value.Edit = false; }
                })
                break;
            case 'Personnel':
                $scope.personnel.isadding = false;
                $scope.personnel.isediting = false;
                $scope.objContract.ContractResources = angular.copy($scope.backup_personnel);  //restore from backup

                angular.forEach($scope.objContract.ContractResources, function (value, index) {
                    if (value.Id == Id) { value.Add = false; value.Edit = false; }
                })
                break;
            default:

        }
    }

    //----------------------------------------------------------------
    //get ready to edit/delete/view Contract
    $scope.selectedContract = function (index, type, arrayindex) {
        var ID = index;
        $scope.submissionPending = false;
        $http.get('/api/Contracts/' + ID).success(function (data) {

            if (data.Id == 0) {
            } else {

                $scope.objContract = data;
                $http.get('/Home/GetAgencies?departmentId=' + $scope.objContract.DepartmentId).success(function (data) {
                    $scope.departments = data.agencyList;
                })
                //------------------------------------
                //needed for workflow implementation
                $scope.objContract.RecordState = $scope.retRecordStateName($scope.objContract.RecordStateId);
                $scope.objContract.RecordPermission = $scope.retRecordStatePermission($scope.objContract.RecordStateId);
                //------------------------------------

                if ($scope.objContract.ContractAwardDate != null) { $scope.objContract.ContractAwardDate = $scope.formatdate($scope.objContract.ContractAwardDate); }
                if ($scope.objContract.ContractStartDate != null) { $scope.objContract.ContractStartDate = $scope.formatdate($scope.objContract.ContractStartDate); }
                if ($scope.objContract.ContractEndDate != null) { $scope.objContract.ContractEndDate = $scope.formatdate($scope.objContract.ContractEndDate); }
                if ($scope.objContract.ContractActualEndDate != null) { $scope.objContract.ContractActualEndDate = $scope.formatdate($scope.objContract.ContractActualEndDate); }

                //Set taskOrder checkbox state
                if ($scope.objContract.TaskOrderNumber != "") {
                    $scope.objContract.isTaskOrder = true;
                    $scope.objContract.isTaskOrderReadonly = false;
                } else {
                    $scope.objContract.isTaskOrder = false;
                    $scope.objContract.isTaskOrderReadonly = false;
                }
                if ($scope.objContract.ContractType == "IQ") {
                    $scope.objContract.isTaskOrderReadonly = true;
                } else {
                    $scope.objContract.isTaskOrderReadonly = false;
                }

                //Fetch the eligible previous,current and next workflow buttons
                $scope.getWorkFlowButtons($scope.objContract.RecordStateId);


                //Fetch Past Performance Contract General if exists
                var id = $scope.objContract.Id;
                $http.get('/api/PastPerformance_ContractGeneral/' + id).success(function (data1) {
                    if (data1 != "") {
                        $scope.generalContractInfo.generalContractInfo1 = data1.Description;
                        $scope.generalContractInfo_isFetched = true;   //during saving $put will be called
                        $scope.generalContractInfo_currentRecordId = data1.Id;
                    } else {
                        $scope.generalContractInfo.generalContractInfo1 = "";
                        $scope.generalContractInfo_isFetched = false;  //during saving $post will be called
                        $scope.generalContractInfo_currentRecordId = 0;
                    }
                })

                //Fetch Past Performance Contract Specific if exists
                $http.get('/api/PastPerformance_ContractSpecific/' + id).success(function (data2) {
                    if (data2 != "") {
                        $scope.specificContractInfo = data2;
                    } else {
                        $scope.specificContractInfo = [];
                    }
                })

                //Fetch the library documents on Main page
                $http.get('/api/Library/Index?module=Contract&moduleId=' + id).success(function (data3) {
                    if (data3 != "") {
                        $scope.documents_mainPage = data3;
                    } else {
                        $scope.documents_mainPage = [];
                    }
                })

                //Fetch history
                $scope.getHistory(ID);

                $scope.currentRecordId = data.Id;

                if (type == 'E') {
                    $scope.attachments = [];
                    $scope.showList = false;
                    $scope.showForm = true;
                    $scope.showView = false;

                }
                else if (type == 'V' && $scope.showList && !$scope.showForm && !$scope.isEditing) {
                    $scope.showList = false;
                    $scope.showForm = false;
                    $scope.showView = true;
                }
                else if (type == 'D') {
                    var ans = confirm("Are you sure you want to delete ?");
                    if (ans) {
                        var indx = 0;
                        angular.forEach($scope.myContracts, function (value, indeX) {
                            if (value.Id == index) { indx = indeX; value.isArchived = true; $scope.myContracts_Archived.push(value); }
                        })
                        $scope.myContracts.splice(indx, 1);
                        $http.delete('/Home/DeleteContract/' + ID).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(30);
                            toaster.pop('success', 'Success', "Contract has been deleted successfully!");
                        }).error(function (data) {
                            $scope.error = "An Error has occurred while deleting Contract! " + data;
                            toaster.pop('error', 'Error', "An Error has occurred while deleting Contract!");
                        });
                    }
                }
                else if (type == 'U') {
                    var ans = confirm("Are you sure you want to restore ?");
                    if (ans) {
                        var indx = 0;
                        angular.forEach($scope.myContracts_Archived, function (value, indeX) {
                            if (value.Id == index) { indx = indeX; value.isArchived = false; $scope.myContracts.push(value); }
                        })
                        $scope.myContracts_Archived.splice(indx, 1);

                        $http.delete('/Home/DeleteContract_Archived/' + ID).success(function (data) {
                            ActivityService.assortedCalls().saveAllCalls(67);
                            toaster.pop('success', 'Success', "Contract has been restored successfully!");
                        }).error(function (data) {
                            $scope.error = "An Error has occurred while restoring Contract! " + data;
                            toaster.pop('error', 'Error', "An Error has occurred while restoring Contract!");
                        });
                    }
                }
                else {
                    //edit

                }
            }
        }).error(function (data1) {
            $scope.error = "An Error has occurred while adding Contract! ";
            toaster.pop('error', 'Error', $scope.error);
        });
    };
    $scope.updateAgencyName=function(objId)
    {
        angular.forEach($scope.departments, function (value, indeX) {
            if (value.Id == objId)
            {
                $scope.objContract.AgencyName = value.Agencyname;
            }
        })
    }
    //insert new Contract / edit exising contract
    $scope.addContract = function () {

        var newRecord = $scope.objContract;
        newRecord.RecordStateId = $scope.defaultRecordstateId;  //needed for workflow implementation
        
        if ($scope.isAdding) {
            $http.post('/api/Contracts/', newRecord).success(function (data) {
                ActivityService.assortedCalls().saveAllCalls(28);
                $scope.currentRecordId = data.Id;
                $scope.myContracts.push(data);
                $scope.objContract.Id = data.Id;
                //--needed for workflow implementation
                $scope.myContracts[$scope.myContracts.length - 1]['RecordState'] = $scope.retRecordStateName($scope.defaultRecordstateId);
                $scope.myContracts[$scope.myContracts.length - 1]['RecordPermission'] = $scope.retRecordStatePermission($scope.defaultRecordstateId);
                //$scope.getWorkFlowButtons($scope.defaultRecordstateId);
                //--

                $scope.currentIndex = $scope.myContracts.length - 1;
                if ($scope.myContracts[$scope.currentIndex].TaskOrderNumber != '')
                    $scope.myContracts[$scope.currentIndex]['ContnTask'] = $scope.myContracts[$scope.currentIndex].Contractnum + '-' + $scope.myContracts[$scope.currentIndex].TaskOrderNumber;
                else
                    $scope.myContracts[$scope.currentIndex]['ContnTask'] = $scope.myContracts[$scope.currentIndex].Contractnum;
                $scope.isAdding = false;
                toaster.pop('success', 'Success', "Contract successfully added.");
            }).error(function (data) {
                $scope.error = "An Error has occurred while adding Contract! " + data;
                toaster.pop('error', 'Error', $scope.error);
            });
        } else {
            $http.put('/api/Contracts/?id=' + newRecord.Id, newRecord).success(function (data) {
                $scope.isEditing = false;
                ActivityService.assortedCalls().saveAllCalls(29);
                var indx = 0;
                angular.forEach($scope.myContracts, function (value, indeX) {
                    if (value.Id == newRecord.Id) { indx = indeX; }
                })
                $scope.myContracts[indx] = newRecord;
                if ($scope.myContracts[indx].TaskOrderNumber != '')
                    $scope.myContracts[indx]['ContnTask'] = $scope.myContracts[indx].Contractnum + '-' + $scope.myContracts[indx].TaskOrderNumber;
                else
                    $scope.myContracts[indx]['ContnTask'] = $scope.myContracts[indx].Contractnum;
                toaster.pop('success', 'Success', "Contract successfully updated.");
                //Fetch history
                $scope.getHistory(newRecord.Id);
            }).error(function (data) {
                $scope.error = "An Error has occurred while editing Contract! " + data;
                toaster.pop('error', 'Error', $scope.error);
            });
        }

        this.contractForm.$setPristine();
        $scope.submissionPending = false;
        $scope.Tab.tab1 = false;
        $scope.Tab.tab2 = true;
        $scope.Tab.tab3 = false;



    }
    //---------------------------------------------------------------------------------
    $scope.CheckNameValidation = function () {
        $http.get("/Home/CheckContract?contractnum=" + $scope.objContract.Contractnum + "&conttaskorder=" + $scope.objContract.TaskOrderNumber + "&cid=" + $scope.objContract.Id).success(function (data) {
            if (data.duplicate == true) {
                $scope.showerror = true;
                if (data.loc == "contract")
                    $scope.validation1 = data.message;
                else if (data.loc == "taskorder")
                    $scope.validation2 = data.message;
            }
            else if (data.duplicate == false) {
                $scope.showerror = false;
                $scope.validation1 = "";
                $scope.validation2 = "";
            }
        })
    }

    //----------------------------general PP methods-----------------------------------
    //insert contract related General Past Performance / update it in DB
    $scope.saveGeneralPP = function (value) {
        //needs to be added
        if (!$scope.generalContractInfo_isFetched) {
            var objForm = this.contractGeneralPPForm;
            $scope.newrecord = angular.copy(objContractGeneralPP);
            $scope.newrecord.Id = 0;
            $scope.newrecord.ContractId = $scope.currentRecordId;
            $scope.newrecord.Description = value;
            $http.post('/api/PastPerformance_ContractGeneral/', $scope.newrecord).success(function (data) {
                ActivityService.assortedCalls().saveAllCalls(37);
                toaster.pop('success', 'Success', " General Past Performance added successfully");
                objForm.$setPristine();
            }).error(function (data) {
                $scope.error = "An Error has occurred while adding General Past Performance! " + data;
                toaster.pop('error', 'Error', $scope.error);
            });
        }
            //needs to be updated
        else {
            var objForm = this.contractGeneralPPForm;
            $scope.oldrecord = angular.copy(objContractGeneralPP);
            $scope.oldrecord.Id = $scope.generalContractInfo_currentRecordId;
            $scope.oldrecord.ContractId = $scope.currentRecordId;
            $scope.oldrecord.Description = value;
            $http.put('/api/PastPerformance_ContractGeneral/' + $scope.oldrecord.Id, $scope.oldrecord).success(function (data) {
                ActivityService.assortedCalls().saveAllCalls(38);
                toaster.pop('success', 'Success', " General Past Performance updated successfully");
                objForm.$setPristine();
            })
            .error(function (data) {
                $scope.error = "An Error has occurred while updating General Past Performance! " + data;
                toaster.pop('error', 'Error', $scope.error);
            });
        }
    }
    //---------------------------------------------------------------------------------

    //----------------------------specific PP methods----------------------------------

    $scope.toggleShowSpecificPPList = function () {
        $scope.showSpecificPPList = !$scope.showSpecificPPList;
    };

    $scope.newSpecificPPAdd = function () {
        $scope.newSpecificPP = true;
        $scope.SpecificPP = angular.copy(objContractSpecificPP);

        $scope.selectedSpecificPP_currentRecordId = 0;
        $scope.SpecificPP.Id = 0;
        $scope.SpecificPP.ContractId = $scope.currentRecordId;
        $scope.SpecificPP.TaskName = "";
        $scope.SpecificPP.Description = "";
        $scope.SpecificPP.TopicId = null;
    }

    $scope.selectedSpecificPP = function (ID, index, type) {
        $scope.selectedSpecificPPIndex = index;
        var SpecificPPID = $scope.specificContractInfo[index].Id;
        if (type == 'D') {
            var ans = confirm("Are you sure you want to delete the task ?");
            if (ans) {
                $scope.specificContractInfo.splice(index, 1);
                $http.delete('/api/PastPerformance_ContractSpecific/' + SpecificPPID).success(function (data) {
                    ActivityService.assortedCalls().saveAllCalls(42);
                    toaster.pop('success', 'Success', "Task has been deleted successfully!");
                }).error(function (data) {
                    $scope.error = "An Error has occurred while deleting Task! " + data;
                    toaster.pop('error', 'Error', $scope.error);
                });
            }
        }
        else {
            $scope.newSpecificPP = false;
            $scope.SpecificPP = angular.copy(objContractSpecificPP);

            $scope.selectedSpecificPP_currentRecordId = $scope.specificContractInfo[index].Id;
            $scope.SpecificPP.Id = $scope.selectedSpecificPP_currentRecordId;
            $scope.SpecificPP.ContractId = $scope.specificContractInfo[index].ContractId;
            $scope.SpecificPP.TaskName = $scope.specificContractInfo[index].TaskName;
            $scope.SpecificPP.Description = $scope.specificContractInfo[index].Description;
            $scope.SpecificPP.TopicId = $scope.specificContractInfo[index].TopicId;

        }
    }

    $scope.saveSpecificPP = function () {
        var objForm = this.contractSpecificPPForm;
        //insert

        if ($scope.newSpecificPP) {
            $http.post('/api/PastPerformance_ContractSpecific/', $scope.SpecificPP).success(function (data) {
                if (data.Id == 0) {
                } else {
                    ActivityService.assortedCalls().saveAllCalls(40);
                    $scope.selectedSpecificPP_currentRecordId = data.Id;
                    $scope.specificContractInfo.push(data);
                    $scope.newSpecificPP = false;
                    objForm.$setPristine();
                    $scope.toggleShowSpecificPPList();
                    toaster.pop('success', 'Success', " Task added successfully");
                }
            }).error(function (data) {
                $scope.error = "An error has occurred while adding task! " + data;
                toaster.pop('error', 'Error', $scope.error);
            });
            //update
        } else {
            $http.put('/api/PastPerformance_ContractSpecific/' + $scope.selectedSpecificPP_currentRecordId, $scope.SpecificPP).success(function (data) {
                $scope.newSpecificPP = false;
                ActivityService.assortedCalls().saveAllCalls(41);
                $scope.specificContractInfo[$scope.selectedSpecificPPIndex].ContractId = $scope.SpecificPP.ContractId;
                $scope.specificContractInfo[$scope.selectedSpecificPPIndex].TaskName = $scope.SpecificPP.TaskName;
                $scope.specificContractInfo[$scope.selectedSpecificPPIndex].Description = $scope.SpecificPP.Description;
                $scope.specificContractInfo[$scope.selectedSpecificPPIndex].TopicId = $scope.SpecificPP.TopicId;
                objForm.$setPristine();
                $scope.toggleShowSpecificPPList();
                toaster.pop('success', 'Success', " Task updated successfully");
            }).error(function (data) {
                $scope.error = "An error has occurred while updating task!" + data;
                toaster.pop('error', 'Error', $scope.error);
                $scope.loading = false;

            });
        }
    }

    //--------------------------------------------------------------------------------
    $scope.openUploadForm = function () {
        $("#uploadForm").show()
    }

    $scope.sppInstance = '';
    $scope.addTopicModal = function () {
        $scope.sppInstance = $modal.open({
            scope: $scope,
            templateUrl: 'tpl/SpecificPastPerformance.html',
            controller: 'SpecificPastPerformanceController',
        })
    }

    //upload attachment
    $scope.uploadAttachment = function () {
        if ($("#conInfUpload").val() == "") { alert("Select an image to upload.."); return false; }
        $scope.isAttachmentUploading = true;
        var fileUpload = $("#conInfUpload").get(0);
        var files = fileUpload.files;
        var test = new FormData();
        for (var i = 0; i < files.length; i++) {
            test.append(files[i].name, files[i]);
        }
        $.ajax({
            async: true,
            url: "fileUploader.ashx",
            type: "POST",
            contentType: false,
            processData: false,
            data: test,
            // dataType: "json",
            success: function (result) {
                //alert(result);
                if (result.substring(0, 7) == "Success") {

                    var newImgModel = {
                        Id: 0,
                        ticketId: 0,
                        ImagePath: result.substring(8)
                    }

                    $("#ContrUpload").val("");
                    $scope.attachments.push(newImgModel);
                    $scope.isAttachmentUploading = false;
                    $scope.$apply();


                    //$scope.objContract.ContractResources[index]
                    //$http.put('/api/ContractPersonnels/' + $scope.currentRecordId , $scope.oldrecord).success(function (data) {}
                } else {
                    alert("Upload failed. Another image with same name exists!!!");
                }
            },
            error: function (err) {
                alert(err.statusText);
            }
        });

    };

    $scope.modalInstance1 = ''

    $scope.openUpload = function () {
        $scope.modalInstance1 = $modal.open({
            templateUrl: 'tpl/uploadModal.html',
            controller: 'contract',
        })
    };

    $scope.ok = function () {
        $scope.modalInstance1.close();
    };

    $scope.cancel = function () {
        $modalInstance1.dismiss('cancel');
    };

    $scope.uploadAttachment1 = function () {
        if ($("#pUpload").val() == "") { alert("Select an image to upload.."); return false; }
        $scope.isAttachmentUploading = true;
        var fileUpload = $("#pUpload").get(0);
        var files = fileUpload.files;
        var test = new FormData();
        for (var i = 0; i < files.length; i++) {
            test.append(files[i].name, files[i]);
        }
        $.ajax({
            async: true,
            url: "fileUploader.ashx",
            type: "POST",
            contentType: false,
            processData: false,
            data: test,
            // dataType: "json",
            success: function (result) {
                //alert(result);
                if (result.substring(0, 7) == "Success") {

                    var newImgModel = {
                        Id: 0,
                        ticketId: 0,
                        ImagePath: result.substring(8)
                    }

                    $("#ContrUpload").val("");
                    $scope.attachments.push(newImgModel);
                    $scope.isAttachmentUploading = false;
                    $scope.$apply();
                } else {
                    alert("Upload failed. Another image with same name exists!!!");
                }
            },
            error: function (err) {
                alert(err.statusText);
            }
        });

    };

    //open image gallery modal
    $scope.open = function (size, index) {
        var ticketID = $scope.myContracts[($scope.myContracts.length - index) - 1].Id;

        $http.get("api/ImageAttachments?tokenID=" + ticketID).success(function (data) {
            $scope.imageAttachments = data;
            var modalInstance = $modal.open({
                templateUrl: 'tpl/app/modal.html',
                controller: 'ModalInstanceCtrl',
                size: size,
                resolve: {
                    imageAttachments: function () {
                        return $scope.imageAttachments;
                    }
                }
            })
        });
    };

    //download the div of View Topic as PDF with filename being the Topic name
    $scope.downloadContractPDF = function () {
        var filename = "Contract" + ".pdf";
        html2canvas(document.getElementById('ExportThis'), {
            onrendered: function (canvas) {
                var data = canvas.toDataURL();
                var docDefinition = {
                    content: [{
                        image: data,
                        width: 500,
                    }]
                };
                pdfMake.createPdf(docDefinition).download(filename);
            }
        });
    }

    //download the div of View Topic as DOCX with filename being the Topic name
    $scope.downloadContractDOC = function () {
        var filename = "Contract" + ".doc";
        var elHtml = document.getElementById('ExportThis').innerHTML;
        var link = document.createElement('a');
        link.setAttribute('download', filename);
        link.setAttribute('href', 'data:' + 'text/doc' + ';charset=utf-8,' + encodeURIComponent(elHtml));
        link.click();
    }

    //print the div for View Topic
    $scope.printContract = function () {
        var printContents = document.getElementById('ExportThis').innerHTML;
        var popupWin = window.open('', '_blank', 'width=300,height=300');
        popupWin.document.open();
        popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + printContents + '</body></html>');
        popupWin.document.close();
    }

    //upload any document
    $scope.uploadLibraryDocument = function (files) {
        if (files[0].size > 12000000) {
            toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
            return false;
        }

        $scope.isAttachmentUploading = true;
        var fd = new FormData();
        //Take the first selected file
        fd.append("file", files[0]);

        $http.post("/api/Library/Resource?module=Contract&moduleId=" + $scope.currentRecordId + "&subModule=Main&subModuleId=0", fd, {
            withCredentials: true,
            headers: { 'Content-Type': undefined },
            transformRequest: angular.identity
        }).success(function (data) {
            $("#document").val("");
            $scope.isAttachmentUploading = false;
            $scope.documents_mainPage.uploadresults.push(data[0]);
        }
        ).error(function (data) {
            alert(data[0]);
        }
        );

    };
    //RR 485 delete Library Document snoppets implement.
    $scope.deleteAttachment = function (id) {
        var ans = confirm("Are you sure you want to delete?");
        if (ans) {
            $http.delete("/api/Library/Resource/" + id).success(function (data) {
                var indx = 0;
                angular.forEach($scope.documents_mainPage.uploadresults, function (value, index) {
                    if (value.fileId == id) {
                        indx = index;
                    }
                })
                $scope.documents_mainPage.uploadresults.splice(indx, 1);
                toaster.pop('success', 'Success', "Attachment successfully deleted!");

            });
        }
    }
        // End RR 485 Implement delete icon snippets

        // Method to add a new Department
    $scope.addnewDepartment = function () {
        $scope.newRecord = {
            Id: 0,
            Agencyname: "",
            Acronym: "",
            TypeIndicator: 0,
        }
        $scope.addEditDepartment($scope.newRecord, "add", "department", $scope.allDepartments);
    }

        // Method to add a new Agency
    $scope.addNewAgency = function () {
        $scope.newRecord = {
            Id: 0,
            Agencyname: "",
            Acronym: "",
            TypeIndicator: $scope.objContract.DepartmentId,
        }
        $scope.addEditDepartment($scope.newRecord, "add", "agency", $scope.departments);
    }
        //to add/edit department and agency
    $scope.addEditDepartment = function (obj, mode, type, completelist) {
        $scope.department = {};
        $scope.department = obj;
        var modalInstance = $modal.open({
            templateUrl: 'Scripts/app/departmentConfiguration/partials/departmentPopUp.html',
            controller: 'modalInstanceDepartmentCtrl',
            backdrop: 'static',
            scope: $scope,
            resolve: {
                item: function () {
                    return $scope.department;
                },
                mode: function () {
                    return mode;
                },
                wholelist: function () {
                    return completelist;
                },
                type: function () {
                    return type;
                }
            }
        });
        modalInstance.result.then(function (value) {
            if (value != "") {
                if (type == "agency") {
                    getAgency(value);
                }
                else if (type == "department") {
                    getDepartments(value);
                }
            }
        });
    }
    function getDepartments(obj) {
        departmentService.getDepartments().then(function (response) {
            $scope.allDepartments = response.data.agencyList;           //populating list of departments 
            $scope.objContract.DepartmentId = obj.Id;
            $scope.objContract.DepartmentName = obj.Agencyname;
            $scope.getAgency(obj.Id);
        });
    }

    function getAgency(obj) {
        var id = $scope.objContract.DepartmentId;
        //get the Agency/agencies according to the department Dropdown selection
        $http.get('/Home/GetAgencies?departmentId=' + id).success(function (data) {
            if (data.length == 0) {
                $scope.departments = [];
            }
            else {
                $scope.departments = data.agencyList;
            }
            $scope.objContract.AgencyId = obj.Id;
            $scope.objContract.AgencyName = obj.Agencyname;
        })
    };

}])

model.controller('ModalInstanceCtrl', ['$scope', '$modalInstance', 'imageAttachments', function ($scope, $modalInstance, imageAttachments) {
    $scope.test = 'Test';
    $scope.myInterval = 5000;
    $scope.imageAttachments = imageAttachments;

    $scope.ok = function () {
        $modalInstance.close();
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
    };
}])

model.controller('SpecificPastPerformanceController', ['$scope', '$http', '$modalInstance', '$rootScope', function ($scope, $http, $modalInstance, $rootScope) {

    var topicModel = {
        id: 0,
        topicname: "",
        businessarea: "",
        category: "",
        topicstatus: "",
        completeness: 0,
        topictype: "",
        topicdescription: ""
    }

    $scope.closePPModal = function () {
        $scope.sppInstance.close();
    };
    $scope.isTopicNameNotUnique = false;
    $scope.topicUniqueNameChk = function (name) {
        $scope.isTopicNameNotUnique = false;
        for (var i = 0; i < $scope.TaskDropdown.length; i++) {
            if ($scope.TaskDropdown[i].TopicName.toLowerCase() == name.toLowerCase()) {
                $scope.isTopicNameNotUnique = true;
            }

        }
    }
    $scope.saveSpecificPP = function () {
        topicModel.topicname = $scope.topicName;
        topicModel.businessarea = $scope.businessArea;
        topicModel.category = $scope.category;
        topicModel.topicstatus = "Draft";
        topicModel.topictype = $scope.topicType;
        topicModel.topicdescription = $scope.topicDescription;
        topicModel.id = 0;
        topicModel.completeness = 0;
        $http.post('/api/Topics/', topicModel).success(function (data) {
            ActivityService.assortedCalls().saveAllCalls(1);
            $scope.TaskDropdown.push(data);
            $scope.SpecificPP.TopicId = data.Id;   //set the newly entered as default in dropdown
            $scope.closePPModal();

        }).error(function (data) {
            $scope.error = "An Error has occurred while adding Topic! " + data;
        });
    };

    $scope.updateSpecificPP = function () {
        topicModel.topicname = $scope.topicName;
        topicModel.businessarea = $scope.businessArea;
        topicModel.category = $scope.category;
        topicModel.topictype = $scope.topicType;
        topicModel.topicdescription = $scope.topicDescription;
        topicModel.id = $scope.currentRecordId;
        topicModel.topicstatus = "Draft";
        $http.put('/api/Topics/' + $scope.currentRecordId, topicModel).success(function (data) {
            $scope.loading = false;
            ActivityService.assortedCalls().saveAllCalls(2);
            angular.forEach($scope.topics, function (value, index) {
                if (value.Id == data.Id) {

                    value.TopicName = data.TopicName;
                    value.TopicName = data.TopicName;
                    value.BusinessArea = data.BusinessArea;
                    value.Category = data.Category;
                    value.TopicType = data.TopicType;
                    value.TopicDescription = data.TopicDescription;
                    value.UpdatedBy = data.UpdatedBy;
                    value.UpdatedDate = data.UpdatedDate;
                    value.TopicStatus = data.TopicStatus;
                    value.Completeness = data.Completeness;
                }
            })
            $scope.Steps[2].step2[0].active = true;
            objForm.$setPristine();
        }).error(function (data) {
            $scope.error = "An Error has occurred while updating Topic! " + data;
            $scope.loading = false;
        });
    }


}])

