﻿app.factory('customUDVConfigService', [
    '$http',
    function ($http) {
        return {
            getAllUserDefinedValues: function () {
                return $http.get('/CustomUserDefinedValuesConfiguration/GetAllUserDefinedValues').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postUserDefinedValues: function (obj) {
                return $http.post('/CustomUserDefinedValuesConfiguration/PostUserDefinedValues', obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putUserDefinedValues: function (id, obj) {
                return $http.put('/CustomUserDefinedValuesConfiguration/PutUserDefinedValues?id=' + id, obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteUserDefinedValues: function (Id) {
                return $http.delete('/CustomUserDefinedValuesConfiguration/DeleteUserDefinedValues?Id=' + Id).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
          
        }
    }
]);