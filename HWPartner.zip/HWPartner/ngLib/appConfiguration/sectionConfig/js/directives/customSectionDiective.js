﻿app.directive('customSection', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        transclude:true,
        templateUrl: 'Scripts/app/appConfiguration/sectionConfig/partials/customSection.html',
        controller: 'customSectionCtrl',
        link: function ($scope, $element, attr) {
        }
    }
}]);