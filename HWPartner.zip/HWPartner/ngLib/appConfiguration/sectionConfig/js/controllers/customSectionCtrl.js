﻿'use strict';

app.controller('customSectionCtrl', ['$scope', '$http', '$modal', 'customSectionService', '$timeout', '$window', 'toaster',
    function ($scope, $http, $modal, customSectionService, $timeout, $window, toaster) {
        $scope.addNewSection = true;
        $scope.editOldSection = false;
        $scope.deleteSection = false;

        $scope.saveSection = false;
        $scope.cancelSection = false;
        $scope.isAddingSection = false;
        $scope.isEditingSection = false;
        $scope.currentSectionIndex = 0;

        $scope.sectionSet = [];// contains all the Sections
        $scope.sectionBackUpSet = [];//contains the back up  of sectionSet
        $scope.newSectionRecord = {};

        $scope.allViews = [];

        // Method to load all sections and views
        $scope.loadSectionData = function () {
            getSectionData();
            //api service call to get all the views
            customSectionService.getAllViews().then(function (response) {
                $scope.allViews = response.data.ViewList;              //populating list of views to show in a table dropdown in UI
            });
        }
        // load at run time
        $scope.loadSectionData();

        function getSectionData() {
            //api service call to get all the sections
            customSectionService.getAllSection().then(function (response) {
                $scope.sectionSet = response.data.SectionList;              //populating list of sections 
                if ($scope.sectionSet.length > 0) {
                    $scope.editOldSection = true;
                    $scope.deleteSection = true;
                }
            });
        }

        // Method to add a new Section
        $scope.addnewSectionRecord = function () {

            $scope.newSectionRecord = {
                Id: 0,
                Name: "",
                Add: true,
                Edit: false,
                Delete: false,
                ViewsId: "",
                ViewsName: "",
                ViewObj: []
            }

            $scope.isAddingSection = true;
            $scope.sectionSet.push($scope.newSectionRecord);
            $scope.currentSectionIndex = $scope.sectionSet.length - 1;
        }


        $scope.editOldSectionRecord = function (index) {
            $scope.sectionBackUpSet = angular.copy($scope.sectionSet);  //will be used in case of undo
            $scope.isEditingSection = true;
            $scope.sectionSet[index].Edit = true;
            $scope.currentSectionIndex = index;
        }

        $scope.deleteSectionRecord = function (index) {
            var Id = $scope.sectionSet[index].Id;
            var ans = confirm("Are you sure you want to delete it?");
            if (ans) {
                customSectionService.deleteSection($scope.sectionSet[index].Id).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.sectionSet.splice(index, 1);
                        toaster.pop('success', 'Success', "Deleted successfully !");
                    }
                    else if (response.data.result == "NotPossible") {
                        toaster.pop('info', 'Alert!!!', "Disassociate Form records with this Section first!!!");
                    }
                    else {
                        toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                    }
                });
            }

        }
        $scope.validateSectionEntry = function (index) {
            //check for duplicate section names
            if ($scope.sectionSet.length == 1) {
                $scope.saveSectionRecord(index);
            }
            else {
                var bool = validateSectionMethod();
                if (bool) {
                    $scope.saveSectionRecord(index);
                }
            }

        }
        function validateSectionMethod() {
            var bool = true;
            var name = $scope.sectionSet[$scope.currentSectionIndex].Name;
            angular.forEach($scope.sectionSet, function (val, indx) {
                if (indx != $scope.currentSectionIndex) {
                    if (val.Name.toLowerCase() == name.toLowerCase()) {
                        bool = false;
                        toaster.pop('error', 'Error', "Section Name cannot be duplicate");
                    }
                }
            })
            return bool;
        }
        $scope.saveSectionRecord = function (index) {
            if ($scope.isAddingSection)    //i.e. new addition
            {
                customSectionService.postSection($scope.sectionSet[$scope.currentSectionIndex]).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.sectionSet[$scope.currentSectionIndex].Id = response.data.NewRecord.Id;
                        $scope.sectionSet[$scope.currentSectionIndex].Add = false;
                        $scope.sectionSet[$scope.currentSectionIndex].Edit = false;
                        $scope.sectionSet[$scope.currentSectionIndex].Delete = false;
                        $scope.isAddingSection = false;
                        toaster.pop('success', 'Success', "Insert successful !");
                    }
                    else {
                        $scope.isAddingSection = false;
                        toaster.pop('error', 'Error', "An error occured while adding section");
                    }
                    getSectionData();

                });
            }
            if ($scope.isEditingSection)    //i.e. existing modification
            {
                $scope.sectionSet[index].Edit = false;
                $scope.isEditingSection = false;

                customSectionService.putSection($scope.sectionSet[index].Id, $scope.sectionSet[$scope.currentSectionIndex]).then(function (response) {
                    if (response.data.result == "Success") {
                        toaster.pop('success', 'Success', "Update successful!");
                    }
                    else {
                        toaster.pop('error', 'Error', "An error occured while editing section");
                    }
                    getSectionData();
                });
            }

        }
        $scope.cancelSectionRecord = function (index) {
            $scope.isAddingSection = false;
            $scope.isEditingSection = false;
            $scope.sectionSet = angular.copy($scope.sectionBackUpSet);  //restore from backup
            getSectionData();
        }

    }]);