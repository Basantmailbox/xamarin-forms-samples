﻿// Service definition for Custom Section Configuration
app.factory('customSectionService', [
    '$http',
    function ($http) {
        return {
            getAllSection: function () {
                return $http.get('/AppConfiguration/AllSections').
                  success(function (data, status, headers) {
                      // console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllViews: function () {
                return $http.get('/AppConfiguration/AllViewsDD').
                  success(function (data, status, headers) {
                      // console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postSection: function (obj) {
                return $http.post('/AppConfiguration/PostSectionSet', obj).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putSection: function (id, obj) {
                return $http.put('/AppConfiguration/PutSectionSet?id=' + id, obj).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteSection: function (id) {
                return $http.delete('/AppConfiguration/DeleteSectionSet?id=' + id).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            }

        }
    }
]);