﻿app.directive('customField', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        transclude:true,
        templateUrl: 'Scripts/app/appConfiguration/fieldConfig/partials/customField.html',
        controller: 'customFieldCtrl',
        link: function ($scope, $element, attr) {
        }
    }
}]);