﻿// Service definition for Custom Field Configuration
app.factory('customFieldService', [
    '$http',
    function ($http) {
        return {
            getAllTables: function () {
                return $http.get('/AppConfiguration/AllTables').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getFields: function (tableId) {
                return $http.get('/AppConfiguration/Fields?tableId=' + tableId).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postField: function (obj) {
                return $http.post('/AppConfiguration/PostFieldSet', obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putField: function (id, obj) {
                return $http.put('/AppConfiguration/PutFieldSet?id=' + id, obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteField: function (id) {
                return $http.delete('/AppConfiguration/DeleteFieldSet?id=' + id).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getFieldInfo: function (fieldId) {
                return $http.get('/AppConfiguration/GetFieldInfo?fieldId=' + fieldId).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllFieldTypes: function () {
                return $http.get('/Home/GetAllFieldTypes').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putFieldProperty: function (obj) {
                return $http.put('/AppConfiguration/PutFieldProperty', obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllLookUpTables: function () {
                return $http.get('/AppConfiguration/AllLookUpTables').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllConstantTypes: function () {
                return $http.get('/Home/AllConstantTypes').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllUserDefinedValues: function () {
                return $http.get('/CustomUserDefinedValuesConfiguration/AllUserDefinedValues').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            saveUserDefinedValues: function (obj) {
                return $http.post('/CustomUserDefinedValuesConfiguration/SaveUserDefinedValues?obj=' + obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllUserDefinedQuestionnaireValues: function () {
                return $http.get('/CustomUserDefinedQuestionnaireValuesConfiguration/AllUserDefinedValues').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            saveUserDefinedQuestionnaireValues: function (value,weightage) {
                return $http.post('/CustomUserDefinedQuestionnaireValuesConfiguration/SaveUserDefinedValues?value=' + value + '&weightage='+weightage).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllQuestionnaireViews: function () {
                return $http.get('/AppConfiguration/AllQuestionnaireViews').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
        }
    }
]);