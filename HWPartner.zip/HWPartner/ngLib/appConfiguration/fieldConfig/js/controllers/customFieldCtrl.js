﻿'use strict';

app.controller('customFieldCtrl', ['$scope', '$http', '$modal', 'customFieldService', '$timeout', '$window', 'toaster',
function ($scope, $http, $modal, customFieldService, $timeout, $window, toaster) {
    $scope.addNewField = true;
    $scope.editOldField = false;
    $scope.deleteField = false;

    $scope.saveField = false;
    $scope.cancelField = false;
    $scope.isAddingField = false;
    $scope.isEditingField = false;
    $scope.currentFieldIndex = 0;
    $scope.tableFilter = 0;
    $scope.tableNameFilter = "";

    $scope.filteredFieldset = [];//contains the list of fields associated with a selected table( table come from $scope.tableFilter)
    $scope.backupFieldset = [];//contains the back up  of filteredFieldset
    $scope.newFieldRecord = {};

    $scope.oldFieldSequence = 0;
    $scope.oldField = "";
    $scope.oldFieldDescription = "";

    $scope.oldFieldValue = [];
    $scope.newFieldValue = [];

    $scope.tables = [];



    // Method to load record states for different tables
    $scope.loadFieldData = function () {
        //api service call to get all the tables
        customFieldService.getAllTables().then(function (response) {
            $scope.tables = response.data.TableList;              //populating list of tables to show in a table dropdown in UI
        });
    }
    // load at run time
    $scope.loadFieldData();

    $scope.changeTable = function () {
        getTableName();//to find the name of  selected table from the list 
        getFields();//to get the fields of the selected table.
    }
    function getFields() {
        customFieldService.getFields($scope.tableFilter).then(function (response) {
            $scope.filteredFieldset = response.data.FieldList;           //populating list of fields per selected table.
            if ($scope.filteredFieldset.length > 0) {
                $scope.editOldField = true;
                $scope.deleteField = true;
            }
        });
    }

    function getTableName() {
        angular.forEach($scope.tables, function (value, index) {
            if (value.Id == $scope.tableFilter) {
                $scope.tableNameFilter = value.Name;
            }
        })
    }
    $scope.captionChange = function (flag) {
        if (flag)
        {
            if ($scope.filteredFieldset[$scope.currentFieldIndex].Caption != "" && $scope.filteredFieldset[$scope.currentFieldIndex].Caption != undefined) {
                var caption = $scope.filteredFieldset[$scope.currentFieldIndex].Caption;
                var name = caption.replace(/ /g, '');
                $scope.filteredFieldset[$scope.currentFieldIndex].Name = name;
            }
        }
    }

    // Method to add a new Field
    $scope.addnewFieldRecord = function () {

        $scope.newFieldRecord = {
            Id: 0,
            TableId: $scope.tableFilter,
            TableName: $scope.tableNameFilter,
            Caption: "",
            Name: "",
            Description: "",
            Add: true,
            Edit: false,
            Delete: false
        }

        $scope.isAddingField = true;
        $scope.filteredFieldset.push($scope.newFieldRecord);
        $scope.currentFieldIndex = $scope.filteredFieldset.length - 1;
    }

    $scope.editOldFieldRecord = function (index) {

        $scope.backupFieldset = angular.copy($scope.filteredFieldset);  //will be used in case of undo
        $scope.isEditingField = true;
        $scope.filteredFieldset[index].Edit = true;
        $scope.oldField = $scope.filteredFieldset[index].Recordstatename;
        $scope.oldFieldDescription = $scope.filteredFieldset[index].Description;
        $scope.currentFieldIndex = index;

    }
    $scope.deleteFieldRecord = function (index) {
        var Id = $scope.filteredFieldset[index].Id;
        var ans = confirm("Are you sure you want to delete it?");
        if (ans) {
            customFieldService.deleteField($scope.filteredFieldset[index].Id).then(function (response) {
                if (response.data.result == "Success") {
                    $scope.filteredFieldset.splice(index, 1);
                    toaster.pop('success', 'Success', "Deleted successfully !");
                }
                else if (response.data.result == "NotPossible") {
                    toaster.pop('info', 'Alert!!!', "Disassociate View records with this Field first!!!");
                }
                else {
                    toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                }
            });
        }
    }
    $scope.validateFieldEntry = function (index) {
        //check for duplicate names
        
        if ($scope.filteredFieldset.length == 1) {
            $scope.saveFieldRecord(index);
        }
        else
        {
            var bool = validateFieldMethod();
            if(bool)
            {
                $scope.saveFieldRecord(index);
            }
        }

    }
    function validateFieldMethod() {
        var bool = true;
        var name = $scope.filteredFieldset[$scope.currentFieldIndex].Name;
        var caption = $scope.filteredFieldset[$scope.currentFieldIndex].Caption;
        angular.forEach($scope.filteredFieldset, function (val, indx) {
            if (indx != $scope.currentFieldIndex) {
                if (val.Caption == caption) {
                    bool = false;
                    toaster.pop('error', 'Error', "Field Caption cannot be duplicate");
                }
                else if (val.Name == name) {
                    bool = false;
                    toaster.pop('error', 'Error', "Field Name cannot be duplicate");
                }
            }
        })
        return bool;
    }
    // Method to save a Field record (whether adding / editing)
    $scope.saveFieldRecord = function (index) {
        if ($scope.isAddingField)    //i.e. new addition
        {
            customFieldService.postField($scope.filteredFieldset[$scope.currentFieldIndex]).then(function (response) {
                if (response.data.result == "Success") {
                    $scope.filteredFieldset[$scope.currentFieldIndex].Id = response.data.NewRecord.Id;
                    $scope.filteredFieldset[$scope.currentFieldIndex].Add = false;
                    $scope.filteredFieldset[$scope.currentFieldIndex].Edit = false;
                    $scope.filteredFieldset[$scope.currentFieldIndex].Delete = false;
                    $scope.isAddingField = false;
                    toaster.pop('success', 'Success', "Insert successful !");
                }
                else {
                    $scope.isAddingField = false;
                    toaster.pop('error', 'Error', "An error occured while adding field");
                }
                getFields();

            });
        }
        if ($scope.isEditingField)    //i.e. existing modification
        {
            $scope.filteredFieldset[index].Edit = false;
            $scope.isEditingField = false;

            customFieldService.putField($scope.filteredFieldset[index].Id, $scope.filteredFieldset[$scope.currentFieldIndex]).then(function (response) {
                if (response.data.result == "Success") {
                    toaster.pop('success', 'Success', "Update successful!");
                }
                else {
                    toaster.pop('error', 'Error', "An error occured while editing  field");
                }
                getFields();
            });
        }
    }
    $scope.cancelFieldRecord = function (index) {
        $scope.isAddingField = false;
        $scope.isEditingField = false;
        $scope.filteredFieldset = angular.copy($scope.backupFieldset);  //restore from backup
        getFields();
    }

    $scope.openPropertyModal = function (index) {
        var modalInstance = $modal.open({
            templateUrl: 'Scripts/app/appConfiguration/fieldConfig/partials/customFieldProperty.html',
            controller: 'modalInstancePropertyCtrl',
            backdrop: 'static',
            size:'lg',
            scope: $scope,
            resolve: {
                object: function () {
                    return $scope.filteredFieldset[index];
                }
            }
        });
        modalInstance.result.then(function () {
           
        });
    }
}]);