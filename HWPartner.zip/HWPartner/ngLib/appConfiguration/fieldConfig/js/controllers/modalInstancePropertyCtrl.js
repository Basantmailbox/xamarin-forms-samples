﻿app.controller('modalInstancePropertyCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'object', 'toaster', '$location', 'customFieldService',
    function ($scope, $http, $modalInstance, $controller, object, toaster, location, customFieldService) {
        $scope.currentFieldId = 0;
        $scope.fieldObj = object;
        $scope.currentFieldId = $scope.fieldObj.Id;
        $scope.fieldInfo = {
            ExtensionsAllowed: '',
        };
        $scope.fieldObject = {
            fieldTypeObj: {},
            lookUpTableObj: {},
            lookUpFieldsObj: {},
            constantTypeObj: {},
            UserDefinedValuesObj: {},
            UserDefinedQuestionnaireValuesObj: {},
            fieldIsAuto: false,
            fieldIsQuestion: false,
            QuestionnaireViewObj:{},
        };
        $scope.UserValues = {
            Name: "",
        }
        $scope.UserQuestionnaireValues = {
            Name: "",
            Weightage: "",
        }

        $scope.allFieldTypes = [];
        $scope.backupFieldTypes = [];
        $scope.allLookUpTables = [];
        $scope.allLookUpFields = [];
        $scope.allConstantTypes = [];
        //list of user defined values for radio button and checkbox
        $scope.allUserDefinedValues = [];
        $scope.addUserValues = false;
        //list of values and weightage for questions
        $scope.allUserDefinedQuestionnaireValues = [];
        $scope.addUserQuestionnaireValues = false;

        $scope.allQuestionnaireViews = [];

        $scope.togglePropertyModal = function () {
            $modalInstance.close();
        }
        OnPageload();
        function OnPageload() {
            getFieldTypes();
            getInfo();
            getLookUpTables();
            getConstantTypes();
            getUserDefinedValues();
            getUserDefinedQuestionnaireValues();
            getQuestionnaireViews();
        }

        // ************** Common functions Start *********************************//
        //get data on page load functions

        function getInfo() {
            customFieldService.getFieldInfo($scope.currentFieldId).then(function (response) {
                //set all the properties in field property object
                $scope.fieldInfo = response.data.result;
                if ($scope.fieldInfo.IsAuto) {
                    $scope.fieldObject.fieldIsAuto = true;
                }
                //set the value of fieldtype for ui.select drop down
                $scope.fieldObject.fieldTypeObj.Id = $scope.fieldInfo.FieldTypeId;
                $scope.fieldObject.fieldTypeObj.Name = $scope.fieldInfo.FieldTypeName;

                //if field is auto generated than set limit the fieldtype to date and identity
                if ($scope.fieldInfo != null && $scope.fieldInfo != {}) {
                    setTypeDD();
                }
                if ($scope.fieldInfo.FieldTypeId == 5 || $scope.fieldInfo.FieldTypeId == 6) //dropdown /Multiselect
                {
                    //set the value of data source id field type is dropdown or multiselect
                    if ($scope.fieldInfo.LookUpTable != "" && $scope.fieldInfo.LookUpTable != null) {
                        $scope.fieldObject.lookUpTableObj.Id = $scope.fieldInfo.LookUpTableId;
                        $scope.fieldObject.lookUpTableObj.Name = $scope.fieldInfo.LookUpTable;
                    }
                    if ($scope.fieldInfo.LookUpValue != "" && $scope.fieldInfo.LookUpValue != null) {
                        $scope.fieldObject.lookUpFieldsObj.Name = $scope.fieldInfo.LookUpValue;
                        $scope.fieldObject.lookUpFieldsObj.Id = $scope.fieldInfo.LookUpValueId;
                    }
                    if ($scope.fieldInfo.ConstantType != "" && $scope.fieldInfo.ConstantType != null) {
                        $scope.fieldObject.constantTypeObj.Id = $scope.fieldInfo.ConstantTypeId;
                        $scope.fieldObject.constantTypeObj.Name = $scope.fieldInfo.ConstantType;
                        $scope.fieldObject.constantTypeObj.TableName = $scope.fieldInfo.ConstantTableName;
                    }
                }
                else {

                }
                //if field type is attachment then set the attachment extension checkboxes
                if ($scope.fieldInfo.FieldTypeId == 16)//Attachment
                {
                    $scope.extensions = new Array($scope.extensionList.length);
                    angular.forEach($scope.extensionList, function (value, index) {
                        angular.forEach($scope.fieldInfo.ExtensionsAllowed, function (value1, index1) {
                            if (value == value1) {
                                $scope.extensions[index] = true;
                            }
                        })
                    })
                }
                //if field type is checkbox/radio  then set the UserDefinedValue
                if ($scope.fieldInfo.FieldTypeId == 13 || $scope.fieldInfo.FieldTypeId == 14) //checkbox / radio
                {
                    $scope.fieldObject.UserDefinedValuesObj.Id = $scope.fieldInfo.UDVId;
                    $scope.fieldObject.UserDefinedValuesObj.Value = $scope.fieldInfo.UDVNames;
                }
                else {
                    // for the required condition we habe created a input hidden box with model bound to fieldInfo.UDVId
                    $scope.fieldInfo.UDVId = "";
                }
                //if field type is Question  then set the UserDefinedValue
                if ($scope.fieldInfo.FieldTypeId == 20) {
                    $scope.fieldObject.UserDefinedQuestionnaireValuesObj.Id = $scope.fieldInfo.UDQuesOptionId;
                    $scope.fieldObject.UserDefinedQuestionnaireValuesObj.Value = $scope.fieldInfo.UDQuesOptionName;
                }
                else {
                    // for the required condition we habe created a input hidden box with model bound to fieldInfo.UDQuesOptionId
                    $scope.fieldInfo.UDQuesOptionId = "";
                }
                //if field type is Questionnaire form   then set the views
                if ($scope.fieldInfo.FieldTypeId == 21) {
                    $scope.fieldObject.QuestionnaireViewObj.Id=$scope.fieldInfo.QViewId;
                    $scope.fieldObject.QuestionnaireViewObj.Value=$scope.fieldInfo.QViewNames;
                }
                else {
                    // for the required condition we habe created a input hidden box with model bound to fieldInfo.UDQuesOptionId
                    $scope.fieldInfo.QViewId = "";
                }
                
                if ($scope.fieldInfo.FieldTypeId == 3 || $scope.fieldInfo.FieldTypeId == 4) //date picker / datetime picker
                {
                    if ($scope.fieldInfo.DateDataSource == "Static") {
                        var jsonMinDate = $scope.fieldInfo.MinDate;
                        var jsonMaxDate = $scope.fieldInfo.MaxDate;
                        var minDate = new Date(parseInt(jsonMinDate.substr(6)));
                        var maxDate = new Date(parseInt(jsonMaxDate.substr(6)));
                        $scope.fieldInfo.MinDate = $scope.formatdate(minDate);
                        $scope.fieldInfo.MaxDate = $scope.formatdate(maxDate);
                    }
                }
                if ($scope.fieldInfo.FieldTypeId != 2) {
                    $scope.fieldInfo.MinNumber = "";
                    $scope.fieldInfo.MaxNumber = "";
                }
            });
        }

        $scope.formatdate = function (sdate) {
            var d = new Date(sdate);
            var currDay = "";
            if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
            var currMonth = "";
            if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
            var currYear = d.getFullYear();
            var startDate = currMonth + "/" + currDay + "/" + currYear;
            return startDate;
        }
        //if field is auto generated than set limit to the fieldtype to date and identity
        function setTypeDD() {
            $scope.allFieldTypes = [];
            if ($scope.fieldInfo.IsAuto) {
                angular.forEach($scope.backupFieldTypes, function (val, indx) {
                    if (val.IsAuto == true) {
                        $scope.allFieldTypes.push(val);
                    }
                })
            }
            else if ($scope.fieldInfo.IsQuestion) {
                angular.forEach($scope.backupFieldTypes, function (val, indx) {
                    if (val.IsQuestion == true) {
                        $scope.allFieldTypes.push(val);
                    }
                })
            }
            else {
                angular.forEach($scope.backupFieldTypes, function (val, indx) {
                    if (val.IsAuto == false && val.IsQuestion == false) {
                        $scope.allFieldTypes.push(val);
                    }
                })
            }
        }
        function getLookUpTables() {
            customFieldService.getAllLookUpTables().then(function (response) {
                $scope.allLookUpFields = [];
                $scope.allLookUpTables = response.data.TableList;
            });
        }
        function getConstantTypes() {
            customFieldService.getAllConstantTypes().then(function (response) {
                $scope.allConstantTypes = response.data.list;
            });
        }
        function getLookUpFields(tableId) {
            $scope.allLookUpFields = [];
            customFieldService.getFields(tableId).then(function (response) {
                $scope.allLookUpFields = response.data.FieldList;
            });
        }
        function getFieldTypes() {
            customFieldService.getAllFieldTypes().then(function (response) {
                $scope.allFieldTypes = response.data.list;
                $scope.backupFieldTypes = angular.copy($scope.allFieldTypes);

            });
        }


        // ************** Common functions End *********************************//

        // Clear Object functions
        //---------------------  Start ---------------------------//
        //for clearing the dropdown/multiselect data sources
        $scope.clearDDSource = function () {
            clearsystemObj();
            clearUserDefinedObj();

        }
        function clearsystemObj() {
            $scope.fieldInfo.LookUpTable = "";
            $scope.fieldInfo.LookUpTableId = 0;
            $scope.fieldInfo.LookUpId = "";
            $scope.fieldInfo.LookUpValue = "";
            $scope.fieldInfo.LookUpValueId = 0;
            $scope.fieldObject.lookUpFieldsObj = {};
            $scope.fieldObject.lookUpTableObj = {};
        }
        function clearUserDefinedObj() {
            $scope.fieldInfo.ConstantType = "";
            $scope.fieldInfo.ConstantTableName = "";
            $scope.fieldInfo.ConstantTypeId = 0;
            $scope.fieldObject.constantTypeObj = {};
        }
        //for clearing the radio/checkbox data sources
        function clearUserDefinedValues() {
            $scope.fieldObject.UserDefinedValuesObj = {};
            $scope.fieldInfo.UDVId = "";
            $scope.fieldInfo.UDVNames = "";
            $scope.addUserValues = false;
        }
        //for clearing the extensions
        function emptyExtensionChoices() {
            $scope.fieldInfo.ExtensionsAllowed = '';
            $scope.extensions = new Array($scope.extensionList.length);
        }
        //for clearing the date/datetime data sources
        $scope.clearDateSource = function () {
            $scope.fieldInfo.MinDate = null;
            $scope.fieldInfo.MaxDate = null;
            $scope.fieldInfo.MinDays = "";
            $scope.fieldInfo.MaxDays = "";

        }
        //for clearing the question data sources
        function clearQuestionObject() {
            $scope.fieldInfo.UDQuesOptionId = "";
            $scope.fieldInfo.UDQuesOptionName = "";
            $scope.fieldObject.UserDefinedQuestionnaireValuesObj = {};
            $scope.fieldInfo.Question = "";
            $scope.fieldInfo.ResponseType = "";
            $scope.addUserQuestionnaireValues = false;
        }
        function clearAllConfigurationsettings() {
            //clear the previous configuration settings values
            $scope.clearDDSource();//dropdown or  multiselect
            $scope.fieldInfo.DataSource = "";//dropdown or  multiselect source
            emptyExtensionChoices();//for attachment
            clearUserDefinedValues();//checkbox or radio
            $scope.clearDateSource();// Date or datetime
            $scope.fieldInfo.DateDataSource = "";// Date or datetime
            $scope.fieldInfo.MinNumber = "";//NumberBox
            $scope.fieldInfo.MaxNumber = "";//NumberBox
            $scope.fieldInfo.TextRowCount = 1;//TextArea
            
        }
        //---------------------  End ---------------------------//



        // If field type is Is Auto and Is Question is changed
        //---------------------  Start ---------------------------//
        $scope.autoUpdated = function () {
            $scope.fieldObject.fieldTypeObj = {};
            $scope.fieldInfo.FieldTypeId = 0;
            $scope.fieldInfo.FieldTypeName = "";
            setTypeDD();
            if ($scope.fieldInfo.IsAuto) {
                $scope.fieldObject.fieldIsAuto = true;
                clearAllConfigurationsettings();
            }
            else {
                $scope.fieldObject.fieldIsAuto = false;
            }
            if ($scope.fieldInfo.IsQuestion) {

                $scope.fieldObject.fieldIsQuestion = true;
                clearAllConfigurationsettings();
            }
            else {
                $scope.fieldObject.fieldIsQuestion = false;
                clearQuestionObject();

            }

        }
        //---------------------  End ---------------------------//

        // fired when the field type is changed
        $scope.updateFieldType = function () {
            var ans = confirm("Updating the Field Type will overwrite the previous configuration settings.Do you want to proceed?");
            if (ans) {
                //set the value of fieldtype in fieldinfo object
                $scope.fieldInfo.FieldTypeId = $scope.fieldObject.fieldTypeObj.Id;
                $scope.fieldInfo.FieldTypeName = $scope.fieldObject.fieldTypeObj.Name;
                clearAllConfigurationsettings();
                clearQuestionObject();
            }
        }

        // If field type is Dropdown/Multiselect To get the data sources 
        //---------------------  Start ---------------------------//
        $scope.updateLookupFields = function () {
            $scope.fieldInfo.LookUpTable = $scope.fieldObject.lookUpTableObj.Name;
            $scope.fieldInfo.LookUpTableId = $scope.fieldObject.lookUpTableObj.Id;
            $scope.fieldInfo.LookUpId = "";
            $scope.fieldInfo.LookUpValue = "";
            $scope.fieldObject.lookUpFieldsObj = {};
            getLookUpFields($scope.fieldObject.lookUpTableObj.Id);
        }
        $scope.updateFieldsObj = function () {
            $scope.fieldInfo.LookUpId = "Id";
            $scope.fieldInfo.LookUpValue = $scope.fieldObject.lookUpFieldsObj.Name;
            $scope.fieldInfo.LookUpValueId = $scope.fieldObject.lookUpFieldsObj.Id;
        }
        $scope.updateConstantTypeObj = function () {
            $scope.fieldInfo.ConstantType = $scope.fieldObject.constantTypeObj.Name;
            $scope.fieldInfo.ConstantTableName = $scope.fieldObject.constantTypeObj.TableName;
            $scope.fieldInfo.ConstantTypeId = $scope.fieldObject.constantTypeObj.Id;
        }
        //---------------------  End ---------------------------//



        // If field type is Attachment To get the extension 
        //---------------------  Start ---------------------------//
        $scope.extensionList = ['.jpg', '.jpeg', '.bmp', '.png', '.pdf', '.txt', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.html'];
        $scope.extensions = new Array($scope.extensionList.length);
        function getSelected() {
            return $scope.extensionList.filter(function (x, i) {
                return $scope.extensions[i]
            });
        }
        $scope.getExtensions = function () {
            $scope.fieldInfo.ExtensionsAllowed = getSelected();

        }
        //---------------------  End ---------------------------//

        // If field type is Radio/CheckBox the methods to get the data values
        //---------------------  Start ---------------------------//
        function getUserDefinedValues() {
            $scope.allUserDefinedQuestionnaireValues = [];
            customFieldService.getAllUserDefinedQuestionnaireValues().then(function (response) {
                $scope.allUserDefinedQuestionnaireValues = response.data.list;
            });
        }
        $scope.updateUserDefinedValues = function () {
            $scope.fieldInfo.UDVId = $scope.fieldObject.UserDefinedValuesObj.Id;
            $scope.fieldInfo.UDVNames = $scope.fieldObject.UserDefinedValuesObj.Value;
        }
        $scope.showUserDefinedDiv = function () {
            $scope.addUserValues = true;
            $scope.UserValues.Name = "";
        }
        $scope.cancelUserDefinedValues = function () {
            $scope.addUserValues = false;
            $scope.UserValues.Name = "";
        }
        $scope.saveUserDefinedValues = function () {
            var invalidentry = hasDuplicates();
            if (!invalidentry) {
                customFieldService.saveUserDefinedValues($scope.UserValues.Name).then(function (response) {
                    if (response.data.result == "Success") {
                        toaster.pop('success', 'Success', "Added successful!");
                        getUserDefinedValues();
                        $scope.fieldObject.UserDefinedValuesObj.Id = response.data.record.Id;
                        $scope.fieldObject.UserDefinedValuesObj.Value = response.data.record.Value;
                        $scope.fieldInfo.UDVId = response.data.record.Id;
                        $scope.fieldInfo.UDVNames = response.data.record.Value;
                        $scope.addUserValues = false;
                    }
                    else {
                        toaster.pop('error', 'Error', "An error occured while adding");
                    }
                });
            }
            else {
                toaster.pop('error', 'Error', "Duplicate values are not allowed");
            }
        }
        function hasDuplicates() {
            var array = $scope.UserValues.Name.split(',');
            var valuesSoFar = Object.create(null);
            for (var i = 0; i < array.length; ++i) {
                var value = array[i];
                if (value in valuesSoFar) {
                    return true;
                }
                valuesSoFar[value] = true;
            }
            return false;
        }
        //---------------------  End ---------------------------//


        // If field type is datepicker /datetimepicker the methods to get the min max dates
        //---------------------  Start ---------------------------//
        $scope.opendp1 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened1 = true;
        };
        $scope.opendp2 = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened2 = true;
        };
        $scope.dateOptions = {
            class: 'datepicker'
        };
        //---------------------  End ---------------------------//


        // If field type is Question the methods to get the data values
        //---------------------  Start ---------------------------//
        function getUserDefinedQuestionnaireValues() {
            $scope.allUserDefinedValues = [];
            customFieldService.getAllUserDefinedValues().then(function (response) {
                $scope.allUserDefinedValues = response.data.list;
            });
        }
        $scope.updateUserDefinedQuestionnaireValues = function () {
            $scope.fieldInfo.UDQuesOptionId = $scope.fieldObject.UserDefinedQuestionnaireValuesObj.Id;
            $scope.fieldInfo.UDQuesOptionName = $scope.fieldObject.UserDefinedQuestionnaireValuesObj.Value;
        }
        $scope.showUserDefinedQuestionnaireDiv = function () {
            $scope.addUserQuestionnaireValues = true;
            $scope.UserQuestionnaireValues.Name = "";
            $scope.UserQuestionnaireValues.Weightage = "";
        }
        $scope.saveUserDefinedQuestionnaireValues = function () {
            var array = $scope.UserQuestionnaireValues.Name.split(',');
            var weightagearray = $scope.UserQuestionnaireValues.Weightage.split(',');
            var invalidentry = hasDuplicatesValue(array);
            if (!invalidentry) {
                if (array.length == weightagearray.length) {
                    var invalidvalues = hasCorrectValues(weightagearray);
                    if (!invalidvalues) {
                        var updated = ParseWeightage(weightagearray);
                        if (updated)
                            saveQuestionOption();
                    }
                    else {
                        toaster.pop('error', 'Error', "Weightages should be number and lie between 0 and 10");
                    }
                }
                else {
                    toaster.pop('error', 'Error', "The number of Values and Weightage does not match.Please make sure that the number of comma separated values and weightage matches");
                }

            }
            else {
                toaster.pop('error', 'Error', "Duplicate values are not allowed");
            }

        }
        function hasDuplicatesValue(array) {
            var valuesSoFar = Object.create(null);
            for (var i = 0; i < array.length; ++i) {
                var value = array[i];
                if (value in valuesSoFar) {
                    return true;
                }
                valuesSoFar[value] = true;
            }
            return false;
        }
        function hasCorrectValues(weightagelist) {
            var returnvalue = false;
            for (var i = 0; i < weightagelist.length; ++i) {
                var value = parseFloat(weightagelist[i]);
                if (value < 0 || value > 10 || isNaN(value)) {
                    returnvalue = true;
                }
            }
            return returnvalue;
        }
        function ParseWeightage(weightagearray) {
            var bool = true;
            angular.forEach(weightagearray, function (value, index) {
                weightagearray[index] = parseFloat(value);
            })
            $scope.UserQuestionnaireValues.Weightage = weightagearray.join();
            return bool;
        }
        function saveQuestionOption() {
            customFieldService.saveUserDefinedQuestionnaireValues($scope.UserQuestionnaireValues.Name, $scope.UserQuestionnaireValues.Weightage).then(function (response) {
                if (response.data.result == "Success") {
                    toaster.pop('success', 'Success', "Added successful!");
                    getUserDefinedQuestionnaireValues();
                    $scope.fieldObject.UserDefinedQuestionnaireValuesObj.Id = response.data.record.Id;
                    $scope.fieldObject.UserDefinedQuestionnaireValuesObj.Value = response.data.record.Value;
                    $scope.fieldInfo.UDQuesOptionId = response.data.record.Id;
                    $scope.fieldInfo.UDQuesOptionName = response.data.record.Value;
                    $scope.addUserQuestionnaireValues = false;
                }
                else {
                    toaster.pop('error', 'Error', "An error occured while adding");
                }
            });
        }
        $scope.cancelUserDefinedQuestionnaireValues = function () {
            $scope.addUserQuestionnaireValues = false;
            $scope.UserQuestionnaireValues.Name = "";
            $scope.UserQuestionnaireValues.Weightage = "";
        }
        //---------------------  End ---------------------------//

        // If field type is Questionnaire form 
        //---------------------  Start ---------------------------//
        function getQuestionnaireViews() {
            $scope.allQuestionnaireViews = [];
            customFieldService.getAllQuestionnaireViews().then(function (response) {
                $scope.allQuestionnaireViews = response.data.list;
            });
        }
        $scope.updateQuestionnaireView = function () {
            $scope.fieldInfo.QViewId = $scope.fieldObject.QuestionnaireViewObj.Id;
            $scope.fieldInfo.QViewNames = $scope.fieldObject.QuestionnaireViewObj.Value;
        }
      
        //---------------------  End ---------------------------//


        $scope.saveData = function () {
            customFieldService.putFieldProperty($scope.fieldInfo).then(function (response) {
                if (response.data.result == "Success") {
                    toaster.pop('success', 'Success', "Update successful!");
                }
                else {
                    toaster.pop('error', 'Error', "An error occured while editing  field");
                }
                $scope.togglePropertyModal();
            });
        }

        $scope.cancelData = function () {
            $scope.togglePropertyModal();
        }
    }]);