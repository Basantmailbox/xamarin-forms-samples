﻿
app.controller("genericView", ['$scope', '$http', '$modal', '$rootScope', '$window', '$timeout', '$compile', 'uiGridConstants', 'toaster', '$interval', 'genericViewService', 'rigilViewDirective', 'rigilFormElementDirective',
    function ($scope, $http, $modal, $rootScope, $window, $timeout, $compile, uiGridConstants, toaster, $interval, genericViewService, rigilViewDirective, rigilFormElementDirective) {
        $scope.fieldsMetaData = [];
        $scope.tableId = 2;
        $scope.formName = "form1";
        $scope.layout = "List";
        $scope.ddOptions = [{ "Key": 1, "Value": "DD First Value" }, { "Key": 2, "Value": "DD Second Value" }, { "Key": 3, "Value": "DD Third Value" }, { "Key": 4, "Value": "DD Fourth Value" }];
        $scope.msOptions = [{ "Key": 1, "Value": "MS First Value" }, { "Key": 2, "Value": "MS Second Value" }, { "Key": 3, "Value": "MS Third Value" }, { "Key": 4, "Value": "MS Fourth Value" }];
        $scope.radioOptions = [{ Value: 'Yes' }, { Value: 'No' }, { Value: 'MayBe' }];
        $scope.checkboxOptions = [{ Value: 'Ch Value1' }, { Value: 'Ch Value2' }, { Value: 'Ch Value3' }];
        $scope.header = 'Put here your header';
        $scope.body = 'Put here your body';
        $scope.footer = 'Put here your footer';
        $scope.showme = false;
        $scope.obj = {
            formid:1,
            moduleid:46
        }

        $scope.myRightButton = function (bool) {
            alert('!!! first function call!');
        };
        genericViewService.getAllFieldsList($scope.tableId).then(function (response) {
            $scope.fieldsMetaData = response.data.FieldsMetaData;
        });

        $scope.openViewDataModal = function () {
            var modalInstance = $modal.open({
                templateUrl: 'addEditView.html',
                controller: 'modalInstanceAddEditCtrl',
                backdrop: 'static',
                scope: $scope,
                size: 'lg',
                resolve: {
                    dataArray: function () {
                        return $scope.fieldsMetaData;
                    }
                }
            });
            modalInstance.result.then(function (value) {

            });
        }
        $scope.saveData = function () {
            alert("hello");
        }
        $scope.printBlueSheet = function () {
            var printContents = document.getElementById('blueSheetDiv').innerHTML;
            var popupWin = window.open('', '_blank', 'width=300,height=300');
            popupWin.document.open();
            popupWin.document.write('<html><head><link rel="stylesheet" type="text/css" href="../css/bluesheet-print.css" /></head><body onload="window.print()">' + printContents + '</body></html>');
            popupWin.document.close();
        }

    }])