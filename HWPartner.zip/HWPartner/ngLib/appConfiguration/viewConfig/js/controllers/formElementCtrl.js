﻿app.controller("formElement", ['$scope', '$http', '$modal', '$rootScope', '$window', '$timeout', '$compile', '$interval',
    function ($scope, $http, $modal, $rootScope, $window, $timeout, $compile, $interval) {
        var vm = this;
        $scope.showme = false;
        $scope.opendp = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened = true;
        };
        $scope.dateOptions = {
            class: 'datepicker'
        };
        $scope.dateTimeOptions = { useCurrent: false, showClear: true, showClose: true };
        $scope.isAttachmentUploading=false;
        vm.formelement = function (row, ddoptions, msoptions,radiooptions,checkboxoptions) {
            if (row.FieldTypeId == 1) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                    "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                    "<div style='width:50%;'><input type='text' ng-model=" + row.Name + " class='form-control'limit-to='50'/></div>" +
                    "</div>";
                return htmltext;
            } else if (row.FieldTypeId == 2) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                    "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                    "<div style='width:50%;'><input type='number' ng-model=" + row.Name + " class='form-control' limit-to='20'/></div>" +
                    "</div>";
                return htmltext;
            }

            else if (row.FieldTypeId == 3) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                    "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                    "<div style='width:50%;'>" +
                    "<div class='input-group date' style='width:100%'>" +
                    "<p class='input-group' style='width:100%'>" +
                    "<input type='text' class='form-control' datepicker-popup='MM/dd/yyyy' ng-model=" + row.Name + " data-show-button-bar='true' " +
                        "is-open=opened close-on-date-selection='true' id=Id_" + row.Name + " datepicker-options=dateOptions " +
                        " date-disabled='disabled(date, mode)'  close-text='Close' ng-disabled='true' />" +
                        "<span class='input-group-btn'>" +
                            "<button type='button' class='btn btn-default' ng-click='opened=true;opendp($event)'>" +
                                "<i class='glyphicon glyphicon-calendar'></i></button>" +
                        "</span> </p> </div>" +
                        "</div>" +
                    "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 4) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                    "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                    "<div style='width:50%;'>" +
                   "<div class='form-group'>" +
                   "<div class='input-group date' id=Id_" + row.Name + " datetimepicker datetimepicker-options=dateTimeOptions" +
                                " data-ng-model=" + row.Name + ">" +
                       "<input type='text' class='form-control'/>" +
                        "<span class='input-group-addon'><span class='glyphicon glyphicon-calendar'></span></span>" +
                         "</div></div>" +
                    "</div>" +
                    "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 5) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                    "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                    "<div style='width:50%;'>" +
                     "<ui-select ng-model=" + row.Name + " ng-disabled='ctrl.disabled'>" +
                          "<ui-select-match placeholder='Search'>{{$select.selected.Value}}</ui-select-match>" +
                            "<ui-select-choices repeat='obj in ddoptions | filter: $select.search'>" +
                               "<span ng-bind-html='obj.Value | highlight: $select.search'></span>" +
                                        "</ui-select-choices> </ui-select>" +
                    "</div>" +
                    "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 6) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                    "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                    "<div style='width:50%;'>" +
                      "<ui-select multiple ng-model=" + row.Name + " theme='bootstrap' close-on-select='false' style='width: 100%;'>" +
                        "<ui-select-match placeholder='Select ...'>{{$item.Value}}</ui-select-match>" +
                        "<ui-select-choices repeat='obj  in msoptions | filter: $select.search'>" +
                            "{{obj.Value}}  </ui-select-choices> </ui-select>" +
                    "</div>" +
                    "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 7) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><input  placeholder='$0.00' ng-model=" + row.Name + " class='form-control' limit-to='20'ui-money-mask/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 8) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + " (%) </label></div>" +
                   "<div style='width:50%;'><input type='number' min='0' max='100' ng-model=" + row.Name + " class='form-control' min='0' max='100' limit-to='3'/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 9) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><input  type='email' ng-model=" + row.Name + " class='form-control' limit-to='30'/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 10) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><input  type='password' ng-model=" + row.Name + " class='form-control' limit-to='20'/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 11) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><input type='tel' ng-model=" + row.Name + " class='form-control'angular-mask='(000)000-0000' limit-to='13'/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 12) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><input type='text' ng-model=" + row.Name + " class='form-control'limit-to='5' minlength='5' maxlength='5' numbers-only/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 13) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'>"+
                    "<span ng-repeat='option in radiooptions' style='padding:5px;'>" +
                     "<label class='i-checks'>"+
                     "<input  style='width:5%' name=" + row.Caption + " type='radio' ng-model=" + row.Name + " value='option.value'> <i></i></label>" +
                     "<span ng-bind-html='option.Value'></span></span>" +
                   "</div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 14) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'>" +
                       "<span ng-repeat='obj in checkboxoptions'style='padding:5px;'>" +
                         "<label class='i-checks'><input style='width:5%' type='checkbox' ng-model ="+row.Name+"  /><i></i>"+
                         "</label> <span ng-bind-html='obj.Value'></span> </span>" +
                   "</div>" +
                   "</div>";
                return htmltext;
            }
          
            else if (row.FieldTypeId == 15) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><textarea rows='5' ng-model=" + row.Name + " class='form-control' limit-to='200'/></div>" +
                   "</div>";
                return htmltext;
            }
            else if (row.FieldTypeId == 16) {
                var htmltext = "";
                return htmltext;
            }
            else if (row.FieldTypeId == 17) {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:70%;'>"+
                   "<div lazy-load='textAngular'>"+
                      "<div text-angular ng-model="+row.Name+" class='btn-groups' name="+row.Name+"></div>"+
                         "<textarea ng-model="+row.Name+" hidden='hidden' name="+row.Name+" id="+row.Name+"></textarea></div></div>" +
                   "</div>";
                return htmltext;
            }
           
            else {
                var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                   "<div style='width:30%;text-align: center;padding:5px;'><label>" + row.Caption + "</label></div>" +
                   "<div style='width:50%;'><span>N/A</span></div>" +
                   "</div>";
                return htmltext;
            }
        }
    }])