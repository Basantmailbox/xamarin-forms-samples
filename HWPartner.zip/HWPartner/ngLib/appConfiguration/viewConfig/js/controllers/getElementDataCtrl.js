﻿app.controller("getElementData", ['$scope', '$http', '$modal', '$rootScope', '$window', '$timeout', '$compile', '$interval',
    function ($scope, $http, $modal, $rootScope, $window, $timeout, $compile, $interval) {
    var vm=this;
    vm.getelementdata = function (row) {
        if (row.FieldTypeId==1) {
            return "<input type='text' style='width:120px;' ng-model=" + row.Name + " class='form-control'/>";
        } else if (row.FieldTypeId == 2) {
            return "<input type='number' style='width:120px;' ng-model=" + row.Name + " class='form-control'/>";
        }
        else if (row.FieldTypeId == 11) {
            return "<input type='tel' style='width:120px;'  ng-model=" + row.Name + " class='form-control'/>";
        }
    }
}])