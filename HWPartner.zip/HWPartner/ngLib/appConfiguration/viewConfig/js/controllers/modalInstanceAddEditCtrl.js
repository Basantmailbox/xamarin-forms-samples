﻿'use strict';
app.controller('modalInstanceAddEditCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'toaster', '$location', 'dataArray',
function ($scope, $http, $modalInstance, $controller, toaster, location,dataArray) {
    $scope.fieldsMetaData = dataArray;
    $scope.obj = {};
    //angular.forEach($scope.fieldsMetaData,function(value,index){
    //    $scope.obj.value.Name
    //})
    $scope.toggleAddEditModal = function () {
        $modalInstance.close("");
    }
    $scope.saveData = function () {
        //var value = $scope.TextBox;
        //alert(value);
    }
}]);