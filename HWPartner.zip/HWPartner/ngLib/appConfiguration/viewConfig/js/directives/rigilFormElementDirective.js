﻿app.directive('rigilFormElement', function () {
    return {
        restrict: "E",
        scope: {
            model: '=',
            fieldtype: '=',
            isprimary: '=',
            label: '=',
        },
        link: function (scope, element, attrs) {
            if (scope.isprimary != true)
            {
                if (scope.fieldtype == 1) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                        "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                        "<div style='width:50%;'><input type='text' ng-model=" + scope.model + " class='form-control'/></div>" +
                        "</div>";
                    element.html(htmltext);
                } else if (scope.fieldtype == 2) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                        "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                        "<div style='width:50%;'><input type='number' ng-model=" + scope.model + " class='form-control'/></div>" +
                        "</div>";
                    element.html(htmltext);
                }
                else if (scope.fieldtype == 7) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                       "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                       "<div style='width:50%;'><input  placeholder='$0.00' ng-model=" + scope.model + " class='form-control' limit-to='20'/></div>" +
                       "</div>";
                    element.html(htmltext);
                }
                else if (scope.fieldtype == 8) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                       "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + " (%) </label></div>" +
                       "<div style='width:50%;'><input type='number' min='0' max='100' ng-model=" + scope.model + " class='form-control' /></div>" +
                       "</div>";
                    element.html(htmltext);
                }
                else if (scope.fieldtype == 9) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                       "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                       "<div style='width:50%;'><input  type='email' ng-model=" + scope.model + " class='form-control' /></div>" +
                       "</div>";
                    element.html(htmltext);
                }
                else if (scope.fieldtype == 11) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                       "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                       "<div style='width:50%;'><input type='tel' ng-model=" + scope.model + " class='form-control'/></div>" +
                       "</div>";
                    element.html(htmltext);
                }
                else if (scope.fieldtype == 12) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                       "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                       "<div style='width:50%;'><input type='text' ng-model=" + scope.model + " class='form-control'limit-to='5' minlength='5' maxlength='5' numbers-only/></div>" +
                       "</div>";
                    element.html(htmltext);
                }
                else if (scope.fieldtype == 15) {
                    var htmltext = "<div  style='display:inline-flex;width:100%;padding:5px;'>" +
                       "<div style='width:30%;text-align: center;padding:5px;'><label>" + scope.label + "</label></div>" +
                       "<div style='width:50%;'><textarea rows='5' ng-model=" + scope.model + " class='form-control'/></div>" +
                       "</div>";
                    element.html(htmltext);
                }
            }
            
        }
    }

})