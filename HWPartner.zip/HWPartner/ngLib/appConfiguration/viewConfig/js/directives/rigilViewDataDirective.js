﻿app.directive("rigilViewData", function () {
    return {
        restrict: "E",
        controller: 'getElementData',
        controllerAs: 'getData',
        scope: {
            layout: '=',
            datarray: '=',
        },
        link: function (scope, element, attrs, ctrl) {
            if (scope.layout == 1) {
                var headerhtml = "";
                var rowhtml = "";

                scope.$watch(function () { return scope.datarray; }, function (value) {
                    angular.forEach(value, function (value, index) {
                        if (!(value.IsPrimary)) {
                            headerhtml = headerhtml + "<th>" + value.Caption + "</th>";
                            rowhtml = rowhtml + "<td>" + ctrl.getelementdata(value) + "</td>";
                        }
                    })
                    var htmltext = "<table class='table table-striped'>" +
                    "<thead>" +
                    "<tr>" +
                    headerhtml +
                    "</tr>" +
                    "</thead>" +
                    "<tbody>" +
                    "<tr>" +
                    rowhtml +
                    "</tr>" +
                    "</tbody>" +
                    "</table>";
                    element.html(htmltext);
                })
            }
        }
    }
});
