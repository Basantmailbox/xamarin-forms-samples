﻿app.directive("rigilView", function ($compile) {
    return {
        restrict: "E",
        controller: 'formElement',
        controllerAs: 'FrmEle',
        scope: {
            layout: '=',
            datarray: '=',
            formname: '=',
            ddoptions:'=',
            msoptions:'=',
            radiooptions: '=',
            checkboxoptions:'=',
        },
        link: function (scope, element, attrs, ctrl) {
            if (scope.layout == 1) {
                var html = "";
                var button = "<div><button ng-click=toggleAddEditModal(); type='button' class='btn btn-info btn-rounded'>Save</button></div>"
                scope.$watch(function () { return scope.datarray; }, function (value) {
                    angular.forEach(value, function (value, index) {
                        if (!(value.IsPrimary)) {
                            html = html + ctrl.formelement(value, scope.ddoptions, scope.msoptions, scope.radiooptions,scope.checkboxoptions);
                        }
                    })
                    var htmltext = "<ng-form class='form-validation' name='" + scope.formname + "'>" +
                    html + 
                    "</ng-form>";
                    var el = angular.element(htmltext);
                    $compile(el)(scope);
                    element.html(el);
                })
            }
        }
    }
});

