﻿app.factory('genericViewService', [
    '$http',
    function ($http) {
        return {

            getAllFieldsList: function (id) {
                return $http.get('/AppConfiguration/FieldMetaData?tableId=' + id).
                success(function (data, status, headers) {
                    console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            }
        }
    }
]);