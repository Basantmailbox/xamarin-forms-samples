﻿app.controller("customUDVQuestionnaireConfigCtrl", ['$scope', '$http', '$modal', 'customUDVQuestionnaireConfigService', '$timeout', '$window', 'toaster',
function ($scope, $http, $modal, customUDVQuestionnaireConfigService, $timeout, $window, toaster) {
    $scope.addnew = true;
    $scope.editold = true;
    $scope.delete = true;

    $scope.save = false;
    $scope.cancel = false;
    $scope.isadding = false;
    $scope.isediting = false;
    $scope.currentindex = 0;

    $scope.allDataSet = [];
    $scope.backupDataSet = [];
    $scope.newrecord = {};

    // DTO model (javascript mirror of server side class [ TBL_UserForm_UDV])
    var objCustomValue = {
        Id: 0,
        Value: "",
        Weightage:"",
        Add: false,
        Edit: false,
        Delete: false
    }

    $scope.loaddata = function () {
        //api service call of all custom user values together
        $scope.allDataSet = [];
        customUDVQuestionnaireConfigService.getAllUserDefinedValues().then(function (response) {
            $scope.allDataSet = response.data.list;
        });
    }
    // load at run time
    $scope.loaddata();

    // Method to add a new entry
    $scope.addnewRecord = function () {
        $scope.backupDataSet = angular.copy($scope.allDataSet);  //will be used in case of undo
        $scope.newrecord = {
            Id: 0,
            Value: "",
            Weightage: "",
            Add: true,
            Edit: false,
            Delete: false
        }
        $scope.isadding = true;
        $scope.allDataSet.push($scope.newrecord);
        $scope.currentindex = $scope.allDataSet.length - 1;
    }

    // Method to edit an old  entry
    $scope.editoldRecord = function (index) {

        $scope.backupDataSet = angular.copy($scope.allDataSet);  //will be used in case of undo
        $scope.isediting = true;
        $scope.allDataSet[index].Edit = true;
        $scope.currentindex = index;

    }

    $scope.validateEntry = function (index) {
        //check for duplicate names
        var array = $scope.allDataSet[index].Value.split(',');
        var weightagearray = $scope.allDataSet[index].Weightage.split(',');
       
        var invalidentry = hasDuplicates(array);
        if (!invalidentry) {
            if (array.length == weightagearray.length)
            {
                var invalidvalues = hasCorrectValues(weightagearray);
                if (!invalidvalues) {
                    var updated = ParseWeightage(index, weightagearray);
                    $scope.saveRecord(index);
                }
                else {
                    toaster.pop('error', 'Error', "Weightages should be number and lie between 0 and 10");
                }
            }
            else
            {
                toaster.pop('error', 'Error', "The number of Values and Weightage does not match.Please make sure that the number of comma separated values and weightage matches");
            }
            
        }
        else {
            toaster.pop('error', 'Error', "Duplicate values are not allowed");
        }
    }
    function hasDuplicates(array) {
        var valuesSoFar = Object.create(null);
        for (var i = 0; i < array.length; ++i) {
            var value = array[i];
            if (value in valuesSoFar) {
                return true;
            }
            valuesSoFar[value] = true;
        }
        return false;
    }

    function hasCorrectValues(weightagelist) {
        var returnvalue = false;
        for (var i = 0; i < weightagelist.length; ++i) {
            var value = parseFloat(weightagelist[i]);
            if (value < 0 || value > 10 || isNaN(value))
            {
                returnvalue = true;
            }
        }
        return returnvalue;
    }
    function ParseWeightage(indx,weightagearray) {
        var bool = true;
        angular.forEach(weightagearray, function (value, index) {
            weightagearray[index] = parseFloat(value);
        })
        $scope.allDataSet[indx].Weightage = weightagearray.join();
        return bool;
    }
    // Method to save a  record (whether adding / editing)
    $scope.saveRecord = function (index) {
        if ($scope.isadding)    //i.e. new addition
        {
            customUDVQuestionnaireConfigService.postUserDefinedValues($scope.allDataSet[$scope.currentindex]).then(function (response) {
                $scope.allDataSet[$scope.currentindex].Id = response.data.NewRecord.Id;
                $scope.allDataSet[$scope.currentindex].Add = false;
                $scope.allDataSet[$scope.currentindex].Edit = false;
                $scope.allDataSet[$scope.currentindex].Delete = false;
                $scope.isadding = false;
                toaster.pop('success', 'Success', "Insert successful !");
            });
        }
        if ($scope.isediting)    //i.e. existing modification
        {
            $scope.allDataSet[index].Edit = false;
            $scope.isediting = false;

            customUDVQuestionnaireConfigService.putUserDefinedValues($scope.allDataSet[index].Id, $scope.allDataSet[$scope.currentindex]).then(function (response) {
                toaster.pop('success', 'Success', "Update successful!");
            });
        }
    }

    // Method to cancel an in-progress Table entry (whether adding / editing)
    $scope.cancelState = function (index) {
        $scope.isadding = false;
        $scope.isediting = false;
        $scope.allDataSet = angular.copy($scope.backupDataSet);  //restore from backup
    }
    $scope.deleteRecord = function (index) {
        var Id = $scope.allDataSet[index].Id;
        var ans = confirm("Are you sure you want to delete it?");
        if (ans) {
            customUDVQuestionnaireConfigService.deleteUserDefinedValues(Id).then(function (response) {
                if (response.data.result == "Success") {
                    $scope.allDataSet.splice(index, 1);
                    toaster.pop('success', 'Success', "Deleted successfully !");
                }
                else if (response.data.result == "NotPossible") {
                    toaster.pop('info', 'Alert!!!', "Disassociate Field records associated with this Value first!!!");
                }
                else {
                    toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                }
            });
        }
    }

}]);