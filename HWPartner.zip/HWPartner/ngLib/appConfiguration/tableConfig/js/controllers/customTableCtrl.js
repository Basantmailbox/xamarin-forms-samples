﻿'use strict';
app.directive('autoFocus', function ($timeout) {
    return {
        restrict: 'AC',
        link: function (_scope, _element) {
            $timeout(function () {
                _element[0].focus();
            }, 0);
        }
    };
});
app.controller('customTableCtrl', ['$scope', '$http', '$modal', 'customTableService', '$timeout', '$window', 'toaster',
function ($scope, $http, $modal, customTableService, $timeout, $window, toaster) {
    // Initialize variables

    $scope.addnew = true;
    $scope.editold = true;
    $scope.delete = true;

    $scope.save = false;
    $scope.cancel = false;
    $scope.isadding = false;
    $scope.isediting = false;
    $scope.currentindex = 0;
    $scope.moduleFilter = 1;
    $scope.moduleNameFilter = "Bid";


    function getModuleName() {
        angular.forEach($scope.modules, function (value, index) {
            if (value.Id == $scope.moduleFilter) {
                $scope.moduleNameFilter = value.Name;
            }
        })
    }
    $scope.filtered_tableset = [];
    $scope.backup_tableset = [];
    $scope.newrecord = {};

    $scope.old_sequence = 0;
    $scope.old_table = "";
    $scope.old_description = "";

    $scope.oldvalue = [];
    $scope.newvalue = [];

    // DTO model (javascript mirror of server side class [TBL_Table])
    var objTable = {
        Id: 0,
        Name: "",
        Caption:"",
        ModuleId: "",
        Description: "",
        Add: false,
        Edit: false,
        Delete: false
    }

    // Method to load record states for different modules
    $scope.loaddata = function () {
        //api service call of all modules together
        customTableService.getAllModules().then(function (response) {
            $scope.modules = response.data.ModuleList;              //populating list of modules to show in a module dropdown in UI
        });
        getTables();
    }
    $scope.changeData = function () {
        getModuleName();
        getTables();
    }
    function getTables() {
        customTableService.getTables($scope.moduleFilter).then(function (response) {
            $scope.filtered_tableset = response.data.TablesList;           //populating list of tables per selected module (default module 'Bid')
        });
    }
    // load at run time
    $scope.loaddata();

    // Method to add a new Table
    $scope.addnewRecord = function () {

        $scope.backup_tableset = angular.copy($scope.filtered_tableset);  //will be used in case of undo

        $scope.newrecord = {
            Id: 0,
            ModuleId: $scope.moduleFilter,
            ModuleName: $scope.moduleNameFilter,
            Name: "",
            Description: "",
            Caption: "",
            Add: true,
            Edit: false,
            Delete: false
        }

        $scope.isadding = true;

        $scope.filtered_tableset.push($scope.newrecord);
        $scope.currentindex = $scope.filtered_tableset.length - 1;

    }

    // Method to edit an old Table entry
    $scope.editoldRecord = function (index) {

        $scope.backup_tableset = angular.copy($scope.filtered_tableset);  //will be used in case of undo

        $scope.isediting = true;
        $scope.filtered_tableset[index].Edit = true;

        $scope.old_table = $scope.filtered_tableset[index].Recordstatename;
        $scope.old_description = $scope.filtered_tableset[index].Description;

        $scope.currentindex = index;

    }
    $scope.validateTableEntry = function (index) {
        //check for duplicate name
        if ($scope.filtered_tableset.length == 1) {
            $scope.saveState(index);
        }
        else {
            var bool = validateTableMethod();
            if (bool) {
                $scope.saveState(index);
            }
        }

    }
    function validateTableMethod() {
        var bool = true;
        var name = $scope.filtered_tableset[$scope.currentindex].Name;
        var caption = $scope.filtered_tableset[$scope.currentindex].Caption;
        angular.forEach($scope.filtered_tableset, function (val, indx) {
            if (indx != $scope.currentindex) {
                if (val.Name == name) {
                    bool = false;
                    toaster.pop('error', 'Error', "Table Name cannot be duplicate");
                }
                if (val.Caption == caption) {
                    bool = false;
                    toaster.pop('error', 'Error', "Caption cannot be duplicate");
                }
            }
        })
        return bool;
    }

    $scope.tableCaptionChange = function (flag) {
        if (flag) {
            if ($scope.filtered_tableset[$scope.currentindex].Caption != "" && $scope.filtered_tableset[$scope.currentindex].Caption != undefined) {
                var caption = $scope.filtered_tableset[$scope.currentindex].Caption;
                var name = caption.replace(/ /g, '');
                $scope.filtered_tableset[$scope.currentindex].Name = name;
            }
        }
    }
    // Method to save a Table record (whether adding / editing)
    $scope.saveState = function (index) {
        if ($scope.isadding)    //i.e. new addition
        {
            customTableService.postTable($scope.filtered_tableset[$scope.currentindex]).then(function (response) {
                $scope.filtered_tableset[$scope.currentindex].Id = response.data.NewRecord.Id;
                $scope.filtered_tableset[$scope.currentindex].Add = false;
                $scope.filtered_tableset[$scope.currentindex].Edit = false;
                $scope.filtered_tableset[$scope.currentindex].Delete = false;
                $scope.isadding = false;
                toaster.pop('success', 'Success', "Insert successful !");
            });
        }
        if ($scope.isediting)    //i.e. existing modification
        {
            $scope.filtered_tableset[index].Edit = false;
            $scope.isediting = false;

            customTableService.putTable($scope.filtered_tableset[index].Id, $scope.filtered_tableset[$scope.currentindex]).then(function (response) {
                toaster.pop('success', 'Success', "Update successful!");
            });
        }
    }

    // Method to cancel an in-progress Table entry (whether adding / editing)
    $scope.cancelState = function (index) {
        $scope.isadding = false;
        $scope.isediting = false;
        $scope.filtered_tableset = angular.copy($scope.backup_tableset);  //restore from backup
    }

    // Method to delete a Table entry
    $scope.deleteState = function (index) {
        var Id = $scope.filtered_tableset[index].Id;
        var ans = confirm("Are you sure you want to delete it?");
        if (ans) {
            customTableService.deleteTable($scope.filtered_tableset[index].Id).then(function (response) {
                if (response.data.result == "Success") {
                    $scope.filtered_tableset.splice(index, 1);
                    toaster.pop('success', 'Success', "Deleted successfully !");
                }
                else if (response.data.result == "NotPossible") {
                    toaster.pop('info', 'Alert!!!', "Disassociate " + $scope.moduleNameFilter + " records with this Table first!!!");
                }
                else {
                    toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                }
            });
        }
    }
}]);