﻿// Service definition for Custom Table Configuration
app.factory('customTableService', [
    '$http',
    function ($http) {
        return {
            getAllModules: function () {
                return $http.get('/AppConfiguration/Modules').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getTables: function (moduleId) {
                return $http.get('/AppConfiguration/Tables?moduleId='+moduleId).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postTable: function (obj) {
                return $http.post('/AppConfiguration/PostTableSet', obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putTable: function (id,obj) {
                return $http.put('/AppConfiguration/PutTableSet?id=' + id, obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteTable: function (id) {
                return $http.delete('/AppConfiguration/DeleteTableSet?id=' + id).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            }
        }
    }
]);