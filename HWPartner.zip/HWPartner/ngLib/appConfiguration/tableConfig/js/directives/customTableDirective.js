﻿app.directive('customTable', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        templateUrl: 'Scripts/app/appConfiguration/tableConfig/partials/customTable.html',
        controller: 'customTableCtrl',
        link: function ($scope, $element, attr) {
        }
    }
    }]);