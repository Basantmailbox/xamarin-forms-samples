﻿app.directive('customConstantTypes', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        templateUrl: 'Scripts/app/appConfiguration/customDropDownConfig/partials/customDDConstantType.html',
        controller: 'customDDConstantTypeCtrl',
        link: function ($scope, $element, attr) {
        }
    }
    }]);