﻿app.directive('customConstantValues', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        templateUrl: 'Scripts/app/appConfiguration/customDropDownConfig/partials/customDDConstant.html',
        controller: 'customDDCtrl',
        link: function ($scope, $element, attr) {
        }
    }
    }]);