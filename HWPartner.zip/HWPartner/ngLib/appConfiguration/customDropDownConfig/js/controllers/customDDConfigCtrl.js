﻿
app.controller("customDDConfigCtrl", function ($scope, $http, $log, $window, toaster, customDDConfigService, $compile) {

    $scope.showData = false;// for removing field directive from Dom and loading it with latest data on tab click
    $scope.AddConstantValuesDirective = function () {
        $scope.showData = true;
    }

    $scope.removeAllDirectives = function () {
        $scope.showData = false;
    }
  
});

