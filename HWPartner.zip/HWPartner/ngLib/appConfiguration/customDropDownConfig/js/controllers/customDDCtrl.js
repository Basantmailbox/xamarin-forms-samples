﻿app.controller("customDDCtrl", ['$scope', '$http', '$modal', 'customDDConfigService', '$timeout', '$window', 'toaster',
function ($scope, $http, $modal, customDDConfigService, $timeout, $window, toaster) {

    // Initialize variables
    $scope.addnew = true;
    $scope.editold = true;
    $scope.delete = true;

    $scope.save = false;
    $scope.cancel = false;
    $scope.isadding = false;
    $scope.isediting = false;
    $scope.currentindex = 0;
    $scope.isNotValid = true;
    $scope.stateFilter = "";
    $scope.stateFilterCaption = "";
    $scope.stateFilterId=0;
   
    $scope.allConstantTypes = [];
    //$scope.test = $window.localStorage.getItem('stateFilter');
    //if ($scope.test == null) { $scope.stateFilter = "PROPOSALSTAGE"; } else { $scope.stateFilter = $scope.test; }


    $scope.filtered_dropdownstates = [];
    $scope.backup_dropdownstates = [];
    $scope.newrecord = {};

    $scope.old_sequence = 0;
    $scope.old_dropdownstate = "";
    $scope.old_constant = "";

    $scope.oldvalue = [];
    $scope.newvalue = [];

    // DTO model (javascript mirror of server side class [RecordState])
    var objRecordState = {
        Id: 0,
        Constant_Type: "",
        Constant: "",
        Order: 0,
        Add: false,
        Edit: false,
        Delete: false
    }

    // Method to load dropdown states for different modules
    $scope.changeConstantType = function () {
        angular.forEach($scope.allConstantTypes, function (value, index) {
            if (value.Id == $scope.stateFilterId)
            {
                $scope.stateFilter = value.Constant_Type;
                $scope.stateFilterCaption = value.ConstantTypeCaption;
            }
        })
        getAllData();
        //$window.localStorage.setItem('stateFilter', $scope.stateFilter);
    }
    function getAllData() {
           $scope.filtered_dropdownstates = [];
        customDDConfigService.getAllConstantValues($scope.stateFilter).then(function (response) {
            $scope.filtered_dropdownstates = response.data.list;              
        });
    }
    // load at run time
    onload();
    function onload() {
        customDDConfigService.getAllConstantTypes().then(function (response) {
            $scope.allConstantTypes = response.data.list;              
        });
    }

    // Method to add a new dropdown state
    $scope.addnewRecord = function () {

        $scope.backup_dropdownstates = angular.copy($scope.filtered_dropdownstates);  //will be used in case of undo

        $scope.newrecord = {
            Id: 0,
            Constant_Type: $scope.stateFilter,
            Constant_TypeCaption: $scope.stateFilterCaption,
            Constant: "",
            Order: $scope.filtered_dropdownstates.length + 1,
            Add: true,
            Edit: false,
            Delete: false
        }

        $scope.isadding = true;

        $scope.filtered_dropdownstates.push($scope.newrecord);
        $scope.currentindex = $scope.filtered_dropdownstates.length - 1;

    }

    // Method to edit an old dropdown state
    $scope.editoldRecord = function (index) {

        $scope.backup_dropdownstates = angular.copy($scope.filtered_dropdownstates);  //will be used in case of undo

        $scope.isediting = true;
        $scope.filtered_dropdownstates[index].Edit = true;

        $scope.old_constant = $scope.filtered_dropdownstates[index].Constant;

        $scope.currentindex = index;

    }
    $scope.validateEntry = function (index) {
        //check for duplicate name
        if ($scope.filtered_dropdownstates.length == 1) {
            $scope.saveState(index);
        }
        else {
            var bool = validateMethod();
            if (bool) {
                $scope.saveState(index);
            }
        }

    }
    function validateMethod() {
        var bool = true;
        var name = $scope.filtered_dropdownstates[$scope.currentindex].Constant;
        angular.forEach($scope.filtered_dropdownstates, function (val, indx) {
            if (indx != $scope.currentindex) {
                if (val.Constant == name) {
                    bool = false;
                    toaster.pop('error', 'Error', "Name cannot be duplicate");
                }
            }
        })
        return bool;
    }
    // Method to save a dropdown state (whether adding / editing)
    $scope.saveState = function (index) {
        if ($scope.isadding)    //i.e. new addition
        {
            customDDConfigService.postCustomValues($scope.filtered_dropdownstates).then(function (response) {
                if (response.data.result == "success")
                {
                    getAllData();
                    $scope.isadding = false;
                    toaster.pop('success', 'Success', "Insert successful !");
                }
                else {
                    toaster.pop('error', 'Error', "An error occured while insertion");
                }
            });
        }
        if ($scope.isediting)    //i.e. existing modification
        {
            $scope.filtered_dropdownstates[index].Edit = false;
            $scope.isediting = false;
            customDDConfigService.putCustomValues($scope.filtered_dropdownstates[index].Id,$scope.filtered_dropdownstates).then(function (response) {
                if (response.data.result == "success") {
                    toaster.pop('success', 'Success', "Update successful !");
                }
                else {
                    toaster.pop('error', 'Error', "An error occured while updation");
                }
            });
        }

    }

    // Method to move order of a row up
    $scope.moveUp = function (index) {
        var selectedrecord = objRecordState;
        selectedrecord = $scope.filtered_dropdownstates[index];
        $scope.filtered_dropdownstates.splice(index, 1);
        var newpos = index - 1;
        if (newpos < 0) { newpos = $scope.filtered_dropdownstates.length; }
        $scope.filtered_dropdownstates.splice(newpos, 0, selectedrecord);
        angular.forEach($scope.filtered_dropdownstates, function (value, index) {
            value.Order = index + 1;
        })
    }

    // Method to move order of a row down
    $scope.moveDown = function (index) {
        var selectedrecord = objRecordState;
        selectedrecord = $scope.filtered_dropdownstates[index];
        $scope.filtered_dropdownstates.splice(index, 1);
        var newpos = index + 1;
        if (newpos > $scope.filtered_dropdownstates.length) { newpos = 0; }
        $scope.filtered_dropdownstates.splice(newpos, 0, selectedrecord);
        angular.forEach($scope.filtered_dropdownstates, function (value, index) {
            value.Order = index + 1;
        })
    }

    // Method to cancel a dropdown state (whether adding / editing)
    $scope.cancelState = function (index) {
        $scope.isadding = false;
        $scope.isediting = false;
        $scope.filtered_dropdownstates = angular.copy($scope.backup_dropdownstates);  //restore from backup
    }

    // Method to delete a dropdown state
    $scope.deleteState = function (index) {
        var Id = $scope.filtered_dropdownstates[index].Id;
        var ans = confirm("Are you sure you want to delete it?");
        if (ans) {
            customDDConfigService.deleteCustomValues($scope.filtered_dropdownstates[index].Id).then(function (response) {
                if (response.data.result == "Success") {
                    $scope.filtered_dropdownstates.splice(index, 1);
                    angular.forEach($scope.filtered_dropdownstates, function (value, index) {
                        value.Order = index + 1;
                    })
                    toaster.pop('success', 'Success', "Deleted successfully !");
                }
                else if (response.data.result == "NotPossible") {
                    toaster.pop('info', 'Alert!!!', "Disassociate records with this Value first!!!");
                }
                else {
                    toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                }
            });
        }
    }
}]);

