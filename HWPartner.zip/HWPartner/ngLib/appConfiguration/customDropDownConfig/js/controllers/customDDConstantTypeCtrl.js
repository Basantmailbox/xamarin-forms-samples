﻿app.controller('customDDConstantTypeCtrl', ['$scope', '$http', '$modal', 'customDDConfigService', '$timeout', '$window', 'toaster',
function ($scope, $http, $modal, customDDConfigService, $timeout, $window, toaster) {
        $scope.addnew = true;
        $scope.editold = true;
        $scope.delete = true;

        $scope.save = false;
        $scope.cancel = false;
        $scope.isadding = false;
        $scope.isediting = false;
        $scope.currentindex = 0;
       
        $scope.allDataSet = [];
        $scope.backupDataSet = [];
        $scope.newrecord = {};

        // DTO model (javascript mirror of server side class [CustomDropDownType])
        var objCustomType = {
            Id: 0,
            Constant_Type: "",
            ConstantTypeCaption: "",
            Add: false,
            Edit: false,
            Delete: false
        }

        // Method to load record states for different modules
        $scope.loaddata = function () {
            //api service call of all coustom types together
            customDDConfigService.getAllConstantTypes().then(function (response) {
                $scope.allDataSet = response.data.list;              
            });
        }
        // load at run time
        $scope.loaddata();

        
        $scope.CustomTypeCaptionChange = function (flag) {
            if (flag) {
                if ($scope.allDataSet[$scope.currentindex].ConstantTypeCaption != "" && $scope.allDataSet[$scope.currentindex].ConstantTypeCaption != undefined) {
                    var caption = $scope.allDataSet[$scope.currentindex].ConstantTypeCaption;
                    var name = caption.replace(/ /g, '');
                    $scope.allDataSet[$scope.currentindex].Constant_Type = name;
                }
            }
        }
        // Method to add a new Table
        $scope.addnewRecord = function () {
            $scope.backupDataSet = angular.copy($scope.allDataSet);  //will be used in case of undo
            $scope.newrecord = {
                Id: 0,
                Constant_Type: "",
                ConstantTypeCaption: "",
                Add: true,
                Edit: false,
                Delete: false
            }
            $scope.isadding = true;
            $scope.allDataSet.push($scope.newrecord);
            $scope.currentindex = $scope.allDataSet.length - 1;
        }

        // Method to edit an old Table entry
        $scope.editoldRecord = function (index) {

            $scope.backupDataSet = angular.copy($scope.allDataSet);  //will be used in case of undo

            $scope.isediting = true;
            $scope.allDataSet[index].Edit = true;

            $scope.old_table = $scope.allDataSet[index].Recordstatename;
            $scope.old_description = $scope.allDataSet[index].Description;

            $scope.currentindex = index;

        }
        $scope.validateEntry = function (index) {
            //check for duplicate name
            if ($scope.allDataSet.length == 1) {
                $scope.saveState(index);
            }
            else {
                var bool = validateMethod();
                if (bool) {
                    $scope.saveState(index);
                }
            }

        }
        function validateMethod() {
            var bool = true;
            var name = $scope.allDataSet[$scope.currentindex].Constant_Type;
            var caption = $scope.allDataSet[$scope.currentindex].ConstantTypeCaption;
            angular.forEach($scope.allDataSet, function (val, indx) {
                if (indx != $scope.currentindex) {
                    if (val.Constant_Type == name) {
                        bool = false;
                        toaster.pop('error', 'Error', "Name cannot be duplicate");
                    }
                    if (val.ConstantTypeCaption == caption) {
                        bool = false;
                        toaster.pop('error', 'Error', "Caption cannot be duplicate");
                    }
                }
            })
            return bool;
        }

       
        // Method to save a Table record (whether adding / editing)
        $scope.saveState = function (index) {
            if ($scope.isadding)    //i.e. new addition
            {
                customDDConfigService.postCustomType($scope.allDataSet[$scope.currentindex]).then(function (response) {
                    $scope.allDataSet[$scope.currentindex].Id = response.data.NewRecord.Id;
                    $scope.allDataSet[$scope.currentindex].Add = false;
                    $scope.allDataSet[$scope.currentindex].Edit = false;
                    $scope.allDataSet[$scope.currentindex].Delete = false;
                    $scope.isadding = false;
                    toaster.pop('success', 'Success', "Insert successful !");
                });
            }
            if ($scope.isediting)    //i.e. existing modification
            {
                $scope.allDataSet[index].Edit = false;
                $scope.isediting = false;

                customDDConfigService.putCustomType($scope.allDataSet[index].Id, $scope.allDataSet[$scope.currentindex]).then(function (response) {
                    toaster.pop('success', 'Success', "Update successful!");
                });
            }
        }

        // Method to cancel an in-progress Table entry (whether adding / editing)
        $scope.cancelState = function (index) {
            $scope.isadding = false;
            $scope.isediting = false;
            $scope.allDataSet = angular.copy($scope.backupDataSet);  //restore from backup
        }

        // Method to delete a Table entry
        $scope.deleteState = function (index) {
            var Id = $scope.allDataSet[index].Id;
            var ans = confirm("Are you sure you want to delete it?");
            if (ans) {
            customDDConfigService.deleteCustomType($scope.allDataSet[index].Id).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.allDataSet.splice(index, 1);
                        toaster.pop('success', 'Success', "Deleted successfully !");
                    }
                    else if (response.data.result == "NotPossible") {
                        toaster.pop('info', 'Alert!!!', "Disassociate records with this Type first!!!");
                    }
                    else {
                        toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                    }
                });
            }
        }
    }]);