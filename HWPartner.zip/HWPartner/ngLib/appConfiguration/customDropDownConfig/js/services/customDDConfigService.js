﻿app.factory('customDDConfigService', [
    '$http',
    function ($http) {
        return {
            getAllConstantTypes: function () {
                return $http.get('/CustomDropDownConfiguration/AllCustomTypes').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postCustomType: function (obj) {
                return $http.post('/CustomDropDownConfiguration/PostCustomType', obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putCustomType: function (id, obj) {
                return $http.put('/CustomDropDownConfiguration/PutCustomType?id=' + id, obj).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteCustomType: function (id) {
                return $http.delete('/CustomDropDownConfiguration/DeleteCustomType?id=' + id).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
             getAllConstantValues: function (constantType) {
                 return $http.get('/CustomDropDownConfiguration/AllCustomValues?constantType=' + constantType).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
             },
             postCustomValues: function (obj) {
                 return $http.post('/CustomDropDownConfiguration/PostCustomValues', obj).
                   success(function (data, status, headers) {
                       console.log("success" + data);
                   }).
                   error(function (data, status, headers) {
                       console.log("error");
                   });
             },
             putCustomValues: function (id, obj) {
                 return $http.put('/CustomDropDownConfiguration/PutCustomValues?id=' + id, obj).
                   success(function (data, status, headers) {
                       console.log("success" + data);
                   }).
                   error(function (data, status, headers) {
                       console.log("error");
                   });
             },
             deleteCustomValues: function (id) {
                 return $http.delete('/CustomDropDownConfiguration/DeleteCustomValues?id=' + id).
                   success(function (data, status, headers) {
                       console.log("success" + data);
                   }).
                   error(function (data, status, headers) {
                       console.log("error");
                   });
             },
        }
    }
]);