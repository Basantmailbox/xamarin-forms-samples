﻿// Service definition for Custom Form Configuration
app.factory('customFormService', [
    '$http',
    function ($http) {
        return {
            getAllSection: function () {
                return $http.get('/AppConfiguration/AllSectionsDD').
                  success(function (data, status, headers) {
                      // console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getTabs: function (moduleId) {
                return $http.get('/AppConfiguration/AllTabs?moduleId=' + moduleId).
               success(function (data, status, headers) {
                  }).
               error(function (data, status, headers) {
                 console.log("error");
                 });
            },
            getAllForms: function () {
                return $http.get('/AppConfiguration/AllForms').
                  success(function (data, status, headers) {
                      // console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            checkFormValidation: function (id, modId, tabId) {
                return $http.get('/AppConfiguration/CheckForm?id=' + id + '&modId=' + modId + '&tabId=' + tabId).
                success(function (data, status, headers) {
                    // console.log("success" + data);
                }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postForm: function (obj) {
                return $http.post('/AppConfiguration/PostFormSet',obj).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putForm: function (id, obj) {
                return $http.put('/AppConfiguration/PutFormSet?id=' + id, obj).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteForm: function (id) {
                return $http.delete('/AppConfiguration/DeleteFormSet?id=' + id).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            }

        }
    }
]);