﻿app.directive('customForm', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        transclude: true,
        templateUrl: 'Scripts/app/appConfiguration/formSetUpConfig/partials/customForm.html',
        controller: 'customFormCtrl',
        link: function ($scope, $element, attr) {
        }
    }
}]);