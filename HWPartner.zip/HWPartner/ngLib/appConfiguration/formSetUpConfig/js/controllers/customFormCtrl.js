﻿'use strict';

app.controller('customFormCtrl', ['$scope', '$http', '$modal', 'customFormService', '$timeout', '$window', 'toaster','customTableService',
    function ($scope, $http, $modal, customFormService, $timeout, $window, toaster, customTableService) {
        $scope.addNewForm = true;
        $scope.editOldForm = false;
        $scope.deleteForm = false;

        $scope.saveForm = false;
        $scope.cancelForm = false;
        $scope.isAddingForm = false;
        $scope.isEditingForm = false;
        $scope.currentFormIndex = 0;

        $scope.formSet = [];// contains all the forms
        $scope.formBackUpSet = [];//contains the back up  of formSet
        $scope.newFormRecord = {};

        $scope.allSections = [];
        $scope.allTabs = [];
        $scope.allModules = [];

        // Method to load all sections and forms
        $scope.loadFormData = function () {
            getFormData();
            //api service call to get all the sections
            customFormService.getAllSection().then(function (response) {
                $scope.allSections = response.data.SectionList;              //populating list of sections to show in a table dropdown in UI
            });
            //api service call of all modules together
            customTableService.getAllModules().then(function (response) {
                $scope.allModules = response.data.ModuleList;              //populating list of modules to show in a module dropdown in UI
            });
        }
        // load at run time
        $scope.loadFormData();

        function getFormData() {
            //api service call to get all the sections
            customFormService.getAllForms().then(function (response) {
                $scope.formSet = response.data.FormList;              //populating list of forms 
                if ($scope.formSet.length > 0) {
                    $scope.editOldForm = true;
                    $scope.deleteForm = true;
                }
            });
        }

        $scope.onModuleSelection = function (selectedModule,index) {
            $scope.allTabs = [];
            $scope.formSet[index].TabObj = {};
            customFormService.getTabs(selectedModule.Id).then(function (response) {
                $scope.allTabs = response.data.TabList;           //populating list of tabs per selected module.
            });
        }
        // Method to add a new Section
        $scope.addnewFormRecord = function () {

            $scope.newFormRecord = {
                Id: 0,
                Name: "",
                Add: true,
                Edit: false,
                Delete: false,
                TabId: 0,
                ModuleId:0,
                SectionId: "",
                TabName: "",
                ModuleName: "",
                SectionsName: "",
                TabObj: {},
                ModuleObj: {},
                SectionObj: []
            }

            $scope.isAddingForm = true;
            $scope.formSet.push($scope.newFormRecord);
            $scope.currentFormIndex = $scope.formSet.length - 1;
        }


        $scope.editOldFormRecord = function (index) {
            $scope.formBackUpSet = angular.copy($scope.formSet);  //will be used in case of undo
            $scope.isEditingForm = true;
            $scope.formSet[index].Edit = true;
            $scope.currentFormIndex = index;
            $scope.onModuleSelection($scope.formSet[index].ModuleObj);
        }

        $scope.deleteFormRecord = function (index) {
            var Id = $scope.formSet[index].Id;
            var ans = confirm("Are you sure you want to delete it?");
            if (ans) {
                customFormService.deleteForm($scope.formSet[index].Id).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.formSet.splice(index, 1);
                        toaster.pop('success', 'Success', "Deleted successfully !");
                    }
                    else if (response.data.result == "NotPossible") {
                        toaster.pop('info', 'Alert!!!', "Disassociate records with this form first!!!");
                    }
                    else {
                        toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                    }
                });
            }

        }
        $scope.validateFormEntry = function (index) {
            //check for duplicate form names
            if ($scope.formSet.length == 1) {
                $scope.saveFormRecord(index);
            }
            else {
                var bool = validateFormMethod();
                if (bool) {
                    customFormService.checkFormValidation($scope.formSet[$scope.currentFormIndex].Id, $scope.formSet[$scope.currentFormIndex].ModuleObj.Id, $scope.formSet[$scope.currentFormIndex].TabObj.Id).then(function (response) {
                        if (response.data.result == "Success") {
                            $scope.saveFormRecord(index);
                        }
                        else if (response.data.result == "Duplicate") {
                            toaster.pop('info', 'Information', "Form already exist for this  Module-Tab combination");
                            $scope.saveFormRecord(index);
                        }
                        else
                        {
                            toaster.pop('error', 'Error', "Error Occured");
                        }
                    });
                }
            }
        }
        function validateFormMethod() {
            var bool = true;
            var name = $scope.formSet[$scope.currentFormIndex].Name;
            angular.forEach($scope.formSet, function (val, indx) {
                if (indx != $scope.currentFormIndex) {
                    if (val.Name.toLowerCase() == name.toLowerCase()) {
                        bool = false;
                        toaster.pop('error', 'Error', "Form Name cannot be duplicate");
                    }
                }
            })
            return bool;
        }
        $scope.saveFormRecord = function (index) {
            if ($scope.isAddingForm)    //i.e. new addition
            {
                customFormService.postForm($scope.formSet[$scope.currentFormIndex]).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.formSet[$scope.currentFormIndex].Id = response.data.NewRecord.Id;
                        $scope.formSet[$scope.currentFormIndex].Add = false;
                        $scope.formSet[$scope.currentFormIndex].Edit = false;
                        $scope.formSet[$scope.currentFormIndex].Delete = false;
                        $scope.isAddingForm = false;
                        toaster.pop('success', 'Success', "Insert successful !");
                    }
                    else {
                        $scope.isAddingForm = false;
                        toaster.pop('error', 'Error', "An error occured while adding form");
                    }
                    getFormData();

                });
            }
            if ($scope.isEditingForm)    //i.e. existing modification
            {
                $scope.formSet[index].Edit = false;
                $scope.isEditingForm = false;

                customFormService.putForm($scope.formSet[index].Id, $scope.formSet[$scope.currentFormIndex]).then(function (response) {
                    if (response.data.result == "Success") {
                        toaster.pop('success', 'Success', "Update successful!");
                    }
                    else {
                        toaster.pop('error', 'Error', "An error occured while editing form");
                    }
                    getFormData();
                });
            }

        }
        $scope.cancelFormRecord = function (index) {
            $scope.isAddingForm = false;
            $scope.isEditingForm = false;
            $scope.formSet = angular.copy($scope.formBackUpSet);  //restore from backup
            getFormData();
        }

    }]);