﻿app.directive('rigilForm', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/FormConfig/partials/customForm.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vm',
        controller: function ($scope, $http) {

            $scope.formid = $scope.vm.formId;
            $scope.moduleid = $scope.vm.moduleId;
            $scope.displayonly = $scope.vm.displayOnly;

            $scope.getSections = function (formid) {
                $http.get("/AppConfiguration/GetForm?id=" + formid).success(function (response) {
                    $scope.form = response.form; //assign fetched FORM row object to this scope variable
                    //what is the form name? I want to put it in the title of the view.
                    $scope.formname = $scope.form.Name;
                    //what sections are contained in the form?
                    $scope.formsections = $scope.form.SectionId;
                    //hey! SectiionId is a comma separated list of Section Ids.
                    //Therefore getting the section details from backend.
                    $http.get("/AppConfiguration/GetSections?sectionids=" + $scope.formsections).success(function (response) {
                        //hey! this section-view details will used to draw the different sections and the related views in the FORM
                        $scope.sections = response.sections;
                    })
                })
            }
        },
        link: function (scope, el, attrs) {
            //render the sections
            scope.getSections(scope.vm.formId);
        }
    }
})

app.directive('rigilListview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/FormConfig/partials/customListview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vc',
        controller: function ($scope, $http, toaster, $sce) {

            //view configuration values from database
            $scope.formid = $scope.vc.formId;
            $scope.moduleid = $scope.vc.moduleId;
            $scope.sectionid = $scope.vc.sectionId;
            $scope.viewid = $scope.vc.viewId;
            $scope.fieldid = parseInt($scope.vc.fieldId);
            $scope.displayonly = $scope.vc.displayOnly;
            $scope.fieldObj = {};

            //to know fieldType this is called because the return value would be used for appropriate display in the UI
            $http.get("/AppConfiguration/GetField?fieldid=" + $scope.fieldid).success(function (response) {
                $scope.fieldObj = response.fieldObject;
            });

            $scope.isadding = false;
            $scope.isediting = false;

            //model of a row
            $scope.row = {
                id: 0,
                linetext: '',
                edit: true
            }
            $scope.dto = {
                formid: 0,
                moduleid: 0,
                sectionid: 0,
                viewid: 0,
                fieldid: 0,
                linetext: ""
            }
            //row insert method
            $scope.addrow = function () {
                $scope.newrow = angular.copy($scope.row);
                $scope.stringTexts.push($scope.newrow);
                $scope.isadding = true;
                $scope.isediting = false;
            }

            //row edit method
            $scope.editrow = function (index) {
                $scope.stringTexts[index].edit = true;
                $scope.isadding = true;
                $scope.isediting = true;
                $scope.backuprow = angular.copy($scope.stringTexts[index]);
            }

            //row save method
            $scope.saverow = function (index) {
                $scope.stringTexts[index].edit = false;
                $scope.isadding = false;
                $scope.isediting = false;

                dto = {
                    id: $scope.stringTexts[index].id,
                    formid: $scope.formid,
                    moduleid: $scope.moduleid,
                    sectionid: $scope.sectionid,
                    viewid: $scope.viewid,
                    fieldid: $scope.fieldid,
                    linetext: $scope.stringTexts[index].linetext
                }

                if ($scope.stringTexts[index].id == 0) {
                    //new record: insert it in table
                    $http.post("/AppConfiguration/PostListline", dto).success(function (response) {
                        $scope.stringTexts[index].id = response.savedId;
                    })
                } else {
                    //old record: update it in table
                    $http.put("/AppConfiguration/PutListline", dto).success(function (response) {

                    })
                }
            }

            //row delete method
            $scope.deleterow = function (index) {
                var ans = confirm("Are you sure?");
                if (ans) {
                    //old record: update it in table
                    $http.delete("/AppConfiguration/DeleteListline?id=" + $scope.stringTexts[index].id).success(function (response) {
                        $scope.stringTexts.splice(index, 1);
                    })
                }
            }

            //row cancel method
            $scope.cancelrow = function (index) {
                //edit case
                if ($scope.isadding && $scope.isediting) {
                    $scope.stringTexts[index] = $scope.backuprow;
                    $scope.stringTexts[index].edit = false;
                }
                //insert case
                if ($scope.isadding && !$scope.isediting) {
                    $scope.stringTexts.splice($scope.stringTexts.length - 1);
                }

                $scope.isadding = false;
                $scope.isediting = false;
            }

            //load existing entries
            $http.get("/AppConfiguration/GetListlines?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid + "&fieldid=" + $scope.fieldid).success(function (response) {
                $scope.stringTexts = response.data;
                //if (fieldObj.FieldTypeId == 17) { //editor
                //    angular.forEach($scope.stringTexts, function (value, index) {
                //        value = $sce.trustAsHtml(value);
                //    })
                //}
            })
        }
    }
})

app.directive('rigilTableview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/FormConfig/partials/customTableview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce,$modal) {

            //VIEW configuration values from database
            $scope.formid = $scope.vt.formId;
            $scope.moduleid = $scope.vt.moduleId;
            $scope.sectionid = $scope.vt.sectionId;
            $scope.viewid = $scope.vt.viewId;
            $scope.displayonly = $scope.vt.displayOnly;
            $scope.fieldids = $scope.vt.fieldId;
            $scope.rows = [];
            $scope.mode = "";
            $scope.isdeletedD = false;
            $scope.isIframe = false;
            $scope.moduleName = "";
           
            getmoduleName();

            function getFields() {
                //fetch the field ids array
                $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                    $scope.fields = response.fielddata;
                   
                    $scope.rows = [];
                    $scope.attachedFiles = [];
                    $scope.row = {};
                    //dynamic open object for the date picker
                    $scope.isOpen = [];
                    //dynamic mouse over event for the money and percentage objects
                    $scope.mouseOver = [];
                    //dynmic checkbox model for storing the checkbox value intermediately
                    //before saving it in the dynamic object itself
                    $scope.checkedData = [];
                    //dynamic datetime option for the datetime picker
                    $scope.dateTimeOptions = [];
                    //dynamic dropdown and multi select Object for ui-select for storing the intermediate object 
                    //before saving it in the dynamic object itself
                    $scope.dropDownObject = [];
                    //prepare the datamodel dynamiclly from fields list
                    angular.forEach($scope.fields, function (value, index) {
                        $scope.row[value.Name] = "";
                        $scope.attachedFiles[value.Id] = [];
                        //dynamic open object for the date picker setting to false default setting
                        $scope.isOpen[value.Id] = false;
                        //dynamic mouse over event for the money and percentage objects  setting to false default setting
                        $scope.mouseOver[value.Id] = false;
                        //dynamic datetime option for the datetime picker specified for each object specifically
                        $scope.dateTimeOptions[value.Id] = { useCurrent: false, showClear: true, showClose: true };
                        //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                        $scope.dropDownObject[value.Id] = {};
                        //for field type checkbox and radio button set the length of array to the length of the list
                        if (value.FieldTypeId == 13 || value.FieldTypeId == 14) {
                            $scope.checkedData[value.Id] = new Array(value.UDVList.length);
                        }
                        if (value.FieldTypeId == 3)//Date Picker  set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                        }
                        if (value.FieldTypeId == 4)//DateTime Picker set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                            $scope.dateTimeOptions[value.Id].maxDate = value.MaxDate;
                            $scope.dateTimeOptions[value.Id].minDate = value.MinDate;
                        }
                    })
                    $scope.row["edit"] = true;
                    $scope.row["id"] = 0;
                    getData();
                })
            }

            function getmoduleName() {
                $http.get("/AppConfiguration/GetModuleName?moduleId=" + $scope.moduleid).success(function (response) {
                    $scope.moduleName = response.data;
                     getFields();
                })
            }

            //The function to open the ui for date picker when the calendar icon is pressed
            $scope.opendp = function ($event, Id) {
                $event.preventDefault();
                $event.stopPropagation();
                var name = "isOpen" + Id;
                $scope[name] = true;
            };

            //default date option for the datepicker
            $scope.dateOptions = {
                class: 'datepicker'
            };

            // To check the validity of zipcode for the respective dynamic object
            $scope.changeZipCode = function (value, id, name) {
                if (value != undefined) {
                    if (value.length == 5) {
                        $http.get("/Home/GetCitynState?zipcode=" + value).success(function (data) {
                            if (data.zipInfo != null) {
                                //success
                            } else {
                                $scope.row[name] = "";
                                toaster.pop('error', 'Error', "Enter a valid zipcode");
                            }
                        }).error(function (data) {
                            $scope.row[name] = "";
                        })
                    }
                    else {
                        $scope.row[name] = "";
                    }
                }
            }

            // To set the value of the checkbox  in the respective dynamic object
            function getSelectedChecked(list, Id) {
                return list.filter(function (x, i) {
                    return $scope.checkedData[Id][i]
                });
            }
            $scope.getCheckedValue = function (name, list, id) {
                var value = getSelectedChecked(list, id);
                $scope.row[name] = value.join(',');
            }

            // To set the value of the dropdown  from drop down in the respective dynamic object
            $scope.getUpdatedDropDownValue = function (index, name, id) {
                var ind = parseInt(index);
                $scope.rows[ind][name] = $scope.dropDownObject[id].Id;
            }

            // To set the value of the selected multiple values from multiselect in the respective dynamic object
            $scope.getUpdatedMultiSelectValue = function (index, name, id) {
                var ind = parseInt(index);
                var selectedlist = $scope.dropDownObject[id];
                var list = [];
                angular.forEach(selectedlist, function (value, index) {
                    list.push(value.Id);
                })
                $scope.rows[ind][name] = list.join(',');
            }

            $scope.isadding = false;
            $scope.isediting = false;
            //*******************   Basic function such as Add ,Edit,delete,cancel  Start*************************************
            //row insert method
            $scope.addrow = function () {
                $scope.newrow = angular.copy($scope.row);
                $scope.rows.push($scope.newrow);
                var len = $scope.rows.length;
                $scope.rows[len - 1]["slno"] = len - 1;
                $scope.isadding = true;
                $scope.isediting = false;
                $scope.dropDownObject = [];
                $scope.mode = "Add";
            }

            //row edit method
            $scope.editrow = function (slno) {
                var index = 0;
                var rowId = "";
                angular.forEach($scope.rows, function (value, indx) {
                    if (value.slno == slno) { index = indx; rowId = value.id;}
                })
                $scope.rows[index].edit = true;
                $scope.isadding = true;
                $scope.isediting = true;
                formatDataSourceCurrentRow(index);
                $scope.backuprow = angular.copy($scope.rows[index]);
                $scope.mode = "Edit";
                getRowAttachments(rowId);
            }

            //row save method
            $scope.saverow = function (slno) {
                var index = 0;
                angular.forEach($scope.rows, function (value, indx) {
                    if (value.slno == slno) { index = indx; }
                })
               

                $scope.dataARRAY = [];
                //create a model for passing field and property value
                //pair in an array to the asp.net mvc controller
                $scope.datarray = {
                    field: "",
                    value: "",
                    fieldid: 0
                }

                //convert property:values of a row to key:value pair array
                angular.forEach($scope.fields, function (value, Index) {
                    $scope.newdatarray = angular.copy($scope.datarray);
                    $scope.newdatarray.field = value.Name;
                    if (value.FieldTypeId == 17) { //editor
                        $scope.newdatarray.value = $sce.valueOf($scope.rows[index][value.Name]);
                    }
                    else {
                        $scope.newdatarray.value = $scope.rows[index][value.Name];
                    }
                    //$scope.newdatarray.value = $scope.rows[index][value.Name];
                    $scope.newdatarray.fieldid = value.Id;
                    $scope.dataARRAY.push($scope.newdatarray);
                })

                //prepare the DTO to go with the post call for row insertion
                dto = {
                    id: $scope.rows[index].id,
                    formid: $scope.formid,
                    moduleid: $scope.moduleid,
                    sectionid: $scope.sectionid,
                    viewid: $scope.viewid,
                    fieldid: $scope.fieldid,
                    row: $scope.dataARRAY
                }

                if ($scope.rows[index].id == 0) {
                    //new record: insert it in table
                    $http.post("/AppConfiguration/PostTablerow", dto).success(function (response) {
                       
                        //check if there is any Attachment field in the table form.
                        var obj = _.filter($scope.fields, function (obj) { if (obj.FieldTypeId == 16) return obj });
                        if (obj != null && obj.length != 0)
                        {
                            var rowId = response.savedId;
                            openAttachmentWindow(rowId, obj);

                        }
                        else
                        {
                         getData();
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                        }
                       
                    })
                } else {
                    //old record: update it in table
                    $http.put("/AppConfiguration/PutTablerow", dto).success(function (response) {
                        getData();
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                }
                
            }

            //row delete method
            $scope.deleterow = function (slno) {
                var index = 0;
                angular.forEach($scope.rows, function (value, indx) {
                    if (value.slno == slno) { index = indx; }
                })
                var ans = confirm("Are you sure?");
                if (ans) {
                    //old record: update it in table
                    $http.delete("/AppConfiguration/DeleteTableline?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid + "&id=" + $scope.rows[index].id).success(function (response) {
                        //$scope.rows.splice(index, 1);
                        getData();
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                }
            }

            //row cancel method
            $scope.cancelrow = function (slno) {
                var index = 0;
                angular.forEach($scope.rows, function (value, indx) {
                    if (value.slno == slno) { index = indx; }
                })
                //edit case
                if ($scope.isadding && $scope.isediting) {
                    $scope.rows[index] = $scope.backuprow;
                    $scope.rows[index].edit = false;
                    // called as the attachment gets directly deleted even if we cancel a edit on a row.
                    var obj = _.filter($scope.fields, function (obj) { if (obj.FieldTypeId == 16) return obj });
                    if (obj != null && obj.length != 0) {
                        updateEachRow();
                    }
                }
                //insert case
                if ($scope.isadding && !$scope.isediting) {
                    $scope.rows.splice($scope.rows.length - 1);
                }
                $scope.isadding = false;
                $scope.isediting = false;
                $scope.mode = "";
            }
            //*******************   Basic function such as Add ,Edit,delete,cancel  End *************************************

            //called so that user can add attachment in Add Mode in table format.
            function openAttachmentWindow(rowId,attachmentFields) {
                var modalInstance = $modal.open({
                    templateUrl: 'Scripts/app/appConfiguration/formConfig/partials/AddAttachmentModal.html',
                    controller: 'modalInstanceAddAttachmentModalCtrl',
                    backdrop: 'static',
                    size: 'lg',
                    scope: $scope,
                    resolve: {
                        rowID: function () {
                            return rowId;
                            },
                        fields : function () {
                            return attachmentFields;
                        },
                        formId: function () {
                            return $scope.formid;
                        },
                        viewId: function () {
                            return $scope.viewid;
                        },
                        sectionId : function () {
                            return $scope.sectionid;
                        },
                        moduleName: function () {
                            return $scope.moduleName;
                            },
                        moduleId: function () {
                            return $scope.moduleid;
                         },
                   }
                });
                modalInstance.result.then(function () {
                    getData();
                    toaster.pop('success', 'Success', "Operation Successfull !!");
                });
            }

            //*************************   Attachment Start *********************************************************
            //1. called when we cancel the edit function on a row.
            //2. called when we fetch the data.
            function updateEachRow() {
                $scope.attachedFilesMaster = [];
                var obj = _.filter($scope.fields, function (obj) { if (obj.FieldTypeId == 16) return obj });
                if (obj != null && obj.length != 0) {
                    angular.forEach(obj, function (val, ind) {
                        getAllAttachmentsData(val.Id, val.Name);
                    })

                }
            }

            //Called from "updateEachRow()"  to fetch the attachments for the fields
            function getAllAttachmentsData(fieldId, fieldName) {
                $http.get("/api/LibraryAppConfiguration/AllIndex?module=" + $scope.moduleName +
                    "&formId=" + $scope.formid + "&fieldId=" + fieldId +
                    "&moduleId=" + $scope.moduleid + "&sectionId=" + $scope.sectionid
                    + "&viewId=" + $scope.viewid).success(function (response) {
                        if (response.uploadresults.length > 0) {
                            var data = response.uploadresults;
                            setAttachedFiles(data, fieldId, fieldName);
                        }

                    })
            }

            // called from "getAllAttachmentsData()" to set the value in the respective rows of a table in list view
            function setAttachedFiles(data, fieldId, fieldName) {
                angular.forEach($scope.rows, function (value, index) {
                    $scope.attachedFilesMaster[index] = [];
                    value[fieldName] = "";
                    var rowId = parseInt(value["id"]);
                    var obj = _.filter(data, function (obj) { if (obj.RowId == rowId) return obj });
                    if (obj.length > 0) {
                        var fileNames = GetAttachmentsName(obj)
                        value[fieldName] = fileNames;
                    }
                })
            }

            //callled from "setAttachedFiles()" to extract the name of files attached from their list 
            function GetAttachmentsName(obj) {
                var Names = [];
                var files = "";
                angular.forEach(obj, function (val, ind) {
                    Names.push(val.fileName);
                })
                files = Names.join(", ");
                return files;
            }

            //get the attachment for that row
            //Called we edit a  row.
            function getRowAttachments(rowId) {
                var obj = _.filter($scope.fields, function (obj) { if (obj.FieldTypeId == 16) return obj });
                if (obj != null && obj.length != 0) {
                    angular.forEach(obj, function (val, ind) {
                        getAttachmentsData(val.Id, val.Name,rowId);
                    })
                }
            }

            // called from the "getAttachments()" function to fetch and set the value of the attachment field
            function getAttachmentsData(fieldId, fieldName, rowId) {
                $scope.attachedFiles[fieldId] = [];
                $http.get("/api/LibraryAppConfiguration/Index?module=" + $scope.moduleName +
                     "&formId=" + $scope.formid + "&fieldId=" + fieldId +
                     "&moduleId=" + $scope.moduleid + "&sectionId=" + $scope.sectionid
                     + "&viewId=" + $scope.viewid + "&rowId=" + rowId).success(function (response) {
                         if (response.uploadresults.length > 0) {
                             var data = response.uploadresults;
                             $scope.attachedFiles[fieldId] = data;
                         }

                     })
            }

            //Called to upload  a document
            $scope.uploadDynamicDocument = function (files, objectId) {
                if (files.length > 0) {
                    var arr = objectId.split('_');
                    var fieldId = arr[1];
                    var fieldName = arr[2];
                    var rowId = arr[3];
                    var extensions = getFieldExtension(fieldId);
                    $scope.extensionlist = [];
                    $scope.extensionlist = extensions.split(',');
                    if (files[0].size > 12000000) {
                        toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                        $("#" + objectId).val("");
                        return false;
                    }
                    var filename = files[0].name;
                    filename = filename.toLowerCase();
                    $scope.allowed = checkExtensionValidity($scope.extensionlist, filename);
                    if ($scope.allowed) {
                        var fd = new FormData();
                        //Take the first selected file
                        fd.append("file", files[0]);
                        $http.post("/api/LibraryAppConfiguration/Resource?module=" + $scope.moduleName + "&formId=" + $scope.formid +
                            "&fieldId=" + fieldId + "&moduleId=" + $scope.moduleid + "&sectionId=" + $scope.sectionid +
                            "&viewId=" + $scope.viewid + "&rowId=" + rowId, fd, {
                            withCredentials: true,
                            headers: { 'Content-Type': undefined },
                            transformRequest: angular.identity
                        }).success(function (data) {
                            $("#" + objectId).val("");
                            $scope.attachedFiles[fieldId].push(data[0]);
                        }
                        ).error(function (data) {
                            toaster.pop('error', 'Error', "File Upload Failed!");
                            $("#" + objectId).val("");
                        }
                        );
                    }
                    else {
                        toaster.pop('error', 'Error', " Invalid file type");
                        $("#" + objectId).val("");
                    };

                }

            };

            //called from "$scope.uploadDynamicDocument()" to find the list of valid extension types
            function getFieldExtension(fieldId) {
                var ext = "";
                angular.forEach($scope.fields, function (value, index) {
                    if (value.Id == fieldId) {
                        ext = value.ExtensionsAllowed;
                    }
                })
                return ext;

            }

            //called from "$scope.uploadDynamicDocument()" to find if the file being uploaded is of the correct extension
            function checkExtensionValidity(extensionlist, filename) {
                var valid = false;
                angular.forEach(extensionlist, function (value, index) {
                    if (filename.includes(value)) {
                        valid = true;
                    }
                })
                return valid;
            }

            //called to delete a document
            $scope.deleteAttachmentD = function (id, fieldId) {
                var ans = confirm("Are you sure you want to delete?");
                if (ans) {
                    $http.delete("/api/LibraryAppConfiguration/Resource/" + id).success(function (data) {
                        var indx = 0;
                        angular.forEach($scope.attachedFiles[fieldId], function (value, index) {
                            if (value.fileId == id) {
                                indx = index;
                                $scope.attachedFiles[fieldId].splice(indx, 1);
                                toaster.pop('success', 'Success', "Document deleted Successfully.");
                            }
                        })
                    }).error(function () {
                        toaster.pop('error', 'Error', "Error Occured while deleting the document.");
                    });
                }
            }
            //called to show a document
            $scope.showimage = function (uniquename, filename, filetype, filepath) {
                $scope.documentID = uniquename;
                $scope.documentNAME = filename;
                $scope.documentFILETYPE = filetype;
                $scope.fullFilePath = filepath + $scope.documentID;
                $scope.viewerFullFilePath = "<iframe src='https://docs.google.com/viewer?url=" + filepath + $scope.documentID + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
                $scope.TrustedviewerFullFilePath = $sce.trustAsHtml($scope.viewerFullFilePath);
                $scope.isIframe = true;
            }

            //*************************   Attachment End *********************************************************

            $scope.checkDateValidFormat = function (date) {
                var retString = "";
                var d = new Date(date);
                if (angular.isDate(d)) {
                    retString = $scope.formatdate(d);
                }
                if (retString == "NaN/NaN/NaN")
                {
                    return "";
                }
                else {
                    return retString;
                }
               
            }

            //format date method
            $scope.formatdate = function (sdate) {
                var d = new Date(sdate);
                var currDay = "";
                if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
                var currMonth = "";
                if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
                var currYear = d.getFullYear();
                var startDate = currMonth + "/" + currDay + "/" + currYear;
                return startDate;
            }
            //returns the default field type of a dynamic field from a fieldname parameter
            function getField(fieldname) {
                var FLDTypeId = {};
                angular.forEach($scope.fields, function (value, index) {
                    if (value.Name == fieldname) { FLDTypeId = value; }
                })
                return FLDTypeId;
            }

            //returns the dropdown text from a dropdown array
            function getDropDownText(listObj, id) {
                var retString = "";
                angular.forEach(listObj, function (value, index) {
                    if (value.Id == id) { retString = value.Value; }
                })
                return retString;
            }

            $scope.getDropdownText = function (fieldname, value) {
                var fieldObj = getField(fieldname);
                var selectedDropDownObj = {
                    Id: 0,
                    Value: ""
                };
                selectedDropDownObj.Id = parseInt(value);
                selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                return selectedDropDownObj.Value;
            };

            $scope.getMultiselectDropdownText = function (fieldname, value) {
                var ids = value.split(",");
                var text = "";
                for (j = 0; j < ids.length; j++) {
                    if (text != "") { text = text + ", "; }
                    text = text + $scope.getDropdownText(fieldname, ids[j]);
                }
                return text;
            };

            //*********************** To fetch Data  and Format the row data   START *************************
            function getData() {
                //load existing entries
                $http.get("/AppConfiguration/GetTableRows?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid).success(function (response) {
                    $scope.sourcerows = response.TableRows;
                    angular.forEach($scope.sourcerows, function (value, index) {
                        value["edit"] = false;
                        value["slno"] = index;
                        value.id = parseInt(value.id);
                       
                    })
                    $scope.rows = $scope.sourcerows;
                    formatDataSource();
                    updateEachRow();
                    //the status of add and edit variable is being set to start as 
                    //this function is called when we add or edit a row 
                    $scope.isadding = false;
                    $scope.isediting = false;
                    $scope.mode = "";
                })
            }

            function formatDataSource() {
                angular.forEach($scope.rows, function (value, index) {
                    angular.forEach(value, function (value1, index1) {
                        var fieldObj = getField(index1);

                        if (fieldObj.FieldTypeId == 2) { //numberbox
                            if (value1 != null & value1 != "") {
                                $scope.rows[index][index1] = parseInt(value1);
                            }
                        }

                        //if (fieldObj.FieldTypeId == 3) { //datePicker
                        //    $scope.rows[index][index1] = value1;
                        //    $scope.$apply();
                        //}

                        if (fieldObj.FieldTypeId == 4) { //datetimePicker
                            if (value1 != null & value1 != "") {
                                $scope.rows[index][index1] = new Date(value1);
                            }
                        }

                        if (fieldObj.FieldTypeId == 5) { //dropdown
                            var selectedDropDownObj = {
                                Id: 0,
                                Value: ""
                            };
                            selectedDropDownObj.Id = parseInt(value1);
                            selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                            $scope.dropDownObject[fieldObj.Id] = selectedDropDownObj;
                        }

                        if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                            var selectedDropDownObj = {
                                Id: 0,
                                Value: ""
                            };
                            var selectedDropDownObjs = [];
                            var ids = value1.split(",");
                            for (j = 0; j < ids.length; j++) {
                                var newObj = angular.copy(selectedDropDownObj);
                                newObj.Id = parseInt(ids[j]);
                                newObj.Value = getDropDownText(fieldObj.DataList, newObj.Id);
                                selectedDropDownObjs.push(newObj);
                            }
                            $scope.dropDownObject[fieldObj.Id] = selectedDropDownObjs;
                        }

                        if (fieldObj.FieldTypeId == 8) { //percentage
                            if (value1 != null & value1 != "") {
                                $scope.rows[index][index1] = parseFloat(value1);
                            } else {
                                $scope.rows[index][index1] = 0;
                            }
                        }

                        if (fieldObj.FieldTypeId == 17) { //editor
                            $scope.rows[index][index1] = $sce.trustAsHtml(value1);
                        }

                    })

                })
            }

            function formatDataSourceCurrentRow(selectedindex) {
                angular.forEach($scope.rows[selectedindex], function (value, index) {
                    var fieldObj = getField(index);

                    if (fieldObj.FieldTypeId == 2) { //numberbox
                        $scope.rows[selectedindex][index] = parseInt(value);
                    }

                    if (fieldObj.FieldTypeId == 3) { //datePicker
                        $scope.rows[selectedindex][index] = new Date(value);
                    }

                    if (fieldObj.FieldTypeId == 4) { //datetimePicker
                        $scope.rows[selectedindex][index] = new Date(value);
                    }

                    if (fieldObj.FieldTypeId == 5) { //dropdown
                        var selectedDropDownObj = {
                            Id: 0,
                            Value: ""
                        };
                        selectedDropDownObj.Id = parseInt(value);
                        selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                        $scope.dropDownObject[fieldObj.Id] = selectedDropDownObj;
                    }

                    if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                        var selectedDropDownObj = {
                            Id: 0,
                            Value: ""
                        };
                        var selectedDropDownObjs = [];
                        var ids = value.split(",");
                        for (j = 0; j < ids.length; j++) {
                            var newObj = angular.copy(selectedDropDownObj);
                            newObj.Id = parseInt(ids[j]);
                            newObj.Value = getDropDownText(fieldObj.DataList, newObj.Id);
                            selectedDropDownObjs.push(newObj);
                        }
                        $scope.dropDownObject[fieldObj.Id] = selectedDropDownObjs;
                    }

                    if (fieldObj.FieldTypeId == 8) { //percentage
                        $scope.rows[selectedindex][index] = parseFloat(value);
                    }

                })
            }
            //*********************** To fetch Data  and Format the row data   END *************************


            //table column sorting generic code
            $scope.reverse = false;
            $scope.predicate = "";
            $scope.headerClick = function (fieldname) {
                $scope.predicate = fieldname;
                $scope.reverse = !$scope.reverse;
                //alert(fieldname);
            }

            $scope.openEditor = function (value, fieldobj, slno) {
                var data = $sce.valueOf(value);
                var index = 0;
                angular.forEach($scope.rows, function (value, indx) {
                    if (value.slno == slno) { index = indx; }
                })
                var modalInstance = $modal.open({
                    templateUrl: 'Scripts/app/appConfiguration/formConfig/partials/EditorModal.html',
                    controller: 'modalInstanceEditorModalCtrl',
                    backdrop: 'static',
                    size: 'lg',
                    scope: $scope,
                    resolve: {
                        object: function () {
                            return fieldobj;
                        },
                        rowdata: function () {
                            return data;
                        }
                    }
                });
                modalInstance.result.then(function (value) {
                    if (value != "") {
                        $scope.rows[index][fieldobj.Name] = $sce.trustAsHtml(value);
                    }

                });
            }

            $scope.viewrow = function (slno) {
                var index = 0;
                angular.forEach($scope.rows, function (value, indx) {
                    if (value.slno == slno) { index = indx; }
                })
                $scope.viewdata = angular.copy($scope.rows[index]);
                $scope.showColumn = [];
                $scope.showInfo=[];
                angular.forEach($scope.viewdata, function (value, indx) {
                    if(indx !="id" && indx !="edit" && indx !="slno")
                    {
                        angular.forEach($scope.fields, function (fieldObj, indx2) {
                            if (fieldObj.Name == indx) {
                                $scope.showColumn.push(fieldObj);
                                if (fieldObj.FieldTypeId == 4) { //datetimePicker
                                    if (value != null & value != "") {
                                        $scope.showInfo.push(new Date(value));
                                    }
                                    else
                                    {
                                        $scope.showInfo.push("---");
                                    }
                                }
                                else if (fieldObj.FieldTypeId == 5) { //dropdown
                                    if (value != null & value != "") {
                                        var dataval = getDropDownText(fieldObj.DataList, parseInt(value));
                                        $scope.showInfo.push(dataval);
                                    }
                                    else {
                                        $scope.showInfo.push("---");
                                    }
                                }
                                else if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                                    if (value != null & value != "") {
                                        var ids = value.split(",");
                                        var mslist = [];
                                        for (j = 0; j < ids.length; j++) {
                                            var id=parseInt(ids[j]);
                                            var msval = getDropDownText(fieldObj.DataList, id);
                                            mslist.push(msval);
                                        }
                                        var dataval = mslist.join(', ');
                                        $scope.showInfo.push(dataval);
                                    }
                                    else {
                                        $scope.showInfo.push("---");
                                    }
                                }
                                //else if (fieldObj.FieldTypeId == 16) { //Attachment
                                //    $scope.showInfo.push("--Att-");
                                //}
                                else
                                {
                                    if (value != null & value != "") {
                                        $scope.showInfo.push(value);
                                    }
                                    else {
                                        $scope.showInfo.push("---");
                                    }
                                }
                            }
                        })
                    }
                })
                $scope.showRowInPopUp($scope.showColumn, $scope.showInfo);
            }
            $scope.showRowInPopUp = function (column,data) {
                var modalInstance = $modal.open({
                    templateUrl: 'Scripts/app/appConfiguration/formConfig/partials/ViewModal.html',
                    controller: 'modalInstanceViewRowModalCtrl',
                    backdrop: 'static',
                    scope: $scope,
                    resolve: {
                        rowcolumn: function () {
                            return column;
                        },
                        rowdata: function () {
                            return data;
                        }
                    }
                });
                modalInstance.result.then(function (value) {
                   
                });
            }
        }
    }
})

app.directive('rigilStandardview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/FormConfig/partials/customStandardview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce, $modal) {

            //VIEW configuration values from database
            $scope.formid = $scope.vt.formId;
            $scope.moduleid = $scope.vt.moduleId;
            $scope.sectionid = $scope.vt.sectionId;
            $scope.viewid = $scope.vt.viewId;
            $scope.displayonly = $scope.vt.displayOnly;
            $scope.fieldids = $scope.vt.fieldId;
            $scope.isIframe = false;
            $scope.editForm = false;
            $scope.showIcon = false;
            $scope.moduleName = "";
            getmoduleName();

            function getmoduleName() {
                $http.get("/AppConfiguration/GetModuleName?moduleId=" + $scope.moduleid).success(function (response) {
                    $scope.moduleName = response.data;
                    getFields();
                })
            }

            $scope.toggleForm = function () {
                $scope.editForm = true;
                getFields();
            }
            $scope.cancelForm = function () {
                $scope.editForm = false;
                getData();
            }
            $scope.scoringData = [];
            function getFields() {
                //fetch the field ids array
                $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                    $scope.fields = response.fielddata;
                    $scope.rows = [];
                    //dynamic open object for the date picker
                    $scope.isOpen = [];
                    //dynamic mouse over event for the money and percentage objects
                    $scope.mouseOver = [];
                    //dynmic checkbox model for storing the checkbox value intermediately
                    //before saving it in the dynamic object itself
                    $scope.checkedData = [];
                    //dynamic datetime option for the datetime picker
                    $scope.dateTimeOptions = [];
                    //dynamic dropdown and multi select Object for ui-select for storing the intermediate object 
                    //before saving it in the dynamic object itself
                    $scope.dropDownObject = [];
                    //dynamic attached file list
                    $scope.attachedFiles = [];

                    $scope.row = {};
                    //prepare the datamodel dynamiclly from fields list
                    angular.forEach($scope.fields, function (value, index) {
                        $scope.row[value.Name] = "";
                        //dynamic open object for the date picker setting to false default setting
                        $scope.isOpen[value.Id] = false;
                        //dynamic mouse over event for the money and percentage objects  setting to false default setting
                        $scope.mouseOver[value.Id] = false;
                        //dynamic datetime option for the datetime picker specified for each object specifically
                        $scope.dateTimeOptions[value.Id] = { useCurrent: false, showClear: true, showClose: true };
                        //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                        $scope.dropDownObject[value.Id] = {};
                        //empty list of attched file for dynmic object
                        $scope.attachedFiles[value.Id] = [];
                        //for field type checkbox and radio button set the length of array to the length of the list
                        if (value.FieldTypeId == 13 || value.FieldTypeId == 14) {
                            $scope.checkedData[value.Id] = new Array(value.UDVList.length);
                        }
                        if (value.FieldTypeId == 21) {
                            $scope.scoringData[value.Id] = "";
                        }
                        if (value.FieldTypeId == 3)//Date Picker  set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                        }
                        if (value.FieldTypeId == 4)//DateTime Picker set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                            $scope.dateTimeOptions[value.Id].maxDate = value.MaxDate;
                            $scope.dateTimeOptions[value.Id].minDate = value.MinDate;
                        }
                    })
                    $scope.row["edit"] = true;
                    $scope.row["id"] = 0;
                    getData();
                })
            }
            //The function to open the ui for date picker when the calendar icon is pressed
            $scope.opendp = function ($event, Id) {
                $event.preventDefault();
                $event.stopPropagation();
                var name = "isOpen" + Id;
                $scope[name] = true;
            };

            $scope.formatdate = function (sdate) {
                var d = new Date(sdate);
                var currDay = "";
                if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
                var currMonth = "";
                if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
                var currYear = d.getFullYear();
                var startDate = currMonth + "/" + currDay + "/" + currYear;
                return startDate;
            }
            //default date option for the datepicker
            $scope.dateOptions = {
                class: 'datepicker'
            };

            // To check the validity of zipcode for the respective dynamic object
            $scope.changeZipCode = function (value, id, name) {
                if (value != undefined) {
                    if (value.length == 5) {
                        $http.get("/Home/GetCitynState?zipcode=" + value).success(function (data) {
                            if (data.zipInfo != null) {
                                //success
                            } else {
                                $scope.row[name] = "";
                                toaster.pop('error', 'Error', "Enter a valid zipcode");
                            }
                        }).error(function (data) {
                            $scope.row[name] = "";
                        })
                    }
                    else {
                        $scope.row[name] = "";
                    }
                }
            }

            // To set the value of the checkbox  in the respective dynamic object
            function getSelectedChecked(list, Id) {
                return list.filter(function (x, i) {
                    return $scope.checkedData[Id][i]
                });
            }
            $scope.getCheckedValue = function (name, list, id) {
                var value = getSelectedChecked(list, id);
                $scope.row[name] = value.join(',');
            }

            // To set the value of the dropdown  from drop down in the respective dynamic object
            $scope.getUpdatedDropDownValue = function (name, id) {
                $scope.row[name] = $scope.dropDownObject[id].Id;
            }

            // To set the value of the selected multiple values from multiselect in the respective dynamic object
            $scope.getUpdatedMultiSelectValue = function (name, id) {
                var selectedlist = $scope.dropDownObject[id];
                var list = [];
                angular.forEach(selectedlist, function (value, index) {
                    list.push(value.Id);
                })
                $scope.row[name] = list.join(',');
            }


            $scope.isdeletedD = false;

            $scope.showimage = function (uniquename, filename, filetype, filepath) {
                $scope.documentID = uniquename;
                $scope.documentNAME = filename;
                $scope.documentFILETYPE = filetype;
                $scope.fullFilePath = filepath + $scope.documentID;
                $scope.viewerFullFilePath = "<iframe src='https://docs.google.com/viewer?url=" + filepath + $scope.documentID + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
                $scope.TrustedviewerFullFilePath = $sce.trustAsHtml($scope.viewerFullFilePath);
                $scope.isIframe = true;
            }

            //Called to upload  a document
            $scope.uploadDynamicDocument = function (files, objectId) {
                if (files.length > 0) {
                    var arr = objectId.split('_');
                    var fieldId = arr[1];
                    var fieldName = arr[2];
                    var rowId = 1;
                    var extensions = getFieldExtension(fieldId);
                    $scope.extensionlist = [];
                    $scope.extensionlist = extensions.split(',');
                    if (files[0].size > 12000000) {
                        toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                        $("#" + objectId).val("");
                        return false;
                    }
                    var filename = files[0].name;
                    filename = filename.toLowerCase();
                    $scope.allowed = checkExtensionValidity($scope.extensionlist, filename);
                    if ($scope.allowed) {
                        var fd = new FormData();
                        //Take the first selected file
                        fd.append("file", files[0]);
                        $http.post("/api/LibraryAppConfiguration/Resource?module=" + $scope.moduleName + "&formId=" + $scope.formid +
                            "&fieldId=" + fieldId + "&moduleId=" + $scope.moduleid + "&sectionId=" + $scope.sectionid +
                            "&viewId=" + $scope.viewid + "&rowId=" + rowId, fd, {
                                withCredentials: true,
                                headers: { 'Content-Type': undefined },
                                transformRequest: angular.identity
                            }).success(function (data) {
                                $("#" + objectId).val("");
                                $scope.attachedFiles[fieldId].push(data[0]);
                            }
                        ).error(function (data) {
                            toaster.pop('error', 'Error', "File Upload Failed!");
                            $("#" + objectId).val("");
                        }
                        );
                    }
                    else {
                        toaster.pop('error', 'Error', " Invalid file type");
                        $("#" + objectId).val("");
                    };

                }

            };

            //called from "$scope.uploadDynamicDocument()" to find the list of valid extension types
            function getFieldExtension(fieldId) {
                var ext = "";
                angular.forEach($scope.fields, function (value, index) {
                    if (value.Id == fieldId) {
                        ext = value.ExtensionsAllowed;
                    }
                })
                return ext;

            }

            //called from "$scope.uploadDynamicDocument()" to find if the file being uploaded is of the correct extension
            function checkExtensionValidity(extensionlist, filename) {
                var valid = false;
                angular.forEach(extensionlist, function (value, index) {
                    if (filename.includes(value)) {
                        valid = true;
                    }
                })
                return valid;
            }

            //called to delete a document
            $scope.deleteAttachmentD = function (id, fieldId) {
                var ans = confirm("Are you sure you want to delete?");
                if (ans) {
                    $http.delete("/api/LibraryAppConfiguration/Resource/" + id).success(function (data) {
                        var indx = 0;
                        angular.forEach($scope.attachedFiles[fieldId], function (value, index) {
                            if (value.fileId == id) {
                                indx = index;
                                $scope.attachedFiles[fieldId].splice(indx, 1);
                                toaster.pop('success', 'Success', "Document deleted Successfully.");
                            }
                        })
                    }).error(function () {
                        toaster.pop('error', 'Error', "Error Occured while deleting the document.");
                    });
                }
            }

            //row save method
            $scope.saveForm = function () {
                $scope.showIcon = true;
                $scope.row.edit = false;
                $scope.isadding = false;
                $scope.isediting = false;

                $scope.dataARRAY = [];
                //create a model for passing field and property value
                //pair in an array to the asp.net mvc controller
                $scope.datarray = {
                    field: "",
                    value: "",
                    fieldid: 0
                }

                //convert property:values of the form to key:value pair array
                angular.forEach($scope.fields, function (value, Index) {
                    $scope.newdatarray = angular.copy($scope.datarray);
                    $scope.newdatarray.field = value.Name;
                    if (value.FieldTypeId == 17) { //editor
                        $scope.newdatarray.value = $sce.valueOf($scope.row[value.Name]);
                    }
                    else {
                        $scope.newdatarray.value = $scope.row[value.Name];
                    }
                    $scope.newdatarray.fieldid = value.Id;
                    $scope.dataARRAY.push($scope.newdatarray);
                })

                //prepare the DTO to go with the post call for row insertion
                dto = {
                    id: $scope.row.id,
                    formid: $scope.formid,
                    moduleid: $scope.moduleid,
                    sectionid: $scope.sectionid,
                    viewid: $scope.viewid,
                    fieldid: $scope.fieldid,
                    row: $scope.dataARRAY
                }

                if ($scope.row.id == 0) {
                    //new record: insert it in table
                    $http.post("/AppConfiguration/PostStandarddata", dto).success(function (response) {
                        $scope.row.id = response.savedId;
                        getData();
                        $scope.editForm = false;
                        $scope.showIcon = false;
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                } else {
                    //old record: update it in table
                    $http.put("/AppConfiguration/PutStandarddata", dto).success(function (response) {
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                        getData();
                        $scope.editForm = false;
                        $scope.showIcon = false;
                    })
                }
            }

            //returns the default field type of a dynamic field from a fieldname parameter
            function getField(fieldname) {
                var FLDTypeId = {};
                angular.forEach($scope.fields, function (value, index) {
                    if (value.Name == fieldname) { FLDTypeId = value; }
                })
                return FLDTypeId;
            }

            //returns the dropdown text from a dropdown array
            function getDropDownText(listObj, id) {
                var retString = "";
                angular.forEach(listObj, function (value, index) {
                    if (value.Id == id) { retString = value.Value; }
                })
                return retString;
            }

            $scope.getDropdownText = function (fieldname, value) {
                var fieldObj = getField(fieldname);
                var selectedDropDownObj = {
                    Id: 0,
                    Value: ""
                };
                selectedDropDownObj.Id = parseInt(value);
                selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                return selectedDropDownObj.Value;
            };

            $scope.getMultiselectDropdownText = function (fieldname, value) {
                var ids = value.split(",");
                var text = "";
                for (j = 0; j < ids.length; j++) {
                    if (text != "") { text = text + ", "; }
                    text = text + $scope.getDropdownText(fieldname, ids[j]);
                }
                return text;
            };



            //fetch saved data
            function getData() {
                //load existing entries
                $http.get("/AppConfiguration/GetStandarddata?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid).success(function (response) {
                    $scope.sourcerows = response.TableRows;
                    angular.forEach($scope.sourcerows, function (value, index) {
                        value["edit"] = false;
                        value.id = parseInt(value.id);
                    })
                    if ($scope.sourcerows.length > 0) {
                        $scope.rowdata = $scope.sourcerows[0];


                        angular.forEach($scope.rowdata, function (value, index) {
                            var fieldObj = getField(index);

                            if (fieldObj.FieldTypeId == 2) { //numberbox
                                if (value != "" && value != null)
                                    $scope.row[index] = parseInt(value);
                            }
                            if ($scope.editForm) {
                                if (fieldObj.FieldTypeId == 4) { //datetimePicker
                                    $scope.row[index] = new Date(value);
                                }
                            }

                            if (fieldObj.FieldTypeId == 5) { //dropdown
                                var selectedDropDownObj = {
                                    Id: 0,
                                    Value: ""
                                };
                                selectedDropDownObj.Id = parseInt(value);
                                selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                                $scope.dropDownObject[fieldObj.Id] = selectedDropDownObj;
                            }

                            if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                                var selectedDropDownObj = {
                                    Id: 0,
                                    Value: ""
                                };
                                var selectedDropDownObjs = [];
                                var ids = value.split(",");
                                for (j = 0; j < ids.length; j++) {
                                    var newObj = angular.copy(selectedDropDownObj);
                                    newObj.Id = parseInt(ids[j]);
                                    newObj.Value = getDropDownText(fieldObj.DataList, newObj.Id);
                                    selectedDropDownObjs.push(newObj);
                                }
                                $scope.dropDownObject[fieldObj.Id] = selectedDropDownObjs;
                            }

                            if (fieldObj.FieldTypeId == 8) { //percentage
                                if (value != "" && value != null)
                                    $scope.row[index] = parseFloat(value);
                            }

                            if (fieldObj.FieldTypeId == 14) { //checkbox
                                var selectedlist = value.split(',');
                                $scope.checkedData[fieldObj.Id] = new Array(fieldObj.UDVList.length);
                                angular.forEach(fieldObj.UDVList, function (value1, index1) {
                                    angular.forEach(selectedlist, function (value2, index2) {
                                        if (value1 == value2) {
                                            $scope.checkedData[fieldObj.Id][index1] = true;
                                        }
                                    })
                                })

                            }

                            if (fieldObj.FieldTypeId == 16) {//attachments
                                $scope.attachedFiles[fieldObj.Id] = [];
                                $http.get("/api/LibraryAppConfiguration/Index?module=" + $scope.moduleName +
                                     "&formId=" + $scope.formid + "&fieldId=" + fieldObj.Id +
                                     "&moduleId=" + $scope.moduleid + "&sectionId=" + $scope.sectionid
                                     + "&viewId=" + $scope.viewid + "&rowId=1").success(function (response) {
                                         if (response.uploadresults.length > 0) {
                                             $scope.attachedFiles[fieldObj.Id] = response.uploadresults;
                                         }

                                     })
                            }
                            if (fieldObj.FieldTypeId == 17) { //editor
                                $scope.row[index] = $sce.trustAsHtml(value);
                            }
                            if (fieldObj.FieldTypeId == 21) {
                                $scope.viewfields = [];
                                var totalscore = 0;
                                var scoredValue = 0;
                                $http.get("/AppConfiguration/GetViewFields?viewId=" + fieldObj.QViewId).success(function (response) {
                                    var fieldsdata = "";
                                    fieldsdata = response.fieldIds;
                                    if (fieldsdata != "") {
                                        //fetch the field ids array
                                        $http.get("/AppConfiguration/GetFields?fieldids=" + fieldsdata).success(function (response) {
                                            $scope.viewfields = response.fielddata;
                                            //prepare the datamodel dynamiclly from fields list
                                            angular.forEach($scope.viewfields, function (values, indexs) {
                                                totalscore = totalscore + values.maxScore;
                                            })
                                            if (value != "" && value != null) {
                                                $scope.fieldData = JSON.parse(value);
                                            }
                                            angular.forEach($scope.viewfields, function (value1, index1) {
                                                angular.forEach($scope.fieldData, function (val, indx) {
                                                    if (indx == value1.Name)
                                                    {
                                                        var selectedvalue = val;
                                                        if (selectedvalue != "") {
                                                            angular.forEach(value1.ValueWeightageList, function (value2, index2) {
                                                                if (value2.Value == selectedvalue) {
                                                                    scoredValue = scoredValue + value2.Weightage;
                                                                }
                                                            })
                                                        }
                                                    }
                                                    
                                                    
                                                })
                                            })
                                            $scope.scoringData[fieldObj.Id] = scoredValue+'/'+totalscore;
                                        })
                                    }

                                })
                                $scope.row[index] = value;
                            }
                            else {
                                if (value != "")
                                    $scope.row[index] = value;

                            }
                        })
                        angular.forEach($scope.row, function (value, index) {
                            if (!value)
                                $scope.row[index] = "";
                        })
                    }

                })
            }
            $scope.openPropertyModal = function (fieldobject, rowdata) {
                var modalInstance = $modal.open({
                    templateUrl: 'Scripts/app/appConfiguration/formConfig/partials/quenstionnaireDirectiveModal.html',
                    controller: 'modalInstanceQuestionnaireModalCtrl',
                    backdrop: 'static',
                    size: 'lg',
                    scope: $scope,
                    resolve: {
                        object: function () {
                            return fieldobject;
                        },
                        rowdata: function () {
                            return rowdata;
                        }
                    }
                });
                modalInstance.result.then(function (value) {
                    if (value != "") {
                        $scope.row[fieldobject.Name] = value.qdata;
                        $scope.scoringData[fieldobject.Id] = value.score;
                    }

                });
            }

        }
    }
})

app.directive('rigilQuestionnaireview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/FormConfig/partials/customQuestionnaireview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce) {

            //VIEW configuration values from database
            $scope.formid = $scope.vt.formId;
            $scope.moduleid = $scope.vt.moduleId;
            $scope.sectionid = $scope.vt.sectionId;
            $scope.viewid = $scope.vt.viewId;
            $scope.displayonly = $scope.vt.displayOnly;
            $scope.fieldids = $scope.vt.fieldId;
            getFields();
            $scope.scoring = {
                totalScore: 0,
                myScore: 0,
            }
            $scope.row = {};

            function getFields() {
                //fetch the field ids array
                $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                    $scope.fields = response.fielddata;
                    $scope.rows = [];

                    //dynamic dropdown  Object for ui-select for storing the intermediate object 
                    //before saving it in the dynamic object itself
                    $scope.dropDownObject = [];
                    $scope.scoring.totalScore = 0;
                    $scope.scoring.myScore = 0;
                    //prepare the datamodel dynamiclly from fields list
                    angular.forEach($scope.fields, function (value, index) {
                        $scope.row[value.Name] = "";
                        //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                        $scope.dropDownObject[value.Id] = {};
                        $scope.scoring.totalScore = $scope.scoring.totalScore + value.maxScore;
                    })
                    $scope.row["edit"] = true;
                    $scope.row["id"] = 0;
                    getData();
                })
            }

            $scope.getLatestScore = function () {
                $scope.scoring.myScore = 0;
                angular.forEach($scope.fields, function (value, index) {
                    var selectedvalue = $scope.row[value.Name];
                    if (selectedvalue != "") {
                        angular.forEach(value.ValueWeightageList, function (value1, index1) {
                            if (value1.Value == selectedvalue) {
                                $scope.scoring.myScore = $scope.scoring.myScore + value1.Weightage;
                            }
                        })
                    }
                })
            }

            //row save method
            $scope.saveForm = function () {
                $scope.row.edit = false;
                $scope.isadding = false;
                $scope.isediting = false;

                $scope.dataARRAY = [];
                //create a model for passing field and property value
                //pair in an array to the asp.net mvc controller
                $scope.datarray = {
                    field: "",
                    value: "",
                    fieldid: 0
                }

                //convert property:values of the form to key:value pair array
                angular.forEach($scope.fields, function (value, Index) {
                    $scope.newdatarray = angular.copy($scope.datarray);
                    $scope.newdatarray.field = value.Name;
                    $scope.newdatarray.value = $scope.row[value.Name];
                    $scope.newdatarray.fieldid = value.Id;
                    $scope.dataARRAY.push($scope.newdatarray);
                })

                //prepare the DTO to go with the post call for row insertion
                dto = {
                    id: $scope.row.id,
                    formid: $scope.formid,
                    moduleid: $scope.moduleid,
                    sectionid: $scope.sectionid,
                    viewid: $scope.viewid,
                    fieldid: $scope.fieldid,
                    row: $scope.dataARRAY
                }

                if ($scope.row.id == 0) {
                    //new record: insert it in table
                    $http.post("/AppConfiguration/PostQuestionnaireData", dto).success(function (response) {
                        $scope.row.id = response.savedId;
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                } else {
                    //old record: update it in table
                    $http.put("/AppConfiguration/PutQuestionnaireData", dto).success(function (response) {
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                }
            }

            $scope.resetForm = function () {
                $scope.scoring.totalScore = 0;
                $scope.scoring.myScore = 0;
                angular.forEach($scope.fields, function (value, index) {
                    $scope.row[value.Name] = "";
                    //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                    $scope.dropDownObject[value.Id] = {};
                    $scope.scoring.totalScore = $scope.scoring.totalScore + value.maxScore;
                })
                toaster.pop('success', 'Success', "Form Reset Successfully !!");
            }

            $scope.resetQuestion = function (name) {
                $scope.row[name] = "";
                $scope.getLatestScore();
                toaster.pop('success', 'Success', "Operation Successfull !!");
            }

            //fetch saved data
            function getData() {
                //load existing entries
                $http.get("/AppConfiguration/GetQuestionnaireData?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid).success(function (response) {
                    $scope.sourcerows = response.TableRows;
                    angular.forEach($scope.sourcerows, function (value, index) {
                        value["edit"] = false;
                        value.id = parseInt(value.id);
                    })
                    if ($scope.sourcerows.length > 0) {
                        $scope.row = $scope.sourcerows[0];
                        $scope.getLatestScore();
                    }
                })
            }

        }
    }
})

app.directive('rigilcustomQuestionnaireview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            viewId: '=',
            jsonValue: '=',
        },
        templateUrl: '../Scripts/app/appConfiguration/FormConfig/partials/customizedQuestionnaireview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce) {

            $scope.viewid = $scope.vt.viewId;
            if ($scope.vt.jsonValue != "" && $scope.vt.jsonValue != null) {
            $scope.fieldData = JSON.parse($scope.vt.jsonValue);
            }
            else {
                $scope.fieldData = "";
            }


            $scope.fieldids = "";
            getFields();
            $scope.scoring = {
                totalScore: 0,
                myScore: 0,
            }
            $scope.row = {};
            

            function getFields() {
                $http.get("/AppConfiguration/GetViewFields?viewId=" + $scope.viewid).success(function (response) {
                    $scope.fieldids = response.fieldIds;
                    if ($scope.fieldids != "") {
                        //fetch the field ids array
                        $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                            $scope.fields = response.fielddata;
                            $scope.rows = [];

                            //dynamic dropdown  Object for ui-select for storing the intermediate object 
                            //before saving it in the dynamic object itself
                            $scope.dropDownObject = [];
                            $scope.scoring.totalScore = 0;
                            $scope.scoring.myScore = 0;
                            //prepare the datamodel dynamiclly from fields list
                            angular.forEach($scope.fields, function (value, index) {
                                $scope.row[value.Name] = "";
                                //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                                $scope.dropDownObject[value.Id] = {};
                                $scope.scoring.totalScore = $scope.scoring.totalScore + value.maxScore;
                            })

                            //getdata
                            if ($scope.fieldData != "" && $scope.fieldData != null) {
                            $scope.row = $scope.fieldData;
                            $scope.getLatestScore();
                            }


                            $scope.row["edit"] = true;
                            $scope.row["id"] = 0;
                        })
                    }
                })
            }

            $scope.getLatestScore = function () {
                $scope.scoring.myScore = 0;
                angular.forEach($scope.fields, function (value, index) {
                    var selectedvalue = $scope.row[value.Name];
                    if (selectedvalue != "") {
                        angular.forEach(value.ValueWeightageList, function (value1, index1) {
                            if (value1.Value == selectedvalue) {
                                $scope.scoring.myScore = $scope.scoring.myScore + value1.Weightage;
                            }
                        })
                    }
                })
            }


            $scope.resetForm = function () {
                $scope.scoring.totalScore = 0;
                $scope.scoring.myScore = 0;
                angular.forEach($scope.fields, function (value, index) {
                    $scope.row[value.Name] = "";
                    //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                    $scope.dropDownObject[value.Id] = {};
                    $scope.scoring.totalScore = $scope.scoring.totalScore + value.maxScore;
                })
               // toaster.pop('success', 'Success', "Form Reset Successfully !!");
            }

            $scope.resetQuestion = function (name) {
                $scope.row[name] = "";
                $scope.getLatestScore();
               // toaster.pop('success', 'Success', "Operation Successfull !!");
            }

            $scope.saveForm = function () {
                $scope.data = {};
                var qdata = JSON.stringify($scope.row);
                $scope.data.qdata = qdata;
                $scope.data.score = $scope.scoring.myScore + '/' + $scope.scoring.totalScore
                $scope.$emit('sendQuestionnaireJson', { data: $scope.data });
            }


        }
    }
})