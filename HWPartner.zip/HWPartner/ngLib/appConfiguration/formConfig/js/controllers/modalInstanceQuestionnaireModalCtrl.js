﻿app.controller('modalInstanceQuestionnaireModalCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'object','rowdata', 'toaster', '$location', 
    function ($scope, $http, $modalInstance, $controller, object, rowdata, toaster, location) {
        $scope.fieldObj = object;
        $scope.rowdata = rowdata;
        $scope.view = {};
        
        $http.get("/AppConfiguration/GetViewInfo?viewId=" + $scope.fieldObj.QViewId).success(function (response) {
            $scope.view = response.data;
        })
        $scope.togglePropertyModal = function () {
            $modalInstance.close("");
        }
        $scope.cancelData = function () {
            $scope.togglePropertyModal();
        }
        $scope.$on('sendQuestionnaireJson', function (event, args) {
            $scope.view = {};
            $scope.data = args.data;
            $modalInstance.close($scope.data);
        });
    }]);