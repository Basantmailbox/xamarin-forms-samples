﻿/// <reference path="modalInstanceAddAttachmentModalCtrl.js" />
app.controller('modalInstanceAddAttachmentModalCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'rowID',
    'fields', 'formId', 'viewId', 'sectionId','moduleName','moduleId', 'toaster', '$location','$sce',
    function ($scope, $http, $modalInstance, $controller, rowID, fields, formId, viewId, sectionId, moduleName,
        moduleId, toaster, location,$sce) {
        $scope.rowID = rowID;
        $scope.fields = fields;
        $scope.formId = formId;
        $scope.viewId = viewId;
        $scope.sectionId = sectionId;
        $scope.moduleName = moduleName;
        $scope.moduleId = moduleId;
        $scope.attachedFiles = [];
        $scope.isdeletedD = false;
        $scope.isIframe = false;
        angular.forEach($scope.fields, function (value, index) {
            $scope.attachedFiles[value.Id] = [];
        })
        $scope.togglePropertyModal = function () {
            $modalInstance.close("");
        }
        $scope.cancelData = function () {
            $scope.togglePropertyModal();
        } 
        //Called to upload  a document
        $scope.uploadDynamicDocument = function (files, objectId) {
            if (files.length > 0) {
                var arr = objectId.split('_');
                var fieldId = arr[1];
                var fieldName = arr[2];
                var extensions = getFieldExtension(fieldId);
                $scope.extensionlist = [];
                $scope.extensionlist = extensions.split(',');
                if (files[0].size > 12000000) {
                    toaster.pop('error', 'Error', "Maximum 12MB image size allowed!");
                    $("#" + objectId).val("");
                    return false;
                }
                var filename = files[0].name;
                filename = filename.toLowerCase();
                $scope.allowed = checkExtensionValidity($scope.extensionlist, filename);
                if ($scope.allowed) {
                    var fd = new FormData();
                    //Take the first selected file
                    fd.append("file", files[0]);
                    $http.post("/api/LibraryAppConfiguration/Resource?module=" + $scope.moduleName + "&formId=" + $scope.formid +
                        "&fieldId=" + fieldId + "&moduleId=" + $scope.moduleid + "&sectionId=" + $scope.sectionid +
                        "&viewId=" + $scope.viewid + "&rowId=" + $scope.rowID, fd, {
                            withCredentials: true,
                            headers: { 'Content-Type': undefined },
                            transformRequest: angular.identity
                        }).success(function (data) {
                            $("#" + objectId).val("");
                            $scope.attachedFiles[fieldId].push(data[0]);
                        }
                    ).error(function (data) {
                        toaster.pop('error', 'Error', "File Upload Failed!");
                        $("#" + objectId).val("");
                    }
                    );
                }
                else {
                    toaster.pop('error', 'Error', " Invalid file type");
                    $("#" + objectId).val("");
                };

            }

        };

        //called from "$scope.uploadDynamicDocument()" to find the list of valid extension types
        function getFieldExtension(fieldId) {
            var ext = "";
            angular.forEach($scope.fields, function (value, index) {
                if (value.Id == fieldId) {
                    ext = value.ExtensionsAllowed;
                }
            })
            return ext;

        }

        //called from "$scope.uploadDynamicDocument()" to find if the file being uploaded is of the correct extension
        function checkExtensionValidity(extensionlist, filename) {
            var valid = false;
            angular.forEach(extensionlist, function (value, index) {
                if (filename.includes(value)) {
                    valid = true;
                }
            })
            return valid;
        }

        //called to delete a document
        $scope.deleteAttachmentD = function (id, fieldId) {
            var ans = confirm("Are you sure you want to delete?");
            if (ans) {
                $http.delete("/api/LibraryAppConfiguration/Resource/" + id).success(function (data) {
                    var indx = 0;
                    angular.forEach($scope.attachedFiles[fieldId], function (value, index) {
                        if (value.fileId == id) {
                            indx = index;
                            $scope.attachedFiles[fieldId].splice(indx, 1);
                            toaster.pop('success', 'Success', "Document deleted Successfully.");
                        }
                    })
                }).error(function () {
                    toaster.pop('error', 'Error', "Error Occured while deleting the document.");
                });
            }
        }
        //called to show a document
        $scope.showimage = function (uniquename, filename, filetype, filepath) {
            $scope.documentID = uniquename;
            $scope.documentNAME = filename;
            $scope.documentFILETYPE = filetype;
            $scope.fullFilePath = filepath + $scope.documentID;
            $scope.viewerFullFilePath = "<iframe src='https://docs.google.com/viewer?url=" + filepath + $scope.documentID + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
            $scope.TrustedviewerFullFilePath = $sce.trustAsHtml($scope.viewerFullFilePath);
            $scope.isIframe = true;
        }
       
    }]);