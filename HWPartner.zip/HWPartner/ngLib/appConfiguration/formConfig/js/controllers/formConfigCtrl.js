﻿
app.controller("formConfiguration", function ($scope, $http, $log, $window, toaster, formConfigService, $compile) {

    $scope.showField = false;// for removing field directive from Dom and loading it with latest data on tab click
    $scope.showView = false;// for removing view directive from Dom and loading it with latest data on tab click
    $scope.showSection = false;// for removing section directive from Dom and loading it with latest data on tab click
    $scope.showForm = false;// for removing form directive from Dom and loading it with latest data on tab click

    $scope.AddFieldDirective = function () {
        $scope.showField = true;
        $scope.showView = false;
        $scope.showSection = false;
        $scope.showForm = false;
    }

    $scope.AddViewDirective = function () {
        $scope.showView = true;
        $scope.showSection = false;
        $scope.showForm = false;
    }

    $scope.removeAllDirectives = function () {
        $scope.showField = false;
        $scope.showView = false;
        $scope.showSection = false;
        $scope.showForm = false;
    }
    $scope.AddSectionDirective = function () {
        $scope.showSection = true;
        $scope.showForm = false;
    }
    $scope.AddFormDirective = function () {
        $scope.showForm = true;
    }
});

