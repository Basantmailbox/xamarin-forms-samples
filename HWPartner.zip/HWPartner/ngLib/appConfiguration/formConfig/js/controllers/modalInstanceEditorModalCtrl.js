﻿app.controller('modalInstanceEditorModalCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'object','rowdata', 'toaster', '$location', 
    function ($scope, $http, $modalInstance, $controller, object, rowdata, toaster, location) {
        $scope.fieldObj = object;
        $scope.rowdata = rowdata;
        
        $scope.togglePropertyModal = function () {
            $modalInstance.close("");
        }
        $scope.cancelData = function () {
            $scope.togglePropertyModal();
        }

        $scope.saveForm = function () {
            $modalInstance.close($scope.rowdata);
        }
    }]);