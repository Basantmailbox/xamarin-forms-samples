﻿app.filter('range', function () {
    return function (input, total) {
        total = parseInt(total);

        for (var i = 0; i < total; i++) {
            input.push(i);
        }

        return input;
    };
});
app.controller('modalInstanceViewRowModalCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'rowcolumn', 'rowdata', 'toaster', '$location',
    function ($scope, $http, $modalInstance, $controller, rowcolumn, rowdata, toaster, location) {
        $scope.fieldObj = rowcolumn;
        $scope.rowData = rowdata;
        $scope.columnCount = rowcolumn.length;
        $scope.togglePropertyModal = function () {
            $modalInstance.close("");
        }
        $scope.cancelData = function () {
            $scope.togglePropertyModal();
        }

        
    }]);