﻿// Service definition
app.service('formConfigService', function ($http, $q, $timeout) {

})