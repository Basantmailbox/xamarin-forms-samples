﻿app.directive('rigilprintForm', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/formPrintConfig/partials/customPrintForm.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vm',
        controller: function ($scope, $http) {

            $scope.formid = $scope.vm.formId;
            $scope.moduleid = $scope.vm.moduleId;
            $scope.displayonly = $scope.vm.displayOnly;

            $scope.getSections = function (formid) {
                $http.get("/AppConfiguration/GetForm?id=" + formid).success(function (response) {
                    $scope.form = response.form; //assign fetched FORM row object to this scope variable
                    //what is the form name? I want to put it in the title of the view.
                    $scope.formname = $scope.form.Name;
                    //what sections are contained in the form?
                    $scope.formsections = $scope.form.SectionId;
                    //hey! SectiionId is a comma separated list of Section Ids.
                    //Therefore getting the section details from backend.
                    $http.get("/AppConfiguration/GetSections?sectionids=" + $scope.formsections).success(function (response) {
                        //hey! this section-view details will used to draw the different sections and the related views in the FORM
                        $scope.sections = response.sections;
                    })
                })
            }
        },
        link: function (scope, el, attrs) {
            //render the sections
            scope.getSections(scope.vm.formId);
        }
    }
})

app.directive('rigilprintListview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/formPrintConfig/partials/customPrintListview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vc',
        controller: function ($scope, $http, toaster, $sce) {

            //view configuration values from database
            $scope.formid = $scope.vc.formId;
            $scope.moduleid = $scope.vc.moduleId;
            $scope.sectionid = $scope.vc.sectionId;
            $scope.viewid = $scope.vc.viewId;
            $scope.fieldid = parseInt($scope.vc.fieldId);
            $scope.displayonly = $scope.vc.displayOnly;
            $scope.fieldObj = {};

            //to know fieldType this is called because the return value would be used for appropriate display in the UI
            $http.get("/AppConfiguration/GetField?fieldid=" + $scope.fieldid).success(function (response) {
                $scope.fieldObj = response.fieldObject;
            });

            $scope.isadding = false;
            $scope.isediting = false;

            //model of a row
            $scope.row = {
                id: 0,
                linetext: '',
                edit: true
            }
            $scope.dto = {
                formid: 0,
                moduleid: 0,
                sectionid: 0,
                viewid: 0,
                fieldid: 0,
                linetext: ""
            }
            //load existing entries
            $http.get("/AppConfiguration/GetListlines?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid + "&fieldid=" + $scope.fieldid).success(function (response) {
                $scope.stringTexts = response.data;
            })
        }
    }
})

app.directive('rigilprintTableview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/formPrintConfig/partials/customPrintTableview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce,$modal) {

            //VIEW configuration values from database
            $scope.formid = $scope.vt.formId;
            $scope.moduleid = $scope.vt.moduleId;
            $scope.sectionid = $scope.vt.sectionId;
            $scope.viewid = $scope.vt.viewId;
            $scope.displayonly = $scope.vt.displayOnly;
            $scope.fieldids = $scope.vt.fieldId;
            $scope.rows = [];
            getFields();
            function getFields() {
                //fetch the field ids array
                $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                    $scope.fields = response.fielddata;
                    $scope.rows = [];
                    $scope.row = {};
                    //dynamic open object for the date picker
                    $scope.isOpen = [];
                    //dynamic mouse over event for the money and percentage objects
                    $scope.mouseOver = [];
                    //dynmic checkbox model for storing the checkbox value intermediately
                    //before saving it in the dynamic object itself
                    $scope.checkedData = [];
                    //dynamic datetime option for the datetime picker
                    $scope.dateTimeOptions = [];
                    //dynamic dropdown and multi select Object for ui-select for storing the intermediate object 
                    //before saving it in the dynamic object itself
                    $scope.dropDownObject = [];
                    //prepare the datamodel dynamiclly from fields list
                    angular.forEach($scope.fields, function (value, index) {
                        $scope.row[value.Name] = "";
                        //dynamic open object for the date picker setting to false default setting
                        $scope.isOpen[value.Id] = false;
                        //dynamic mouse over event for the money and percentage objects  setting to false default setting
                        $scope.mouseOver[value.Id] = false;
                        //dynamic datetime option for the datetime picker specified for each object specifically
                        $scope.dateTimeOptions[value.Id] = { useCurrent: false, showClear: true, showClose: true };
                        //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                        $scope.dropDownObject[value.Id] = {};
                        //for field type checkbox and radio button set the length of array to the length of the list
                        if (value.FieldTypeId == 13 || value.FieldTypeId == 14) {
                            $scope.checkedData[value.Id] = new Array(value.UDVList.length);
                        }
                        if (value.FieldTypeId == 3)//Date Picker  set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                        }
                        if (value.FieldTypeId == 4)//DateTime Picker set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                            $scope.dateTimeOptions[value.Id].maxDate = value.MaxDate;
                            $scope.dateTimeOptions[value.Id].minDate = value.MinDate;
                        }
                    })
                    $scope.row["edit"] = true;
                    $scope.row["id"] = 0;
                    getData();
                })
            }

        
            // To set the value of the dropdown  from drop down in the respective dynamic object
            $scope.getUpdatedDropDownValue = function (index, name, id) {
                var ind = parseInt(index);
                $scope.rows[ind][name] = $scope.dropDownObject[id].Id;
            }

            // To set the value of the selected multiple values from multiselect in the respective dynamic object
            $scope.getUpdatedMultiSelectValue = function (index, name, id) {
                var ind = parseInt(index);
                var selectedlist = $scope.dropDownObject[id];
                var list = [];
                angular.forEach(selectedlist, function (value, index) {
                    list.push(value.Id);
                })
                $scope.rows[ind][name] = list.join(',');
            }

            $scope.isadding = false;
            $scope.isediting = false;

            //returns the default field type of a dynamic field from a fieldname parameter
            function getField(fieldname) {
                var FLDTypeId = {};
                angular.forEach($scope.fields, function (value, index) {
                    if (value.Name == fieldname) { FLDTypeId = value; }
                })
                return FLDTypeId;
            }

            //returns the dropdown text from a dropdown array
            function getDropDownText(listObj, id) {
                var retString = "";
                angular.forEach(listObj, function (value, index) {
                    if (value.Id == id) { retString = value.Value; }
                })
                return retString;
            }

            $scope.getDropdownText = function (fieldname, value) {
                var fieldObj = getField(fieldname);
                var selectedDropDownObj = {
                    Id: 0,
                    Value: ""
                };
                selectedDropDownObj.Id = parseInt(value);
                selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                return selectedDropDownObj.Value;
            };

            $scope.getMultiselectDropdownText = function (fieldname, value) {
                var ids = value.split(",");
                var text = "";
                for (j = 0; j < ids.length; j++) {
                    if (text != "") { text = text + ", "; }
                    text = text + $scope.getDropdownText(fieldname, ids[j]);
                }
                return text;
            };

            function getData() {
                //load existing entries
                $http.get("/AppConfiguration/GetTableRows?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid).success(function (response) {
                    $scope.sourcerows = response.TableRows;
                    angular.forEach($scope.sourcerows, function (value, index) {
                        value["edit"] = false;
                        value["slno"] = index;
                        value.id = parseInt(value.id);
                    })
                    $scope.rows = $scope.sourcerows;
                    formatDataSource();
                })
            }

            function formatDataSource() {
                angular.forEach($scope.rows, function (value, index) {
                    angular.forEach(value, function (value1, index1) {
                        var fieldObj = getField(index1);

                        if (fieldObj.FieldTypeId == 2) { //numberbox
                            if (value1 != null & value1 != "") {
                                $scope.rows[index][index1] = parseInt(value1);
                            }
                        }

                        //if (fieldObj.FieldTypeId == 3) { //datePicker
                        //    $scope.rows[index][index1] = value1;
                        //    $scope.$apply();
                        //}

                        if (fieldObj.FieldTypeId == 4) { //datetimePicker
                            if (value1 != null & value1 != "") {
                                $scope.rows[index][index1] = new Date(value1);
                            }
                        }

                        if (fieldObj.FieldTypeId == 5) { //dropdown
                            var selectedDropDownObj = {
                                Id: 0,
                                Value: ""
                            };
                            selectedDropDownObj.Id = parseInt(value1);
                            selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                            $scope.dropDownObject[fieldObj.Id] = selectedDropDownObj;
                        }

                        if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                            var selectedDropDownObj = {
                                Id: 0,
                                Value: ""
                            };
                            var selectedDropDownObjs = [];
                            var ids = value1.split(",");
                            for (j = 0; j < ids.length; j++) {
                                var newObj = angular.copy(selectedDropDownObj);
                                newObj.Id = parseInt(ids[j]);
                                newObj.Value = getDropDownText(fieldObj.DataList, newObj.Id);
                                selectedDropDownObjs.push(newObj);
                            }
                            $scope.dropDownObject[fieldObj.Id] = selectedDropDownObjs;
                        }

                        if (fieldObj.FieldTypeId == 8) { //percentage
                            if (value1 != null & value1 != "") {
                                $scope.rows[index][index1] = parseFloat(value1);
                            } else {
                                $scope.rows[index][index1] = 0;
                            }
                        }

                        if (fieldObj.FieldTypeId == 17) { //editor
                            $scope.rows[index][index1] = $sce.trustAsHtml(value1);
                        }

                    })

                })
            }

            $scope.formatdate = function (sdate) {
                var d = new Date(sdate);
                var currDay = "";
                if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
                var currMonth = "";
                if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
                var currYear = d.getFullYear();
                var startDate = currMonth + "/" + currDay + "/" + currYear;
                return startDate;
            }

            function formatDataSourceCurrentRow(selectedindex) {
                angular.forEach($scope.rows[selectedindex], function (value, index) {
                    var fieldObj = getField(index);

                    if (fieldObj.FieldTypeId == 2) { //numberbox
                        $scope.rows[selectedindex][index] = parseInt(value);
                    }

                    if (fieldObj.FieldTypeId == 3) { //datePicker
                        $scope.rows[selectedindex][index] = new Date(value);
                    }

                    if (fieldObj.FieldTypeId == 4) { //datetimePicker
                        $scope.rows[selectedindex][index] = new Date(value);
                    }

                    if (fieldObj.FieldTypeId == 5) { //dropdown
                        var selectedDropDownObj = {
                            Id: 0,
                            Value: ""
                        };
                        selectedDropDownObj.Id = parseInt(value);
                        selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                        $scope.dropDownObject[fieldObj.Id] = selectedDropDownObj;
                    }

                    if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                        var selectedDropDownObj = {
                            Id: 0,
                            Value: ""
                        };
                        var selectedDropDownObjs = [];
                        var ids = value.split(",");
                        for (j = 0; j < ids.length; j++) {
                            var newObj = angular.copy(selectedDropDownObj);
                            newObj.Id = parseInt(ids[j]);
                            newObj.Value = getDropDownText(fieldObj.DataList, newObj.Id);
                            selectedDropDownObjs.push(newObj);
                        }
                        $scope.dropDownObject[fieldObj.Id] = selectedDropDownObjs;
                    }

                    if (fieldObj.FieldTypeId == 8) { //percentage
                        $scope.rows[selectedindex][index] = parseFloat(value);
                    }

                })
            }

          
        }
    }
})

app.directive('rigilprintStandardview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/formPrintConfig/partials/customPrintStandardview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce, $modal) {

            //VIEW configuration values from database
            $scope.formid = $scope.vt.formId;
            $scope.moduleid = $scope.vt.moduleId;
            $scope.sectionid = $scope.vt.sectionId;
            $scope.viewid = $scope.vt.viewId;
            $scope.displayonly = $scope.vt.displayOnly;
            $scope.fieldids = $scope.vt.fieldId;
            getFields();

           
            $scope.scoringData = [];
            function getFields() {
                //fetch the field ids array
                $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                    $scope.fields = response.fielddata;
                    $scope.rows = [];
                    //dynamic open object for the date picker
                    $scope.isOpen = [];
                    //dynamic mouse over event for the money and percentage objects
                    $scope.mouseOver = [];
                    //dynmic checkbox model for storing the checkbox value intermediately
                    //before saving it in the dynamic object itself
                    $scope.checkedData = [];
                    //dynamic datetime option for the datetime picker
                    $scope.dateTimeOptions = [];
                    //dynamic dropdown and multi select Object for ui-select for storing the intermediate object 
                    //before saving it in the dynamic object itself
                    $scope.dropDownObject = [];
                    //dynamic attached file list
                    $scope.attachedFiles = [];

                    $scope.row = {};
                    //prepare the datamodel dynamiclly from fields list
                    angular.forEach($scope.fields, function (value, index) {
                        $scope.row[value.Name] = "";
                        //dynamic open object for the date picker setting to false default setting
                        $scope.isOpen[value.Id] = false;
                        //dynamic mouse over event for the money and percentage objects  setting to false default setting
                        $scope.mouseOver[value.Id] = false;
                        //dynamic datetime option for the datetime picker specified for each object specifically
                        $scope.dateTimeOptions[value.Id] = { useCurrent: false, showClear: true, showClose: true };
                        //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                        $scope.dropDownObject[value.Id] = {};
                        //empty list of attched file for dynmic object
                        $scope.attachedFiles[value.Id] = [];
                        //for field type checkbox and radio button set the length of array to the length of the list
                        if (value.FieldTypeId == 13 || value.FieldTypeId == 14) {
                            $scope.checkedData[value.Id] = new Array(value.UDVList.length);
                        }
                        if (value.FieldTypeId == 21) {
                            $scope.scoringData[value.Id] = "";
                        }
                        if (value.FieldTypeId == 3)//Date Picker  set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                        }
                        if (value.FieldTypeId == 4)//DateTime Picker set min and max
                        {
                            value.MinDate = new Date(parseInt(value.MinDate.substr(6)));
                            value.MaxDate = new Date(parseInt(value.MaxDate.substr(6)));
                            $scope.dateTimeOptions[value.Id].maxDate = value.MaxDate;
                            $scope.dateTimeOptions[value.Id].minDate = value.MinDate;
                        }
                    })
                    $scope.row["edit"] = true;
                    $scope.row["id"] = 0;
                    getData();
                })
            }
           

            $scope.formatdate = function (sdate) {
                var d = new Date(sdate);
                var currDay = "";
                if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
                var currMonth = "";
                if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
                var currYear = d.getFullYear();
                var startDate = currMonth + "/" + currDay + "/" + currYear;
                return startDate;
            }
           

           
            // To set the value of the checkbox  in the respective dynamic object
            function getSelectedChecked(list, Id) {
                return list.filter(function (x, i) {
                    return $scope.checkedData[Id][i]
                });
            }
            $scope.getCheckedValue = function (name, list, id) {
                var value = getSelectedChecked(list, id);
                $scope.row[name] = value.join(',');
            }

            // To set the value of the dropdown  from drop down in the respective dynamic object
            $scope.getUpdatedDropDownValue = function (name, id) {
                $scope.row[name] = $scope.dropDownObject[id].Id;
            }

            // To set the value of the selected multiple values from multiselect in the respective dynamic object
            $scope.getUpdatedMultiSelectValue = function (name, id) {
                var selectedlist = $scope.dropDownObject[id];
                var list = [];
                angular.forEach(selectedlist, function (value, index) {
                    list.push(value.Id);
                })
                $scope.row[name] = list.join(',');
            }


            $scope.isdeletedD = false;

            $scope.showimage = function (uniquename, filename, filetype, filepath) {
                $scope.documentID = uniquename;
                $scope.documentNAME = filename;
                $scope.documentFILETYPE = filetype;
                $scope.fullFilePath = filepath + $scope.documentID;
                $scope.viewerFullFilePath = "<iframe src='https://docs.google.com/viewer?url=" + filepath + $scope.documentID + "&embedded=true&chrome=false&dov=1' style='width:100%;height:750px' frameborder='0'></iframe>";
                $scope.TrustedviewerFullFilePath = $sce.trustAsHtml($scope.viewerFullFilePath);
                $scope.isIframe = true;
            }

           

            //returns the default field type of a dynamic field from a fieldname parameter
            function getField(fieldname) {
                var FLDTypeId = {};
                angular.forEach($scope.fields, function (value, index) {
                    if (value.Name == fieldname) { FLDTypeId = value; }
                })
                return FLDTypeId;
            }

            //returns the dropdown text from a dropdown array
            function getDropDownText(listObj, id) {
                var retString = "";
                angular.forEach(listObj, function (value, index) {
                    if (value.Id == id) { retString = value.Value; }
                })
                return retString;
            }

            $scope.getDropdownText = function (fieldname, value) {
                var fieldObj = getField(fieldname);
                var selectedDropDownObj = {
                    Id: 0,
                    Value: ""
                };
                selectedDropDownObj.Id = parseInt(value);
                selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                return selectedDropDownObj.Value;
            };

            $scope.getMultiselectDropdownText = function (fieldname, value) {
                var ids = value.split(",");
                var text = "";
                for (j = 0; j < ids.length; j++) {
                    if (text != "") { text = text + ", "; }
                    text = text + $scope.getDropdownText(fieldname, ids[j]);
                }
                return text;
            };



            //fetch saved data
            function getData() {
                //load existing entries
                $http.get("/AppConfiguration/GetStandarddata?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid).success(function (response) {
                    $scope.sourcerows = response.TableRows;
                    angular.forEach($scope.sourcerows, function (value, index) {
                        value["edit"] = false;
                        value.id = parseInt(value.id);
                    })
                    if ($scope.sourcerows.length > 0) {
                        $scope.rowdata = $scope.sourcerows[0];


                        angular.forEach($scope.rowdata, function (value, index) {
                            var fieldObj = getField(index);

                            if (fieldObj.FieldTypeId == 2) { //numberbox
                                if (value != "" && value != null)
                                    $scope.row[index] = parseInt(value);
                            }
                            if ($scope.editForm) {
                                if (fieldObj.FieldTypeId == 4) { //datetimePicker
                                    $scope.row[index] = new Date(value);
                                }
                            }

                            if (fieldObj.FieldTypeId == 5) { //dropdown
                                var selectedDropDownObj = {
                                    Id: 0,
                                    Value: ""
                                };
                                selectedDropDownObj.Id = parseInt(value);
                                selectedDropDownObj.Value = getDropDownText(fieldObj.DataList, selectedDropDownObj.Id);
                                $scope.dropDownObject[fieldObj.Id] = selectedDropDownObj;
                            }

                            if (fieldObj.FieldTypeId == 6) { //multiselect dropdown
                                var selectedDropDownObj = {
                                    Id: 0,
                                    Value: ""
                                };
                                var selectedDropDownObjs = [];
                                var ids = value.split(",");
                                for (j = 0; j < ids.length; j++) {
                                    var newObj = angular.copy(selectedDropDownObj);
                                    newObj.Id = parseInt(ids[j]);
                                    newObj.Value = getDropDownText(fieldObj.DataList, newObj.Id);
                                    selectedDropDownObjs.push(newObj);
                                }
                                $scope.dropDownObject[fieldObj.Id] = selectedDropDownObjs;
                            }

                            if (fieldObj.FieldTypeId == 8) { //percentage
                                if (value != "" && value != null)
                                    $scope.row[index] = parseFloat(value);
                            }

                            if (fieldObj.FieldTypeId == 14) { //checkbox
                                var selectedlist = value.split(',');
                                $scope.checkedData[fieldObj.Id] = new Array(fieldObj.UDVList.length);
                                angular.forEach(fieldObj.UDVList, function (value1, index1) {
                                    angular.forEach(selectedlist, function (value2, index2) {
                                        if (value1 == value2) {
                                            $scope.checkedData[fieldObj.Id][index1] = true;
                                        }
                                    })
                                })

                            }

                            if (fieldObj.FieldTypeId == 16) {//attachments
                                $http.get("/api/Library/Index?module=Bid&moduleId=" + $scope.moduleid + "&subModule=" + fieldObj.Name + "&subModuleId=" + $scope.formid).success(function (response) {
                                    $scope.attachedFiles[fieldObj.Id] = response.uploadresults;
                                })
                            }
                            if (fieldObj.FieldTypeId == 17) { //editor
                                $scope.row[index] = $sce.trustAsHtml(value);
                            }
                            if (fieldObj.FieldTypeId == 21) {
                                $scope.viewfields = [];
                                var totalscore = 0;
                                var scoredValue = 0;
                                $http.get("/AppConfiguration/GetViewFields?viewId=" + fieldObj.QViewId).success(function (response) {
                                    var fieldsdata = "";
                                    fieldsdata = response.fieldIds;
                                    if (fieldsdata != "") {
                                        //fetch the field ids array
                                        $http.get("/AppConfiguration/GetFields?fieldids=" + fieldsdata).success(function (response) {
                                            $scope.viewfields = response.fielddata;
                                            //prepare the datamodel dynamiclly from fields list
                                            angular.forEach($scope.viewfields, function (values, indexs) {
                                                totalscore = totalscore + values.maxScore;
                                            })
                                            if (value != "" && value != null) {
                                                $scope.fieldData = JSON.parse(value);
                                            }
                                            angular.forEach($scope.viewfields, function (value1, index1) {
                                                angular.forEach($scope.fieldData, function (val, indx) {
                                                    if (indx == value1.Name)
                                                    {
                                                        var selectedvalue = val;
                                                        if (selectedvalue != "") {
                                                            angular.forEach(value1.ValueWeightageList, function (value2, index2) {
                                                                if (value2.Value == selectedvalue) {
                                                                    scoredValue = scoredValue + value2.Weightage;
                                                                }
                                                            })
                                                        }
                                                    }
                                                    
                                                    
                                                })
                                            })
                                            $scope.scoringData[fieldObj.Id] = scoredValue+'/'+totalscore;
                                        })
                                    }

                                })
                                $scope.row[index] = value;
                            }
                            else {
                                if (value != "")
                                    $scope.row[index] = value;

                            }
                        })
                        angular.forEach($scope.row, function (value, index) {
                            if (!value)
                                $scope.row[index] = "";
                        })
                    }

               })
            }
        }
    }
})

app.directive('rigilprintQuestionnaireview', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            formId: '=',
            moduleId: '=',
            sectionId: '=',
            viewId: '=',
            fieldId: '=',
            displayOnly: '='
        },
        templateUrl: '../Scripts/app/appConfiguration/formPrintConfig/partials/customPrintQuestionnaireview.html',
        transclude: true,
        bindToController: true,
        controllerAs: 'vt',
        controller: function ($scope, $http, toaster, $sce) {

            //VIEW configuration values from database
            $scope.formid = $scope.vt.formId;
            $scope.moduleid = $scope.vt.moduleId;
            $scope.sectionid = $scope.vt.sectionId;
            $scope.viewid = $scope.vt.viewId;
            $scope.displayonly = $scope.vt.displayOnly;
            $scope.fieldids = $scope.vt.fieldId;
            getFields();
            $scope.scoring = {
                totalScore: 0,
                myScore: 0,
            }
            $scope.row = {};

            function getFields() {
                //fetch the field ids array
                $http.get("/AppConfiguration/GetFields?fieldids=" + $scope.fieldids).success(function (response) {
                    $scope.fields = response.fielddata;
                    $scope.rows = [];

                    //dynamic dropdown  Object for ui-select for storing the intermediate object 
                    //before saving it in the dynamic object itself
                    $scope.dropDownObject = [];
                    $scope.scoring.totalScore = 0;
                    $scope.scoring.myScore = 0;
                    //prepare the datamodel dynamiclly from fields list
                    angular.forEach($scope.fields, function (value, index) {
                        $scope.row[value.Name] = "";
                        //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                        $scope.dropDownObject[value.Id] = {};
                        $scope.scoring.totalScore = $scope.scoring.totalScore + value.maxScore;
                    })
                    $scope.row["edit"] = true;
                    $scope.row["id"] = 0;
                    getData();
                })
            }

            $scope.getLatestScore = function () {
                $scope.scoring.myScore = 0;
                angular.forEach($scope.fields, function (value, index) {
                    var selectedvalue = $scope.row[value.Name];
                    if (selectedvalue != "") {
                        angular.forEach(value.ValueWeightageList, function (value1, index1) {
                            if (value1.Value == selectedvalue) {
                                $scope.scoring.myScore = $scope.scoring.myScore + value1.Weightage;
                            }
                        })
                    }
                })
            }

            //row save method
            $scope.saveForm = function () {
                $scope.row.edit = false;
                $scope.isadding = false;
                $scope.isediting = false;

                $scope.dataARRAY = [];
                //create a model for passing field and property value
                //pair in an array to the asp.net mvc controller
                $scope.datarray = {
                    field: "",
                    value: "",
                    fieldid: 0
                }

                //convert property:values of the form to key:value pair array
                angular.forEach($scope.fields, function (value, Index) {
                    $scope.newdatarray = angular.copy($scope.datarray);
                    $scope.newdatarray.field = value.Name;
                    $scope.newdatarray.value = $scope.row[value.Name];
                    $scope.newdatarray.fieldid = value.Id;
                    $scope.dataARRAY.push($scope.newdatarray);
                })

                //prepare the DTO to go with the post call for row insertion
                dto = {
                    id: $scope.row.id,
                    formid: $scope.formid,
                    moduleid: $scope.moduleid,
                    sectionid: $scope.sectionid,
                    viewid: $scope.viewid,
                    fieldid: $scope.fieldid,
                    row: $scope.dataARRAY
                }

                if ($scope.row.id == 0) {
                    //new record: insert it in table
                    $http.post("/AppConfiguration/PostQuestionnaireData", dto).success(function (response) {
                        $scope.row.id = response.savedId;
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                } else {
                    //old record: update it in table
                    $http.put("/AppConfiguration/PutQuestionnaireData", dto).success(function (response) {
                        toaster.pop('success', 'Success', "Operation Successfull !!");
                    })
                }
            }

            $scope.resetForm = function () {
                $scope.scoring.totalScore = 0;
                $scope.scoring.myScore = 0;
                angular.forEach($scope.fields, function (value, index) {
                    $scope.row[value.Name] = "";
                    //dynamic dropdown and multi select Object for ui-select specified for each object specifically
                    $scope.dropDownObject[value.Id] = {};
                    $scope.scoring.totalScore = $scope.scoring.totalScore + value.maxScore;
                })
                toaster.pop('success', 'Success', "Form Reset Successfully !!");
            }

            $scope.resetQuestion = function (name) {
                $scope.row[name] = "";
                $scope.getLatestScore();
                toaster.pop('success', 'Success', "Operation Successfull !!");
            }

            //fetch saved data
            function getData() {
                //load existing entries
                $http.get("/AppConfiguration/GetQuestionnaireData?moduleid=" + $scope.moduleid + "&formid=" + $scope.formid + "&sectionid=" + $scope.sectionid + "&viewid=" + $scope.viewid).success(function (response) {
                    $scope.sourcerows = response.TableRows;
                    angular.forEach($scope.sourcerows, function (value, index) {
                        value["edit"] = false;
                        value.id = parseInt(value.id);
                    })
                    if ($scope.sourcerows.length > 0) {
                        $scope.row = $scope.sourcerows[0];
                        $scope.getLatestScore();
                    }
                })
            }

        }
    }
})

