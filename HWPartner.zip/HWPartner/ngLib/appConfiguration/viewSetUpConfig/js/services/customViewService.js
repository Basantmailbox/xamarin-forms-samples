﻿// Service definition for Custom View Configuration
app.factory('customViewService', [
    '$http',
    function ($http) {
        return {
            getAllViews: function () {
                return $http.get('/AppConfiguration/AllViews').
                  success(function (data, status, headers) {
                     // console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getAllLayouts: function () {
                return $http.get('/AppConfiguration/AllLayouts').
                  success(function (data, status, headers) {
                     // console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getFields: function (tableId) {
                return $http.get('/AppConfiguration/tableFields?tableId=' + tableId).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getSpecificFields: function (tableId,layoutId) {
                return $http.get('/AppConfiguration/tableLayoutSpecificFields?tableId=' + tableId + '&layoutId=' + layoutId).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            postView: function (obj) {
                return $http.post('/AppConfiguration/PostViewSet', obj).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            putView: function (id, obj) {
                return $http.put('/AppConfiguration/PutViewSet?id=' + id, obj).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            deleteView: function (id) {
                return $http.delete('/AppConfiguration/DeleteViewSet?id=' + id).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            }

        }
    }
]);