﻿app.directive('customView', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: false,
        templateUrl: 'Scripts/app/appConfiguration/viewSetUpConfig/partials/customView.html',
        controller: 'customViewCtrl',
        link: function ($scope, $element, attr) {
        }
    }
}]);