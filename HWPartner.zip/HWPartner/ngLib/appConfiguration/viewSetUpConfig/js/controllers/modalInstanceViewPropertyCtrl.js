﻿app.controller('modalInstanceViewPropertyCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'object', 'toaster', '$location', 'customFieldService',
    function ($scope, $http, $modalInstance, $controller, object, toaster, location, customFieldService) {

        $scope.objectData = object;
        $scope.fieldsObject = $scope.objectData.FieldsObj;
        $scope.togglePropertyModal = function () {
            $modalInstance.close("");
        }

        $scope.cancelOrder = function () {
            $modalInstance.close("");
        }
        $scope.saveOrder = function () {
            $modalInstance.close($scope.objectData);
        }

    }]);