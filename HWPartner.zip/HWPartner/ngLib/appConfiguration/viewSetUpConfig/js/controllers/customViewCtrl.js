﻿'use strict';

app.controller('customViewCtrl', ['$scope', '$http', '$modal', 'customViewService', '$timeout', '$window', 'toaster', 'customFieldService',
    function ($scope, $http, $modal, customViewService, $timeout, $window, toaster, customFieldService) {
        $scope.addNewView = true;
        $scope.editOldView = false;
        $scope.deleteView = false;

        $scope.saveView = false;
        $scope.cancelView = false;
        $scope.isAddingView = false;
        $scope.isEditingView = false;
        $scope.currentViewIndex = 0;
        $scope.isLayoutEmpty = true;
        $scope.viewSet = [];// contains all the views
        $scope.viewBackUpSet = [];//contains the back up  of viewSet
        $scope.newViewRecord = {};

        $scope.allLayouts = [];
        $scope.allTables = [];
        $scope.allFields = [];

        // Method to load record states for different tables
        $scope.loadViewData = function () {
            getViewData();
            //api service call to get all the layouts
            customViewService.getAllLayouts().then(function (response) {
                $scope.allLayouts = response.data.LayoutList;              //populating list of layouts to show in a table dropdown in UI
            });
            //api service call to get all the tables
            customFieldService.getAllTables().then(function (response) {
                $scope.allTables = response.data.TableList;              //populating list of tables to show in a table dropdown in UI
            });
        }
        // load at run time
        $scope.loadViewData();

        function getViewData() {
            //api service call to get all the views
            customViewService.getAllViews().then(function (response) {
                $scope.viewSet = response.data.ViewList;              //populating list of views 
                if ($scope.viewSet.length > 0) {
                    $scope.editOldView = true;
                    $scope.deleteView = true;
                }
            });
        }
       
        // Method to add a new View
        $scope.addnewViewRecord = function () {

            $scope.newViewRecord = {
                Id: 0,
                Name: "",
                Description: "",
                TableId: 0,
                FieldsId: "",
                CustomLayoutId: 0,
                Add: true,
                Edit: false,
                Delete: false,
                TableName: "",
                LayoutName: "",
                FieldsName: "",
                TableObj: {},
                LayoutObj: {},
                FieldsObj: []
            }
            $scope.isLayoutEmpty = true;
            $scope.isAddingView = true;
            $scope.viewSet.push($scope.newViewRecord);
            $scope.currentViewIndex = $scope.viewSet.length - 1;
        }

        $scope.onTableSelection = function (selectedTable,index) {
            
            $scope.viewSet[index].FieldsObj = [];
            getfields(index, selectedTable.Id);
        }
        
        function getfields(index,tableId) {
            $scope.allFields = [];
            var layoutId = $scope.viewSet[index].LayoutObj.Id;
            customViewService.getSpecificFields(tableId, layoutId).then(function (response) {
                $scope.allFields = response.data.FieldList;           //populating list of fields per selected table and layout
            });
        }

        $scope.onLayoutSelection = function (index) {
            $scope.viewSet[index].TableObj = {};
            $scope.viewSet[index].FieldsObj = [];
            $scope.isLayoutEmpty = false;
        }

        $scope.editOldViewRecord = function (index) {
            $scope.isLayoutEmpty = false;
            $scope.viewBackUpSet = angular.copy($scope.viewSet);  //will be used in case of undo
            $scope.isEditingView = true;
            $scope.viewSet[index].Edit = true;
            $scope.currentViewIndex = index;
            getfields(index,$scope.viewSet[index].TableObj.Id);
        }
        $scope.deleteViewRecord = function (index) {
            var Id = $scope.viewSet[index].Id;
            var ans = confirm("Are you sure you want to delete it?");
            if (ans) {
                customViewService.deleteView($scope.viewSet[index].Id).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.viewSet.splice(index, 1);
                        toaster.pop('success', 'Success', "Deleted successfully !");
                    }
                    else if (response.data.result == "NotPossible") {
                        toaster.pop('info', 'Alert!!!', "Disassociate Section records with this View first!!!");
                    }
                    else {
                        toaster.pop('error', 'Error', "An Error Occured while deleting!!!");
                    }
                });
            }

        }


        $scope.validateViewEntry = function (index) {
           
            var isLayoutValid = CheckLayout(index);
            if (isLayoutValid)
            {
                if ($scope.viewSet.length == 1) {
                    $scope.saveViewRecord(index);
                }
                else {
                    //check for duplicate view names
                    var bool = validateViewMethod();
                    if (bool) {
                        $scope.saveViewRecord(index);
                    }
                }
            }
            else
            {
                toaster.pop('error', 'Error', "List layout can have only one field");
            }
        }
        //if layout is list then only one field can be selected
        function CheckLayout(index) {
            var valid = true;
            if ($scope.viewSet[index].LayoutObj.Id == 2)
            {
                if($scope.viewSet[index].FieldsObj.length>1)
                {
                    valid = false;
                }
            }
            return valid;
        }
        //check for duplicate view names
        function validateViewMethod() {
            var bool = true;
            var name = $scope.viewSet[$scope.currentViewIndex].Name;
            angular.forEach($scope.viewSet, function (val, indx) {
                if (indx != $scope.currentViewIndex) {
                    if (val.Name.toLowerCase() == name.toLowerCase()) {
                        bool = false;
                        toaster.pop('error', 'Error', "View Name cannot be duplicate");
                    }
                }
            })
            return bool;
        }
        $scope.saveViewRecord = function (index) {
            var obj = $scope.viewSet[$scope.currentViewIndex];
            if ($scope.isAddingView)    //i.e. new addition
            {
                customViewService.postView($scope.viewSet[$scope.currentViewIndex]).then(function (response) {
                    if (response.data.result == "Success") {
                        $scope.viewSet[$scope.currentViewIndex].Id = response.data.NewRecord.Id;
                        $scope.viewSet[$scope.currentViewIndex].Add = false;
                        $scope.viewSet[$scope.currentViewIndex].Edit = false;
                        $scope.viewSet[$scope.currentViewIndex].Delete = false;
                        $scope.isAddingView = false;
                        toaster.pop('success', 'Success', "Insert successful !");
                    }
                    else {
                        $scope.isAddingView = false;
                        toaster.pop('error', 'Error', "An error occured while adding view");
                    }
                    getViewData();

                });
            }
            if ($scope.isEditingView)    //i.e. existing modification
            {
                $scope.viewSet[index].Edit = false;
                $scope.isEditingView = false;
                putViewData(index);
            }
        }

        function putViewData(index) {
            customViewService.putView($scope.viewSet[index].Id, $scope.viewSet[index]).then(function (response) {
                if (response.data.result == "Success") {
                    toaster.pop('success', 'Success', "Update successful!");
                }
                else {
                    toaster.pop('error', 'Error', "An error occured while editing view");
                }
                getViewData();
            });
        }
        $scope.cancelViewRecord = function (index) {
            $scope.isAddingView = false;
            $scope.isEditingView = false;
            $scope.viewSet = angular.copy($scope.viewBackUpSet);  //restore from backup
            getViewData();
        }


        $scope.openPropertyModal = function (index) {
            var modalInstance = $modal.open({
                templateUrl: 'Scripts/app/appConfiguration/viewSetUpConfig/partials/customViewProperty.html',
                controller: 'modalInstanceViewPropertyCtrl',
                backdrop: 'static',
                size: 'lg',
                scope: $scope,
                resolve: {
                    object: function () { 
                        return $scope.viewSet[index];
                    }
                }
            });
            modalInstance.result.then(function (result) {
                if (result !="")
                {
                    $scope.viewSet[index] = result;
                    putViewData(index);
                }

            });
        }

    }]);