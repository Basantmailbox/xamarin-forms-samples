﻿//used by "App\master\Resume\js\controllers\chart.js"
//used by "App\master\Resume\Scripts\app\resume-controller.js"
//used by "App\master\Resume\Scripts\app\bidtracking-controller.js"
app.directive("limitTo", [function () {
    return {
        restrict: "A",
        link: function (scope, elem, attrs) {
            var limit = parseInt(attrs.limitTo);
            angular.element(elem).on("keypress", function (e) {
                if (this.value.length == limit) e.preventDefault();
            });
        }
    }
}]);

// used by "App\master\Resume\Scripts\app\resume-controller.js"
//used by "App\master\Resume\Scripts\app\bidtracking-controller.js"
app.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});

app.directive('autoFocus', function ($timeout) {
    return {
        restrict: 'AC',
        link: function (_scope, _element) {
            $timeout(function () {
                _element[0].focus();
            }, 0);
        }
    };
});

// used by "App\master\Resume\Scripts\app\resume-controller.js"
//used by "App\master\Resume\Scripts\app\bidtracking-controller.js" ----"bidtracker partner"
app.directive('noSpecialChar', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                if (inputValue == undefined)
                    return ''
                cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
                if (cleanInputValue != inputValue) {
                    modelCtrl.$setViewValue(cleanInputValue);
                    modelCtrl.$render();
                }
                return cleanInputValue;
            });
        }
    }
});

// used by "App\master\Resume\Scripts\app\resume-controller.js"
//used by "App\master\Resume\Scripts\app\bidtracking-controller.js"
app.directive('validateMaskedCtrl', function () {
    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            $(element).on("change", function () {
                scope.$apply(function () { ngModelCtrl.$setViewValue(element.val()); });
            });
        }
    };
});
// used by "App\master\Resume\Scripts\app\resume-controller.js"
app.directive('myEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.myEnter);
                });

                event.preventDefault();
            }
        });
    };
});


