﻿app.directive('customerDatePicker', function () {
    return {
        restrict: "A",
        require: 'ngModel',
        scope: {
            firstDate: '@',
            lastDate: '@'
        },
        link: function (scope, element, attrs, ngModel) {
            $(function () {
                $(element).datepicker({
                    changeMonth: true,
                    changeYear: true,
                    closeText: 'Clear',
                    showButtonPanel: true,
                    maxDate: new Date(),
                    onClose: function () {
                        var event = arguments.callee.caller.caller.arguments[0];
                        // If "Clear" gets clicked, then really clear it
                        if ($(event.delegateTarget).hasClass('ui-datepicker-close')) {
                            $(this).val('');
                            scope.$apply(function () {
                                ngModel.$setViewValue(null);
                                var obj = {};
                                obj.firstDate = scope.firstDate;
                                obj.lastDate = scope.lastDate;
                                scope.$emit('clearDate', obj);
                            });
                        }
                    },
                    onSelect: function (date) {
                        scope.$apply(function () {
                            ngModel.$setViewValue(date);
                        });
                    }
                });
            })
        }
    }
});