﻿app.directive('customerHistory', ['$location', function ($location) {
    return {
        restrict: "EA",
        scope: { id: '@' },
        templateUrl: 'Scripts/app/customer/partials/customerHistory.html',
        controller: 'customerHistoryCtrl',
        link: function ($scope, $element, attr) {

        }
    }
}]);