﻿'use strict';
app.factory('customerHistoryModel', [
    function () {
        var customerHistoryDataModel = function (data) {
            var property = {};
            angular.extend(this, {
                id: data.Id,
                customerId: data.CustomerId,
                changeKey: data.ChangeKey,
                changeDate: data.ChangeDate,
                userId: data.UserId,
                changeFieldName: data.ChangeFieldname,
                oldValue: data.Oldvalue,
                newValue: data.Newvalue,
                userAction: data.UserAction,//'Add / 'Update' / 'Delete'
                tabName: data.Tabname,
                tabPageRecordId: data.Tabpage_RecordId
            });
            return this;
        };
        return customerHistoryDataModel;
    }]);