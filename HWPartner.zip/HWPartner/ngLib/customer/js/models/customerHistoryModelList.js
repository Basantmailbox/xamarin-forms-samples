﻿app.factory('customerHistoryModelList', [
    'customerHistoryModel',
    function (customerHistoryModel) {
        var customerHistoryList = function (customerHistoryListData) {
            angular.extend(this, {
                customerHistory: populateList(customerHistoryListData)
            });
            return this;
        };
        return customerHistoryList;

        function populateList(events) {
            var customerHistoryItems = [];
            _.each(events, function (item) {
                customerHistoryItems.push(new customerHistoryModel(item));
            });
            return customerHistoryItems;
        }
    }]);