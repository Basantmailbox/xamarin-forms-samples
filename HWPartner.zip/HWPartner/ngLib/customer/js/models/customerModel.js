﻿'use strict';
app.factory('customerModel', [
    function () {
        var customerDataModel = function (data) {
            var property = {};
            angular.extend(this, {
                id: data.Id,
                name: data.Name,
                title: data.Title,
                email: data.Email,
                phone: data.Phone,
                mobile: data.Mobile,
                address: data.Address,
                city: data.City,
                district: data.District,
                pinCode: data.PinCode,
                facebookUrl: data.FacebookUrl,
                linkedinUrl: data.LinkedinUrl,
                twitter: data.Twitter,
                pocId: data.PocId,
                relationShipId: data.RelationShipId,
                departmentId: data.DepartmentId,
                agencyId: data.AgencyId,
                bids: data.Bids,
                bidsStr:data.BidsStr,
                capabilities: data.Capabilities,
                capabilitiesStr:data.CapabilitiesStr,
                contracts: data.Contracts,
                contractsStr:data.ContractsStr,
                createDate: data.CreateDate,
                relationShip: data.RelationShip,
                department: data.Department,
                agency: data.Agency,
                otherPhones:data.OtherPhones,
                pocRelation: data.PocRelation,
                description: data.Description,
            });
            return this;
        };
        return customerDataModel;
    }]);