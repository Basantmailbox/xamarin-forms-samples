﻿app.factory('customerModelList', [
    'customerModel',
    function (customerModel) {
        var customerList = function (customerListData) {
            angular.extend(this, {
                customer: populateList(customerListData)
            });
            return this;
        };
        return customerList;

        function populateList(events) {
            var customerItems = [];
            _.each(events, function (item) {
                customerItems.push(new customerModel(item));
            });
            return customerItems;
        }
    }]);