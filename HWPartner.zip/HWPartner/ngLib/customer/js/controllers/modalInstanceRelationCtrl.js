﻿'use strict';
app.controller('modalInstanceRelationCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'toaster', '$location', 'userlist', 'relationlist', 'poc', 'relationId', 'wholelist',
    function ($scope, $http, $modalInstance, $controller, toaster, location, userlist, relationlist, poc, relationId, wholelist) {
    $scope.userListDropDown = userlist;
    $scope.relationshipDropDown = relationlist;
    $scope.newpocId = poc;
    $scope.newrelationShipId = relationId;
    $scope.completedata = [];
    $scope.completedata = wholelist;
    $scope.newrelation = { POC: "", Relation: 0 };
    $scope.toggleAttachModal = function () {
        $modalInstance.close("",0);
    }
    $scope.saveRelation = function () {
        var find = _.find($scope.completedata, function (obj) {
            return (obj.POC == $scope.newpocId && obj.Relation == $scope.newrelationShipId);
        });
        if (_.isUndefined(find)) {
            $scope.newrelation.POC = $scope.newpocId;
            $scope.newrelation.Relation = $scope.newrelationShipId;
            $modalInstance.close($scope.newrelation);
        }
        else {
            $scope.newpocId = poc;
            $scope.newrelationShipId = relationId;
            toaster.pop('error', 'Duplicate Data', "POC-Relation already exists!");
        }
       
    }
}]);