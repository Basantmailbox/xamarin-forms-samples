﻿'use strict';
app.controller('customerCtrl', ['$scope', '$http', '$modal', 'customerService', 'customerModelList', 'customerModel', 'uiGridConstants', '$timeout', 'toaster', '$window', 'customerHistoryModelList', 'customerHistoryModel', '$interval','$sce',
function ($scope, $http, $modal, customerService, customerModelList, customerModel, uiGridConstants, $timeout, toaster, $window, customerHistoryModelList, customerHistoryModel, $interval, $sce) {
    $scope.showEntry = false;
    $scope.showList = true;
    var customerObj = {};
    $scope.customerId = 0;
    $scope.dirFlag = false;
    $scope.emailFormat = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,5})$/;
    $scope.mandatory = {};
    $scope.mandatory.check = false;

    $scope.userList = [];
    $scope.relationship = [];
    $scope.departmentList = [];
    $scope.contractList = [];
    $scope.bidList = [];
    $scope.capabilityList = [];
    $scope.agencyList = [];

    $scope.userListDropDown = [];
    $scope.relationshipDropDown = [];
    $scope.departmentListDropDown = [];
    $scope.contractListDropDown = [];
    $scope.bidListDropDown = [];
    $scope.capabilityListDropDown = [];
    $scope.agencyListDropDown = [];

    $scope.multiContractList = [];
    $scope.multiBidList = [];
    $scope.multiCapabilityList = [];

    $scope.isExpandedPhoneSection = true;
    $scope.isExpandedContractSection = true;
    $scope.isExpandedBidSection = true;
    $scope.isExpandedCapabilitySection = true;
    $scope.isExpandedRelationSection = true;

    $scope.phoneList = [];
    $scope.relationList = [];
    $scope.Step1 = {};
    $scope.Step2 = {};
    $scope.Step1.active = true;
    $scope.Step2.active = false;


    $scope.togglePhoneExpandedSection = function () {
        $scope.isExpandedPhoneSection = !$scope.isExpandedPhoneSection;
    }
    $scope.toggleContractExpandedSection = function () {
        $scope.isExpandedContractSection = !$scope.isExpandedContractSection;
    }
    $scope.toggleBidExpandedSection = function () {
        $scope.isExpandedBidSection = !$scope.isExpandedBidSection;
    }
    $scope.toggleCapabilityExpandedSection = function () {
        $scope.isExpandedCapabilitySection = !$scope.isExpandedCapabilitySection;
    }
    $scope.toggleRelationExpandedSection = function () {
        $scope.isExpandedRelationSection = !$scope.isExpandedRelationSection;
    }

    $scope.currentRecordId = 0;
    $scope.customerData = new customerModel(customerObj);
    $scope.toggleShowList = function () {
        $scope.showEntry = !$scope.showEntry;
        $scope.showList = !$scope.showList;
        getData();
        $scope.gridApi.grid.refresh();
    };
    $scope.cancelEntry = function () {

    }

    $scope.new = function () {
        $scope.mandatory.check = false;
        $scope.customerData = new customerModel(customerObj);
        $scope.multiContractList = [];
        $scope.multiBidList = [];
        $scope.multiCapabilityList = [];
        $scope.customerData.twitter = "";
        $scope.customerData.linkedinUrl = "";
        $scope.customerData.facebookUrl = "";
        $scope.phoneList = [];
        $scope.relationList = [];
        $scope.customerData.pocId = "";
        $scope.customerData.relationShipId = 0;
        $scope.currentRecordId = 0;
        $scope.Step1.active = true;
        $scope.Step2.active = false;
    }

    $scope.save = function () {
        $scope.customerData.contracts = getIdValues($scope.multiContractList);
        $scope.customerData.bids = getIdValues($scope.multiBidList);
        $scope.customerData.capabilities = getIdValues($scope.multiCapabilityList);
        $scope.customerData.otherPhones = getPhoneString($scope.phoneList);
        $scope.customerData.pocRelation = $scope.relationList;
        if ($scope.customerData.id > 0) {
            customerService.putData($scope.customerData.id, $scope.customerData).then(function (response) {
                getData();
                toaster.pop('success', 'Success', "Customer Record updated successfully!");
                $scope.gridApi.grid.refresh();
            });
        }
        else {
            customerService.postData($scope.customerData).then(function (response) {
                getData();
                toaster.pop('success', 'Success', "Customer Record added successfully!");
                $scope.gridApi.grid.refresh();

            });
        }
    };
    function getIdValues(obj) {
        $scope.returnvalue = [];
        if (obj.length > 0) {
            angular.forEach(obj, function (value, index) {
                $scope.returnvalue.push(parseInt(value.Key));
            });
        }
        return $scope.returnvalue;
    }
    function getPhoneString(obj) {
        $scope.returnvalue = [];
        if (obj.length > 0) {
            angular.forEach(obj, function (value, index) {
                $scope.returnvalue.push(value.Phone);
            });

        }
        return $scope.returnvalue.toString();
    }


    //----------ui-grid------------------------------
    bindGrid();
    getDropdownData();
    getData();
    getGeneralConfigs();

    function getDropdownData() {

        customerService.getAllUsersList().then(function (response) {
            if (response.data.data) {
                _.each(response.data.data, function (obj) {
                    var newObj = {};
                    newObj["Id"] = obj;
                    newObj["Name"] = obj;
                    $scope.userListDropDown.push(newObj);
                });

                _.each(response.data.data, function (data) {
                    var find = _.find($scope.userList, function (obj) {
                        return (obj.value == data);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data;
                        obj.label = data;
                        $scope.userList.push(obj);
                    }
                })
            }
        });

        customerService.getRelationship().then(function (response) {
            if (response.data.types) {
                $scope.relationshipDropDown = response.data.types;
                _.each(response.data.types, function (data) {
                    var find = _.find($scope.relationship, function (obj) {
                        return (obj.Name == data.Name);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data.Name;
                        obj.label = data.Name;
                        $scope.relationship.push(obj);
                    }
                })
            }
        });

        customerService.getDepartments().then(function (response) {
            if (response.data.agencyList) {
                $scope.departmentListDropDown = response.data.agencyList;
                _.each(response.data.agencyList, function (data) {
                    var find = _.find($scope.departmentList, function (obj) {
                        return (obj.label == data.Name);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data.Agencyname;
                        obj.label = data.Agencyname;
                        $scope.departmentList.push(obj);
                    }
                })
            }
        });

        customerService.getAllContracts().then(function (response) {
            if (response.data.data) {
                $scope.contractListDropDown = response.data.data;
                _.each(response.data.data, function (data) {
                    var find = _.find($scope.contractList, function (obj) {
                        return (obj.Name == data.Name);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data.Name;
                        obj.label = data.Name;
                        $scope.contractList.push(obj);
                    }
                })
            }
        });

        customerService.getAllBids().then(function (response) {
            if (response.data.data) {
                $scope.bidListDropDown = response.data.data;
                _.each(response.data.data, function (data) {
                    var find = _.find($scope.bidList, function (obj) {
                        return (obj.value == data.Name);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data.Name;
                        obj.label = data.Name;
                        $scope.bidList.push(obj);
                    }
                })
            }
        });

        customerService.getAllCapabilities().then(function (response) {
            if (response.data.data) {
                $scope.capabilityListDropDown = response.data.data;
                _.each(response.data.data, function (data) {
                    var find = _.find($scope.capabilityList, function (obj) {
                        return (obj.value == data.Name);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data.Name;
                        obj.label = data.Name;
                        $scope.capabilityList.push(obj);
                    }
                })
            }
        });
    }

    $scope.getAgency = function () {
        customerService.getAgencies($scope.customerData.departmentId).then(function (response) {
            if (response.data.agencyList) {
                $scope.agencyListDropDown = response.data.agencyList;
                _.each(response.data.agencyList, function (data) {
                    var find = _.find($scope.agencyList, function (obj) {
                        return (obj.value == data.Name);
                    });
                    if (_.isUndefined(find)) {
                        var obj = {};
                        obj.value = data.Name;
                        obj.label = data.Name;
                        $scope.agencyList.push(obj);
                    }
                })
            }
        });
    };

    function getData() {
        customerService.getData().then(function (response) {
            if (response.data && response.data.length > 0) {
                var customerData = new customerModelList(response.data);
                $scope.gridOptions.data = customerData.customer;
            }
            else {
                $scope.gridOptions.data = [];
            }
        });
    }

    function getGeneralConfigs() {
        customerService.getGeneralConf().then(function (response) {
            if (response.data) {
                $scope.savedState = response.data;
                $scope.state = JSON.parse(response.data.Value);
                $timeout(function () {
                    $scope.gridApi.saveState.restore($scope, $scope.state);
                }, 1000);
            }
        });
    }
   
    function bindGrid() {
        var deleteButton = '<span  ng-if="grid.appScope.showLink(\'ContactData.DeleteBtn\')"  class="fa fa-trash" style="cursor:pointer;padding-left:7px;color:green;"  ng-click ="grid.appScope.deleteRow(row,col)" title="Delete Customer"></span><span  ng-if="!grid.appScope.showLink(\'ContactData.DeleteBtn\')"  class="fa fa-ban" style="cursor:pointer;padding-left:7px;color:red;"   title="Insuffient Rights"></span>';
        var editButton = '<span  ng-if="grid.appScope.showLink(\'ContactData.EditBtn\')"class="fa fa-pencil-square-o" style="cursor:pointer;padding-left:7px;color:green;" ng-click ="grid.appScope.editRow(row,col)" title="Edit Customer" ></span><span  ng-if="!grid.appScope.showLink(\'ContactData.EditBtn\')"  class="fa fa-ban" style="cursor:pointer;padding-left:7px;color:red;"   title="Insuffient Rights"></span>';
        var phoneMasking = '<input ng-model="row.entity.phone" angular-mask="(000)000-0000" style="border:none" readonly></input>';
        var mobileMasking = '<input ng-model="row.entity.mobile" angular-mask="(000)000-0000" style="border:none" readonly></input>';
        $scope.gridOptions = {
            enableRowSelection: true,
            enableRowHeaderSelection: false,
            enableCellEditOnFocus: true,
            enableColumnResizing: true,
            enableFiltering: false,
            enableGridMenu: true,
            showGridFooter: true,
            showColumnFooter: true,
            fastWatch: true,
            rowTemplate: rowTemplate(),
            exporterMenuPdf: false,
            exporterMenuAllData: $scope.showLink('ContactData.ExportLink'),
            exporterMenuVisibleData: $scope.showLink('ContactData.ExportLink'),
            paginationPageSizes: [10, 20, 50],
            paginationPageSize: 10,
            columnDefs: [
              {
                  field: 'name', displayName: 'Customer Name', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'title', displayName: 'Title', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'email', displayName: 'Email', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'phone', cellTemplate: phoneMasking, displayName: 'Phone', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'mobile', cellTemplate: mobileMasking, displayName: 'Mobile', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'address', displayName: 'Address', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'city', displayName: 'City', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'district', displayName: 'State', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'pinCode', displayName: 'Zip Code', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
              },
              {
                  field: 'facebookUrl', displayName: 'facebook url', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  cellTooltip: tooltipData
              },
              {
                  field: 'linkedinUrl', displayName: 'Linkedin Url', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  cellTooltip: tooltipData
              },
              {
                  field: 'twitter', displayName: 'Twitter Url', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  cellTooltip: tooltipData
              },
              {
                  field: 'pocId', displayName: 'Rigil POC', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  cellTooltip: tooltipData
              },
              {
                  field: 'relationShip', displayName: 'Relationship', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filter: {
                      noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.relationship,
                  }, cellTooltip: tooltipData
              },
              {
                  field: 'department', displayName: 'Department', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filter: {
                      noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.departmentList,
                  }, cellTooltip: tooltipData
              },
              {
                  field: 'agency', displayName: 'Agency', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filter: {
                      noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.agencyList,
                  }, cellTooltip: tooltipData
              },
              {
                  field: 'bidsStr', displayName: 'Bids', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filter: {
                      noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.bidList,
                  }, cellTooltip: tooltipData
              },
              {
                  field: 'capabilitiesStr', displayName: 'Capabilities', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filter: {
                      noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.capabilityList,
                  }, cellTooltip: tooltipData
              },
              {
                  field: 'contractsStr', displayName: 'Contracts', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filter: {
                      noTerm: true, type: uiGridConstants.filter.SELECT, selectOptions: $scope.contractList,
                  }, cellTooltip: tooltipData
              },
              //------ RR-517 Start ---------------
               {
                   field: 'description', displayName: 'Description', minWidth: 100, enableGrouping: false, enableCellEdit: false, cellTooltip: tooltipData
               },
               //------ RR-517 End ---------------
              {
                  field: 'createDate', displayName: 'Create Date', cellFilter: 'date', minWidth: 100, enableGrouping: false, enableCellEdit: false,
                  filters: [{ condition: checkStart }, {
                      condition: checkEnd
                  }],
                  filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" customer-date-picker type="text" first-date="active" last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" customer-date-picker type="text" first-date="deactive" last-date="active" ng-model="col.filters[1].term" placeholder="To" ng-class="{textColor:grid.appScope.endDateTextFlag}"/></div>'
              },
              {
                  name: 'edit', displayName: 'Edit', visible: false, minWidth: 100, cellTemplate: editButton, enableFiltering: false, enableGrouping: false, enableSorting: false, enablePinning: true, enableHiding: false,
              },
              {
                  name: 'delete', displayName: 'Delete', visible: false, minWidth: 100, cellTemplate: deleteButton, enableFiltering: false, enableGrouping: false, enableSorting: false, enablePinning: false, enableHiding: false
              }
            ],

            onRegisterApi: function onRegisterApi(gridApi) {
                $scope.gridApi = gridApi;
                $scope.gridApi.grid.registerRowsProcessor($scope.singleFilter, 200);
            }
        };

        $scope.gridOptions.columnDefs[20].visible = $scope.showLink("ContactData.EditBtn");
        $scope.gridOptions.columnDefs[21].visible = $scope.showLink("ContactData.DeleteBtn");
    }

    function tooltipData(row, col) {
        return row.entity[col.field];
    }

    function rowTemplate() {
        return '<div ng-dblclick="grid.appScope.rowDblClick(row)" >' +
                     '  <div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div>' +
                     '</div>';
    }

    $scope.rowDblClick = function (row) {
        //$scope.selectedTopic(row.entity.Id, 'V', row.entity.Id);
    };

    $scope.editRow = function (row, col) {
        $scope.custId = row.entity.id;
        $scope.mandatory.check = false;
        customerService.getCustomer(row.entity.id).then(function (response) {
            $scope.customerData = new customerModel(response.data);
            //------ RR-517 Start ---------------
            if (($scope.customerData.title == "" || $scope.customerData.title == null) && $scope.showLink('ContactData.MandatoryCheck'))
            {
                $scope.mandatory.check = true;
            }
            //------ RR-517 End ---------------
            $scope.getAgency();
            $scope.multiContractList = [];
            $scope.multiBidList = [];
            $scope.multiCapabilityList = [];
            $scope.phoneList = [];
            $scope.relationList = [];
            getContractKey($scope.customerData.contracts);
            getBidKey($scope.customerData.bids);
            getCapabilityKey($scope.customerData.capabilities);
            getOtherPhones($scope.customerData.otherPhones);
            $scope.relationList = $scope.customerData.pocRelation;
            $scope.currentRecordId = $scope.customerData.id;
            $scope.Step1.active = true;
            $scope.Step2.active = false;
        });
        $scope.toggleShowList();
    }
    function getContractKey(obj) {
        angular.forEach(obj, function (value, index) {
            $scope.multiContractList.push({
                Key: parseInt(value)
            })
        });
    }
    function getBidKey(obj) {
        angular.forEach(obj, function (value, index) {
            $scope.multiBidList.push({
                Key: parseInt(value)
            })
        });
    }
    function getCapabilityKey(obj) {
        angular.forEach(obj, function (value, index) {
            $scope.multiCapabilityList.push({
                Key: parseInt(value)
            })
        });
    }
    function getOtherPhones(obj) {
        if (obj != null && obj != "") {
            $scope.phonearray = obj.split(',');
            angular.forEach($scope.phonearray, function (value, index) {
                $scope.phoneList.push({
                    Phone: value
                })
            });
        }

    }

    $scope.deleteRow = function (row, col) {
        var ans = confirm("Are you sure you want to delete ?");
        if (ans) {
            customerService.delData(row.entity.id).then(function (response) {
                toaster.pop('success', 'Success', "Customer Record has been deleted successfully!");
                getData();
            });
        }
    }

    $scope.globalSearch = function () {
        $scope.gridApi.grid.refresh();
    };

    $scope.singleFilter = function (renderableRows) {
        var textValue = '';
        var findval = '';
        var searchedval = '';
        textValue = $("#globalSearchId").val();
        if (textValue)
            findval = textValue.toLowerCase();
        var matcher = new RegExp(findval);
        renderableRows.forEach(function (row) {
            var match = false;
            ['name', 'title', 'email', 'phone', 'mobile', 'address', 'city', 'district', 'pinCode', 'facebookUrl', 'linkedinUrl', 'twitter', 'pocId', 'relationShip', 'department', 'agency', 'bidsStr', 'capabilitiesStr', 'contractsStr', 'createDate'].forEach(function (field) {
                var value = row.entity[field];
                if (value) {
                    if (value.toString().toLowerCase().match(matcher)) {
                        match = true;
                    }
                }
            });
            if (!match) {
                row.visible = false;
            }
        });
        return renderableRows;
    };

    $scope.toggleFiltering = function () {
        $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    };

    $scope.saveStateData = function () {
        $scope.state = $scope.gridApi.saveState.save();
        $scope.savedState.Id = 21;
        arrangeData();
        $scope.savedState.Value = JSON.stringify($scope.state);
        customerService.putDataGeneralConfigs($scope.savedState).then(function (response) {
            toaster.pop("success", "Success", "Grid setting saved successfully!")
        });
    };

    function arrangeData() {
        if ($scope.state.columns && $scope.state.columns.length > 0) {
            _.each($scope.state.columns, function (obj) {
                if (obj.filters && obj.filters.length > 0) {
                    if (obj.filters[0].selectOptions)
                        delete obj.filters[0].selectOptions;
                }
            });
        }
    }

    $scope.restoreState = function () {
        $scope.gridApi.saveState.restore($scope, $scope.state);
    };

    $scope.defaultState = function () {
        customerService.getDataGeneralConfigs($scope.savedState).then(function (response) {
            $scope.savedState = response.data;
            if (response.data.Value != null) {
                $scope.state = JSON.parse(response.data.Value);
                $scope.gridApi.saveState.restore($scope, $scope.state);
            }
        });
    };

    function checkStart(term, value, row, column) {
        $scope.endDateTextFlag = false;
        var duration = '';
        term = term.replace(/\\/g, "")
        $scope.startDate = moment(term);
        if ($scope.endDate) {
            var duration = $scope.endDate.diff($scope.startDate, 'days');
            if (duration < 0)
                $scope.endDateTextFlag = true;
        }
        var now = moment(value);
        if (term) {
            if (moment(term).isAfter(now, 'day')) return false;;
        }
        return true;
    }

    function checkEnd(term, value, row, column) {

        $scope.endDateTextFlag = false;
        term = term.replace(/\\/g, "")
        $scope.endDate = moment(term);
        var duration = $scope.endDate.diff($scope.startDate, 'days');
        var now = moment(value);
        if (duration < 0)
            $scope.endDateTextFlag = true;
        if (term) {
            if (moment(term).isBefore(now, 'day')) return false;;
        }
        return true;
    }

    $scope.$on('clearDate', function (event, args) {
        if (args) {
            if (args.lastDate == 'active') {
                $scope.endDate = '';
            } else if (args.firstDate == 'active') {
                $scope.startDate = '';
            }
        }
        if ($scope.endDateTextFlag) {
            $scope.endDateTextFlag = false;
        }
    });

    $scope.changeZipCode = function () {
        if ($("#zipid1").val().length == 5) {
            customerService.getCityState($scope.customerData.pinCode).then(function (response) {
                if (response.status == 200) {
                    if (response.data.zipInfo != null) {
                        $scope.customerData.city = response.data.zipInfo.City;
                        $scope.customerData.district = response.data.zipInfo.Statename;
                    } else {
                        $scope.customerData.city = "";
                        $scope.customerData.district = "";
                        toaster.pop('error', 'Error', "Enter a valid zipcode");
                        $scope.customerData.pinCode = "";
                    }
                } else {
                    $scope.customerData.city = "";
                    $scope.customerData.district = "";
                }
            })
        }
        else {
            $scope.customerData.city = "";
            $scope.customerData.district = "";
        }
    }
    $scope.multiselectSetting = {
        scrollableHeight: '200px', scrollable: true, enableSearch: true, searchField: 'Value', showEnableSearchButton: true, styleActive: true, selectedToTop: true
    };
    $scope.contractTexts = {
        buttonDefaultText: 'Select Contract(s)'
    };
    $scope.bidTexts = {
        buttonDefaultText: 'Select Bid(s)'
    };
    $scope.capabilityTexts = {
        buttonDefaultText: 'Select Capability(s)'
    };
    $scope.removeContract = function (id) {
        $scope.multiContractList1 = [];
        angular.copy($scope.multiContractList, $scope.multiContractList1);
        $scope.multiContractList = [];
        angular.forEach($scope.multiContractList1, function (value, index) {
            if (value.Key != id) {
                $scope.multiContractList.push({
                    Key: parseInt(value.Key)
                })
            }
        });
    }

    $scope.removeBid = function (id) {
        $scope.multiBidList1 = [];
        angular.copy($scope.multiBidList, $scope.multiBidList1);
        $scope.multiBidList = [];
        angular.forEach($scope.multiBidList1, function (value, index) {
            if (value.Key != id) {
                $scope.multiBidList.push({
                    Key: parseInt(value.Key)
                })
            }
        });
    }

    $scope.removeCapability = function (id) {
        $scope.multiCapabilityList1 = [];
        angular.copy($scope.multiCapabilityList, $scope.multiCapabilityList1);
        $scope.multiCapabilityList = [];
        angular.forEach($scope.multiCapabilityList1, function (value, index) {
            if (value.Key != id) {
                $scope.multiCapabilityList.push({
                    Key: parseInt(value.Key)
                })
            }
        });
    }

    $scope.linkModelFunc = function (url) {
        $window.open(url);
    }

    $scope.addPhone = function () {
        $scope.phone = { Phone: "" };

        $scope.completePhoneList = [];
        $scope.completePhoneList.push({ Phone: $scope.customerData.phone });
        angular.forEach($scope.phoneList, function (value1, index) {
            $scope.completePhoneList.push({ Phone: value1.Phone });
        });
        var modalInstance = $modal.open({
            templateUrl: 'AddPhone.html',
            controller: 'modalInstancePhoneCtrl',
            backdrop: 'static',
            sixe: 'sm',
            scope: $scope,
            resolve: {
                item: function () {
                    return $scope.phone;
                },
                value: function () {
                    return "";
                },
                wholelist: function () {
                    return $scope.completePhoneList;
                }
            }
        });
        modalInstance.result.then(function (value) {
            if (value != "") {
                $scope.phoneList.push({ Phone: value });
            }

        });
    }
    $scope.editPhone = function (number, obj) {
        $scope.completePhoneList = [];
        $scope.completePhoneList.push({ Phone: $scope.customerData.phone });
        angular.forEach($scope.phoneList, function (value1, index) {
            if (value1.Phone != number) {
                $scope.completePhoneList.push({ Phone: value1.Phone });
            }
        });
        var modalInstance = $modal.open({
            templateUrl: 'AddPhone.html',
            controller: 'modalInstancePhoneCtrl',
            backdrop: 'static',
            sixe: 'sm',
            scope: $scope,
            resolve: {
                item: function () {
                    return obj;
                },
                value: function () {
                    return number;
                },
                wholelist: function () {
                    return $scope.completePhoneList;
                }
            }
        });
        modalInstance.result.then(function (value) {
            if (value != "") {
                angular.forEach($scope.phoneList, function (value1, index) {
                    if (value1.Phone == number) {
                        value1.Phone = value;
                    }
                });
            }
        });
    }
    $scope.removePhone = function (obj) {
        var ans = confirm("Are you sure you want to delete ?");
        if (ans) {
            angular.forEach($scope.phoneList, function (value, index) {
                if (value.Phone == obj.Phone || value.Phone == obj) {
                    $scope.phoneList.splice(index, 1);
                }
            })

        }
    }


    $scope.addRelationships = function () {
        $scope.completeRelationList = [];
        if (($scope.customerData.pocId != "" || $scope.customerData.pocId != null) && $scope.customerData.relationShipId != 0) {
            $scope.completeRelationList.push({ POC: $scope.customerData.pocId, Relation: $scope.customerData.relationShipId });
        }
        angular.forEach($scope.relationList, function (value1, index) {
            $scope.completeRelationList.push(value1);
        });
        var modalInstance = $modal.open({
            templateUrl: 'AddRelation.html',
            controller: 'modalInstanceRelationCtrl',
            backdrop: 'static',
            sixe: 'sm',
            scope: $scope,
            resolve: {
                userlist: function () {
                    return $scope.userListDropDown;
                },
                relationlist: function () {
                    return $scope.relationshipDropDown;
                },
                poc: function () {
                    return "";
                },
                relationId: function () {
                    return 0;
                },
                wholelist: function () {
                    return $scope.completeRelationList;
                }
            }
        });
        modalInstance.result.then(function (obj) {
            if (obj.POC != "" && obj.Relation != 0) {
                $scope.relationList.push(obj);
            }

        });
    }

    $scope.editRelationship = function (poc, relation) {
        $scope.completeRelationList = [];
        if (($scope.customerData.pocId != "" || $scope.customerData.pocId != null) && $scope.customerData.relationShipId != 0) {
            $scope.completeRelationList.push({ POC: $scope.customerData.pocId, Relation: $scope.customerData.relationShipId });
        }
        angular.forEach($scope.relationList, function (value1, index) {
            if (value1.POC != poc && value1.Relation != relation) { $scope.completeRelationList.push(value1); }
        });
        var modalInstance = $modal.open({
            templateUrl: 'AddRelation.html',
            controller: 'modalInstanceRelationCtrl',
            backdrop: 'static',
            sixe: 'sm',
            scope: $scope,
            resolve: {
                userlist: function () {
                    return $scope.userListDropDown;
                },
                relationlist: function () {
                    return $scope.relationshipDropDown;
                },
                poc: function () {
                    return poc;
                },
                relationId: function () {
                    return relation;
                },
                wholelist: function () {
                    return $scope.completeRelationList;
                }
            }
        });
        modalInstance.result.then(function (obj) {
            if (obj.POC != "" && obj.Relation != 0) {
                angular.forEach($scope.relationList, function (value1, index) {
                    if (value1.POC == poc && value1.Relation == relation) {
                        value1.POC = obj.POC;
                        value1.Relation = obj.Relation;
                    }
                });
            }
        });
    }

    $scope.removeRelationship = function (obj) {
        var ans = confirm("Are you sure you want to delete ?");
        if (ans) {
            angular.forEach($scope.relationList, function (value1, index) {
                if (value1.POC == obj.POC && value1.Relation == obj.Relation) {
                    $scope.relationList.splice(index, 1);
                }
            })

        }
    }
    //$scope.callDirective = function () {
    //    $scope.dirFlag = true;
    //}
    //////////////////////  History Data//////////////////////////////////////////////////////////////////////
    var customerHistoryObj = {};
    $scope.customerHistoryData = new customerHistoryModel(customerHistoryObj);
    $scope.customerHistory = [];


    $scope.maxSize = 10;
    $scope.HcurrentPage = 0;
    $scope.LcurrentPage = 0;
    $scope.Hstartindex = 0;
    $scope.HpageChanged = function (pageno) {
        $scope.Hstartindex = (pageno * $scope.maxSize) - $scope.maxSize;
    };

    $scope.getHistory = function () {
        if ($scope.currentRecordId != 0) {
            customerService.getCustomerHistory($scope.currentRecordId).then(function (response) {
                if (response.data && response.data.length > 0) {
                    var customerHistoryData = new customerHistoryModelList(response.data);
                    $scope.customerHistory = customerHistoryData.customerHistory;
                    $scope.HbidsCount = $scope.customerHistory.length;
                }
                else {
                    $scope.customerHistory = [];
                }
            });
        }
    }

    //////////////////////History Data End////////////////////////////////////////////////////////////////
}]);

