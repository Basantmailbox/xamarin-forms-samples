﻿'use strict';
app.controller('modalInstancePhoneCtrl', ['$scope', '$http', '$modalInstance', '$controller', 'toaster', '$location', 'item', 'value', 'wholelist',
    function ($scope, $http, $modalInstance, $controller, toaster, location, item, value, wholelist) {
    $scope.phone = value;
    $scope.completedata = [];
    $scope.completedata = wholelist;
    $scope.obj = item;
    $scope.toggleAttachModal = function () {
        $modalInstance.close("");
    }
    $scope.savePhone = function () {
            var find = _.find($scope.completedata, function (obj) {
                return (obj.Phone == $scope.phone);
            });
            if (_.isUndefined(find)) {
                $modalInstance.close($scope.phone);
            }
            else
            {
                $scope.phone = "";
                toaster.pop('error', 'Duplicate Data', "Phone already exists!");
            }
    }
}]);