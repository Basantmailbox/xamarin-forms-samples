﻿'use strict';
app.controller('customerHistoryCtrl', ['$scope', '$http', '$modal', 'customerService', 'customerHistoryModelList', 'customerHistoryModel', 'uiGridConstants', '$timeout', 'toaster', '$window','$interval',
function ($scope, $http, $modal, customerService, customerHistoryModelList, customerHistoryModel, uiGridConstants, $timeout, toaster, $window, $interval) {
    var customerObj = {};
    $scope.customerData = new customerHistoryModel(customerObj);

    //----------ui-grid------------------------------
    bindGrid();
    getCustomerHistory();

    function getCustomerHistory() {
        customerService.getCustomerHistory($scope.id).then(function (response) {
            if (response.data && response.data.length > 0) {
                var customerData = new customerHistoryModelList(response.data);
                $scope.gridOptions.data = customerData.customerHistory;
            }
            else {
                $scope.gridOptions.data = [];
            }
        });
    }

    function bindGrid() {
        $scope.gridOptions = {
            enableRowSelection: true,
            enableRowHeaderSelection: false,
            enableCellEditOnFocus: true,
            enableColumnResizing: false,
            enableFiltering: false,
            enableGridMenu: true,
            showGridFooter: true,
            showColumnFooter: true,
            fastWatch: true,
            exporterMenuPdf: false,
            paginationPageSizes: [10, 20, 50],
            paginationPageSize: 10,
            columnDefs: [
              {
                  field: 'changeDate', displayName: 'Change Date', width: '20%', cellFilter: 'date', enableGrouping: false, enableCellEdit: false,
                  filters: [{ condition: checkStart }, {
                      condition: checkEnd
                  }],
                  filterHeaderTemplate: '<div class="ui-grid-filter-container"><input style="display:inline; width:100%"  class="ui-grid-filter-input" customer-date-picker type="text" first-date="active" last-date="deactive" ng-model="col.filters[0].term" placeholder="From"/><input style="display:inline; width:100%" class="ui-grid-filter-input" customer-date-picker type="text" first-date="deactive" last-date="active" ng-model="col.filters[1].term" placeholder="To" ng-class="{textColor:grid.appScope.endDateTextFlag}"/></div>'
              },
              {
                  field: 'userId', displayName: 'By User', width: '15%', enableGrouping: false, enableCellEdit: false
              },
              {
                  field: 'changeFieldName', displayName: 'Attribute', width: '15%', enableGrouping: false, enableCellEdit: false
              },
              {
                  field: 'oldValue', displayName: 'Old Value', width: '15%', enableGrouping: false, enableCellEdit: false
              },
              {
                  field: 'newValue', displayName: 'New Value', width: '15%', enableGrouping: false, enableCellEdit: false
              },
              {
                  field: 'userAction', displayName: 'Action', width: '20%', enableGrouping: false, enableCellEdit: false
              },
            ],

            onRegisterApi: function onRegisterApi(gridApi) {
                $scope.gridApi = gridApi;
                $scope.gridApi.grid.registerRowsProcessor($scope.singleFilter, 200);
            }
        };
    }

    $scope.globalSearch = function () {
        $scope.gridApi.grid.refresh();
    };

    $scope.singleFilter = function (renderableRows) {
        var textValue = '';
        var findval = '';
        var searchedval = '';
        textValue = $("#globalSearchId").val();
        if (textValue)
            findval = textValue.toLowerCase();
        var matcher = new RegExp(findval);
        renderableRows.forEach(function (row) {
            var match = false;
            ['changeDate', 'userId', 'changeFieldName', 'oldValue', 'newValue', 'userAction'].forEach(function (field) {
                var value = row.entity[field];
                if (value) {
                    if (value.toString().toLowerCase().match(matcher)) {
                        match = true;
                    }
                }
            });
            if (!match) {
                row.visible = false;
            }
        });
        return renderableRows;
    };

    function checkStart(term, value, row, column) {
        $scope.endDateTextFlag = false;
        var duration = '';
        term = term.replace(/\\/g, "")
        $scope.startDate = moment(term);
        if ($scope.endDate) {
            var duration = $scope.endDate.diff($scope.startDate, 'days');
            if (duration < 0)
                $scope.endDateTextFlag = true;
        }
        var now = moment(value);
        if (term) {
            if (moment(term).isAfter(now, 'day')) return false;;
        }
        return true;
    }

    function checkEnd(term, value, row, column) {

        $scope.endDateTextFlag = false;
        term = term.replace(/\\/g, "")
        $scope.endDate = moment(term);
        var duration = $scope.endDate.diff($scope.startDate, 'days');
        var now = moment(value);
        if (duration < 0)
            $scope.endDateTextFlag = true;
        if (term) {
            if (moment(term).isBefore(now, 'day')) return false;;
        }
        return true;
    }

    $scope.$on('clearDate', function (event, args) {
        if (args) {
            if (args.lastDate == 'active') {
                $scope.endDate = '';
            } else if (args.firstDate == 'active') {
                $scope.startDate = '';
            }
        }
        if ($scope.endDateTextFlag) {
            $scope.endDateTextFlag = false;
        }
    });

    $scope.toggleFiltering = function () {
        $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
        $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
    };
    $interval(function () {
        $scope.gridApi.core.handleWindowResize();
    }, 1000);
}]);

