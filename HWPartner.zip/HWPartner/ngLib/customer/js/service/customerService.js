﻿app.factory('customerService', [
    '$http',
    function ($http) {
        return {

            getAllUsersList: function () {
                return $http.get('home/GetAllUsersList').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            getRelationship: function () {
                return $http.get('home/GetRelationship').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            getDepartments: function () {
                return $http.get('home/GetDepartments').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            getAgencies: function (id) {
                return $http.get('home/GetAgencies?departmentId=' + id).
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            getAllCapabilities: function () {
                return $http.get('home/GetAllCapabilities').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            getAllBids: function () {
                return $http.get('home/GetAllBids').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            getAllContracts: function () {
                return $http.get('home/GetAllContracts').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },

            getData: function () {
                return $http.get('api/Customer').
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },

            getCustomer: function (id) {
                return $http.get('api/Customer?id=' + id).
                success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    // console.log("error");
                });
            },
            postData: function (data) {
                return $http.post('api/Customer', data).
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
            putData: function (id, data) {
                return $http.put('api/Customer?id=' + id, data).
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
            putDataGeneralConfigs: function (data) {
                return $http.put('/api/GeneralConfigs/21', data).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            delData: function (id) {
                return $http.delete('api/Customer?id=' + id).
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
            getDataGeneralConfigs: function () {
                return $http.get('/api/GeneralConfigs/20').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getGeneralConf: function () {
                return $http.get('/api/GeneralConfigs/21').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getCityState: function (pram) {
                return $http.get('/Home/GetCitynState?zipcode=' + pram).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getCustomerHistory: function (id) {
                return $http.get('/api/Customer_History?id=' + id).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            }
        }
    }
]);