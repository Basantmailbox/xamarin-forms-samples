﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace WBP.BusinessLogic
{
    public class BaseRepository : IDisposable
    {
        protected IDbConnection _connectionSQL;
        public BaseRepository()
        {
            //string connectionString = "Data Source=tcp:hwdevelopment.database.windows.net,1433; Integrated Security=false;Initial Catalog=HW_developer; uid=hwdevelopment; Password=hindu!@#123;";
            string connectionString = "Data Source=tcp:ddszsqnoe5.database.secure.windows.net,1433; Integrated Security=false;Initial Catalog=HW; uid=HindustanWellness@ddszsqnoe5; Password= dbpa$$w0rd#2015!;";
            _connectionSQL = new SqlConnection(connectionString);
        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
