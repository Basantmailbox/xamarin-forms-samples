﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WBP.BusinessLogic.IRepository
{
   public interface IUserRepository
    {
    }
}
