﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WBP.Shared.DTOs
{
   public class BranchDto
    {
        public int id { get; set; }
        public string wano { get; set; }
        public string company_name { get; set; }
        public string company_owner_name { get; set; }
    }
}
