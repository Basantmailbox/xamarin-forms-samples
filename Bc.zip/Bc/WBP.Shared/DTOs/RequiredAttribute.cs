﻿using System;

namespace WBP.Shared.DTOs
{
    internal class RequiredAttribute : Attribute
    {
    }
}