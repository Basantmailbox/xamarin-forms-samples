﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WBP.Shared.Entities
{
   public class User
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string wano { get; set; }
        public string company_name { get; set; }
        public string company_email { get; set; }
        public string company_mobileno { get; set; }
        public string company_owner_name { get; set; }
        public string company_country_name { get; set; }
        public string company_wa_dp { get; set; }
        public int company_wa_dp_status { get; set; }
        public int BranchId { get; set; }
        public bool IsActive { get; set; }
        //public string Token { get; set; }
    }
}
