﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WBP.Shared.DTOs;
using WBP.Shared.Entities;

namespace WBP.API.JwtHelper
{
    public static class ExtensionMethods
    {
        public static IEnumerable<UserDto> WithoutPasswords(this IEnumerable<UserDto> users)
        {
            return users.Select(x => x.WithoutPassword());
        }

        public static UserDto WithoutPassword(this UserDto user)
        {
            user.password = null;
            return user;
        }
    }
}
