﻿using System;

namespace WBP.BusinessLogic
{
    public class Class1
    {
    }
}
