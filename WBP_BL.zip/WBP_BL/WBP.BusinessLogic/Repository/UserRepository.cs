﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WBP.BusinessLogic.IRepository;
using WBP.Shared.DTOs;

namespace WBP.BusinessLogic.Repository
{
   public class UserRepository : BaseRepository, IUserRepository
    {

        public UserDto GetAuthenticate(string userName,string password)
        {
            UserDto resultData = new UserDto();
            try
            {
                string cmdStr = "Select Id,username,password,wano,company_name,BranchId,IsActive,* FROM Users Where(username = '" + userName + "' OR wano = '"+ userName + "') AND password = '"+ password + "';";
                resultData = SqlMapper.Query<UserDto>(_connectionSQL, cmdStr).FirstOrDefault();
                return resultData;
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                return resultData;
            }
        }

        public List<BranchDto> GetMyBranches(int mainBranachId)
        {
            List<BranchDto> resultData = new List<BranchDto>();
            try
            {
                string cmdStr = "Select Id,username,wano,company_name FROM Users Where (id="+ mainBranachId + " OR BranchId="+ mainBranachId + ") AND IsActive=1;";
                resultData = SqlMapper.Query<BranchDto>(_connectionSQL, cmdStr).ToList();
                return resultData;
            }
            catch (Exception ex)
            {
                string err = ex.Message;
                return resultData;
            }
        }


        //public OTPValidateDto OTPSet(string mobileNo, string otp)
        //{
        //    List<OTPValidateDto> oTPValidateDtos = new List<OTPValidateDto>();
        //    try
        //    {
        //        DynamicParameters parameters = new DynamicParameters();
        //        parameters.Add("@mobileNo", mobileNo);
        //        parameters.Add("@OTP", otp);
        //        oTPValidateDtos = SqlMapper.Query<OTPValidateDto>(_connectionSQL, "spWeb_OTPSet", parameters, commandType: StoredProcedure).ToList();
        //        return oTPValidateDtos.FirstOrDefault();
        //    }
        //    catch (Exception ex)
        //    {
        //        string err = ex.Message;
        //        return oTPValidateDtos.FirstOrDefault();
        //    }
        //}

        //public CustomerDto OTPValidate(string mobileNo, string otp)
        //{
        //    List<CustomerDto> oTPValidateDtos = new List<CustomerDto>();
        //    try
        //    {
        //        DynamicParameters parameters = new DynamicParameters();
        //        parameters.Add("@MobileNo", mobileNo);
        //        parameters.Add("@OTP", otp);
        //        oTPValidateDtos = SqlMapper.Query<CustomerDto>(_connectionSQL, "spWeb_OTPValidate", parameters, commandType: StoredProcedure).ToList();
        //        return oTPValidateDtos.FirstOrDefault();
        //    }
        //    catch (Exception ex)
        //    {
        //        string error = ex.Message;
        //        return oTPValidateDtos.FirstOrDefault();
        //    }
        //}

        //public CustomerDto GetByMobileNo(string mobileNo, bool isMainMember)
        //{
        //    List<CustomerDto> oTPValidateDtos = new List<CustomerDto>();
        //    try
        //    {
        //        string cmdStr = "SELECT aca_id AS ACAId, ca_id As CustomerId, ca_fname AS FirstName,ca_sname As LastName,ca_gender AS Gender,ca_mob As MobileNo,ca_email As EmailId,ca_dob As DOB,relation AS RelationShip,ca_enable AS IsActive FROM App_customer_account where ca_mob='" + mobileNo + "'";

        //        if (isMainMember)
        //        {
        //            cmdStr = cmdStr + " AND ca_isaffiliate='M'";
        //        }
        //        else
        //        {
        //            cmdStr = cmdStr + " AND ca_isaffiliate!='M'";
        //        }
        //        oTPValidateDtos = SqlMapper.Query<CustomerDto>(_connectionSQL, cmdStr).ToList();
        //        return oTPValidateDtos.FirstOrDefault();
        //    }
        //    catch (Exception ex)
        //    {
        //        string error = ex.Message;
        //        return oTPValidateDtos.FirstOrDefault();
        //    }
        //}
    }
}
