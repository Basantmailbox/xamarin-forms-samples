﻿using System;
using System.Collections.Generic;
using System.Text;
using WBP.Shared.DTOs;

namespace WBP.BusinessLogic.IRepository
{
   public interface IUserRepository
    {
        UserDto GetAuthenticate(string userName, string password);
        List<BranchDto> GetMyBranches(int mainBranachId);
    }
}
