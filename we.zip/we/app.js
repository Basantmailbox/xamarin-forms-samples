'use strict';


angular.module('app', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ngStorage',
    'ui.router',
    'ui.bootstrap',
    'ui.load',
    'ui.jq',
    'ui.validate',
    'oc.lazyLoad',
    'pascalprecht.translate',

    'ui.grid',
    'ui.grid.edit',
    'ui.grid.pagination',
    'ui.grid.selection',
    'ui.grid.autoResize',
    'ui.grid.exporter',
    'ui.grid.moveColumns',
    'ui.grid.saveState',
    'ui.grid.pinning',
    'ui.grid.resizeColumns',
    'ui.grid.grouping',
    'toaster',

    'as.sortable',

    'gantt',
    'gantt.sortable',
    'gantt.movable',
    'gantt.drawtask',
    'gantt.tooltips',
    'gantt.bounds',
    'gantt.progress',
    'gantt.table',
    'gantt.tree',
    'gantt.groups',
    'gantt.resizeSensor',
    'gantt.overlap',

    'ui.calendar',

    'googlechart',

    'angular-timeline',

    'angularMask',

    'ui.utils.masks',

    'angular.filter',
        'dndLists',
     'ngPatternRestrict',
      'ngMessages',
      'angularjs-dropdown-multiselect',
      'ui.bootstrap.modal',
      'angularjs-userdropdown-multiselect',
      'angularjs-customerdropdown-multiselect',
      'daterangepicker',
      'ngFileSaver',
      'ui.select',
       '720kb.tooltips',
       'color.picker'//color Picker
      //'ae-datetimepicker'
])
    
.run(['$anchorScroll', function ($anchorScroll) {
    $anchorScroll.yOffset = 200;   // always scroll by 150 extra pixels

}]);

