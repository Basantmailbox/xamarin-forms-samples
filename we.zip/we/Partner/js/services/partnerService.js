﻿app.factory('partnerService', [
    '$http',
    function ($http) {
        return {
            getAllPartnersList: function () {
                return $http.get('/api/Partner').success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            postData: function (data) {
                return $http.post('/api/Partner', data).success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            getPartnerDetails: function (id) {
                return $http.get('/api/Partner/GetPartnerDetails/' + id).success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            putData: function (id, data) {
                return $http.put('/api/Partner?Id=' + id, data).success(function (data, status, headers) {
                    //console.log("success" + data);
                }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            putGeneralConfigs: function (data) {
                return $http.put('/api/GeneralConfigs/27', data).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      //console.log("error");
                  });
            },
            getDefaultGeneralConfigs: function () {
                return $http.get('/api/GeneralConfigs/26').
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      //console.log("error");
                  });
            },
            getStoredGeneralConf: function () {
                return $http.get('/api/GeneralConfigs/27').
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      // console.log("error");
                  });
            },
            delelePartner: function (id) {
                return $http.delete('api/Partner?id=' + id).
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
            partnerType: function () {
                return $http.get('/Home/GetPartnerType').
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
            getCoreCompetencies: function () {
                return $http.get('/Home/GetCoreCompetencyDropdown').
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      //console.log("error");
                  });
            },
            getPartnerByDuns: function (duns, bidId) {
                return $http.get('/api/Partner/GetPartnerByDuns/' + duns + '/' + bidId).
                  success(function (data, status, headers) {
                      //console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      //console.log("error");
                  });
            },
            getPartnerHistoryData: function () {
                return $http.get('/api/Partner_History').
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      // console.log("error");
                  });
            },
            getBidByPOC: function (partnerContactId) {
                return $http.get('/api/Bids/GetByPOC/' + partnerContactId).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            getBidByPartner: function (partnerId) {
                return $http.get('/api/Bids/GetByPartner/' + partnerId).
                  success(function (data, status, headers) {
                      console.log("success" + data);
                  }).
                  error(function (data, status, headers) {
                      console.log("error");
                  });
            },
            delelePOC: function (pid, pcid) {
                return $http.delete("api/PartnerContact?pid=" + pid + "&pcid=" + pcid).
               success(function (data, status, headers) {
                   //console.log("success" + data);
               }).
               error(function (data, status, headers) {
                   // console.log("error");
               });
            },
            getPOCDetailByPartner: function (partnerId) {
                return $http.get('/api/PartnerContact/GetByPartner/' + partnerId)
                    .success(function (data, status, headers) {
                        //console.log("success" + data);
                    }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            getByBid: function (bidId) {
                return $http.get('/api/Partner/GetByBid/' + bidId)
                    .success(function (data, status, headers) {
                        //console.log("success" + data);
                    }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            updateBidIds: function (pocData) {
                return $http.put('/api/PartnerContact/UpdateBidIds',pocData)
                    .success(function (data, status, headers) {
                        //console.log("success" + data);
                    }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
            updateLinkingPartnerWithBid: function (partnerId, bidId) {
                return $http.put('/api/Partner/UpdateLinkingPartnerWithBid/' + partnerId + '/' + bidId)
                    .success(function (data, status, headers) {
                        //console.log("success" + data);
                    }).
                error(function (data, status, headers) {
                    //console.log("error");
                });
            },
        }
    }
]);