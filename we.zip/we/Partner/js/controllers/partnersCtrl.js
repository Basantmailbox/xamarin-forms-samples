﻿'use strict';
//used in "App\master\Resume\tpl\app\Partials\BidTracking\PartnerSection.html"
app.filter('phonenumber', function () {
    /* 
    Format phonenumber as: c (xxx) xxx-xxxx
        or as close as possible if phonenumber length is not 10
        if c is not '1' (country code not USA), does not use country code
    */

    return function (number) {
        if (!number) { return ''; }

        number = String(number);
        // Will return formattedNumber. 
        // If phonenumber isn't longer than an area code, just show number
        var formattedNumber = number;
        var area = number.substring(0, 3);
        var front = number.substring(3, 6);
        var end = number.substring(6, 10);
        if (front) {
            formattedNumber = ("(" + area + ") " + front);
        }
        if (end) {
            formattedNumber += ("-" + end);
        }
        return formattedNumber;
    };
});

//used in bid partner
app.directive('dateTimePicker', function () {

    return {
        restrict: "A",
        require: "ngModel",
        link: function (scope, element, attrs, ngModelCtrl) {
            var parent = $(element).parent();
            var dtp = parent.datetimepicker({
                format: "MM/DD/YYYY",
                showTodayButton: true,
                minDate: "25/10/2016" ? "01/01/2012" : false

            });

            dtp.on("dp.change", function (e) {
                ngModelCtrl.$setViewValue(moment(e.date).format("MM/DD/YYYY"));
                scope.$apply();
            });
        }
    };
})

app.controller('partnersCtrl', ['$scope', '$http', '$timeout', 'partnerService', 'uiGridConstants', 'toaster', 'ActivityService', '$modal',
   function ($scope, $http, $timeout, partnerService, uiGridConstants, toaster, ActivityService, $modal) {


       //get Partners list from partner service
       $scope.partners = [];
       $scope.gridOptions = {};
       $scope.filterValue = "";
       $scope.savedState = {};
       $scope.state = {};
       $scope.isExpandedPOCSection = true;
       $scope.isExpandedPOCListSection = true;
       $scope.partnerHistoryObjs = [];
       $scope.partnerHistoryCount = 0;

       $scope.partner = {};
       $scope.isloading = true;           //for showing loader

       $scope.showList = false;            //for switching between add/edit page
       $scope.showView = false;           //for displaying report type snapshot page
       $scope.showEntry = false;          //for displaying add/edit page

       $scope.isShowPOCList = false;

       $scope.mandatory = {};
       $scope.mandatory.check = false;

       $scope.partnerTypeDrpDwn = [];
       $scope.coreCompetenciesDropDwn = [];

       $scope.PocDetails = [];
       $scope.typeObj = {
           PartnerTypeObj: {
               Id: 0,
               Name: ""
           },
       }

       bindGrid();
       $scope.partner = {
           PartnerType: { Id: 0, Name: "" },
           Id: 0,
           ServiceProviderName: "",
           Duns: "",
           Street: "",
           City: "",
           State: "",
           Country: "",
           Zip: "",
           Cage: "",
           DunsPlus4: "",
           ExpirationDate: "",
           isDelinquentFederalDebt: false,
           isKnownExclusion: false,
           isProviderActive: false,
           Phone: "",
           ServiceProviderContact: "",
           ContactPhone: "",
           ContactEmail: "",
           webSite: "",
           POC: "",
           Email: "",
           Comments: "",
           PocDetails: [],
           isEditing: false,         //editmode or not
           isAdding: false,          //editmode or not
           CoreCompetencies: ""
       }


       var pocDetailsObj = {
           Id: 0,
           POC: "",
           Email: "",
           Phone: "",
           Comments: "",
           POCTitle: "",
           MobileNo: ""
       };
       $scope.partner.PocDetails = pocDetailsObj;


       $scope.tempObjs = {
           CoreCompetencyObj: []
       };


       //Onload fetch all partners
       $scope.getPartners = function () {
           $scope.partners.partnerData = [];
           $scope.showList = true;
           partnerService.getAllPartnersList().then(function (response) {
               if (response.data && response.data.length > 0) {
                   $scope.partners = response.data;
                   $scope.gridOptions.data = $scope.partners;
                   $scope.isloading = false;
               }
               else {
                   $scope.partners = [];
               }
           });

       }

       $scope.cancelEntry = function () {
           $scope.showEntry = false; $scope.partner.isAdding = false; $scope.showList = true;
       }

       //configure grid
       function bindGrid() {
           var deleteButton = '<span ng-if="grid.appScope.showLink(\'PartnerData.DeleteBtn\')" class="fa fa-trash ui-grid-actionBtnGreen" ng-click ="grid.appScope.onClickDeletePartner(row,col)" title="Delete Partner"></span><span ng-if="!grid.appScope.showLink(\'PartnerData.DeleteBtn\')" class="fa fa-ban ui-grid-actionBtnGreen" title="Insuffient Rights"></span>';
           var editButton = '<span ng-if="grid.appScope.showLink(\'PartnerData.EditBtn\')" class="fa fa-pencil-square-o ui-grid-actionBtnGreen" ng-click ="grid.appScope.onClickEditPartner(row,col)" title="Edit Partner" ></span><span ng-if="!grid.appScope.showLink(\'PartnerData.EditBtn\')" class="fa fa-ban ui-grid-actionBtnGreen" title="Insuffient Rights"></span>';
           $scope.gridOptions = {
               enableRowSelection: false,
               enableRowHeaderSelection: false,
               enableCellEditOnFocus: true,
               enableColumnResizing: true,
               enableFiltering: false,
               enableGridMenu: true,
               showGridFooter: true,
               showColumnFooter: true,
               fastWatch: true,
               exporterMenuPdf: false,
               exporterMenuAllData: true,
               exporterMenuVisibleData: true,
               paginationPageSizes: [10, 20, 50],
               paginationPageSize: 10,
               columnDefs: [
                           { field: 'PartnerName', displayName: 'Partner Name', width: '30%', enablePinning: true, enableGrouping: false },
                           { field: 'Street', displayName: 'Street', width: '20%', enableGrouping: false },
                           { field: 'City', displayName: 'City', enableGrouping: false },
                           { field: 'State', displayName: 'State', enableGrouping: false },
                           { field: 'Country', displayName: 'Country', enableGrouping: false },
                           { field: 'Zip', displayName: 'Zip Code', enableGrouping: false },
                           { field: 'Duns', displayName: 'Duns', visible: false, enableGrouping: false },
                           { field: 'DunsPlus4', displayName: 'DunsPlus4', visible: false, enableGrouping: false },
                           { field: 'ContactPhone', displayName: 'Contact Phone', visible: false, enableGrouping: false },
                           { field: 'ContactEmail', displayName: 'Contact Email', visible: false, enableGrouping: false },
                           { field: 'WebSite', displayName: 'WebSite', visible: false, enableGrouping: false },
                           { field: 'POC', displayName: 'POC', visible: false, enableGrouping: false },
                           { field: 'Email', displayName: 'POC Email', visible: false, enableGrouping: false },
                           { field: 'PartnerType', displayName: 'Partner Type', enableGrouping: false },
                           { field: 'Comments', displayName: 'Comments', enableGrouping: false },
                           { name: 'edit', displayName: 'Edit', visible: false, minWidth: 50, cellTemplate: editButton, enableFiltering: false, enableGrouping: false, enableSorting: false, enablePinning: true, enableHiding: false },
                           { name: 'delete', displayName: 'Delete', visible: false, minWidth: 50, cellTemplate: deleteButton, enableFiltering: false, enableGrouping: false, enableSorting: false, enablePinning: false, enableHiding: false }
               ],
               onRegisterApi: function onRegisterApi(gridApi) {
                   $scope.gridApi = gridApi;
                   $scope.gridApi.grid.registerRowsProcessor($scope.singleFilter, 200);
               }
           };
           $scope.gridOptions.columnDefs[13].visible = true;
           $scope.gridOptions.columnDefs[14].visible = true;
       }


       //Onload fetch Partners Type
       $scope.getPartnerTypes = function () {
           $scope.partnerTypeDrpDwn = [];
           partnerService.partnerType().then(function (response) {
               if (response.data.types && response.data.types.length > 0) {
                   $scope.partnerTypeDrpDwn = response.data.types;
                   //  $scope.isloading = false;
               }
               else {
                   $scope.partnerTypeDrpDwn = [];
               }
           });

       }

       // RR-527 Bind CoreCometency DropDown
       $scope.getCoreCompetencies = function () {
           $scope.coreCompetenciesDropDwn = [];
           partnerService.getCoreCompetencies().then(function (response) {
               if (response.data.IsSuccess) {
                   $scope.coreCompetenciesDropDwn = response.data.responseData;
                   //  $scope.isloading = false;
               }
               else {
                   $scope.coreCompetenciesDropDwn = [];
               }
           });

       }


       function tooltipData(row, col) {
           return row.entity[col.field];
       }

       $scope.toggleFiltering = function () {
           $scope.gridOptions.enableFiltering = !$scope.gridOptions.enableFiltering;
           $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
       };


       $scope.onClickEditPartner = function (row, col) {
           $scope.partner.Id = row.entity.Id;
           partnerService.getPartnerDetails($scope.partner.Id).then(function (response) {
               if (response.status == "200" && response.data != "" && response.data.Id > 0) {
                   $scope.partner.Id = response.data.Id;
                   $scope.partner.ServiceProviderName = response.data.PartnerName;
                   $scope.partner.Duns = response.data.Duns;
                   $scope.partner.Street = response.data.Street;
                   $scope.partner.City = response.data.City;
                   $scope.partner.State = response.data.State;
                   $scope.partner.Country = response.data.Country;
                   $scope.partner.Zip = response.data.Zip;
                   $scope.partner.DunsPlus4 = response.data.DunsPlus4;
                   $scope.partner.Cage = response.data.Cage;
                   $scope.partner.Phone = response.data.Phone;
                   $scope.partner.ServiceProviderContact = response.data.ServiceProviderContact;
                   $scope.partner.ContactPhone = response.data.ContactPhone;
                   $scope.partner.ContactEmail = response.data.ContactEmail;
                   $scope.partner.WebSite = response.data.WebSite;
                   $scope.partner.POC = response.data.POC;
                   $scope.partner.Email = response.data.Email;
                   $scope.partner.Comments = response.data.Comments;

                   $scope.typeObj.PartnerTypeObj.Id = response.data.PartnerTypeId;
                   $scope.typeObj.PartnerTypeObj.Name = response.data.PartnerType;

                   $scope.partner.ExpirationDate = $scope.formatdate(response.data.ExpirationDate);
                   var delinquent = response.data.HasDelinquentFederalDebt;
                   if (delinquent) {
                       $scope.partner.isDelinquentFederalDebt = true;
                   }
                   var Exclusion = response.data.HasKnownExclusion;
                   if (Exclusion) {
                       $scope.partner.isKnownExclusion = true;
                   }
                   $scope.partner.isProviderActive = response.data.isPartnerActive;



                   $scope.partner.CoreCompetencies = response.data.CoreCompetencies;

                   if ($scope.partner.CoreCompetencies != null && $scope.partner.CoreCompetencies != "") {
                       var coreCompetenciesArray = $scope.partner.CoreCompetencies.split(',');
                       if (coreCompetenciesArray.length > 0) {
                           angular.forEach(coreCompetenciesArray, function (value, key) {
                               var coreCompetencySelectedObj = _.find($scope.coreCompetenciesDropDwn, function (obj) { return obj.Id == value });
                               if (coreCompetencySelectedObj != null) {
                                   $scope.tempObjs.CoreCompetencyObj.push({ 'Id': coreCompetencySelectedObj.Id, 'Name': coreCompetencySelectedObj.Name });
                               }
                           });
                       }
                   }
                   $scope.isloading = false;
                   $scope.spLoad = false;
                   $scope.partner.isAdding = false;
                   $scope.partner.isEditing = true;
                   $scope.isShowPOCList = true;
                   $scope.GetPocDetailsByPartner($scope.partner.Id);


               }

           });




           $scope.mandatory.check = false;
           $scope.toggleShowList();
       };

       $scope.addNewPartnerRequest = function () {
           $scope.partners = [];
           $scope.partner.isAdding = true;
           $scope.partner.isEditing = false;
           // $scope.showEntry = true;
           $scope.isShowPOCList = false;
       }


       $scope.onClickDeletePartner = function (row, col) {
           var isNeedToDelete = confirm("Are you sure you want to delete ?");
           if (isNeedToDelete) {
               var selectedPartnerId = row.entity.Id;
               partnerService.getBidByPartner(selectedPartnerId).then(function (response) {
                   if (response.data.length > 0) {
                       toaster.pop('error', 'Error', "You cannot delete the Partner as it is already linked with an Opportunity.");
                   } else {
                       partnerService.delelePartner(selectedPartnerId).then(function (response) {
                           toaster.pop('success', 'Success', "Partner Record has been deleted successfully!");
                           ActivityService.assortedCalls().saveAllCalls(66);
                           var index = $scope.partners.indexOf(row.entity);
                           $scope.partners.splice(index, 1);

                           //angular.forEach($scope.partners, function (value, index) {
                           //    if (value.Id == selectedPartnerId) {
                           //        $scope.partners.splice(index, 1);
                           //    }
                           //})

                       });
                   }
               });
           }

       }


       $scope.singleFilter = function (renderableRows) {
           var textValue = '';
           var findval = '';
           var searchedval = '';
           textValue = $("#globalSearchId").val();
           if (textValue)
               findval = textValue.toLowerCase();
           var matcher = new RegExp(findval);
           renderableRows.forEach(function (row) {
               var match = false;
               ['PartnerName', 'Street', 'City', 'State', 'Country', 'Zip', 'Duns', 'DunsPlus4', 'ContactPhone', 'ContactEmail', 'WebSite', 'POC', 'Email'].forEach(function (field) {
                   var value = row.entity[field];
                   if (value) {
                       if (value.toString().toLowerCase().match(matcher)) {
                           match = true;
                       }
                   }
               });
               if (!match) {
                   row.visible = false;
               }
           });
           return renderableRows;
       };


       $scope.globalSearch = function () {
           $scope.gridApi.grid.refresh();
       };

       //Manage Grid State : Start
       $scope.saveStateData = function () {
           $scope.state = $scope.gridApi.saveState.save();
           $scope.savedState.Id = 27;
           $scope.savedState.Value = JSON.stringify($scope.state);
           partnerService.putGeneralConfigs($scope.savedState).then(function (response) {
               toaster.pop("success", "Success", "Grid setting saved successfully!")
           });
       };

       $scope.restoreState = function () {
           $scope.gridApi.saveState.restore($scope, $scope.state);
       };

       $scope.defaultState = function () {
           partnerService.getDefaultGeneralConfigs($scope.savedState).then(function (response) {
               $scope.savedState = response.data;
               if (response.data.Value != null) {
                   $scope.state = JSON.parse(response.data.Value);
                   $scope.gridApi.saveState.restore($scope, $scope.state);
               }
           });
       };

       function getGeneralConfigs() {
           partnerService.getStoredGeneralConf().then(function (response) {
               if (response.data) {
                   $scope.savedState = response.data;
                   $scope.state = JSON.parse(response.data.Value);
                   $timeout(function () {
                       $scope.gridApi.saveState.restore($scope, $scope.state);
                   }, 1000);
               }
           });
       }

       //Manage Grid State : End
       $scope.rebindGridEntry = function () {
           $scope.getPartners();
       }

       ////edit/view method
       //$scope.selectedPartner = function (index, type, id) {
       //    $scope.loadingImage = false;
       //};




       // Create Partner Process Start



       // $scope.partnerTypeObj = { Id: 0, Name: "" }

       // Pagination control related
       $scope.maxSize = 10;
       $scope.HcurrentPage = 0;
       $scope.LcurrentPage = 0;
       $scope.Hstartindex = 0;
       $scope.predicate = "ChangeDate";
       $scope.reverse = true;
       $scope.HpageChanged = function (pageno) {
           $scope.Hstartindex = (pageno * $scope.maxSize) - $scope.maxSize;
       };

       //RR-527 Get Partner Hitory Data
       $scope.getHistory = function () {
           partnerService.getPartnerHistoryData().success(function (data) {
               debugger;
               $scope.partnerHistoryObjs = data;
               $scope.partnerHistoryCount = data.length;
           })
       }

       $scope.isDevelopment = function (stageId, statusId) {
           if ((stageId == 2 || stageId == 26) && (statusId == 12 || statusId == 29 || statusId == 42)) {
               return true;
           }
           else if (stageId == 11 && statusId == 12) {
               return true;
           }
           else {
               return false;
           }
       }

       //initializes Model
       $scope.newPartnerAdd = function () {
           $scope.partner.PartnerType = { Id: 0, Name: "" };
           $scope.partner.ServiceProviderName = "";
           $scope.partner.Duns = "";
           $scope.partner.Street = "";
           $scope.partner.City = "";
           $scope.partner.State = "";
           $scope.partner.Country = "";
           $scope.partner.Zip = "";
           $scope.partner.Cage = "";
           $scope.partner.DunsPlus4 = "";
           $scope.partner.ExpirationDate = "";
           $scope.partner.isDelinquentFederalDebt = false;
           $scope.partner.isKnownExclusion = false;
           $scope.partner.isProviderActive = false;
           $scope.partner.Phone = "";
           $scope.partner.ServiceProviderContact = "";
           $scope.partner.ContactPhone = "";
           $scope.partner.ContactEmail = "";
           $scope.partner.WebSite = "";
           $scope.partner.POC = "";
           $scope.partner.Email = "";
           $scope.partner.Comments = "";
           $scope.partner.WorkShare = "";
           $scope.partner.PocDetails = [];
           $scope.partner.isShowPocDetails = true;
           $scope.partner.CoreCompetencies = "";

           $scope.tempObjs.CoreCompetencyObj = [];
           $scope.partner.isAdding = true;
           $scope.partner.isEditing = false;
           $scope.isShowPOCList = false;
       }

       $scope.toggleShowList = function () {
           $scope.showList = !$scope.showList;
           if (!$scope.showList) {
               $scope.newPartnerAdd();
               $scope.showEntry = true;
               $scope.partner.isAdding = true;
           }
       };


       // get the data realted to service provider from the service
       $scope.getAPICall = function () {

           var selectedServiceProvider = $('#spName').val().replace(/[^a-z*0-9\s]/gi, '').replace(/[_\s]/g, '-');
           $scope.newPartnerAdd();
           $scope.partner.ServiceProviderName = selectedServiceProvider;
           $scope.isloading = true;

           var url = 'https://api.data.gov/sam/v1/registrations?qterms=legalBusinessName:' +
                       selectedServiceProvider +
                       '&api_key=sTb3Twqloh67fVfGyv0T9TUX8bjnTTtI3p6fPFlh';
           $http.get(url).success(function (data) {
               if (data.results.length < 1) {
                   $scope.spLoad = false;
                   toaster.pop('error', 'Error', "No Company Records found for the name entered!");
                   $scope.isloading = false;
                   $scope.partner.ServiceProviderName = "";
                   $scope.partner.Duns = "";
                   $scope.partner.Street = "";
                   $scope.partner.City = "";
                   $scope.partner.State = "";
                   $scope.partner.Country = "";
                   $scope.partner.Zip = "";
                   $scope.partner.Cage = "";
                   $scope.partner.DunsPlus4 = "";
                   $scope.partner.ExpirationDate = "";
                   $scope.partner.isDelinquentFederalDebt = false;
                   $scope.partner.isKnownExclusion = false;
                   $scope.partner.isProviderActive = false;
                   return false;
               }
               else if (data.results.length == 1) {
                   $scope.spLoad = false;
                   $scope.isloading = false;
                   $scope.partner.ServiceProviderName = data.results[0].legalBusinessName;
                   $scope.partner.Duns = data.results[0].duns;
                   $scope.partner.Street = data.results[0].samAddress.line1;
                   $scope.partner.City = data.results[0].samAddress.city;
                   $scope.partner.State = data.results[0].samAddress.stateOrProvince;
                   $scope.partner.Country = data.results[0].samAddress.country;
                   $scope.partner.Zip = data.results[0].samAddress.zip;
                   if (data.results[0].samAddress.zip4 != null && data.results[0].samAddress.zip4 != "")
                       $scope.partner.Zip = data.results[0].samAddress.zip + "-" + data.results[0].samAddress.zip4;
                   else
                       $scope.partner.Zip = data.results[0].samAddress.zip;

                   $scope.partner.Cage = data.results[0].cage;
                   $scope.partner.DunsPlus4 = data.results[0].dunsPlus4;
                   $scope.partner.ExpirationDate = $scope.formatdate(data.results[0].expirationDate);
                   var delinquent = data.results[0].hasDelinquentFederalDebt;
                   if (delinquent) {
                       $scope.partner.isDelinquentFederalDebt = true;
                   }
                   var Exclusion = data.results[0].hasKnownExclusion;
                   if (Exclusion) {
                       $scope.partner.isKnownExclusion = true;
                   }
                   if (data.results[0].status == "Active") {
                       $scope.partner.isProviderActive = true;
                   }
               }
               else {
                   $scope.spLoad = true;
                   $scope.serviceProviders = data.results;
                   $scope.isloading = false;

               }

           }).error(function (data) {
               $scope.isloading = false;
               $scope.partner.ServiceProviderName = "";
               $scope.partner.Duns = "";
               $scope.partner.Street = "";
               $scope.partner.City = "";
               $scope.partner.State = "";
               $scope.partner.Country = "";
               $scope.partner.Zip = "";
               $scope.partner.Cage = "";
               $scope.partner.DunsPlus4 = "";
               $scope.partner.ExpirationDate = "";
               $scope.partner.isDelinquentFederalDebt = false;
               $scope.partner.isKnownExclusion = false;
               $scope.partner.isProviderActive = false;
               toaster.pop('error', 'Error', "Failed to get company data");
           })


       }


       // gets the Data of Service Providers From the Service
       $scope.getAPIData = function (data) {
           $scope.isloading = true;
           var selectedServiceProviderDuns = $scope.partner.ServiceProviderName;
           partnerService.getPartnerByDuns(selectedServiceProviderDuns, 0).then(function (response) {
               if (response.status == "200" && response.data != "" && response.data.Id > 0) {
                   toaster.pop("warning", "Success", "Partner already exist.")
                   $scope.partner.Id = response.data.Id;
                   $scope.partner.ServiceProviderName = response.data.PartnerName;
                   $scope.partner.Duns = response.data.Duns;
                   $scope.partner.Street = response.data.Street;
                   $scope.partner.City = response.data.City;
                   $scope.partner.State = response.data.State;
                   $scope.partner.Country = response.data.Country;
                   $scope.partner.Zip = response.data.Zip;
                   $scope.partner.DunsPlus4 = response.data.DunsPlus4;
                   $scope.partner.Cage = response.data.Cage;
                   $scope.partner.Phone = response.data.Phone;
                   $scope.partner.ServiceProviderContact = response.data.ServiceProviderContact;
                   $scope.partner.ContactPhone = response.data.ContactPhone;
                   $scope.partner.ContactEmail = response.data.ContactEmail;
                   $scope.partner.WebSite = response.data.WebSite;
                   $scope.partner.POC = response.data.POC;
                   $scope.partner.Email = response.data.Email;
                   $scope.partner.Comments = response.data.Comments;


                   $scope.partner.PartnerType = { Id: response.data.PartnerTypeId, Name: response.data.PartnerType };
                   $scope.partner.ExpirationDate = $scope.formatdate(response.data.ExpirationDate);
                   var delinquent = response.data.HasDelinquentFederalDebt;
                   if (delinquent) {
                       $scope.partner.isDelinquentFederalDebt = true;
                   }
                   var Exclusion = response.data.HasKnownExclusion;
                   if (Exclusion) {
                       $scope.partner.isKnownExclusion = true;
                   }
                   $scope.partner.isProviderActive = response.data.isPartnerActive;



                   $scope.partner.CoreCompetencies = response.data.CoreCompetencies;

                   if ($scope.partner.CoreCompetencies != null && $scope.partner.CoreCompetencies != "") {
                       var coreCompetenciesArray = $scope.partner.CoreCompetencies.split(',');
                       if (coreCompetenciesArray.length > 0) {
                           angular.forEach(coreCompetenciesArray, function (value, key) {
                               var coreCompetencySelectedObj = _.find($scope.coreCompetenciesDropDwn, function (obj) { return obj.Id == value });
                               if (coreCompetencySelectedObj != null) {
                                   $scope.tempObjs.CoreCompetencyObj.push({ 'Id': coreCompetencySelectedObj.Id, 'Name': coreCompetencySelectedObj.Name });
                               }
                           });
                       }
                   }
                   $scope.isloading = false;
                   $scope.spLoad = false;
                   $scope.partner.isAdding = false;
                   $scope.partner.isEditing = true;
                   $scope.isShowPOCList = true;

                   //$scope.partner.PocDetails = response.data.PocDetails;
                   $scope.GetPocDetailsByPartner($scope.partner.Id);


               }
               else {
                   $scope.partner.Id = 0;
                   $http.get('https://api.data.gov/sam/v1/registrations?qterms=duns:' +
                             selectedServiceProviderDuns +
                               '&api_key=sTb3Twqloh67fVfGyv0T9TUX8bjnTTtI3p6fPFlh').success(function (data) {
                                   $scope.partner.ServiceProviderName = data.results[0].legalBusinessName;
                                   $scope.partner.Duns = data.results[0].duns;
                                   $scope.partner.Street = data.results[0].samAddress.line1;
                                   $scope.partner.City = data.results[0].samAddress.city;
                                   $scope.partner.State = data.results[0].samAddress.stateOrProvince;
                                   $scope.partner.Country = data.results[0].samAddress.country;
                                   $scope.partner.Zip = data.results[0].samAddress.zip;
                                   if (data.results[0].samAddress.zip4 != null && data.results[0].samAddress.zip4 != "")
                                       $scope.partner.Zip = data.results[0].samAddress.zip + "-" + data.results[0].samAddress.zip4;
                                   else
                                       $scope.partner.Zip = data.results[0].samAddress.zip;
                                   $scope.partner.Cage = data.results[0].cage;
                                   $scope.partner.DunsPlus4 = data.results[0].dunsPlus4;
                                   $scope.partner.ExpirationDate = $scope.formatdate(data.results[0].expirationDate);
                                   var delinquent = data.results[0].hasDelinquentFederalDebt;
                                   if (delinquent) {
                                       $scope.partner.isDelinquentFederalDebt = true;
                                   }
                                   var Exclusion = data.results[0].hasKnownExclusion;
                                   if (Exclusion) {
                                       $scope.partner.isKnownExclusion = true;
                                   }
                                   if (data.results[0].status == "Active") {
                                       $scope.partner.isProviderActive = true;
                                   }
                                   $scope.isloading = false;
                                   $scope.spLoad = false;
                                   $scope.partner.isAdding = true;
                                   $scope.partner.isEditing = false;
                                   $scope.isShowPOCList = false;
                               }).error(function (data) {
                                   $scope.spLoad = false;
                                   $scope.error = data;
                               });

               }

           });

       }

       $scope.GetPocDetailsByPartner = function (partnerId) {
           $scope.partner.PocDetails = [];
           if (partnerId > 0) {
               partnerService.getPOCDetailByPartner(partnerId).then(function (response) {
                   $scope.partner.PocDetails = response.data;
               });
           }
       }
       $scope.formatdate = function (sdate) {
           var d = new Date(sdate);
           var currDay = "";
           if (d.getDate() < 10) { currDay = "0" + d.getDate(); } else { currDay = d.getDate(); }
           var currMonth = "";
           if ((d.getMonth() + 1) < 10) { currMonth = "0" + (d.getMonth() + 1); } else { currMonth = d.getMonth() + 1; }
           var currYear = d.getFullYear();
           var startDate = currMonth + "/" + currDay + "/" + currYear;
           return startDate;
       }

       $scope.togglePOCExpandedSection = function () {
           $scope.isExpandedPOCSection = !$scope.isExpandedPOCSection;
       }
       $scope.togglePOCListExpandedSection = function () {
           $scope.isExpandedPOCListSection = !$scope.isExpandedPOCListSection;
       }


       $scope.addEditPartner = function () {
           var objPartner = {};

           // update the partner Records 
           if ($scope.partner.isEditing) {
               objPartner.Id = $scope.partner.Id;
               // objPartner.PocDetails = $scope.partnerIndex[$scope.Partner.currentIndex].PocDetails;
           }
           else {
               objPartner.Id = 0;
               objPartner.PocDetails = [];
           }

           // Process to get Core-competency comma spared from selected list
           if ($scope.tempObjs.CoreCompetencyObj != undefined && $scope.tempObjs.CoreCompetencyObj.length > 0) {
               var coreCompList = [];
               _.each($scope.tempObjs.CoreCompetencyObj, function (data) {
                   coreCompList.push(data.Id);
               });

               objPartner.CoreCompetencies = coreCompList.join(',');
           }
           else {
               objPartner.CoreCompetencies = "";
           }

           objPartner.Bid_Id = 0;
           objPartner.PartnerName = $scope.partner.ServiceProviderName;
           objPartner.PartnerType = $scope.partner.PartnerType.Name;
           objPartner.PartnerTypeId = $scope.partner.PartnerType.Id;
           objPartner.ExpirationDate = $scope.formatdate($scope.partner.ExpirationDate);
           objPartner.Cage = $scope.partner.Cage;
           objPartner.isPartnerActive = $scope.partner.isProviderActive
           objPartner.Duns = $scope.partner.Duns;
           objPartner.DunsPlus4 = $scope.partner.DunsPlus4;
           objPartner.Street = $scope.partner.Street;
           objPartner.City = $scope.partner.City;
           objPartner.State = $scope.partner.State;
           objPartner.Country = $scope.partner.Country;
           objPartner.Zip = $scope.partner.Zip;
           objPartner.Phone = $scope.partner.Phone;
           objPartner.ServiceProviderContact = $scope.partner.ServiceProviderContact;
           objPartner.ContactPhone = $scope.partner.ContactPhone;
           objPartner.ContactEmail = $scope.partner.ContactEmail;
           objPartner.WebSite = $scope.partner.WebSite;
           objPartner.POC = $scope.partner.POC;
           objPartner.Email = $scope.partner.Email;
           objPartner.HasDelinquentFederalDebt = $scope.partner.isDelinquentFederalDebt;
           objPartner.HasKnownExclusion = $scope.partner.isKnownExclusion;
           objPartner.Comments = $scope.partner.Comments;

           if ($scope.partner.isAdding) {
               partnerService.postData(objPartner).then(function (response) {
                   if (response.data.id == 0) {
                       toaster.pop('error', 'Error', "Server validation reported save error. So, data could not be saved !");
                   } else {
                       toaster.pop('success', 'Success', "Partner saved Successfully");
                       ActivityService.assortedCalls().saveAllCalls(64);
                       $scope.partner.Id = response.data.Id;
                       $scope.partner.isAdding = false;
                       $scope.partner.isEditing = true;
                       $scope.isShowPOCList = true;
                   }
               });
               //.error(function (data) {
               //    $scope.error = "An Error has occurred while adding Partner! " + data;
               //});
           }
           else if ($scope.partner.isEditing) {
               partnerService.putData($scope.partner.Id, objPartner).then(function (response) {
                   ActivityService.assortedCalls().saveAllCalls(65);
                   toaster.pop('success', 'Success', "Partner updated successfully!");
                   // $scope.loadPartners($scope.currentRecordId);
                   //$scope.partner.isAdding = true;
                   //$scope.partner.isEditing = false;
               }).error(function (data) {
                   $scope.error = "An Error has occurred while Updating Partner! " + data;
               });
           }



       }



       // Create Partner Process End

       // POC Details and Add/Edit/Remove Process Start


       $scope.newPOCRequest = function (id) {
           $scope.AddNewPOCModal(id);
       }

       $scope.deletePoc = function (pid, pcid) {
           if ($scope.partner.PocDetails.length == 1) {
               toaster.pop('info', 'Message', "POC cannot be deleted.Atleast one POC is required!");
           }
           else {
               partnerService.getBidByPOC(pcid).then(function (response) {
                   if (response.data.length > 0) {
                       toaster.pop('error', 'Error', "You cannot delete the POC Details as it is already linked with an Opportunity.");
                   } else {
                       var ans = confirm("Are you sure you want to delete this POC?");
                       if (ans) {

                           partnerService.delelePOC(pid, pcid).then(function (response) {
                               toaster.pop('success', 'Success', "POC Details deleted successfully!");
                               angular.forEach($scope.partner.PocDetails, function (value, index) {
                                   if (value.Id == pcid) {
                                       $scope.partner.PocDetails.splice(index, 1);
                                   }
                               });
                           });
                       }

                   }
               });
           }
       }

       $scope.editPoc = function (data, id) {
           $scope.showEntry = false;
           $scope.mode = "Edit";

           $scope.partnerDetails = {
               Id: data.Id,
               POC: data.POC,
               Email: data.Email,
               Phone: data.Phone,
               Comments: data.Comments,
               POCTitle: data.POCTitle,
               MobileNo: data.MobileNo,
               Bid_Id: data.Bid_Id
           }

           var modalInstance = $modal.open({
               templateUrl: '../Scripts/app/Partner/partials/pocAddEdit.html',
               controller: 'modalInstanceAddPOCCtrl',
               backdrop: 'static',
               scope: $scope,
               resolve: {
                   partnerId: function () {
                       return id;
                   },
                   obj: function () {
                       return $scope.partnerDetails;
                   },
                   mode: function () {
                       return $scope.mode;
                   }
               }
           });
           modalInstance.result.then(function (data) {
               toaster.pop('success', 'Success', "POC Details edited successfully!");
               if (data != "" && data != undefined) {
                   $scope.partner.PocDetails = [];
                   $scope.partner.PocDetails = data;
               }
               $scope.showEntry = true;
           });
       }


       $scope.AddNewPOCModal = function (id) {
           $scope.showEntry = false;
           $scope.mode = "Create";
           $scope.partnerDetails = {
               Id: 0,
               POC: "",
               Email: "",
               Phone: "",
               Comments: "",
               POCTitle: "",
               MobileNo: "",
               Bid_Id: ""
           }


           var modalInstance = $modal.open({
               templateUrl: '../Scripts/app/Partner/partials/pocAddEdit.html',
               controller: 'modalInstanceAddPOCCtrl',
               backdrop: 'static',
               scope: $scope,
               resolve: {
                   partnerId: function () {
                       return id;
                   },
                   obj: function () {
                       return $scope.partnerDetails;
                   },
                   mode: function () {
                       return $scope.mode;
                   }
               }
           });
           modalInstance.result.then(function (data) {
               if (data != "" && data != undefined) {
                   $scope.partner.PocDetails.push(data);
                   toaster.pop('success', 'Success', "POC Details added successfully!");
               }
               $scope.showEntry = true;
           });
       }






       $scope.togglePOCExpandedSection = function () {
           $scope.isExpandedPOCSection = !$scope.isExpandedPOCSection;
       }
       $scope.togglePOCListExpandedSection = function () {
           $scope.isExpandedPOCListSection = !$scope.isExpandedPOCListSection;
       }




       // Create New POC Details Process End



       //RR-527 : Call Model for Bids Information by click Partner 'i' button
       $scope.showBidInfoModalByPartner = function (id) {
           $scope.mode = "Partner";
           var modalInstance = $modal.open({
               templateUrl: '../Scripts/app/Partner/partials/modalBidInfo.html',
               controller: 'modalInstanceBidInfo',
               backdrop: 'static',
               scope: $scope,
               resolve: {
                   partnerId: function () {
                       return id;
                   },
                   mode: function () {
                       return $scope.mode;
                   }
               }
           });
           modalInstance.result.then(function () {

           });
       }

       //RR-527 : Call Model for Bids Information by click POC 'i' button
       $scope.showBidInfoModalByPOC = function (id) {
           $scope.mode = "POC";
           var modalInstance = $modal.open({
               templateUrl: '../Scripts/app/Partner/partials/modalBidInfo.html',
               controller: 'modalInstanceBidInfo',
               backdrop: 'static',
               scope: $scope,
               resolve: {
                   partnerId: function () {
                       return id;
                   },
                   mode: function () {
                       return $scope.mode;
                   }
               }
           });
           modalInstance.result.then(function () {

           });
       }

       $scope.getPartners();
       getGeneralConfigs();
       $scope.getPartnerTypes();

       $scope.getCoreCompetencies();
       $scope.getHistory();
   }]);

