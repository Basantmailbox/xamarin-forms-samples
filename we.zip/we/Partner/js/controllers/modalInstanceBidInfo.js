﻿
app.controller('modalInstanceBidInfo', ['$scope', '$http', '$modalInstance', '$controller', 'partnerId', 'mode', 'toaster', '$location', 'partnerService',
    function ($scope, $http, $modalInstance, $controller, partnerId, mode, toaster, location, partnerService) {
        $scope.partnerId = partnerId;
        $scope.bidObjs = [];
       
        $scope.currentMode = mode;

        $scope.toggleInfoModal = function () {
            $modalInstance.close();
        }

        if ($scope.currentMode == "Partner") {

            getBidsByPartner($scope.partnerId);
        }
        else if ($scope.currentMode == "POC") {
            getBidsByPOC($scope.partnerId);
        }

        function getBidsByPartner(partnerId) {
            $scope.bidObjs = [];
            partnerService.getBidByPartner(partnerId).then(function (response) {
                if (response.status==200) {
                    $scope.bidObjs = response.data;
                }
                else {
                    toaster.pop('error', 'Error', "An Error has occurred while adding POC Details!");
                }
            });
        }

        function getBidsByPOC(partnerContactId) {
            $scope.bidObjs = [];
            partnerService.getBidByPOC(partnerContactId).then(function (response) {
                if (response.status == 200) {
                    $scope.bidObjs = response.data;
                }
                else {
                    toaster.pop('error', 'Error', "An Error has occurred while adding POC Details!");
                }
            });
        }

    }]);