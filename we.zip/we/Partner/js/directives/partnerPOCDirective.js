﻿app.directive('partnerPocManage', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            displayOnly: '=',
            bidTypes: '=',
            followDuration: '=',
            dateCriertia: '=',
            isFavorite: '=',
            isMytab: '=',
            redirectUser:'=',
        },
        templateUrl: '../Scripts/app/Partner/partials/pocManager.html',
        transclude: true,
        controller: 'partnerPocManage',
        link: function (scope, el, attrs) {
            
        }
    }
})