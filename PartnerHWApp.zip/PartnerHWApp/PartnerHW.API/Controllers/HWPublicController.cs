﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PartnerHW.DTOs;
using PartnerHW.Core.Helpers;
using PartnerHW.IRepository;
using static PartnerHW.Core.AppEnum;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class HWPublicController : Controller
    {
        private IHWPublicRepository _hWPublicRepository;
        private IPartnerRepository _partnerService;
        private IReportRepository _reportService;
        private readonly AppSettings _appSettings;

        public HWPublicController(
            IHWPublicRepository hWPublicRepository, 
            IOptions<AppSettings> appSettings,
            IPartnerRepository partnerService,
            IReportRepository reportService
            )
        {
          _hWPublicRepository = hWPublicRepository;
            _appSettings = appSettings.Value;
            _partnerService = partnerService;
            _reportService = reportService;
        }

        //[Route("getlinkedinsaledata")]
        //[HttpGet]
        //public async Task<IActionResult> GetlinkedinSaleData()
        //{
        //    try
        //    {
        //        //https://www.linkedin.com/uas/oauth2/authorization?response_type=code&client_id=81rtj2l627v4s8&scope=r_basicprofile%20r_fullprofile%20r_emailaddress&state=DCEEFWF454Us5dffef424&redirect_uri=http://localhost:61912/LinkedINAuth

        //        var baseAddress2 = "https://www.linkedin.com/sales/search/people/list/employees-for-account/422813?doFetchHeroCard=false&logHistory=true&page=1&searchSessionId=4uAVTn3zT2q5uzfi%2FcupaA%3D%3D&seniorityIncluded=7%2C6%2C8";

        //        var baseAddress = "https://www.linkedin.com/uas/oauth2/authorization?response_type=code&client_id=81rtj2l627v4s8&scope=r_basicprofile%20r_fullprofile%20r_emailaddress&state=DCEEFWF454Us5dffef424&redirect_uri=http://localhost:61912/LinkedINAuth";
        //        using (var client = new HttpClient())
        //        {
        //            using (var response = client.GetAsync(baseAddress).Result)
        //            {
        //                if (response.IsSuccessStatusCode)
        //                {
        //                    var customerJsonString = await response.Content.ReadAsStringAsync();
        //                    // var cust = JsonConvert.DeserializeObject<Response>(customerJsonString);
        //                }
        //                else
        //                {
        //                    Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
        //                }
        //            }
        //        }

        //        var resultObj = _hWPublicRepository.GetlinkedinSaleData();
        //        return Ok(resultObj);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }

        //}


        [Route("getmypartners4chart")]
        [HttpGet]
        public IActionResult GetMyPartners4Chart(string partnerId)
        {
            try
            {
                var users = _partnerService.GetMyPartners4Chart(Convert.ToInt32(partnerId));
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getspent")]
        [HttpGet]
        public IActionResult GetSpent(int partnerId, int tenure = 1, int spentOn = 1)
        {
            try
            {
                //int partnerId = 530;
                //int tenure = 1;
                //int spentOn = 1;
                EnumSpentTenure enumSpentTenure = new EnumSpentTenure();
                EnumSpentOn enumSpentOn = new EnumSpentOn();

                enumSpentOn = (EnumSpentOn)Enum.ToObject(typeof(EnumSpentOn), spentOn);
                enumSpentTenure = (EnumSpentTenure)Enum.ToObject(typeof(EnumSpentTenure), tenure);

                var resultObjs = _reportService.GetSpent(partnerId, enumSpentTenure, enumSpentOn);
                return Ok(resultObjs);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



      
    }

}