﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using PartnerHW.DTOs;
using PartnerHW.Core.Helpers;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : Controller
    {
        private IUserRepository _userService;
        private readonly AppSettings _appSettings;

        public AuthController(IUserRepository userService, IOptions<AppSettings> appSettings)
        {
            _userService = userService;
            _appSettings = appSettings.Value;
        }

        //[AllowAnonymous]
        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody]LoginRequestDto userParam)
        {
            if (!string.IsNullOrEmpty(userParam.LoginId) || !string.IsNullOrEmpty(userParam.Password))
            {
                var user = _userService.Authenticate(userParam.LoginId, userParam.Password);

                //ResponseResultDto responseResultDto = new ResponseResultDto();

                if (user != null)
                {
                    // authentication successful so generate jwt token
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(new Claim[]
                        {
                    new Claim(ClaimTypes.Name, user.PartnerId.ToString())
                        }),
                        Expires = DateTime.UtcNow.AddDays(1),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                    };
                    var token = tokenHandler.CreateToken(tokenDescriptor);
                    user.Token = tokenHandler.WriteToken(token);

                    // remove password before returning
                    user.Password = null;

                    //responseResultDto.Data = user;
                    //responseResultDto.StatusCode =(int) AppEnum.StatusCode.SUCCESS;
                    //responseResultDto.MSG
                    return Ok(user);
                }
                else
                {
                    return BadRequest(new { message = "Username or password is incorrect" });
                }
            }
            else
            {
                return BadRequest(new { message = "Username or password is incorrect" });
            }

        }


    }
}
