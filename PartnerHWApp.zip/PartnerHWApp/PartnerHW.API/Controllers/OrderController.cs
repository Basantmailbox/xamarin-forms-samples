﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.DTOs;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : Controller
    {
        private IOrderRepository _orderService;

        public OrderController(IOrderRepository orderService)
        {
            _orderService = orderService;
        }
       

        [Route("getpartnerhistorydaywise")]
        [HttpGet]
        public IActionResult GetPartnerHistoryDayWise(int partnerId)
        {
            try
            {
                if (partnerId>0)
                {
                    var users = _orderService.GetPartnerHistoryDayWise(partnerId);
                    return Ok(users);
                }
                else
                {

                    return BadRequest("Please enter amount");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [Route("getpartnerhistoryoneday")]
        [HttpGet]
        public IActionResult GetPartnerHistoryOneDay(int partnerId, string orderDate)
        {
            try
            {
                if (partnerId>0)
                {
                    var users = _orderService.GetPartnerHistoryOneDay(partnerId, orderDate);
                    return Ok(users);
                }
                else
                {
                    return BadRequest("Partner not valid");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

    }
}
