﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.DTOs;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PackageController : Controller
    {
        private IPackageRepository _packageService;

        public PackageController(IPackageRepository packageService)
        {
            _packageService = packageService;
        }

        [Route("insertnew")]
        [HttpPost]
        public IActionResult InsertNew(PackageDto entityObj)
        {
            try
            {
                if (!string.IsNullOrEmpty(entityObj.MappedPkgIds))
                {
                    var resultObj = _packageService.InsertNew(entityObj);
                    return Ok(resultObj);
                }
                else
                {
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status406NotAcceptable, "Please Select Packages.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getpackage4booking")]
        [HttpGet]
        public IActionResult GetPackage4Booking(int partnerId)
        {
            try
            {
                var resultObj = _packageService.GetPackage4Booking();
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getmypackages")]
        [HttpGet]
        public IActionResult GetMyPackages(int partnerId)
        {
            try
            {
                var resultObj = _packageService.GetMyPackages(partnerId);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }


        [Route("getmypackagedetails")]
        [HttpGet]
        public IActionResult GetMyPackageDetails(int partnerId,int packageId)
        {
            try
            {
                var resultObj = _packageService.GetMyPackageDetails(partnerId, packageId);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        [Route("gethwpackages")]
        [HttpGet]
        public IActionResult GetHWPackages()
        {
            try
            {
                var resultObj = _packageService.GetHWPackages();
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
