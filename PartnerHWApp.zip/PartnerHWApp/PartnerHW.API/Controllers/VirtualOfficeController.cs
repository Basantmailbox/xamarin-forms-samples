﻿using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.DTOs;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class VirtualOfficeController : Controller
    {
        private IVirtualOfficeRepository _virtualOfficeService;

        public VirtualOfficeController(IVirtualOfficeRepository virtualOfficeService)
        {
            _virtualOfficeService = virtualOfficeService;
        }

        [Route("setnewentity")]
        [HttpPost]
        public IActionResult SetNewEntity(VirtualOfficeDto entityObj)
        {
            try
            {
                var resultObj = _virtualOfficeService.SetNewEntity(entityObj);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getbypartnerid")]
        [HttpGet]
        public IActionResult GetByPartnerId(string partnerId)
        {
            try
            {
                var resultObj = _virtualOfficeService.GetByPartnerId(partnerId);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

    }
}
