﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.DTOs;
using PartnerHW.IRepository;
using static PartnerHW.Core.AppEnum;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class GlobalDiscountController : Controller
    {

        private IGlobalDiscountRepository _discountService;

        public GlobalDiscountController(IGlobalDiscountRepository discountService)
        {
            _discountService = discountService;
        }

        [Route("insertorupdate")]
        [HttpPost]
        public IActionResult InsertOrUpdate(GlobalDiscountDto entityObj)
        {
            try
            {
                if (entityObj.GlobalDiscount> 0)
                {
                    var resultObjs = _discountService.InsertOrUpdate(entityObj);
                    if (resultObjs)
                    { return Ok(resultObjs); }
                    else {
                        return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status406NotAcceptable, "Some thing Wrong.");
                    }
                    
               
                }
                else
                {
                    return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status406NotAcceptable,"Some thing Wrong.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        [Route("getbypartnerid")]
        [HttpGet]
        public IActionResult GetByPartnerId(int partnerId)
        {
            try
            {
                var resultObjs = _discountService.GetByPartnerId(partnerId);
                return Ok(resultObjs);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [Route("getall")]
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var resultObjs = _discountService.GetByPartnerId(0);
                return Ok(resultObjs);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
