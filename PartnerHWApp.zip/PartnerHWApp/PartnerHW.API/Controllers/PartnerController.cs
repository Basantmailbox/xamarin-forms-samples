﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.DTOs;
using PartnerHW.Core;
using PartnerHW.Core.Utilities;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{

    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PartnerController : Controller
    {
        private IPartnerRepository _partnerService;

        public PartnerController(IPartnerRepository partnerService)
        {
            _partnerService = partnerService;
        }

        [Route("getmypartner")]
        [HttpGet]
        public IActionResult GetMyPartner(string partnerId)
        {
            try
            {
                var users = _partnerService.GetMyPartner(Convert.ToInt32(partnerId));
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("updateentity")]
        [HttpPost]
        public IActionResult UpdateEntity(PartnerDto entityObj)
        {
            try
            {
                if (entityObj.PartnerId > 0)
                {
                    var users = _partnerService.UpdateEntity(entityObj);
                    return Ok(users);
                }
                else
                {
                    return BadRequest("Try again.");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("insertnewentity")]
        [HttpPost]
        public IActionResult InsertNewEntity(PartnerDto entityObj)
        {
            try
            {
                entityObj.AvailableCredit = "0";
                entityObj.IsActive = true;
                    var users = _partnerService.InsertEntity(entityObj);
                    return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getpartnerapprovalpending")]
        [HttpGet]
        public IActionResult GetPartnerApprovalPending(int partnerId = 0, int roleId = 0)
        {
            try
            {
                List<PartnerDto> partnerDtos = new List<PartnerDto>();
                if (partnerId == 0 && roleId == 0)
                {
                    partnerDtos = _partnerService.GetPartnerApprovalPending();
                }
                else if (partnerId == 0 && roleId > 0)
                {
                    partnerDtos = _partnerService.GetPartnerApprovalPending(roleId);
                }
                else if (partnerId > 0)
                {
                    partnerDtos = _partnerService.GetPartnerApprovalPending(partnerId, roleId);
                }

                return Ok(partnerDtos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getpartnerbyrole")]
        [HttpGet]
        public IActionResult GetPartnerByRole(int roleId)
        {
            try
            {
                List<PartnerDto> partnerDtos = new List<PartnerDto>();
                if ((int)AppEnum.RoleType.GOLD == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.GOLD);
                }
                else if ((int)AppEnum.RoleType.PLATINUM == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.PLATINUM);
                }
                else if ((int)AppEnum.RoleType.SILVER == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.SILVER);
                }

                return Ok(partnerDtos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getpartnerbyroleandpartner")]
        [HttpGet]
        public IActionResult GetPartnerByRoleAndPartner(int partnerId, int roleId)
        {
            try
            {
                List<PartnerDto> partnerDtos = new List<PartnerDto>();
                if ((int)AppEnum.RoleType.GOLD == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.GOLD, partnerId);
                }
                else if ((int)AppEnum.RoleType.PLATINUM == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.PLATINUM, partnerId);
                }
                else if ((int)AppEnum.RoleType.SILVER == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.SILVER, partnerId);
                }
                else if ((int)AppEnum.RoleType.VOffice == roleId)
                {
                    partnerDtos = _partnerService.GetByRole(AppEnum.RoleType.VOffice, partnerId);
                }
                return Ok(partnerDtos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getminbalancemypartners")]
        [HttpGet]
        public IActionResult GetMinBalanceMyPartners(string partnerId)
        {
            try
            {
                var users = _partnerService.GetMinBalanceMyPartners(Convert.ToInt32(partnerId));
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getmypartners4chart")]
        [HttpGet]
        public IActionResult GetMyPartners4Chart(string partnerId)
        {
            try
            {
                var users = _partnerService.GetMyPartners4Chart(Convert.ToInt32(partnerId));
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getpartner")]
        [HttpGet]
        public IActionResult GetPartner(int partnerId)
        {
            try
            {
                var resultObj = _partnerService.GetPartner(partnerId);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Route("getcurrentpoints")]
        [HttpGet]
        public IActionResult GetCurrentPoints(int partnerId)
        {
            try
            {
                if (partnerId > 0)
                {
                    var resultObj = _partnerService.GetCurrentPoints(partnerId);
                    return Ok(resultObj);
                }
                else
                {
                    return BadRequest("Partner not valid");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
}
