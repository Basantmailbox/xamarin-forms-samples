﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PartnerHW.DTOs;
using PartnerHW.Core.Helpers;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PromoCodeController : Controller
    {
        private IPromoCodeRepository _promoCodeRepository;
        private readonly AppSettings _appSettings;

        public PromoCodeController(IPromoCodeRepository promoCodeRepository, IOptions<AppSettings> appSettings)
        {
            _promoCodeRepository = promoCodeRepository;
            _appSettings = appSettings.Value;
        }

        [Route("insertnew")]
        [HttpPost]
        public IActionResult InsertNew(PromoCodeDto entityObj)
        {
            try
            {
                var resultObj = _promoCodeRepository.InsertNew(entityObj);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getAll")]
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                //_promoCodeRepository.InsertNewBulck(530, DateTime.Today, 1500);
                var resultObj = _promoCodeRepository.GetAll();
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getbypartnerid")]
        [HttpGet]
        public IActionResult GetByPartnerId(int partnerId)
        {
            try
            {
                //_promoCodeRepository.InsertNewBulck(530, DateTime.Today, 1500);
                var resultObj = _promoCodeRepository.GetByPartnerId(partnerId);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getvalidrechargepromo")]
        [HttpGet]
        public IActionResult GetValidRechargePromo()
        {
            try
            {
                var resultObj = _promoCodeRepository.GetValidRechargePromo();
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getvalidbookingpromo")]
        [HttpGet]
        public IActionResult GetValidBookingPromo()
        {
            try
            {
                var resultObj = _promoCodeRepository.GetValidBookingPromo();
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("appliedpromovalidate")]
        [HttpPost]
        public IActionResult AppliedPromoValidate(PromoCodeDto entityObj)
        {
            try
            {
                var resultObj = _promoCodeRepository.AppliedPromoValidate(entityObj);
                return Ok(resultObj);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        

    }
}
