﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.DTOs;
using PartnerHW.IRepository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CreditController : Controller
    {
        private ICreditRepository _creditService;

        public CreditController(ICreditRepository creditService)
        {
            _creditService = creditService;
        }
       

        [Route("buy")]
        [HttpPost]
        public IActionResult Buy(CreditBuy entityObj)
        {
            try
            {
                if (!string.IsNullOrEmpty(entityObj.RechargeAmount))
                {
                    var returnResult = _creditService.Buy(entityObj);
                    if (returnResult)
                    {
                        return Ok(returnResult);
                    }
                    else
                    {
                        return BadRequest("somthing wromg, Please reload page and try again.");
                    }
                }
                else
                {

                    return BadRequest("Please enter amount");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("getallocated")]
        [HttpGet]
        public IActionResult GetAllocated(int partnerId)
        {
            try
            {
                if (partnerId>0)
                {
                    var users = _creditService.GetAllocated(partnerId);
                    return Ok(users);
                }
                else
                {
                    return BadRequest("Partner not valid");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Route("gettransectionhistory")]
        [HttpGet]
        public IActionResult GetTransectionHistory(int partnerId)
        {
            try
            {
                if (partnerId > 0)
                {
                    var users = _creditService.GetTransectionHistory(partnerId);
                    return Ok(users);
                }
                else
                {
                    return BadRequest("Partner not valid");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }


        

    }
}
