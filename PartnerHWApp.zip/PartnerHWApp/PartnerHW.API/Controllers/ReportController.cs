﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PartnerHW.IRepository;
using static PartnerHW.Core.AppEnum;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ReportController : Controller
    {

        private IReportRepository _reportService;

        public ReportController(IReportRepository reportService)
        {
            _reportService = reportService;
        }


        [Route("getspent")]
        [HttpGet]
        public IActionResult GetSpent(int partnerId,int tenure=1, int spentOn=1)
        {
            try
            {
                EnumSpentTenure enumSpentTenure = new EnumSpentTenure();
                EnumSpentOn enumSpentOn = new EnumSpentOn();

                enumSpentOn= (EnumSpentOn)Enum.ToObject(typeof(EnumSpentOn), spentOn);
                enumSpentTenure = (EnumSpentTenure)Enum.ToObject(typeof(EnumSpentTenure), tenure);

                var resultObjs = _reportService.GetSpent(partnerId, enumSpentTenure, enumSpentOn);
                return Ok(resultObjs);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
