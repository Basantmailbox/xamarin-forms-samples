﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

using PartnerHW.DTOs;
using PartnerHW.Core.Converter;
using PartnerHW.IRepository;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PartnerHW.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CommonAPI : Controller
    {
        private ICityRepository _cityService;
        private IUserRepository _userService;

        public CommonAPI(ICityRepository cityService, IUserRepository userService)
        {
            _cityService = cityService;
            _userService = userService;
        }


        #region Google PinCode Verification 
        [Route("getvalidatepincode")]
        [HttpGet]
        public IActionResult GetValidatePinCode(int userId, string pinCode)
        {
            CityStateDto cityStateDtos = new CityStateDto();
            try
            {

                string postalAPI = "https://api.postalpincode.in/pincode/" + pinCode;
                HttpWebRequest request1 = (HttpWebRequest)WebRequest.Create(postalAPI);
                request1.Method = "GET";
                request1.ContentType = "application/json";
                try
                {
                    WebResponse response1 = request1.GetResponse();
                    StreamReader reader1 = new StreamReader(response1.GetResponseStream());
                    string responseStringData1 = reader1.ReadToEnd();
                    DataTable dtResult = new JsonConvertor().JsonStringToDataTable(responseStringData1);
                    if (dtResult.Rows.Count > 0)
                    {
                        if (dtResult.Rows[0]["Message"].ToString() == "No records found")
                        {
                            string googleKey = "NA";
                            cityStateDtos = GetValidateCity(dtResult, userId, "", pinCode, out googleKey);
                        }
                        else
                        {
                            DataView view = new DataView(dtResult);
                            DataTable distinctValues = view.ToTable(true, "District");
                            distinctValues.Columns.Add("Count");
                            foreach (DataRow rowObj in distinctValues.Rows)
                            {

                                var allDistricts = (from customer in dtResult.AsEnumerable()
                                                    where customer.Field<string>("District") == rowObj[0].ToString()
                                                    select new
                                                    {
                                                        District = customer.Field<string>("District")
                                                    }).ToList();

                                rowObj[1] = allDistricts.Count();

                            }
                            if (distinctValues.Rows.Count > 0)
                            {
                                DataView dv = new DataView(distinctValues);
                                dv.Sort = "Count DESC";
                                string googleKey = "NA";
                                cityStateDtos = GetValidateCity(dtResult, userId, dv.Table.Rows[0][0].ToString(), pinCode, out googleKey);
                            }
                        }
                    }
                    else
                    {
                        string googleKey = "NA";
                        GetValidateCity(dtResult, userId, "", pinCode, out googleKey);
                    }
                }
                catch (WebException we)
                {
                    string webExceptionMessage = we.Message;
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return Ok(cityStateDtos);
        }

        private CityStateDto GetValidateCity(DataTable dtCityState, int userId, string cityName, string pincode, out string googleKey)
        {
            CityStateDto resultCityStateDto = new CityStateDto();
            DataSet ds = new DataSet();
            googleKey = "";

            string block = "";
            string district = "";
            string state = "";

            if (dtCityState.Rows.Count > 0)
            {
                if (!dtCityState.Rows[0]["Message"].ToString().Contains("records found"))
                {
                    var allDistricts = (from customer in dtCityState.AsEnumerable()
                                        where customer.Field<string>("District") == cityName
                                        select new
                                        {
                                            Block = customer.Field<string>("Block"),
                                            District = customer.Field<string>("District"),
                                            State = customer.Field<string>("State"),
                                            Pincode = customer.Field<string>("Pincode")
                                        }).ToList();

                    if (allDistricts.Count > 0)
                    {
                        block = allDistricts[0].Block;
                        district = allDistricts[0].District;
                        state = allDistricts[0].State;
                        pincode = allDistricts[0].Pincode;
                        if (string.IsNullOrEmpty(district)) { district = state; }
                    }
                }

                try
                {
                    CityStateDto reqCityStateDto = new CityStateDto();
                    reqCityStateDto.BlockName = block.Trim();
                    reqCityStateDto.CityName = district.Trim();
                    reqCityStateDto.StateName = state.Trim();
                    reqCityStateDto.Pincode = pincode.Trim();
                    reqCityStateDto.UserId = userId;
                    reqCityStateDto.GoogleKey = "";

                    googleKey = "";
                    var cityPincod = _cityService.GetCityStateWithPinCode(reqCityStateDto);

                    if (cityPincod.Count > 0)
                    {
                        resultCityStateDto = cityPincod.Where(d => d.CityId != 0 && !string.IsNullOrEmpty(d.CityName) && d.StateId != 0 && !string.IsNullOrEmpty(d.CityName)).FirstOrDefault(); ;
                    }
                }
                catch (Exception ex)
                {
                    return resultCityStateDto;
                }
            }
            return resultCityStateDto;
        }

        [Route("getgeoaddress")]
        [HttpGet]
        public IActionResult GetGeoAddress(string searchText, string pinCode, string cityName, int userId)
        {
            List<GoogleAPIGeoAddressResultDto> Address = new List<GoogleAPIGeoAddressResultDto>();

            if (!string.IsNullOrEmpty(pinCode) && !string.IsNullOrEmpty(cityName) && cityName != "Select City")
            {
                List<string> queryStr = new List<string>();
                if (!string.IsNullOrEmpty(searchText)) { queryStr.Add(searchText); }
                if (!string.IsNullOrEmpty(cityName)) { queryStr.Add(cityName); }
                if (!string.IsNullOrEmpty(pinCode)) { queryStr.Add(pinCode); }

                DataTable dtGoogleKey = new DataTable();
                string googleKey = "";
                if (userId > 0)
                {
                 googleKey = _userService.GetGoogleAPIKey(userId);
                }
                
                string url = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=" + string.Join(",", queryStr) + "&sensor=false&key=" + googleKey;


                HttpWebRequest request1 = (HttpWebRequest)WebRequest.Create(url);
                request1.Method = "GET";
                request1.ContentType = "application/json";
                try
                {
                    WebResponse response1 = request1.GetResponse();
                    StreamReader reader1 = new StreamReader(response1.GetResponseStream());
                    string responseStringData1 = reader1.ReadToEnd();


                    GooglAPIPlaceResponceDto.RootObject item = JsonConvert.DeserializeObject<GooglAPIPlaceResponceDto.RootObject>(responseStringData1);

                    if (item.status == "OK")
                    {
                        if (item.predictions != null)
                    {
                        foreach (var predictionObj in item.predictions)
                        {
                            if (!predictionObj.types.Contains("postal_code"))
                            {
                                Address.Add(new GoogleAPIGeoAddressResultDto { GeoPlaceName  = predictionObj.description, GeoPlaceId = predictionObj.place_id });
                            }
                        }
                    }
                    }

                    if (Address.Count == 0)
                    {
                        Address.Add(new GoogleAPIGeoAddressResultDto { GeoPlaceName = " Location Not Found : " + item.status, GeoPlaceId = "0000000" });
                    }

                }
                catch (Exception ex)
                {
                    Address.Add(new GoogleAPIGeoAddressResultDto { GeoPlaceName = " Location Not Found : " + ex.Message, GeoPlaceId = "0000000" });
                }
            }
            else
            {
                Address.Add(new GoogleAPIGeoAddressResultDto { GeoPlaceName = " Location Not Found", GeoPlaceId = "0000000" });
            }
            return Ok(Address);
        }

        [Route("getlatlongbyplaceid")]
        [HttpGet]
        public IActionResult GetLatLongByPlaceId(int userId,string placeId)
        {
            string googleKey = "";
            if (userId > 0)
            {
                googleKey = _userService.GetGoogleAPIKey(userId);
            }

            string url = "https://maps.googleapis.com/maps/api/place/details/json?place_id=" + placeId + "&key="+ googleKey;
            HttpWebRequest request1 = (HttpWebRequest)WebRequest.Create(url);
            request1.Method = "GET";
            request1.ContentType = "application/json";
            GoogleAPIPlaceDetailsDto.Location locationPlaceId = new GoogleAPIPlaceDetailsDto.Location();
            try
            {
                WebResponse response1 = request1.GetResponse();
                StreamReader reader1 = new StreamReader(response1.GetResponseStream());
                string responseStringData1 = reader1.ReadToEnd();

                GoogleAPIPlaceDetailsDto.RootObject item = JsonConvert.DeserializeObject<GoogleAPIPlaceDetailsDto.RootObject>(responseStringData1);

                if (item.status == "OK")
                {
                    if (item.result != null)
                    {
                        if (item.result.geometry != null)
                        {
                            locationPlaceId = item.result.geometry.location;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return Ok(locationPlaceId);
        }

        #endregion

    }
}
