﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class PartnerChartDto
    {
        public int Id { get; set; }
        public string Label { get; set; }
        public string Value { get; set; }
        public string Link { get; set; }
    }
}
