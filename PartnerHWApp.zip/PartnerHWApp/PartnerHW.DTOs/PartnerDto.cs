﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class PartnerDto
    {

        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public int PartnerTypeId { get; set; }
        public string PartnerType { get; set; }

        public string DisplayRoleName { get; set; }
        
        public string LoginPassword { get; set; }
        public int CreatedBy { get; set; }
        public bool IsActive { get; set; }
        public string AvailableCredit { get; set; }

        public string Earning { get; set; }
        public int ReportingTo { get; set; }

        //public string FullName { get; set; }
        //public string MobileNo { get; set; }
        //public string Username { get; set; }
        //public string Password { get; set; }
        //public string Token { get; set; }
        //public int RoleId { get; set; }
        //public string RoleName { get; set; }
    }
}
