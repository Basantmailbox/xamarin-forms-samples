﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class PackageDto
    {
        public int PackageId { get; set; }
        public string PackageName { get; set; }
        public string TestCount { get; set; }
        public string TestNames { get; set; }
        public string OfferPrice { get; set; }
        public string ActualPrice { get; set; }
        public string OffAmount { get; set; }
        public bool IsHWPackage { get; set; }
        public string CreatedDate { get; set; }
        public string Description { get; set; }

        public bool IsPackage { get; set; }

        public string MappedPkgIds { get; set; }
        public int PartnerId { get; set; }

        public int Earning { get; set; }
        public string PackageType { get; set; }

        public string PreInfo { get; set; }

        public string Availabilty { get; set; }

    }
}
