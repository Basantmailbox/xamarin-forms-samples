﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class LoggedUserDto
    {
        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public string LoginId { get; set; }
        public string Password { get; set; }
        public string Balance { get; set; }
        public string Token { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
