﻿
namespace PartnerHW.DTOs
{
    public class OrderHistoryDayWise
    {
        public int PartnerId { get; set; }
        public string OrderDate { get; set; }
        public int PickedOrder { get; set; }
        public string PickedRevenue { get; set; }
        public string PartnerEarning { get; set; }
        public string MyEarning { get; set; }
        public string OrderId { get; set; }
        public string Status { get; set; }
        public string Amount { get; set; }
        public string CustomerName { get; set; }
    }
}
