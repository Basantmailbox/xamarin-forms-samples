﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
    public class ResponseResultDto
    {
        public int StatusCode { get; set; }
        public string MSG { get; set; }
        public dynamic Data { get; set; }
    }
}
