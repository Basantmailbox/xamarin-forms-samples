﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerHW.DTOs
{
    public class GoogleAPIGeoAddressResultDto
    {
        public string GeoPlaceId { get; set; }
        public string GeoPlaceName { get; set; }
        
    }
}