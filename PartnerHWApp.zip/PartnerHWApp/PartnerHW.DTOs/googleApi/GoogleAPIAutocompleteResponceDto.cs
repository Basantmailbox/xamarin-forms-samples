﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerHW.DTOs
{
    public class GoogleAPIAutocompleteResponceDto
    {
        public GoogleAPIAutocompleteResponceDto()
        {
            //
            // TODO: Add constructor logic here
            //
        }


    }
}