﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
  public class ReportSpentDto
    {
        public int SpentAmount { get; set; }

        public int Percentage { get; set; }

        public string SpentDate { get; set; }

        public string SpentOn { get; set; }

        
    }
}
