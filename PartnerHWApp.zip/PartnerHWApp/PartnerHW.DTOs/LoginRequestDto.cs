﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class LoginRequestDto
    {
        public string LoginId { get; set; }
        public string Password { get; set; }

        public bool IsRemamberMe { get; set; }
    }
}
