﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
    public class VirtualOfficeDto
    {
        public int VOfficeId { get; set; }
        public string VOfficeName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string GeoAddress { get; set; }
        public string Landmark { get; set; }
        public string GeoLongitude { get; set; }
        public string GeoLatitude { get; set; }
        public string Pincode { get; set; }
        public string Zone { get; set; }
        public int CityId { get; set; }
        public string ContactName { get; set; }
        public string ContactNo { get; set; }
        public bool IsActive { get; set; }
        public string HouseNo { get; set; }
        public string BlockNo { get; set; }
        public string FloorNo { get; set; }
        public string Area { get; set; }
        public int PartnerId { get; set; }
        public string AvailableCredit { get; set; }

        //public int isdeletable { get; set; }

    }


    //public class VirtualOffice
    //{
    //    public int ccd_Id { get; set; }
    //    public string ClinicName { get; set; }
    //    public string Address1 { get; set; }
    //    public string Address2 { get; set; }
    //    public string GeoAddress { get; set; }
    //    public string Landmark { get; set; }
    //    public string GeoLongitude { get; set; }
    //    public string GeoLatitude { get; set; }
    //    public string Pincode { get; set; }
    //    public int CityId { get; set; }
    //    public string ContactName { get; set; }
    //    public string ContactNo { get; set; }
    //    public string Status_info { get; set; }
    //    public string HouseNo { get; set; }
    //    public string BlockNo { get; set; }
    //    public string FloorNo { get; set; }
    //    public string Area { get; set; }
    //    public int UserId { get; set; }

    //    public int City_Id { get; set; }

    //    public int isdeletable { get; set; }

    //}
}
