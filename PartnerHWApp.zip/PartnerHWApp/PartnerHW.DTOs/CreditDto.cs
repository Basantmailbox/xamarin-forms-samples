﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
    public class CreditBuy
    {
        public int PromoCodeId { get; set; }
        public int UserId { get; set; }
        public string PaymentMode { get; set; }
        public string RechargeAmount { get; set; }

        public string Remarks { get; set; }
    }

    public class CreditAllocated
    {
        public string PartnerName { get; set; }
        public string PartnerType { get; set; }
        public string AvailableCredit { get; set; }

        public string AllocateCredits { get; set; }

        public string CreditLimitReminder { get; set; }

        public string myEarning { get; set; }

        public int PartnerId { get; set; }

    }

    public class CreditTransectionHistory
    {
        public string TransectionId { get; set; }
        public string TransectionDate { get; set; }
        public string AssignedCredit { get; set; }

        public int PartnerId { get; set; }
    }





}
