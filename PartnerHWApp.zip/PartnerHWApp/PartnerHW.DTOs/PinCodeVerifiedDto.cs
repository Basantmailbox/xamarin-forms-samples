﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
    //public class PinCodeVerifiedDto
    //{
    //    public string GoogleKey;
    //    public List<CityStateDto> CityStates;
    //}

    
}
