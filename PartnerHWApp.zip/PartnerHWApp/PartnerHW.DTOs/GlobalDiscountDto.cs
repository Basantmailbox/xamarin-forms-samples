﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
    public class GlobalDiscountDto
    {
        public int GlobalDiscountId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int GlobalDiscount { get; set; }
        public bool IsActive { get; set; }
        public int PartnerId { get; set; }
    }
}
