﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class RoleDto
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleDisplayName { get; set; }
    }
}
