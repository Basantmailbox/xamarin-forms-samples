﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
   public class PromoCodeDto : RoleDto
    {
        public int PromoCodeId { get; set; }
        public int PartnerId { get; set; }

        public string PromoCodeName { get; set; }
        public string PromoType { get; set; }

        public int AppliedCounter { get; set; }
        public int Discount { get; set; }
        public string Description { get; set; }
        public string CreatedDate { get; set; }
        public bool IsActive { get; set; }
        public string EmployeeId { get; set; }
        public string PartnerName { get; set; }
        public int UId { get; set; }
        //public string DiscountType { get; set; }
        public DateTime ValidTo { get; set; }
        public DateTime ValidFrom { get; set; }
        public int MinAmount { get; set; }
        public bool IsExpired { get; set; }
        

    }
}
