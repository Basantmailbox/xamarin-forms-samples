﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.DTOs
{
    public class CityStateDto
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public int StateId { get; set; }
        public string StateName { get; set; }
        public string BlockName { get; set; }
        public string District { get; set; }
        
        public string Pincode { get; set; }
        public int UserId { get; set; }
        public string GoogleKey { get; set; }

    }
}
