﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IHWPublicRepository
    {
        bool GetlinkedinSaleData();
       
    }
}
