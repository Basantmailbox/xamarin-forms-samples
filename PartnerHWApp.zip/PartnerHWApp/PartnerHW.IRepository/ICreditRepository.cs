﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface ICreditRepository
    {
        bool Buy(CreditBuy entityObj);
        List<CreditAllocated> GetAllocated(int partnerId);

        List<CreditTransectionHistory> GetTransectionHistory(int partnerId);
        
    }
}
