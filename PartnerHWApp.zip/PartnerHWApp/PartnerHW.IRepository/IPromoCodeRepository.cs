﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IPromoCodeRepository
    {
        PromoCodeDto InsertNew(PromoCodeDto entityObj);
        PromoCodeDto InsertNewBulck(int partnerId, DateTime promoDate, int promoCodeCount = 99);
        List<PromoCodeDto> GetByPromoCode(string promocodeName, int partnerId = 0);
        List<PromoCodeDto> GetByPartnerId(int partnerId);
        bool SetDeactive(int promocodeId, int userId);
        List<PromoCodeDto> GetValidRechargePromo();
        List<PromoCodeDto> GetValidBookingPromo();
        List<PromoCodeDto> GetAll();
        PromoCodeDto AppliedPromoValidate(PromoCodeDto entityObj);
    }
}
