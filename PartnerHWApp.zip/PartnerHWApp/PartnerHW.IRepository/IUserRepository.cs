﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IUserRepository
    {
        LoggedUserDto Authenticate(string username, string password);
        string GetGoogleAPIKey(int partnerId);
        IEnumerable<LoggedUserDto> GetAll();
    }
}
