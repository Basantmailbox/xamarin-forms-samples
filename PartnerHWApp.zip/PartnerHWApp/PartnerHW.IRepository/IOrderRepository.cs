﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IOrderRepository
    {
        List<OrderHistoryDayWise> GetPartnerHistoryDayWise(int partnerId);
        List<OrderHistoryDayWise> GetPartnerHistoryOneDay(int partnerId, string orderDate);
        
    }
}
