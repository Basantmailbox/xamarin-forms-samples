﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;
using static PartnerHW.Core.AppEnum;

namespace PartnerHW.IRepository
{
   public interface IReportRepository
    {
        List<ReportSpentDto> GetSpent(int partnerId, EnumSpentTenure tenure, EnumSpentOn spentOn);
    }
}
