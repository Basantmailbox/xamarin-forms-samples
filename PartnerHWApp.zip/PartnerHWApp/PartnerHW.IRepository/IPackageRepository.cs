﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IPackageRepository
    {
        PartnerDto InsertNew(PackageDto entityObj);
        List<PackageDto> GetPackage4Booking();
        List<PackageDto> GetMyPackages(int partnerId);
        List<PackageDto> GetMyPackageDetails(int partnerId, int packageId);
        List<PackageDto> GetHWPackages();
    }
}
