﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IVirtualOfficeRepository
    {
        PartnerDto SetNewEntity(VirtualOfficeDto entotyObj);
        List<VirtualOfficeDto> GetByPartnerId(string partnerId);
    }
}
