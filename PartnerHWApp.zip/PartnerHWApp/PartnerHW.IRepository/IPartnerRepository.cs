﻿using PartnerHW.DTOs;
using PartnerHW.Core;
using System;
using System.Collections.Generic;
using System.Text;
using static PartnerHW.Core.AppEnum;

namespace PartnerHW.IRepository
{
   public interface IPartnerRepository
    {
        PartnerDto InsertEntity(PartnerDto entityObj);
        bool UpdateEntity(PartnerDto entityObj);
        PartnerDto GetById(int partnerId);
        List<PartnerDto> GetMyPartner(int partnerId);
        List<PartnerDto> GetByRole(AppEnum.RoleType partnerType);
        List<PartnerDto> GetByRole(AppEnum.RoleType partnerType, int partnerId);
        List<PartnerDto> GetPartnerApprovalPending();
        List<PartnerDto> GetPartnerApprovalPending(int roleId);
        List<PartnerDto> GetPartnerApprovalPending(int partnerId, int roleId = 0);
        List<PartnerDto> GetMinBalanceMyPartners(int partnerId);
        List<PartnerChartDto> GetMyPartners4Chart(int partnerId);
        PartnerDto GetPartner(int partnerId);
        PartnerDto GetCurrentPoints(int partnerId);

    }
}
