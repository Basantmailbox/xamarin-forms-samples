﻿using PartnerHW.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.IRepository
{
   public interface IGlobalDiscountRepository
    {
        GlobalDiscountDto GetByPartnerId(int partnerId);
        bool InsertOrUpdate(GlobalDiscountDto entityObj);
    }
}
