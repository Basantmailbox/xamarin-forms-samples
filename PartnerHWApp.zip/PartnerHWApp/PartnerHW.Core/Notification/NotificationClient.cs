﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json;
//using System.Web.Script.Serialization;

namespace PartnerHW.Core.Notification
{
  public class NotificationClient
    {
        #region GCMNotification
        public void SendNotification(string deviceId, string message, string image, string title, string type1, int customerid)
        {
            try
            {
                var applicationID = "AIzaSyDg-Ux3O1aSjKVBWC0PB2SCqBRLWRbGPPU";
                var senderId = "54130990034";
               
                WebRequest tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
                tRequest.Method = "post";
                tRequest.ContentType = "application/json";
                var data = new
                {
                    priority = "high",
                    to = deviceId,
                    data = new
                    {
                        type = type1,
                        body = message,
                        title = title,
                        icon = image,
                        id = customerid,
                    }
                };

                var json = JsonConvert.SerializeObject(data);

                //var serializer = new JavaScriptSerializer();
                //var json = serializer.Serialize(data);
                Byte[] byteArray = Encoding.UTF8.GetBytes(json);
                tRequest.Headers.Add(string.Format("Authorization: key={0}", applicationID));
                tRequest.Headers.Add(string.Format("Sender: id={0}", senderId));
                tRequest.ContentLength = byteArray.Length;

                using (Stream dataStream = tRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse tResponse = tRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = tResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();

                                Console.Write(sResponseFromServer);
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
        }

        #endregion
    }
}
