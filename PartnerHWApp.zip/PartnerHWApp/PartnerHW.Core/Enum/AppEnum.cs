﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartnerHW.Core
{
    public class AppEnum
    {
        public enum RoleType : int
        {
            ADMIN = 44,
            PLATINUM = 45,
            VOffice = 46,
            SILVER = 81,
            GOLD = 82
        }

        public enum StatusCode : int
        {
            SUCCESS = 101,
            ERROR = 102
        }

        public enum EnumPaymentMode : int
        {
            BANK_TRANSFER = 1,
            CASH = 2,
            //CHECK=3,
            CARD = 4,
            PAYTM = 5
        }

        public enum EnumSpentOn : int
        {
            BOTH = 0,
            SELF = 1,
            PARTNER = 2
        }

        public enum EnumSpentTenure : int
        {
            All = 0,
            DAY = 1,
            WEEKLY = 2,
            MONTHLY = 3
        }
    }
}
