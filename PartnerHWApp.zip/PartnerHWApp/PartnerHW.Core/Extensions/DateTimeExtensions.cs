﻿
namespace PartnerHW.Core.Extensions
{
    using System;
    using System.Globalization;

    public static class DateTimeExtensions
    {
        //ToDateTime(format: "ddMMyyyy");
        public static DateTime ToDateTime(this string s, string format = "ddMMyyyy", string cultureString = "tr-TR")
        {
            try
            {
                var r = DateTime.ParseExact(
                    s: s, format: format, provider: CultureInfo.GetCultureInfo(cultureString));
                return r;
            }
            catch (FormatException)
            {
                throw;
            }
            catch (CultureNotFoundException)
            {
                throw; // Given Culture is not supported culture
            }
        }
        
        //ToDateTime("yyyy/d MMMM", cultureString: "en-US");
        public static DateTime ToDateTime(this string s, string format, CultureInfo culture)
        {
            try
            {
                var r = DateTime.ParseExact(s: s, format: format, provider: culture);
                return r;
            }
            catch (FormatException)
            {
                throw;
            }
            catch (CultureNotFoundException)
            {
                throw; // Given Culture is not supported culture
            }

        }


        /// <summary>
        /// Returns formatted date string in Database timestamp format.
        /// </summary>
        public static string DisplayFormat(this DateTime date)
        {
            return date.ToString("dd MMMM, yyyy");
        }

    }
}
