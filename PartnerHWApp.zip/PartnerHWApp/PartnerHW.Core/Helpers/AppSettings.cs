﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PartnerHW.Core.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
