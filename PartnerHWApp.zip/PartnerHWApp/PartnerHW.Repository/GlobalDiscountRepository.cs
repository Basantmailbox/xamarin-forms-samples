﻿using System;
using System.Linq;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class GlobalDiscountRepository : BaseRepository, IGlobalDiscountRepository
    {
        public GlobalDiscountDto GetByPartnerId(int partnerId)
        {
            GlobalDiscountDto newEntityObj = new GlobalDiscountDto();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@userId", partnerId);

                //string cmdStr = "select * from App_client_clinic_global_discount where status_info=1 and clientid=" + partnerId;
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "spAPI_GetGlobalDiscount", param: parameters, commandType: StoredProcedure).ToList();

                if (dataDynamic.Count > 0)
                {
                    var firstobj = dataDynamic.FirstOrDefault();
                    newEntityObj.FromDate = firstobj.from_date;
                    newEntityObj.ToDate = firstobj.to_date;
                    newEntityObj.GlobalDiscount = firstobj.global_discount;
                    newEntityObj.IsActive = firstobj.Status_Info==1?true:false;
                    newEntityObj.PartnerId = firstobj.clientID;
                }
                return newEntityObj;
            }
            catch (Exception ex)
            {
                return newEntityObj;
            }
        }
        public bool InsertOrUpdate(GlobalDiscountDto entityObj)
        {
            CreditBuy ewEntityObj = new CreditBuy();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@partnerId", entityObj.PartnerId);
                parameters.Add("@fromDate", entityObj.FromDate);
                parameters.Add("@toDate", entityObj.ToDate);
                parameters.Add("@globalDiscout", entityObj.GlobalDiscount);
                //parameters.Output("@outStatus",);
                //OLD App_client_clinic_global_discount_insert
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "spAPI_GlobalDiscountInsert", param: parameters, commandType: StoredProcedure);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}
