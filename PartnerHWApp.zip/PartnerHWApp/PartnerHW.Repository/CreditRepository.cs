﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core.Extensions;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class CreditRepository : BaseRepository, ICreditRepository
    {
        public bool Buy(CreditBuy entityObj)
        {
            CreditBuy newEntityObj = new CreditBuy();
            try
            {
                entityObj.Remarks = "";
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@user_id", entityObj.UserId);
                parameters.Add("@mihpayid", "1234");
                parameters.Add("@txnid", "4567");
                parameters.Add("@pay_amount", entityObj.RechargeAmount);
                parameters.Add("@pay_method", entityObj.PaymentMode);
                parameters.Add("@payment_remark", entityObj.Remarks);
                parameters.Add("@payment_recieved_By", entityObj.UserId);
                parameters.Add("@payment_receive", "1");
                parameters.Add("@promoCodeId", entityObj.PromoCodeId);

                //OLD sp_D_insert_credit_payment
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "spAPI_CreditBuy", param: parameters, commandType: StoredProcedure);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<CreditAllocated> GetAllocated(int partnerId)
        {
            List<CreditAllocated> newEntityObj = new List<CreditAllocated>();
            try
            {
                

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@partnerId", partnerId);

                newEntityObj = SqlMapper.Query<CreditAllocated>(_connectionSQL, "spAPI_GetReportAllocated", param: parameters, commandType: StoredProcedure).ToList();

                //CreditAllocated fff = new CreditAllocated();
                //fff.PartnerName = "Partner1";
                //fff.PartnerType = "Gold";
                //fff.CurrentBalance = "200202";
                //fff.AllocateCredits = "AllocateCredits";
                //fff.CreditLimitReminder = "?";
                //fff.SelfEarning = "3003";
                //fff.PartnerEarning = "5969";
                //fff.PartnerId = 1065;
                //newEntityObj.Add(fff);
                return newEntityObj;
            }
            catch (Exception ex)
            {
                return newEntityObj;
            }
        }

        


        public List<CreditTransectionHistory> GetTransectionHistory(int partnerId)
        {
            List<CreditTransectionHistory> returnObj = new List<CreditTransectionHistory>();
            try
            {
                CreditTransectionHistory newObj = new CreditTransectionHistory();
                newObj.TransectionId = "Partner1";
                newObj.AssignedCredit = "40000";
                newObj.TransectionDate = DateTime.Now.DisplayFormat();
                newObj.PartnerId = 1065;
                returnObj.Add(newObj);
                return returnObj;
            }
            catch (Exception ex)
            {
                return returnObj;
            }
        }


    }
}
