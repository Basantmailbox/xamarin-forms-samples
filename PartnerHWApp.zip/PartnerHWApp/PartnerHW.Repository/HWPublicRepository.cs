﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core.Utilities;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class HWPublicRepository : BaseRepository, IHWPublicRepository
    {
  

        public HWPublicRepository()
        {
           

        }

        //private List<PromoCodeDto> Table2Dto(List<dynamic> dynamicDtos)
        //{
        //    List<PromoCodeDto> returnObjs = new List<PromoCodeDto>();
        //    try
        //    {
        //        if (dynamicDtos.Count > 0)
        //        {
        //            PromoCodeDto entityObj;
        //            foreach (var item in dynamicDtos)
        //            {
        //                entityObj = new PromoCodeDto();
        //                entityObj.PromoCodeId = item.C_ID;
        //                entityObj.UserId = item.USER_ID;
        //                entityObj.PromoCodeName = item.COUPON_CODE;
        //                entityObj.PromoType = item.PromoType;
        //                entityObj.Discount = item.DISCOUNT;
        //                entityObj.DiscountType = item.DiscountType;
        //                entityObj.Description = item.DESCRIPTION;
        //                entityObj.CreatedDate = item.CREATED_DATE.ToString();
        //                entityObj.IsActive = item.STATUS_INFO == 0 ? false : true;
        //                entityObj.RoleId = item.r_id;
        //                entityObj.RoleName = item.r_role_name;
        //                entityObj.RoleDisplayName = item.show_role_name;
        //                entityObj.EmpId = item.U_emp_id;
        //                entityObj.UserName = item.username;
        //                entityObj.ValidFrom = item.ValidFrom;
        //                entityObj.ValidTo = item.ValidTo;
        //                entityObj.IsExpired = item.IsExpired == 0 ? true : false;
        //                entityObj.MinAmount = item.MinAmount;
        //                entityObj.UId = item.u_id;
        //                returnObjs.Add(entityObj);
        //            }

        //        }
        //        return returnObjs.OrderBy(d => d.PromoCodeName).ToList();
        //    }
        //    catch (Exception ex)
        //    {
        //        return returnObjs;
        //    }

        //}
        public bool GetlinkedinSaleData()
        {
            PromoCodeDto promoCodeDto = new PromoCodeDto();
            try
            {
                return true;

            }
            catch (Exception)
            {
                return false;
            }
        }



    }
}
