﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class CityRepository : BaseRepository, ICityRepository
    {
        public List<CityStateDto> GetCityStateWithPinCode(CityStateDto entityObj)
        {
            List<CityStateDto> cityStateDtos = new List<CityStateDto>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@blockName", entityObj.BlockName);
                parameters.Add("@cityName", entityObj.CityName);
                parameters.Add("@stateName", entityObj.StateName);
                parameters.Add("@pincode", entityObj.Pincode);
                parameters.Add("@userId", entityObj.UserId);
                parameters.Add("@googleKey", "");

                //OLD usp_Fetch_CityStateWithPinCode_V2
                cityStateDtos = SqlMapper.Query<CityStateDto>(_connectionSQL, "sp_GetCityStateWithPinCode", param: parameters, commandType: StoredProcedure).ToList();

                return cityStateDtos;
            }
            catch (Exception ex)
            {
                return cityStateDtos;
            }
        }
    }
}
