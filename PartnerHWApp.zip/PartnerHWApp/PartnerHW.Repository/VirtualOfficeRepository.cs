﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core.Utilities;
using PartnerHW.IRepository;
using static System.Data.CommandType;
using static PartnerHW.Core.AppEnum;

namespace PartnerHW.Repository
{
    public class VirtualOfficeRepository : BaseRepository, IVirtualOfficeRepository
    {

        //spAPI_ClinicDebitByBooking
        HWEncryptDecrypt _hWEncryptDecrypt;

        public VirtualOfficeRepository()
        {
            if (_hWEncryptDecrypt == null)
            {
                _hWEncryptDecrypt = new HWEncryptDecrypt();
            }

        }

        private List<VirtualOfficeDto> Table2Dto(List<dynamic> dynamicDtos)
        {
            List<VirtualOfficeDto> returnObjs = new List<VirtualOfficeDto>();
            try
            {
                if (dynamicDtos.Count > 0)
                {
                    VirtualOfficeDto entityObj;
                    foreach (var item in dynamicDtos)
                    {
                        entityObj = new VirtualOfficeDto();
                        entityObj.VOfficeId = item.VOfficeId;
                        entityObj.PartnerId = item.PartnerId;
                        entityObj.VOfficeName = item.VOfficeName;
                        entityObj.Address1 = item.Address1;
                        entityObj.Address2 = item.Address2;
                        entityObj.GeoAddress = item.GeoAddress;
                        entityObj.Landmark = item.Landmark;
                        entityObj.GeoLongitude = item.GeoLongitude;
                        entityObj.GeoLatitude = item.GeoLatitude;
                        entityObj.Pincode = item.Pincode;
                        entityObj.CityId = item.CityId;
                        entityObj.Zone = item.Zone;
                        entityObj.IsActive = item.status_info == 0 ? false : true;
                        entityObj.ContactName = item.ContactName;
                        entityObj.ContactNo = _hWEncryptDecrypt.DecryptCRM(item.ContactNo);
                        entityObj.BlockNo = item.BlockNo;
                        entityObj.FloorNo = item.FloorNo;
                        entityObj.HouseNo = item.HouseNo;
                        entityObj.Area = item.Area;
                        entityObj.AvailableCredit = Convert.ToString(item.AvailableCredit);
                        returnObjs.Add(entityObj);
                    }

                }
                return returnObjs.OrderByDescending(d => d.VOfficeId).ToList();
            }
            catch (Exception ex)
            {
                return returnObjs;
            }

        }

        public PartnerDto SetNewEntity(VirtualOfficeDto entityObj)
        {
            try
            {
                entityObj.Address1 = entityObj.HouseNo+"," + entityObj.FloorNo + "," + entityObj.BlockNo + "," + entityObj.Area;
                var newPassword= HWEncryptDecrypt.CRM4Encrypt(entityObj.ContactNo);
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@userId", entityObj.PartnerId);
                parameters.Add("@clinicName", entityObj.VOfficeName);
                parameters.Add("@address1", entityObj.Address1);
                parameters.Add("@address2", "");
                parameters.Add("@geoAddress", entityObj.GeoAddress);
                parameters.Add("@landmark", entityObj.Landmark);
                parameters.Add("@longitude", entityObj.GeoLongitude);
                parameters.Add("@latitude", entityObj.GeoLatitude);
                parameters.Add("@pincode", entityObj.Pincode);
                parameters.Add("@cityId", entityObj.CityId);
                parameters.Add("@contactName", entityObj.ContactName);
                parameters.Add("@mobileNo", newPassword);
                parameters.Add("@houseNo", entityObj.HouseNo);
                parameters.Add("@blockNo", entityObj.BlockNo);
                parameters.Add("@floorNo", entityObj.FloorNo);
                parameters.Add("@area", entityObj.Area);
                parameters.Add("@roleId", (int)RoleType.VOffice);
                parameters.Add("@u_password", newPassword);
                //sp_app_client_SaveClinicAddress
               PartnerDto returnObj =  SqlMapper.Query<PartnerDto>(_connectionSQL, "spAPI_PartnerClinicCreate", param: parameters, commandType: StoredProcedure).FirstOrDefault();
                return returnObj;
            }
            catch (Exception ex)
            {
                return null;
            }
     
        }


        public List<VirtualOfficeDto> GetByPartnerId(string partnerId)
        {
            List<VirtualOfficeDto> virtualOffices = new List<VirtualOfficeDto>();
            try
            {
                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@userId", partnerId);

                // SqlMapper.Execute(_connectionSQL, "sp_app_client_GetClinicAddresses", param: parameters, commandType: StoredProcedure);

                string cmdStr = "SELECT * FROM viewAPI_PartnerClinics WHERE ReportingToId="+ partnerId;
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();

                //var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "", param: parameters, commandType: StoredProcedure).ToList();
                virtualOffices = Table2Dto(dataDynamic);

                return virtualOffices;
            }
            catch (Exception ex)
            {
                return virtualOffices;
            }
            
        }

    }
}
