﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core.Utilities;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class PromoCodeRepository : BaseRepository, IPromoCodeRepository
    {
        HWEncryptDecrypt _hWEncryptDecrypt;

        public PromoCodeRepository()
        {
            if (_hWEncryptDecrypt == null)
            {
                _hWEncryptDecrypt = new HWEncryptDecrypt();
            }

        }

        private List<PromoCodeDto> Table2Dto(List<dynamic> dynamicDtos)
        {
            List<PromoCodeDto> returnObjs = new List<PromoCodeDto>();
            try
            {
                if (dynamicDtos.Count > 0)
                {
                    PromoCodeDto entityObj;
                    foreach (var item in dynamicDtos)
                    {
                        entityObj = new PromoCodeDto();
                        entityObj.PromoCodeId = item.PromoCodeId;
                        entityObj.PartnerId = item.PartnerId;
                        entityObj.PromoCodeName = item.PromoCodeName;
                        entityObj.PromoType = item.PromoType;
                        entityObj.Discount = item.Discount;
                        entityObj.Description = item.Description;
                        entityObj.CreatedDate = item.CreatedDate.ToString();
                        entityObj.IsActive = item.IsActive == 0 ? false : true;
                        entityObj.RoleId = item.RoleId;
                        entityObj.RoleName = item.RoleName;
                        entityObj.RoleDisplayName = item.RoleDisplayName;
                        entityObj.EmployeeId = item.EmployeeId;
                        entityObj.PartnerName = item.PartnerName;
                        entityObj.ValidFrom = item.ValidFrom;
                        entityObj.ValidTo = item.ValidTo;
                        entityObj.IsExpired = item.IsExpired == 0 ? true : false;
                        entityObj.MinAmount = item.MinAmount;
                        entityObj.UId = item.UId;
                        entityObj.AppliedCounter = item.AppliedCounter;
                        returnObjs.Add(entityObj);
                    }

                }
                return returnObjs.OrderBy(d => d.PromoCodeName).ToList();
            }
            catch (Exception ex)
            {
                return returnObjs;
            }

        }
        public PromoCodeDto InsertNew(PromoCodeDto entityObj)
        {
            PromoCodeDto promoCodeDto = new PromoCodeDto();
            try
            {
                StringBuilder cmdStr = new StringBuilder();
                cmdStr.Append("INSERT INTO BlueApp_Coupon(COUPON_CODE, DISCOUNT, DESCRIPTION, USER_ID, CREATED_DATE, STATUS_INFO,PromoType,ValidTo,ValidFrom,MinAmount)");
                cmdStr.Append("VALUES('" + entityObj.PromoCodeName + "', " + entityObj.Discount + ", '" + entityObj.Description + "', " + entityObj.PartnerId + ", GETDATE(), 1,'" + entityObj.PromoType + "','"+ entityObj.ValidTo + "','" + entityObj.ValidFrom + "'," + entityObj.MinAmount + ")");

                var dataDynamic = SqlMapper.Query(_connectionSQL, cmdStr.ToString());

                List<PromoCodeDto> promoCodeDtos = GetByPromoCode(entityObj.PromoCodeName, entityObj.PartnerId);

                if (promoCodeDtos.Count > 0)
                {
                    promoCodeDto = promoCodeDtos.FirstOrDefault();
                }
                return promoCodeDto;

            }
            catch (Exception)
            {
                return promoCodeDto;
            }
        }

        public PromoCodeDto InsertNewBulck(int partnerId, DateTime promoDate, int promoCodeCount = 99)
        {
            PromoCodeDto promoCodeDto = new PromoCodeDto();
            try
            {
                //string yearDigit = promoDate.Year.ToString().Substring(2, 2).PadLeft(2, '0');
                //string monthDigit = promoDate.Month.ToString().PadLeft(2, '0');
                //string dayDigit = promoDate.Day.ToString().PadLeft(2, '0');

                StringBuilder cmdStr = new StringBuilder();
                cmdStr.Append("SELECT u_name FROM user_informations Where userId=" + partnerId);

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr.ToString()).ToList();

                Random randomProc = new Random();


                if (dataDynamic.Count > 0)
                {
                    string userName = dataDynamic[0].u_name;
                    if (!string.IsNullOrEmpty(userName))
                    {
                        userName = "SWP";//userName.Substring(0, 3).ToUpper();

                        int updateCounter = 1;


                        for (int i = 1; i <= promoCodeCount; i++)
                        {
                            var randomNo = randomProc.Next(0, 1000000);
                            string newpromoCode = userName + randomNo.ToString("000000");
                            cmdStr.Append("INSERT INTO BlueApp_Coupon(COUPON_CODE, DISCOUNT,PromoType, DESCRIPTION, USER_ID, CREATED_DATE, STATUS_INFO) ");
                            cmdStr.Append("VALUES('" + newpromoCode + "', 999,'B','NA', " + partnerId + ", GETDATE(), 1);");

                            if (updateCounter >= 100)
                            {
                                try
                                {
                                    SqlMapper.Query(_connectionSQL, cmdStr.ToString());
                                    cmdStr.Clear();
                                    updateCounter = 1;
                                }
                                catch (Exception)
                                {

                                    throw;
                                }

                            }
                            else
                            {
                                updateCounter++;
                            }


                        }
                    }
                }

                if (!string.IsNullOrEmpty(cmdStr.ToString()))
                {
                    SqlMapper.Query(_connectionSQL, cmdStr.ToString());
                }
                return promoCodeDto;
            }
            catch (Exception)
            {
                return promoCodeDto;
            }
        }

        public List<PromoCodeDto> GetByPromoCode(string promocodeName, int partnerId = 0)
        {
            List<PromoCodeDto> promoCodeDtos = new List<PromoCodeDto>();
            try
            {
                StringBuilder cmdStr = new StringBuilder();
                if (partnerId > 0)
                {
                    cmdStr.Append("SELECT * FROM ViewAPI_PromoCodes WHERE PartnerId=" + partnerId + " AND PromoCodeName='" + promocodeName + "' Order by PromoCodeId DESC");
                }
                else
                {
                    cmdStr.Append("SELECT * FROM ViewAPI_PromoCodes WHERE PromoCodeName='" + promocodeName + "' Order by PromoCodeId DESC");
                }

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr.ToString()).ToList();
                promoCodeDtos = Table2Dto(dataDynamic);

                return promoCodeDtos;
            }
            catch (Exception)
            {
                return promoCodeDtos;
            }

        }
        public List<PromoCodeDto> GetByPartnerId(int partnerId)
        {
            List<PromoCodeDto> promoCodeDtos = new List<PromoCodeDto>();
            try
            {
                string cmdStr = "SELECT * from ViewAPI_PromoCodes WHERE PartnerId=" + partnerId;
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                promoCodeDtos = Table2Dto(dataDynamic);

                return promoCodeDtos;
            }
            catch (Exception ex)
            {
                return promoCodeDtos;
            }

        }

        public List<PromoCodeDto> GetAll()
        {
            List<PromoCodeDto> promoCodeDtos = new List<PromoCodeDto>();
            try
            {
                string cmdStr = "SELECT * from ViewAPI_PromoCodes";
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                promoCodeDtos = Table2Dto(dataDynamic);

                return promoCodeDtos;
            }
            catch (Exception ex)
            {
                return promoCodeDtos;
            }

        }
        public bool SetDeactive(int promocodeId, int userId)
        {
            try
            {
                string cmdStr = "UPDATE BlueApp_Coupon SET STATUS_INFO=0, UPDATED_DATE=GETDATE() WHERE C_ID=" + promocodeId + " AND USER_ID=" + userId;
                var dataDynamic = SqlMapper.Query(_connectionSQL, cmdStr);

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public List<PromoCodeDto> GetValidRechargePromo()
        {
            List<PromoCodeDto> promoCodeDtos = new List<PromoCodeDto>();
            try
            {
                string cmdStr = "SELECT * from ViewAPI_PromoCodes WHERE PromoType='R' AND IsActive=1";
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                promoCodeDtos = Table2Dto(dataDynamic);

                return promoCodeDtos;
            }
            catch (Exception ex)
            {
                return promoCodeDtos;
            }

        }
        public List<PromoCodeDto> GetValidBookingPromo()
        {
            List<PromoCodeDto> promoCodeDtos = new List<PromoCodeDto>();
            try
            {
                string cmdStr = "SELECT * from ViewAPI_PromoCodes WHERE PromoType='B' AND IsActive=1";
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                promoCodeDtos = Table2Dto(dataDynamic);

                return promoCodeDtos;
            }
            catch (Exception ex)
            {
                return promoCodeDtos;
            }

        }




        public PromoCodeDto AppliedPromoValidate(PromoCodeDto entityObj)
        {
            PromoCodeDto promoCodeDto = new PromoCodeDto();
            try
            {
                StringBuilder cmdStr = new StringBuilder();
                cmdStr.Append("SELECT * from ViewAPI_PromoCodes Where IsActive=1 and PromoCodeName='" + entityObj.PromoCodeName + "' AND PromoType='" + entityObj.PromoType + "' AND MinAmount<="+ entityObj.MinAmount+ " AND IsExpired=0");

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr.ToString()).ToList();


                var promoCodeDtos = Table2Dto(dataDynamic);

                if (promoCodeDtos.Count > 0)
                {
                    promoCodeDto = promoCodeDtos.FirstOrDefault();
                }
                return promoCodeDto;

            }
            catch (Exception)
            {
                return promoCodeDto;
            }
        }


    }
}
