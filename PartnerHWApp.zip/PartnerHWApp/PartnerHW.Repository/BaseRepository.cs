﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;


namespace PartnerHW.Repository
{
    public class BaseRepository : IDisposable
    {
        protected IDbConnection _connectionSQL;
        public BaseRepository()
        {
            string connectionString = "Data Source=tcp:hwdevelopment.database.windows.net,1433; Integrated Security=false;Initial Catalog=HW_developer; uid=hwdevelopment; Password= hindu!@#123;";
            _connectionSQL = new SqlConnection(connectionString);
        }

        public void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
