﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core;
using PartnerHW.Core.Utilities;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class PartnerRepository : BaseRepository, IPartnerRepository
    {
      

        //public IList<PartnerDto> GetAllUser() => SqlMapper.Query<PartnerDto>(_connectionSQL, "GetAllUsers", commandType: StoredProcedure).ToList();

        private List<PartnerDto> Table2Dto(List<dynamic> dynamicDtos)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {

                if (dynamicDtos.Count > 0)
                {
                    PartnerDto partnerDto;
                    foreach (var item in dynamicDtos)
                    {
                        partnerDto = new PartnerDto();
                        partnerDto.PartnerId = item.PartnerId;
                        partnerDto.PartnerName = item.PartnerName;
                        partnerDto.EmailId = item.EmailId;
                        partnerDto.PartnerType = item.RoleName;
                        partnerDto.DisplayRoleName = item.DisplayRoleName;
                        partnerDto.PartnerTypeId = item.RoleId;
                        partnerDto.MobileNo = item.MobileNo;
                        partnerDto.IsActive = item.IsActive == 0 ? false : true;
                        partnerDto.CreatedBy = 0;
                        partnerDto.AvailableCredit = Convert.ToString(item.AvailableCredit);
                        partnerDtos.Add(partnerDto);
                    }

                    //partnerDtos = (dynamicDtos.Select(item => new PartnerDto()
                    //{
                    //    PartnerId = item.userid,
                    //    FullName = item.u_name,
                    //    EmailId = item.u_email,
                    //    PartnerTypeName = item.r_role_name,
                    //    PartnerTypeId = item.r_id,
                    //    MobileNo = item.u_mobileno,
                    //    IsActive = item.u_enable,
                    //    CreatedBy = 0
                    //})).OrderByDescending(d => d.PartnerId).ToList();
                }
                return partnerDtos.OrderByDescending(d => d.PartnerId).ToList();
            }
            catch (Exception ex)
            {
                return partnerDtos;
            }

        }
        public List<PartnerDto> GetPartnerApprovalPending()
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {
                string cmdStr = "SELECT * FROM viewAPI_Partners WHERE IsActive=0";

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();


                //var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "", param: parameters, commandType: StoredProcedure).ToList();
                partnerDtos = Table2Dto(dataDynamic);
                //(dataDynamic.Select(item => new PartnerDto()
                //                          {
                //                              PartnerId = item.userid,
                //                              FullName = item.u_name,
                //                              EmailId = item.u_email,
                //                              PartnerTypeName = item.r_role_name,
                //                              PartnerTypeId = item.r_id,
                //                              MobileNo = item.u_mobileno,
                //                              CreatedBy = 0
                //                          })).OrderByDescending(d => d.PartnerId).ToList();
                return partnerDtos;
            }
            catch (Exception ex)
            {
                return partnerDtos;
            }

        }
        public List<PartnerDto> GetPartnerApprovalPending(int roleId)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {
                string cmdStr = "SELECT * FROM viewAPI_Partners WHERE IsActive=0 AND RoleId=" + roleId;

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();


                //var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "", param: parameters, commandType: StoredProcedure).ToList();
                partnerDtos = Table2Dto(dataDynamic);
                return partnerDtos;
            }
            catch (Exception)
            {

                return partnerDtos;
            }

        }
        public List<PartnerDto> GetPartnerApprovalPending(int partnerId, int roleId = 0)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {
                string cmdStr = "";
                if (roleId == 0)
                {
                    cmdStr = "SELECT * FROM viewAPI_Partners WHERE IsActive=0 AND RoleId=" + roleId;
                }
                else
                {
                    cmdStr = "SELECT * FROM viewAPI_Partners WHERE IsActive=0 AND RoleId=" + roleId + " AND ReportingTo=" + partnerId;
                }

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();

                partnerDtos = Table2Dto(dataDynamic);
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }


        }
        public PartnerDto InsertEntity(PartnerDto entityObj)
        {
            PartnerDto partnerDto = new PartnerDto();
            try
            {
                entityObj.LoginPassword = HWEncryptDecrypt.User4Encrypt(entityObj.MobileNo);

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@u_name", entityObj.PartnerName);
                parameters.Add("@u_mobileno", entityObj.MobileNo);
                parameters.Add("@u_email", entityObj.EmailId);
                parameters.Add("@userid", entityObj.CreatedBy);
                parameters.Add("@u_password", entityObj.LoginPassword);
                parameters.Add("@user_role_r_id", entityObj.PartnerTypeId);

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "spAPI_PartnerCreate", param: parameters, commandType: StoredProcedure);
                if (dataDynamic != null)
                {
                    partnerDto = (dataDynamic
                                        .Select(item => new PartnerDto()
                                        {
                                            PartnerId = item.PartnerId,
                                            PartnerName = item.FullName,
                                            EmailId = item.EmailId,
                                            PartnerType = item.RoleName,
                                            PartnerTypeId = item.RoleId,
                                            MobileNo = item.MobileNo,
                                            CreatedBy = 0
                                        })).FirstOrDefault();
                }
                return partnerDto;
            }
            catch (Exception ex)
            {
                return partnerDto;
            }
        }
        public PartnerDto GetById(int userId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@CustomerID", userId);
                return SqlMapper.Query<PartnerDto>((SqlConnection)_connectionSQL, "GetUserById", parameters, commandType: StoredProcedure).FirstOrDefault();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public bool UpdateEntity(PartnerDto entityObj)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@UserId", user.UserId);
                //parameters.Add("@UserName", user.UserName);
                //parameters.Add("@UserMobile", user.UserMobile);
                //parameters.Add("@UserEmail", user.UserEmail);
                //parameters.Add("@FaceBookUrl", user.FaceBookUrl);
                //parameters.Add("@LinkedInUrl", user.LinkedInUrl);
                //parameters.Add("@TwitterUrl", user.TwitterUrl);
                //parameters.Add("@PersonalWebUrl", user.PersonalWebUrl);

                SqlMapper.Execute(_connectionSQL, "UpdateUser", param: parameters, commandType: StoredProcedure);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public List<PartnerDto> GetMyPartner(int partnerId)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@userid", partnerId);
                string cmdStr = "SELECT * FROM viewAPI_Partners WHERE ReportingTo=" + partnerId;

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();

                //var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "spAPI_GetMyPartner", param: parameters, commandType: StoredProcedure).ToList();
                partnerDtos = Table2Dto(dataDynamic);
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }


            //return _users;
        }
        public List<PartnerDto> GetByRole(AppEnum.RoleType partnerType)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {
                string cmdStr = "SELECT viewAPI_Partners FROM view_Partners WHERE RoleId=" + (int)partnerType;

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();

                partnerDtos = Table2Dto(dataDynamic);
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }

        }
        public List<PartnerDto> GetByRole(AppEnum.RoleType partnerType, int partnerId)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {
                string cmdStr = "SELECT viewAPI_Partners FROM view_Partners WHERE RoleId=" + (int)partnerType + " AND ReportingTo = " + partnerId;

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();

                partnerDtos = Table2Dto(dataDynamic);
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }

        }

        public List<PartnerDto> GetMinBalanceMyPartners(int partnerId)
        {
            List<PartnerDto> partnerDtos = new List<PartnerDto>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@userid", partnerId);
                string cmdStr = "SELECT top 7 * FROM viewAPI_Partners WHERE ReportingTo = " + partnerId + " order by AvailableCredit";
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                partnerDtos = Table2Dto(dataDynamic);
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }


            //return _users;
        }

        public List<PartnerChartDto> GetMyPartners4Chart(int partnerId)
        {
            List<PartnerChartDto> partnerDtos = new List<PartnerChartDto>();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@userid", partnerId);
                string cmdStr = "SELECT u_name AS Label,AvailableCredit As Value, userId as ID,'/partner/order/partnerhistorydaywise/'+ convert(varchar(10), userId) AS Link FROM viewAPI_Partners WHERE re_reporting_id="+ partnerId + " AND AvailableCredit>100 AND u_name IS NOT NULL";
                 partnerDtos = SqlMapper.Query<PartnerChartDto>(_connectionSQL, cmdStr).ToList();
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }


            //return _users;
        }

        public PartnerDto GetPartner(int partnerId)
        {
            PartnerDto partnerDtos = new PartnerDto();
            try
            {
                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@userid", partnerId);
                string cmdStr = "SELECT * FROM viewAPI_Partners WHERE PartnerId=" + partnerId;

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                partnerDtos = Table2Dto(dataDynamic).FirstOrDefault();
                return partnerDtos;
            }
            catch (Exception)
            {
                return partnerDtos;
            }
        }

        public PartnerDto GetCurrentPoints(int partnerId)
        {
            PartnerDto partnerDto = new PartnerDto();
            try
            {
                string cmdStr = "SELECT * FROM viewAPI_Partners WHERE PartnerId=" + partnerId;
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();
                partnerDto = Table2Dto(dataDynamic).FirstOrDefault();
                return partnerDto;
            }
            catch (Exception)
            {
                return partnerDto;
            }
        }

    }
}
