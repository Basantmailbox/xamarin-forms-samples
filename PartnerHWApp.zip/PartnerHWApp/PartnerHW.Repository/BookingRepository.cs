﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class BookingRepository : BaseRepository, IBookingRepository
    {

    }
}
