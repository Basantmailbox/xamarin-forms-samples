﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core.Utilities;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class UserRepository : BaseRepository, IUserRepository
    {
        // users hardcoded for simplicity, store in a db with hashed passwords in production applications
        //private List<LoggedUserDto> _users = new List<LoggedUserDto>
        //{
        //    new LoggedUserDto { UserId = 1, FullName = "AAAAA Kumar", UserName = "admin", Password = "admin123",RoleId=1,RoleName="Admin",Balance="10000" },
        //    new LoggedUserDto { UserId = 2, FullName = "BBBBB Kumar", UserName = "platinum", Password = "platinum",RoleId=2,RoleName="Platinum",Balance="20000" },
        //    new LoggedUserDto { UserId = 3, FullName = "CCCCC Kumar", UserName = "gold", Password = "gold123",RoleId=3,RoleName="Gold",Balance="30000"  },
        //    new LoggedUserDto { UserId = 4, FullName = "DDDDD Kumar", UserName = "silver", Password = "silver",RoleId=4,RoleName="Silver",Balance="40000" }

        //};

        //private readonly AppSettings _appSettings;

        //public UserService(IOptions<AppSettings> appSettings)
        //{
        //    _appSettings = appSettings.Value;
        //}

        public LoggedUserDto Authenticate(string userName, string password)
        {
            // var user = _users.SingleOrDefault(x => x.UserName == userName && x.Password == password);

            LoggedUserDto loggedUserDto = new LoggedUserDto();
            try
            {
                string passwordEnc = HWEncryptDecrypt.User4Encrypt(password);

                string cmdStr = "SELECT * FROM viewAPI_Partners WHERE LoginId='" + userName + "' AND LoginPassword ='" + passwordEnc + "'";


                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@username", userName);
                //parameters.Add("@U_password", passwordEnc);

                //var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "spAPI_GetPartnerLogin", param: parameters, commandType: StoredProcedure).ToList();

                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr).ToList();

                if (dataDynamic.Count>0)
                {
                    loggedUserDto = (dataDynamic
                                                   .Select(item => new LoggedUserDto()
                                                   {
                                                       PartnerId = item.PartnerId,
                                                       PartnerName = item.PartnerName,
                                                       //LoginId = item.LoginId,
                                                       RoleName = item.RoleName,
                                                       RoleId = item.RoleId,
                                                       Balance = Convert.ToString(item.AvailableCredit)
                                                   })).FirstOrDefault();
                }

                return loggedUserDto;

            }
            catch (Exception ex)
            {
                return loggedUserDto;
            }
        }


        public string GetGoogleAPIKey(int partnerId)
        {
            CreditBuy newEntityObj = new CreditBuy();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@userId", partnerId);

                //OLD usp_Fetch_PinCode_GoogleAPIKey
                var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, "sp_GetGoogleAPIKey", param: parameters, commandType: StoredProcedure).ToList();
                if (dataDynamic.Count > 0)
                {
                    return dataDynamic[0].GoogleAPIKeyGGN;
                }
                return "";
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public IEnumerable<LoggedUserDto> GetAll()
        {
            return new List<LoggedUserDto>();
        }
    }
}
