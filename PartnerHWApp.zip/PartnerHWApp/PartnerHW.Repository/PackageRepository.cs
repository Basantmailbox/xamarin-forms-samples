﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.Core.Extensions;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class PackageRepository : BaseRepository, IPackageRepository
    {
        public List<PackageDto> GetPackage4Booking()
        {
            List<PackageDto> returnObjs = new List<PackageDto>();

            try
            {
                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@packageId", packageId);

                returnObjs = SqlMapper.Query<PackageDto>(_connectionSQL, "spAPI_GetPackage4Booking", commandType: StoredProcedure).ToList();
                return returnObjs;

            }
            catch (Exception)
            {
                return returnObjs;
            }
        }


        public List<PackageDto> GetPackages()
        {
            List<PackageDto> returnObjs = new List<PackageDto>();
            try
            {
                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@packageId", packageId);

                returnObjs = SqlMapper.Query<PackageDto>(_connectionSQL, "spAPI_GetPackageAll", commandType: StoredProcedure).ToList();
                return returnObjs;

            }
            catch (Exception)
            {
                return returnObjs;
            }
        }


        public PartnerDto InsertNew(PackageDto entityObj)
        {
            PartnerDto partnerDto = new PartnerDto();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@pkgIds", entityObj.MappedPkgIds);
                parameters.Add("@pkgName", entityObj.PackageName);
                parameters.Add("@actualPrice", entityObj.ActualPrice);
                parameters.Add("@offerPrice", entityObj.OfferPrice);
                parameters.Add("@description", entityObj.Description);
                parameters.Add("@partnerId", entityObj.PartnerId);

                //OLD sp_customer_app_AddPackage
                var dataDynamic = SqlMapper.Query<PartnerDto>(_connectionSQL, "spAPI_PackageInsert", param: parameters, commandType: StoredProcedure).ToList();
                if (dataDynamic.Count > 0)
                {
                    partnerDto= dataDynamic.FirstOrDefault();
                }
                return partnerDto;
            }
            catch (Exception ex)
            {
                return partnerDto;
            }
        }

        public List<PackageDto> GetMyPackages(int partnerId)
        {
            
        List<PackageDto> returnObjs = new List<PackageDto>();

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@partnerId", partnerId);


                returnObjs = SqlMapper.Query<PackageDto>(_connectionSQL, "spAPI_GetMyPackages", param: parameters, commandType: StoredProcedure).ToList();
                //OLD sp_app_client_ViewPackage
                return returnObjs;

            }
            catch (Exception)
            {
                return returnObjs;
            }
        }

        public List<PackageDto> GetMyPackageDetails(int partnerId,int packageId)
        {

            List<PackageDto> returnObjs = new List<PackageDto>();

            try
            {
                DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@partnerId", partnerId);
                parameters.Add("@packageId", packageId);

                returnObjs = SqlMapper.Query<PackageDto>(_connectionSQL, "spAPI_GetPackageDetails", param: parameters, commandType: StoredProcedure).ToList();
                return returnObjs;

            }
            catch (Exception)
            {
                return returnObjs;
            }
        }

        public List<PackageDto> GetHWPackages()
        {
            

            List<PackageDto> returnObjs = new List<PackageDto>();

            try
            {
                //DynamicParameters parameters = new DynamicParameters();
                //parameters.Add("@partnerId", partnerId);
                //parameters.Add("@packageId", packageId);

                returnObjs = SqlMapper.Query<PackageDto>(_connectionSQL, "spAPI_PackageHW",commandType: StoredProcedure).ToList();
                //sp_customer_blueapp_get_package_price
                return returnObjs;

            }
            catch (Exception)
            {
                return returnObjs;
            }
        }
    }

    public class BookingPackageData
    {
        public List<PackageDto> GetBookingData()
        {
            List<PackageDto> packageDtos = new List<PackageDto>();
            packageDtos.Add(new PackageDto { PackageId= 7610, PackageName= "Swasth Bharat", OffAmount="40", OfferPrice= "999", TestCount= "80", TestNames= "Anemia Profile, CBC, Liver Profile, Kidney Profile, Lipid Profile, Bones Profile, Diabetes Profile, Urine Profile", ActualPrice="2202",CreatedDate=DateTime.Now.DisplayFormat(),IsHWPackage=false, PartnerId=11 });

            packageDtos.Add(new PackageDto { PackageId = 7650, PackageName = "Master Wellness - Men", OffAmount = "42", OfferPrice = "1999", TestCount = "90", TestNames = "Vitamin Profile, CBC, Anaemia with Iron, Liver Profile, Kidney Profile, Electrolyte Profile, Lipid Profile, Diabetes Profile, Bones Profile, Thyroid, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });

            packageDtos.Add(new PackageDto { PackageId = 7653, PackageName = "Maxima Wellness - Men", OffAmount = "40", OfferPrice = "2950", TestCount = "100", TestNames = "Vitamin Profile, CBC, Anaemia, Liver Profile, Kidney Profile, Electrolyte Profile, Lipid Profile, Diabetes Profile, Thyroid Profile, Bones Profile, Extended Bones Profile, Prostate Cancer Profle, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });


            packageDtos.Add(new PackageDto { PackageId = 7610, PackageName = "Swasth Bharat", OffAmount = "40", OfferPrice = "999", TestCount = "80", TestNames = "Anemia Profile, CBC, Liver Profile, Kidney Profile, Lipid Profile, Bones Profile, Diabetes Profile, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });

            packageDtos.Add(new PackageDto { PackageId = 7650, PackageName = "Master Wellness - Men", OffAmount = "42", OfferPrice = "1999", TestCount = "90", TestNames = "Vitamin Profile, CBC, Anaemia with Iron, Liver Profile, Kidney Profile, Electrolyte Profile, Lipid Profile, Diabetes Profile, Bones Profile, Thyroid, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });

            packageDtos.Add(new PackageDto { PackageId = 7653, PackageName = "Maxima Wellness - Men", OffAmount = "40", OfferPrice = "2950", TestCount = "100", TestNames = "Vitamin Profile, CBC, Anaemia, Liver Profile, Kidney Profile, Electrolyte Profile, Lipid Profile, Diabetes Profile, Thyroid Profile, Bones Profile, Extended Bones Profile, Prostate Cancer Profle, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });


            packageDtos.Add(new PackageDto { PackageId = 7610, PackageName = "Swasth Bharat", OffAmount = "40", OfferPrice = "999", TestCount = "80", TestNames = "Anemia Profile, CBC, Liver Profile, Kidney Profile, Lipid Profile, Bones Profile, Diabetes Profile, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });

            packageDtos.Add(new PackageDto { PackageId = 7650, PackageName = "Master Wellness - Men", OffAmount = "42", OfferPrice = "1999", TestCount = "90", TestNames = "Vitamin Profile, CBC, Anaemia with Iron, Liver Profile, Kidney Profile, Electrolyte Profile, Lipid Profile, Diabetes Profile, Bones Profile, Thyroid, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });

            packageDtos.Add(new PackageDto { PackageId = 7653, PackageName = "Maxima Wellness - Men", OffAmount = "40", OfferPrice = "2950", TestCount = "100", TestNames = "Vitamin Profile, CBC, Anaemia, Liver Profile, Kidney Profile, Electrolyte Profile, Lipid Profile, Diabetes Profile, Thyroid Profile, Bones Profile, Extended Bones Profile, Prostate Cancer Profle, Urine Profile", ActualPrice = "2202", CreatedDate = DateTime.Now.DisplayFormat(), IsHWPackage = false, PartnerId = 11 });



            return packageDtos;
        }

    }
}
