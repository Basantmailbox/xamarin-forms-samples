﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.IRepository;
using static System.Data.CommandType;
using static PartnerHW.Core.AppEnum;

namespace PartnerHW.Repository
{
    public class ReportRepository : BaseRepository, IReportRepository
    {
       // HWEncryptDecrypt _hWEncryptDecrypt;

        public ReportRepository()
        {
            //if (_hWEncryptDecrypt == null)
            //{
            // _hWEncryptDecrypt = new HWEncryptDecrypt();
            //}
        }

        public List<ReportSpentDto> GetSpent(int partnerId, EnumSpentTenure tenure, EnumSpentOn spentOn)
        {
            List<ReportSpentDto> reportSpentDtos = new List<ReportSpentDto>();
            try
            {
                StringBuilder cmdStr = new StringBuilder();
                cmdStr.Append("SELECT * FROM ViewAPI_PromoCodes WHERE USER_ID=" + partnerId);
                
                if (tenure==EnumSpentTenure.All)
                {
                  
                }
               else if (tenure == EnumSpentTenure.DAY)
                {
                    
                }
                else if (tenure == EnumSpentTenure.WEEKLY)
                {
                  
                }
                else if (tenure == EnumSpentTenure.MONTHLY)
                {
                   
                }
                else
                {
                    
                }

                reportSpentDtos.Add(new ReportSpentDto { SpentAmount = 22000, Percentage = 20, SpentDate = DateTime.Now.ToString(), SpentOn = "Self" });
                reportSpentDtos.Add(new ReportSpentDto { SpentAmount = 22000, Percentage = 18, SpentDate = DateTime.Now.ToString(), SpentOn = "Pawan Kumar" });
                //var dataDynamic = SqlMapper.Query<dynamic>(_connectionSQL, cmdStr.ToString()).ToList();
                //promoCodeDtos = Table2Dto(dataDynamic);

                return reportSpentDtos;
            }
            catch (Exception)
            {
                return reportSpentDtos;
            }

        }
    }
}
