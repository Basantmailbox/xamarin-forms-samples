﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Dapper;
using PartnerHW.DTOs;
using PartnerHW.IRepository;
using static System.Data.CommandType;

namespace PartnerHW.Repository
{
    public class OrderRepository : BaseRepository, IOrderRepository
    {
        public List<OrderHistoryDayWise> GetPartnerHistoryDayWise(int partnerId)
        {
            List<OrderHistoryDayWise> newEntityObj = new List<OrderHistoryDayWise>();
            try
            {
                OrderHistoryDayWise newObj = new OrderHistoryDayWise();
                newObj.PartnerId = 11;
                newObj.MyEarning = "2000";
                newObj.OrderDate = DateTime.Now.ToString("dd MMMM, yyyy");
                newObj.PartnerEarning = "60066";
                newObj.PickedOrder = 30;
                newObj.PickedRevenue = "3003";
                newEntityObj.Add(newObj);
                return newEntityObj;
            }
            catch (Exception ex)
            {
                return newEntityObj;
            }
        }
        public List<OrderHistoryDayWise> GetPartnerHistoryOneDay(int partnerId,string orderDate)
        {
            List<OrderHistoryDayWise> returnObj = new List<OrderHistoryDayWise>();
            try
            {
                OrderHistoryDayWise newObj = new OrderHistoryDayWise();
                newObj.OrderId = "11001001";
                newObj.MyEarning = "2000";
                newObj.PartnerEarning = "60066";
                newObj.PickedOrder = 30;
                newObj.PickedRevenue = "3003";
                newObj.Status = "Done";
                newObj.Amount = "1999";
                newObj.CustomerName= "Ram Kumar";
                returnObj.Add(newObj);
                return returnObj;
            }
            catch (Exception ex)
            {
                return returnObj;
            }
        }
    }
}
