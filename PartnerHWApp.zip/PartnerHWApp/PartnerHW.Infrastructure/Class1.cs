﻿using System;

namespace PartnerHW.Infrastructure
{
    public class Class1
    {
    }
}
