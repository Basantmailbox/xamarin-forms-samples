﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PaymentMasterDTO
    {
        public long Id { get; set; }
        public string PaymentId { get; set; }
        public string TransactionId { get; set; }
        public string CustomerName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }

        public List<PaymentDTO> Payments { get; set; }
        public string PaymentGateway { get; set; }
        public string Currency { get; set; }
        public string Status { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public Int64 MemberId { get; set; }

         public int? StateCode { get; set; }
        public string Address { get; set; }

     
        public int StateId { get; set; }
        public string BillAddress { get; set; }
        public string GST { get; set; }
        public string PAN { get; set; }
        public int InvoiceType { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal IGSTR { get; set; }
        public decimal CGSTR { get; set; }
        public decimal SGSTR { get; set; }
        public int StateTaxId { get; set; }
        public decimal NetTotalPriceINR { get; set; }
        public decimal NetPriceINR { get; set; }
        public decimal ServiceTaxINR { get; set; }

        public string STaxNameINR { get; set; }
        public decimal PriceUSD { get; set; }
        public decimal DiscountUSD { get; set; }
        public decimal DiscountPercentage { get; set; }
        public Boolean Discount_AppliedToCourse { get; set; }
        public decimal NetPriceUSD { get; set; }
        public decimal TotalUSD { get; set; }
        public long ShoppingCartDataID { get; set; }

        public bool DiscountApplied { get; set; }
        public decimal TotalDiscount { get; set; }
        public decimal TotalDiscountUSD { get; set; }
        public decimal NetTotalPriceUSD { get; set; }
        public decimal TotalPriceINR { get; set; }
        public decimal TotalPriceUSD { get; set; }
        
        public decimal TotalSaving { get; set; }
        public decimal TotalSavingUSD { get; set; }
       public string DiscountCoupon { get; set; }

        public decimal gstprice { get; set; }

        public decimal GrandTotalPrice { get; set; }
    }
}
