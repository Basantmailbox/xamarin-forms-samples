﻿using DNTShared.CustomAttribute;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class MemberProfileDTO
    {
        
        public Int64 MemberId { get; set; }

        [Required(ErrorMessage = "Please enter name")]
        [Display(Name = "Full Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Display(Name = "Email")]
        [StringLength(50)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Please enter a valid e-mail adress")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Mobile Number")]
        [StringLength(20)]
        [RegularExpression(@"^(\+\d{1,3}[- ]?)?\d{10}$", ErrorMessage = "Please enter a valid mobile number")]
        public string MobileNo { get; set; }

        public string ProfilePic { get; set; }

        [Display(Name = "Profile Picture")]
        [ValidatePhoto]
        public HttpPostedFileBase File { get; set; }

        [Display(Name = "Designation")]
        [StringLength(100)]
        public string Designation { get; set; }
        [Display(Name = "Company")]
        [StringLength(250)]
        public string Company { get; set; }

         [Required(ErrorMessage = "Please enter your bio")]
        [Display(Name = "Bio")]
        [StringLength(1000)]
        public string Biography { get; set; }

        [Required(ErrorMessage="Please enter your current location")]
        [Display(Name = "Current Location")]
        [StringLength(1000)]
        public string CurrentLocation { get; set; }

        [Required(ErrorMessage = "Please select gender")]
         public int? GenderId { get; set; }
        public List<GenderMaster> genderList { get; set; }

        public string LinkedIn { get; set; }
        public string Twitter { get; set; }
        public string Facebook { get; set; }
        public string Skype { get; set; }
        public string DomainName { get; set; }
        public string Skills { get; set; }
        public string InterestedSkills { get; set; }
    }
}
