﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
namespace DNTShared.DTO
{
    public class MockupTestMasterQuestionMappingDTO
    {
        public int MockupTestId { get; set; }
        public int QuestionId { get; set; }
        public string QuestionTitle { get; set; }
        public string MockupTestTitle { get; set; }

        public int PageSize { get; set; }
        public int Page { get; set; }
        public IEnumerable<MockUpTestMasterDTO> MockUpTestMasterList { get; set; }
        public int TotalRows { get; set; }
    }
}
