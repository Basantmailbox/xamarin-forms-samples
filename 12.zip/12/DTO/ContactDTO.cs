﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class ContactDTO
    {
        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Contact No")]
        [StringLength(20)]
        public string ContactNo { get; set; }

        [Required(ErrorMessage = "Please enter subject")]
        [Display(Name = "Subject")]
        [StringLength(150)]
        public string Subject { get; set; }

        [Required(ErrorMessage = "Please enter your current City")]
        [Display(Name = "Current City")]
        [StringLength(50)]
        public string City { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [Display(Name = "Message")]
        [StringLength(500)]
        public string Message { get; set; }
        public string DomainName { get; set; }
        public Nullable<System.DateTime> SubmitDate { get; set; }
        public string code { get; set; }
        public string isauthor { get; set; }



    }
}
