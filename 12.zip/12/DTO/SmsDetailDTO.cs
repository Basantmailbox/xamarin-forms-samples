﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class SmsDetailDTO
    {
        public long Id { get; set; }
        [Required(ErrorMessage = "Please enter the contact no.")]
        public string ContactNo { get; set; }
        [Required(ErrorMessage = "Please enter the message content")]
        public string Message { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public int SmsTypeId { get; set; }
        public string TypeName { get; set; }
        public string Gateway { get; set; }
        public DateTime SentDateTime { get; set; }
        public string SessionId { get; set; }
        [Required(ErrorMessage = "Please enter the message subject")]
        public string SmsSubject { get; set; }

        public int? SalesMenId { get; set; }
        public string SaleMenName { get; set; }
        public string ContactSMS { get; set; }
        
    }
}
