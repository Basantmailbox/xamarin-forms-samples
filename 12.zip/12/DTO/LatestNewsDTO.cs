﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.VM
{
    public class LatestNewsDTO_
    {
        public int NewsID { get; set; }
        [Required(ErrorMessage = "Enter News Text")]
        [Display(Name = "News Title")]
        public string NewsText { get; set; }
        public DateTime CreatedDate { get; set; }
        [Required(ErrorMessage = "Enter Expiry Date")]
        [Display(Name = "Expiry Date")]
        public DateTime ExpiryDate { get; set; }
        [Required(ErrorMessage = "Enter redirection Url")]
        [Display(Name = "Url")]
        public string Url { get; set; }
        [Display(Name = "Active Status")]
        public bool IsActive { get; set; }
        public bool IsNotify { get; set; }
        public string PostedBy { get; set; }
        public string NewsFullDetail { get; set; }
        //public List<LatestNewsViewModel> NewsFullDetail { get; set; }
    }
}
