﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
  public  class CartsItemsDTO
    {
        [Key]
        public int CartsItemId { get; set; }

        public int CourseId { get; set; }

        public int Quantity { get; set; }

        public long ShoppingCartDataID { get; set; }

        public DateTime? DateCreated { get; set; }

        public DateTime? DateUpdate { get; set; }

        public virtual ShoppingCartDTO ShoppingCart { get; set; }
    }
}
