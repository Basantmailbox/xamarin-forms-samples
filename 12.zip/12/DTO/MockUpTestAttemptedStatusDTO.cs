﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class MockUpTestAttemptedStatusDTO
    {
        public int test { get; set; }
        public int courseSubscriptionId { get; set; }
        public decimal percentage { get; set; }
        public int score { get; set; }
        public int mins { get; set; }
        public int secs { get; set; }
        public int user { get; set; }
        public string[] answers { get; set; }
        public int correctQuestions { get; set; }
        public int wrongQuestions { get; set; }
        public int leftQuestions { get; set; }
        public int attemptedQuestions { get; set; }
        public int TotalQuestions { get; set; }
        public int Duration { get; set; }
        public int TimeTaken { get; set; }
        public int leftTime { get; set; }
        public bool? AttemptedStatus { get; set; }
        public string MockupTestTitle { get; set; }
        public float Totalscore { get; set; }
        public float TotalcorrectQuestions { get; set; }
        public float TotalwrongQuestions { get; set; }
        public Int64 MemberId { get; set; }
        public string Name { get; set; }
        public int MockUpTestAttemptedStatusId { get; set; }
        public int MockupTestMasterId { get; set; }
        public int CategoryID { get; set; }
        public string MemberName { get; set; }
        public decimal Scores { get; set; }
        public string Designation { get; set; }
        public string MockupTestName { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public DateTime TestTakenDate { get; set; }
        public ICollection<CourseDTO> Courses { get; set; }

        public int TScore { get; set; }
        public string TPercentage { get; set; }
    }
}
