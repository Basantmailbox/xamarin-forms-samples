﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CourseSubscriptionDTO
    {
        public int CourseSubscriptionId { get; set; }

        public Int64 MemberId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public int ModeId { get; set; }
        public string Mode { get; set; }
        public int CourseId { get; set; }
        public string Course { get; set; }
        public DateTime SubscribeDate { get; set; }
        public DateTime ExpiryDate { get; set; }

        public string strSubscribeDate { get; set; }
        public string strExpiryDate { get; set; }

        public bool? IsActive { get; set; }

        public virtual MemberDTO memberDetails { get; set; }

        public int BatchId { get; set; }
        public int VideoAccess { get; set; }

        [Required(ErrorMessage = "Please fill Batch Name")]
        [Display(Name = "Batch Name")]
        public string BatchName { get; set; }
        //new added
        public string CourseShortDescription { get; set; }
        public string TrainingDuration { get; set; }
        public string URL { get; set; }

        public int DocumentId { get; set; }
        
        public string DocumentUrl { get; set; }
        //////
        public string LargeBanner { get; set; }
        public string MobileBanner { get; set; }
        public string SmallBanner { get; set; }
        

        public string Summary { get; set; }
        public decimal Reviews { get; set; }
        public string Learners { get; set; }


        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }

        public bool SubscriptionType { get; set; }
        public string CertificateId { get; set; }
        public int CourseType { get; set; }

    }
}
