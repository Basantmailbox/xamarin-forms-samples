﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNTShared.Entities;

namespace DNTShared.DTO
{
    public class PaymentDTO
    {
        public long Id { get; set; }
        public long InvoiceNo { get; set; }
        public string PaymentId { get; set; }
        public string TransactionId { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public decimal DiscountPercentage { get; set; }
        public int CourseType { get; set; }

        public decimal PriceINR { get; set; }
        public decimal DiscountINR { get; set; }
        public decimal NetPriceINR { get; set; }
        public decimal ServiceTaxINR { get; set; }
        public string STaxNameINR { get; set; }
        public decimal TotalINR { get; set; }

        public decimal PriceUSD { get; set; }
        public decimal DiscountUSD { get; set; }
        public decimal NetPriceUSD { get; set; }
        public decimal TotalUSD { get; set; }

        public string CustomerName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }

        public string PaymentGateway { get; set; }
        public string Currency { get; set; }
        public string Status { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public Int64 MemberId { get; set; }

         public int? StateCode { get; set; }
        public string Address { get; set; }

        ////////////
        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public decimal NetPrice { get; set; }
        public decimal ServiceTax { get; set; }
        public decimal Total { get; set; }
        public bool DiscountApplied { get; set; }
        ////////////
        public int StateId { get; set; }
        public string BillAddress { get; set; }
        public string GST { get; set; }
        public string PAN { get; set; }
        public int InvoiceType { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal IGSTR { get; set; }
        public decimal CGSTR { get; set; }
        public decimal SGSTR { get; set; }
        public int StateTaxId { get; set; }
        
        public string CompanyDetail { get; set; }
        public int Quantity { get; set; }
        public long CreatedBy { get; set; }
        public decimal RoundOff { get; set; }


        //////////////refund/       
        public decimal PaymentGatewayCharge { get; set; }
        public decimal ServiceCharge { get; set; }
        public decimal ClassAttendedCharge { get; set; }
        public decimal RefundAmount { get; set; }
        public string RefundPaymentMode { get; set; }
        public string DetailReason { get; set; }
        public long UpdatedBy { get; set; }
        public string RefundNo { get; set; }
        public string DisCreatedBy { get; set; }
        public decimal TotalInrDisp { get; set; }
        public decimal TotalUsdDisp { get; set; }

        public int CartsItemId { get; set; }
        public decimal NetPriceINRDis { get; set; }
        public long ParentId { get; set; }
        public string DiscountCoupon { get; set; }
        public TransactionDTO paymentchildlistt { get; set; }

        //////////////////////////
        public bool IsOnSale { get; set; }
        public decimal SalePercentage { get; set; }

        public decimal SaleOffAmount_INR { get; set; }
        public decimal AfterSale_INR { get; set; }
        public decimal SaleOffAmount_USD { get; set; }
        public decimal AfterSale_USD { get; set; }



        //public long Id { get; set; }
        //public string PaymentId { get; set; }
        //public string TransactionId { get; set; }
        //public int CourseId { get; set; }
        //public string Name { get; set; }
        //public string Title { get; set; }
        //public decimal PriceINR { get; set; }
        //public decimal PriceUSD { get; set; }
        //public bool IsOnSale { get; set; }
        //public decimal SalePercentage { get; set; }
        //public decimal SaleOffAmount_INR { get; set; }
        //public decimal AfterSale_INR { get; set; }
        //public decimal SaleOffAmount_USD { get; set; }
        //public decimal AfterSale_USD { get; set; }
        //public bool Discount_Applied { get; set; }
        //public decimal TotalDiscountPercentage { get; set; }
        //public decimal TotalDiscountPercentageAmount { get; set; }
        //public decimal NetPrice { get; set; }
        //public int DiscountId { get; set; }
        //public string CouponCode { get; set; }
    }
}
