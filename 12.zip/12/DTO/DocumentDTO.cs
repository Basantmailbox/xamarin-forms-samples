﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
namespace DNTShared.DTO
{
    public class DocumentDTO
    {
       
        public int DocumentId { get; set; }
        [Display(Name = "Document Name")]
        [Required(ErrorMessage = "Please Fill Document Name")]
        public string DocumentName { get; set; }
      
        [Required(ErrorMessage = "Please Select Course")]
        public int CourseId { get; set; }
        [Display(Name = "Course Name")]
   
        public string CourseName { get; set; }

     [Required(ErrorMessage = "Please Select Document Type")]
        public int DocumentTypeId { get; set; }
        [Display(Name = "Document Type")]
        public string DocumentTypeName { get; set; }
       
        public string DocumentUrl { get; set; }
        [Display(Name = "Upload Image")]
        // [ValidatePhoto]
        public HttpPostedFileBase File { get; set; }

        public virtual CourseDTO Course { get; set; }
        public List<CourseDTO> courseList { get; set; }

        public virtual DocumentType DocumentType { get; set; }
        public List<DocumentType> documentTypeList { get; set; }
    }
}
