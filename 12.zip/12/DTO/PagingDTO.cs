﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingDTO<T> where T : class
    {
        public PagingDTO()
        {
            Data = new List<T>();
        }
        public IList<T> Data { get; set; }
        public int TotalRows { get; set; }
        public long? TotalCounts { get; set; }
        public string TViews { get; set; }
        public int PageSize { get; set; }
        public int Page { get; set; }        
        
        //others properties
        public int? CourseId { get; set; }
        public IEnumerable<CourseDTO> Courses { get; set; }       
        [Display(Name = "Category")]
        public int? CategoryID { get; set; }
        public List<CategoryDTO> CategoryList { get; set; }
      
        [Display(Name = "User Name")]
        public int AdminId { get; set; }
        public List<AdminUserDTO> AdminUsers { get; set; }

        public List<EventDTO> upcomingevents { get; set; }

        public string QueryIds { get; set; }

        public List<Job> AllJobListActive { get; set; }
        public MentorMaster MentorDetails { get; set; }
    }
}
