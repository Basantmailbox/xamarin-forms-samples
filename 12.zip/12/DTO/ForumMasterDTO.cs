﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class ForumMasterDTO
    {
        public string elapsedtime { get; set; }
        [Key]
        public Guid FId { get; set; }
        [Required(ErrorMessage = "Please enter title")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Please enter Content")]
        [AllowHtml]
        public string Contents { get; set; }
        public int CourseId { get; set; }
        public long UserId { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsVerified { get; set; }
        public string ImageURL { get; set; }
        [AllowHtml]
        public string RplyContents { get; set; }

        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public int replycount { get; set; }
        public List<MemberDTO> memlist { get; set; }
        public int GenderId { get; set; }
        public string CourseName { get; set; }
        
        public List<ReplyOnForumDTO> replylist { get; set; }
    }
}
