﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class MockUpTestResultDTO
    {
        public int MockupTestMasterId { get; set; }
        public int QuestionId { get; set; }
        public string Answers { get; set; }
        public string CorrectOption { get; set; }
        public int TotalQuestions { get; set; }
        public string MockupTestTitle { get; set; }
        public string QuestionTitle { get; set; }
        public Int64 MemberId { get; set; }
        public int MockUpTestAttemptedStatusId { get; set; }    
  
    }
}
