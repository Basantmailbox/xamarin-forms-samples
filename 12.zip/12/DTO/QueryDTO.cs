﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class QueryDTO
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Please enter your current City")]
        [Display(Name = "Current City")]
        [StringLength(50)]
        public string City { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Mobile No")]
        [StringLength(20)]
        public string ContactNo { get; set; }
        public string code { get; set; }

        [Required(ErrorMessage = "Please enter subject")]
        [Display(Name = "Subject")]
        [StringLength(50)]
        public string Subject { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [Display(Name = "Message")]
        [StringLength(400)]
        public string Message { get; set; }

        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int CourseId { get; set; }

        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }

        public DateTime? SubmitDate { get; set; }
        public string SubmitDateDisplay { get; set; }

        public string Type { get; set; }
        public int EnquiryTypeId { get; set; }
        public string sessionid { get; set; }
        public string DomainName { get; set; }
        public int CreatedBy { get; set; }
        //public int EnquiryTypeId { get; set; }
        public int EnquiryStatusId { get; set; }
        public int FollowUpUserId { get; set; }
        public DateTime? AssignedDate { get; set; }
        public DateTime? FollowUpDate { get; set; }
        public string FollowUpDateDisplay { get; set; }
        public DateTime? FollowUpDateNext { get; set; }
        public string FollowUpDateNextDisplay { get; set; }
        public DateTime DateForNextFollowUp { get; set; }
        public int FollowUpCounter { get; set; }
        public int AssignedCounter { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public string followed { get; set; }

        public int IsRemark { get; set; }
        public int RemarkType { get; set; }
        public int? BatchId { get; set; }
        public long MembID { get; set; }
        public int CloseFlag { get; set; }
        public string CloseRemark { get; set; }
        public string saleman { get; set; }
        public string EnquiryTypeName { get; set; }

        public int EnquiryCount { get; set; }
        public int New { get; set; }
        public int Interested { get; set; }
        public int NotInterested { get; set; }
        public int Pending { get; set; }
        public int Fake { get; set; }
        public int Demo { get; set; }
        public int Closed { get; set; }
        public string UserName { get; set; }
        public string DisDate { get; set; }
        public int TotalEnq { get; set; }
        public int OldEnquiryType { get; set; }
        public bool OTPVerified { get; set; }
        public int OTPText { get; set; }
        public int OTPQText { get; set; }
        public int DCourseId { get; set; }

        public int Status { get; set; }
        // in excel
        public string TrainingModeName { get; set; }
        public bool IsBackHistory { get; set; }

        /////////report
        public int AdminId { get; set; }
        public int AdminName { get; set; }
        public int TotalQueries { get; set; }
        public int TotalClosed { get; set; }
        public int NewQueries { get; set; }
        public decimal successrate { get; set; }
    }
}
