﻿using DNTShared.Entities;
using System.Collections.Generic;

namespace DNTShared.DTO
{
    public class MemberNotificationsDTO
    {
        public List<Course> NewCourseRelease { get; set; }
        public List<Course> ExistingCourseUpdate { get; set; }
        public List<Course> NewEbookRelease { get; set; }
        public List<Course> ExistingEbookUpdate { get; set; }
        public List<Job> NewJobPost { get; set; }
        public List<Event> UpcomingWebinars { get; set; }
        public List<AssignedMockUpTestDTO> AssignedMockuptest { get; set; }
        public int NotificationCount { get; set; }
    }
}
