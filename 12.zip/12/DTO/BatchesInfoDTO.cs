﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class BatchesInfoDTO
    {
        public int BatchId { get; set; }
        //public int CourseId { get; set; }
        [Required(ErrorMessage = "Please Enter Batch Name")]
        [Display(Name = "Batch Name")]
        public string Name { get; set; }
       
        [Required(ErrorMessage = "Enter Start date")]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{mm-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        public string StartDateDisplay { get; set; }

        [Required(ErrorMessage = "Enter End date")]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{mm-dd-yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime? ExpectedDate { get; set; }
        public string ExpectedDateDisplay { get; set; }
      
        public int ModeId { get; set; }

        [Required(ErrorMessage = "Enter Mentor Name")]
        [Display(Name = "Mentor")]
        public string Mentor { get; set; }

        [Required(ErrorMessage = "Enter Day")]
        [Display(Name = "Day")]
        public string Days { get; set; }

        [Required(ErrorMessage = "Enter Time")]
        [Display(Name = "Time")]
        public string Time { get; set; }
        public bool? IsActive { get; set; }
        //public int TrainingModeId { get; set; }
          [Display(Name = "Mode")]
        public string modename { get; set; }

        [Required(ErrorMessage = "Enter Url")]
          public string Url { get; set; }


          [Required(ErrorMessage = "Please select course")]
          [Display(Name = "Course")]
          public int CourseId { get; set; }

          [Display(Name = "Course Name")]
          public string CourseName { get; set; }
          public List<CourseDTO> CourseList { get; set; }

          [Required(ErrorMessage = "Please select training mode")]
          [Display(Name = "Training Mode")]
          public int TrainingModeId { get; set; }

          [Display(Name = "Training Mode")]
          public string TrainingMode { get; set; }
          public List<TrainingMode> TrainingModeList { get; set; }

          public int TotalRows { get; set; }
          public string FullDetail { get; set; }
          public string PostedBy { get; set; }
          public string ImportantInfo { get; set; }
    }
}
