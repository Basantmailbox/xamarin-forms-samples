﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class IndexDisplayDataDTO
    {
        public IndexDisplayDataDTO()
        {
            newsList = new List<LatestNews>();
        }
        public List<LatestNews> newsList { get; set; }
        public int? TrainedStudentCount { get; set; }
        public int? TotalBatches { get; set; }
        public int? UpcomingBatches { get; set; }
        public int? JobOpenings { get; set; }
        public List<CourseDTO> CourseDTO { get; set; }
    }
}
