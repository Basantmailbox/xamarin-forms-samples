﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class MockupTestQuestionOptionAnswerDTO
    {
        public int QuestionId { get; set; }
        public string QuestionTitle { get; set; }
        public string QuestionCode { get; set; }
        public string QuestionOptions { get; set; }
        public string QuestionAnswer { get; set; }
        //public string MockupTestTitle { get; set; }
        //public int MockupTestMasterId { get; set; }
        public int? Marks { get; set; }
        public string UsersSelectedAnswer { get; set; }
        public int MockupTestId { get; set; }
    }
}
