﻿using DNTShared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using DNTShared.Entities;

namespace DNTShared.DTO
{
    public class InstallmentDetailsDTO
    {
        public long Id { get; set; }
        public string UID { get; set; }
        public string PaymentId { get; set; }
        public string TransactionId { get; set; }
        [Required(ErrorMessage = "Please Enter Installment Name")]
        public string InstallmentName { get; set; }

        public int CourseId { get; set; }
        public string CourseName { get; set; }

        [Required(ErrorMessage = "Please Enter Customer Name")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "Please Enter Customer Email")]
        [Display(Name = "Email")]
        [StringLength(50)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Please enter a valid e-mail adress")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please Enter Customer Contact No.")]
        public string ContactNo { get; set; }

        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public decimal NetPrice { get; set; }
        public decimal ServiceTax { get; set; }
        public string STaxName { get; set; }

        public decimal Total { get; set; }

        [Required(ErrorMessage = "Please Select Currency")]
        public string Currency { get; set; }
        public string PaymentGateway { get; set; }

        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string disUpdatedDate { get; set; }

        public string URL { get; set; }
        public DateTime? ExpiryDate { get; set; }

        public bool IsPaymentDone { get; set; }
        public int IsCancelled { get; set; }
        public List<InstallmentDetailsDTO> InstallmentDetailsList { get; set; }
        public List<Course> CourseList { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
        public string DispCreatedBy { get; set; }
        public string DispUpdatedBy { get; set; }
        public int? SalesId { get; set; }
        public int CreatedFor { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }

        public decimal IGSTPercent { get; set; }
        public decimal CGSTPercent { get; set; }
        public decimal SGSTPercent { get; set; }
        public decimal RoundOff { get; set; }
        

        public int StateCode { get; set; }
        public string Address { get; set; }
        public int StateId { get; set; }
        public string BillAddress { get; set; }
        public DateTime ExpyDate { get; set; }
        public decimal ServiceTaxPercentage { get; set; }

        public long ParentId { get; set; }
        public List<CourseSalesList_V1> courslist { get; set; }
        public List<InstallmentDetails_V1> InstallmentV1 { get; set; }

        public List<InstallmentList> Installments { get; set; }
        public List<TransactionChildDetails_V1> TransactionChildList { get; set; }

    }
}
