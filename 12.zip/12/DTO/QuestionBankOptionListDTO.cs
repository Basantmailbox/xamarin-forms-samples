using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

namespace DNTShared.DTO
{
    public class QuestionBankOptionListDTO
    {
        public string OptionChar { get; set; }
        public string OptionTitle { get; set; }
    }
}
