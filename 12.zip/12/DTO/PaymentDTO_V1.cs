﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNTShared.Entities;

namespace DNTShared.DTO
{
    public class PaymentDTO_V1
    {
        public long Id { get; set; }
        public string PaymentId { get; set; }
        public string TransactionId { get; set; }
        public int CourseId { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public decimal Price { get; set; }
        public bool IsOnSale { get; set; }
        public decimal SalePercentage { get; set; }
        public decimal SaleOffAmount { get; set; }
        public decimal AfterSale { get; set; }
        public bool Discount_Applied { get; set; }
        public decimal TotalDiscountPercentage { get; set; }
        public decimal TotalDiscountPercentageAmount { get; set; }
        public decimal NetPrice { get; set; }
        public int DiscountId { get; set; }
        public string CouponCode { get; set; }
        public int CourseType { get; set; }
    }
}
