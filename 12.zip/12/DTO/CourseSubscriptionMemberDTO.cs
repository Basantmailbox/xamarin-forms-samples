﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CourseSubscriptionMemberDTO
    {

        public Int64 MemberId { get; set; }

        [Required(ErrorMessage = "Please enter name")]
        [Display(Name = "Full Name")]
        [StringLength(50)]
        public string Name { get; set; }
           
        public string Email { get; set; }

       [Display(Name = "Mobile No")]
        public string MobileNo { get; set; }
        public string ContactNo { get; set; }
        public string ProfilePic { get; set; }

        [Display(Name = "Profile Picture")]
        // [ValidatePhoto]
        public HttpPostedFileBase File { get; set; }
        public string CurrentLocation { get; set; }
        public int? MailSentCounter { get; set; }

        public string EncriptedKey { get; set; }

        public string VerificationUrl { get; set; }

        public Nullable<bool> IsActive { get; set; }

        public DateTime CreatedDate { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }

        public Nullable<bool> IsVerified { get; set; }
        public Nullable<DateTime> VerificationDate { get; set; }
       
        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int? CourseId { get; set; }

        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string DisExpiryDate { get; set; }

        public int? BatchId { get; set; }

        [Required(ErrorMessage = "Please fill Batch Name")]
        [Display(Name = "Batch Name")]
        public string BatchName { get; set; }
       
        public List<BatchMasterDTO> BatchList { get; set; }
        public int TotalCourse { get; set; }
      
        public int? CourseSubscriptionId { get; set; }
        public DateTime? SubscribeDate { get; set; }
        public string DisSubscribeDate { get; set; }
        public bool SubscriptionType { get; set; }
        public int CourseType { get; set; }
        public int? ModeId { get; set; }
        public int VideoAccess { get; set; }
        public string BatchCode { get; set; }
        public string CourseTypeName { get; set; }
    }
}
