﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class BookMasterDTO
    {
        public int BookId { get; set; }

        [Required(ErrorMessage = "Please enter Title Name")]
        [Display(Name = "Title Name")]
        [StringLength(200)]
        public string BookTitle { get; set; }
        [Required(ErrorMessage = "Please enter Author Name")]
        public string Author { get; set; }
        [Required(ErrorMessage = "Please enter Keywords")]
        public string Keywords { get; set; }
        [Display(Name = "Posted Date")]
        public DateTime PostedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [Display(Name = "Total Views")]
        public Int64? TotalDownloads { get; set; }
        [Required(ErrorMessage = "Please enter Short Description")]
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }

        public string Description { get; set; }
        public string URL { get; set; }

        [Required(ErrorMessage = "Please select Image")]
        [Display(Name = "Image Url")]
        public string ImageUrl { get; set; }
        public bool? IsActive { get; set; }
        [Display(Name = "Book Name")]
        public string BookName { get; set; }

        public int DocumentId { get; set; }
        [Display(Name = "Document Name")]
        public string DocumentName { get; set; }
        public string DocumentUrl { get; set; }
        [Display(Name = "Upload Image")]
        // [ValidatePhoto]
        public HttpPostedFileBase File { get; set; }
        [Required(ErrorMessage = "Please enter Book Short Name")]
        [Display(Name = "Book Short Name")]
        public string BookShortName { get; set; }
        public int MentorId { get; set; }
        public string Mentors { get; set; }
        [Required(ErrorMessage = "Please select Domain Name")]
        public string DomainName { get; set; }
        public string Footer { get; set; }

        public List<DocumentDTO> DocumentList { get; set; }
        public List<MentorMaster> MentorMasterList { get; set; }

        public List<MentorMaster> MentorList { get; set; }
        public List<MentorMaster> SelectedMentors { get; set; }
        public IEnumerable<SelectListItem> MentorMaster { get; set; }

    }
}
