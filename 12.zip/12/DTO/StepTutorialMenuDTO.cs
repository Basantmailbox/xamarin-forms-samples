﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
   public class StepTutorialMenuDTO
    {
            public string Logo { get; set; }
            public string Title { get; set; }
            public string SideMenuLinks { get; set; }
    }
}
