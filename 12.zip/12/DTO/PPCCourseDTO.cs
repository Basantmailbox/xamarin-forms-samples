﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class PPCCourseDTO
    {
        public int Id { get; set; }
        //[Required(ErrorMessage = "Please Enter Name")]
        public string CourseName { get; set; }
        [Required(ErrorMessage = "Please Select Course")]
        public int CourseId { get; set; }
        
        [Required(ErrorMessage = "Please Select Source")]
        public int SourceId { get; set; }
        public string DispSourceName { get; set; } 
       
        [Required(ErrorMessage = "Please Enter Url")]
        public string URL { get; set; }
        [AllowHtml]
        [Required(ErrorMessage = "Please Enter Summary")]
        public string Summary { get; set; }
        [AllowHtml]
        public string FooterDetails { get; set; }
        public string City { get; set; }
        [Required(ErrorMessage = "Please Select Mentors")]
        public string Mentors { get; set; }
        [Required(ErrorMessage = "Please Enter Title")]
        public string H1Tag { get; set; }
        public string H2Tag { get; set; }
        public bool IsActive { get; set; }
        [Required(ErrorMessage = "Please Select Mode")]
        public int TrainingModeId { get; set; }
        public string DispTrainingModeName { get; set; }
         [Required(ErrorMessage = "Please Select Domain Name")]
        public string DomainName { get; set; } 
        public int? Sequence { get; set; }
        public string DocumentUrl { get; set; }
        public string LargeBanner { get; set; }
        public string SmallBanner { get; set; }
        public string MobileBanner { get; set; }
        public string CourseFeatures { get; set; }
        [Required(ErrorMessage = "Please Enter Reviews")]
        public decimal Reviews { get; set; }
        [Required(ErrorMessage = "Please Enter Learners")]
        public string Learners { get; set; }
        public string Keyword { get; set; }
        public string Description { get; set; }
        public string WhyUsContents { get; set; }
        
        public List<CourseDetail> CourseDetailList { get; set; }
        public List<MentorMaster> MentorMasterList { get; set; }
       public List<CourseDTO> courseList { get; set; }
       public IEnumerable<SelectListItem> MentorMasterSelectlist { get; set; }
       public List<MentorMaster> SpeakersList { get; set; }
       public List<SourceMaster> SourceList { get; set; }
       public List<TrainingMode> TrainingModeList { get; set; }
       public string DemoUrl { get; set; }

        ////////////
        public string CoursesList { get; set; }
        public string SkillName { get; set; }
        public int CourseType { get; set; }
        public int CourseCount { get; set; }
        public int SkillsCount { get; set; }
        public List<SkillMaster> SkillsList { get; set; }
        public decimal TotalCPrice{ get; set; }
        public decimal FixCPriceInr { get; set; }
        public decimal FixCPriceUsd { get; set; }
        public decimal DisCPrice { get; set; }
        public decimal Final { get; set; }
      //  public List<CoursePrice> curpriceList { get; set; }
        public int EnquiryType { get; set; }
        public List<CourseTopic> CurPreRecTopiclist { get; set; }
        public List<MaterCourseCurriculum> SubCourseDetailsList { get; set; }
        public string Currency { get; set; }
        public List<CoursePriceDTO> curpriceList { get; set; }
        public string ImageDemo { get; set; }
        [Display(Name = "Upload Image")]
        [NotMapped]
        public HttpPostedFileBase File { get; set; }
    }
}
