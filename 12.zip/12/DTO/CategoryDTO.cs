﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CategoryDTO
    {
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Please Enter Category Name")]
        [Display(Name = "Category Name")]
        [StringLength(100)]
        public string CategoryName { get; set; }
        public int Total { get; set; }

        [Required(ErrorMessage = "Please Enter Title")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Please Enter Meta Title")]
        public string MetaTitle { get; set; }

        [Required(ErrorMessage = "Please Enter Title")]
        public string Url { get; set; }

        [Required(ErrorMessage = "Please Enter Meta Keywords")]
        public string MetaKeywords { get; set; }

        [Required(ErrorMessage = "Please Enter Meta Description")]
        public string MetaDescription { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; }

        public string Skills { get; set; }
        public string Books { get; set; }
        public string Courses { get; set; }
        public string Beginners { get; set; }
        public string Intermediate { get; set; }
        public string Advanced { get; set; }
        public string Questions { get; set; }
        public string CourseDescription { get; set; }
        public string SkillPath { get; set; }
        public string SkillContents { get; set; }
        public int CategoryType { get; set; }
        public string ImageUrl { get; set; }
        public string DisplayName { get; set; }
        public HttpPostedFileBase File { get; set; }
        public ICollection<CourseDTO> CategoryCourses { get; set; }       
        
        public IEnumerable<SelectListItem> BookMaster { get; set; }
        public IEnumerable<SelectListItem> CoursesMaster { get; set; }
        public IEnumerable<SelectListItem> SkillMaster { get; set; }
        
    }
}
