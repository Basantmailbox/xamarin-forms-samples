﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DNTShared.DTO
{
    public class LoginDTO
    {
        [Required(ErrorMessage = "Please Enter Email")]
        [Display(Name="Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { get; set; }

        [Display(Name="Remember me")]
        public bool IsRemember { get; set; }
    }
}