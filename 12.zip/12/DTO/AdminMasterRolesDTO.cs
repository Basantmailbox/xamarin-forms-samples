﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class AdminMasterRolesDTO
    {
        public int AdminId { get; set; }
        public string RoleId { get; set; }
    }
}
