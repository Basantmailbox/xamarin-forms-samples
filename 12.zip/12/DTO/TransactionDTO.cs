﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class TransactionDTO
    {
        public long Id { get; set; }
       
        public string PaymentId { get; set; }

        [Required(ErrorMessage = "Please Enter Transaction Id")]
        public string TransactionId { get; set; }
        public string UID { get; set; }

        public int CourseId { get; set; }
        public string CourseName { get; set; }

        public string CustomerName { get; set; }
        public string CurrentLocation { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }

        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public decimal NetPrice { get; set; }
        public decimal ServiceTax { get; set; }
        public decimal Total { get; set; }
        public string Currency { get; set; }
        public string PaymentGateway { get; set; }

        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string DisUpdatedDate { get; set; }
        public Int64 MemberId { get; set; }

        public string Paypal { get; set; }
        public string PayUMoney { get; set; }
        public List<TransactionDTO> TransactionList { get; set; }
        public int ModeId { get; set; }

        public decimal TotalInrDisp { get; set; }
        public decimal TotalUsdDisp { get; set; }
        public bool IsInvoice { get; set; }
        public int CourseType { get; set; }
        public string StateCode { get; set; }
        public string Address { get; set; }
        public string DiscountCoupon { get; set; }

        public long ParentId { get; set; }
        public List<PaymentChildDetail> PaymentChildDetailList{ get; set; }
        public InstallmentDetails_V1 InstallmentDetails { get; set; }
        public List<TransactionChildDetails_V1> TransactionChildDetailsList { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }

        public decimal IGSTPercent { get; set; }
        public decimal CGSTPercent { get; set; }
        public decimal SGSTPercent { get; set; }
        public decimal ServiceTaxPercentage { get; set; }

        public decimal IGSTR { get; set; }
        public decimal CGSTR { get; set; }
        public decimal SGSTR { get; set; }
        public int StateTaxId { get; set; }
        public decimal RoundOff { get; set; }
        public string GST { get; set; }
        public string PAN { get; set; }
        public int InvoiceType { get; set; }
        public int DiscountId { get; set; }
        public bool Discount_Applied { get; set; }
        public decimal TotalDiscountPercentageAmount { get; set; }
        public string CompanyDetail { get; set; }
        public Boolean IsInstallment { get; set; }
        public long InstallmentID { get; set; }

        public string InvoiceNo { get; set; }
        public bool IsGST { get; set; }
        public int IsCancelled { get; set; }

        public string URLSource { get; set; }

    }
}
