﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
    class LearningProgressDTO
    {
    }

   public  class LearningProgressStatusDTO
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public int LearntCount { get; set; }
        public int TotalCount { get; set; }
        public string RemainPer { get; set; }
        public string LastViewDate { get; set; }

        public string Duration { get; set; }

        public string URL { get; set; }

    }
}
