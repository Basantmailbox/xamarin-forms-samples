﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class QueryRemarkDTO
    {
        public int QueryRemarkId { get; set; }
        public int QueryId { get; set; }
        public int UserId { get; set; }
        public DateTime FollowUpDate { get; set; }
        public DateTime? NextFollowUpDate { get; set; }
        public string Remarks { get; set; }

        public string UserName { get; set; }
        public QueryDTO QueryVM { get; set; }
        public AdminMasterDTO AdminMasterVM { get; set; }

        public string Name { get; set; }
        public string EmailID { get; set; }
        //public int Course { get; set; }
        public string ContactNo { get; set; }
        public int RemarkType { get; set; }
        public int? BatchId { get; set; }
        public int EnquiryTypes { get; set; }
        
    }
}
