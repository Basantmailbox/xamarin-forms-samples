﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DNTShared.DTO
{
    public class DashboardCounterDTO
    {
        //Enquiry
        public int TotalEnquiryCount { get; set; }
        public int TodaysEnquiryCount { get; set; }
        public int Last7DaysEnquiryCount { get; set; }
        public int Last15DaysEnquiryCount { get; set; }
        //Member
        public int TotalRegistrationCount { get; set; }
        public int TotalVerifiedMemberCount { get; set; }
        public int TotalUnVerifiedMemberCount { get; set; }
        //Callback Request
        public int TotalCallbackRequestCount { get; set; }
        public int TodaysCallbackRequestCount { get; set; }
        public int Last7DaysCallbackRequestCount { get; set; }
        public int Last15DaysCallbackRequestCount { get; set; }
        //Subscription
        public int TotalSubscriptionCount { get; set; }
        public int TotalSubscribedUserCount { get; set; }
        public int TotalUnSubscribedUserCount { get; set; }

        //Contacts
        public int TotalContactCount { get; set; }
        public int TodaysContactCount { get; set; }
        public int Last7DaysContactCount { get; set; }
        public int Last15DaysContactCount { get; set; }

        //Batches
        public int TotalBatchesCount { get; set; }
        public int UpcomingBatchCount { get; set; }
        public int CurrentBatchCount { get; set; }

        //Events
        public int TotalEventsCount { get; set; }
        public int TotalWebinarCount { get; set; }
        public int TotalSeminarCount { get; set; }

        //News
        public int TotalNewsCount { get; set; }
        public int TotalLiveCount { get; set; }
        public int TotalExpiredCount { get; set; }

        //BLOG
        public int TutorialCount { get; set; }
        public int BloggerCount { get; set; }
        public int CategoryCount { get; set; }

        //STEP BY STEP
        public int StepTutorialCount { get; set; }
        public int StepQuestionCount { get; set; }
        public int StepCategoryCount { get; set; }
        public int Question_Sub_CategoryCount { get; set; }
        public int Tutorial_CategoryCount { get; set; }

        //Installment Details
        public int TotalInstallmentCount { get; set; }
        public int InstallmentSuccessCount { get; set; }
        public int InstallmentInitiatedCount { get; set; }

        //Transaction Details
        public int TotalTransactionCount { get; set; }
        public int TransactionSuccessCount { get; set; }
        public int TransactionInitiatedCount { get; set; }
        public int TransactionPendingCount { get; set; }

        //////////sales//////
        public int NewCount { get; set; }
        public int PendingCount { get; set; }
        public int InterestedCount { get; set; }
        public int NotInterestedCount { get; set; }
        public int FakeCount { get; set; }
        public int DemoCount { get; set; }
        public int ClosedCount { get; set; }
    }
}
