﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace DNTShared.DTO
{
    public class CourseTrainingDTO
    {
        //query  
        public int ID { get; set; }
        public string Name { get; set; }
        public string EmailID { get; set; }
        public string City { get; set; }
        public string ContactNo { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public int EnquiryStatusId { get; set; }
        public int EnquiryTypeId { get; set; }

        public DateTime? SubmitDate { get; set; }

        //course
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public int Fees { get; set; }
        public Nullable<System.Int32> FlatDiscount { get; set; }
        public int? PercentDiscount { get; set; }

        public string Type { get; set; }
        public string Audience { get; set; }
        public string ToolsIDE { get; set; }
        public string DeliveryMethod { get; set; }
        public string TrainingDuration { get; set; }
        public string Language { get; set; }
        //training mode
        public int TrainingModeId { get; set; }
        public string TrainingModeName { get; set; }
        //course category
        public int CourseCategoryId { get; set; }
        public string CourseCategoryName { get; set; }
        public int followcounter { get; set; }

        public int RemarkId { get; set; }
        public string RemarkName { get; set; }
        public List<RemarkType> RemarkType { get; set; }
        public int? BatchId { get; set; }
        public int CloseFlag { get; set; }
        public string CloseRemark { get; set; }
        public int FollowUpUserId { get; set; }
        public DateTime? AssignedDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? NextFollowUpDate { get; set; }
        public DateTime? FollowUpDate { get; set; }
        public string DomainName { get; set; }
        public bool OTPVerified { get; set; }
        public string FollowUpUserName { get; set; }
        public string Remarks { get; set; }

        public string FollowUpDateNextDisplay { get; set; }
      
    }
}
