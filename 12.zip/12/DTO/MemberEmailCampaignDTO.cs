﻿//using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class MemberEmailCampaignDTO
    {
        public IEnumerable<MemberDTO> Members { get; set; }
        public int TotalCounts { get; set; }
        public int AllRegisteredMember { get; set; }
    }
}
