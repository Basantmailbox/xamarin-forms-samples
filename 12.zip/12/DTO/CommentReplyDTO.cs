﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CommentReplyDTO
    {
        public Guid CommentId { get; set; }
        [Required(ErrorMessage = "Please enter Content")]
        [AllowHtml]
        public string ContentsComment { get; set; }
        public int TutorialID { get; set; }
        public long UserId { get; set; }
        public DateTime CreatedDateComment { get; set; }
        public bool IsVerifiedComment { get; set; }
        
        //public long ReplyId { get; set; }
        //[Required(ErrorMessage = "Please enter Content")]
        //[AllowHtml]
        //public string ContentsReply { get; set; }
        //public bool IsVerifiedReply { get; set; }
        //public DateTime CreatedDateReply { get; set; }

        public List<ReplyOnCommentDTO> ReplyOnComments { get; set; }
       
    }
}
