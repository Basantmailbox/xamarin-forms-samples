﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class DownloadSyllabusDTO
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string DName { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string DEmailID { get; set; }


        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Mobile No")]
        [StringLength(20)]
        public string DContactNo { get; set; }
        public string DCity { get; set; }
        public string code { get; set; }
        public string codeot { get; set; } 
        public int DCourseId { get; set; }
        public string Type { get; set; }
        public int TrainingModeId { get; set; }
        public int EnquiryType { get; set; }
        public bool OTPVerified { get; set; }
        public int OTPText { get; set; }
        public int OtpId { get; set; }
        public string msg { get; set; }
    }
}
