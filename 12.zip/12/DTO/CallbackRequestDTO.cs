﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class CallbackRequestDTO
    {
        public int CallbackRequestId { get; set; }

        [Required(ErrorMessage = "Please Enter Your Name")]
        [StringLength(50)]
        public string Name1 { get; set; }
        [Required(ErrorMessage = "Please Enter Your Contact No.")]
        [StringLength(20)]
        public string ContactNo1 { get; set; }
        [Required(ErrorMessage = "Please Enter your preferred Call Time")]
        [StringLength(20)]
        public string CallTime { get; set; }
        public DateTime SubmitDate { get; set; }
        public bool IsCalled { get; set; }
        public bool IsActive { get; set; }
        public string IpAddress { get; set; }
        public string DomainName { get; set; }
        public List<CourseDTO> CourseList { get; set; }
        [Required(ErrorMessage = "Please select course")]
        public int CourseId1 { get; set; }

        public int EnquiryType { get; set; }
        public string code { get; set; }

        public string OTPcallText { get; set; }
        public bool OTPVerified { get; set; }
        public int QID { get; set; }
    }
}
