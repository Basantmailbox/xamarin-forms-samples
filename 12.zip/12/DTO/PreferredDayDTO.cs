﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PreferredDayDTO
    {
        public int PreferredDayId { get; set; }
        public string Name { get; set; }
    }
}
