﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class StepTutorialSubCategoryDTO
    {
        public int TutorialSubCategoryID { get; set; }

        [Range(1, 50, ErrorMessage = "Please Select Category")]
        public int? CategoryID { get; set; }

        [Required(ErrorMessage = "Please Enter Tutorial SubCategory Name")]
        [Display(Name = "SubCategory Name")]
        public string TutorialSubCategoryName { get; set; }
        public string CategoryName { get; set; }
    }
}
