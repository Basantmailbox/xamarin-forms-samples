﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingSmsDTO<T> : PagingDTO<T> where T : class
    {
        [Display(Name = "Type")]
        public int? SmsTypeId { get; set; }
        public List<SmsType> smstypeList { get; set; }
        //public int? AdminId { get; set; }
        public List<AdminUserDTO> SalesList { get; set; }
    }
}
