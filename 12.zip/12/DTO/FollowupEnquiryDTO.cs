﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{

    /// <summary>
    /// Author : Basant Kumar
    /// Created Date : 11 Sep 2016
    /// </summary>
  public class FollowupEnquiryDTO
    {
        public int FollowupEnquiryId { get; set; }
        public int EnquiryId { get; set; }
        public int CourceId { get; set; }
        public int EnquiryTypeId { get; set; }
        public int EnquiryStatusId { get; set; }
        public int FollowUpUserId { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime FollowUpDate { get; set; }
        public DateTime? FollowUpDateNext { get; set; }
        public int AssignedCounter { get; set; }
        public string Remarks { get; set; }
    }
}
