﻿using System;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class AssignedMockUpTestDTO
    {
        public int MockupTestAssignedBatchDetailId { get; set; }
        public int AssessmentId { get; set; }
        public int MockupTestId { get; set; }
        public int BatchId { get; set; }
        public string BatchName { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public string AssignmentUrl { get; set; }
        public string MockupTestTitle { get; set; }
        public int Duration { get; set; }
        public int TotalQuestion { get; set; }
        public string AssignedDate { get; set; }
        //mockup test
        public DateTime FromDate { get; set; }
        public string FromDateDisplay { get; set; }
        public DateTime ToDate { get; set; }
        public string ToDateDisplay { get; set; }
        //assessment
        public DateTime AssignmentFromDate { get; set; }
        public string AssignmentFromDateDisplay { get; set; }
        public DateTime AssignmentToDate { get; set; }
        public string AssignmentToDateDisplay { get; set; }
        public int MockupTestAlreadyTaken { get; set; }

    }
}
