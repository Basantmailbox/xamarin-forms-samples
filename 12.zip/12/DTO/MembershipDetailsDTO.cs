﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
    public class MembershipDetailsDTO
    {
        public int MembershipId { get; set; }
        public DateTime ExpiryDate { get; set; }
    }
}
