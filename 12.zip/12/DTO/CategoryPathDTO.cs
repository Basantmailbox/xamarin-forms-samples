﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
    public class CategoryPathDTO
    {
        public string Title { get; set; }
        public string MetaTitle { get; set; }
        public string Url { get; set; }
        public string MetaKeywords { get; set; }
        public string MetaDescription { get; set; }
        public string Beginners { get; set; }
        public string Intermediate { get; set; }
        public string Advanced { get; set; }
        public string Questions { get; set; }
        
        public string SkillContents { get; set; }
        public string CourseDescription { get; set; }
        public string SkillPath { get; set; }
        public int CategoryType { get; set; }
        public ICollection<TutorialDTO> Tutorials { get; set; }
        public ICollection<CourseDTO> Courses { get; set; }
    }
}
