﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CourseCategoryDTO
    {
        public int CourseCategoryId { get; set; }
           [Required(ErrorMessage = "Please Enter Course Category")]
        public string CourseCategoryName { get; set; }
        public string Description { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsActive { get; set; }
        public int CurType { get; set; }

        public List<CourseMenuDTO> CourseMenu { get; set; }

        public List<CourseDTO> Courses { get; set; }
        public List<CourseDTO> SelectedAreas { get; set; }
        public IEnumerable<SelectListItem> CoursesList { get; set; }
        public virtual CourseDTO Course { get; set; }
        public IEnumerable<SelectListItem> artcatList { get; set; }
        public List<CategoryDTO> Categories { get; set; }
        public IEnumerable<SelectListItem> CategoryList { get; set; }
        public virtual CategoryDTO Category { get; set; }
    }
}
