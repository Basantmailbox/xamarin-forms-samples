﻿using System.Collections.Generic;


namespace DNTShared.DTO
{
    public class SalesReportMasterDTO
    {
        public List<decimal> Total { get; set; }
        public List<CourseWise> CourseWiseList { get; set; }
        public List<MentorCourseWise> MentorCourseWiseList { get; set; }
        public List<CourseTypeWise> CourseTypeList { get; set; }
        public class CourseWise
        {
            public string Name { get; set; }
            public int CourseType { get; set; }
            public string Currency { get; set; }
            public decimal Total { get; set; }                    
        }
       
        public class MentorCourseWise
        {
            public string MentorsName { get; set; }
            public string Mentors { get; set; }
            public int CourseType { get; set; }
            public string Currency { get; set; }
            public decimal Total { get; set; }            
        }

        public class CourseTypeWise
        {           
            public int CourseType { get; set; }
            public string Currency { get; set; }
            public decimal Total { get; set; }            
        }
    }
}
