﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class VoteMasterDTO
    {
        public int VoteID { get; set; }
        public int TutorialID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int MID { get; set; }
        public bool? IsActive { get; set; }
        public int Medal { get; set; }
        public string Details { get; set; }

        public string ArticleUrl { get; set; }
        public string Title { get; set; }
        public bool IsAdded { get; set; }

        public long VoteCount { get; set; }

        ////////////////
        public string Ids { get; set; }
        public string ExpDate { get; set; }
        public DateTime ExpiredDate { get; set; }
        public List<MentorMaster> mentorlist { get; set; }
        //[Required(ErrorMessage = "Please Upload Image")]
        //[Display(Name = "Upload Image")]
        public int IsMailed { get; set; }

    }
}
