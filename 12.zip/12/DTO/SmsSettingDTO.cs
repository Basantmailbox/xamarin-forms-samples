﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class SmsSettingDTO
    {
        public int CallerId { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public List<CourseDTO> CourseList { get; set; }
        public int SalesMenId { get; set; }
        public string SalesMenName { get; set; }
        public List<AdminUserDTO> SalesList { get; set; }
        [Required(ErrorMessage = "Enter Mobile")]
        public string Mobile { get; set; }
        public DateTime DateTime { get; set; }
        public int ModeId { get; set; }
        public bool IsActive { get; set; }
        public int? TrainingModeId { get; set; }
        public string ModeName { get; set; }
        public int Rid { get; set; }
       
        public List<CourseDTO> CourseMasterList { get; set; }
        public List<AdminUserDTO> SelectedList { get; set; }
        public List<CourseDTO> SelectedCourse { get; set; }
        public IEnumerable<SelectListItem> SalesMaster { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }
        public int? AdminId { get; set; }

    }
}
