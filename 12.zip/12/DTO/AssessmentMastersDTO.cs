﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class AssessmentMastersDTO
    {
        public int AssessmentId { get; set; }

        [Required(ErrorMessage = "Please Enter Question Paper Name")]
        [Display(Name = "MockupTest Name")]
        public string MockupTestTitle { get; set; }

        [Required(ErrorMessage = "Please Enter MockupTest")]
        [Display(Name = "MockupTest Name")]
        public int MockupTestId { get; set; }
        public string MockupTestName { get; set; }
        [Required(ErrorMessage = "Please enter Test Instructions")]
        public int InstructionId { get; set; }

        [Display(Name = "Question Paper Instructions")]
        [Required(ErrorMessage = "Please enter Test Instructions")]
        public string InstructionText { get; set; }

        [Display(Name = "Course")]
        public int CourseId { get; set; }
        public string CourseName { get; set; }


        [Display(Name = "Category")]
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public int? AssignmentId { get; set; }

        public int? DocumentId { get; set; }
        [Display(Name = "Document Name")]
        public string DocumentName { get; set; }


        public List<AssessmentInstruction> AssessmentInstructionList { get; set; }
        public List<CourseDTO> courseList { get; set; }
        public List<DocumentDTO> DocumentList { get; set; }
        public List<MockUpTestMasterDTO> MockUpTestList { get; set; }
        public List<CategoryDTO> CategoryList { get; set; }
        public string DateDisp { get; set; }
        public bool IsAssign { get; set; }

        //////////////mapping////////
        public DateTime AssignedDate { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public DateTime AssignmentFromDate { get; set; }
        public DateTime AssignmentToDate { get; set; }
        public int BatchID { get; set; }
    }
}
