﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingQuestionDTO<T> : PagingDTO<T> where T : class
    {
        public int TotalQuestionCount { get; set; }
        public IEnumerable<QuestionMasterDTO> QuestionList { get; set; }
    }
}
