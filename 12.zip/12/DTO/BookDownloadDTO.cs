﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class BookDownloadDTO
    {
        public int ID { get; set; }
        public Int64 MemberId { get; set; }
        public string BookName { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public DateTime DownloadDate { get; set; }

    }
}
