﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class QuotationsAndChildDTO
    {
        public long Id { get; set; }

        [Required(ErrorMessage = "Enter QuotationNo")]
        public string QuotationNo { get; set; }

        [Required(ErrorMessage = "Enter CustomerName")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Enter Email")]
        public string Email { get; set; }
        public string ContactNo { get; set; }
        [Required(ErrorMessage = "Enter State")]
        public int StateId { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string Address { get; set; }
        [Required(ErrorMessage = "Enter Currency")]
        public string Currency { get; set; }
        
        public long ParentId { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public decimal Price { get; set; }
        public int NoDays { get; set; }
        public int HrsPerDay { get; set; }
        public List<QuotationsChild> QuotationsChildList { get; set; }

    }
}
