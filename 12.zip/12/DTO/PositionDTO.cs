﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.VM
{
    public class PositionDTO_
    {

        public int Id { get; set; }
        [Required(ErrorMessage="Please enter Position Type")]
        public string PositionType { get; set; }
        [Required(ErrorMessage = "Please enter Description")]
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        public List<PositionDTO_> PositionList { get; set; }
    }
}
