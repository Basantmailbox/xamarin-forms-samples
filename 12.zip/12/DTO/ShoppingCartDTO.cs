﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
  public  class ShoppingCartDTO
    {
        
        public long ShoppingCartDataID { get; set; }

        public int UserID { get; set; }

        public int TotalCount { get; set; }

        public bool Isactive { get; set; }


        public int CourseId { get; set; }
        public int CourseType { get; set; }
        public string name { get; set; }
        public int Quantity { get; set; }

        public decimal CoursePrice { get; set; }

        public decimal ToTal { get; set; }

        public decimal Price { get; set; } // Price before Discont
        public decimal DiscountPercentage { get; set; } // Discont %  from databse or RunningCourseSale if it is SelfPlaced
        
        public int CartsItemId { get; set; }
        

        //for calculation only
        public decimal Discount { get; set; } //Discont amount coming from databse or RunningCourseSale if it is SelfPlaced
        public decimal NetPrice { get; set; }  //Price after Discont form system
        public decimal ServiceTax { get; set; }
        public string STaxName{ get; set; }
        public decimal Total{ get; set; }
        public string mobileImage { get; set; }
        public int StateId { get; set; }
        public string BillAddress { get; set; }


        //////////////////////////
        public bool IsOnSale { get; set; }
        public decimal SalePercentage { get; set; }

        public decimal SaleOffAmount{ get; set; }
        public decimal AfterSale{ get; set; }

        public decimal TotalDiscountPercentage { get; set; }
        public decimal TotalDiscountPercentageAmount { get; set; }

        public int DiscountId { get; set; }

        public string CouponCode { get; set; }
        public string Currency { get; set; }

        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string UserContact { get; set; }

        public DateTime DateCreated { get; set; }
        public string CourseName { get; set; }
    }
}
