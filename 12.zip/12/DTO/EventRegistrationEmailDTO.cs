﻿using DNTShared.Entities;
//using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class EventRegistrationEmailDTO
    {
        public List<EventRegistrationDTO> AllRegisteredMember { get; set; }
        public int TotalCounts { get; set; }
       
        public List<EventDTO> EventList { get; set; }
        public List<EventType> EventTypeList { get; set; }
        public int? EventId { get; set; }
        public int? EventTypeId { get; set; }
    }
}
