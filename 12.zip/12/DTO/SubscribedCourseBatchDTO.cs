﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class SubscribedCourseBatchDTO
    {
        public int CourseSubscriptionId { get; set; }

        public long MemberId { get; set; }
      
        public int ModeId { get; set; }
        public string Mode { get; set; }
        public int CourseId { get; set; }
        public string Course { get; set; }
    
        public bool? IsActive { get; set; }

        public virtual MemberDTO memberDetails { get; set; }

        public int BatchId { get; set; }

        [Required(ErrorMessage = "Please fill Batch Name")]
        [Display(Name = "Batch Name")]
        public string BatchName { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string DispStartDate { get; set; }
        public string DispEndDate { get; set; }
    }
}
