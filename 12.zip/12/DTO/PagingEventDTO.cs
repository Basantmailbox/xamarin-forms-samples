﻿
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingEventDTO<T> : PagingDTO<T> where T : class
    {
        public virtual ICollection<EventType> EventType { get; set; }
        [Display(Name = "Event Title")]
        public int? EventId { get; set; }
        public int? EventTypeId { get; set; }
        public List<EventDTO> EventList { get; set; }
        public List<EventType> EventTypeList { get; set; }
    }
}
