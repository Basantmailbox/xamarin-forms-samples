﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class MemberBatchDetailDTO
    {
        public int BatchId { get; set; }
        public string BatchName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string TrainingMode { get; set; }
        public DateTime BatchTiming { get; set; }
        public string BatchCode { get; set; }
        public string TrainerName { get; set; }
        public string MeetingUrl { get; set; }
        public string MeetingPassword { get; set; }
        public string Title { get; set; }

        public TimeSpan BatchHours { get; set; }
        public DateTime BatchEndTiming { get; set; }
        public string BatchDays { get; set; }
        public string BatchStartTimingDisplay { get; set; }
        public string BatchEndTimingDisplay { get; set; }

    }
}
