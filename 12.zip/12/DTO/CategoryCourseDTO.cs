﻿using System;

namespace DNTShared.DTO
{
    public class CategoryCourseDTO
    {
        public string CategoryName { get; set; }
        public int CourseCount { get; set; }
        public string Url { get; set; }
        public string ImageUrl { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
