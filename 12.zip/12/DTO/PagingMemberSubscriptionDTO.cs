﻿
using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingMemberSubscriptionDTO<T> : PagingDTO<T> where T : class
    {
        public int? CourseCategoryId { get; set; }
        public List<CourseCategoryDTO> CourseCategoriesList { get; set; }
        public int? FilterId { get; set; }
        public List<FilterOptionsDTO> FilterOptionList { get; set; }
        public virtual CourseSubscription CourseSubscription { get; set; }
        public IEnumerable<SubscribedCourseBatchDTO> CourseSubs { get; set; }
    }
}
