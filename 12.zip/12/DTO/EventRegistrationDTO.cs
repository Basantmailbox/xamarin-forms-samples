﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class EventRegistrationDTO
    {
        public int EventRegistrationId { get; set; }
        public int EventId { get; set; }
        public Int64 MemberId { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string MobileNo { get; set; }
        public string ProfilePic { get; set; }
        public DateTime? RegistrationDate { get; set; }
        public DateTime? VerificationDate { get; set; }
        public bool IsVerified { get; set; }
        //
        public string EventTitle { get; set; }
        public string EventDisplayDateTime { get; set; }
        public DateTime EventDate { get; set; }
        public string Url { get; set; }
        public string EventSpeakers { get; set; }
        public virtual EventDTO Event { get; set; }
        
    }
}
