﻿
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingBatchDocDTO<T> : PagingDTO<T> where T : class
    {
        public int BatchId { get; set; }
        public string BatchName { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public DateTime AssignmentFromDate { get; set; }
        public DateTime AssignmentToDate { get; set; }
        public int DocumentId { get; set; }
        public string DocumentName { get; set; }
        public int DocumentTypeId { get; set; }
        public List<DocumentType> documentTypeList { get; set; }
        public virtual ICollection<DocumentType> documentType { get; set; }
        public IEnumerable<BatchMasterDTO> BatchMasterList { get; set; }
        public int MockupTestMasterId { get; set; }
        public string MockupTestTitle { get; set; }
        public IEnumerable<MockUpTestMasterDTO> MockUpTestList { get; set; }
       
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }
    }
}
