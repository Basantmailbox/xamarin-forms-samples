﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
    public class PlayerDTO
    {
        public int CourseId { get; set; }
        public string Name { get; set; }
        public string CourseUrl { get; set; }
        public string ImageUrl { get; set; }
        public int Accessibility { get; set; }
        public Int64 UserId { get; set; }
        public Int64 TopicId { get; set; }
        public Int64 SubTopicId { get; set; }
        public int MembershipId { get; set; }

        public string ProfileImageUrl { get; set; }
        public ICollection<CourseTopicDTO> Topics { get; set; }
    }
    public class CourseTopicDTO
    {
        public int TopicId { get; set; }
        public string TopicName { get; set; }
        public TimeSpan TopicDuration { get; set; }
        public ICollection<CourseSubTopicDTO> SubTopics { get; set; }
        public ICollection<MockupTestQuestionOptionAnswerDTO> QuizQuestions { get; set; }
    }
    public class CourseSubTopicDTO
    {
        public int SubTopicId { get; set; }
        public string SubTopicName { get; set; }
        public string Content { get; set; } //Description
        public string PdfPath { get; set; }
        public string VideoUrl { get; set; } //UrlPath
        public string CodePath { get; set; }
        public string Duration { get; set; }
        public int TopicType { get; set; }
        public string IDELanguage { get; set; }
        public string Instructions { get; set; }
        public string Hint { get; set; }
        public string Solution { get; set; }
        public bool IsLock { get; set; } //private=true, public=false
        public bool IsBookmarked { get; set; }
        public bool IsLearnt { get; set; }
    }

    public class QuizDTO
    {
        public int QuestionId { get; set; }
        public string Question { get; set; }
        public string Code { get; set; }
        public ICollection<AnswerDTO> Answers { get; set; }
        public string Correct { get; set; }
        public int Marks { get; set; }
    }

    public class AnswerDTO
    {
        public int AnswerId { get; set; }
        public string Option { get; set; }
        public string Answer { get; set; }
    }
}
