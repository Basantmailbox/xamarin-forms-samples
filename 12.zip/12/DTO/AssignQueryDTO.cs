﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class AssignQueryDTO
    {

        public List<QueryDTO> Queries { get; set; }
        [Display(Name = "Course")]
        public int? CourseId { get; set; }
        public List<CourseDTO> CourseList { get; set; }
        [Display(Name = "User Name")]
        public int AdminId { get; set; }
        public List<AdminUserDTO> AdminUsers { get; set; }
        public int OldAdminId { get; set; }
        public string QueryIds { get; set; }
        public int AssignBy { get; set; }
    }

    public class ReAssignQueryViewModel
    {

        public List<QueryDTO> Queries { get; set; }
        public int FollowupHistoryId { get; set; }
        [Display(Name = "User Name")]
        public int AssignedUserId { get; set; }
        public List<AdminUserDTO> AssignedUsers { get; set; }

        public int ReAssignedUserId { get; set; }
        public List<AdminUserDTO> ReAssignedUsers { get; set; }
        public string QueryIds { get; set; }
        public int PageSize { get; set; }
        public int Page { get; set; }
        public int TotalRows { get; set; }
        public int AssignBy { get; set; }
        public int ExistUserId { get; set; }
        public int QueryId { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime? GrabbedDate { get; set; }
        public string AssignedDateDisp { get; set; }
        public string GrabbedDateDisp { get; set; }
        public string CurrentAssignedUserName { get; set; }
        public string NewAssignedUserName { get; set; }
        public string AssignByName { get; set; }
    }
}
