﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
  public  class InstallmentList
    {
        public string InstallmentName { get; set; } 
        public decimal NetPrice { get; set; }
        public DateTime? ExpiryDate { get; set; }

        public decimal? ServiceTaxPercentage { get; set; }

        public decimal? ServiceTax { get; set; }



    }
}
