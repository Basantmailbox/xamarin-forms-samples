﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class CoursePriceDTO
    {
        public int CourseId { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public decimal Price { get; set; }
        
        public bool IsOnSale { get; set; }
        public decimal SalePercentage { get; set; }

        public decimal SaleOffAmount { get; set; }
        public decimal AfterSale { get; set; }
        public bool IsPaymentGateway { get; set; }
        public int CourseType { get; set; }

        public string Currency { get; set; }
        public int Sequence { get; set; }
        public string CourseSellingPoints { get; set; }

        public bool IsCourseSubscription { get; set; }
        
    }
}
