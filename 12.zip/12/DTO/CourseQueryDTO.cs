﻿using DNTShared;
using DNTShared.Entities;
//using DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class CourseQueryDTO
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Please enter your current City")]
        [Display(Name = "Current City")]
        [StringLength(50)]
        public string City { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Mobile No")]
        [StringLength(20)]
        public string ContactNo { get; set; }
        public string code { get; set; }

        [Required(ErrorMessage = "Please enter subject")]
        [Display(Name = "Subject")]
        [StringLength(50)]
        public string Subject { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [Display(Name = "Message")]
        [StringLength(400)]
        public string Message { get; set; }

        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int CourseId { get; set; }

        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }

        public DateTime? SubmitDate { get; set; }
        public string SubmitDateDisplay { get; set; }
         
    }
}
