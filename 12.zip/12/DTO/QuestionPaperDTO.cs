using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

namespace DNTShared.DTO
{
    public class QuestionPaperDTO
    {
        public int QuestionPaperId { get; set; }

        [Required(ErrorMessage = "Please Enter Question Paper Title")]
        [Display(Name = "Question Paper Title")]
        public string QuestionPaperTitle { get; set; }


        public List<QuestionDifficultyLevel> DifficultyLevelList { get; set; }
        public List<AssessmentInstruction> QuestionPaperInstructionList { get; set; }
        public List<QuestionPaperTypeDTO> QuestionPaperTypeList { get; set; }
        public List<QuestionPaperDuration> TotalDurationList { get; set; }
        public List<QuestionPaperTotalQuestionDTO> TotalQuestionList { get; set; }

        public virtual ICollection<MockupTestMasterQuestionMappingDTO> QuestionPaperDetails { get; set; }

        public List<QuestionSubjectsDTO> SubjectList { get; set; }
        public List<CourseDTO> CourseList { get; set; }

    }
    public class QuestionPaperTotalQuestionDTO
    {

        public int QuestionPaperTotalQuestionId { get; set; }
        public int Value { get; set; }

    }
}
