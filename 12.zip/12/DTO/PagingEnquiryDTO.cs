﻿
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
namespace DNTShared.DTO
{
    public class PagingEnquiryDTO<T> : PagingDTO<T> where T : class
    {
        [Display(Name = "Provider")]
        public int? ProviderId { get; set; }
        public IEnumerable<EnquiryProvider> EnqTypeList { get; set; }
        public int Batch { get; set; }
        public int Queryid { get; set; }
        public string CloseRemark { get; set; }
        //[Display(Name = "User Name")]
        //public int AdminId { get; set; }
        //public List<AdminUserDTO> AdminUsers { get; set; }
     
        //public string QueryIds { get; set; }
    }
}
