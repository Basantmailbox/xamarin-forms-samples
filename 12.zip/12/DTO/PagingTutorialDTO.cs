﻿
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingTutorialDTO<T> : PagingDTO<T> where T : class
    {
        public int? AuthorId { get; set; }
        public List<MentorMaster> AuthorList { get; set; }
        public List<CategoryDTO> CategoryLst { get; set; }
    }
}
