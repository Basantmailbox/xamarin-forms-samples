﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class CourseMenuDTO
    {
        public string Name { get; set; }
        public int CourseCount { get; set; }
        public string Url { get; set; }
        public IEnumerable<MenuPathsDTO> Paths { get; set; }
    }

    public class MenuPathsDTO
    {
        public string Name { get; set; }
        public string Url { get; set; }
    }
}
