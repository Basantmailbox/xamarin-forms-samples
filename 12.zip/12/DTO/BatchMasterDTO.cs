﻿using DNTShared;
using DNTShared.DTO;
using DNTShared.Entities;
//using DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class BatchMasterDTO
    {
        public int BatchId { get; set; }

        [Required(ErrorMessage = "Please fill Batch Name")]
        [Display(Name = "Batch Name")]
        public string BatchName { get; set; }

        public int TotalMockUpTest { get; set; }
        public int AssignedMockupTest { get; set; }
        public int ModeId { get; set; }

        public string modename { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string DispStartDate { get; set; }
        public string DispEndDate { get; set; }
        public bool IsActive { get; set; }

        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int CourseId { get; set; }

        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }
        public List<MentorMaster> MentorList { get; set; }
        public int TotalMember { get; set; }
        [Required(ErrorMessage = "Please fill Batch Code")]
        public string BatchCode { get; set; }

        [Required(ErrorMessage = "Please Select Trainer")]
        public int MentorId { get; set; }
        public string Name { get; set; }
       
        public int Id { get; set; }

        public string MockUpTitle { get; set; }

        [Required(ErrorMessage = "Please fill Batch Url")]
        public string Url { get; set; }
        public string FullDetail { get; set; }
        [Display(Name = "Description")]
        public string ImportantInfo { get; set; }
        public string PostedBy { get; set; }
        [Required(ErrorMessage = "Please fill Meeting Url")]
        public string MeetingUrl { get; set; }
        [Required(ErrorMessage = "Please Fill Title")]

        public string MeetingPassword { get; set; } 
        public string Title { get; set; }
        public string OldEventName { get; set; }
        public string BatchDays { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal TotalINR { get; set; }
        public decimal TotalUSD { get; set; }
        public decimal DiscountINR { get; set; }
        public decimal NetPriceUSD { get; set; }
        public decimal NetPriceINR { get; set; }
        public decimal DiscountUSD { get; set; }
        public bool IsPaymentGateway { get; set; }
        public int CourseType { get; set; }
        public TimeSpan BatchHours { get; set; }
        
        [Required(ErrorMessage = "Please fill Batch Timing")]
        [Display(Name = "Batch Timing")]
        
        public DateTime BatchTiming { get; set; }
        public string BatchStartTimingDisplay { get; set; }

        public DateTime BatchEndTiming { get; set; }
        public string BatchEndTimingDisplay { get; set; }
        
        public string TimeZone { get; set; }
        public string listzone { get; set; }
        public IEnumerable<string> BatchDaysSelected { get; set; }
        public IEnumerable<SelectListItem> DTypelist { get; set; }
        public List<SelectListItem> Dayslist { get; set; }
        public int Classes { get; set; }

        /// <summary>
        /// /////////Price////////////
        /// </summary>
        public bool IsOnSale { get; set; }
        public decimal SalePercentage { get; set; }
        public decimal SaleOffAmount { get; set; }
        public decimal AfterSale { get; set; }
        public decimal Price { get; set; }
        public string Currency { get; set; }

        public int IsSelfPlacedBatch { get; set; }
    }
}
