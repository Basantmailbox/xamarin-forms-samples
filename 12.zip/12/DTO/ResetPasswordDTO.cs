﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
//using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class ResetPasswordDTO
    {      
        public string EmailId { get; set; }

        [Required(ErrorMessage = "Please enter your password")]
        [Display(Name = "Password")]
        [StringLength(50)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please re-enter your password")]
        [Display(Name = "Confirm Password")]
        [StringLength(50)]
        [Compare("Password", ErrorMessage = "Password and Confirm Password does not matched")]
        public string ConfirmPassword { get; set; }

        public string EncryptedKey { get; set; }
    }
}
