﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class StepQuestionDTO
    {
        public string ID { get; set; }

        [Range(1, 50, ErrorMessage = "Select Question")]
        public Int64 QuestionID { get; set; }

        [Required(ErrorMessage = "Enter Question")]
        [Display(Name = "Question")]
        [StringLength(100)]
        public string Question { get; set; }

        [Required(ErrorMessage = "Enter Answer")]
        [Display(Name = "Answer")]
        public string Answer { get; set; }

        public string PostedBy { get; set; }

        [Required(ErrorMessage = "Enter posted date")]
        [Display(Name = "Posted Date")]
        [DataType(DataType.Date)]
        public DateTime PostedDate { get; set; }
        public string strPostedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
        public string strUpdatedDate { get; set; }

        [Range(1, 50, ErrorMessage = "Select Category")]
        [Display(Name = "Category")]
        public int CategoryID { get; set; }

        [Display(Name = "CategoryName")]
        public string CategoryName { get; set; }

        [Range(1, 50, ErrorMessage = "Select SubCategory")]
        [Display(Name = "SubCategory")]
        public int SubCategoryID { get; set; }

        public Int64? TotalViews { get; set; }
        public string Url { get; set; }

    }
}
