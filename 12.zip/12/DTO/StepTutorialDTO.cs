﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class StepTutorialDTO
    {
        public int TutorialID { get; set; }

        [Required(ErrorMessage = "Select Tutorial")]
        public string ID { get; set; }

        [Required(ErrorMessage = "Enter title")]
        [Display(Name = "Title")]
        [StringLength(200)]
        public string Title { get; set; }

        [Display(Name = "Version Support")]
        [StringLength(50)]
        public string Version { get; set; }

        [Required(ErrorMessage = "Enter short description")]
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }

        [Required(ErrorMessage = "Enter description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Enter Meta Keywords")]
        [Display(Name = "Meta Keywords")]
        [StringLength(300)]
        public string MetaKeywords { get; set; }

        public string PostedBy { get; set; }

        [Required(ErrorMessage = "Enter posted date")]
        [Display(Name = "Posted Date")]
        [DataType(DataType.Date)]
        public DateTime PostedDate { get; set; }
        public string strPostedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
        public string strUpdatedDate { get; set; }

        [Range(1, 50, ErrorMessage = "Select Category")]
        [Display(Name = "Category")]
        public int CategoryID { get; set; }

        [Display(Name = "CategoryName")]
        public string CategoryName { get; set; }

        //[Range(1, 50, ErrorMessage = "Select SubCategory")]
        [Display(Name = "SubCategory")]
        public int SubCategoryID { get; set; }
        public string SubCategoryName { get; set; }

        public string Url { get; set; }
        public string MetaDescription { get; set; }
        public Int64? TotalViews { get; set; }
        [Required(ErrorMessage = "Enter Domain Name")]
        public string DomainName { get; set; }
        public string TutorialTitle { get; set; }
        public string TutorialSubCategoryName { get; set; }

    }
}
