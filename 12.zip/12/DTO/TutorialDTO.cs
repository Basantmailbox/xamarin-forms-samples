﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class TutorialDTO
    {
        public TutorialDTO()
        {
            AuthorList = new List<MentorMaster>();
        }
        public int TutorialID { get; set; }
        public string ID { get; set; }
        public int Priority { get; set; }

        [Display(Name = "Schema")]
        public string SchemaSEO { get; set; } 

        [Required(ErrorMessage = "Enter short title")]
        [Display(Name = "Short Title")]
        [StringLength(100)]
        public string ShortTitle { get; set; }

        [Required(ErrorMessage = "Enter title")]
        [Display(Name = "Title")]
        [StringLength(200)]
        public string Title { get; set; }

        [Display(Name = "Version Support")]
        [StringLength(50)]
        public string Version { get; set; }

        [Required(ErrorMessage = "Enter short description")]
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }

        [Required(ErrorMessage = "Enter description")]
        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Enter tags")]
        [Display(Name = "Tags")]
        [StringLength(200)]
        public string Tags { get; set; }

        [Required(ErrorMessage = "Enter Meta Keywords")]
        [Display(Name = "Meta Keywords")]
        [StringLength(300)]
        public string MetaKeywords { get; set; }

        public string PostedBy { get; set; }

        [Required(ErrorMessage = "Enter posted date")]
        [Display(Name = "Posted Date")]
        [DataType(DataType.Date)]
        public DateTime PostedDate { get; set; }
        public string strPostedDate { get; set; }

        public DateTime UpdatedDate { get; set; }
        public string strUpdatedDate { get; set; }

        [Range(1, 250, ErrorMessage = "Select Category")]
        [Display(Name = "Category")]
        public int CategoryID { get; set; }

        [Display(Name = "CategoryName")]
        public string CategoryName { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; }
        public long? TotalViews { get; set; }
        public string TViews { get; set; }

        public string Url { get; set; }
        public string MetaDescription { get; set; }
        public string PostUrl { get; set; }
        [Required(ErrorMessage = "Enter Article Url")]
        public string ArticleUrl { get; set; }
        public List<CategoryDTO> CategoryList { get; set;}

        public string SourceCodeUrl { get; set; }
        public string DomainName { get; set; }
        public int MentorId { get; set; }
        //public int Mentors { get; set; }
        public string Authors { get; set; }
        public List<MentorMaster> AuthorMasterList { get; set; }
        public List<MentorMaster> AuthorList { get; set; }       
        public List<MentorMaster> SelectedAuthors{ get; set; }
        public IEnumerable<SelectListItem> AuthorMaster { get; set; }      

        [Required(ErrorMessage = "Please Upload Image")]
        [Display(Name = "Upload Image")]
        public HttpPostedFileBase TImage { get; set; }
        public string TutorialImage { get; set; }

        public int ArticleLevel { get; set; }
        public int ArticleType { get; set; }
        public decimal Sequence { get; set; }
        public bool IsMailed { get; set; }

        public int WordCount { get; set; }
        public decimal WordPrice { get; set; }
    }
}
