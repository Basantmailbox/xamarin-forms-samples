﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
//using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class ChangePasswordDTO
    {
        public Int64 MemberId { get; set; }

        public string Email { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "Password")]
        [StringLength(50)]
        public string OldPassword { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "Password")]
        [StringLength(50)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "Password")]
        [StringLength(50)]
        [Compare("NewPassword", ErrorMessage = "Confirm Password does not matched")]
        public string ConfirmPassword { get; set; }
    }
}
