﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class WebinarDTO
    {
        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string YourName { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your ContactNo")]
        [Display(Name = "ContactNo")]
        [StringLength(20)]
        public string ContactNo { get; set; }

        public string WebinarName { get; set; }

        public DateTime WebinarDate { get; set; }
        public string WebinarTime { get; set; }

        public string Duration { get; set; }
        public bool IsActive { get; set; }
    }
}
