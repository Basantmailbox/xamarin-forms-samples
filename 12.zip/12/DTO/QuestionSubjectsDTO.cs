﻿//using DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class QuestionSubjectsDTO
    {
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Please Enter Category Name")]
        [Display(Name = "Category Name")]
        [StringLength(100)]
        public string CategoryName { get; set; }
        public bool IsActive { get; set; }
         
    }
}
