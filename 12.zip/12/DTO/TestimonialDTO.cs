﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;

namespace DNTShared.DTO
{
    public class TestimonialDTO
    {
        public int TestimonialId { get; set; }

        [Required(ErrorMessage = "Please Enter Message")]
        [Display(Name = "Testimonial Contents")]
        public string Contents { get; set; }

        [Required(ErrorMessage = "Please Enter Student Name")]
        [Display(Name = "Students Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please Enter Student Designation")]
        public string Designation { get; set; }

        public string LinkUrl { get; set; }
        public int LinkType { get; set; }

        public string DisLinkType { get; set; }
        [Required(ErrorMessage = "Please Select Course")]
        public int CourseId { get; set; }
        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        public decimal Reviews { get; set; }
    public string ImageUrl { get; set; }
        public bool? IsActive { get; set; }
        public int? GenderId { get; set; }
        [Required(ErrorMessage = "Please Upload Image")]

        [Display(Name = "Upload Image")]
        // [ValidatePhoto]
        public HttpPostedFileBase File { get; set; }
        public List<GenderMaster> genderList { get; set; }
        public virtual CourseDTO Course { get; set; }
        public List<CourseDTO> courseList { get; set; }

        public int UpdatedBy { get; set; }
        public int CreatedBy { get; set; }
        public string UpdatedByName { get; set; }
        public string CreatedByName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
         public string DisCreatedUpadate { get; set; }
    }
}
