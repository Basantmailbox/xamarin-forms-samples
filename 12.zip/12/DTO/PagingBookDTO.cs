﻿
using DNTShared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PagingBookDTO<T> : PagingDTO<T> where T :class
    {       
        public int? BookId { get; set; }
        public List<BookMasterDTO> BooksList { get; set; }
    }
}
