﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class PaymentMasterDTO_V1
    {
        public long Id { get; set; }
        public string PaymentId { get; set; }
        public string TransactionId { get; set; }
        public decimal Price { get; set; }
        public decimal SaleOffAmount { get; set; }
        public decimal AfterSaleAmount { get; set; }
        public bool Discount_Applied { get; set; }
        public decimal TotalDiscountPercentage { get; set; }
        public decimal TotalDiscountPercentageAmount { get; set; }
        public decimal NetPrice { get; set; }

        public decimal TotalSaving { get; set; }
        public decimal ServiceTaxPercentage { get; set; }
        public decimal ServiceTax { get; set; }
        public decimal Total { get; set; }
        public string Status { get; set; }
        public string TransactionStatus { get; set; }
        public string PaymentGateway { get; set; }
        public string Currency { get; set; }
        public string CustomerName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string StateCode { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Address { get; set; }
        public long ShoppingCartDataID { get; set; }
        public int DiscountId { get; set; }
        public List<PaymentDTO_V1> Payments { get; set; }
        public string CouponCode { get; set; }

        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }

        public decimal IGSTPercent { get; set; }
        public decimal CGSTPercent { get; set; }
        public decimal SGSTPercent { get; set; }
        public decimal RoundOff { get; set; }
        public string URLSource { get; set; }
        public string ReferralCode { get; set; }
    }
}
