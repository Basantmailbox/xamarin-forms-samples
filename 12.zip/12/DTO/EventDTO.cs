﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class EventDTO
    {

        public int EventID { get; set; }
        public string ID { get; set; }
        [Required(ErrorMessage = "Enter Event title")]
        [Display(Name = "Event Title")]
        [StringLength(200)]
        public string EventTitle { get; set; }

        [Required(ErrorMessage = "Enter short description")]
        [Display(Name = "Short Description")]
        public string ShortDescription { get; set; }
        [Display(Name = "Event Address")]
        public string EventAddress { get; set; }

        [Required(ErrorMessage = "Enter EventType")]
        [Display(Name = "Event Type")]
        public int EventTypeId { get; set; }
        [Display(Name = "Event Type")]
        public string EventTypeName { get; set; }
        [Required(ErrorMessage = "Enter description")]
        [Display(Name = "Description")]
        public string EventDescription { get; set; }

        [Required(ErrorMessage = "Enter Meta Keywords")]
        [Display(Name = "Meta Keywords")]
        [StringLength(300)]
        public string MetaKeywords { get; set; }

        [Required(ErrorMessage = "Enter Event Joining Link")]
        [StringLength(300)]
        [Display(Name = "Event Joining Link")]
        public string EventJoiningLink { get; set; }        

        public string PostedBy { get; set; }

        //[Required(ErrorMessage = "Enter event date")]
        [Display(Name = "Event Date")]
        //[DataType(DataType.Date)]
        public DateTime EventDate { get; set; }
        public string strEventDate { get; set; }

        [Display(Name = "Event Display Time")]
        public string EventDisplayDateTime { get; set; }

       // [Required(ErrorMessage = "Enter posted date")]
        [Display(Name = "Posted Date")]
        //[DataType(DataType.Date)]
        public DateTime PostedDate { get; set; }
        public string strPostedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }
        public string strUpdatedDate { get; set; }

        public string Url { get; set; }
        [Display(Name = "Meta Description")]
        public string MetaDescription { get; set; }
        [Display(Name = "Total Views")]
        public Int64? TotalViews { get; set; }
        [Display(Name = "Event Image")]
        public string EventImage { get; set; }
        [Display(Name = "Upload Image")]
        public HttpPostedFileBase File { get; set; }
        public bool? IsActive { get; set; }

        [Display(Name = "Registration Closed?")]
        public bool IsRegistrationClosed { get; set; }

        public int TotalCounts { get; set; }
        public int TotalAttendees { get; set; }
        public virtual EventType EventTypes { get; set; }
        public virtual ICollection<EventRegistrationDTO> EventRegistrations { get; set; }

        public int MentorId { get; set; }
        [Display(Name = "Speaker")]
        public string EventSpeakers { get; set; }
        public string DomainName { get; set; }

        public List<MentorMaster> SpeakersMasterList { get; set; }
        public List<MentorMaster> SpeakersList { get; set; }
        public List<MentorMaster> SelectedSpeakers { get; set; }
        public IEnumerable<SelectListItem> SpeakersMaster { get; set; }
    }
}
