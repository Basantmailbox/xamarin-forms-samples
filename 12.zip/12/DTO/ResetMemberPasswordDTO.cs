﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class ResetMemberPasswordDTO
    {
        public Int64 MemberId { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "Password")]
        [StringLength(50)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "New Password")]
        [StringLength(50)]
        [Compare("NewPassword", ErrorMessage = "Confirm Password does not matched")]
        public string ConfirmPassword { get; set; }
    }
}
