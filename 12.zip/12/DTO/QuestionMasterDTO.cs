using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class QuestionMasterDTO 
    {       
        public int QuestionId { get; set; }


        [Required(ErrorMessage = "Please fill Question Title")]
        [Display(Name="Question Title")]
        public string QuestionTitle { get; set; }
        public string QuestionCode { get; set; }
        [AllowHtml]
        public string OptionAText { get; set; }
         [AllowHtml]
        public string OptionBText { get; set; }
         [AllowHtml]
        public string OptionCText { get; set; }
         [AllowHtml]
        public string OptionDText { get; set; }
         [AllowHtml]
        public string OptionEText { get; set; }

        [Display(Name = "Correct Answer Option")]
        public string CorrectOption { get; set; }

        [Display(Name = "Category")]
        public int CategoryID { get; set; }

        public string CategoryName { get; set; }

        [Display(Name = "Difficulty Level")]
        public int DifficultyLevelId { get; set; }

        public string DifficultyLevelName { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        [Display(Name = "Active Status")]
        public bool IsActive { get; set; }
        public int? Marks { get; set; }
        public int QuestionOptionId { get; set; }
        public string OptionChar { get; set; }
        public string OptionTitle { get; set; }

        public List<QuestionMasterOption> QuestionMasterOptionList { get; set; }
        public List<CategoryDTO> CategoryList { get; set; }
        public List<QuestionDifficultyLevel> DifficultyLevelList { get; set; }

    }
}
