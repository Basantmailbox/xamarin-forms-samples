﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class TutorialExcelDTO
    {

        public int totalArticle { get; set; }
        public string AuthorsName { get; set; }
        public string AuthorsEmail { get; set; }
        public String Date { get; set; }
        public decimal Sequence { get; set; }

        public int WordCount { get; set; }
        public decimal WordPrice { get; set; }
    }
}
