﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CourseDTO
    {
        public int CourseId { get; set; }
        [Required(ErrorMessage = "Please Enter Name")]
        public string Name { get; set; }
        public string Title { get; set; }
        public bool? IsActive { get; set; }

        [AllowHtml]
        public string Summary { get; set; }
        [AllowHtml]
        public string FooterDetails { get; set; }

        public string LargeBanner { get; set; }
        public string SmallBanner { get; set; }
        public string MobileBanner { get; set; }

        public string Keyword { get; set; }

        public string Description { get; set; }
        public int MentorId { get; set; }
        public string Mentors { get; set; }
        [Required(ErrorMessage = "Please Enter Url")]
        public string URL { get; set; }
        public decimal? Sequence { get; set; }
        public string DocumentUrl { get; set; }
        [AllowHtml]
        public string CourseFeatures { get; set; }
        [Required(ErrorMessage = "Please Enter Reviews")]
        public decimal Reviews { get; set; }
        [Required(ErrorMessage = "Please Enter Learners")]
        public string Learners { get; set; }

        [Required(ErrorMessage = "Please Upload Image")]
        [Display(Name = "Upload Image")]
        public HttpPostedFileBase Large { get; set; }
        public HttpPostedFileBase Small { get; set; }
        public HttpPostedFileBase Mobile { get; set; }

        public string TagLine { get; set; }
        [AllowHtml]
        public string CourseSellingPoints { get; set; }

        public List<CourseCategoryDTO> CourseCategories { get; set; }
        public List<MentorMaster> MentorMasterList { get; set; }
        public List<CourseDetail> CourseDetailList { get; set; }

        public List<MentorMaster> MentorList { get; set; }
        public List<MentorMaster> SelectedMentors { get; set; }
        public IEnumerable<SelectListItem> MentorMaster { get; set; }
        public IEnumerable<SelectListItem> SelectedCategories { get; set; }
        public List<CourseDTO> courseList { get; set; }

        public bool Selected { get; set; }
        public string SkillChallengeURL { get; set; }
        public int Id { get; set; }
        [Required(ErrorMessage = "Please Enter City")]
        public string City { get; set; }
        public string Type { get; set; }
        public int EnquiryType { get; set; }
        public string H1Tag { get; set; }
        public string H2Tag { get; set; }
        [Required(ErrorMessage = "Please Select Domain Name")]
        public string DomainName { get; set; }
        public string SkillName { get; set; }
        public int TotalLessons { get; set; }
        public string CoursesList { get; set; }
        public string CategoryList { get; set; }
        public int CourseType { get; set; }
        public string Duration { get; set; }
        public List<CourseDTO> UrlList { get; set; }
        public string DemoUrl { get; set; }

        /// <summary>
        /// ////coursesales
        /// </summary>
        public IEnumerable<SelectListItem> CourselistSales { get; set; }
        [Key]
        public int SaleId { get; set; }
        public string CourseIds { get; set; }
        public string SalesText { get; set; }
        [Required(ErrorMessage = "Enter News Text")]
        [Display(Name = "News Title")]
        public string NewsText { get; set; }
        public DateTime CreatedDate { get; set; }
        [Required(ErrorMessage = "Enter Expiry Date")]
        [Display(Name = "Expiry Date")]
        public DateTime ExpiryDate { get; set; }
        [Required(ErrorMessage = "Enter redirection Url")]
       
        [Display(Name = "Active Status")]
        public decimal DiscountPercentage { get; set; }
        public int IsFree { get; set; }
        public string IsFreeDis { get; set; }
        public string WhyUsContents { get; set; }

        public List<SkillMaster> SkillsList { get; set; }
        public List<SkillMaster> SelectedSkills { get; set; }
        public IEnumerable<SelectListItem> SkillList { get; set; }
        public int SkillId { get; set; }
        public List<Course> SelectcurList { get; set; }

        //Course List
        public List<Course> curList { get; set; }
        public List<CoursePriceDTO> curpriceList { get; set; }
        public IEnumerable<SelectListItem> CoursesL { get; set; }
        public int CourseCount { get; set; }
        public int SkillsCount { get; set; }
        public decimal TotalCPrice { get; set; }
        public decimal FixCPrice { get; set; }
        public decimal DisCPrice { get; set; }
        public decimal Final { get; set; }
        public List<CourseTopic> CurPreRecTopiclist { get; set; }
        public List<MaterCourseCurriculum> SubCourseDetailsList { get; set; }
        public CoursePrice CoursePricesSelf { get; set; }
        public CoursePriceDTO CoursePricesSelfDTO { get; set; }
        public List<MockUpTestMasterDTO> quizlist { get; set; }
        public string Currency { get; set; }
        
        //public int VideoTypeId { get; set; }
        public string CourseTypeName { get; set; }
        public int DifficultyLevelId { get; set; }
        public string DifficultyLevelName { get; set; }

        public int DifficultyTypeId { get; set; }
        public string DifficultyTypeName { get; set; }
        
        public List<Category> CategoryDDL { get; set; }

        public string CourseNewStatus { get; set; }
        public DateTime UpdatedDate { get; set; }
        public List<CourseDTO> RelatedVideos { get; set; }
        public List<CategoryDTO> CategoryLst { get; set; }
        public List<MockUpTestAttemptedStatusDTO> MemberList { get; set; }

        public int DocumentId4Preview { get; set; }
        public string DocumentURL4Preview { get; set; }
    }
}
