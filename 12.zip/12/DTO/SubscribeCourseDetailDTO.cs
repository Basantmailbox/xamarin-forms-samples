﻿using DNTShared.Entities;
using System.Collections.Generic;

namespace DNTShared.DTO
{
    public class SubscribeCourseDetailDTO
    {

        public int BatchId { get; set; }
        public string BatchName { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public string curdetails { get; set; }
        public int mode { get; set; }

        public int subtopic { get; set; }
        public bool flag { get; set; }

        public List<AssignedMockUpTestDTO> AssingMockList { get; set; }
        public List<CourseLiveSessionVideo> CurRecTopiclist { get; set; }
        public List<CourseLiveSessionVideo> CurRecTopiclistMaster { get; set; }
        public List<CourseTopic> CurPreRecTopiclist { get; set; }
        public bool CourseSubsType { get; set; }
        public int VideoAccess { get; set; }
        public string Reason { get; set; }
        public int CourseType { get; set; }
        public List<MaterCourseCurriculum> SubCourseDetailsList { get; set; }
        public int BatchIdLive { get; set; }
    }
}
