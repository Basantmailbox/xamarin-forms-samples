﻿using DNTShared;
using DNTShared.Entities;
//using DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class QuickQueryDTO
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string QName { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string QEmailID { get; set; }

        [Required(ErrorMessage = "Please enter your current City")]
        [Display(Name = "Current City")]
        [StringLength(50)]
        public string QCity { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Mobile No")]
        [StringLength(20)]
        public string QContactNo { get; set; }
        public string code { get; set; }

        [Required(ErrorMessage = "Please enter subject")]
        [Display(Name = "Subject")]
        [StringLength(50)]
        public string QSubject { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [Display(Name = "Message")]
        [StringLength(400)]
        public string QMessage { get; set; }

        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int QCourseId { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        public string CourseName { get; set; }

        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int QTrainingModeId { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }

        public string TrainingModeName { get; set; }
        public string Type { get; set; }
        public int EnquiryType { get; set; }
        public string sessionid { get; set; }

        public int UserId { get; set; }
    }
}
