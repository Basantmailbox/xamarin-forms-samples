﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class QueryRemarkUpdateDTO
    {
        public int QueryId { get; set; }

        [Display(Name = "Name")]
        public string QName { get; set; }

        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email")]
        // [StringLength(50)]
        //[RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string QEmailID { get; set; }
                
        [Display(Name = "Current City")]
        [StringLength(50)]
        public string QCity { get; set; }

        [Display(Name = "Mobile")]
        [StringLength(20)]
        public string QContactNo { get; set; }
        public string code { get; set; }

        [Required(ErrorMessage = "Please Select Course")]
        [Display(Name = "Course")]
        public int QCourseId { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        public string CourseName { get; set; }
        
        [Required(ErrorMessage="Please Enter Remarks")]
        public string Remarks { get; set; }
        public string RemarkUpdateBy { get; set; }

        [Required(ErrorMessage = "Please select Next Followup Date")]
        [Display(Name = "Next Followup Date")]
        public DateTime NextFollowupDate { get; set; }

        [Required(ErrorMessage = "Please Select Interest")]
        public int? EnquiryTypeId { get; set; }
        public List<EnquiryType> EnquiryTypes { get; set; }
        public int? EnquiryTypeIdf { get; set; }

        [Required(ErrorMessage = "Please Select Lead")]
        public int? EnquiryStatusId { get; set; }
        public List<EnquiryStatus> EnquiryStatus { get; set; }
        public int isremark { get; set; }
        public int RemarkType { get; set; }
        public int CloseFlag { get; set; }
        public int? Batch { get; set; }
        public int? Batchf { get; set; }
        public int OldEnquiryType { get; set; }
        public int Status { get; set; }
    }
}
