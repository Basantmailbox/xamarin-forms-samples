﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class CommentMasterDTO
    {
        public Guid CommentId { get; set; }
        [Required(ErrorMessage = "Please enter Content")]
        [AllowHtml]
        public string Contents { get; set; }
        public int ReferralID { get; set; }
        public long UserId { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsVerified { get; set; }
        public bool IsBook { get; set; }

        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string ArticleUrl { get; set; }
        public List<MemberDTO> memlist { get; set; }

        public List<ReplyOnCommentDTO> replylist { get; set; }

        public string elapsedtime { get; set; }
    }
}
