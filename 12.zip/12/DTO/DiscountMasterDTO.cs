﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
  public  class DiscountMasterDTO
    { public Discount Discount { get; set; }

        public List<Discount_AppliedToCourse> Discount_AppliedToCourse { get; set; }
        public bool CouponApplied { get; set; }
    }
}
