﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class AdsMastersDTO
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please enter the name of Ad")]
        public string AdsName { get; set; }
        public string PositionType { get; set; }
        public string Description { get; set; }
        public string Catname { get; set; }
        public bool? IsPopular { get; set; }
        public bool? IsActive { get; set; }
        public int? CategoryId { get; set; }
        public List<CategoryDTO> CategoryList { get; set; }
        public int PositionId { get; set; }
        //public List<PositionDTO> PositionList { get; set; }
        public List<PositionMasters> PositionList { get; set; }
        public int ImageId { get; set; }
        public List<AdsImageCollection> ImageList { get; set; }
        public int count { get; set; }

    }
}
