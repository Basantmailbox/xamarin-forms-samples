﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.DTO
{
   public class BookmarkDTO
    {
        public int CourseId { get; set; }

        public string CourseName { get; set; }

        public List<Bookmark> Bookmarks { get; set; }
        public int BookmarkCounter { get; set; }
    }
}
