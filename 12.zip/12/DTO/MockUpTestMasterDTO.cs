﻿using DNTShared;
using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class MockUpTestMasterDTO
    {
        public int MockupTestId { get; set; }

        [Required(ErrorMessage = "Please Enter Question Paper Name")]
        [Display(Name = "MockupTest Name")]
        public string MockupTestName { get; set; }

        [Required(ErrorMessage = "Please Select Difficulty Level")]
        [Display(Name = "Difficulty Type")]
        public int DifficultyType { get; set; }

        [Display(Name = "Difficulty Type Name")]
        public string DifficultyTypeName { get; set; }

        [Display(Name = "Category")]
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }

        [Display(Name = "Course")]
        public int CourseId { get; set; }
        public string CourseName { get; set; }

        [Display(Name = "Question Paper Type")]
        public string QuestionPaperTypeName { get; set; }

        [Required(ErrorMessage = "Please Enter Total Questions")]
        [Display(Name = "Total Questions")]
        public int QuestionPaperTotalQuestionValue { get; set; }

        [Required(ErrorMessage = "Please Enter Duration")]
        [Display(Name = "Duration")]
        public int QuestionPaperDurationValue { get; set; }

        [Display(Name = "Question Added")]
        public int? QuestionAdded { get; set; }

        public int Duration { get; set; }
        public int TotalQuestion { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public int TestType { get; set; }
        public string URL { get; set; }
        public string Description { get; set; }
        public string Keyword { get; set; }       
        public List<QuestionDifficultyLevel> DifficultyLevelList { get; set; }        
        public List<QuestionPaperTypeDTO> QuestionPaperTypeList { get; set; }
        public List<QuestionPaperDuration> TotalDurationList { get; set; }
        public List<QuestionPaperTotalQuestionDTO> TotalQuestionList { get; set; }

        public virtual ICollection<MockupTestMasterQuestionMappingDTO> QuestionPaperDetails { get; set; }

        public List<CategoryDTO> CategoryList { get; set; }
        public List<DropDownDTO> CourseList { get; set; }
        public decimal Score { get; set; }
        public decimal topScore { get; set; }

        public int CountMemberList { get; set; }
        public string CatImage { get; set; }
        public long MemberId { get; set; }
        public List<MockUpTestAttemptedStatusDTO> MemberList { get; set; }

        public int mapcat { get; set; }
        public string Details { get; set; }
    }
}
