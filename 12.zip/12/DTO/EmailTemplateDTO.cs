﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
   public class EmailTemplateDTO
    {
        public int EmailTemplateId { get; set; }
        [Display(Name = "Email Template Name")]
        [Required(ErrorMessage = "Please enter Email Template Name")]
        public string EmailTemplateName { get; set; }
        public string EmailFrom { get; set; }
        public string EmailUsername { get; set; }
        public string EmailPassword { get; set; }
        [Display(Name = "Email Subject")]
        [Required(ErrorMessage = "Please enter Email Subject")]
        public string EmailSubject { get; set; }
        [Display(Name = "Email Body")]
        [AllowHtml]
        [Required(ErrorMessage = "Please Fill Email Body")]
        public string EmailBody { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public Boolean IsActive { get; set; }
        public string DomainName { get; set; }
    }
}
