﻿using DNTShared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.DTO
{
    public class MemberDTO
    {

        public Int64 MemberId { get; set; }

        [Required(ErrorMessage = "Please enter name")]
        [Display(Name = "Full Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "Password")]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        public string Password { get; set; }

        [Required(ErrorMessage = " ")]
        [Display(Name = "Confirm Password")]
        [StringLength(50)]
        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = "Confirm Password does not matched")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Please enter your email id")]
        [Display(Name = "Email")]
        [StringLength(50)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Please enter a valid e-mail adress")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        //[Display(Name = "Mobile Number")]
        [StringLength(20)]
       // [RegularExpression(@"^(\+\d{1,3}[- ]?)?\d{10}$", ErrorMessage = "Please enter a valid contact number")]
        public string ContactNo { get; set; }
        public string MobileNo { get; set; }
        public string ProfilePic { get; set; }
        public string ProfilePicDomain { get; set; }

        [Display(Name = "Profile Picture")]
        // [ValidatePhoto]
        public HttpPostedFileBase File { get; set; }

        public int? MailSentCounter { get; set; }

        public string EncriptedKey { get; set; }

        public string VerificationUrl { get; set; }

        public Nullable<bool> IsActive { get; set; }

        public DateTime CreatedDate { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }

        public Nullable<bool> IsVerified { get; set; }
        public Nullable<DateTime> VerificationDate { get; set; }
        //
        [Display(Name = "Designation")]
        [StringLength(100)]
        public string Designation { get; set; }

        [Display(Name = "Company")]
        [StringLength(250)]
        public string Company { get; set; }

        //[Required(ErrorMessage = "Please enter your bio")]
        [Display(Name = "Bio")]
        [StringLength(1000)]
        public string Biography { get; set; }

        //[Required(ErrorMessage="Please enter your current location")]
        [Display(Name = "Current Location")]
        [StringLength(1000)]
        public string CurrentLocation { get; set; }

        public string[] Roles { get; set; }
        public int? GenderId { get; set; }

        public List<GenderMaster> genderList { get; set; }

        public string GenderName { get; set; }
        //public int countSearch { get; set; }

        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int CourseId { get; set; }

        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        public List<CourseDTO> CourseList { get; set; }

        [Required(ErrorMessage = "Please select training mode")]
        [Display(Name = "Training Mode")]
        public int TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        public string TrainingMode { get; set; }
        public List<TrainingMode> TrainingModeList { get; set; }
        public DateTime ExpiryDate { get; set; }

        public string LinkedIn { get; set; }
        public string Twitter { get; set; }
        public string Facebook { get; set; }
        public string Skype { get; set; }
        public string code { get; set; }
        public string DomainName { get; set; }
        public string Skills { get; set; }
        public string InterestedSkills { get; set; }
        public int MembershipId { get; set; }
        public string ProviderName { get; set; }
        public DateTime MembershipExpiry { get; set; }
        public List<SkillMaster> SelectedSkills { get; set; }
        public List<SkillMaster> SelectedInterestSkills { get; set; }
        public IEnumerable<SelectListItem> SkillList { get; set; }
        public IEnumerable<SelectListItem> SkillInterestList { get; set; }
    }
}
