﻿using DNTShared;
using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.DTO
{
    public class CallbackRequestDTO2
    {
        public int CallbackRequestId { get; set; }

        [Required(ErrorMessage = "Please Enter Your Name")]
        [StringLength(50)]
        public string Name2 { get; set; }
        [Required(ErrorMessage = "Please Enter Your Contact No.")]
        [StringLength(20)]
        public string ContactNo2 { get; set; }
        [Required(ErrorMessage = "Please Enter your prefered Call Time")]
        [StringLength(10)]
        public string CallTime2 { get; set; }
        public DateTime SubmitDate { get; set; }
        public bool IsCalled { get; set; }
        public bool IsActive { get; set; }
        public string IpAddress { get; set; }
        public string DomainName { get; set; }
        public List<CourseDTO> CourseList { get; set; }
         [Required(ErrorMessage = "Please select course")]
        public int CourseId2 { get; set; }
         public int EnquiryType { get; set; }
         public string code { get; set; }

         public string OTPcallText2 { get; set; }
         public bool OTPVerified { get; set; }
         public int QID { get; set; }
    }
}
