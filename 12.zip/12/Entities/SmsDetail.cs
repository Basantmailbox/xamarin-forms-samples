﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace DNTShared.Entities
{
   public class SmsDetail
    {
        [Key]
        public long Id { get; set; }
        public string ContactNo { get; set; }
        public string Message { get; set; }
        public int CourseId { get; set; }
        public int SmsTypeId { get; set; }
        public string Gateway { get; set; }
        public DateTime SentDateTime { get; set; }
        public string SessionId { get; set; }
        public string Subject { get; set; }
        public int? SalesMenId { get; set; }
    }
}
