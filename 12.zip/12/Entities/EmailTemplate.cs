﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class EmailTemplate
    {
        [Key]
        public int EmailTemplateId { get; set; }
        public string EmailTemplateName { get; set; }
       
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public Boolean IsActive { get; set; }
        public string DomainName { get; set; }
    }
}
