﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class Document
    {
        [Key]
        public int DocumentId { get; set; }
        public string DocumentName { get; set; }
        public int CourseId { get; set; }
        public int DocumentTypeId { get; set; }
        public string DocumentUrl { get; set; }

    }
}
