using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
namespace DNTShared.Entities
{

    public class Job
    {
        [Key]
        public int JobId { get; set; }
        [Required(ErrorMessage = "Please enter Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter Skills")]
        public string Skills { get; set; }
        public string Location { get; set; }
        public string CompanyName { get; set; }
        [Required(ErrorMessage = "Please enter Description")]
        public string Description { get; set; }
        [AllowHtml]
        [Required(ErrorMessage = "Please enter Long Description")]
        public string LongDescription { get; set; }
        public string Experience { get; set; }
        public bool IsActive { get; set; }
        public DateTime ExpiryDate { get; set; }

        [NotMapped]
        public string ResumeCount { get; set; }

       
    }
}
