﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace DNTShared.Entities
{
    public class OtpHistory
    {
        [Key]
        public int OtpId { get; set; }
        public int QueryId { get; set; }
        public int Otp { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}
