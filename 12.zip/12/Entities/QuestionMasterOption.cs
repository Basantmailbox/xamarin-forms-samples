using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
    public class QuestionMasterOption
    {
        [Key]
        public int QuestionOptionId { get; set; }
        public int QuestionId { get; set; }
        public string OptionChar { get; set; }
        public string OptionTitle { get; set; }
        public bool IsActive { get; set; }

    }
}
