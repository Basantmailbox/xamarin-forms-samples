﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class CourseDetail
    {
        [Key]
        public int CourseDetailId { get; set; }

        [Required(ErrorMessage = "Please Fill Key Name")]
        public string KeyName { get; set; }
        [AllowHtml]
        [Required(ErrorMessage = "Please Fill Value")]
        public string Value { get; set; }
        [Required(ErrorMessage = "Please select Type")]
        public string Type { get; set; }
        public string Sequence { get; set; }
        public bool IsActive { get; set; }
        
        [ForeignKey("Course")]
        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int CourseId { get; set; }

        public virtual Course Course { get; set; }
        [NotMapped]
        public int CourseType { get; set; }
        [NotMapped]
        [Display(Name = "Course Name")]
        public string CourseName { get; set; }

        [NotMapped]
        public List<CourseDTO> CourseList { get; set; }
        [NotMapped]
        public string hashtagName{ get; set; }
    }
}
