using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
    public class BatchMember
    {

        [Key, Column(Order = 0)]
        public int BatchId { get; set; }
       
        [Key, Column(Order = 1)]
        public int CourseSubscriptionId { get; set; }

       // public virtual CourseSubscription CourseSubscription { get; set; }
        //public virtual BatchMasters BatchMaster { get; set; }
    }
}
