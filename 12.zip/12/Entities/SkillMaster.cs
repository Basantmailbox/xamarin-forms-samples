﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class SkillMaster
    {
        [Key]
        public int SkillId { get; set; }
        [Required(ErrorMessage = "Please Fill Name")]
        public string Name { get; set; }
        public bool? IsActive { get; set; }

    }
}
