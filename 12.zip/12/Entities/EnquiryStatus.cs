﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    /// <summary>
    /// Author : Basant Kumar
    /// Created Date : 4 Sep 2016
    /// </summary>
    public class EnquiryStatus
    {
        [Key]
        public int EnquiryStatusId { get; set; }
        public string EnquiryStatusName { get; set; }
        public string Description { get; set; }
        public bool? IsActive { get; set; }
    }
}
