﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class PaymentRefundInvoice
    {
        public long Id { get; set; }
        public long InvoiceNo { get; set; }  
        public decimal Total { get; set; }
        public decimal PaymentGatewayCharge { get; set; }
        public decimal ServiceCharge { get; set; }
        public decimal ClassAttendedCharge { get; set; }
        public decimal RefundAmount { get; set; }
        public string RefundPaymentMode { get; set; }
        public string TransactionId { get; set; }
        public string Currency { get; set; }
        public string CustomerName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string DetailReason { get; set; }
        public long CreatedBy { get; set; }
        public long UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
