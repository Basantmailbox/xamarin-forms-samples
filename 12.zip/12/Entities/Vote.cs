﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class Vote
    {
        [Key]
        public int ID { get; set; }
        public int  VoteID { get; set; }
        public long MemberId { get; set; }
        public int MID { get; set; }
        public DateTime CreatedDate { get; set; }
        public decimal? Rating { get; set; }

    }
}
