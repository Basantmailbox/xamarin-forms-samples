using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class StateTaxMapping
    {
        [Key]
        public int STid { get; set; }
        public int StateId { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public DateTime To { get; set; }
        public DateTime From { get; set; }
        public bool IsActive { get; set; }
        [NotMapped]
        public string StateCode { get; set; }
    }
}
