﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class CourseFeature
    {
        [Key]
        public int CourseFeatureId { get; set; } 
        public string Name { get; set; }

        [ForeignKey("Course")]
        public Nullable<int> CourseId { get; set; }
        public virtual Course Course { get; set; }

    }
}
