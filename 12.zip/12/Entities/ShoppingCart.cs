using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{

    [Table("ShoppingCart")]
    public  class ShoppingCart
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ShoppingCart()
        {
            CartsItems = new HashSet<CartsItems>();
        }

        [Key]
        public long ShoppingCartDataID { get; set; }

        public int UserID { get; set; }

        public int TotalCount { get; set; }

        public bool Isactive { get; set; }

        public DateTime DateCreated { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<CartsItems> CartsItems { get; set; }
    }
}
