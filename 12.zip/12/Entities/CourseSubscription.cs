﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class CourseSubscription
    {
        [Key]
        public int CourseSubscriptionId { get; set; }

        public Int64 MemberId { get; set; }
        public int ModeId { get; set; }
        public int CourseId { get; set; }

        public DateTime? SubscribeDate { get; set; }
        public DateTime? RenewDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public bool? IsActive { get; set; }
        public bool SubscriptionType { get; set; }
        public int VideoAccess { get; set; }
        public int CourseType { get; set; }
    }
}
