using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DNTShared.Entities
{
   
    public class StepTutorial
    {
        [Key]
        public int TutorialID { get; set; }
        public string ID { get; set; }
        public string Title { get; set; }
        public string Version { get; set; }
        public string ShortDescription { get; set; }
        public string Description { get; set; }
        public string MetaKeywords { get; set; }
        public string DomainName { get; set; }
        public string PostedBy { get; set; }
        public System.DateTime PostedDate { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }

        [ForeignKey("StepCategory")]
        public Nullable<int> CategoryID { get; set; }

        [ForeignKey("StepSubCategory")]
        public Nullable<int> SubCategoryID { get; set; }

        public Int64? TotalViews { get; set; }

        public virtual StepCategory StepCategory { get; set; }
        public virtual StepTutorialSubCategory StepSubCategory { get; set; }
    }
}
