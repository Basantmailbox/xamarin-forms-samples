using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DNTShared.Entities
{
  
    public class StepCategory
    {
        [Key]
        public int CategoryID { get; set; }
        [Required(ErrorMessage = "Please Enter Category Name")]
        public string CategoryName { get; set; }
        public string Logo { get; set; }

        [Required(ErrorMessage = "Please Enter Tutorial Title")]
        [Display(Name = "Tutorial Title")]
        public string TutorialTitle { get; set; }

        [Required(ErrorMessage = "Please Enter Tutorial Url")]
        public string TutorialUrl { get; set; }

         [Required(ErrorMessage = "Please Enter Meta Keywords")]
        public string TutorialMetaKeywords { get; set; }

        [Required(ErrorMessage = "Please Enter Meta Description")]
        public string TutorialMetaDescription { get; set; }


        [Required(ErrorMessage = "Please Enter Question Title")]
        [Display(Name = "Question Title")]
        public string QuestionTitle { get; set; }

        [Required(ErrorMessage = "Please Enter Question Url")]
        public string QuestionUrl { get; set; }
        [Required(ErrorMessage = "Please Enter Question Meta Keywords")]
        public string QuestionMetaKeywords { get; set; }

         [Required(ErrorMessage = "Please Enter Question Meta Description")]
        public string QuestionMetaDescription { get; set; }

         [Required(ErrorMessage = "Please Enter Answer Url")]
        public string AnswerUrl { get; set; }

        public virtual ICollection<StepTutorial> StepTutorials { get; set; }
        public virtual ICollection<StepQuestionsAnswers> StepQuestionsAnswers { get; set; }
    }
}
