﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class InstallmentDetails_V1
    {
        public long Id { get; set; }
        public long ParentId { get; set; }
        public string UID { get; set; }
        public string InstallmentName { get; set; }
        public string PaymentId { get; set; }
        public string InvoiceNo { get; set; }
        public decimal NetPrice { get; set; }

        public decimal? ServiceTaxPercentage { get; set; }

        public decimal? ServiceTax { get; set; }
        public decimal RoundOff { get; set; }

        public decimal Total { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public string URL { get; set; }
        public DateTime? ExpiryDate { get; set; }

        public bool IsPaymentDone { get; set; }
        public int CreatedBy { get; set; }
        public int CreatedFor { get; set; }
        public int UpdatedBy { get; set; }
        public int IsCancelled { get; set; }

    }
}
