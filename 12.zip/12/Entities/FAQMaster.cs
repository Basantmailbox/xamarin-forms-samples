﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class FAQMaster
    {
        [Key]
        public int FAQId { get; set; }
        [Required(ErrorMessage = "Enter FAQ Title")]
        [Display(Name = "FAQ Title")]
        public string FAQTitle { get; set; }
        [AllowHtml]
        public string Answer { get; set; }
        public int? CourseId { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Sequence { get; set; }
        public bool? IsActive { get; set; }
        public int CourseType { get; set; }

        [NotMapped]
        [Display(Name = "Course Name")]
        public string CourseName { get; set; }
        [NotMapped]
        public List<CourseDTO> courseList { get; set; }
        [NotMapped]
        public string CourseTypeName { get; set; }
    }
}
