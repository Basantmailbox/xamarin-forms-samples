﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DNTShared.Entities
{  
    public class BookDownload
    {
        [Key]
        public int ID { get; set; }
        public Int64 MemberId { get; set; }
        public string BookName { get; set; }
        public DateTime DownloadDate { get; set; }

        //[NotMapped]
        //public string Name { get; set; }
        //[NotMapped]
        //public string Email { get; set; }
        //[NotMapped]
        //public string Mobile { get; set; }
    }
}