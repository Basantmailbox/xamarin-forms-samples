﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DNTShared.Entities
{
   
    public class StepTutorialSubCategory
    {
        [Key]
        public int TutorialSubCategoryID { get; set; }
        public string TutorialSubCategoryName { get; set; }

        [ForeignKey("StepCategory")]
        public Nullable<int> CategoryID { get; set; }
        public virtual StepCategory StepCategory { get; set; }
    }
}