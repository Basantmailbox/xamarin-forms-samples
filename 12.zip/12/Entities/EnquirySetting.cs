﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class EnquirySetting
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Please select course")]
        [Display(Name = "Course")]
        public int CourseId { get; set; }
        public int ModeId { get; set; }
        public long Counter { get; set; }

        
        [Display(Name = "Course Name")]
        [NotMapped]
        public string CourseName { get; set; }
        [NotMapped]
        public List<Course> CourseList { get; set; }

        
        [Display(Name = "Training Mode")]
        [NotMapped]
        public int? TrainingModeId { get; set; }

        [Display(Name = "Training Mode")]
        [NotMapped]
        public string TrainingMode { get; set; }
        [NotMapped]
        public List<TrainingMode> TrainingModeList { get; set; }
    }
}
