using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class QuestionDifficultyLevel
    {
        [Key]
        public int DifficultyLevelId { get; set; }
        public string DifficultyLevelName { get; set; }
        public bool IsActive { get; set; }
        //public virtual ICollection<QuestionMaster> QuestionMasters { get; set; }
        //public virtual ICollection<MockUpTestMaster> QuestionPapers { get; set; }
         [NotMapped]
        public virtual QuestionPaperDTO QuestionPaper { get; set; }
    }
}
