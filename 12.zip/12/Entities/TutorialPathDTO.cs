﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public class TutorialPathDTO
    {
        public TutorialPathDTO()
        {
            AuthorList = new List<MentorMaster>();
            AdImages = new List<AdsImageCollection>();
            Books = new List<CourseDTO>();
            TutList = new List<TutorialDTO>();
        }
        public int TutorialID { get; set; }
        public int CategoryID { get; set; }
        public string TutorialImage { get; set; }
        public string Title { get; set; }
        public string SchemaSEO { get; set; }
        public string ShortTitle { get; set; }
        public string MetaKeywords { get; set; }
        public string MetaDescription { get; set; }
        public string ShortDescription { get; set; }
        public string ArticleUrl { get; set; }
        public string Description { get; set; }
        public string strPostedDate { get; set; }
        public string strUpdatedDate { get; set; }
        public long? TotalViews { get; set; }
        public string TViews { get; set; }
        public string SourceCodeUrl { get; set; }
        public string DomainName { get; set; }
        public string Author { get; set; }
        public int ArticleLevel { get; set; }
        public int ArticleType { get; set; }
        public int ReadTime { get; set; }
        public bool? IsActive { get; set; }
        public string SkillTestUrl { get; set; }
        public ICollection<MentorMaster> AuthorList { get; set; }
        public ICollection<AdsImageCollection> AdImages { get; set; }
        public ICollection<CourseDTO> Books { get; set; }
        public ICollection<TutorialDTO> TutList { get; set; }

    }
}
