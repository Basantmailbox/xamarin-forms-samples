﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class TransactionDetails
    {
        public int Id { get; set; }
        public string PaymentId { get; set; }
        public string TransactionId { get; set; }
        public int CourseId { get; set; }
        public int CourseType { get; set; }
        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public decimal DiscountPercentage { get; set; }
        public decimal NetPrice { get; set; }
        public decimal ServiceTax { get; set; }
        public decimal Total { get; set; }

        public string Status { get; set; }
        public string PaymentGateway { get; set; }
        public string Currency { get; set; }

        public string CustomerName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int StateCode { get; set; }
        public string Address { get; set; }

        public long? ShoppingCartDataID { get; set; }
        public string DiscountCoupon { get; set; }
        public virtual ICollection<TransactionChildDetail> TransactionChildDetails { get; set; }
    }
}
