using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class QuestionPaperDuration
    {
        [Key]
        public int QuestionPaperDurationId { get; set; }
        public string DurationValue { get; set; }

        [NotMapped]
        public string DurationValueText { get; set; }
    }
}
