﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class TrainingMode
    {
        public int TrainingModeId { get; set; }
        public string Name { get; set; }

    }
}
