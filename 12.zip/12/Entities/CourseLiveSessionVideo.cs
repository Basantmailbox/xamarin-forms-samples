using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{

    public class CourseLiveSessionVideo
    {
        [Key]

        public int LiveTopicId { get; set; }
        [Required(ErrorMessage = "Please Enter Name")]
        public string TopicName { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        [Required(ErrorMessage = "Please Enter URL")]
        public string UrlPath { get; set; }
        public string CodePath { get; set; }
        public bool IsLock { get; set; }
        [Required(ErrorMessage = "Please Enter Duration")]
        public string Duration { get; set; }
        public int Sequence { get; set; }
        public bool IsActive { get; set; }
        public string PdfPath { get; set; }
        
        [Required(ErrorMessage = "Please Select Batch")]
        public int BatchId { get; set; }
        public int CourseId { get; set; }
        public bool IsMailed { get; set; }

        [NotMapped]
        public string CourseName { get; set; }
      

    }
}
