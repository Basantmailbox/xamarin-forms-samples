﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class TransactionInvoice
    {
        public long Id { get; set; }
        public string TransactionId { get; set; }
        public long InvoiceNo { get; set; }
        public string PaymentId { get; set; }
        public decimal Price { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal Total { get; set; }
        public string Currency { get; set; }
        public string PaymentGateway { get; set; }
        public string Details { get; set; }
        public int InvoiceType { get; set; }
        public int? StateCode { get; set; }
        public string PAN { get; set; }
        public string GSTIN { get; set; }
        public long CreatedBy { get; set; }
        public long UpdatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        [AllowHtml]
        public string CompanyDetail { get; set; }
        public decimal RoundOff { get; set; }
        public Boolean IsInstallment { get; set; }
        
    }
}
