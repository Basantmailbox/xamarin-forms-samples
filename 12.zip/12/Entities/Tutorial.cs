using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DNTShared.Entities
{
    
    public class Tutorial
    {
        [Key]
        public int TutorialID { get; set; }
        public string ID { get; set; }
        public Nullable<int> Priority { get; set; }
        public string ShortTitle { get; set; }
        public string Title { get; set; }        
        public string SchemaSEO { get; set; }
        public string Version { get; set; }
        public string ShortDescription { get; set; }
        public string Description { get; set; }
        public string MetaKeywords { get; set; }
        public string Tags { get; set; }
        public string Authors { get; set; }
        public string SourceCodeUrl { get; set; }
        public string PostedBy { get; set; }
        public System.DateTime PostedDate { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        public string DomainName { get; set; }
        public string TutorialImage { get; set; }

        [ForeignKey("Category")]
        public Nullable<int> CategoryID { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsRecent { get; set; }
        public string Url { get; set; }
        public string ArticleUrl { get; set; }
        public long? TotalViews { get; set; }
        public virtual Category Category { get; set; }

        public int ArticleLevel { get; set; }
        public int ArticleType { get; set; }
        public decimal Sequence { get; set; }
        public bool IsMailed { get; set; }


    }
}
