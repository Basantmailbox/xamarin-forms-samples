using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class Category
    {
        public Category()
        {
            Tutorial = new HashSet<Tutorial>();
        }
        [Key]
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string Url { get; set; }
        public string Title { get; set; }
        public string MetaTitle { get; set; }
        
        public string MetaKeywords { get; set; }
        public string MetaDescription { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; }

        public string Skills { get; set; }
        public string Books { get; set; }
        public string Courses { get; set; }

        public string Beginners { get; set; }
        public string Intermediate { get; set; }
        public string Advanced { get; set; }
        public string Questions { get; set; }
        public string CourseDescription { get; set; }
        public string SkillPath { get; set; }
        public string SkillContents { get; set; }
        public int CategoryType { get; set; }
        public string ImageUrl { get; set; }
        public string DisplayName { get; set; }
        public virtual ICollection<Tutorial> Tutorial { get; set; }
    }
}
