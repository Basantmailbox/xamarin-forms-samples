﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    [Table("DiscountType")]
    public class DiscountType
    {
        [Key]
        public int DiscountTypeId { get; set; }
        public String DiscountTypeName { get; set; }

        public Boolean isActive { get; set; }

        public DateTime DateCreated { get; set; }
    }
}
