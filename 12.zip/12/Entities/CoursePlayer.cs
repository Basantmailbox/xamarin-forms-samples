﻿using System.ComponentModel.DataAnnotations;

namespace DNTShared.Entities
{
    public class CoursePlayer
    {
        [Key]
        public int CoursePlayerId { get; set; }
        public int CourseType { get; set; }
        public int Id { get; set; }
    }
}
