﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DNTShared.Entities
{
    
    public class StepSubCategory
    {
        [Key]
        public int SubCategoryID { get; set; }

        [Required(ErrorMessage = "Please Enter Question SubCategory Name")]
        [Display(Name = "SubCategory Name")]
        public string SubCategoryName { get; set; }

        [Required(ErrorMessage = "Please Enter Meta Keywords")]
        public string MetaKeywords { get; set; }

        [ForeignKey("StepCategory")]
        public Nullable<int> CategoryID { get; set; }

        public virtual StepCategory StepCategory { get; set; }

        
        [NotMapped]
        public string CategoryName { get; set; }


    }
}