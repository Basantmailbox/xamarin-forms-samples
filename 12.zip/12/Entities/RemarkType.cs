﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class RemarkType
    {
        [Key]
        public int RemarkId { get; set; }
        public string RemarkName { get; set; }
        public string RemarksDesc { get; set; }
        public bool IsActive { get; set; }

        //public AdminMaster AdminMasters { get; set; }
    }
}
