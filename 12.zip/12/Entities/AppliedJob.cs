using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
namespace DNTShared.Entities
{

    public class AppliedJob
    {
        [Key]
        public int Id { get; set; }
        public int JobId { get; set; }
        public string JobTitle { get; set; }
        public string RequiredSkills { get; set; }
        public string JobLocation { get; set; }
        public string Experience { get; set; }
        public string CompanyName { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string UserMobile { get; set; }
        public DateTime SubmitedDate { get; set; }
        public bool IsActive { get; set; }
    }
}
