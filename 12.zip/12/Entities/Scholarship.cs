using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
   
    public class Scholarship
    {
        [Key]
        public int SId { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Contact No")]
        [StringLength(20)]
        public string ContactNo { get; set; }

        [Required(ErrorMessage = "Please enter your degree")]
        [Display(Name = "Degree")]
        [StringLength(50)]
        public string Degree { get; set; }

        [Required(ErrorMessage = "Please enter your location")]
        [Display(Name = "Location")]
        [StringLength(150)]
        public string Location { get; set; }

        [Required(ErrorMessage = "Please enter your College Name")]
        [Display(Name = "College Name")]
        [StringLength(150)]
        public string CollegeName { get; set; }

        [Required(ErrorMessage = "Please enter your msg")]
        [StringLength(500)]
        public string ScholarshipMsg { get; set; }
        public DateTime SubmitDate { get; set; }

        public int CourseId { get; set; }

        [NotMapped]
        public string code { get; set; }
        [NotMapped]
        public string CourseName { get; set; }
       
        
    }
}
