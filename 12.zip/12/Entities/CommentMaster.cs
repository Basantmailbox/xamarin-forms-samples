﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class CommentMaster
    {
        public CommentMaster()
        {
            Replies = new HashSet<ReplyOnComment>();
        }

        [Key]
        public Guid CommentId { get; set; }
        public string Contents { get; set; }
        public int ReferralID { get; set; }
        public long UserId { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsVerified { get; set; }
        public bool IsBook { get; set; }

        public virtual ICollection<ReplyOnComment> Replies { get; set; }
    }
}
