﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
   public class LoginHistory
    {
        [Key]
        public Guid LoginHistoryId { get; set; }
        public Int64 LoginUserId { get; set; }
        public int RoleId { get; set; }
        public string IPAddress { get; set; }
        public string MACAddress { get; set; }
        public bool IsMobileDevice { get; set; }
        public string BrowserName { get; set; }
        public DateTime LastLoginAt { get; set; }
    }
}
