﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public  class CoursePrices_v1
    {
        [Key]
        public int CoursePriceId { get; set; }

        public decimal Price { get; set; }

        public int CourseId { get; set; }

        public bool IsPaymentGateway { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

       public int ExpireByMonth { get; set; }

        public int CourseType { get; set; }
        public string Currency { get; set; }
        [NotMapped]
        public string CourseName { get; set; }
        [NotMapped]
        public string CourseTypeText { get; set; }
        [NotMapped]
        public ICollection<CourseDTO> CourseList { get; set; }

    }
}
