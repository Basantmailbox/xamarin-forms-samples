using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
   
    public class CorporateEnquiry
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [Display(Name = "Your Name")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter Company name")]
        [Display(Name = "Company Name")]
        [StringLength(50)]
        public string Company { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "Please enter your mobile number")]
        [Display(Name = "Contact No")]
        [StringLength(20)]
        public string ContactNo { get; set; }

       
        [Required(ErrorMessage = "Please enter your current City")]
        [Display(Name = "Current City")]
        [StringLength(50)]
        public string City { get; set; }

        [Required(ErrorMessage = "Please enter your message")]
        [Display(Name = "Message")]
        [StringLength(500)]
        public string Message { get; set; }
        public DateTime SubmitDate { get; set; }

        [Required(ErrorMessage = "Please enter your Learners")]
        public string Learners { get; set; }
        

        [NotMapped]
        public string code { get; set; }
    }
}
