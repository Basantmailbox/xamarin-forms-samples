﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class MockUpTestAttemptedDetail
    {
        [Key]
        public int MockUpTestAttemptedDetailsId { get; set; }
      
        public int MockUpTestAttemptedStatusId { get; set; }  
       
        public int QuestionId { get; set; }

        public string Answers { get; set; }

    }
}
