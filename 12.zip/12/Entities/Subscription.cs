using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
  
    public class Subscription
    {
        [Key]
        [Required(ErrorMessage = "Please enter your email address")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email address")]
        [StringLength(50)]
        [RegularExpression(@"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Please enter correct email")]
        public string EmailID { get; set; }
        public Nullable<System.DateTime> SubscribeDate { get; set; }
        public string SubscribeUrl { get; set; } 
        public bool IsVerified { get; set; }
        public Nullable<System.DateTime> VerificationDate { get; set; }
        public string EncriptedKey { get; set; }
        public int? MailSentCounter { get; set; }


    }
}
