
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class CourseSubTopic
    {
        [Key]
        public int SubTopicId { get; set; }
        public int TopicId { get; set; }

        [Required(ErrorMessage = "Please Enter Name")]
        public string SubTopicName { get; set; }
        public string Description { get; set; }
        public string PdfPath { get; set; }
       
        public string UrlPath { get; set; }
        public string CodePath { get; set; }
        public bool IsLock { get; set; }

        [Required(ErrorMessage = "Please Enter Duration")]
        public string Duration { get; set; }
        public decimal Sequence { get; set; }
        public bool IsActive { get; set; }
        public string OptionalHeader { get; set; }

        public int TopicType { get; set; }
        public string IDELanguage { get; set; }
        public string Hint { get; set; }
        public string Solution { get; set; }
        public int MentorId { get; set; }

        [NotMapped]
        public string TopicName { get; set; }

        [NotMapped]
        [Required(ErrorMessage = "Please Select Batch")]
        public int BatchId { get; set; }
        [NotMapped]
        public int CourseId { get; set; }
        [NotMapped]
        public string CourseName { get; set; }
    }
}
