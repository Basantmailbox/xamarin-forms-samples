using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
    public class PageViewStatistics
    {
        [Key]
        public int PageId { get; set; }
        public string Name { get; set; }
        public long TotalViews { get; set; }
    }
}
