using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
    public class MockupTestMasterQuestionMapping
    {
        [Key, Column(Order = 0)]
        public int MockupTestId { get; set; }
        [Key, Column(Order = 1)]
        public int QuestionId { get; set; }
        public virtual MockUpTestMaster QuestionPaper { get; set; }
    }

    public class StudyModeQuizQuestionMapping
    {
        [Key, Column(Order = 0)]
        public int SubTopicId { get; set; }
        [Key, Column(Order = 1)]
        public int QuestionId { get; set; }
    }
}
