using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DNTShared.Entities
{
    public class Member
    {
        public Member()
        {
            Roles = new HashSet<Role>();
        }

        [Key]
        public Int64 MemberId { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string ProfilePic { get; set; }

        public string ProfilePicDomain { get; set; }
        
        public string VerificationUrl { get; set; }
        public int? MailSentCounter { get; set; }
        public string EncriptedKey { get; set; }

        public Nullable<bool> IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public Nullable<DateTime> UpdatedDate { get; set; }

        public Nullable<bool> IsVerified { get; set; }
        public Nullable<DateTime> VerificationDate { get; set; }
        
        public string Designation { get; set; }
        public string Company { get; set; }
        public string Biography { get; set; }
        public string CurrentLocation { get; set; }        
        public int? GenderId { get; set; }
        
        public string LinkedIn { get; set; }
        public string Twitter { get; set; }
        public string Facebook { get; set; }
        public string Skype { get; set; }
        public string DomainName { get; set; }
        public string Skills { get; set; }
        public string InterestedSkills { get; set; }

        public string ProviderName { get; set; }
        
        public virtual ICollection<Role> Roles { get; set; }
    }
}