﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public bool? IsActive { get; set; }
        public string Summary { get; set; }
        public string LargeBanner { get; set; }
        public string SmallBanner { get; set; }
        public string MobileBanner { get; set; }
        public string Keyword { get; set; }
        public string Description { get; set; }
        public decimal? Sequence { get; set; }
        public string Mentors { get; set; }
        public string URL { get; set; }
        public string CourseFeatures { get; set; }
        public decimal Reviews { get; set; }
        public string Learners { get; set; }
        public string TagLine { get; set; }
        public string CourseSellingPoints { get; set; }
        public string H1Tag { get; set; }
        public string H2Tag { get; set; }
        public string FooterDetails { get; set; }
        public int IsFree { get; set; }
        public string WhyUsContents { get; set; }
        public string SkillChallengeURL { get; set; }
        public string Duration { get; set; }
        public DateTime? PublishedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual ICollection<CitywiseCourse> CitywiseCourse { get; set; }
        public virtual ICollection<CourseDetail> CourseDetails { get; set; }
        public virtual ICollection<CourseCategories> CourseCategories { get; set; }      
        public virtual ICollection<CourseSalesList_V1> CourseSalesList_V1 { get; set; }
        
        public string DomainName { get; set; }
        public string SkillName { get; set; }
        public string CoursesList { get; set; }
        public string CategoryList { get; set; }
        public int CourseType { get; set; }
        public string DemoUrl { get; set; } 
        public int IsSelfPlacedBatch { get; set; }

        public int VideoTypeId { get; set; }
        public int DifficultyLevelId { get; set; }
        public int DifficultyTypeId { get; set; }
    }
}
