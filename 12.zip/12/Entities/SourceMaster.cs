﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class SourceMaster
    {
        [Key]
        public int SourceId { get; set; }
        [Required(ErrorMessage = "Please enter Source name")]
        [Display(Name = "Source Name")]
        public string SourceName { get; set; }
       
    }
}
