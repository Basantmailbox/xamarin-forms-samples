using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class CourseSubTopicsBatch
    {
        [Key]
        public int SubTopicId { get; set; }
        public int TopicId { get; set; }
        [Required(ErrorMessage = "Please Enter Name")]
        public string SubTopicName { get; set; }
        public string Description { get; set; }
        public string PdfPath { get; set; }
        [Required(ErrorMessage = "Please Enter URL")]
        public string UrlPath { get; set; }
        public string CodePath { get; set; }
        public bool IsLock { get; set; }
        [Required(ErrorMessage = "Please Enter Duration")]
        public string Duration { get; set; }
        public int Sequence { get; set; }
        public bool IsActive { get; set; }

        [NotMapped]
        public string OptionalHeader { get; set; }
        [NotMapped]
        public string TopicName { get; set; }

        [Required(ErrorMessage = "Please Select Batch")]
        public int BatchId { get; set; }
        [NotMapped]
        public int CourseId { get; set; }
        [NotMapped]
        public string CourseName { get; set; }
    }
}
