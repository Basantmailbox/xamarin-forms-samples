﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class Counter
    {
        [Key]
        public int CounterId { get; set; }
        public int Trained { get; set; }
        public int Batches { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
