﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class PPCCourse
    {
        [Key]
        public int Id { get; set; }
        public int CourseId { get; set; }
        public int ModeId { get; set; }
        public int SourceId { get; set; }
        public string URL { get; set; }
        [AllowHtml]
        public string Summary { get; set; }
        [AllowHtml]
        public string FooterDetails { get; set; }
        public string DomainName { get; set; } 
        public string City { get; set; }
        public string Mentors { get; set; }
        public string H1Tag { get; set; }
        public string H2Tag { get; set; }
        public bool IsActive { get; set; }
        
        public string ImageDemo { get; set; }
        [Display(Name = "Upload Image")]
        [NotMapped]
        public HttpPostedFileBase File { get; set; }
    }
}
