﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
   public class Bookmark
    {

        public Bookmark()
        {
            this.BookmarkId = Guid.NewGuid();
        }
        [Key]
        public Guid BookmarkId { get; set; }
       // public Int64 BookmarkId { get; set; }
        public Int64 MemberId { get; set; }
        public int CourseId { get; set; }
        public int ModuleId { get; set; }
        public int CourseType { get; set; }
        public DateTime CreatedOn { get; set; }

        [NotMapped]
        public string CourseName { get; set; }

        [NotMapped]
        public string ModuleName { get; set; }

        [NotMapped]
        public string CreatedDate { get; set; }

        [NotMapped]
        public string URL { get; set; }

        [NotMapped]
        public string Title { get; set; }

        [NotMapped]
        public string Duration { get; set; }

        
    }
}
