﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class EventType
    {
        [Key]
        public int EventTypeId { get; set; }

        [Required(ErrorMessage = "Enter Event Type Name")]
        [Display(Name = "Event Type Name")]
        public string EventTypeName { get; set; }

        [Display(Name = "Event Description")]
        public string EventTypeDescription { get; set; }

        public DateTime? AddDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<Event> Events { get; set; } //one-to-many
    }
}
