﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class VoteMaster
    {
        [Key]
        public int VoteID { get; set; }
        public int TutorialID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int MID { get; set; }
        public bool? IsActive { get; set; }
        public int Medal { get; set; }
        public string Details { get; set; }
        public int IsMailed { get; set; }
    }
}
