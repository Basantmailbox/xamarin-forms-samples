﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
  public class LearningProgress
    {
        public LearningProgress()
        {
            this.LearningProgressId = Guid.NewGuid();
        }
        [Key]

        public Guid LearningProgressId { get; set; }
       // public long LearningProgressId { get; set; }
        public int CourseId { get; set; }
        public int TopicId { get; set; }
        public int TopicType { get; set; }
        public long MemberId { get; set; }
        public DateTime LearntDate { get; set; }
        public bool IsResetByMember { get; set; }
    }
}
