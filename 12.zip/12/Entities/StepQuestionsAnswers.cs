﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace DNTShared.Entities
{
    public class StepQuestionsAnswers
    {
        [Key]
        public Int64 QuestionID { get; set; }
        public string ID { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public string PostedBy { get; set; }
        public System.DateTime PostedDate { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }

        [ForeignKey("StepCategory")]
        public int? CategoryID { get; set; }
        public virtual StepCategory StepCategory { get; set; }

        [ForeignKey("StepSubCategory")]
        public int? SubCategoryID { get; set; }
        public virtual StepSubCategory StepSubCategory { get; set; }

        public Int64? TotalViews { get; set; }
    }
}