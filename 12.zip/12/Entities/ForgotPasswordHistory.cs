﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class ForgotPasswordHistory
    {
        [Key]
        public int Id { get; set; }
        public string EmailId { get; set; }
        public string EncryptedKey { get; set; }
        public string Url { get; set; }
        public DateTime RequestedDate { get; set; }
        public DateTime? VerificationDate { get; set; }
        public bool IsVerified { get; set; }

        [NotMapped]
        public int CourseId { get; set; }
        [NotMapped]
        public int BatchId { get; set; }
    }
}
