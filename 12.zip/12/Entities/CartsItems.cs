using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;


namespace DNTShared.Entities
{
    public partial class CartsItems
    {
        [Key]
        public int CartsItemId { get; set; }

        public int CourseId { get; set; }
        public  int CourseType { get; set; }

        public int Quantity { get; set; }

        public long ShoppingCartDataID { get; set; }

        public DateTime? DateCreated { get; set; }

        public DateTime? DateUpdate { get; set; }
        //[JsonIgnore]
        public virtual ShoppingCart ShoppingCart { get; set; }
    }
}
