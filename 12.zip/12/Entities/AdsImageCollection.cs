﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web;

namespace DNTShared.Entities
{
    public class AdsImageCollection
    {
        [Key]
        public int ImageId { get; set; }
        [Required(ErrorMessage = "Please enter the Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter the Description")]
        public string ImageURL { get; set; }
         [Required(ErrorMessage = "Please enter the Description")]
        public string AdsURL { get; set; }
        public int AdsId { get; set; }
        public bool? IsActive { get; set; }
        
        [NotMapped]
        public HttpPostedFileBase image { get; set; }

         [NotMapped]
        public List<AdsMastersDTO> AdsList { get; set; }
    }
}
