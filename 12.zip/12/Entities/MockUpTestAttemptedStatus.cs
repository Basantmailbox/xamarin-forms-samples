﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class MockUpTestAttemptedStatus
    {
        [Key]
        public int MockUpTestAttemptedStatusId { get; set; }
        public int MockupTestMasterId { get; set; }
        public int BatchId { get; set; }
        public int CourseSubscriptionId { get; set; }
        public int TimeTaken { get; set; }
        public int Score { get; set; }
        public decimal Percentage { get; set; }
        public DateTime TestTakenDate { get; set; }
        public int CorrectQuestions { get; set; }
        public int WrongQuestions { get; set; }
        public int LeftQuestions { get; set; }
        public bool? AttemptedStatus { get; set; }
        
        
    }
}
