﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class Event
    {
        [Key]
        public int EventID { get; set; }
        public string ID { get; set; }
        public string EventTitle { get; set; }
        public string ShortDescription { get; set; }
        public string EventAddress { get; set; }
        //[ForeignKey("EventType")] // this is defined in the DataContext using Fluent-API
        public int EventTypeId { get; set; }       
        public string EventDescription { get; set; }
        public string EventSpeakers { get; set; }
        public string MetaKeywords { get; set; }
        public string PostedBy { get; set; }
        public string EventDisplayDateTime { get; set; }
        public DateTime EventDate { get; set; }     
        public DateTime PostedDate { get; set; }     
        public DateTime? UpdatedDate { get; set; }     
        public string Url { get; set; }
        public string EventJoiningLink { get; set; }        
        public string MetaDescription { get; set; }
        public Int64? TotalViews { get; set; }
        public string EventImage { get; set; }
        public bool? IsActive { get; set; }
        public bool IsRegistrationClosed { get; set; }
        public virtual EventType EventType { get; set; } //only for mapping
        public string DomainName { get; set; }
        public virtual ICollection<EventRegistration> EventRegistrations { get; set; } //one-to-many

    }
}
