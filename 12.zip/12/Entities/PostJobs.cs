using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
namespace DNTShared.Entities
{

    public class PostJobs
    {
        [Key]
        public int JobId { get; set; }
        public string JobTitle { get; set; }
        public string Vacancies { get; set; }
        public string Description { get; set; }
        public string DesiredCandidateProfile { get; set; }
        public string WorkExp { get; set; }
        public string Currency { get; set; }
        public string Min_salary { get; set; }
        public string Max_salary { get; set; }
        public string Location { get; set; }
        public string Company_name { get; set; }
        public string C_Person_name { get; set; }
        public string C_Person_mobile { get; set; }
        public string C_Person_email { get; set; }
        public string Company_url { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsActive { get; set; }

    }
}
