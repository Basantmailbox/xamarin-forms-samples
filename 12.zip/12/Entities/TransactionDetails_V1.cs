﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public  class TransactionDetails_V1
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public TransactionDetails_V1()
        {
            TransactionChildDetails_V1 = new HashSet<TransactionChildDetails_V1>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [StringLength(20)]
        public string PaymentId { get; set; }

        [StringLength(20)]
        public string TransactionId { get; set; }

        public Boolean? IsInstallment { get; set; }
        
        public decimal? Price { get; set; }

        public decimal? SaleOffAmount { get; set; }

        public decimal? AfterSaleAmount { get; set; }

        public bool Discount_Applied { get; set; }

        public int? DiscountId { get; set; }

        public decimal TotalDiscountPercentage { get; set; }

        public decimal TotalDiscountPercentageAmount { get; set; }

        public decimal NetPrice { get; set; }
        public decimal IGST { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }

        public decimal IGSTPercent { get; set; }
        public decimal CGSTPercent { get; set; }
        public decimal SGSTPercent { get; set; }
        public decimal? ServiceTaxPercentage { get; set; }

        public decimal RoundOff { get; set; }
        

        public decimal? ServiceTax { get; set; }

        public decimal Total { get; set; }

        [StringLength(50)]
        public string Status { get; set; }

        [StringLength(50)]
        public string TransactionStatus { get; set; }

        [StringLength(50)]
        public string PaymentGateway { get; set; }

        [StringLength(50)]
        public string Currency { get; set; }

        [StringLength(50)]
        public string CustomerName { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(50)]
        public string ContactNo { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }
      
        public int? StateCode { get; set; }

        [StringLength(500)]
        public string Address { get; set; }

        public long? ShoppingCartDataID { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<TransactionChildDetails_V1> TransactionChildDetails_V1 { get; set; }
        [NotMapped]
        public int CreatedFor { get; set; }
        public int IsCancelled { get; set; }

        [NotMapped]
        public long InvoiceNo { get; set; }
        [NotMapped]
        public virtual ICollection<string> Courses { get; set; }

        public string URLSource { get; set; }
        public string ReferralCode { get; set; }
    }
}
