﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class CourseCategories
    {
        public CourseCategories()
        {
            Courses = new HashSet<Course>();
        }
        [Key]
        public int CourseCategoryId { get; set; }
        public string CourseCategoryName { get; set; }
        public int CurType { get; set; }
        public string Description { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsActive { get; set; }

        public virtual ICollection<Course> Courses { get; set; }
    }
}
