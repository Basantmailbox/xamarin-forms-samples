using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DNTShared.DTO;
namespace DNTShared.Entities
{

    public class CourseTopic
    {
        public CourseTopic()
        {
            Subtopics = new HashSet<CourseSubTopic>();
        }
        [Key]
        public int TopicId { get; set; }
        [Required(ErrorMessage = "Please Enter Course Name")]
        public int CourseId { get; set; }
        [Required(ErrorMessage = "Please Enter Name")]
        public string TopicName { get; set; }
        public bool IsActive { get; set; }
        public decimal Sequence { get; set; }

        [Required(ErrorMessage = "Please Select Topic Type")]
        [Display(Name = "Topic Type")]
        public int TopicTypeId { get; set; }

        [Display(Name = "Quiz")]
        public int QuizId { get; set; }

        [NotMapped]
        public TimeSpan TotalTime { get; set; }
        [NotMapped]
        public TimeSpan AllTimeDuration { get; set; }

        [NotMapped]
        public string CourseName { get; set; }

        [NotMapped]
        public string TopicTypeName { get; set; }


        public virtual ICollection<CourseSubTopic> Subtopics { get; set; }
        public virtual ICollection<CourseSubTopicsBatch> SubtopicsBatch { get; set; }

        [NotMapped]
        public List<DropDownDTO> QuizDDL { get; set; }
    }
}
