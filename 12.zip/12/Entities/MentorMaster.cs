﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class MentorMaster
    {
        
        [Key]
        public int MentorId { get; set; }
        [Required(ErrorMessage = "Please Enter Biography")]
        [Display(Name = "Mentor Biography")]
        public string Biography { get; set; }
        [Required(ErrorMessage = "Please Enter Name")]
        [Display(Name = "Mentor Name")]
        public string Name { get; set; }
         [Required(ErrorMessage = "Please Enter Mentor Designation")]
        public string Designation { get; set; }
       // [Required(ErrorMessage = "Please Enter Mentor Skills")]
        public string Skills { get; set; }
        public string ImageUrl { get; set; }
        public bool? IsActive { get; set; }
        public int? GenderId { get; set; }       
        public string URL { get; set; }

        [Required(ErrorMessage = "Please Enter Mentor EmailID")]
        public string EmailID { get; set; }

        public string ShortDescription { get; set; }
        

         //[Required(ErrorMessage = "Please Upload Image")]
         [Display(Name = "Upload Image")]
        [NotMapped]
        public HttpPostedFileBase File { get; set; }
        [NotMapped]
        public List<GenderMaster> GenderList { get; set; }
        [NotMapped]
      public  List<SkillMaster> SkillsList { get; set; }
        [NotMapped]
        public List<SkillMaster> SelectedSkills { get; set; }
        [NotMapped]
        public IEnumerable<SelectListItem> SkillList { get; set; }
    }
}
