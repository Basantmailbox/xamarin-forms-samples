﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class LatestNews
    {
        [Key]
        public int NewsID { get; set; }
        [Required(ErrorMessage = "Enter News Text")]
        [Display(Name = "News Title")]
        public string NewsText { get; set; }
        public DateTime CreatedDate { get; set; }
        [Required(ErrorMessage = "Enter Expiry Date")]
        [Display(Name = "Expiry Date")]
        public DateTime ExpiryDate { get; set; }
        [Required(ErrorMessage = "Enter redirection Url")]
        [Display(Name = "Url")]
        public string Url { get; set; }
        [Display(Name = "Active Status")]
        public bool IsActive { get; set; }
        public bool IsNotify { get; set; }
        public string PostedBy { get; set; }

        public int SaleId { get; set; }

        [NotMapped]
        public string NewsFullDetail { get; set; }
        [NotMapped]
        public string ShowExpiryDate { get; set; }       
    }
}
