﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class ForumMaster
    {
        public ForumMaster()
        {
            Replies = new HashSet<ReplyOnForum>();
        }

        [Key]
        public Guid FId { get; set; }
        public string Title { get; set; }
        [AllowHtml]
        public string Contents { get; set; }
        public int CourseId { get; set; }
        public long UserId { get; set; }
        public DateTime CreatedDate { get; set; }
        public bool IsVerified { get; set; }
        public string ImageURL { get; set; }


        [NotMapped]
        public HttpPostedFileBase image { get; set; }
        [NotMapped]
        public string Name { get; set; }
        [NotMapped]
        public string Email { get; set; }
        [NotMapped]
        public string MobileNo { get; set; }
        [NotMapped]
        public string elapsedtime { get; set; }
        public virtual ICollection<ReplyOnForum> Replies { get; set; }
    }
}
