﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    [Table("CourseSubscriptionHistory")]
    public class CourseSubscriptionHistory
    {
        [Key]
        public int Id { get; set; }
        public int CourseSubscriptionId { get; set; }
        public Int64 MemberId { get; set; }
        public int ModeId { get; set; }
        public int CourseId { get; set; }
        public DateTime SubscribeDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public bool SubscriptionType { get; set; }
        public int CourseType { get; set; }
    }
}
