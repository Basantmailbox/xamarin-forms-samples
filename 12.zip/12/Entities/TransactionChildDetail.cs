﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
   public class TransactionChildDetail
    {
        public long Id { get; set; }

        public int ParentId { get; set; }

        [StringLength(20)]
        public string PaymentId { get; set; }

        [StringLength(20)]
        public string TransactionId { get; set; }

        public int CourseId { get; set; }

        public decimal Price { get; set; }

        public decimal? Discount { get; set; }

        public decimal NetPrice { get; set; }

        public decimal ServiceTax { get; set; }

        public decimal Total { get; set; }

        [StringLength(50)]
        public string Status { get; set; }

        [StringLength(50)]
        public string PaymentGateway { get; set; }

        [StringLength(50)]
        public string Currency { get; set; }

        [StringLength(50)]
        public string CustomerName { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(50)]
        public string ContactNo { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public decimal DiscountPercentage { get; set; }

        public int CourseType { get; set; }

        public int? StateCode { get; set; }

        [StringLength(500)]
        public string Address { get; set; }
        public string DiscountCoupon { get; set; }
        public virtual TransactionDetails TransactionDetail { get; set; }

    }
}
