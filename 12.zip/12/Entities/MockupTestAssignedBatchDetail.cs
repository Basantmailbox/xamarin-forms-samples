﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class MockupTestAssignedBatchDetail
    {
        [Key]
        public int MockupTestAssignedBatchDetailId { get; set; }
        public int BatchId { get; set; }
        public int AssessmentId { get; set; }
        public int CourseSubscriptionId { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public DateTime AssignmentFromDate { get; set; }
        public DateTime AssignmentToDate { get; set; }
        public bool IsActive { get; set; }
    }
}
