using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace DNTShared.Entities
{

    public class BatchMasters
    {
        public BatchMasters()
        {
            //  CourseSubscription = new HashSet<CourseSubscription>();
            //BatchMembers = new HashSet<BatchMember>();
        }
        [Key]
        public int BatchId { get; set; }
        public string BatchName { get; set; }
        public int CourseId { get; set; }
        public int TotalMockUpTest { get; set; }
        public int AssignedMockupTest { get; set; }
        public int ModeId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsActive { get; set; }
        public string BatchCode { get; set; }
        public int MentorId { get; set; }
           

        public string Url { get; set; }
        [AllowHtml]
        public string ImportantInfo { get; set; }
        public string PostedBy { get; set; }
        public string MeetingUrl { get; set; }
        public string MeetingPassword { get; set; } 
        public string Title { get; set; }
        public string BatchDays { get; set; }
      
        public TimeSpan BatchHours { get; set; }
        public DateTime BatchTiming { get; set; }
        public int Classes { get; set; }

    }
}
