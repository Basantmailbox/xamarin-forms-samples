﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class CertificateMaster
    {
        [Key]
        public long Id { get; set; }
        public string CertificateId { get; set; }
        public long MemberId { get; set; }
        public string Name { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }        
        public DateTime IssueDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Grade { get; set; }        
        public bool? IsActive { get; set; }

        public int CertificateType { get; set; }
        public int Medal { get; set; }

        [NotMapped]
        public string disIssueDate { get; set; }
        [NotMapped]
        public string email { get; set; }
        [NotMapped]
        public string authorsId { get; set; }

    }
}
