﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class SmsType
    {
        [Key]
        public int SmsTypeId { get; set; }
        [Required(ErrorMessage = "Enter Sms Type")]
        [Display(Name = "Sms Type")]
        public string SmsTypeName { get; set; }
        public bool IsActive { get; set; }
    }
}
