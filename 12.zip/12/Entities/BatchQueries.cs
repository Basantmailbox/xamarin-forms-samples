using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class BatchQueries
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public string EmailID { get; set; }
        public string ContactNo { get; set; }
        public string Message { get; set; }
        public Nullable<System.DateTime> SubmitDate { get; set; }
        public string City { get; set; }
        public int TrainingModeId { get; set; }
        public int CourseId { get; set; }
    }
}
