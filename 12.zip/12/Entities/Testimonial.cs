﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class Testimonial
    {
        
        [Key]
        public int TestimonialId { get; set; }
        public string Contents { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
        public string LinkUrl { get; set; }
        public int LinkType { get; set; }
        public string ImageUrl { get; set; }
        
        [ForeignKey("Courses")]
        public int  CourseId { get; set; }
        public bool? IsActive { get; set; }
        public int? GenderId { get; set; }
        public int UpdatedBy { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? CreatedDate{ get; set; }
        public DateTime? UpdatedDate { get; set; }

        public decimal Reviews { get; set; }
        public virtual Course Courses { get; set; }
    }
}
