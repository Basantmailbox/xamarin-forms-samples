﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class MockUpQuizAttemptedDetail
    {
        [Key]
        public int MockUpQuizAttemptedId { get; set; }

        public int MockUpQuizAttemptedStatusId { get; set; }

        public int QuestionId { get; set; }

        public string Answers { get; set; }

    }
}
