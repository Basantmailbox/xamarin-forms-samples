﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class MockUpTestMaster
    {
        [Key]
        public int MockupTestId { get; set; }
        public int CategoryID { get; set; }
        public string MockupTestName { get; set; }
        public int TotalQuestions { get; set; }

        public int DifficultyType { get; set; }
        public int Duration { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public bool IsActive { get; set; }
        public int TestType { get; set; }
        public string URL { get; set; }
        public string Description { get; set; }
        public string Keyword { get; set; }

        public int CourseId { get; set; }
        
        [AllowHtml]
        public string Details { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<MockupTestMasterQuestionMapping> QuestionPaperDetails { get; set; }
    }
}
