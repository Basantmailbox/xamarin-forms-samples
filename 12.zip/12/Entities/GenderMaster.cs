using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DNTShared.Entities
{
    public class GenderMaster
    {
        [Key]
        public int GenderId{ get; set; }
        public string GenderName { get; set; }
       
        
    }
}
