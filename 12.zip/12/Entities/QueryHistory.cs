﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    /// <summary>
    /// Author : Basant Kumar
    /// Created Date : 11 Sep 2016
    /// </summary>
    public class QueryHistory
    {
        [Key]
        public int FollowupHistoryId { get; set; }
        public int QueryId { get; set; }
        public int FollowUpUserId { get; set; }
        public int AssignedCounter { get; set; }
        public DateTime AssignedDate { get; set; }
        public DateTime? GrabbedDate { get; set; }
        public int AssignedBy { get; set; }
        public int GrabbedBy { get; set; }

    }
}
