﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
   public class PaymentChildDetail
    {
        public long Id { get; set; }

        public long ParentId { get; set; }

        [StringLength(20)]
        public string PaymentId { get; set; }

        [StringLength(20)]
        public string TransactionId { get; set; }

        public int CourseId { get; set; }

        public decimal Total { get; set; }

        [StringLength(50)]
        public string Status { get; set; }

        [StringLength(50)]
        public string PaymentGateway { get; set; }

        [StringLength(50)]
        public string Currency { get; set; }

        [StringLength(50)]
        public string CustomerName { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(50)]
        public string ContactNo { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public decimal DiscountPercentage { get; set; }

        public int CourseType { get; set; }

        public long CreatedBy { get; set; }

        public int? StateCode { get; set; }

        [StringLength(500)]
        public string Address { get; set; }
        public string DiscountCoupon { get; set; }

        public virtual PaymentDetails PaymentDetail { get; set; }
        [NotMapped]
        public string CourseName{ get; set; }
        [NotMapped]
        public bool IsInvoice { get; set; }
    }
}
