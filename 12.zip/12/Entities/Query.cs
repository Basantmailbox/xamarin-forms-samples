using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{
   
    public class Query
    {
        public Query()
        {
            EnquiryTypeId = 1;
        }

        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public string EmailID { get; set; }
        public string ContactNo { get; set; }
        
        public string Message { get; set; }
        public Nullable<System.DateTime> SubmitDate { get; set; }
        public string City { get; set; }
        public int TrainingModeId { get; set; }
        public int CourseId { get; set; }

        public int EnquiryProviderId { get; set; }
        public int EnquiryTypeId { get; set; }
        public int EnquiryStatusId { get; set; }
        public int FollowUpUserId { get; set; }
        public DateTime? AssignedDate { get; set; }
        public DateTime? FollowUpDate { get; set; }
        public DateTime? NextFollowUpDate { get; set; }
        public int FollowUpCounter { get; set; }
        public int AssignedCounter { get; set; }
       
        public bool IsActive { get; set; }
        public int? BatchId { get; set; }
        public string DomainName { get; set; }
        public int CloseFlag { get; set; }
        public string CloseRemark { get; set; }
        public int CreatedBy { get; set; }
        public bool OTPVerified { get; set; }
    }
}
