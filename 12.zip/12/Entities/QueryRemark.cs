﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class QueryRemark
    {
        [Key]
        public int QueryRemarkId { get; set; }
        public int QueryId { get; set; }
        public int UserId { get; set; }
        public DateTime FollowUpDate { get; set; }
        public DateTime? NextFollowUpDate { get; set; }
        public string Remarks { get; set; }
        public Query Queries { get; set; }
        public int RemarkType { get; set; }
        public int? BatchId { get; set; }
        public int EnquiryTypes { get; set; }
    }
}
