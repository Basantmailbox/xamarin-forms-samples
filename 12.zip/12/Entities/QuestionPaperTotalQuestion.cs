using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class QuestionPaperTotalQuestion
    {
        [Key]
        public int QuestionPaperTotalQuestionId { get; set; }
        public int Value { get; set; }
    
    }
}
