﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class MaterCourseCurriculum
    {
        [Key]
        public int CId { get; set; }
        public string Title { get; set; }
        public int CourseId { get; set; }
        public int SubCourseId { get; set; }

        [AllowHtml]
        public string Description { get; set; }
        public int Sequence { get; set; }
        public string Url { get; set; }
        public bool? IsActive { get; set; }
        public int Mode { get; set; }
        public int IsElective { get; set; }

        [NotMapped]
        public string CourseName { get; set; }
        [NotMapped]
        public string ModeName { get; set; }

        [NotMapped]
        public string imgurl { get; set; }

    }
}
