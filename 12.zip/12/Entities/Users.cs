using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DNTShared.Entities
{
    public class Users
    {
        [Key]
        [Required(ErrorMessage = "Please enter your username")]
        [Display(Name = "User Name")]
        [StringLength(50)]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please enter your password")]
        [Display(Name = "Password")]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please enter name")]
        [Display(Name = "Name")]
        [StringLength(50)]
        public string Name { get; set; }
        public Nullable<bool> IsAdmin { get; set; }
        public Nullable<bool> IsActive { get; set; }


        [NotMapped]
        [Required(ErrorMessage = "Please enter new username")]
        [Display(Name = "New User Name")]
        [StringLength(50)]
        public string NewUserName { get; set; }

    }
}
