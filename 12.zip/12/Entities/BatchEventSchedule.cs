﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class BatchEventSchedule
    {
        [Key]
        public int Id { get; set; }
        public int BatchId { get; set; }
        public string EventName { get; set; }
        public string StartDate { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime? EndDate { get; set; }
        public string TagColor { get; set; }

        [NotMapped]
        public string BatchName { get; set; }
          [NotMapped]
        public string OldEventName { get; set; }
    }
}
