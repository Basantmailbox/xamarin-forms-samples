﻿using DNTShared.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNTShared.Entities
{
    public class AdsPopUpMaster
    {
        [Key]
        public Guid AId { get; set; }
        public string Title { get; set; }
        [AllowHtml]
        public string Contents { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Categories { get; set; }
        public bool IsActive { get; set; }
        [NotMapped]
        public IEnumerable<SelectListItem> categoryList { get; set; }
        [NotMapped]
        public int CategoryID { get; set; }
        [NotMapped]
        public List<TutorialDTO> catList { get; set; }
    }
}
