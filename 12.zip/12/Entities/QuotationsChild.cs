using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class QuotationsChild
    {
        public QuotationsChild()
        {

        }
        [Key]
        public long Id { get; set; }
        public long ParentId { get; set; }
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public decimal Price { get; set; }
        public int NoDays { get; set; }
        public int HrsPerDay { get; set; }
        [NotMapped]
        public ICollection<QuotationsChild> qchildlist { get; set; }
    }
}
