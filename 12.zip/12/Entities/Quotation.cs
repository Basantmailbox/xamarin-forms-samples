using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace DNTShared.Entities
{

    public class Quotation
    {
        public Quotation()
        {

        }
        [Key]
        public long Id { get; set; }

        [Required(ErrorMessage = "Enter QuotationNo")]
        public string QuotationNo { get; set; }

        [Required(ErrorMessage = "Enter CustomerName")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Enter Email")]
        public string Email { get; set; }
        public string ContactNo { get; set; }
        [Required(ErrorMessage = "Enter State")]
        public int StateId { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        [AllowHtml]
        public string Address { get; set; }
        [Required(ErrorMessage = "Enter Currency")]
        public string Currency { get; set; }

        [NotMapped]
        public string CreatedUpdated { get; set; }
    }
}
