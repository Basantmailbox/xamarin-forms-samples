﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public class CourseSalesList_V1
    {
        public int ID { get; set; }

        public int CourseId { get; set; }

        public int SaleId { get; set; }

        public decimal SalePercentage { get; set; }

        public decimal SaleOffAmount { get; set; }

        public decimal AfterSale { get; set; }
        public string Currency { get; set; }
        public virtual Course Courses { get; set; }
        public int CourseType { get; set; }
        [NotMapped]
        public string coursename { get; set; }
        public virtual CourseSales_V1 CourseSales_V1 { get; set; }
    }
}
