using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DNTShared.Entities
{

    public class QuestionMaster
    {
        [Key]
        public int QuestionId { get; set; }
        public string QuestionTitle { get; set; }
        public string QuestionCode { get; set; }
        public string CorrectOption { get; set; }
        public int CategoryID { get; set; }
        public int DifficultyType { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? Marks { get; set; }
        public bool IsActive { get; set; }
    }
}
