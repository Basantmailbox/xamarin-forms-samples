﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
namespace DNTShared.Entities
{
    public class DocumentType
    {
        [Key]
        public int DocumentTypeId { get; set; }
        [Required(ErrorMessage = "Please Fill Document Type Name")]
        [Display(Name = "Document Type")]
        public string DocumentTypeName { get; set; }

    }
}
