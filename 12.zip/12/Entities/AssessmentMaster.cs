﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class AssessmentMaster
    {
        [Key]
        public int AssessmentId { get; set; }
        public int CourseId { get; set; }
        public string MockupTestTitle { get; set; }
        public int MockupTestId { get; set; }
        public int? AssignmentId { get; set; }
        public int InstructionId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public bool IsActive { get; set; }

        //public virtual Course Course { get; set; }
       // public virtual QuestionDifficultyLevel QuestionDifficultyLevel { get; set; }
      //  public virtual ICollection<MockUpTestMaster> MockUpTestMaster { get; set; }

    }
}
