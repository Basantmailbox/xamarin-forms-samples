﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public class TransactionChildDetails_V1
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public long ParentId { get; set; }

        [StringLength(20)]
        public string PaymentId { get; set; }

        [StringLength(20)]
        public string TransactionId { get; set; }

        public int? CourseId { get; set; }

        [StringLength(50)]
        public string Name { get; set; }

        [StringLength(50)]
        public string Title { get; set; }

        public decimal? Price { get; set; }

        public bool IsOnSale { get; set; }

        public decimal? SalePercentage { get; set; }

        public decimal? SaleOffAmount { get; set; }

        public decimal? AfterSale { get; set; }

        public bool Discount_Applied { get; set; }

        public decimal? TotalDiscountPercentage { get; set; }

        public decimal? TotalDiscountPercentageAmount { get; set; }

        public decimal? NetPrice { get; set; }

        public int? DiscountId { get; set; }

        [StringLength(50)]
        public string CouponCode { get; set; }
        public string Currency { get; set; }
        public int CourseType { get; set; }
        public virtual TransactionDetails_V1 TransactionDetails_V1 { get; set; }

        [NotMapped]
        public string CourseName { get; set; }
    }
}
