﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DNTShared.DTO;
namespace DNTShared.Entities
{
    public class CoursePrice
    {
        public CoursePrice()
        {
           
        }
        public int CoursePriceId { get; set; }

        //saved in db
        public decimal PriceINR { get; set; } 
        public decimal DiscountPercentage { get; set; }
        public decimal PriceUSD { get; set; }

        //for calculation only
        public decimal DiscountINR { get; set; } 
        public decimal NetPriceINR { get; set; }
        public decimal ServiceTaxINR { get; set; } 
        public string STaxNameINR { get; set; } 
        public decimal TotalINR { get; set; } 
        public decimal DiscountUSD { get; set; } 
        public decimal NetPriceUSD { get; set; } 
        public decimal TotalUSD { get; set; } 
        public int CourseType { get; set; }

        [ForeignKey("Course")]
        public int CourseId { get; set; }
        public bool IsPaymentGateway { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual Course Course { get; set; }

        [NotMapped]
        public bool? CourseIsActive { get; set; }
        [NotMapped]
        public ICollection<CourseDTO> CourseList { get; set; }
        [NotMapped]
        public string CourseName { get; set; }
        [NotMapped]
        public string SalesText { get; set; }
        [NotMapped]
        public string CourseTypeText { get; set; }
        [NotMapped]
        public int Sequence { get; set; }

        [NotMapped]
        public int IsMaster { get; set; }
    }
}
