﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class CallbackRequest
    {
        [Key]
        public int CallbackRequestId { get; set; }
        public string Name { get; set; }
        public string ContactNo { get; set; }
        public string CallTime { get; set; }
        public DateTime SubmitDate { get; set; }
        public bool IsCalled { get; set; }
        public bool IsActive { get; set; }
        public string DomainName { get; set; }
        public string IpAddress { get; set; }
    }
}
