﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public  class CourseSales_V1
    {
        public CourseSales_V1()
        {
            CourseSalesList_V1 = new HashSet<CourseSalesList_V1>();
        }

        [Key]
        public int SaleId { get; set; }
        public string Title { get; set; }

        public DateTime? CreatedDate { get; set; }

        public DateTime? ExpiryDate { get; set; }      

        public decimal DiscountPercentage { get; set; }

        public virtual ICollection<CourseSalesList_V1> CourseSalesList_V1 { get; set; }
    }
}
