﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
    public class CitywiseCourse
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("Course")]
        public int CourseId { get; set; }
        public string Title { get; set; }
        public string URL { get; set; }
        public string Summary { get; set; }
        public string FooterDetails { get; set; }
        public string Keyword { get; set; }
        public string Description { get; set; }
        public string City { get; set; }
        public string H1Tag { get; set; }
        public string H2Tag { get; set; }
        public bool? IsActive { get; set; }
        public string DomainName { get; set; }

        public virtual Course Course { get; set; }
    }
}
