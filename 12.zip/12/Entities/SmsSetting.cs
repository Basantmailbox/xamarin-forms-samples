﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DNTShared.Entities
{
   public class SmsSetting
    {
        [Key]
        public int CallerId { get; set; }
        public int CourseId { get; set; }
        public int SalesMenId { get; set; }
       
        public DateTime DateTime { get; set; }
        public int ModeId { get; set; }
        public bool IsActive { get; set; }
        public int Rid { get; set; }
    }
}
