using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
namespace DNTShared.Entities
{
    public class AssessmentInstruction
    {
        [Key]
        public int InstructionId { get; set; }
        [Display(Name = "Question Paper Instructions")]
        [Required(ErrorMessage = "Please enter Test Instructions")]
        public string InstructionText { get; set; }
        [AllowHtml]
        public string Description { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool IsActive { get; set; }
    }
}
