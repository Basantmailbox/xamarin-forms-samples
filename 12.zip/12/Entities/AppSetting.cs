﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNTShared.Entities
{
    public class AppSetting
    {
        public int AppSettingId { get; set; }
        [Required]
        public string AppValue { get; set; }
        [Required]
        public string AppKey { get; set; }
        [Required]
        public string Description { get; set; }

    }
}
