﻿using DNTShared.DTO;
using System.Collections.Generic;
using System.Web.Mvc;

namespace DNTShared
{
    public static class AppDropDowns
    {
        public static List<DropDownDTO> GetDuration()
        {
            return new List<DropDownDTO>
            {
                new DropDownDTO{ Value=10, Text="10" },
                new DropDownDTO{ Value=20, Text="20" },
                new DropDownDTO{ Value=25, Text="25" },
                new DropDownDTO{ Value=30, Text="30" },
                new DropDownDTO{ Value=35, Text="35" },
                new DropDownDTO{ Value=40, Text="40" },
                new DropDownDTO{ Value=45, Text="45" },
                new DropDownDTO{ Value=50, Text="50" },
                new DropDownDTO{ Value=55, Text="55" },
                new DropDownDTO{ Value=60, Text="60" },
                new DropDownDTO{ Value=65, Text="65" },
                new DropDownDTO{ Value=70, Text="70" },
                new DropDownDTO{ Value=75, Text="75" },
                new DropDownDTO{ Value=80, Text="80" },
                new DropDownDTO{ Value=85, Text="85" },
                new DropDownDTO{ Value=90, Text="90" },
                new DropDownDTO{ Value=95, Text="95" },
                new DropDownDTO{ Value=100, Text="100" }
            };
        }

        public static List<SelectListItem> GetPaymentSource()
        {
            return new List<SelectListItem>
            {
                new SelectListItem{ Value="fa", Text="Facebook Ad" },
                new SelectListItem{ Value="ga", Text="Google Ad" },
                new SelectListItem{ Value="la", Text="LinkedIn Ad" },
                new SelectListItem{ Value="qa", Text="Quora Ad" },
                new SelectListItem{ Value="ta", Text="Twitter Ad" },
                new SelectListItem{ Value="fs", Text="Facebook SEO" },
                new SelectListItem{ Value="ls", Text="LinkedIn SEO" },
                new SelectListItem{ Value="ts", Text="Twitter SEO" },
                new SelectListItem{ Value="qs", Text="Quora SEO" },
                new SelectListItem{ Value="ms", Text="Medium SEO" },
                new SelectListItem{ Value="ss", Text="Slide Share SEO" },
            };
        }
    }
}
