﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNTShared
{
    public enum EnumTrainingMode : int
    {
        Any = 1,
        Classroom = 2,
        Online = 3,
        SelfPlaced = 4
    }
    public enum EnumInvoiceType : int
    {
        Personal = 0,
        B2B = 1,
    }
    public enum EnumArticleLevel : int
    {
        DNTL100 = 100,
        DNTL200 = 200,
        DNTL300 = 300,
        DNTL400 = 400,
        DNTL500 = 500,
    }
    public enum EnumDaysType : int
    {

        Monday = 0,
        Tuesday = 1,
        Wednesday = 2,
        Thursday = 3,
        Friday = 4,
        Saturday = 5,
        Sunday = 6,
    }
    //Membership
    public enum EnumMembership : int
    {
        Monthly = 125,
        Quarterly = 126,
        Halfyearly = 127,
        Yearly = 128,
        Promo = 198,
        Trial = 199,
        Business = 200
    }

    //course type i.e. program type
    public enum EnumCourseType : int
    {
        Instructorled = 1,
        SelfPlaced = 2, //update courses set CourseType=2 where CourseType==0
        Books = 3,
        Membership = 4,
        BootCamp = 5, //not in use, update courses set CourseType=5 where CourseType==2
        LearningPath = 6,
        Project = 7,
        HandsOnLab = 8, //not in use
        Support = 9,
        Empowerment = 10 //not in use
    }

    public enum EnumFaqType : int
    {
        Course = 0,
        MastersProgram = 1,
        SelfPlacedProgram = 2,
        BootCamp = 3
    }

    public enum EnumArticleType : int
    {
        Beginners = 1,
        Intermediate = 2,
        Advanced = 3,
        Questions = 4
    }
    public enum EnumCurrency : int
    {
        INR,
        USD,
        EUR,
        CAD,
        CNY
    }
    public enum EnumEnquiryType : int
    {
        New = 1,
        Interested = 2,
        NotInterested = 3,
        Pending = 4,
        Fake = 5,
        Demo = 6,
        Closed = 7,
        // Student=8
        Completed = 8,
    }
    public enum EnumEventType : int
    {
        Seminar = 1,
        Webinar = 2,
        Bootcamp = 3
    }

    public enum EnumGenderType
    {
        Male,
        Female
    }
    public enum EnumMedalType : int
    {
        Gold = 1,
        Silver = 2,
        Bronze = 3
    }
    public enum EnumPaymentMode
    {
        PayPal,
        PayUMoney,
        Cash,
        Cheque,
        Neft,
    }
    public enum EnumRole : int
    {
        Admin = 1,
        Author = 2,
        User = 3,
        Consultant = 4
    }

    public enum EnumCertificateType : int
    {
        Course = 0,
        Article = 1,
        Event = 2,
    }

    //Need to remove
    //public enum EnumVideoType : int
    //{
    //    Course = 1,
    //    Project = 2,
    //    Recipe = 3,
    //    Interview = 4,
    //    LearningPath = 5
    //}

    public enum EnumDifficultyType : int
    {
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3

    }
    public enum EnumDifficultyLevel : int
    {
        DNTL100 = 100,
        DNTL200 = 200,
        DNTL300 = 300,
        DNTL400 = 400,
        DNTL500 = 500,
    }

    public enum EnumTopicType : int
    {
        Video = 1,
        Quiz = 2,
        Article = 3,
        Excercise = 4,
        CodeSandbox = 5,
        TPCodeSandbox = 6
    }
    public enum EnumCategoryType : int
    {
        Article = 1,
        Course = 2
    }
    public enum EnumTestType : int
    {
        SkillTest = 1,
        StudyModeQuiz = 2,
        MockupTest = 3
    }

    public enum EnumIDELanguage
    {
        none,
        csharp,
        html,
        java,
        javascript,
        python,
        typescript
    }


    public enum EnumDocType : int
    {
        Assignment = 2,
        SyllabusAndeBook = 3,
        ebookPreview = 4
    }

    //public enum EnumBookmarkType : int
    //{
    //    Course = 1,
    //    CourseTopic = 2,
    //    CourseSubTopic = 3
    //}

    
}
