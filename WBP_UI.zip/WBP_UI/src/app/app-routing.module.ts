import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from '../app/home/home.component';
import { LoginComponent } from '../app/login/login.component';
// import { AuthGuard } from '../app/_helpers/auth.guard';
import { AboutusComponent } from './aboutus/aboutus.component';
import { SiteLayoutComponent } from './_layout/site-layout/site-layout.component';
import { DashboardComponent } from './member/dashboard/dashboard.component';
import { ProfileComponent } from './member/profile/profile.component';
import { AuthorisedLayoutComponent } from './_layout/authorised-layout/authorised-layout.component';


const routes: Routes = [
   //Site routes goes here 
   { 
    path: '', 
    component: SiteLayoutComponent  ,
    children: [
      { path: '', component: HomeComponent, pathMatch: 'full'},
      { path: 'home', component: HomeComponent  },
      { path: 'about', component: AboutusComponent  },
      {  path: 'login', component: LoginComponent }
    ]
},
{ path: 'member', loadChildren: () => import('./member/member.module').then(m => m.MemberModule) },
{ path: '**', redirectTo: '' }

// App routes goes here here
// { 
//     path: 'member',
//     component: AuthorisedLayoutComponent , 
//     children: [
//       { path: 'dashboard', component: DashboardComponent },
//       { path: 'profile', component: ProfileComponent }
//     ]
// },
   

//no layout routes
// { path: 'login', component: LoginComponent},
// { path: 'register', component: RegisterComponent },

// otherwise redirect to home

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
