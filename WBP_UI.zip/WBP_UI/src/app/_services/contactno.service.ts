import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ContactDto } from '../_models/ContactDto';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { AppSetting } from '../_security/appSetting';

@Injectable({
  providedIn: 'root'
})
export class ContactNoService {

  appURL: string = environment.apiUrl + "ContactNo";
  appHeader: any = AppSetting.HTTTP_OPTION;
  
  constructor(private http: HttpClient) { }


  // GetCont() {
  //   return this.http.post<ContactDto>(this.appURL + '/buy/', entityObj, this.appHeader);
  // }

  GetMyContact(wano: string): Observable<ContactDto[]> {
    return this.http.get<ContactDto[]>(this.appURL + '/GetMyContact/?wano=' + wano);
  }

}
