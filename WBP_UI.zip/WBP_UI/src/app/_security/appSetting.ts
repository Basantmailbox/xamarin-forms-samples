import { HttpHeaders } from "@angular/common/http";



export class AppSetting {

 //static API_URL: string = "https://localhost:44327/api/";

  static HTTTP_OPTION= {
    headers: new HttpHeaders({ 'Content-Type': 'application/json'})
  };


}