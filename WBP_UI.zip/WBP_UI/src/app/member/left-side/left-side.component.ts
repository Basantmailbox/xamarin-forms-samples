import { Component, OnInit } from '@angular/core';
import { ContactNoService } from 'src/app/_services/contactno.service';

@Component({
  selector: 'app-left-side',
  templateUrl: './left-side.component.html',
  styleUrls: ['./left-side.component.scss']
})
export class LeftSideComponent implements OnInit {

  constructor(
    private _contactnoService: ContactNoService 
    ) { 


    }

  ngOnInit(): void {
  }
GetLeftSideContacts(){
  this._contactnoService.GetMyContact("8860563533")
  .subscribe(respons => {
    debugger;
    
    this.creditAllocatedObjs= respons;
    this.dataSource.data = this.creditAllocatedObjs;
  },
    error => console.log("Error (GetData) :: " + error)
  );
}


}
