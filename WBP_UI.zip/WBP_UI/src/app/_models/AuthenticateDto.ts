export class AuthenticateDto {
    Username: string;
    Password: string;
}