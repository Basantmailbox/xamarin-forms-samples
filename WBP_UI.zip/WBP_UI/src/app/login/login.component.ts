import { Component, OnInit, DebugElement } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ReactiveFormsModule  } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../_services/auth.service';

import { first } from 'rxjs/operators';
import { AuthenticateDto } from '../_models/AuthenticateDto';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    error = '';
    authenticateDto : AuthenticateDto;

    constructor(
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private authenticationService: AuthService,
      private toastr: ToastrService,
  ) { 
    debugger;
      // redirect to home if already logged in
      if (this.authenticationService.currentUserValue) { 
          this.router.navigate(['/member/dashboard']);
      }
  }



  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });

  // get return url from route parameters or default to '/'
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';

  this.authenticateDto = new AuthenticateDto();
}

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }


    onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }
debugger;
      this.loading = true;
      debugger;
      this.authenticateDto.Username=this.f.username.value;
      this.authenticateDto.Password=this.f.password.value;

      this.authenticationService.login(this.authenticateDto)
          .pipe(first())
          .subscribe(
              data => {
                debugger;
                this.toastr.warning("Welcome.");
                  this.router.navigate([this.returnUrl]);
              },
              error => {
                debugger;
                console.log("Error (onSubmit) :: " + error.message)
                this.toastr.warning(error.message);
                  this.loading = false;
              });
  }


}
