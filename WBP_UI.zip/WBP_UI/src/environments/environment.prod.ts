export const environment = {
  production: true,
  apiUrl: 'http://localhost:55834/api'
};
